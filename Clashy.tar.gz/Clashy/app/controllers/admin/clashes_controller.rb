class Admin::ClashesController < ApplicationController
  layout 'admin'
  before_filter :login_required
  before_filter:login_admin
  protect_from_forgery :except => [:clash_summary]

  def index

  end

  def new

  end

  def create
  end

  def edit
  end

  def update
  end

  def show
  end

  def destroy
    @clash=Clash.find(params[:id])
    @clash.destroy
     respond_to do |format|
      format.html { redirect_to(clash_summary_path) }
      format.xml  { head :ok }
      end
    #~ @clash=Clash.find(params[:id])
      #~ if params[:status]=="true"
        #~ @clash.update_attribute(:is_disable,true)
      #~ else
        #~ @clash.update_attribute(:is_disable,false)
      #~ end
      #~ if request.xhr?
        #~ @clashes=Clash.all.paginate :page=>params[:page] ? params[:page] : 1,:per_page=>10
        #~ render :partial=>"clash_summary"
        #~ render :nothing=>true
        #~ return
      #~ else redirect_to clash_summary_path
         #~ end
  end

def clash_day
    if params[:status]=="next"
     @clashes=params[:day].to_i<0? Clash.clash_daily_event((params[:day].to_i*-1).days.ago.to_date) : Clash.clash_daily_event((params[:day].to_i).days.since.to_date)
     @date=params[:day].to_i<0? (params[:day].to_i*-1).days.ago.to_date : (params[:day].to_i).days.since.to_date
      render :partial=>"clash_day",:locals=>{:clashes_collection=>@clashes}
    elsif params[:status]=="previous"
      @clashes=params[:day].to_i<0? Clash.clash_daily_event((params[:day].to_i*-1).days.ago.to_date) : Clash.clash_daily_event((params[:day].to_i).days.since.to_date)
      @date=params[:day].to_i<0? (params[:day].to_i*-1).days.ago.to_date : (params[:day].to_i).days.since.to_date
       render :partial=>"clash_day",:locals=>{:clashes_collection=>@clashes}
    else
     #~ @clashes=Clash.clash_daily_event(Time.now.to_date).paginate(:page=>params[:page] ? params[:page] : 1,:per_page => 10)
     @clashes=Clash.clash_daily_event(Time.current.to_date)
     @date=Time.current.to_date
     render :partial=>"clash_day", :locals=>{:clashes_collection=>@clashes}
     end
  end

  def clash_week
		@week_clashes = Clash.find_by_sql("SELECT * FROM clashes WHERE DATE(created_at) >= DATE(CURRENT_DATE - INTERVAL '7 DAY') and DATE(created_at) <= DATE(CURRENT_DATE)") rescue {}
    render :partial=>"clash_week"
  end

  def clash_month
    @duration=Time.current.day-Time.current.at_beginning_of_month.day
    render :partial=>"clash_month", :locals=>{:month_duration=>@duration}
 end

  def clash_summary
    if params[:clash_title] and !params[:clash_title].blank?
      #@clashes=Clash.all.paginate (:conditions=>['title LIKE (?)',"%#{params[:clash_title]}%"], :page=>params[:page], :per_page=>10)
      @clashes=Clash.all(:conditions=>['title LIKE (?)',"%#{params[:clash_title]}%"]).paginate(:per_page => 3, :page => params[:page] ? params[:page] : 1)
    else
      @clashes = Clash.all.paginate :page=>params[:page] ? params[:page] : 1,:per_page=>50
      if request.xhr?
              @clashes = Clash.all.paginate :page=>params[:page] ? params[:page] : 1,:per_page=>50
             render :partial=>"clash_summary", :locals=>{:summary_collection=>@clashes}
        end
    end
  end
  end
