class Admin::FaqsController < ApplicationController
  layout 'admin'
  before_filter :login_required
  before_filter:login_admin
  before_filter :find_faq, :only =>['edit','update']
  def new

  end

  def create
    Faq.create(params[:faq])
    redirect_to :action=>"index"
  end

  def edit
  end

  def update
     if @faq.update_attributes(params[:faq])
         redirect_to admin_faqs_path
     else
       render :action=>'edit'
    end
  end

  def destroy
    Faq.find(params[:id]).destroy
    @faqs=Faq.all.paginate(:page => params[:page] ? params[:page] : 1,:per_page =>10)
    render :partial=>"faqs_listings",  :locals=>{:faq_collection=>@faqs}
  end

  def show

  end

  def index
    @faqs=Faq.all.paginate(:page => params[:page] ? params[:page] : 1,:per_page =>10)
    if request.xhr?
      render :partial=>"faqs_listings", :locals=>{:faq_collection=>@faqs}
    end
  end

protected

  def find_faq
    @faq = Faq.find(params[:id])
  end
end
