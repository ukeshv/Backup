class Admin::ReportsController < ApplicationController
  layout 'admin'
  before_filter :login_required
  before_filter:login_admin
  protect_from_forgery :except => [:destroy]

  def new
  end

  def create
  end

  def edit
  end

  def update
    @report = Report.find(params[:id]).clash
      if  params[:delete][:accepted]=="1"
       @report.update_attribute(:is_disable,true)
        Report.find(params[:id]).destroy
        redirect_to admin_reports_path
      else
        redirect_to admin_reports_path
      end
  end

  def destroy
    @report=Report.find(params[:id])
    @report.destroy
      respond_to do |format|
      format.html { redirect_to(admin_reports_path) }
      format.xml  { head :ok }
      end
    #~ report=Report.find(params[:id])
    #~ a=report.clash.update_attribute(:is_disable,true)
    #~ Report.delete(params[:id])
    #~ @reports_old=Report.all.paginate(:page=>params[:page] ? params[:page] : 1,:per_page =>10)
    #~ @reports=Report.all.paginate(:page=>params[:page] ? (@reports_old.empty? ? 1 : params[:page]) : 1,:per_page =>10)
    #~ render :partial=>"reports_listings" , :locals=>{:report_collection=>@reports}
  end

  def show
    @report=Report.find(params[:id])
  end

  def index
    @reports=Report.all.paginate(:page=>params[:page] ? params[:page] : 1,:per_page =>10)
    if request.xhr?
      render :partial =>"reports_listings" , :locals=>{:report_collection=>@reports}
    end
  end

end
