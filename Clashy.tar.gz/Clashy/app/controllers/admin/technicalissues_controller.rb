class Admin::TechnicalissuesController < ApplicationController
  layout 'admin'
  before_filter :login_required
  before_filter:login_admin
  protect_from_forgery :except => [:destroy]
  def new
  end

  def create
  end

  def index
    @issues=Technicalsupport.all.paginate :page=>params[:page] ? params[:page] : 1,:per_page=>10
        if request.xhr?
      render :partial =>"technical_issue" , :locals=>{:issue_collection=>@issues}
    end
  end

  def show
  end

  def update
    if  params[:delete][:accepted]=="1"
      Technicalsupport.find(params[:id]).destroy
      redirect_to admin_technicalissues_path
    else
      redirect_to admin_technicalissues_path
    end
  end

  def show
    @issue=Technicalsupport.find(params[:id])
  end

  def destroy
    p params.inspect
    Technicalsupport.delete(params[:id])
    @issues_old=Technicalsupport.all.paginate(:page=>params[:page] ? params[:page] : 1,:per_page =>10)
    @issues=Technicalsupport.all.paginate(:page=>params[:page] ? (@issues_old.empty? ? 1 : params[:page]) : 1,:per_page =>10)
    render :partial=>"technical_issue" , :locals=>{:issue_collection=>@issues}
  end

end
