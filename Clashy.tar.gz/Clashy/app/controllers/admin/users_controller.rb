class Admin::UsersController < ApplicationController
  layout 'admin'
  before_filter :login_required
  before_filter:login_admin
  def index
    @users=User.all(:conditions=>["is_admin=?",false]).paginate :page=>params[:page] ? params[:page] : 1,:per_page=>10
    sql = ActiveRecord::Base.connection();
    if RAILS_ENV=="production"
      @online_users = sql.execute("SELECT count(*) FROM sessions WHERE updated_at > (now()-INTERVAL '30 minutes');") rescue {}
      @users_online=@online_users.to_a[0]["count"]
    else
      @users_online = sql.execute("SELECT count(*) FROM sessions WHERE updated_at > (now()-interval 30 minute);").fetch_row[0] rescue {}
    end
    #~ @users_online = User.online_users.all(:conditions=>["is_admin=?",false]).count
    if request.xhr?
        render :partial =>"users", :locals => { :users_collection=>@users }
      end
  end

  def new
  end

  def create
  end

  def edit
  end

  def update
  end

  def show

  end

  def destroy
    @user=User.find(params[:id])
    if params[:status]=="true"
      @user.update_attribute(:is_disable,true)
      EmailUser.disable_user(@user).deliver
    else
      @user.update_attribute(:is_disable,false)
      end
    if request.xhr?
      @users=User.all(:conditions=>["is_admin=?",false]).paginate :page=>params[:page] ? params[:page]  : 1,:per_page=>10
      render :partial=>"users", :locals => { :users_collection=>@users }
      return
    else redirect_to admin_users_path
    end
  end

  def show_users
    @users = User.online_users.all(:conditions=>["is_admin=?",false]).paginate :page=>params[:page] ? params[:page] : 1,:per_page=>10
    render :partial=>"users", :locals => { :users_collection=>@users }
  end
end
