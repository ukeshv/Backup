require 'authenticated_system.rb'
class ApplicationController < ActionController::Base
  include AuthenticatedSystem
  protect_from_forgery
  before_filter :check_website_url
  before_filter :set_is_disable_to_true
  before_filter :get_user_from_cookie

  def set_is_disable_to_true
    clash = Clash.find(:all,:conditions=>["is_disable=?",false]).select{|v| (v.end_date<=>(Time.current)).eql?(-1)} rescue []
    unless clash.empty?
      clash.each do |clsh|
        clsh.is_disable=true
        clsh.save
      end
    end
  end

  def check_website_url
    if request.env["HTTP_HOST"].include?('www.') && RAILS_ENV!="development"
      redirect_to ("http://"+request.env["HTTP_HOST"].split("www.").join+request.request_uri)
    end
  end

def get_country_name(code)
		return Ipaddress.where(:country_code=>code).first.country_name rescue "-"
	end

def login_admin
  if !current_user.is_admin?
    redirect_to "/"
    end
  end

def get_user_from_cookie
    if cookies[:auth_token] && !cookies[:auth_token].blank?
      current_user=User.find_by_remember_token(cookies[:auth_token])
      session[:user_id]=current_user.id rescue nil
    end
  end
end
