# This controller contains the business logic related to cookbook
# chapters. For more details, see the documentation for each public
# instance method.

class ClashesController < ApplicationController
  require 'youtube_g'
  require 'flickraw'
  layout 'clash'
  before_filter :check_clash, :only=> ['show']
  before_filter :check_clash_and_item, :only => ['vote_for_item','vote_statistics','votes_by_day']
  before_filter :find_clash, :only =>['vote_for_item','vote_statistics','votes_by_day']
  before_filter :check_clash_is_finalized,:only=>['show']
  def new
    @attachment = Attachment.new
  end

  def create
    item_a_options={:name => params[:item_1_name]}
    if (params[:item_a] && params[:item_a][:item])
      attachment_a = Attachment.create(params[:item_a]) rescue nil
      item_a_options.update(:attachment_id => attachment_a.id)
    elsif (params[:item_1_url] && !params[:item_1_url].blank?)
      item_a_options.update(:video_url=>params[:item_1_url])
    elsif (params[:item_1_text] && !params[:item_1_text].blank?)
      item_a_options.update(:quote=>params[:item_1_text])
    end
    item_a = Item.create(item_a_options)

    item_b_options={:name => params[:item_2_name]}
    if (params[:item_b] && params[:item_b][:item])
      attachment_b = Attachment.create(params[:item_b]) rescue nil
      item_b_options.update(:attachment_id => attachment_b.id)
    elsif (params[:item_2_url] && !params[:item_2_url].blank?)
      item_b_options.update(:video_url=>params[:item_2_url])
    elsif (params[:item_2_text] && !params[:item_2_text].blank?)
      item_b_options.update(:quote=>params[:item_2_text])
    end
    item_b = Item.create(item_b_options)
    clash = Clash.create(:user_id => current_user ? current_user.id : nil,:title => params[:clash_name],:item_one_id => item_a.id,:item_two_id => item_b.id,:duration => params[:duration] ? params[:duration].to_i : nil,:end_date=> params[:duration].to_i.days.since(Time.current),:ip_address=>request.remote_ip,:is_disable=>false,:is_finalize => true)
    redirect_to clash_path(:id=>clash,:share=>true)
  end

  def edit
    @clash = Clash.find(params[:id])
    if current_user && @clash.user_id==current_user.id || !((current_user && @clash.user_id==!current_user.id)rescue false)
      @item_a=Item.find(@clash.item_one_id)
      @item_b=Item.find(@clash.item_two_id)
      @days_diff = (@clash.end_date.to_date-@clash.created_at.to_date).to_i
      @attach_a_name = Attachment.find(@item_a.attachment_id).item_file_name rescue nil
      @attach_b_name = Attachment.find(@item_b.attachment_id).item_file_name rescue nil
    else
      redirect_to "/anything"
    end
  end

  #~ def update
    #~ clash = Clash.find(params[:id])
    #~ finalize=clash.finalize rescue nil
    #~ unless finalize.nil?
      #~ finalize.update_attributes({:item_a_name => params[:item_1_name],:item_b_name => params[:item_2_name],:clash_name => params[:clash_name],:duration => params[:duration],:clash_id =>params[:id]}) ? Clash.find(params[:id]).update_attributes({:is_finalize => false}) : Clash.find(params[:id]).update_attributes({:is_finalize => true})
    #~ else
      #~ Finalize.create({:item_a_name => params[:item_1_name],:item_b_name => params[:item_2_name],:clash_name => params[:clash_name],:duration => params[:duration],:clash_id =>params[:id]}) ? Clash.find(params[:id]).update_attributes({:is_finalize => false}) : Clash.find(params[:id]).update_attributes({:is_finalize => true})
    #~ end
    #~ redirect_to clash_path(:id=>params[:id],:share=>true,:from_update=>true)
  #~ end
  
  def update
    clash=Clash.find(params[:id])
    item_a=Item.find(clash.item_one_id)
    item_b=Item.find(clash.item_two_id)
    clash.update_attributes({"title"=>params[:clash_name], "end_date"=>params[:duration].to_i.days.since(clash.created_at)})
    item_a.update_attribute(:name,params[:item_1_name])
    item_b.update_attribute(:name,params[:item_2_name])
    #redirect_to clash_path(:id=>clash,:share=>true)
    redirect_to clash_path(:id=>clash, :share=>true, :from_update=>true)
  end
  
  def show
    @clash= params[:id] ? Clash.find(params[:id]) : Clash.find_by_permalink(params[:permalink])
    @clash.view_count = (@clash.view_count ? @clash.view_count+=1 : 1)
    @clash.save
    @item_a, @item_b = @clash.get_clashed_items
    @item_a_url=Attachment.find(@item_a.attachment_id).item.url if @item_a.attachment_id
    @item_b_url=Attachment.find(@item_b.attachment_id).item.url if @item_b.attachment_id
    @embed_video={}
    fetch_media_data("item_a", @item_a.video_url) if @item_a.video_url
    fetch_media_data("item_b", @item_b.video_url) if @item_b.video_url
  end

  #~ def show
    #~ @clash= params[:id] ? Clash.find(params[:id]) : Clash.find_by_permalink(params[:permalink])
    #~ finalize = @clash.finalize rescue nil
    #~ if params[:share] && finalize
      #~ item_one = Item.find_by_id(@clash.item_one_id)
      #~ item_two = Item.find_by_id(@clash.item_two_id)
      #~ @clash.view_count = (@clash.view_count ? @clash.view_count+=1 : 1)
      #~ @clash.is_finalize=true
      #~ @clash.end_date = finalize.duration.to_i.days.since(@clash.created_at)
      #~ @clash.duration = finalize.duration
      #~ @clash.title = finalize.clash_name
      #~ item_one.name=finalize.item_a_name
      #~ item_two.name=finalize.item_b_name
      #~ item_one.save
      #~ item_two.save
      #~ @clash.save
    #~ elsif finalize.nil? && params[:share]
      #~ @clash.is_finalize=true
      #~ @clash.save
    #~ else
      #~ if @clash && @clash.is_disable.eql?(true)
        #~ redirect_to vote_statistics_clashes_path(:clash_id=>@clash.id, :item_id=>@clash.item_one_id)
      #~ end
      #~ @clash.view_count = (@clash.view_count ? @clash.view_count+=1 : 1)
      #~ @clash.save
    #~ end
    #~ @item_a, @item_b = @clash.get_clashed_items
    #~ @embed_video={}
    #~ fetch_media_data("item_a", @item_a.video_url) if @item_a.video_url
    #~ fetch_media_data("item_b", @item_b.video_url) if @item_b.video_url
    #~ @item_a_url=Attachment.find(@item_a.attachment_id).item.url if @item_a.attachment_id
    #~ @item_b_url=Attachment.find(@item_b.attachment_id).item.url if @item_b.attachment_id
    #~ if params[:from_update]
      #~ @finalize=Finalize.find_by_clash_id(params[:id])    
    #~ end
  #~ end

  def index
      oauth = Koala::Facebook::OAuth.new(APP_CONFIG[:facebook_app_id],"#{APP_CONFIG[:facebook_app_secret]}")
     @facebook_client ||= if @facebook_cookies = oauth.get_user_info_from_cookies(cookies)
     Koala::Facebook::GraphAPI.new(@facebook_cookies['access_token'])
   end
  if @facebook_client
           profile = @facebook_client.get_object("me") 
           @user=User.find_by_email(profile["email"])
           @user=User.create(:email => profile["email"], :password =>profile['id'], :password_confirmation =>profile['id'], :is_admin => false, :is_loggedin => true,:is_disable => false) unless @user
           self.current_user =@user
           self.session[:user_id]=@user.id
         end
    if current_user
      @currentclashes=current_user.clashes.where(:is_disable=>false).all.paginate :page=>params[:page],:per_page=>10
      @completedclashes=current_user.clashes.where(:is_disable=>true).all.paginate :page=>params[:page],:per_page=>10
      if request.xhr?
        if params[:clash_type]=="current"
          render :partial =>'clashes/partial/current_clashes', :locals => { :currentclashes_collection=>@currentclashes }
        elsif params[:clash_type]=="completed"
         render :partial =>'clashes/partial/completed_clashes', :locals => { :completedclashes_collection=>@completedclashes }
        end
      end
    else
      redirect_to "/"
    end
    rescue
     logout_killing_session!
    redirect_to "/"
  end

def clashy_technical
	@techsupport=Technicalsupport.new(params[:tech])
	if @techsupport.save
		render :update do |p|
		p.redirect_to '/'
		end
	else
	error={:issue_blank=>(params[:tech][:issue].length>500 ? "Please limit only 500 Characters" : "")}
	       if params[:tech][:issue].strip.empty?
		       error[:issue_error]="Enter clashy problem"
	       end
	       if params[:tech][:contact_email].empty?
		       error[:email_blank]="Enter an Email address"
	       end
	       if params[:tech][:issue].length>500
			error[:issue_blank]="Please limit only 500 Characters"
	       end
         error[:email_invalidd]=(@techsupport.errors[:contact_email].member?("should look like an email address.") && !params[:tech][:contact_email].empty?) ? "Unknown Email Address. Please try again." : ""
	 render :json => error.to_json
	end
end

  def clashy_report
    #Report.create(params[:report])
    @report = Report.new(params[:report])
    success = @report && @report.valid?
    if @report.save
     render :update do |p|
        p.redirect_to "/"
      end
    else
	error={}
	if params[:report][:feedback].strip.empty?
       error[:feedback_error]="Enter Report about the clash items"
	end
	if params[:report][:contact_email].empty?
      error[:email_error]="Enter an Email address"
	end
	if params[:report][:feedback].length>500
	error[:feedback_blank]="Please limit only 500 Characters"
	end
	error[:email_invalid]=(@report.errors[:contact_email].member?("should look like an email address.") && !params[:report][:contact_email].empty?) ? "Invalid Email Address" : ""
    render :json => error.to_json
    end
  end

  def clashy_browse
    #@clashes=Clash.paginate(:page => params[:page], :per_page=>7) rescue []
    #@clashes = Clash.find(:all,:conditions => ["is_finalize = ?", true]).paginate(:page => params[:page], :per_page=>7) rescue []
    if params[:sort]
      if params[:sort].include?("item_one_id")
       if params[:sort].include?("desc")
          @clashes = Clash.find_by_sql("select * from clashes c inner join items i on i.id = c.item_one_id order by i.name desc").paginate(:page=>params[:page], :per_page => 7) rescue[]
      else
          @clashes = Clash.find_by_sql("select * from clashes c inner join items i on i.id = c.item_one_id order by i.name asc").paginate(:page=>params[:page], :per_page => 7) rescue[]        
      end   
      else
        @clashes = Clash.find(:all,:order=>"#{params[:sort]}").paginate(:page=>params[:page], :per_page => 7) rescue[]
      end
    else 
      @clashes = Clash.find(:all,:order=>"created_at desc").paginate(:page=>params[:page], :per_page => 7) rescue[]
    end  
    if request.xhr?
       render  :partial =>"clashes/partial/browse_list"
    end
  end

  def vote_for_item
    @item=Item.find(params[:item_id])
    #~ clash_ip=@clash.ip_address.gsub(".","").to_i
    user_ip = get_valid_ip(request.remote_ip)
    remote_ip_location=Ipaddress.first(:conditions=>["number_one<=? and number_two>=?",user_ip,user_ip]).country_code rescue nil
    Hit.create(:ip_address=>request.remote_ip, :user_id=>session[:user_id], :clash_id=>@clash.id, :voted_for=>@item.id, :country_code=>remote_ip_location=="-" ? "IN" : remote_ip_location, :created_at=>Time.current, :updated_at=>Time.current)
    redirect_to vote_statistics_clashes_path(:clash_id=>@clash.id)
  end

  def vote_statistics
    @item=Item.find(@clash.item_one_id)
    #~ secondary = (@item.id == @clash.item_one_id ? @clash.item_two_id : @clash.item_one_id)
    @item_secondary=Item.find(@clash.item_two_id)
    primary_votes=Hit.where(:clash_id=>@clash.id, :voted_for=>@item.id)
    secondary_votes=Hit.where(:clash_id=>@clash.id, :voted_for=>@item_secondary.id)
    @total_votes=Hit.where(:clash_id=>@clash.id).count.to_f
    @vote_count=primary_votes.count
    @vote_count_secondary=secondary_votes.count
    if @clash.hits.empty?
      redirect_to "/anything"
      return false
    end
     sing_plu=@vote_count.eql?(1) ? "vote" : "votes"
    sing_plu_second=@vote_count_secondary.eql?(1) ? "vote" : "votes"
    @chart_array=[[@item.name+" #{(@vote_count*100/@total_votes).round(2)}%"+" (#{@vote_count.to_s+""+sing_plu})", @vote_count],[@item_secondary.name+" #{(@vote_count_secondary*100/@total_votes).round(2)}%"+" (#{@vote_count_secondary.to_s+""+sing_plu_second})", @vote_count_secondary]].flatten.*"^"

    primary_chart_hsh=primary_votes.group_by{|x| x.country_code}
    primary_chart=primary_chart_hsh.sort_by{|k,v| v.length}.reverse
    @primary_chart_array=[]
    @primary_chart_hash={}
    prim_vote_length=0
    primary_chart && primary_chart.each_with_index do |x,i|
      if i<4 || primary_chart.length==5
                    sing_plu_xlength=x[1].length.eql?(1) ? "vote" : "votes"
        @primary_chart_array<<[x[0]+" (#{x[1].length.to_s+""+sing_plu_xlength})",x[1].length]
        @primary_chart_hash[get_country_name(x[0])] = ((x[1].length/primary_chart_hsh.values.flatten.length.to_f)*100).round
      else
        prim_vote_length+=x[1].length
      end
    end
    if prim_vote_length>0
                  sing_plu_prim=prim_vote_length.eql?(1) ? "vote" : "votes"
      @primary_chart_array<<["other"+" (#{prim_vote_length.to_s+""+sing_plu_prim})",prim_vote_length]
      @primary_chart_hash["other"] = ((prim_vote_length/primary_chart_hsh.values.flatten.length.to_f)*100).round
    end
    @primary_chart_array = @primary_chart_array.flatten.*"^"

    secondary_chart_hsh=secondary_votes.group_by{|x| x.country_code}
    secondary_chart=secondary_chart_hsh.sort_by{|k,v| v.length}.reverse
    @secondary_chart_array=[]
    @secondary_chart_hash={}
    sec_vote_length=0
    secondary_chart && secondary_chart.each_with_index do |y,j|
      if j<4 || secondary_chart.length==5
                  sing_plu_ylength=y[1].length.eql?(1) ? "vote" : "votes"
        @secondary_chart_array<<[y[0]+" (#{y[1].length.to_s+""+sing_plu_ylength})",y[1].length]
        @secondary_chart_hash[get_country_name(y[0])] = ((y[1].length/secondary_chart_hsh.values.flatten.length.to_f)*100).round
      else
        sec_vote_length+=y[1].length
      end
    end
    if sec_vote_length>0
                      sing_plu_sec=sec_vote_length.eql?(1) ? "vote" : "votes"
      @secondary_chart_array<<["other"+" (#{sec_vote_length.to_s+""+sing_plu_sec})",sec_vote_length]
      @secondary_chart_hash["other"] = ((sec_vote_length/secondary_chart_hsh.values.flatten.length.to_f)*100).round
    end
    @secondary_chart_array = @secondary_chart_array.flatten.*"^"
  end
  
  def votes_by_day
    @clash= params[:clash_id] ? Clash.find(params[:clash_id]) : Clash.find_by_permalink(params[:permalink])
    @item=Item.find(@clash.item_one_id)
    @item_secondary=Item.find(@clash.item_two_id)
    @total_votes=Hit.where(:clash_id=>@clash.id).count.to_f
    @date_wise=[]
    starting_at = @clash.created_at.day
    if @clash.duration==7
      @duration=6
      raw_data = []
      @date_wise = [0,0,0,0,0,0,0]
      a=Hit.count(:all, :conditions=>["clash_id=?",@clash.id], :group => ["DATE(created_at)"]).collect{|a| raw_data<<a}
      i = 0      
      j = 0 
      while(i < @clash.duration) do
        pos = (raw_data[j][0].split("-").last).to_i
        if((starting_at+i) == pos)
          @date_wise[i] = raw_data[j][1]
          j = j + 1 if j < (raw_data.length-1)
        end         
        i = i + 1
      end
    elsif @clash.duration==30
      @duration=29
      raw_data = []
      @date_wise = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
      a=Hit.count(:all, :conditions=>["clash_id=?",@clash.id], :group => ["DATE(created_at)"]).collect{|a| raw_data<<a}
      i = 0      
      j = 0      
      while(i < @clash.duration) do
        pos = (raw_data[j][0].split("-").last).to_i
        if((starting_at+i) == pos)
          @date_wise[i] = raw_data[j][1]
          j = j + 1  if j < (raw_data.length-1)
        end         
        i = i + 1
      end
    else
      @duration=0
      raw_data = []
      a=Hit.count(:all, :conditions=>["clash_id=?",@clash.id], :group => ["DATE(created_at)"]).collect{|a| raw_data<<a}
      p raw_data[0][1]
      @date_wise[0] = raw_data[0][1]
    end 
    if @clash.hits.empty?
      redirect_to "/anything"
      return false
    end
  end
  def startaclash

  end

  def update_share_count
        clash=Clash.find(params[:clash_id])
    if params[:share_type]=="facebook"
      clash.fb_share_count = clash.fb_share_count ? clash.fb_share_count+1 : 1
    elsif params[:share_type]=="twitter"
      clash.tw_share_count = clash.tw_share_count ? clash.tw_share_count+1 : 1
    end
    clash.save
    fb_share_count = clash.fb_share_count ? clash.fb_share_count : 0
    tw_share_count = clash.tw_share_count ? clash.tw_share_count : 0
    render :text=>(fb_share_count + tw_share_count)
  end
  # Its to delete a current and completed clash
  def delete
    @clash=Clash.find(params[:id])
    @clash.destroy
     respond_to do |format|
      format.html { redirect_to(clashes_url) }
      format.xml  { head :ok }
      end
    end

  private

  def fetch_media_data(item,url)
    if url.include?("www.youtube.com")
      client=YouTubeG::Client.new
      video=client.video_by(url.scan(/v=(.*)[&|?]*/).to_s.split('&')[0]) rescue nil
      @embed_video["#{item}_youtube"]=video ? video.embed_url : nil
    elsif url.include?("www.flickr.com")
      FlickRaw.api_key="8f6f7417439d33d3bd4093e98acf8f5d"
      FlickRaw.shared_secret="58b1335ac01f10d4"
      info = flickr.photos.getInfo(:photo_id =>url.split("/").last)
      @embed_video["#{item}_flickr"]=FlickRaw.url(info) rescue FlickRaw.url_o(info) rescue FlickRaw.url_b(info)
    end
	end
  def check_clash
  redirect_to root_path() unless (Clash.all.map(&:id).collect{|ids| ids.to_s}.member?(params[:id]) || Clash.exists?(:permalink=>params[:permalink]))
  end
  def check_clash_and_item
    check_clash_id = params[:clash_id].to_s.match(/^\d+$/) == nil ? false : true
    check_item_id = params[:item_id].to_s.match(/^\d+$/) == nil ? false : true
    redirect_to clashy_browse_path() unless (check_clash_id || check_item_id) && Clash.exists?(params[:clash_id]) && Item.exists?(params[:item_id]) && !Clash.find(params[:clash_id]).get_clashed_items.collect(&:id).include?(params[:item_id])
  end
  def check_clash_is_finalized
     clash = params[:id] ? Clash.find_by_id(params[:id]) : Clash.find_by_permalink(params[:permalink])
     if (clash.is_finalize.eql?(true) || clash.is_finalize.eql?(false)) && (clash.user_id.eql?(current_user.id) rescue false)
    elsif clash.is_finalize.eql?(true) && !(clash.user_id.eql?(current_user.id) rescue false)
      elsif clash.user_id.nil?
           elsif  current_user.nil? && clash.is_finalize.eql?(false)
        redirect_to root_path
      else
      redirect_to root_path
    end
  end
  def check_date_clash
    clash = params[:id] ? Clash.find_by_id(params[:id]) : Clash.find_by_permalink(params[:permalink])
    (redirect_to vote_statistics_clashes_path(:clash_id=>clash.id) and return) if (clash.end_date<=>Time.current).eql?(-1)
  end
  def get_valid_ip(ip)
    ip_arr = ip.split('.')
    ip_addr = ((((ip_arr[0].to_i*256)+ip_arr[1].to_i)*256+ip_arr[2].to_i)*256 + ip_arr[3].to_i)
    return ip_addr
  end
  
protected

  def find_clash
    @clash=Clash.find(params[:clash_id])
  end
 end
