class HomesController < ApplicationController
  layout 'clash'
  def hiw

  end

  def about
  end

  def faq
    @faqs=Faq.all
  end

  def privacypolicy
  end

  def termsconditions
  end

  def contactus
  end

  def jobsatclashy
  end

  def error_site

  end

end
