require "authenticated_system.rb"
# This controller handles the login/logout function of the site.
class SessionsController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  include AuthenticatedSystem

  # render new.rhtml
  def new
    redirect_to "/error"
  end

  def create
    logout_keeping_session!
    #dis_user=User.find(:all, :conditions => ["email = ? AND is_disable = ?", params[:email],true])
    dis_user = User.find_by_email(params[:email])
    user = User.authenticate(params[:email], params[:password])
    if user
      if dis_user.is_disable == false or dis_user.is_disable.nil?
        self.current_user = user
        session[:user_id] = user.id
        user.update_attribute(:is_loggedin,true) unless user.is_admin?
        new_cookie_flag = (params[:remember_me] == "1")
        handle_remember_cookie!(params[:remember_me])
        new_cookie_flag

        if request.xhr?
          render :update do |p|
            if params[:from_clash] == "true"
              p "Test Clash here"
              p.call "goToClashPage"
            elsif user.is_admin?
              p.redirect_to clash_summary_path
            else
              p "Clash Here"
              p.redirect_to clashes_path
            end
          end
        else
          redirect_to "/"
        end
        return
      else
        login=User.find_by_email(params[:email])
        error={:dis_email=>(login.is_disable==true) ? "Oops,Your account is disabled. Contact Admin" : "",:email_blank=>(params[:email].blank? ? "Enter an Email Address" : ""),:password_blank=>(params[:password].blank? ? "Enter a Password" : ""),:invalid_email=>(!login) ? "Invalid email,try again" : ""}
        render :json => error.to_json
      end
    else
      login=User.find_by_email(params[:email])
      if (params[:email].length==0  || params[:password].length==0)
        #~ error={:email_blank=>(@a.blank? ? "Email should not be blank": "")}
        error={:email_blank=>(params[:email].blank? ? "Enter an Email Address" : ""),:password_blank=>(params[:password].blank? ? "Enter a Password" : ""),:invalid_email=>(!login) ? "Invalid email,try again" : ""}
        render :json => error.to_json
      else
        password=(user && login) ? "" : "Invalid password,try again or"
        error={:login => (!login) ? "Invalid email,try again" : "",:password => password,:blank=>""}
        render :json => error.to_json
      end
    end
  end

  def destroy
    if session[:user_id]
      user = User.find(session[:user_id])
      user.update_attribute(:is_loggedin,false)
    end
    logout_killing_session!
    redirect_back_or_default('/', :notice => "You have been logged out.")
  end

  def remove_online_user
    puts "--------remove_online_user-----------"
    puts params.inspect
  end

protected
  # Track failed login attempts
  def note_failed_signin
    flash.now[:error] = "Couldn't log you in as '#{params[:email]}'"
    logger.warn "Failed login for '#{params[:email]}' from #{request.remote_ip} at #{Time.now.utc}"
  end
end
