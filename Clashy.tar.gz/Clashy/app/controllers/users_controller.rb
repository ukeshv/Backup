require "authenticated_system.rb"
class UsersController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  include AuthenticatedSystem
  		  layout "clash",:only=>["reset","reset_password"]
  # Protect these actions behind an admin login
  # before_filter :admin_required, :only => [:suspend, :unsuspend, :destroy, :purge]
  before_filter :find_user, :only => [:suspend, :unsuspend, :destroy, :purge]


  # render new.rhtml
  def new
    @user = User.new
  end

  def create
    logout_keeping_session!
    @user = User.new(params[:user])
     success = @user && @user.valid?
    if success && @user.errors.empty? && params[:user][:password].length<20
      @user.save
      EmailUser.signup(@user).deliver
      # Protects against session fixation attacks, causes request forgery
      # protection if visitor resubmits an earlier form using back
      # button. Uncomment if you understand the tradeoffs.
      # reset session
      self.current_user = @user # !! now logged in
      #~ redirect_back_or_default('/', :notice => "Thanks for signing up!  We're sending you an email with your activation code.")
      render :update do |p|
        if params[:from_clash] == "true"
          p.call "goToClashPage"
        else
          p.redirect_to clashes_path
        end
      end
    else
     login=User.find_by_email(params[:user][:email])
     error={:email_blank=>(params[:user][:email].blank? ? "Enter Email Address" : ""),:confirm_email_blank=>(params[:user][:confirm_email].blank? ? "Enter Confirm-email" : ""),:password_blank=>(params[:user][:password].blank? ? "Enter a Password" : ""),:confirm_password_blank=>(params[:user][:password_confirmation].blank? ? "Enter Confirm Password" : ""),:email_mismatch=>(params[:user][:email]!=params[:user][:confirm_email] ? "#{ERRORS["Errors"]["Email_mismatch"]}" : ""),:password_mismatch=>(params[:user][:password]!=params[:user][:password_confirmation] ? "#{ERRORS["Errors"]["Password_mismatch"]}" : ""),:email_wrong=>(!params[:user][:email].blank? && @user.errors ? "#{@user.errors[:email]}" : ""),:taken_email=>(login) ? "#{@user.errors[:email]}" : "",:password_length=>(params[:user][:password].length<6) ? "6 characters min" : (params[:user][:password].length>20 ? "20 characters max" : "")}
      render :json => error.to_json
end
  end

  def suspend
    @user.suspend!
    redirect_to users_path
  end

  def unsuspend
    @user.unsuspend!
    redirect_to users_path
  end

  def destroy
    @user.delete!
    redirect_to users_path
  end

  def purge
    @user.destroy
    redirect_to users_path
  end
  def change_password
    #if !pwd.nil?
    if params[:password]==params[:confirm_password] && params[:password].length>=6 && User.authenticate(current_user.email, params[:old_password])
    # if User.authenticate(current_user.email, params[:old_password])
      current_user.update_attributes(:password=>params[:password],:password_confirmation=>params[:password])
      render :update do |p|
      p.redirect_to clashes_path
      end
    else
      pwd =  User.authenticate(current_user.email, params[:old_password])
      error={:length_password =>(params[:password].length<6) ? "Minimum 6 characters":"",:length_confirm=>(params[:confirm_password].length<6) ? "Minimum 6 characters":"",:password =>(params[:password]!=params[:confirm_password]) ? "Password and Confirm Password doesn't match":"",:password_blank=>(params[:password].length==0) ? "Enter New Password" : "", :confirm_blank=>(params[:confirm_password].length==0) ? "Enter Confirm Password" : "", :old_blank=>(params[:old_password].length==0) ? "Enter Old Password":"", :wrong_password=> pwd.nil? ? "Old Password is incorrect" : "",:length_password_max =>(params[:password].length>20) ? "Maximum 20 characters":"",:length_confirm_max =>(params[:confirm_password].length>20) ? "Maximum 20 characters":""}
      render :json => error.to_json
     end
    end
  def retrieve_password
    user=User.find_by_email(params[:contact_email])
    if user
      user.create_reset_code
     EmailUser.retrievepassword(user).deliver
      render :update do |p|
        #p.redirect_to "/"
        p.call "goToSuccessPage"
      end
    else
      error={:email_error=>(params[:contact_email].blank? || params[:contact_email] == "Enter Address" ? "Enter Email Address" : "#{ERRORS["Errors"]["Invalid_email"]}")}
      render :json => error.to_json
    end
  end

  # There's no page here to update or destroy a user.  If you add those, be
  # smart -- make sure you check that the visitor is authorized to do so, that they
  # supply their old password along with a new one to update it, etc.
  def reset
    @reset=User.find_by_reset_code(params[:reset_code])
    if @reset.nil?
      redirect_to '/'
      end
  end

  def reset_password
    reset=User.find(params[:reset])
    if reset
      p reset
    reset.update_attributes(:password=>params[:password],:password_confirmation=>params[:password],:reset_code=>nil)
    render :update do |f|
    f.redirect_to "/"
    end
    else
      f.redirect_to "/"
    end
  end
  protected

  def find_user
    @user = User.find(params[:id])
  end
end
