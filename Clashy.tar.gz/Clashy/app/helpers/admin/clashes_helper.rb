module Admin::ClashesHelper
 def day_clashes_for_week(week_day)
		Clash.find(:all,:conditions=>["Date(created_at) <= ? AND Date(end_date) >=  ? AND is_disable = ?", week_day, week_day,false])
	end
	def day_clashes_for_month(monthly_day)
		#Clash.find(:all,:conditions=>["Date(created_at) <= ? AND Date(end_date) >=  ? AND is_disable = ?", monthly_day, monthly_day,false])
		#Clash.find(:all,:conditions=>["month(created_at) = ?",monthly_day])
                Clash.find(:all,:conditions=>["EXTRACT(MONTH FROM created_at) = ?",monthly_day])
 end
end
