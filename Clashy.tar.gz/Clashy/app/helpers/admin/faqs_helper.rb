module Admin::FaqsHelper
end
