module ApplicationHelper
  def commify(data)
    return data.to_s.gsub(/(\d)(?=\d{3}+(\.\d*)?$)/, '\1,')
  end
  def calc_total_share(clash_id)
    clash=Clash.find(clash_id)
    fb_share_count = clash.fb_share_count ? clash.fb_share_count : 0
    tw_share_count = clash.tw_share_count ? clash.tw_share_count : 0
    return (fb_share_count + tw_share_count)
  end
end
