class EmailUser < ActionMailer::Base
  default :from => "from@example.com"
  def retrievepassword(user)
    @url = "#{APP_CONFIG[:site_url]}/reset/#{user.reset_code}"
    @user=user
    mail(:from=>"#{APP_CONFIG[:admin_email]}",:to=>user.email,
            :subject=>'Reset your Password')
  end

  def signup(user)
    @user=user
    mail(:from=>"#{APP_CONFIG[:admin_email]}",:to=>user.email,
            :subject=>'Account Registration')
  end

  def disable_user(user)
    @user=user
    mail(:from=>"#{APP_CONFIG[:admin_email]}",:to=>user.email,
            :subject=>'Your Account Disabled')
  end
end
