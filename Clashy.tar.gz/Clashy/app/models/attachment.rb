class Attachment < ActiveRecord::Base
	 has_attached_file :item, :styles => { :medium => "300x300>", :thumb => "100x100>" }, :storage => :s3,:s3_credentials => "#{RAILS_ROOT}/config/s3.yml",:path => "/items/:id/:style/:filename"#,:bucket => 'clashy-development'
	 attr_accessible :item
end
