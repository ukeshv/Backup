require 'time_diff.rb'
class Clash < ActiveRecord::Base
	has_many :hits
	has_one :finalize
	has_many :reports, :dependent => :destroy
	belongs_to :user
	after_create :create_permalink
	#Retrieves the daily Clash Events
	scope :clash_daily_event, lambda{|date| {:conditions=>["Date(created_at) <= ? AND Date(end_date) >=  ? AND is_disable = ?", date, date,false]}}
	
	def week_diff(start_date,end_date)
		date_diff= Time.diff(start_date,end_date)
		return date_diff[:week].to_i
	end
	
	def day_diff(start_date,end_date)
		date_diff= Time.diff(start_date,end_date)
		return date_diff[:day].to_i
	end
	def hour_diff(start_date,end_date)
		date_diff= Time.diff(start_date,end_date)
		return date_diff[:hour].to_i
	end
	def min_diff(start_date,end_date)
		date_diff= Time.diff(start_date,end_date)
		return date_diff[:minute].to_i
	end
	def get_clashed_items
		return Item.find(self.item_one_id),Item.find(self.item_two_id)
	end
	def create_permalink
		self.permalink = self.build_random_string(6)
		self.save
	end
	def get_permalink
		str = (self.permalink && !self.permalink.blank? && !self.permalink.nil?) ? self.permalink : Clash.first.permalink
		return  "#{APP_CONFIG[:site_url]}/clashy/#{str}"
	end	
	
	def build_random_string(len)
		a = ('A'..'Z').to_a+('a'..'z').to_a+(0..9).to_a
		return (1..len).collect { a[rand(a.size)] }.join
	end
	
end
