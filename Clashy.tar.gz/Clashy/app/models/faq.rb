#It represents the faq information and the data from the database.
#It also does the validation of the data before it gets into the database.

class Faq < ActiveRecord::Base
  validates :question, :presence   => true,
																:uniqueness => true
  validates :answer, :presence => true #, :message => 'Answer cannot be blank'
end

