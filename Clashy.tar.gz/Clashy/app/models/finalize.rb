class Finalize < ActiveRecord::Base
	belongs_to :clash
end
