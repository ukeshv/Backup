class Ipaddress < ActiveRecord::Base
end
