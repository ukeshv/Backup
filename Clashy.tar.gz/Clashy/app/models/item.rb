class Item < ActiveRecord::Base
	has_one :attachment
end
