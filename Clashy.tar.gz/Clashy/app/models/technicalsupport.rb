class Technicalsupport < ActiveRecord::Base
	  validates :contact_email, :presence   => true,
                   #~ #:uniqueness => true,
                     :format     => { :with => Authentication.email_regex, :message => Authentication.bad_email_message }
                     #~ :length     => { :within => 6..100 }
										
		validates :issue, :presence => true,
								  :length   => { :within => 1..500 }	
end

	