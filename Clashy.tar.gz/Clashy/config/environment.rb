 # Load the rails application
require File.expand_path('../application', __FILE__)
#loads errors for the project
ERRORS = YAML.load_file("#{RAILS_ROOT}/config/errors.yml")

# Initialize the rails application
Clashy::Application.initialize!
