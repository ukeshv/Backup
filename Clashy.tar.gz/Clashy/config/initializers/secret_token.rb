# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Clashy::Application.config.secret_token = 'f9e8428c963864f83c749babe86db500cda478759496a2f06cd3b33ede2055a59c66b21a9dc3da020052dd1252c9895db02c2359b90fa52cfa6e526687565067'
