Clashy::Application.routes.draw do
  resources :users do
   collection do
   get :reset_password
  end
  end
  resources :clashes do
    collection do
      get :vote_for_item
      get :vote_statistics
      get :update_share_count
      get :votes_by_day
    end
  end
  resources :index
   #~ resources :sessions

  resource :session, :only => [:new, :create, :destroy]
  match '/clashy/:permalink' => 'clashes#show'

  match 'signup' => 'users#new', :as => :signup

  match 'register' => 'users#create', :as => :register

  match 'login' => 'sessions#new', :as => :login

  match 'logout' => 'sessions#destroy', :as => :logout
  match 'change_password' => 'users#change_password', :as => :change_password
  #~ match '/users/reset_password' => 'users#reset_password'

  #~ match '/session/create' => 'sessions#create'
  match '/activate/:activation_code' => 'users#activate', :as => :activate, :activation_code => nil
  #Admin named_routes
  match '/admin/clashes/clash_day' => 'admin/clashes#clash_day',:as => :clash_day_clashes_admin
  match '/admin/clashes/clash_week' => 'admin/clashes#clash_week',:as => :clash_week_clashes_admin
  match '/admin/clashes/clash_month' => 'admin/clashes#clash_month',:as => :clash_month_clashes_admin
  match '/admin/clashes/clash_summary' => 'admin/clashes#clash_summary',:as => :clash_summary
  match '/admin/users/show_users' => 'admin/users#show_users',:as => :show_users_users_admin
    match 'retrieve_password' => 'users#retrieve_password', :as => :retrieve_password

   match '/clashes/:id/delete' => "clashes#delete",:as=>:clash_delete
  match '/admin/faqs/destroy' => 'admin/faqs#destroy'
  match '/admin/reports/:id/destroy' => 'admin/reports#destroy',:as =>:admin_report_delete
  match '/admin/technicalissues/destroy' => 'admin/technicalissues#destroy'
  match '/clashy_technical' => 'clashes#clashy_technical',:as=>:clashy_technical
  match '/browse' => 'clashes#clashy_browse', :as=>:clashy_browse
  match '/clashy_report' => 'clashes#clashy_report', :as=>:clashy_report
  match '/howitworks' => 'homes#hiw',:as=>:homes_hiw
  match '/contactus' => 'homes#contactus',:as=>:homes_contactus
  match '/about' => 'homes#about',:as=>:homes_about
  match '/faqs' => 'homes#faq',:as=>:homes_faq
  match '/privacypolicy' => 'homes#privacypolicy',:as=>:homes_privacypolicy
  match '/terms&conditions' => 'homes#termsconditions',:as=>:homes_termsconditions
  match '/startaclash' => 'clashes#startaclash',:as=>:startaclash
  match 'reset/:reset_code' => 'users#reset', :as => :reset
  match '/admin/clashes/:id/destroy' => 'admin/clashes#destroy',:as =>:admin_clash_delete
  match '/admin/users/destroy' => 'admin/users#destroy'
  match '/:anything', :to => "homes#error_site"
  #~ match '/:anything/:anything', :to => "homes#error_site"
  #~ match '/:anything/:anything/:anything', :to => "homes#error_site"


  # The priority is based upon order of creation:
  # first created -> highest priority.

  # Sample of regular route:
  #   match 'products/:id' => 'catalog#view'
  # Keep in mind you can assign values other than :controller and :action

  # Sample of named route:
  #   match 'products/:id/purchase' => 'catalog#purchase', :as => :purchase
  # This route can be invoked with purchase_url(:id => product.id)

  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   resources :products

  # Sample resource route with options:
  #   resources :products do
  #     member do
  #       get 'short'
  #       post 'toggle'
  #     end
  #
  #     collection do
  #       get 'sold'
  #     end
  #   end

  # Sample resource route with sub-resources:
  #   resources :products do
  #     resources :comments, :sales
  #     resource :seller
  #   end

  # Sample resource route with more complex sub-resources
  #   resources :products do
  #     resources :comments
  #     resources :sales do
  #       get 'recent', :on => :collection
  #     end
  #   end

  # Sample resource route within a namespace:
    namespace :admin do
     # Directs /admin/products/* to Admin::ProductsController
  #     # (app/controllers/admin/products_controller.rb)
      resources :faqs
      resources :reports
      resources :clashes
      resources :users
      resources :technicalissues

    end
  # You can have the root of your site routed with "root"
  # just remember to delete public/index.html.
  # root :to => "welcome#index"
  root :to => "clashes#new"

  # See how all your routes lay out with "rake routes"

  # This is a legacy wild controller route that's not recommended for RESTful applications.
  # Note: This route will make all actions in every controller accessible via GET requests.
  # match ':controller(/:action(/:id(.:format)))'
end
