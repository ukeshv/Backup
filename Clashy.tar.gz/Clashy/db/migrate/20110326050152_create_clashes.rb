class CreateClashes < ActiveRecord::Migration
  def self.up
    create_table :clashes do |t|
      t.column :user_id, :integer
      t.column :title, :string
      t.column :item_one_id, :integer
      t.column :item_two_id, :integer
      t.column :permalink, :string
      t.column :duration, :integer
      t.column :view_count, :integer
      t.column :fb_share_count, :integer
      t.column :tw_share_count, :integer
      t.column :total_share_count, :integer
      t.column :end_date, :datetime
      t.column :ip_address, :string
      t.column :is_disable, :boolean
      t.timestamps
    end
  end

  def self.down
    drop_table :clashes
  end
end
