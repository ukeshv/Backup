class CreateItems < ActiveRecord::Migration
  def self.up
    create_table :items do |t|
      t.column :attachment_id, :integer
      t.column :name, :string
      t.column :quote, :text
      t.column :video_url, :string
      t.timestamps
    end
  end

  def self.down
    drop_table :items
  end
end
