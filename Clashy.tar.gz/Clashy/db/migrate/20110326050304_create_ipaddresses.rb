require 'rubygems'
require 'mysql'
class CreateIpaddresses < ActiveRecord::Migration
 def self.up
    create_table :ipaddresses do |t|
      t.column :number_one, :bigint
      t.column :number_two, :bigint
      t.column :country_code, :string
      t.column :country_name, :string
    end

  #~ path = "#{RAILS_ROOT}/tmp/ipaddress.csv"
    #~ tablename = "ipaddresses"
    #~ ActiveRecord::Base.connection.execute("load data local infile \'#{path}\' into table #{tablename} fields enclosed by \'\"\';")

  end

  def self.down
    drop_table :ipaddresses
  end
end
