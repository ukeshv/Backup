class CreateTechnicalsupports < ActiveRecord::Migration
  def self.up
    create_table :technicalsupports do |t|
      t.column :issue, :text
      t.column :contact_email, :string
      t.timestamps
    end
  end

  def self.down
    drop_table :technicalsupports
  end
end
