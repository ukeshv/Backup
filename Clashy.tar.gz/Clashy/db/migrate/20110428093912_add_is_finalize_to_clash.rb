class AddIsFinalizeToClash < ActiveRecord::Migration
  def self.up
    add_column :clashes, :is_finalize, :boolean
  end

  def self.down
    remove_column :clashes, :is_finalize
  end
end
