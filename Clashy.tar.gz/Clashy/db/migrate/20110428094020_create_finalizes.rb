class CreateFinalizes < ActiveRecord::Migration
  def self.up
    create_table :finalizes do |t|
      t.column :clash_id, :integer
      t.column :item_a_name, :string
      t.column :item_b_name, :string
      t.column :clash_name, :string
      t.column :duration, :integer
      t.timestamps
    end
  end

  def self.down
    drop_table :finalizes
  end
end
