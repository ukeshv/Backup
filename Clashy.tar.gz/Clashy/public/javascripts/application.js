// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults
$(document).ready(function(){ 
	
				$("#clas-items").live('click',function(){
				if ($(this).hasClass('clas-items up-arrow'))
				{
					var url_this = "/browse?sort=item_one_id desc" 
					$.ajax({
						url:url_this,
						success: function(data) {$('#list-pages').html(data); $("#clas-items").attr('class','clas-items down-arrow');}
				});
				return false;
      }
			else
			{
				var url_this = "/browse?sort=item_one_id asc" 
				$.ajax({
					url:url_this,
					success: function(data) {$('#list-pages').html(data); $("#clas-items").attr('class','clas-items up-arrow');}
				});
				return false;
			}
			});		
			
			$("#clas-title").live('click',function(){
				if ($(this).hasClass('clas-title up-arrow'))
				{
					var url_this = "/browse?sort=title desc" 
					$.ajax({
						url:url_this,
						success: function(data) {$('#list-pages').html(data); $("#clas-title").attr('class','clas-title down-arrow clas-title-ico');}
					});
					return false;
			}
			else
			{
					var url_this = "/browse?sort=title asc" 
					$.ajax({
						url:url_this,
						success: function(data) {$('#list-pages').html(data); $("#clas-title").attr('class','clas-title up-arrow clas-title-ico');}
					});
					return false;
			} 
		}); 
		
		$("#clas-num-view").live('click',function(){
				if ($(this).hasClass('clas-num-view up-arrow'))
				{
					var url_this = "/browse?sort=view_count asc" 
					$.ajax({
						url:url_this,
						success: function(data) {$('#list-pages').html(data); $("#clas-num-view").attr('class','clas-num-view down-arrow');}
					});
					return false;
			}
			else
			{
					var url_this = "/browse?sort=view_count desc" 
					$.ajax({
						url:url_this,
						success: function(data) {$('#list-pages').html(data); $("#clas-num-view").attr('class','clas-num-view up-arrow');}
					});
					return false;
			} 
		});  
			

		$("#clas-left-vote").live('click',function(){
				if ($(this).hasClass('clas-left-vote up-arrow'))
				{
					var url_this = "/browse?sort=end_date desc" 
					$.ajax({
						url:url_this,
						success: function(data) {$('#list-pages').html(data); $("#clas-left-vote").attr('class','clas-left-vote down-arrow clas-left-vote-ico');}
					});
					return false;
			}
			else
			{
					var url_this = "/browse?sort=end_date asc" 
					$.ajax({
						url:url_this,
						success: function(data) {$('#list-pages').html(data); $("#clas-left-vote").attr('class','clas-left-vote up-arrow clas-left-vote-ico');}
					});
					return false;
			} 
		}); 

			
			$(".paginate_users a").live('click',function(){
				var url_this = $(this).attr("href");
				$.ajax({
					url:url_this,
					success: function(data) {$('#tech_issue_view').html(data);}
				});
				return false;
			});	

			$("input.file_1").filestyle({ 
					image: "/images/img/choose-file.png",
					imageheight : 26,
					imagewidth : 70,
					width : 192
			});
			$(".various1_fancybox").fancybox({
			'titlePosition'		: 'inside',
			'transitionIn'		: 'none',
			'transitionOut'		: 'none',
			'scrolling' : 'no',
				'onClosed': function () { $("input.error,input.error-white").removeClass("error error-white")
							 $("#retrieve_password_form,#techical_form,#changepassword_form,#signin_form,#without_signup_form,#signup_form,#signup_form_two,#report_form").find('p').css({'display':'none'});
							 $("#tech_issue").removeAttr("style");
							 $("#tech_email").removeAttr("style");
							 $("#report_user_feedback").removeAttr("style");
							 $("#error_message_without_feedback").css({'display' : 'none'})	
							 $("#retrieve_password_form,#techical_form,#changepassword_form,#signin_form,#without_signup_form,#signup_form,#signup_form_two,#report_form").find("input:text, textarea,input:password").val("")
							 $("#retrieve_password_form,#techical_form,#changepassword_form,report_form").find("input.error").removeClass("error")
							 $("#retrieve_password_form,#techical_form,#changepassword_form,#signin_form,#without_signup_form,#signup_form,#signup_form_two,#report_form").find("input:text,textarea,input:password").focus()
							 $("#retrieve_password_form,#techical_form,#changepassword_form,#signin_form,#without_signup_form,#signup_form,#signup_form_two,#report_form").find("input:text,textarea,input:password").blur()
							 $("#report_text_one").css({'display':'block'});
							 $("#report_text_two").css({'display':'block'});
							 return false;
							 } 
		});
		$(".various1_fancybox_change").fancybox({
			'titlePosition'		: 'inside',
			'transitionIn'		: 'none',
			'transitionOut'		: 'none',
			'scrolling' : 'no',
						'onComplete': function() {
								$('#fancybox-content').css({'width':'785px'});
								$('#fancybox-wrap').css({'width':'800px'});
            },
						 'onClosed': function () { $("input.error,input.error-white").removeClass("error error-white")
								$("#signin_form, #signup_form,#signup_form_two,#without_signup_form").find('p').css({'display':'none'});
								$("#signin_form, #signup_form,#signup_form_two,#without_signup_form").find("input:text, input:password").val("")
								$("#signin_form, #signup_form,#signup_form_two,#without_signup_form").find("input:text, input:password").focus()
								$("#signin_form, #signup_form,#signup_form_two,#without_signup_form").find("input:text, input:password").blur()
								return false;
							 } 
		});
		
		$(".clashy-close").click(function(){
				$(".signin-input").removeClass("error");		
				$("#error_message_password p").html("");
				$("#password_user").removeClass("error");
				$("#error_message_password p").html("");
				$("#error_message_forgot_password p").css({'display' : 'none'})	
				$("#error_message_confirm_password_length p").html("")
				$("#error_message_confirm_password p").html("")
				$("#error_message_confirm_password_blank p").html(" ")
				$("#error_message_confirm_password p").html("")
				$("#error_message_confirm_password_length p").html("")
				$("#error_message_confirm_password_blank p").html(" ")
				$("#confirm_password_change").val("")
				$("#password_change").val("")
				$.fancybox.close()
				return false;
		});
		$(".tech_support_close").click(function(data)
		{
							$.fancybox.close()
		});
		
		$(".report_close").click(function(data)
		{
							$.fancybox.close()
		});
		
  	$('#signin_form').ajaxForm(function(data) {
       if (data.length)
			{
				$("#error_message_forgot_password p").css({'display' : 'none'})}
				 else
					{		
						
						if((data.password_blank && data.email_blank) || (((data.invalid_email) != undefined && data.invalid_email!=0) || data.login != 0))
						{
							$("div.forpass-link").css({'display' : 'none'});
							//$("#error_message_forgot_password p").css({'display' : 'none'});
							if(data.login ==undefined && data.invalid_email == 0 && data.dis_email==0)
							{
								$("#email_user_login").removeClass("error");
								$("#error_message_password1").show();
								$("#error_message_password1 p").show();
								$("#error_message_password2").hide();
							}
							else
							{
								
								if(data.invalid_email == 0 && data.password_blank)
								{
									$("#email_user_login").removeClass("error");
									$("#error_message_password1").show();
									$("#error_message_password1 p").show();
									$("#error_message_password2").hide();
								}
								else{
								$("#email_user_login").addClass("error");
								$("#error_message_password2 p").show();
								$("#error_message_password2").show();
								$("#error_message_password1").hide();
								}
							}
							if(data.password_blank =="Enter a Password" && data.password_blank != undefined)
								$("#password_user_login").addClass("error");
							else
								$("#password_user_login").removeClass("error");
						}
						else
						{
							$("#error_message_password1").show();
							$("#error_message_password1 p").show();
							$("#error_message_password2").hide();
							$("div.forpass-link").css({'display' : 'none'});
							//$("#error_message_forgot_password p").css({'display' : 'none'});
							$("#email_user_login").removeClass("error");
							$("#password_user_login").removeClass("error");
							$("#password_user_login").addClass("error");
						}
						return false;
					}
					
		}); 
		$('#without_signup_form').ajaxForm(function(data) {
			if (data.length)
			{
				$("#error_message_without_forgot_password p").css({'display' : 'none'})}
				 else
					{				
						if((data.password_blank && data.email_blank) || (((data.invalid_email) != undefined && data.invalid_email!=0) || data.login != 0))
						{							
							$("div.forpass-link").css({'display' : 'none'});
							//$("#error_message_without_forgot_password p").css({'display' : 'none'});
							if(data.login ==0 && data.invalid_email == undefined && data.dis_email==0)
							{
								$("#email_user").removeClass("error");
								$("#error_message_without_password1").show();
								$("#error_message_without_password2").hide();
							}
							else
							{
								if(data.invalid_email == 0 && data.password_blank)
								{
									$("#email_user").removeClass("error");
									$("#error_message_without_password1").show();
									$("#error_message_without_password1 p").show();
									$("#error_message_without_password2").hide();
								}
								else{
								$("#email_user").addClass("error");
								$("#error_message_without_password2 p").show();
								$("#error_message_without_password2").show();
								$("#error_message_without_password1").hide();
								}
							}
							if(data.password_blank =="Enter a Password" && data.password_blank != undefined)
								$("#password_user").addClass("error");
							else
								$("#password_user").removeClass("error");
						}
						else
						{
							$("#error_message_without_password1").show();
							$("#error_message_without_password2").hide();
							$("div.forpass-link").css({'display' : 'none'});
							//$("#error_message_without_forgot_password p").css({'display' : 'none'});
							$("#email_user").removeClass("error");
							$("#password_user").removeClass("error");
							$("#password_user").addClass("error");
						}
					}
            }); 
		 $('#signup_form').ajaxForm(function(data) { 
				if(data.email_blank)
				{
					$(".fancy_signup_email").addClass("error-white")
					//$(".fancy_signup_email").css({'border-color' : 'red'})
					$("#error-email-login p").html(data.email_blank)
					$("#error-email-login p").css({'display' : 'block'})
				}	
				if(data.email_blank=="")
				{
						$(".fancy_signup_email").removeClass("error-white")
						$(".fancy_signup_email").removeAttr("style")
					$("#error-email-login p").html("")
				}
				if(data.confirm_email_blank)
					{
					$(".fancy_signup_confirm_email").addClass("error-white")
						//$(".fancy_signup_confirm_email").css({'border-color' : 'red'})
					$("#error-confirm-email-login p").html(data.confirm_email_blank)
						$("#error-confirm-email-login p").css({'display' : 'block'})
				}
				if(data.confirm_email_blank=="")
					{
					$(".fancy_signup_confirm_email").removeClass("error-white")
					$(".fancy_signup_confirm_email").removeAttr("style")
					$("#error-confirm-email-login p").html("")
				}
					if(data.password_blank)
					{
					$(".fancy_signup_password").addClass("error-white")
					//$(".fancy_signup_password").css({'border-color' : 'red'})
					$("#error-password-login p").html(data.password_blank)
					$("#error-password-login p").css({'display' : 'block'})
				}
					if(data.password_blank=="")
					{
					$(".fancy_signup_password").removeClass("error-white")
					$(".fancy_signup_password").removeAttr("style")
					$("#error-password-login p").html("")
				}
					if(data.confirm_password_blank)
					{
					$(".fancy_signup_confirm_password").addClass("error-white")
						//$(".fancy_signup_confirm_password").css({'border-color' : 'red'})
					$("#error-confirm-password-login p").html(data.confirm_password_blank)
						$("#error-confirm-password-login p").css({'display' : 'block'})
				}
				if(data.confirm_password_blank=="")
					{
					$(".fancy_signup_confirm_password").removeClass("error-white")
					$(".fancy_signup_confirm_password").removeAttr("style")
					$("#error-confirm-password-login p").html("")
				}
						if(data.email_mismatch){
							if (data.confirm_email_blank){$(".fancy_signup_confirm_email").addClass("error-white")
								//$(".fancy_signup_confirm_email").css({'border-color' : 'red'})
					$("#error-confirm-email-login p").html(data.confirm_email_blank)
							}else{
					$(".fancy_signup_confirm_email").addClass("error-white")
					//$(".fancy_signup_confirm_email").css({'border-color' : 'red'})
					$("#error-confirm-email-login p").html(data.email_mismatch)
					$("#error-confirm-email-login p").css({'display' : 'block'})}}
				if(data.password_mismatch)
					{ if(data.confirm_password_blank){
					$(".fancy_signup_confirm_password").addClass("error-white")
						//$(".fancy_signup_confirm_password").css({'border-color' : 'red'})
					$("#error-confirm-password-login p").html(data.confirm_password_blank)
						$("#error-confirm-password-login p").css({'display' : 'block'})
						}else{
					$(".fancy_signup_confirm_password").addClass("error-white")
						//$(".fancy_signup_confirm_password").css({'border-color' : 'red'})
					$("#error-confirm-password-login p").html(data.password_mismatch)
						$("#error-confirm-password-login p").css({'display' : 'block'})}
				}
				if(data.email_wrong)
						{$(".fancy_signup_email").addClass("error-white")
							//$(".fancy_signup_email").css({'border-color' : 'red'})
							$("#error-email-login p").html(data.email_wrong)
							$("#error-email-login p").css({'display' : 'block'})}
				if(data.taken_email)
				{
					if (data.taken_email)
						{$(".fancy_signup_email").addClass("error-white")
							//$(".fancy_signup_email").css({'border-color' : 'red'})
				    	$("#error-email-login p").html(data.taken_email)
							$("#error-email-login p").css({'display' : 'block'})}
				}
				if (data.password_length){
				if (data.password_blank)
				{$(".fancy_signup_password").addClass("error-white")
					//$(".fancy_signup_password").css({'border-color' : 'red'})
					$("#error-password-login p").html(data.password_blank)
					$("#error-password-login p").css({'display' : 'block'})}
					else{
						$(".fancy_signup_password").addClass("error-white")
						//$(".fancy_signup_password").css({'border-color' : 'red'})
					$("#error-password-login p").html(data.password_length)
						$("#error-password-login p").css({'display' : 'block'})}
				}
            }); 
			$('#signup_form_two').ajaxForm(function(data) { 
				if(data.email_blank)
				{
					$(".fancy_signup_email").addClass("error-white")
				//	$(".fancy_signup_email").css({'border-color' : 'red'})
					$("#error-without-email-login p").html(data.email_blank)
					$("#error-without-email-login p").css({'display' : 'block'})
				}	
				if(data.email_blank=="")
				{
						$(".fancy_signup_email").removeClass("error-white")
						$(".fancy_signup_email").removeAttr("style")
					$("#error-without-email-login p").html("")
				}
				if(data.confirm_email_blank)
					{
					$(".fancy_signup_confirm_email").addClass("error-white")
					//	$(".fancy_signup_confirm_email").css({'border-color' : 'red'})
					$("#error-without-confirm-email-login p").html(data.confirm_email_blank)
						$("#error-without-confirm-email-login p").css({'display' : 'block'})
				}
				if(data.confirm_email_blank=="")
					{
					$(".fancy_signup_confirm_email").removeClass("error-white")
					$(".fancy_signup_confirm_email").removeAttr("style")
					$("#error-without-confirm-email-login p").html("")
				}
					if(data.password_blank)
					{
					$(".fancy_signup_password").addClass("error-white")
					//$(".fancy_signup_password").css({'border-color' : 'red'})
					$("#error-without-password-login p").html(data.password_blank)
					$("#error-without-password-login p").css({'display' : 'block'})
				}
					if(data.password_blank=="")
					{
					$(".fancy_signup_password").removeClass("error-white")
					$(".fancy_signup_password").removeAttr("style")
					$("#error-without-password-login p").html("")
				}
					if(data.confirm_password_blank)
					{
					$(".fancy_signup_confirm_password").addClass("error-white")
						//$(".fancy_signup_confirm_password").css({'border-color' : 'red'})
					$("#error-without-confirm-password-login p").html(data.confirm_password_blank)
						$("#error-without-confirm-password-login p").css({'display' : 'block'})
				}
				if(data.confirm_password_blank=="")
					{
					$(".fancy_signup_confirm_password").removeClass("error-white")
					$(".fancy_signup_confirm_password").removeAttr("style")
					$("#error-without-confirm-password-login p").html("")
				}
						if(data.email_mismatch){
							if (data.confirm_email_blank){$(".fancy_signup_confirm_email").addClass("error-white")
								//$(".fancy_signup_confirm_email").css({'border-color' : 'red'})
					$("#error-without-confirm-email-login p").html(data.confirm_email_blank)
								$("#error-without-confirm-email-login p").css({'display' : 'block'})
							}else{
					$(".fancy_signup_confirm_email").addClass("error-white")
				//	$(".fancy_signup_confirm_email").css({'border-color' : 'red'})
					$("#error-without-confirm-email-login p").html(data.email_mismatch)
					$("#error-without-confirm-email-login p").css({'display' : 'block'})
					}}
				if(data.password_mismatch)
					{ if(data.confirm_password_blank){
					$(".fancy_signup_confirm_password").addClass("error-white")
						//$(".fancy_signup_confirm_password").css({'border-color' : 'red'})
					$("#error-without-confirm-password-login p").html(data.confirm_password_blank)
						$("#error-without-confirm-password-login p").css({'display' : 'block'})
						}else{
					$(".fancy_signup_confirm_password").addClass("error-white")
						//$(".fancy_signup_confirm_password").css({'border-color' : 'red'})
					$("#error-without-confirm-password-login p").html(data.password_mismatch)
						$("#error-without-confirm-password-login p").css({'display' : 'block'})}
				}
				if(data.email_wrong)
						{$(".fancy_signup_email").addClass("error-white")
							//$(".fancy_signup_email").css({'border-color' : 'red'})
							$("#error-without-email-login p").html(data.email_wrong)
							$("#error-without-email-login p").css({'display' : 'block'})}
				if(data.taken_email)
				{
					if (data.taken_email)
						{$(".fancy_signup_email").addClass("error-white")
							//$(".fancy_signup_email").css({'border-color' : 'red'})
				    	$("#error-without-email-login p").html(data.taken_email)
							$("#error-without-email-login p").css({'display' : 'block'})
							}
				}
				if (data.password_length){
				if (data.password_blank)
				{$(".fancy_signup_password").addClass("error-white")
					//$(".fancy_signup_password").css({'border-color' : 'red'})
					$("#error-without-password-login p").html(data.password_blank)
					$("#error-without-password-login p").css({'display' : 'block'})}
					else{
						$(".fancy_signup_password").addClass("error-white")
						//$(".fancy_signup_password").css({'border-color' : 'red'})
					 $("#error-without-password-login p").html(data.password_length)
						$("#error-without-password-login p").css({'display' : 'block'})}
				}
           }); 
					
		$('#changepassword_form').ajaxForm(function(data) { 
					if (data.password_blank){
						$("#error_message_password p").html(data.password_blank)
						$("#error_message_password p").css({'display' : 'block'})
						$('#password_change').addClass("error")
						}
					else if (data.length_password){ 
						$("#error_message_password p").html(data.length_password)
						$("#error_message_password p").css({'display' : 'block'})						
						$('#password_change').addClass("error")
						}
					else{
						$("#error_message_password p").html("")
						$("#error_message_password p").css({'display' : 'none'})
						$('#password_change').removeClass("error")
						}
					
					if (data.old_blank){
						$("#error_message_old_password p").html(data.old_blank)
						$("#error_message_old_password p").css({'display' : 'block'})
						$('#old_password').addClass("error")
						}
					else if (data.wrong_password){
						$("#error_message_old_password p").html(data.wrong_password)
						$("#error_message_old_password p").css({'display' : 'block'})
						$('#old_password').addClass("error")
					}
						else {
						$("#error_message_old_password p").html("")
						$("#error_message_old_password p").css({'display' : 'none'})
						$('#old_password').removeClass("error")							
					}
				
				if (data.confirm_blank){
						$("#error_message_confirm_password p").html(data.confirm_blank)
						$("#error_message_confirm_password p").css({'display' : 'block'})
						$('#confirm_password_change').addClass("error")}
					else if (data.length_confirm){
						$("#error_message_confirm_password p").html(data.length_confirm)
						$("#error_message_confirm_password p").css({'display' : 'block'})
						$('#confirm_password_change').addClass("error")
					}
					else if (data.password){ 
						$("#error_message_confirm_password p").html(data.password)
						$("#error_message_confirm_password p").css({'display' : 'block'})
						$('#confirm_password_change').addClass("error")
					}
					else{
					$("#error_message_confirm_password p").html("")
					$("#error_message_confirm_password p").css({'display' : 'none'})
					$('#confirm_password_change').removeClass("error")							
						}
						
						if (data.length_confirm_max){
						$("#error_message_confirm_password p").html(data.length_confirm_max)
						$("#error_message_confirm_password p").css({'display' : 'block'})
						$('#confirm_password_change').addClass("error")}
					else if (data.length_confirm_max){
						$("#error_message_confirm_password p").html("")
						$("#error_message_confirm_password p").css({'display' : 'none'})
						$('#confirm_password_change').removeClass("error")
					}
					
					if (data.length_password_max){ 
						$("#error_message_password p").html(data.length_password_max)
						$("#error_message_password p").css({'display' : 'block'})						
						$('#password_change').addClass("error")
						}
        });
					
						$('#techical_form').ajaxForm(function() { 
            }); 
						
							$("#email_user").click(function(){
							$("#email_user").val("")
						});
						$("#password_user").click(function(){
							$("#password_user").val("")
						});
						$(".signup_without_email").click(function(){
							$(".signup_without_email").val("");
						});
						$(".signup_without_confirm_email").click(function(){
							$(".signup_without_confirm_email").val("");
						});
						$(".signup_without_password").click(function(){
							$(".signup_without_password").val("");
						});
						$(".signup_without_confirm_password").click(function(){
							$(".signup_without_confirm_password").val("");
						});
						$("#current_clashes").click(function(){
						if($('#current_clashes').hasClass('active'))
							{
								$("#list-cont-wrapper").slideUp()
               $('#current_clashes').removeClass('active')
	               return false;
                 }
						else{
								$("#list-cont-wrapper").slideDown()
								$('#current_clashes').addClass('active')}
               return false;								
						});
						
							$("#completed_clashes").click(function(){
						if($('#completed_clashes').hasClass('active'))
							{
								$("#completed-clash").slideUp()	
                $('#completed_clashes').removeClass('active')
               return false;
                 }
						else{
								$("#completed-clash").slideDown()			
								$('#completed_clashes').addClass('active')}
								return false;
						});
						
			$("#btn_start_clash_submit").click(function(){
			if($.trim($("#item_a_name").val())!="" && $.trim($("#item_b_name").val())!="" && $.trim($("#item_clash_name").val())!="" && selected_one_item_a()==1 && selected_one_item_b()==1 && selected_duration()==1){
					if ($("#start_a_clash_popup").length>0){$("#start_a_clash_popup").trigger('click'); return false;}
					else{return true;}
			}
			else if($(this).attr("location")=="update" && $.trim($("#item_a_name").val())!="" && $.trim($("#item_b_name").val())!="" && $.trim($("#item_clash_name").val())!="" && selected_duration()==1)
			{
					if ($("#start_a_clash_popup").length>0){$("#start_a_clash_popup").trigger('click'); return false;}
					else{return true;}
			}
			else{
				selected_one_item_a();
				selected_one_item_b();

				if($.trim($("#item_a_name").val())==""){
					$("#item_a_name").siblings().show();
					$("#item_a_name").addClass("errors");
				}
				else{
					$("#item_a_name").siblings().hide();
					$("#item_a_name").removeClass("errors");
				}
				if($.trim($("#item_b_name").val())==""){
					$("#item_b_name").siblings().show();
					$("#item_b_name").addClass("errors");
				}      
				else{
					$("#item_b_name").siblings().hide();
					$("#item_b_name").removeClass("errors");
				}      
				if($.trim($("#item_clash_name").val())==""){
					$("#item_clash_name").siblings().show();
					$("#item_clash_name").attr("style","border: 2px solid #FF6C00;color: #FF6C00;");
				}
				else{
					$("#item_clash_name").siblings().hide();
					$("#item_clash_name").attr("style","border: none;color: black;");
				}      
				if(selected_duration()==0){
					$("#select_duration_clash").show();
				}
				else{
					$("#select_duration_clash").hide();
				}
				setTimeout(function () {
					$(".error-message").fadeOut(1000);
					$.each($(".error-message"), function(index, value) { 
						if($(value).siblings('.file.file_1').hasClass('error')){$(value).siblings('.file.file_1').removeClass('error')}
						else if($(value).siblings().hasClass('errors')){$(value).siblings().removeClass('errors	')}
						else{$(value).siblings("#item_clash_name").attr("style","border:none;color:black;");}
					});
					$("#select_duration_clash").fadeOut(1000);
					$("#select_only_one_a").fadeOut(1000);
					$("#select_only_one_b").fadeOut(1000);
				},3000)
				return false;
			}
  });
	
  function selected_one_item_a(){
    if($.trim($("#item_a_file").val())=="" && $.trim($("#item_a_url").val())=="" && $.trim($("#item_a_text").val())!=""){      
			$(".select_a_anyone").hide();
			$(".items-a.left-row .item-a-form .file.file_1").removeClass("error");
			$("#item_a_url").removeClass("errors");
			$("#item_a_text").removeClass("errors");
			$("#select_only_one_a").hide();
			$("#item_a_fut").val("text");
      return 1;
    }
    else if($.trim($("#item_a_file").val())=="" && $.trim($("#item_a_url").val())!="" && $.trim($("#item_a_text").val())==""){
			$(".select_a_anyone").hide();
			$(".items-a.left-row .item-a-form .file.file_1").removeClass("error");
			$("#item_a_url").removeClass("errors");
			$("#item_a_text").removeClass("errors");
			$("#select_only_one_a").hide();
			if(/^http:\/\/(www\.youtube|youtube)\.com\/watch\?v=[^&]*(&.*){0,}$/.test($.trim($("#item_a_url").val())) || /^http:\/\/(www\.flickr|flickr)\.com\/photos\/[0-9a-zA-Z@\-\_]*\/[0-9]*\/$/.test($.trim($("#item_a_url").val())))
			{				
				$("#item_a_fut").val("url");
				return 1;
			}
			else
			{
				$("#item_a_url").siblings().show();
				$("#item_a_url").siblings().children('.empty').hide();
				$("#item_a_url").siblings().children('.invalid').show();
				$("#item_a_url").addClass("errors");
				return 0;
			}
    }
    else if($.trim($("#item_a_file").val())!="" && $.trim($("#item_a_url").val())=="" && $.trim($("#item_a_text").val())==""){
			$(".select_a_anyone").hide();
			$("#item_a_url").removeClass("errors");
			$("#item_a_text").removeClass("errors");
			$("#select_only_one_a").hide();
			if ($.trim($("#item_a_file").val()).split(".").pop().toLowerCase().search(/(jpg|png|jpeg)/)>=0)
			{
				$(".items-a.left-row .item-a-form .file.file_1").removeClass("error");
				$("#item_a_fut").val("image");
				return 1;
			}
			else{
				$("#item_a_file").parent().siblings(".error-message.ie6png.select_a_anyone").show();
				$("#item_a_file").parent().siblings(".error-message.ie6png.select_a_anyone").children(".empty").hide();
				$("#item_a_file").parent().siblings(".error-message.ie6png.select_a_anyone").children(".invalid").show();
				$(".items-a.left-row .item-a-form .file.file_1").addClass("error");
				return 0;
			}
    }
    else if($.trim($("#item_a_file").val())=="" && $.trim($(".items-a.left-row .item-a-form .file.file_1").val())=="" && $.trim($("#item_a_url").val())=="" && $.trim($("#item_a_text").val())==""){
			$(".select_a_anyone").show();
			$(".select_a_anyone .invalid").hide();
			$(".select_a_anyone .empty").show();
			$("#item_a_text").addClass("errors");
			$(".items-a.left-row .item-a-form .file.file_1").addClass("error");
			$("#item_a_url").addClass("errors");
			$("#select_only_one_a").hide();
      $("#item_a_fut").val("nothing");
      return 0;
    }
		else{
			$(".select_a_anyone").hide();
			$(".items-a.left-row .item-a-form .file.file_1").addClass("error");
			$("#item_a_url").addClass("errors");
			$("#item_a_text").addClass("errors");
			$("#select_only_one_a").show();
			$("#item_a_fut").val("nothing");
			return 0;
		}
  }
	
  function selected_one_item_b(){
    if($.trim($("#item_b_file").val())=="" && $.trim($("#item_b_url").val())=="" && $.trim($("#item_b_text").val())!=""){
			$(".select_b_anyone").hide();
			$(".items-a.middle-row .item-a-form .file.file_1").removeClass("error");
			$("#item_b_url").removeClass("errors");
			$("#item_b_text").removeClass("errors");
			$("#select_only_one_b").hide();
			$("#item_a_fut").val("text");
      return 1;
    }
    else if($.trim($("#item_b_file").val())=="" && $.trim($("#item_b_url").val())!="" && $.trim($("#item_b_text").val())==""){
			$(".select_b_anyone").hide();
			$(".items-a.middle-row .item-a-form .file.file_1").removeClass("error");
			$("#item_b_url").removeClass("errors");
			$("#item_b_text").removeClass("errors");
			$("#select_only_one_b").hide();
			if(/^http:\/\/(www\.youtube|youtube)\.com\/watch\?v=[^&]*(&.*){0,}$/.test($.trim($("#item_b_url").val())) || /^http:\/\/(www\.flickr|flickr)\.com\/photos\/[0-9a-zA-Z@\-\_]*\/[0-9]*\/$/.test($.trim($("#item_b_url").val())))
			{
				$("#item_b_fut").val("url");
				return 1;
			}
			else
			{
				$("#item_b_url").siblings().show();
				$("#item_b_url").siblings().children('.empty').hide();
				$("#item_b_url").siblings().children('.invalid').show();
				$("#item_b_url").addClass("errors");
				return 0;
			}
    }
    else if($.trim($("#item_b_file").val())!="" && $.trim($("#item_b_url").val())=="" && $.trim($("#item_b_text").val())==""){
			$(".select_b_anyone").hide();
			$("#item_b_url").removeClass("errors");
			$("#item_b_text").removeClass("errors");
			$("#select_only_one_b").hide();
			if ($.trim($("#item_b_file").val()).split(".").pop().toLowerCase().search(/(jpg|png|jpeg)/)>=0)
			{
				$(".items-a.middle-row .item-a-form .file.file_1").removeClass("error");
				$("#item_b_fut").val("image");
				return 1;
			}
			else{
				$("#item_b_file").parent().siblings(".error-message.ie6png.select_b_anyone").show();
				$("#item_b_file").parent().siblings(".error-message.ie6png.select_b_anyone").children('.empty').hide();
				$("#item_b_file").parent().siblings(".error-message.ie6png.select_b_anyone").children('.invalid').show();
				$(".items-a.middle-row .item-a-form .file.file_1").addClass("error");
				return 0;
			}
    }
    else if($.trim($("#item_b_file").val())=="" && $.trim($(".items-a.middle-row .item-a-form .file.file_1").val())=="" && $.trim($("#item_b_url").val())=="" && $.trim($("#item_b_text").val())==""){
			$(".select_b_anyone").show();
			$(".select_b_anyone .invalid").hide();
			$(".select_b_anyone .empty").show();
			$("#item_b_text").addClass("errors");
			$(".items-a.middle-row .item-a-form .file.file_1").addClass("error");
			$("#item_b_url").addClass("errors");
			$("#select_only_one_b").hide();
      $("#item_b_fut").val("nothing");
      return 0;
    }
		else{
			$(".select_b_anyone").hide();
			$(".items-a.middle-row .item-a-form .file.file_1").addClass("error");
			$("#item_b_url").addClass("errors");
			$("#item_b_text").addClass("errors");
			$("#select_only_one_b").show();
			$("#item_b_fut").val("nothing");
			return 0;
		}
  }

  function selected_duration(){
    if($(".right-row input[type='radio']").is(":checked")){
      return 1;
    }
    else{
      return 0;
    }
  } 
	$(".f-arrow").click(function(){
			if($(this).hasClass("active"))
		{
		$(this).removeClass("active");
		$(this).next().css({'display' : 'none'})
		$(this).parent().parent().removeClass("secondli");		
		a1=($(this).attr('id'))
		$('#remove_answer_'+a1).css({'display' : 'none'})
	}
	else
	{
		$(this).parent().parent().addClass("secondli");
		$(this).addClass("active");
		$("#remove-answer").css({'display':'block'})
		a1=($(this).attr('id'))
		$('#remove_answer_'+a1).css({'display' : 'block'})
	}
	});
	//~ $("#view-results-clash").click(function(){
		//~ if ($("#view-results-clash").hasClass("remove")){
		//~ $("#show-no-clash").slideDown()
			//~ $('#show-no-clash').fadeOut(2500);
			//~ }
			//~ return false;
		//~ });
	$("a.remove").click(function(){
		$("#show-no-clash_"+$(this).attr("clash_id")).html($(this).attr("find_id")=="views" ? "Cannot view the completed clash item." :"No results for this clash.").slideDown();
		$("#show-no-clash_"+$(this).attr("clash_id")).fadeOut(2500);
		return false;
	});		
			$(".remove_result").click(function(){
		id=($(this).attr('id'))
			//alert($(this).parent().parent().parent().get(0).tagName)
		$(".no_result_"+id).slideDown()
			$(".no_result_"+id).fadeOut(2500);
			return false;
		});
				$("#finalize-clash-share").click(function(){
			//~ $("#show-edit-finalize-clash").hide();
			//~ $(".clash_preview").addClass("share_clash");
			//~ $("#share_the_clash_show").slideDown(1500);
				window.location.href="?share=true";
				return false;
		});
		$(".hidethis").click(function(){
			$("#share_the_clash_show").slideUp(1000);
			$("#share_the_clash_show").hide();
			imagePreview();
			//$("#show-edit-finalize-clash").slideDown(2000);
			});
			
			$("input.errors, input.error, textarea.errors, textarea.point-3-textarea").live("focus", function(){ 
				 if($("form:visible").length==1 && $("form:visible").attr("id")=="start_a_clash"){
				$(this).siblings("div.error-message").fadeOut(1000); 
				if($(this).hasClass("error")) {$(this).removeClass("error");}
				else if($(this).hasClass("errors")) {$(this).removeClass("errors");}
				else{$(this).attr("style","border:none;color:black;");}}
			});
			$("textarea.point-3-textarea#item_clash_name").live("focus", function(){ 
				$(this).attr("style","color:#666666; font-family:HeliosCondBold,HeliosCond,HeliosCondBlack,Arial,Helvetica,sans-serif; font-size:15px;");
			});
			
			$("div.error-message").live('click',function(){
				$(this).fadeOut(1000);
				if($(this).siblings('.file.file_1').hasClass('error')){$(this).siblings('.file.file_1').removeClass('error')}
				else if($(this).siblings().hasClass('errors')){$(this).siblings().removeClass('errors	')}
				else{$(this).siblings("#item_clash_name").attr("style","border:none;color:black;");}
			})
			var day_count=0
$("#previous_day").live('click',function(){
	day_count=day_count-1
	$.ajax({
			url:"/admin/clashes/clash_day",
			data: {
			day: day_count,
			status:"previous"
		},
				success: function(data) {$('#clash_day').html(data);}
			});
});	
var day_next=0
$("#next_day").live('click',function(){
	day_count=day_count+1
	$.ajax({
			url:"/admin/clashes/clash_day",
			data: {
			day: day_count,
			status:"next"
		},
				success: function(data) {$('#clash_day').html(data);}
			});
});	

});	

$(document).ready(function() {
//ajax for day, month, week
	$(".paginate_users_DWM a").live('click',function(){
	var url_this = $(this).attr("href");
	$.ajax({
			url:url_this,
				success: function(data) {$('#clash_day').html(data);}
			});
			return false;
});
//end 
//ajax faq
$(".paginate_users_FAQ a").live('click',function(){
	var url_this = $(this).attr("href");
	$.ajax({
		url:url_this,
		success: function(data) {$('#main').html(data);}
	});
	return false;
});
//end	
//ajax faq
$(".paginate_users_RL a").live('click',function(){
	var url_this = "/admin/reports?page="+$(this).attr('href').split("page=")[1].split("&")[0];
	$.ajax({
		url:url_this,
		success: function(data) {$('#main').html(data);}
	});
	return false;
});
$(".paginate_users_total_users a").live('click',function(){
	var url_this = "/admin/users?page="+$(this).attr('href').split("page=")[1].split("&")[0];
	$.ajax({
		url:url_this,
		success: function(data) {$('#total_users').html(data);}
	});
	return false;
});
$(".paginate_summary_clash a").live('click',function(){
	var url_this = "/admin/clashes/clash_summary?page="+$(this).attr('href').split("page=")[1].split("&")[0];
	$.ajax({
		url:url_this,
		success: function(data) {$('#main').html(data);}
	});
	return false;
});
//end		
    $('#clas-title').click(function() {
		if ($('#clas-title').hasClass('down-arrow'))
		{
           $(this).addClass('up-arrow')
				   $(this).removeClass('down-arrow')
				 }
				 else
				 {
					 $(this).addClass('down-arrow')
				   $(this).removeClass('up-arrow')
				 }
  });	 
	
});

$(document).ready(function() {
    $('#clas-items').click(function() {
		if ($('#clas-items').hasClass('down-arrow'))
		{  $("form#start_a_clash")
           $(this).addClass('up-arrow')
				   $(this).removeClass('down-arrow')
				 }
				 else
				 {
					 $(this).addClass('down-arrow')
				   $(this).removeClass('up-arrow')
				 }
  });	
});

$(document).ready(function() {
    $('#clas-num-view').click(function() {
		if ($('#clas-num-view').hasClass('up-arrow'))
		{
           $(this).addClass('down-arrow')
				   $(this).removeClass('up-arrow')
				 }
				 else
				 {
					 $(this).addClass('up-arrow')
				   $(this).removeClass('down-arrow')
				 }
  });	
});

$(document).ready(function() {
    $('#clas-left-vote').click(function() {
		if ($('#clas-left-vote').hasClass('down-arrow'))
		{
           $(this).addClass('up-arrow')
				   $(this).removeClass('down-arrow')
				 }
				 else
				 {
					 $(this).addClass('down-arrow')
				   $(this).removeClass('up-arrow')
				 }
  });
});


$('#report_form').ajaxForm(function(data) { 
$("#report_user_feedback").css({"border":""});
$("#report_user_email").removeClass("error");
$("#error_message_without_feedback").html("");
$("#report_error_message_wrong_email p").html("");
if(data.feedback_blank)	
{ 
	if(data.feedback_blank.length!=0)
	{
	$("#error_message_without_feedback").html(data.feedback_blank);
		$("#error_message_without_feedback").css({'display' : 'block'})	
	$("#report_user_feedback").css({"border":"3px solid #ff6600"});
	}
}
if(data.feedback_blank)
{
	if(data.feedback_blank=="")
	{	
	   $("#error_message_without_feedback ").html("");        
	   $("#report_user_feedback").css({"border":"3px solid #ff6600"});
	}
}
if(data.feedback_error)
{
	if(data.feedback_error.length!=0)
	{
	       $("#report_user_feedback").css({"border":"3px solid #ff6600"});
	       $("#error_message_without_feedback ").html(data.feedback_error);
				 $("#error_message_without_feedback ").css({'display' : 'block'})
	}
}
if(data.feedback_error)
{
	if(data.feedback_error == "")
	{
		$("#error_message_without_feedback ").html("");
		$("#report_user_feedback").css({"border":"3px solid #ff6600"});
	}	
}
if(data.email_error)
{
	if(data.email_error.length!=0)
	{ 
		$("#report_error_message_wrong_email p").html(data.email_error);
		$("#report_error_message_wrong_email p").css({'display' : 'block'})
		$("#report_user_email").addClass("error");
	}	
}
if(data.email_error)
{
	if(data.email_error=="")
	{							
		$("#report_error_message_wrong_email p").html("");
		$("#report_user_email").addClass("error");
	}
}
if(data.email_invalid){
       $("#report_error_message_wrong_email p").html(data.email_invalid);
	     $("#report_error_message_wrong_email p").css({'display' : 'block'})
			 $("#report_user_email").addClass("error");
}
});



$('#techical_form').ajaxForm(function(data) { 
$("#tech_issue").css({"border":""});
$("#tech_email").removeClass("error");
$("#tech_email").removeAttr("style");
$("#error_message_without_techissue p").html("");
$("#tech_error_message_wrong_email p").html("");
if(data.issue_blank)
{ 
	if(data.issue_blank.length!=0) 
{
	$("#tech_issue").addClass("error");
	$("#error_message_without_techissue p").html(data.issue_blank);
		$("#error_message_without_techissue p").css({'display' : 'block'})
	$("#error_message_without_techissue p").html(data.issue_error);
			$("#error_message_without_techissue p").css({'display' : 'block'})
	$("#tech_issue").css({"border":"3px solid #FE0101"}); 
}
}
if(data.issue_blank=="") 
{ 
	$("#tech_issue").removeClass("error");
	$("#tech_issue").removeAttr("style");
	$("#error_message_without_techissue p").html("");
}	

if(data.email_blank)
{ 
	$("#tech_email").addClass("error");
	$("#tech_error_message_wrong_email p").html(data.email_blank);
		$("#tech_error_message_wrong_email p").css({'display' : 'block'})
}		
if(data.email_blank=="")
{ 
	$("#tech_email").removeClass("error");
	$("#tech_email").removeAttr("style");
	$("#tech_error_message_wrong_email p").html("");
}		

if(data.email_blank)
{
	if(data.email_blank.length!=0)
	{  
		$("#tech_error_message_wrong_email p").html(data.email_blank);
			$("#tech_error_message_wrong_email p").css({'display' : 'block'})
		$("#tech_email").css({"border":"3px solid #FE0101"});
	}
}

if(data.issue_error)
{
	if(data.issue_error=="")
	{ 
	       $("#error_message_without_techissue p").html("");
	       $("#tech_issue").css({"border":"3px solid #FE0101"});
	}
}

if(data.issue_error)
{
	if(data.issue_error.length!=0)
	{ 
	       $("#error_message_without_techissue p").html(data.issue_error);
			$("#error_message_without_techissue p").css({'display' : 'block'})
	       $("#tech_issue").css({"border":"3px solid #FE0101"});
	}
}

if(data.email_invalidd){
       $("#tech_error_message_wrong_email p").html(data.email_invalidd);
		$("#tech_error_message_wrong_email p").css({'display' : 'block'})
		 $("#tech_email").css({"border":"3px solid #FE0101"});
}
});
								
function goToClashPage()
{
	$(".clashy-close").trigger('click');
	$('#start_a_clash').submit();
}

 function connectFacebookNew(id,name,description,message,clashy_url) {
      // No score, share link
		FB.ui({
			method: 'stream.publish',
			message: message,
			attachment: {name: name, caption: '', description: description, href: clashy_url}                               
			},
			function(response) {
				if (response && response.post_id) {
					$.ajax({
						type: "GET",
						url: "/clashes/update_share_count",
						data: {
						clash_id: id,
						share_type: 'facebook'
						},
						success: function(html, status) {
							    if($("#total_share_changed").attr("id")=="total_share_changed"){
								$("#total_share_changed").html(html);
							}
						}
					});
				}
			}
		);
 }
 
 function twitterPop(id,str,text){
    mywindow = window.open('http://twitter.com/share?url='+str+'&text='+text,"Tweet_widow","channelmode=no,directories=no,location=no,menubar=no,scrollbars=no,toolbar=no,status=no,width=500,height=375,left=300,top=200");
  mywindow.focus();
	$.ajax({
		type: "GET",
		url: "/clashes/update_share_count",
		data: {
			clash_id: id,
			share_type: 'twitter'
		},
		success: function(html, status) {
		                       if($("#total_share_changed").attr("id")=="total_share_changed"){
					$("#total_share_changed").html(html);
				}               
		}
	});
 }
 
  $('#retrieve_password_form').ajaxForm(function(data) { 
    if(data.email_error.length!=0)
    {
      $("#retrievepass_error_message_wrong_email h3 p").html(data.email_error)
			$("#retrievepass_error_message_wrong_email h3 p").css({'display' : 'block'})
			$("#retrieve_password_email").addClass("error");
    }
  }); 
$(document).ready(function() {
	// call the tablesorter plugin
	$("#summary_table").tablesorter({
		// sort on the first column and third column, order asc
		sortList: [[0,0],[0,0]]
	});
	//$("#remove-header").removeClass("headerSortDown")
$("input:text, input:password,textarea").bind(
    {
        focus: function()
        {
            $(this).siblings('label.example').hide();
        },
        blur: function()
        {
            if ($(this).val()==""){
                $(this).siblings('label.example').show();
            }
        }
    });
		
		 
	});
	
		function reset_password()
			{  
				if (($("#password_change_reset").val()=="") || ($("#confirm_password_change_reset").val()=="") || ($("#password_change_reset").val().length<6)  || ($("#password_change_reset").val()!=$("#confirm_password_change_reset").val())){
			if ($("#password_change_reset").val()=="")
				{
					$('#password_change_reset').siblings().children().html("Enter Password")
					$('#password_change_reset').addClass("error")
					} 
				if ($("#confirm_password_change_reset").val()=="")
				{$('#confirm_password_change_reset').siblings().children().html("Enter Confirm Password")
					$('#confirm_password_change_reset').addClass("error")
					}
					if ($("#password_change_reset").val().length<6 && $("#password_change_reset").val()!="")
				{$('#password_change_reset').siblings().children().html("6 Characters min")
					$('#password_change_reset').addClass("error")
					}
					if ($("#password_change_reset").val().length>=6 )
				{
					$('#password_change_reset').siblings().children().html(" ")
					$('#password_change_reset').removeClass("error")
					}
					if ($("#password_change_reset").val().length>20 && $("#password_change_reset").val()!="")
				{$('#password_change_reset').siblings().children().html("20 Characters max")
					$('#password_change_reset').addClass("error")
					}
						if ($("#password_change_reset").val!=$("#confirm_password_change_reset").val() && $("#confirm_password_change_reset").val()!="")
				{$('#confirm_password_change_reset').siblings().children().html("Password Mismatch")
					$('#confirm_password_change_reset').addClass("error")
					}
				}
				else
				{					
				$.ajax({
			url:"/users/reset_password",
			data: {
			password: $("#password_change_reset").val(),
				reset:$('.reset_id').attr('id')
		}
			});}
				}
				
				
				
function DeleteClashy(url)
{
	if(confirm("Would you like to delete this Clash?"))
	{
		window.location = url;
	}
	else
	{
		return false;
	}
}

function DeleteReport(url)
{
	if(confirm("Would you like to delete this Report?"))
	{
		window.location = url;
	}
	else
	{
		return false;
	}
}

function goToSuccessPage()
{
		//$.fancybox.close();
	//$("a#forgotpassword_homepage").fancybox({ 'hideOnContentClick': false, 'frameWidth': 300, 'frameHeight': 300 }).trigger('click');
	$("a#forgotpassword_success").fancybox({ 'hideOnContentClick': false, 'frameWidth': 300, 'frameHeight': 300}).trigger('click');
}

function open2(){
    //$("a#fancyboxButton").fancybox().trigger('click');
}


function delete_FBuserLogin(appid)
{
		 FB.init({ appId:appid, cookie:true, status:true, xfbml:true});
		 	FB.logout(function(response) {});
}