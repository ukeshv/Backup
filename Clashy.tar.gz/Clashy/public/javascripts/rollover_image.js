/*
 * Image preview script 
 * powered by jQuery (http://www.jquery.com)
 * 
 * written by Alen Grakalic (http://cssglobe.com)
 * 
 * for more info visit http://cssglobe.com/post/1695/easiest-tooltip-and-image-preview-using-jquery
 *
 */
 
this.imagePreview = function(){	
	/* CONFIG */
	if ($("#share_the_clash_show").is(':visible'))
	{
	a=screen.width
	b=screen.height
		if((a>=1280 && a<1400)&& b>=760)
	{
		xOffset = 715;
		yOffset = 320;
		width= 700;
		height=495;
	}
	else if((a>=1024 && a<1280)&& b>=760) 
	{
		var chrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
		var  IE = navigator.userAgent.toLowerCase().indexOf('windows') > -1
		 if (chrome || IE)
		{
			xOffset = 715;
		  yOffset = 145;
		  width= 700;
		  height=495;
		}
		else{
		xOffset = 720;
		yOffset = 145;
		width= 700;
		height=495;
			}
	}
	else
	{
		xOffset = 715;
		yOffset = 275;
		width= 700;
		height=495;
	}
}
else
{
		a=screen.width
	b=screen.height
		if((a>=1280 && a<1400)&& b>=760)
	{
		xOffset = 580;
		yOffset = 320;
		width= 700;
		height=495;
	}
	else if((a>=1024 && a<1280)&& b>=760) 
	{
		var chrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
		var  IE = navigator.userAgent.toLowerCase().indexOf('windows') > -1
		 if (chrome || IE)
		{
			xOffset = 580;
		  yOffset = 145;
		  width= 700;
		  height=495;
		}
		else{
		xOffset = 715;
		yOffset = 145;
		width= 700;
		height=495;
			}
	}
	else
	{
		xOffset = 715;
		yOffset = 275;
		width= 700;
		height=495;
	}
	
}
		// these 2 variable determine popup's distance from the cursor
		// you might want to adjust to get the right result
		
	/* END CONFIG */
	$("a.preview").hover(function(e){
		this.t = this.title;
		this.title = "";	
		var c = (this.t != "") ? "<br/>" + this.t : "";
		$("#preview").remove();
		$("body").append("<p id='preview'><img src='"+ this.href +"' alt='Image preview'  style='width:"+width+"px;height:"+height+"px;'/>"+ c +"</p>");					
		$("#preview").mouseout(function(){$(this).remove();})		
		$("#preview")
			.css("top",(xOffset) + "px")
			.css("left",(yOffset) + "px")
			.fadeIn("fast");						
    },
	function(e){
		this.title = this.t;	
		if (e.pageX>330 && e.pageX<1030 && e.pageY>600 && e.pageY<1100){}
		else{$("#preview").remove();}
    });	
	//~ $("a.preview").mousemove(function(e){
		//~ $("#preview")
			//~ .css("top",(e.pageY - xOffset) + "px")
			//~ .css("left",(e.pageX + yOffset) + "px");
	//~ });			
};


// starting the script on page load
$(document).ready(function(){
	imagePreview();
});