require 'test_helper'

class HomesControllerTest < ActionController::TestCase
  test "should get hiw" do
    get :hiw
    assert_response :success
  end

  test "should get about" do
    get :about
    assert_response :success
  end

  test "should get faq" do
    get :faq
    assert_response :success
  end

  test "should get blog" do
    get :blog
    assert_response :success
  end

  test "should get browse" do
    get :browse
    assert_response :success
  end

  test "should get privacypolicy" do
    get :privacypolicy
    assert_response :success
  end

  test "should get blog" do
    get :blog
    assert_response :success
  end

  test "should get termsconditions" do
    get :termsconditions
    assert_response :success
  end

  test "should get contactus" do
    get :contactus
    assert_response :success
  end

  test "should get jobsatclashy" do
    get :jobsatclashy
    assert_response :success
  end

end
