require 'test_helper'

class Admin::ClashesHelperTest < ActionView::TestCase
end
