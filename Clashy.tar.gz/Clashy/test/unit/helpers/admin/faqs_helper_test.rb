require 'test_helper'

class Admin::FaqsHelperTest < ActionView::TestCase
end
