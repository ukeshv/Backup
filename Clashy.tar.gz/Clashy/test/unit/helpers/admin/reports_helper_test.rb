require 'test_helper'

class Admin::ReportsHelperTest < ActionView::TestCase
end
