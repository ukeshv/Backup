require 'test_helper'

class Admin::TechnicalissuesHelperTest < ActionView::TestCase
end
