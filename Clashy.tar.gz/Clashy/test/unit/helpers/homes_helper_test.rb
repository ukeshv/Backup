require 'test_helper'

class HomesHelperTest < ActionView::TestCase
end
