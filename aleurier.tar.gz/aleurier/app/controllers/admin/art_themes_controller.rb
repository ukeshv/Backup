class Admin::ArtThemesController < ApplicationController
	layout "admin"
	 before_filter :admin_login_required
   @@entries_per_page = 20 
 def index
    @artist = Artist.find(params[:artist_id])
    conditions = "(title like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
  
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"

    options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
    
    if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @art_themes = @artist.art_themes.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @art_themes = @artist.art_themes.paginate(options)
      @search_art_theme=1
      @search_value=params[:search]
    else
      @art_themes = @artist.art_themes.paginate(options)
    end
  end
  
  def show
    @artist = Artist.find(params[:artist_id])
    @art_theme = ArtTheme.find(params[:id])
  end
  
  def new
    @artist = Artist.find(params[:artist_id])
    @art_theme = ArtTheme.new
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @song }
    end
  end

  def edit
		@artist = Artist.find(params[:artist_id])
    @art_theme = ArtTheme.find(params[:id])
  end

  def create
    @art_theme = ArtTheme.new(params[:art_theme])   
		@artist = Artist.find(params[:artist_id])
    @art_theme.artist_id = @artist.id
    respond_to do |format|
      if @art_theme.save
       if !params[:article].nil? && !params[:article][:uploaded_data].blank?
			@attachment = Attachment.new(params[:article])
			@art_theme.attachments << @attachment		 
		end	 
        flash[:success] = 'Art Theme was successfully created.'
        format.html { redirect_to(admin_artist_art_themes_path(@artist.id)) }
        format.xml  { render :xml => @artist, :status => :created, :location => @artist }
      else
        format.html { render :action => "new", :artist_id=>@artist.id }
        format.xml  { render :xml => @artist.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  def update
    @art_theme = ArtTheme.find(params[:id])
    @artist = Artist.find(params[:artist_id])
    @art_theme.artist_id = @artist.id
    respond_to do |format|
      if @art_theme.update_attributes(params[:art_theme])
        if @art_theme.attachments.empty?
              if !params[:article].nil? && !params[:article][:uploaded_data].blank?
                @attachment = Attachment.new(params[:article])
                @art_theme.attachments << @attachment		 
              end
        else
           if !params[:article].nil? && !params[:article][:uploaded_data].blank?
              @art_theme_attachments = @art_theme.attachments.all :order=>'created_at'
              @art_theme_attachments[0].destroy #if @artist_attachments.length > 1
              @attachment = Attachment.new(params[:article])
              @art_theme.attachments << @attachment		 
          end          
        end
        flash[:success] = 'Art Theme was successfully updated.'
        format.html { redirect_to(admin_artist_art_themes_path(@artist.id)) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit", :artist_id=>@artist.id }
        format.xml  { render :xml => @art_theme.errors, :status => :unprocessable_entity }
      end
    end
  end

  def destroy
    @art_theme = ArtTheme.find(params[:id])
		@artist = Artist.find(params[:artist_id])
    @art_theme.destroy
    flash[:success] = "Art Theme successfully deleted"
    respond_to do |format|
      format.html { redirect_to(admin_artist_art_themes_path(@artist.id)) }
      format.xml  { head :ok }
    end
  end
end
