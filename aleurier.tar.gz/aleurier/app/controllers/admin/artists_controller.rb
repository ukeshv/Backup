class Admin::ArtistsController < ApplicationController
  layout "admin"
	 before_filter :admin_login_required
   @@entries_per_page = 20
   def index
    conditions = "(name like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
  
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"

    options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
    
    if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @artists = Artist.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @artists = Artist.paginate(options)
      @search_artist=1
      @search_value=params[:search]
    else
      @artists = Artist.paginate(options)
    end
  end

  def show
    @artist = Artist.find(params[:id])
  end
  
  def new
    @artist = Artist.new
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @artist }
    end
  end

  def edit
    @artist = Artist.find(params[:id])
  end

  def create
    @artist = Artist.new(params[:artist])    
    respond_to do |format|
      if @artist.save
       if !params[:article].nil? && !params[:article][:uploaded_data].blank?
			@attachment = Attachment.new(params[:article])
			@artist.attachments << @attachment		 
		end	 
        
        flash[:success] = 'Artist was successfully created.'
        format.html { redirect_to(admin_artists_path) }
        format.xml  { render :xml => @artist, :status => :created, :location => @artist }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @artist.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  def update
    @artist = Artist.find(params[:id])
    respond_to do |format|
      if @artist.update_attributes(params[:artist])
        if @artist.attachments.empty?
              if !params[:article].nil? && !params[:article][:uploaded_data].blank?
                @attachment = Attachment.new(params[:article])
                @artist.attachments << @attachment		 
              end
        else
           if !params[:article].nil? && !params[:article][:uploaded_data].blank?
              @artist_attachments = @artist.attachments.all :order=>'created_at'
              @artist_attachments[0].destroy #if @artist_attachments.length > 1
              @attachment = Attachment.new(params[:article])
              @artist.attachments << @attachment		 
          end          
        end
        flash[:success] = 'Artist was successfully updated.'
        format.html { redirect_to(admin_artists_path) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @artist.errors, :status => :unprocessable_entity }
      end
    end
  end

  def destroy
    @artist = Artist.find(params[:id])
    @artist.destroy
    flash[:success] = "Artist deleted successfully!"
    respond_to do |format|
      format.html { redirect_to(admin_artists_path) }
      format.xml  { head :ok }
    end
  end
end
