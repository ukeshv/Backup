class Admin::BrandsController < ApplicationController
	 # GET /brands
  # GET /brands.xml
    layout "admin"
	before_filter :admin_login_required
  @@entries_per_page = 20
 def index
    conditions = "(name like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
  
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"

    options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
    
    if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @brands = Brand.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @brands = Brand.paginate(options)
      @search_brand=1
      @search_value=params[:search]
    else
      @brands = Brand.paginate(options)
    end
  end
  # GET /brands/1
  # GET /brands/1.xml
  def show
    @brand = Brand.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @brand }
    end
  end

  # GET /brands/new
  # GET /brands/new.xml
  def new
    @brand = Brand.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @brand }
    end
  end

  # GET /brands/1/edit
  def edit
    @brand = Brand.find(params[:id])
    render :layout =>false
  end

  # POST /brands
  # POST /brands.xml
  def create
    @brand = Brand.new(params[:brand])

      if @brand.save
          @brands = Brand.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
        render :update do |page|
          page.hide "name_brand"
          page.replace_html "list", :partial=>"listing_brands"
          page.replace_html "flashnotice",  :text=>"Brand created successfully!"
          page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
          page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
        end
      else
         show_hide_error_messages(@brand,'brand')	    
      end
    end
    
    
def show_hide_error_messages1(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id + "1"
               page.replace_html "#{h[0]}_" + replacing_id+"1", "#{h[1]}"
             end
              page.hide "search_text"
               page.hide "flashnotice"
               page.hide "name_brand"
             	page.hide "name_brand1"  if  obj.errors["name"].nil?
           end
         end
  end
  def show_hide_error_messages(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id
               page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
             end
              page.hide "search_text"
              page.hide "flashnotice"
             	page.hide "name_brand"  if  obj.errors["name"].nil?
           end
         end
  end

  # PUT /brands/1
  # PUT /brands/1.xml
  def update
    @brand = Brand.find(params[:id])
      if @brand.update_attributes(params[:brand])
           @brands = Brand.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
        render :update do |page|
          page.hide "edit_#{@brand.id}"
          page.hide "name_brand"
          page.replace_html "editname_#{@brand.id}", :partial=>"updated_brand"
          page.replace_html "flashnotice",  :text=>"Brand updated successfully!"
          page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
          page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
        end
      else
         show_hide_error_messages1(@brand,'brand')	    
      end
  end

  # DELETE /brands/1
  # DELETE /brands/1.xml
    def destroy
      @brand = Brand.find(params[:id])
      brand_pref = UserPreference.find(:first,:conditions=>['preference_type = ? and preference_id = ?','Brand',@brand.id])
      if @brand.gears.empty? && brand_pref.nil?
      @brand.destroy
      flash[:success] = "Brand deleted successfully!"
      else
      flash[:success] =  "You cannot delete this brand as it has related gears/preferences added by users"
      end
      respond_to do |format|
        format.html { redirect_to(admin_brands_url) }
        format.xml  { head :ok }
      end  
      end

  def cancel
  @brand = Brand.find(params[:id]) 
  render :update do |page|
          page.replace_html "edit_#{@brand.id}", :partial=>"edit_icon"
        end
  
  end
end
