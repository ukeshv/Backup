class Admin::CategoriesController < ApplicationController
	 # GET /categories
  # GET /categories.xml
  layout "admin"
	before_filter :admin_login_required
  @@entries_per_page = 20
 def index
    conditions = "(name like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
  
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"

    options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
    
    if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @categories = Category.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @categories = Category.paginate(options)
      @search_category=1
      @search_value=params[:search]
    else
      @categories = Category.paginate(options)
    end
  end
  
  # GET /categories/1
  # GET /categories/1.xml
  def show
    @category = Category.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @category }
    end
  end

  # GET /categories/new
  # GET /categories/new.xml
  def new
    @category = Category.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @category }
    end
  end

  # GET /categories/1/edit
  def edit
    @category = Category.find(params[:id])
  end

  # POST /categories 
  # POST /categories.xml
  def create
    @category = Category.new(params[:category])
    if !params[:attach].nil?
      @attachment= Attachment.new(:uploaded_data=>params[:attach][:image_attachment]) 
    end
    @category.attachment = @attachment
       respond_to do |format|
         if (!@attachment.nil? ? (@attachment.valid? && @category.save) : (@category.save))
        flash[:success] = 'Category was successfully created.'
        format.html { redirect_to(admin_categories_path) }
        format.xml  { render :xml => @category, :status => :created, :location => @category }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @category.errors, :status => :unprocessable_entity }
      end
    end
    end
    
    
def show_hide_error_messages1(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id + "1"
               page.replace_html "#{h[0]}_" + replacing_id+"1", "#{h[1]}"
             end
              page.hide "search_text"
              page.hide "flashnotice"
              page.hide "name_category"
             	page.hide "name_category1"  if  obj.errors["name"].nil?

           end
         end
  end
  def show_hide_error_messages(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id
               page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
             end
              page.hide "search_text"
              page.hide "flashnotice"
             	page.hide "name_category"  if  obj.errors["name"].nil?
           end
         end
  end

  # PUT /categories/1
  # PUT /categories/1.xml
  def update
    @category = Category.find(params[:id])
    if !params[:attach].nil?
      @attachment= Attachment.new(:uploaded_data=>params[:attach][:image_attachment]) 
      @category.attachment = @attachment
    end
    if @category.update_attributes(params[:category])
      flash[:success] = 'Category was successfully created.'
      redirect_to admin_categories_path
    else
      render :action=>"edit"
    end    
  end

  # DELETE /categories/1
  # DELETE /categories/1.xml
    def destroy
      @category = Category.find(params[:id])  
      cat_pref = UserPreference.find(:first,:conditions=>['preference_type = ? and preference_id = ?','Category',@category.id])
        if @category.gears.empty? && cat_pref.nil?
          @category.destroy
          flash[:success] =  "Category deleted successfully!"        
        else
          flash[:success] =  "You cannot delete this category as it has related gears/preferences added by users"
      end
        respond_to do |format|
        format.html { redirect_to(admin_categories_url) }
        format.xml  { head :ok }
      end      
    end  
      
  def cancel
  @category = Category.find(params[:id]) 
  render :update do |page|
    page.replace_html "edit_#{@category.id}", :partial=>"edit_icon"
  end
  
  end
  
end
