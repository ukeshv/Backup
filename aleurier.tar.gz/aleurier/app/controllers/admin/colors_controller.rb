class Admin::ColorsController < ApplicationController
	layout "admin"
  before_filter :admin_login_required
  @@entries_per_page = 20
def index
    conditions = "(name like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
  
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"

    options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
    
    if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @colors = Color.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @colors =Color.paginate(options)
      @search_color=1
      @search_value=params[:search]
    else
      @colors = Color.paginate(options)
    end
  end

  # GET /products/1
  # GET /products/1.xml
  def show
    @color = Color.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @color }
    end
  end

  # GET /products/new
  # GET /products/new.xml
  def new
    @color = Color.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @color }
    end
  end

  # GET /products/1/edit
  def edit
    @color = Color.find(params[:id])
    render :layout =>false
  end

  # POST /products
  # POST /products.xml
  def create
    @color = Color.new(params[:color])

      if @color.save
          @colors = Color.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
        render :update do |page|
          page.hide "name_color"
          page.replace_html "list", :partial=>"listing_colors"
          page.replace_html "flashnotice", :text=>"Color created successfully!"
          page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
          page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
        end
      else
         show_hide_error_messages(@color,'color')	    
      end
    end
    
    
def show_hide_error_messages1(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id + "1"
               page.replace_html "#{h[0]}_" + replacing_id+"1", "#{h[1]}"
             end
              page.hide "search_text"
               page.hide "flashnotice"
               page.hide "name_color"
             	page.hide "name_color1"  if  obj.errors["name"].nil?
           end
         end
  end
  def show_hide_error_messages(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id
               page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
             end
             page.hide "search_text"
             page.hide "flashnotice"
             page.hide "name_color"  if  obj.errors["name"].nil?
           end
         end
  end

  # PUT /products/1
  # PUT /products/1.xml
  def update
    @color = Color.find(params[:id])
      if @color.update_attributes(params[:color])
           @colors = Color.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
        render :update do |page|
          page.hide "edit_#{@color.id}"
          page.hide "name_color"
          page.replace_html "editname_#{@color.id}", :partial=>"updated_color"
          page.replace_html "flashnotice", :text=>"Color updated successfully!"
          page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
          page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
        end
      else
         show_hide_error_messages1(@color,'color')	    
      end
  end

  # DELETE /products/1
  # DELETE /products/1.xml
  def destroy
    @color = Color.find(params[:id])
    color_pref = UserPreference.find(:first,:conditions=>['preference_type = ? and preference_id = ?','Color',@color.id])
    if @color.gears.empty? && color_pref.nil?
    @color.destroy
    flash[:success] = "Color deleted successfully!"
    else
      flash[:success] =  "You cannot delete this color as it has related gears/preferences added by users"
    end  
    respond_to do |format|
      format.html { redirect_to(admin_colors_url) }
      format.xml  { head :ok }
    end
  end  
  def cancel
  @color = Color.find(params[:id]) 
  render :update do |page|
          page.replace_html "edit_#{@color.id}", :partial=>"edit_icon"
        end
  
  end
  
end
