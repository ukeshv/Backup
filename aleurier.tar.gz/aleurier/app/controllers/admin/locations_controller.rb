class Admin::LocationsController < ApplicationController
	 # GET /locations
  # GET /locations.xml
  layout "admin"
	before_filter :admin_login_required
  @@entries_per_page = 20
 def index
    conditions = "(name like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
  
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"

    options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
    
    if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @locations = Location.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @locations = Location.paginate(options)
      @search_location=1
      @search_value=params[:search]
    else
      @locations = Location.paginate(options)
    end
  end
  # GET /locations/1
  # GET /locations/1.xml
  def show
    @location = Location.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @location }
    end
  end

  # GET /locations/new
  # GET /locations/new.xml
  def new
    @location = Location.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @location }
    end
  end

  # GET /locations/1/edit
  def edit
    @location = Location.find(params[:id])
    render :layout =>false
  end

  # POST /locations
  # POST /locations.xml
  def create
    @location = Location.new(params[:location])

      if @location.save
          @locations = Location.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
        render :update do |page|
          page.hide "name_location"
          page.hide "search_text"
          page.replace_html "list", :partial=>"listing_locations"
          page.replace_html "flashnotice",:text=>"Location created successfully!"
          page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
          page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
        end
      else
         show_hide_error_messages(@location,'location')	    
      end
    end
    
    
def show_hide_error_messages1(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id + "1"
               page.replace_html "#{h[0]}_" + replacing_id+"1", "#{h[1]}"
             end
             page.hide "search_text"
             page.hide "flashnotice"
             page.hide "name_location"
             page.hide "name_location1"  if  obj.errors["name"].nil?
           end
         end
  end
  def show_hide_error_messages(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id
               page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
             end
             page.hide "search_text"
             page.hide "flashnotice"
             	page.hide "name_location"  if  obj.errors["name"].nil?
           end
         end
  end

  # PUT /locations/1
  # PUT /locations/1.xml
  def update
    @location = Location.find(params[:id])
      if @location.update_attributes(params[:location])
           @locations = Location.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
        render :update do |page|
          page.hide "edit_#{@location.id}"
          page.hide "search_text"
          page.hide "name_location"
          page.replace_html "editname_#{@location.id}", :partial=>"updated_location"
          page.replace_html "flashnotice", :text=>"Location Updated successfully!"
          page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
          page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
        end
      else
         show_hide_error_messages1(@location,'location')	    
      end
  end

  # DELETE /categories/1
  # DELETE /categories/1.xml
  def destroy
    @location = Location.find(params[:id])
    loc_pref = UserPreference.find(:first,:conditions=>['preference_type = ? and preference_id = ?','Location',@location.id])
      if @location.gears.empty? && loc_pref.nil?
    @location.destroy
    flash[:success] =  "Location deleted successfully!"
     else
      flash[:success] =  "You cannot delete this location as it has related gears/preferences added by users"
      end
    respond_to do |format|
      format.html { redirect_to(admin_locations_url) }
      format.xml  { head :ok }
    end
  end  
  def cancel
  @location = Location.find(params[:id]) 
  render :update do |page|
          page.replace_html "edit_#{@location.id}", :partial=>"edit_icon"
        end
  
  end
  
end
