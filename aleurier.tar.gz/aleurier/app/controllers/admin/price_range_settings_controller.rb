class Admin::PriceRangeSettingsController < ApplicationController
	 layout "admin"
   before_filter :admin_login_required
   @@entries_per_page = 20
	 def index
    @price_range_settings = PriceRangeSetting.paginate(:all,:page=>params[:page],:per_page=>@@entries_per_page)
  end

  def show
    @price_range_setting = PriceRangeSetting.find(params[:id])
  end
  
  def new
    @price_range_setting = PriceRangeSetting.new
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @price_range_setting }
    end
  end

  def edit
    @price_range_setting = PriceRangeSetting.find(params[:id])
  end

  def create

    @price_range_setting = PriceRangeSetting.new(params[:price_range_setting])
    respond_to do |format|
      if @price_range_setting.save
        flash[:success] = 'Price Range Setting was successfully created.'
        format.html { redirect_to(admin_price_range_settings_path) }
        format.xml  { render :xml => @price_range_setting, :status => :created, :location => @price_range_setting }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @price_range_setting.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  def update
    @price_range_setting = PriceRangeSetting.find(params[:id])
    respond_to do |format|
      if @price_range_setting.update_attributes(params[:price_range_setting])
        flash[:success] = 'Price Range Setting was successfully updated.'
        format.html { redirect_to(admin_price_range_settings_path) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @price_range_setting.errors, :status => :unprocessable_entity }
      end
    end
  end

  def destroy
    @price_range_setting = PriceRangeSetting.find(params[:id])
    @price_range_setting.destroy
    flash[:success] = "Price Range Setting successfully deleted"
    respond_to do |format|
      format.html { redirect_to(admin_price_range_settings_path) }
      format.xml  { head :ok }
    end
  end
end
