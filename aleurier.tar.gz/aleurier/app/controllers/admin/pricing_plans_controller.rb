class Admin::PricingPlansController < ApplicationController
	 layout "admin"
   before_filter :admin_login_required
   @@entries_per_page = 20
	 def index
    @pricing_plans = PricingPlan.paginate(:all,:page=>params[:page],:per_page=>@@entries_per_page)
  end

  def show
    @pricing_plan = PricingPlan.find(params[:id])
  end
  
  def new
    @pricing_plan = PricingPlan.new
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @pricing_plan }
    end
  end

  def edit
    @pricing_plan = PricingPlan.find(params[:id])
  end

  def create

    @pricing_plan = PricingPlan.new(params[:pricing_plan])
    respond_to do |format|
      if @pricing_plan.save
        flash[:success] = 'PricingPlan was successfully created.'
        format.html { redirect_to(admin_pricing_plans_path) }
        format.xml  { render :xml => @pricing_plans, :status => :created, :location => @pricing_plans }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @pricing_plans.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  def update
    @pricing_plan = PricingPlan.find(params[:id])
    respond_to do |format|
      if @pricing_plan.update_attributes(params[:pricing_plan])
        flash[:success] = 'Pricing plan was successfully updated.'
        format.html { redirect_to(admin_pricing_plans_path) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @pricing_plan.errors, :status => :unprocessable_entity }
      end
    end
  end

  def destroy
    @pricing_plan = PricingPlan.find(params[:id])
    @pricing_plan.destroy
    flash[:success] = "Pricing Plan successfully deleted"
    respond_to do |format|
      format.html { redirect_to(admin_pricing_plans_path) }
      format.xml  { head :ok }
    end
  end
end
