class Admin::UsersController < ApplicationController
	layout "admin"
	 before_filter :admin_login_required
   @@entries_per_page = 20
	 def index
     if params[:order] || params[:by]
    @users = User.paginate(:all,:order => "#{params[:order]} #{params[:by]}",:page=>params[:page], :per_page=>@@entries_per_page)
    elsif params[:commit] == "Search" && !params[:search].empty? && !params[:search].blank?
    @users = User.paginate(:all, :conditions=>['firstname LIKE (?)', "%#{params[:search]}%"],:page=>params[:page],:per_page=>@@entries_per_page)    
    elsif params[:commit] == "Search" && params[:search].empty?
      @flag = 1
    else
      @flag1 = 1
    @users = User.paginate(:all,:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
    end
  end
	
	def edit
	@user = User.find(params[:id])
	end

def update
	@user = User.find(params[:id])
	if @user.update_attributes(params[:user])
			flash[:success] = "User Updated Successfully!"
			redirect_to admin_users_path
	else
		render :action=>"edit"
	end
end

 def destroy
    @user = User.find(params[:id])
    @user.destroy
    flash[:success] = "User successfully deleted"
    respond_to do |format|
      format.html { redirect_to(admin_users_path) }
      format.xml  { head :ok }
    end
  end
	
	def activate_user
	@user = User.find(params[:id])
	if @user.update_attribute("status",true)
			flash[:success] = "User Activated Successfully!"
	end
			redirect_to admin_users_path			
	end
	
	def deactivate_user
	@user = User.find(params[:id])
	if @user.update_attribute("status",false)
			flash[:success] = "User Deactivated Successfully!"
	end
			redirect_to admin_users_path	
	end
		
	def do_delete
		@user = User.find(params[:id])
	if @user.update_attribute("is_deleted",true)
			flash[:success] = "User Deleted status changed Successfully!"
	end
			redirect_to admin_users_path			
	end

	def donot_delete
		@user = User.find(params[:id])
	if @user.update_attribute("is_deleted",false)
			flash[:success] = "User Deleted status changed Successfully!"
	end
			redirect_to admin_users_path			
	end

		
		
		
	
end
