class Admin::VendorsController < ApplicationController
	layout "admin"
	 before_filter :admin_login_required
   @@entries_per_page = 20
	 def index
		 conditions = "(username like '%#{params[:search]}%' || email  like '%#{params[:search]}%' || company  like '%#{params[:search]}%' || contact_person like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
  
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"

		options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
		  if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @vendors = Vendor.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @vendors = Vendor.paginate(options)
      @search_vendor=1
      @search_value=params[:search]
    else
      @vendors = Vendor.paginate(options)
    end
  end
	
	def edit
	@vendor = Vendor.find(params[:id])
	end

def update
	@vendor = Vendor.find(params[:id])
	if @vendor.update_attributes(params[:vendor])
			flash[:success] = "Vendor Updated Successfully!"
			redirect_to admin_vendors_path
	else
		render :action=>"edit"
	end
end

 def destroy
    @vendor = Vendor.find(params[:id])
    @vendor.destroy
    flash[:success] = "Vendor successfully deleted"
    respond_to do |format|
      format.html { redirect_to(admin_vendors_path) }
      format.xml  { head :ok }
    end
  end

def activate_vendor 
	@vendor = Vendor.find(params[:id])
	 status=@vendor.status ? false : true
	if @vendor.update_attribute("status",status)
			flash[:success] =@vendor.status ?  "Vendor Deactivated Successfully!" :  "Vendor Activated Successfully!"
	end
			redirect_to admin_vendors_path
	end
		
	def do_delete
		@vendor = Vendor.find(params[:id]) 
		status=@vendor.is_deleted ? false : true
	if @vendor.update_attribute("is_deleted",status)
			flash[:success] = "Vendor Deleted status changed Successfully!"
	end
			redirect_to admin_vendors_path			
	end
	
	def verify
		@vendor = Vendor.find(params[:id])
		 status=@vendor.is_verified ? false : true
	if @vendor.update_attribute("is_verified",status)
		if @vendor.is_verified == true && @vendor.fb_user_id.nil? 	
			AdminMailer.deliver_vendor_activated_notification(@vendor)
		end	
			flash[:success] = "Vendor Verification status changed Successfully!"
	end
			redirect_to admin_vendors_path		
 end
		
end
