class AdminsController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  layout "admin"
 include AdminAuthenticatedSystem
before_filter :admin_login_required, :except=>['new','create']
  # render new.rhtml
  def new
    redirect_to dashboard_admins_path if current_admin
  end

  def create
    admin_logout_keeping_session!
    admin = Admin.authenticate(params[:username], params[:password])
    if admin
      # Protects against session fixation attacks, causes request forgery
      # protection if user resubmits an earlier form using back
      # button. Uncomment if you understand the tradeoffs.
      # reset_session
      self.current_admin = admin
      #new_cookie_flag = (params[:remember_me] == "1")
      #admin_handle_remember_cookie! new_cookie_flag
      redirect_to dashboard_admins_path
      flash[:notice] = "Logged in successfully"
    else
      note_failed_signin
      @username       = params[:username]
      @remember_me = params[:remember_me]
      render :action => 'new'
    end
  end

  def destroy
    admin_logout_killing_session!
    flash[:notice] = "You have been logged out."
    redirect_to admin_logout_path
  end
  
  def dashboard
  
  end
  

protected
  # Track failed login attempts
  def note_failed_signin
    flash[:error] = "Invalid Username or password."
    logger.warn "Failed login for '#{params[:username]}' from #{request.remote_ip} at #{Time.now.utc}"
  end
end
