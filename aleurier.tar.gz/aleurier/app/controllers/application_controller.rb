# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  helper :all # include all helpers, all the time
  #protect_from_forgery # See ActionController::RequestForgeryProtection for details
  before_filter :set_facebook_session
  helper_method :facebook_session

  include ExceptionNotifiable
  include AuthenticatedSystem
  include AdminAuthenticatedSystem
  # Scrub sensitive parameters from your log
  # filter_parameter_logging :password
  def remaining_categories(gears) # return the list of categories that is not included in the cube look gears
    category_ids = gears.collect{|x| x.category_id}
    remaining_objects = []
    Category.find(:all).collect{|x| remaining_objects << x if !category_ids.include?(x.id)}
    remaining_ids = remaining_objects.collect{|x| x.id}
    return remaining_objects, remaining_ids
  end
  def collect_gear_from_category(category_id_array)
    new_categories = []
    new_gears = []
    #~ category_id_array[position_of_array.to_i] = value_of_position
    category_id_array.each do |each_id|
      category = Category.find(each_id)
      new_categories << category
      #~ new_gears << category.gears.first
      prefered_gear = User.preferred_gears(current_user, category)
      # collect gears based on user preference
      if prefered_gear.nil?
        new_gears << category.gears.first
      else
        new_gears << prefered_gear 
      end            
    end
    return new_categories, new_gears
  end
  
  def collect_category_ids_from_gear_ids(gear_ids)
    category_ids = []
    gear_ids.each do |gear_id|
      category_ids << Gear.find(gear_id).category_id
    end    
    return category_ids
  end  
  
  def find_gear_from_category_collection(category_collection) # method returns the gear id collection for the appropriate category collection.
    gear_ids = []
    category_collection.each do |category_id|
      category = Category.find(category_id)
      gear_ids << category.gears.first if !category.gears.empty?
    end    
    return gear_ids
  end
  
  def check_input_parameters(params)    
    return false, 'both' if (params[:subscription][:cc_last_4digit].strip == '' && params[:subscription][:ccv_number].strip == '')        
    if (params[:subscription][:cc_last_4digit].strip == '' || params[:subscription][:ccv_number].strip == '')            
      return false, (params[:subscription][:cc_last_4digit].strip == '')? 'card_number' : 'ccv_number'
    else      
      error_type = []
      unless (params[:subscription][:cc_last_4digit] =~ /\D/).nil?
        error_type << 'card_number'
      end
      unless (params[:subscription][:ccv_number] =~ /\D/).nil?
        error_type << 'ccv_number'
      end
      if (error_type.length >= 1)
        return false, (error_type.length == 2)? 'both' : error_type.first
      else
        if (params[:subscription][:cc_last_4digit].strip.length == 16 && params[:subscription][:ccv_number].strip.length == 3)          
          return true, 'no-error'
        else
          return false, (params[:subscription][:cc_last_4digit].strip.length == 16)? 'ccv_number' : 'card_number'
        end        
      end
    end    
  end
  
  def plan_already_exists?(new_plan_id)
    return (current_vendor.current_plan_id == new_plan_id.to_i)? false : true
  end
  
  def assign_gears_to_cube(cube_obj, gear_ids)
    gear_position = 1
    gear_ids.each do |gear_id|    
      if Gear.exists?(gear_id)
        @gear = Gear.find(gear_id)
        cube_obj.gears << @gear
        update_gear_position(cube_obj.id, gear_id, gear_position)
        gear_position += 1
      end
    end    
  end
  
  def update_gear_position(cube_id, gear_id, position)
    @cube_gear = CubeGear.find(:first, :conditions => ['cube_id = ? && gear_id = ?', cube_id, gear_id])
    @cube_gear.update_attributes(:user_id => current_user.id, :position => position )
  end  
  
  def render_to_pdf(options = nil)
  data = render_to_string(options)
  pdf = PDF::HTMLDoc.new
  pdf.set_option :bodycolor, :white
  pdf.set_option :toc, false
  pdf.set_option :portrait, true
  pdf.set_option :links, false
  pdf.set_option :webpage, true
  pdf.set_option :left, '2cm'
  pdf.set_option :right, '2cm'
  pdf << data
  pdf.generate
end
  
  def toggle_position_of_gear(gear_id_array, position)
    go_to_back = gear_id_array[position]
    go_to_front = gear_id_array[position-1]
    gear_id_array[position] = go_to_front
    gear_id_array[position-1] = go_to_back
  end  
  
  def check_gear_id_conflict(array_ids, value)
    count = 0
    array_ids.each do |each_value|
      count += 1 if each_value == value
    end    
    return (count > 2)? true : false
  end  
  
  def collect_songs(artists_obj)
    songs_coll = []
    artists_obj.each do |artist|
      artist.songs.collect{|song| songs_coll << song}
    end    
    return songs_coll
  end  
  
  #Method for initializing the PaypalGateway using login,pwd and signature
  def creditcard_gateway
  ActiveMerchant::Billing::Base.mode = :test #change the mode,when deployed to live or comment this line
 
	gateway = ActiveMerchant::Billing::PaypalGateway.new(
				:login => APP_CONFIG[:gateway_login],
				:password => APP_CONFIG[:gateway_password],
				:signature => APP_CONFIG[:gateway_signature]
	)
  end  
  
end



