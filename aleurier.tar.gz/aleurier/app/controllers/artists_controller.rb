class ArtistsController < ApplicationController
	layout "user",:except=>['show'] #"application1",:except=>['show']
	include AuthenticatedSystem

	def index
		session[:current_artist] = Artist.find :first
		if (params[:tab] && params[:tab] == "newly_added")
			@songs = Song.paginate(:page=>params[:page], :per_page => 5,:order=>'created_at DESC')
		elsif (params[:tab] && params[:tab] == "current_artist")
			@songs = session[:current_artist] ? session[:current_artist].songs.paginate(:page=>params[:page], :per_page => 5,:order=>'created_at DESC') : []
		elsif (params[:tab] && params[:tab] == "most_hearted")
			@songs = Song.paginate(:page=>params[:page], :per_page => 5,:order=>'heart_count DESC')
		elsif (params[:tab] && params[:tab] == "random")
			@songs = Song.paginate(:page=>params[:page], :per_page => 5,:order=>'RAND()')
		else
			@songs = Song.paginate(:page=>params[:page], :per_page => 5,:order=>'created_at DESC')	if !params[:art_themes] 
			#this query don't call when call ajax pagination in art themes
	 end
			@themes = ArtTheme.paginate(:page=>params[:page], :per_page => 2,:order=>'RAND()')
			
			unless params[:tab].nil?
				render :update do |page|
				page.replace_html "list_of_songs", :partial=>"/partials/list_of_songs_display",:object=>@songs
				end
		  end	 
		
			unless params[:art_themes].nil? 
				render :update do |page|
				page.replace_html "list_of_themes", :partial=>"/partials/artist_right_sidebar",:object=>@themes 
				end	 
			end	 
	end	
		
	def pagination_update
		respond_to do |format|
		format.js {
			render :update do |page|				
				if params[:art_themes] && params[:art_themes]=="true"
					page.replace_html "list_of_themes", :partial=>"partials/artist_right_sidebar",:object=>@themes
				else
					page.replace_html "list_of_songs", :partial=>"partials/list_of_songs_display",:object=>@songs
				end
			end
		}
end 
	end
	
	def show
		@artist = Artist.find_by_id(params[:id])
		if @artist &&  params[:list] &&  params[:list]=="songs"
			@songs=@artist.songs.paginate(:page=>params[:page], :per_page => 5,:order=>'created_at DESC') 
		elsif @artist 
			@art_themes=@artist.art_themes.paginate(:page=>params[:page], :per_page => 5,:order=>'created_at DESC') 
		end
			@themes = ArtTheme.paginate(:page=>params[:page], :per_page => 5,:order=>'created_at DESC')
	end
	
	def change_layout
    if !session[:vendor_id].nil? 
    	"application1" unless action_name == "show"
	  elsif !session[:user_id].nil?
			"users_application" unless action_name == "show"
		else
      "application1"	unless action_name == "show"		
		end	
		#~ cname = controller_name
    #~ aname = action_name
		#~ if cname= "vendors" || cname= "vendor/gears" || !current_vendor.nil?
			#~ "application1" 
		#~ else
			#~ "users_application"
    #~ end			
	end
	
	def default_playlist_xml		# playlist types: [recent, random, hearted, same]				
				@artists = Artist.newest(2) if params[:playlist_type] == 'newest'		
				if params[:playlist_type] == 'artist'
					@artists = Artist.find(:all, :conditions => ['id = ?', Attachment.find(params[:attachment_id]).attachable.artist.id])
				end
				
				if params[:playlist_type] == 'hearted'
					@songs = Song.most_hearted_songs(5)
				elsif params[:playlist_type] == 'random'
					@songs = Song.random_record(5)
				else			
					@songs = collect_songs(@artists)	
				end		
				@status = (@songs.length >= 1)? true : false
		
		render :partial => '/artists/playlist', :layout => false, :content_type => 'application/xml'    
	end	
	
	def heart_count
		if Attachment.exists?(params[:attachment_id])
			attachment = Attachment.find(params[:attachment_id])
			song = attachment.attachable
			song.update_attribute('heart_count', (song.heart_count + 1))		if params[:update_count] == "true"
			render :update do |page|
				page.replace_html 'heart_count', "<span id='heart_count_display'>#{song.heart_count}</span>"
				#page.call("update_heart_count_display", song.heart_count)
			end			
		end		
	end	
	
	def below_heart_count
		if Song.exists?(params[:song_id])
			song = Song.find(params[:song_id])
			song.update_attribute('heart_count', (song.heart_count + 1))
			render :update do |page|
				page.replace_html "heart_count_display_#{song.id}", "#{song.heart_count}"
			end			
		end		
	end	
	
	def load_selected_song
		@songs = []
		if (!params[:song_id].nil? && Song.exists?(params[:song_id]))
			@songs << Song.find(params[:song_id])			
			
			@artists = Artist.newest(2) if params[:playlist_type] == 'newly_added'		
			@artists = Artist.random_record(2) if params[:playlist_type] == 'current_artist'
			
			if params[:playlist_type] == 'most_hearted'
				@songs << Song.most_hearted_songs(7)
			elsif (params[:playlist_type] == 'random' || params[:playlist_type] == '')
				@songs << Song.random_record(7)
			else			
				@songs << collect_songs(@artists)	
			end					
			@songs = @songs.flatten.uniq
			@status = (@songs.length >= 1)? true : false			
			
			render :partial => '/artists/playlist', :layout => false, :content_type => 'application/xml'    
		end		
	end	
	
end
