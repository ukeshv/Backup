class HomeController < ApplicationController
	 layout :change_layout
	 include VendorAuthenticatedSystem
	 
	 def vendors
		if current_vendor
    redirect_to vendor_dashboard_path
    end
	 end
	
	 def users
		
	end 
	
	def change_layout
		(controller_name == 'home' && action_name == 'vendors') ? 'application1' : 'user'
	end	
	
	 
	 
end
