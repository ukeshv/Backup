# This controller handles the login/logout function of the site.  
class SessionsController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
   layout "user"
  include AuthenticatedSystem

  # render new.rhtml
  def new
    #redirect_to admin_path
    redirect_to user_gears_path if current_user
  end

  def create
    return unless request.post?
    logout_keeping_session!
    unless params[:user][:email].blank? || params[:user][:password].blank?
      user = User.authenticate(params[:user][:email], params[:user][:password])
      user ? user.is_deleted ? is_account_deleted_user   :  successful_login : user_login_failed
      self.current_user = user 
    else
      email_or_password_blank #email  or password is balnk validation
    end
  end
  
  def email_or_password_blank
    flash.now[:error] = "Enter Email and Password"
    render :action => 'new'
  end
  
  def user_login_failed
    @email       = params[:user][:email]
    @remember_me = params[:remember_me]
    flash.now[:error] = "Please enter valid Email and Password !"	
    render :action => 'new'
  end
  
  def successful_login   
    if params[:remember_me] 
      new_cookie_flag = (params[:remember_me] == "1")
      handle_remember_cookie! new_cookie_flag
    else
      cookies.delete :auth_token
    end
      flash[:notice] = "Logged in successfully"
      redirect_back_or_default(user_gears_path)
  end

  def is_account_deleted_user
    flash.now[:error] = "Your Account has been deleted.If you want to login contact Admin"  
    render :action => 'new'
  end  
  
  def destroy
    logout_killing_session!
    flash[:notice] = "You have been logged out."
    redirect_back_or_default('/')
  end  
  
  def show  # method is used to redirect the page to sessions new page.
    goto_new_session
  end  
  
protected
  # Track failed login attempts
  def note_failed_signin
    flash[:error] = "Couldn't log you in as '#{params[:user][:email]}'"
    logger.warn "Failed login for '#{params[:user][:email]}' from #{request.remote_ip} at #{Time.now.utc}"
  end
  
  def goto_new_session
    redirect_to :action => 'new'
  end
  
end
