require 'json'

class User::CubesController < ApplicationController
	layout "user",:except=>['share','share_cube', 'testy','share_twitter_fb','popup_matrix']
	include AuthenticatedSystem
	before_filter :login_required,:except=>['public_view']
	
	
	def new
  	@cubed_gear_ids = params[:gear_ids].split(',')
		render :layout => false
	end	
	
	def create		# create cubed look
		@cube = Cube.create(params[:cube])
		if @cube.save			# cube saved proceed to save gear for the cube
			if params[:cube][:is_private]  == "1"
				@cube.update_attribute('is_private', 1)
			else
 				@cube.update_attribute('is_private', 0)
			end	
			current_user.cubes << @cube
			assign_gears_to_cube(@cube, params[:gear_ids].first.split(',').uniq)
			render :update do |page|
				page.replace_html 'body_content', :partial => '/user/cubes/success_page'
				page.call('reload_parent_to_other_page')
			end
		else
			@title_error = (@cube.errors['title'].nil?)? false : true
			@description_error = (@cube.errors['description'].nil?)? false : true
			render :update do |page|
				if @title_error
					page.replace_html 'title_error', "#{(display_cube_error(@cube, 'title').class == 'Array')? display_cube_error(@cube, 'title') : display_cube_error(@cube, 'title')}"  
				else
					page.replace_html 'title_error', ''
				end
				if @description_error
					page.replace_html 'description_error', "#{display_cube_error(@cube, 'description')}"  
				else
					page.replace_html 'description_error',  ''
				end				
			end			
		end		
	end	
	
	def edit_matrix
		if Cube.exists?(params[:id])
			@cube = Cube.find(params[:id])			
			@cube_look_gears, @displaying_categories = @cube.cube_look_gears
			
			# collect all gear ids displayed in matrix
			@displaying_gear_ids = @cube_look_gears.collect{|g| g.id}
			
			#To retrieve All categories and their ids separately except categories of items displayed in looks
			@remaining_categories, @remaining_category_ids = remaining_categories(@cube_look_gears) 
		end		
	end	
	
	def add_new_category
		@current_gear_ids = params[:displaying_gear_ids].split(',').uniq
		@current_gear_ids.delete_at(params[:position].to_i)
		
		@remaining_category_ids = (params[:remaining_category_ids].nil? || params[:remaining_category_ids]=='')? '[]' : params[:remaining_category_ids].split(',')
		@displaying_category_ids = params[:displaying_category_ids].split(',')		
		
		@displaying_category_ids.delete(params[:removed_category_id])		# remove the category from cube
		@remaining_category_ids << params[:removed_category_id]				# add the category to bottom scroller list
		
		@displaying_categories, @displaying_gears = collect_gear_from_category(@displaying_category_ids)				
		@displaying_category_ids = @displaying_categories.collect{|x| x.id}
		@displaying_gear_ids = @displaying_gears.collect{|x| x.id}
		@scroller_categories = Category.find(:all, :conditions => ['id in (?)', @remaining_category_ids])
		return unless request.xhr?
		#~ Jq4r.jquery_hide('category_5')
		respond_to do |format|
			format.js
		end	
	end	
	
	def index
		@cubes = current_user.cubes.paginate(:page=>params[:page], :per_page => 5)
		@recent_gears = current_user.gears.all :limit=>5,:order=>'created_at desc'
	end	
	
	def add_to_closet
		session[:closet_id] = params[:id]
		redirect_to gear_matrix_path
	end	
	
	def matrix
		# @cube_look_gears = get the gears to be displayed in matrix initially
		# @displaying_categories = get the corresponding gear's categories
		if session[:closet_id].nil?
			@cube_look_gears, @displaying_categories = current_user.cube_look_gears	
		else #If add to my closet link is clicked,selected gear is stored in session and placed in the look
			gears = [ ]
			categories = [ ]
			gear = Gear.find_by_id(session[:closet_id])
			gears << gear
			@cube_look_gears = gears
			categories << gear.category_id
			@displaying_categories = categories
			session[:closet_id] = nil
		end	
		# collect all gear ids displayed in matrix
		@displaying_gear_ids = @cube_look_gears.collect{|g| g.id}
		
		#To retrieve All categories and their ids separately except categories of items displayed in looks
		@remaining_categories, @remaining_category_ids = remaining_categories(@cube_look_gears) 
		
		#Not required - remove this
		@cubes = current_user.cubes.paginate(:page=>params[:page], :per_page => 5,:order=>"created_at DESC")
	end	
	
	def dropped_category
		original_gear_ids_array = params[:displaying_gear_ids].split(',')
		conflict_status = check_gear_id_conflict(original_gear_ids_array, params[:dropped_category_id].split('_').last)
		
		@current_gear_ids = original_gear_ids_array.uniq
		@remaining_category_ids = JSON.parse(params[:remaining_category_ids])
		displaying_category_ids = JSON.parse(params[:displaying_category_ids])
		dropped_category_id = params[:dropped_category_id].split('_').last
		displaying_category_ids << dropped_category_id
		
		@remaining_category_ids.delete(dropped_category_id)
		@gear_position = @current_gear_ids.index(dropped_category_id)		# get position of newly inserted gear
		
		gear = User.preferred_gears(current_user, Category.find(dropped_category_id))
		if conflict_status
			@current_gear_ids << gear.id unless gear.nil?
		else
			@current_gear_ids[@gear_position] = gear.id unless gear.nil?		
		end		
		
		toggle_position_of_gear(@current_gear_ids, @gear_position)		unless original_gear_ids_array.index(dropped_category_id) == (original_gear_ids_array.length - 1) # toggles the position of gear id with the prev one
		displaying_category_ids = collect_category_ids_from_gear_ids(@current_gear_ids)
		
		@displaying_categories, @displaying_gears = collect_gear_from_category(displaying_category_ids)		
		@displaying_category_ids = @displaying_categories.collect{|x| x.id}
		@displaying_gear_ids = @displaying_gears.collect{|x| x.id}
		@scroller_categories = Category.find(:all, :conditions => ['id in (?)', @remaining_category_ids])
		return unless request.xhr?
		respond_to do |format|
			format.js
		end
	end	
	
	def export_pdf
		if Cube.exists?(params[:id])
		 @cube = Cube.find(params[:id])
		 @gears = @cube.gears
    respond_to do |format|
      format.html # index.html
      format.xml { head :ok }
      format.pdf { send_data render_to_pdf({ :action => 'export_pdf.rpdf', :layout => 'pdf_report' }) }
    end
		else
			back_to_listing
		end		
	end
	
	
	
	def export_pdf_summary
	 if Cube.exists?(params[:id])	
		 @cube = Cube.find(params[:id])
		 @gears = @cube.gears
    respond_to do |format|
      format.html # index.html
      format.xml { head :ok }
      format.pdf { send_data render_to_pdf({ :action => 'export_pdf_summary.rpdf', :layout => 'pdf_report' }) }
    end
   else
		back_to_listing
	 end		
	end	
		
		
def show 
		@cube=Cube.find_by_id(params[:id])
		@recent_gears = current_user.gears.all :limit=>5,:order=>'created_at desc'
		if !@cube.nil?
			@cube_gears=CubeGear.find_all_by_user_id_and_cube_id(current_user.id,@cube.id) if @cube
			@gears=[]
			@cube_gears.each { | cube_gear| 
			@gears<< Gear.find_by_id(cube_gear.gear_id)  if cube_gear && cube_gear.gear_id
			}
			@gears=@gears.compact	 
		else
			redirect_to cubed_looks_path
		end
end

	def edit
		if Cube.exists?(params[:id])
			@cube=Cube.find_by_id(params[:id])
			@cubed_gear_ids = params[:gear_ids].split(',').uniq			
		end		
		render :layout => false
	end
	
	def update 
		if Cube.exists?(params[:id])
			@cube = Cube.find(params[:id])
			@gear_ids = params[:gear_ids].split(',').uniq
			if @cube.update_attributes(params[:cube])
					@cube.update_gears(@gear_ids, current_user.id)
					render :update do |page|
						page.replace_html 'body_content', :partial => '/user/cubes/success_page'
						page.call('reload_parent_to_other_page')
					end
			else				
					@title_error = (@cube.errors['title'].nil?)? false : true
					@description_error = (@cube.errors['description'].nil?)? false : true
					render :update do |page|
						if @title_error
							page.replace_html 'title_error', "#{(display_cube_error(@cube, 'title').class == 'Array')? display_cube_error(@cube, 'title') : display_cube_error(@cube, 'title')}"  
						else
							page.replace_html 'title_error', ''
						end
						if @description_error
							page.replace_html 'description_error', "#{display_cube_error(@cube, 'description')}"  
						else
							page.replace_html 'description_error',  ''
						end				
					end		
			end		
		end				
	end	
	
	def update_backup
		@cube=Cube.find_by_id(params[:id])
		if @cube && @cube.update_attributes(params[:cube])
				flash[:notice] = 'Cubed look was successfully updated.'
				redirect_to(cubed_looks_path)
		else
				render :action=>'edit'
		end
  end

def destroy
	@cube=Cube.find_by_id(params[:id])
	 if @cube
			@cube.destroy
			respond_to do |format|
      flash[:notice] = 'Cubed look was successfully deleted.'
      format.html { redirect_to(cubed_looks_path) }
      format.xml  { head :ok }
		end
	else
			redirect_to(cubed_looks_path)
  end
end

def  share 
	@cube=Cube.find_by_id(params[:id])
	@networks = Network.find(:all)
end

def share_cube
	@cube=Cube.find_by_id(params[:id])
	@email_error=false
	@error_msg=""
	if params[:email] && params[:email].blank?
		@error_msg="Required field cannot be left blank"
	elsif params[:message] && params[:message].blank?	
		@error_msg="Required field cannot be left blank"
	else
		 params[:email] && params[:email].split(',').each { |email|
		  if !(/\A[\w\.%\+\-]+@(?:[A-Z0-9\-]+\.)+(?:[A-Z]{2}|com|org|net|edu|gov|mil|biz|info|mobi|name|aero|jobs|museum)\z/i.match(email.strip))
				#@msgs<< "#{email} email address must be valid"
				@email_error =true
			end
		 }
				@error_msg="email address must be valid."   if  @email_error==true
				
				if params[:email] && !params[:email].blank?  && @email_error==false
					params[:email] && params[:email].split(',').each { |email|
					EmailNotification.create(:cube_id=>@cube.id,:email=>email,:message=>params[:message])
					flash[:notice] = "Successfully Added"
					#VendorMailer.deliver_share_with_friends(email,params[:message],current_user.firstname) 
					}
				end
	end
			ajax_update
end

def ajax_update
	 	 #~ respond_to do |format|
				#~ #format.html { redirect_to cubed_looks_path }
				#~ format.xml  { head :ok }
				#~ format.js {
					render :update do |page|
						if  params[:email] && !params[:email].blank? && params[:message] && !params[:message].blank? && @email_error==false
							#~ page.replace_html "success_msg", :text=>"Successfully Added in EmailNotification."
							#~ page.visual_effect(:appear, 'success_msg',  :duration =>1.5)
							#~ page.visual_effect(:fade, 'success_msg',  :duration => 2.5)
							page.call('goto_cube_look')
						else
							page.replace_html "error_msg_for_email", :text=>"#{@error_msg}"
							page.visual_effect(:appear, 'error_msg_for_email',  :duration =>1.5)
							page.visual_effect(:fade, 'error_msg_for_email',  :duration => 2.5)
						end
					end
			  #~ }
			#~ end
	
end
	
	def back_to_listing
		redirect_to :controller => 'user/cubes', :action => 'index'
	end
	
	def share_twitter_fb
		@cube=Cube.find_by_id(params[:id])
		@msg_error = ""
		if params[:network_result][:network_id] && params[:network_result][:network_id].blank?
		@msg_error="Required field cannot be left blank"
		elsif params[:network_result][:message] && params[:network_result][:message].blank?
		@msg_error="Required field cannot be left blank"
		else
			flash[:notice] = "Added successfully"
			NetworkResult.create(:user_id=>current_user.id,:cube_id=>@cube.id,:network_id=>params[:network_result][:network_id],:message=>params[:network_result][:message],:status=>false)
	  end
		
		render :update do |page|
		if  params[:network_result][:network_id] && !params[:network_result][:network_id].blank? && params[:network_result][:message] && !params[:network_result][:message].blank?
		#~ page.replace_html "success_msg", :text=>"Successfully Added in EmailNotification."
		#~ page.visual_effect(:appear, 'success_msg',  :duration =>1.5)
		#~ page.visual_effect(:fade, 'success_msg',  :duration => 2.5)
		page.call('goto_cube_look')
		else
		page.replace_html "error_msg_for_network", :text=>"#{@msg_error}"
		page.visual_effect(:appear, 'error_msg_for_network',  :duration =>1.5)
		page.visual_effect(:fade, 'error_msg_for_network',  :duration => 2.5)
		end
		end
		
	end	
	
	def public_view
		@cube = Cube.find_by_title(params[:title_url])
		if !@cube.nil?
			if !@cube.is_private? || (current_user && (current_user.id==@cube.user_id))
		   @cube_look_gears = @cube.gears
			else
				flash[:notice] = "#{@cube.user.firstname.capitalize} has set private for this look" 
				redirect_to :controller => 'user/cubes', :action => 'index'
      end				
		else
			redirect_to :controller => 'user/cubes', :action => 'index'
		end	
	end	
	
	def popup_matrix
		@selected_gear = Gear.find(params[:id])
		@gears = User.popup_preferred_gears(current_user,Category.find(@selected_gear.category_id)) 
	end	
	
	def change_popup_gear_content
		if Gear.exists?(params[:gear_id])
			@selected_gear = Gear.find(params[:gear_id])
			render :update do |page|
				page.replace_html 'gear_header', :partial => 'user/cubes/gear_header'
				page.replace_html 'gear_footer', :partial => 'user/cubes/gear_footer'
			end		
		end
	end	
	
	def change_background_gear_content
		if Gear.exists?(params[:new_gear_id])
			@new_gear = Gear.find(params[:new_gear_id])
			render :update do |page|
				page.call('update_background_gear', params[:new_gear_id], params[:old_gear_id], "#{@new_gear.get_local_path}")
			end			
		end
	end
	
	
end