class User::GearsController < ApplicationController
	layout "user"
	include AuthenticatedSystem
	
	before_filter :login_required
	before_filter :load_owner,:only=>[:edit]
	before_filter :check_id_exist,:only=>[:edit]
	 
	def check_id_exist
   gear =  Gear.find_by_id(params[:id])
		if gear.nil?
			redirect_to(user_gears_path)
		end   
  end 
	
	def load_owner
    if Gear.exists?(params[:id])
      @gear = Gear.find(params[:id])
      result = current_user.gears.include?(@gear)
      if !result   
        redirect_to user_gears_path
      end
    else
        redirect_to user_gears_path
    end
  end
	
	def index
		@user = User.find(current_user.id)
		if params[:q].blank? && params[:sort_by].blank?
		@gears = @user.gears.paginate(:page=>params[:page], :per_page => 5,:order=>"created_at DESC")
		else
			if(params[:sort_by] == "Categories")
				sort_by = "categories.created_at"
			elsif(params[:sort_by] == "Color")	
				sort_by = "colors.created_at"
			elsif(params[:sort_by] == "Brand")	
				sort_by = "brands.created_at"
			elsif(params[:sort_by] == "Gender")	
				sort_by = "gender"
			end	
		 @gears = @user.gears.paginate(:conditions=>["(title LIKE '%%#{params[:q]}%%') or (description LIKE '%%#{params[:q]}%%')"],:page=>params[:page], :per_page => 5,:include=>[:category,:color,:brand],:order=>"#{sort_by} DESC")
		 params[:sort_by] ||="Categories"
		end	
	end
	
	def new
		@categories = Category.find(:all)
		@locations = Location.find(:all)
		@brands = Brand.find(:all)
		@colors = Color.find(:all)
		load_recently_created_gears
		@gear = Gear.new
		respond_to do |format|
		format.html # new.html.erb
		format.xml  { render :xml => @gear }
		end
	end	
	
	def create
		@categories = Category.find(:all)
		@locations = Location.find(:all)
		@brands = Brand.find(:all)
		@colors = Color.find(:all)
		load_recently_created_gears
		@gear = Gear.new(params[:gear])
		if !params[:attach].nil?
		 @attachment= Attachment.new(:uploaded_data=>params[:attach][:image_attachment]) 
	 end
	 @gear.attachment = @attachment
	 @gear.owner = current_user
	 @gear.step = 0
		respond_to do |format|
      if (!@attachment.nil? ? (@attachment.valid? && @gear.save) : (@gear.save))
        flash[:notice] = 'Successfully Created Gear'
        format.html { redirect_to(user_gear_image_modify_path(@gear.attachment.id)) }
        format.xml  { render :xml => @gear, :status => :created, :location => @gear }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @gear.errors, :status => :unprocessable_entity }
      end
    end
	end
	
	def edit
		@categories = Category.find(:all)
		@locations = Location.find(:all)
		@brands = Brand.find(:all)
		@colors = Color.find(:all)
		load_recently_created_gears
		@gear = Gear.find_by_id(params[:id])
		respond_to do |format|
		format.html # new.html.erb
		format.xml  { render :xml => @gear }
		end
	end	
	
  def update
		@categories = Category.find(:all)
		@locations = Location.find(:all)
		@brands = Brand.find(:all)
		@colors = Color.find(:all)
		load_recently_created_gears
		@gear = Gear.find_by_id(params[:id])
		if !params[:attach].nil?
		@attachment= Attachment.new(:uploaded_data=>params[:attach][:image_attachment]) 
		@gear.attachment = @attachment
		end
		if @gear.update_attributes(params[:gear])
			flash[:notice] = "Successfully Updated"
			redirect_to user_gears_path
		else
			render :action=>'edit'
    end			
  end
	
	def destroy
    @gear = Gear.find_by_id(params[:id])
    @gear.destroy

    respond_to do |format|
      flash[:notice] = 'Gear was successfully deleted'
      format.html { redirect_to(user_gears_path) }
      format.xml  { head :ok }
    end
  end
	
	def delete_user_gears
    if !params[:gear_ids].blank?
      gear_ids = params[:gear_ids].split(',')
      gear_ids.each do |gear_id|
        gear = Gear.find(gear_id)
        gear.destroy 
      end
		flash[:notice]	= "Selected gear(s) deleted successfully." 
    end
    #load_email_domains
		@gears = Gear.find(:all)
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @gears }
      format.js do          
        render :update do |page|
        page.redirect_to user_gears_path
        end
      end
    end
	end 
	
	def user_gear_image_modify
		@image = Attachment.find(params[:id])
    render :action =>  'crop' 
  end
  
	
	 def crop
    if request.post?
      @image = Attachment.find(params[:id])
      @image.crop(params[:x1], params[:x2], params[:y1], params[:y2])
      redirect_to user_gears_path
    end
  end
	
	def change_layout
		if action_name == "new" || action_name == "create" || action_name == "edit" || action_name == "update"
			"user"
		else
			"users_application"
		end	
	end	
	
	def load_recently_created_gears
		@recent_gears = current_user.gears.all :limit=>5,:order=>'created_at desc'
	end	
	
end
