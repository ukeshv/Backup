class User::PreferencesController < ApplicationController
  layout "users_application"
  before_filter :login_required
  
  def index
    @user=User.find(current_user.id)
    
    if params[:type]=="featured_vendors"
      @featured_vendors=Vendor.find(:all,:conditions=>['status=? and is_verified=?',true,true])
      @lfeatured_vendors_preferences=[]
      @lfeatured_vendors_preferences=@user.preference.featured_vendors.split(",") if !@user.preference.featured_vendors.nil?
      
    elsif params[:type]=="vendors"
       @vendors=Vendor.find(:all,:conditions=>['status=? and is_verified=?',true,true])
       @vendors_preferences=[]
      @vendors_preferences=@user.preference.vendors.split(",") if !@user.preference.vendors.nil?

    elsif params[:type]=="colors"
      @colors=Color.find:all
      @color_preferences=[]
      @color_preferences=@user.preference.colors.split(",") if  !@user.preference.colors.nil?
      
    elsif params[:type]=="price_range"
      @price_ranges=PriceRangeSetting.find:all
      @price_settings_preferences=[]
      @price_settings_preferences=@user.preference.price_ranges.split(",") if  !@user.preference.price_ranges.nil?
      
    elsif params[:type]=="location"
      @locations=Location.find:all
      @location_preferences=[]
      @location_preferences=@user.preference.locations.split(",") if  !@user.preference.locations.nil?
      
    elsif params[:type]=="network"
      @featured_vendors=Vendor.find:all
      
    elsif params[:type]=="brand"
      @brands=Brand.find:all
      @brands_preferences=[]
      @brands_preferences=@user.preference.brands.split(",") if  !@user.preference.brands.nil?
    end
    
  end
 
 def update
    @user=User.find(params[:id])
    if params[:type]  && params[:type]=="colors"
       color_ids=params[:colors].join(",") if params[:colors] 
       option={:colors=>color_ids}
    elsif params[:type]  && params[:type]=="locations"
      location_ids=params[:locations].join(",") if params[:locations] 
      option={:locations=>location_ids} 
    elsif params[:type]  && params[:type]=="brands"
      brand_ids=params[:brands].join(",") if params[:brands] 
      option={:brands=>brand_ids}
    elsif params[:type]  && params[:type]=="featured_vendors"
      featured_vendor_ids=params[:featured_vendors].join(",") if params[:featured_vendors] 
      option={:featured_vendors=>featured_vendor_ids}
    elsif params[:type]  && params[:type]=="vendors"
      vendor_ids=params[:vendors].join(",") if params[:vendors] 
      option={:vendors=>vendor_ids}
    elsif params[:type]  && params[:type]=="price_range_settings"
      price_range_ids=params[:price_range_settings].join(",") if params[:price_range_settings] 
      option={:price_ranges =>price_range_ids}
    end

    if @user.preference.update_attributes(option)
        success_failure_msg_display("flashnotice","successfully updated")
    end
      
  end
  
 def success_failure_msg_display(id,msg)
   render :update do |page|
      page.replace_html "#{id}",  :text=>"#{msg}"
      page.visual_effect(:appear, "#{id}",  :duration => 1.5)
      page.visual_effect(:fade, "#{id}",  :duration => 2.5)
    end
 end
 
end