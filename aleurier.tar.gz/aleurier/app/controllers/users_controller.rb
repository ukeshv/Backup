class UsersController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  layout "user" , :except=>['generate_code','get_session','create_test_session']
  include AuthenticatedSystem
	before_filter :initialize_keys, :only=>['replace_credentials', 'generate_code','get_session','create_test_session']
	before_filter :initialize_values, :only=>['edit', 'update','change_password']
  before_filter :login_required, :except=>['new','create','index','forgot','reset_password','activate','link_user_accounts','email_verification','email_confirmation']
	
	def initialize_values
			@featured_vendors = Vendor.featured
			@vendors = Vendor.find(:all,:conditions=>['is_verified = true'],:group=>'company')
			@colors = Color.find(:all)
			@price_ranges=PriceRangeSetting.find(:all)
			@brands = Brand.find(:all)
			@locations = Location.find(:all)
			@networks = Network.find(:all)
	end	

	def index
		@latest_cubes = Cube.find_all_by_is_private(false,:limit=>10)
		@cube_gears = []
		for cube in @latest_cubes
			@cube_gears << cube.cube_gears.first #For Latest Look in Home page
		end	
		@is_featured_vendors = true
		@featured_vendors = Vendor.featured.limit(10)
		@gears = []
		@featured_vendors.each do |fv|
			@gears << fv.gears.first if !fv.gears.empty? #For Featured Vendors in Home page
		end	
		
		# If Featured Vendor's gears is blank?
		if @gears.empty?
			@is_featured_vendors = false
			vendors = Vendor.find :all
			vendors.each do |vendor|
				@gears << vendor.gears.last if !vendor.gears.empty?
			end	
		end	
	end	

  # render new.rhtml
  def new
    @user = User.new
  end
 
  def create
    logout_keeping_session!
    @user = User.new(params[:user])
    success = @user && @user.save
    if success && @user.errors.empty?
      redirect_to login_path
      flash[:notice] = "Thanks for registering in Aleurier. An E-mail has been sent to your E-mail ID provided. "
    else
      flash[:error]  = "We couldn't set up that account, sorry.  Please try again, or contact an admin (link is below)."
      render :action => 'new'
    end
  end
  
  def edit
		user = User.find_by_id(params[:id])
		if (!user.nil? && user == current_user)
			@user = User.find_by_id(current_user.id)
			@u_featured_vendors =  !@user.preference.featured_vendors.nil? ? @user.preference.featured_vendors.split(",") : []
			@u_vendors =  !@user.preference.vendors.nil? ? @user.preference.vendors.split(",") : []
			@u_colors =  !@user.preference.colors.nil? ? @user.preference.colors.split(",") : []
			@u_price_ranges = !@user.preference.price_ranges.nil? ? @user.preference.price_ranges.split(",") : []
			@u_brands = !@user.preference.brands.nil? ? @user.preference.brands.split(",") : []
			@u_locations = !@user.preference.locations.nil? ? @user.preference.locations.split(",") : []
		else
			redirect_to user_gears_path
		end	
  end
  
  def update
     @user = User.find_by_id(params[:id])
			@u_featured_vendors =  !@user.preference.featured_vendors.nil? ? @user.preference.featured_vendors.split(",") : []
			@u_vendors =  !@user.preference.vendors.nil? ? @user.preference.vendors.split(",") : []
			@u_colors =  !@user.preference.colors.nil? ? @user.preference.colors.split(",") : []
			@u_price_ranges = !@user.preference.price_ranges.nil? ? @user.preference.price_ranges.split(",") : []
			@u_brands = !@user.preference.brands.nil? ? @user.preference.brands.split(",") : []
			@u_locations = !@user.preference.locations.nil? ? @user.preference.locations.split(",") : []
    if @user.update_attributes(params[:user])
			flash[:notice] = "Successfully Updated"
			redirect_to edit_user_path(@user.id)
		else
      render :action => 'edit'
    end
  end
  	
  def profile_view_status  
     @user = User.find_by_id(current_user.id)
     params[:status] =="true" ? status=true  : status=false
     @user.is_cube_view_public=status
     @user.save
		 respond_to do |format|
				format.html { redirect_to edit_user_path(@user.id) }
				format.xml  { head :ok }
				format.js {
					render :update do |page|
						page.replace_html "flashnotice", :text=>"Profile view status changed successfully."
						page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
						#page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
					end
			  }
    end
  end
    
	def delete_account
		load_recently_created_gears
	end
	
	def account_delete_reason
		load_recently_created_gears
		if params[:user] && (params[:user][:reason_for_deletion].blank? || params[:user][:reason_for_deletion].strip.empty?)
			flash.now[:error] = "Provide reason for your account deletion."
			render :action => 'delete_account'
		else
			@user = User.find_by_id(current_user.id)
			@user.reason_for_deletion=params[:user][:reason_for_deletion].strip
			@user.is_deleted=true
			@user.activated_at=Time.now
			#@user.update_attributes(:reason_for_deletion=>params[:user][:reason_for_deletion].strip,:is_deleted=>true)
			@user.save
			flash.now[:notice]="Your account deleted successfully."
			redirect_to logout_path
		end
	end
	
	def change_password
    @user = User.find_by_id(current_user.id)
		@u_featured_vendors =  !@user.preference.featured_vendors.nil? ? @user.preference.featured_vendors.split(",") : []
		@u_vendors =  !@user.preference.vendors.nil? ? @user.preference.vendors.split(",") : []
		@u_colors =  !@user.preference.colors.nil? ? @user.preference.colors.split(",") : []
		@u_price_ranges = !@user.preference.price_ranges.nil? ? @user.preference.price_ranges.split(",") : []
		@u_brands = !@user.preference.brands.nil? ? @user.preference.brands.split(",") : []
		@u_locations = !@user.preference.locations.nil? ? @user.preference.locations.split(",") : []
		return unless request.post?
		unless params[:old_password].blank? || params[:password].blank? || params[:password_confirmation].blank?
		  if User.authenticate(@user.email, params[:old_password])
				if params[:password].length > 5
					if params[:password] == params[:password_confirmation]
						if @user.update_attributes(:password=>params[:password], :password_confirmation=>params[:password_confirmation])
							flash[:password_notice] = "Password is successfully reseted"
						end
					else
						flash.now[:passsword_error] = "Mismatch in Password and Confirmation Password."
					end 
				else
					flash.now[:passsword_error] = "Password Must have at least 6 characters."
				end	
			else
				flash.now[:passsword_error] = "Your current password is incorrect."
      end				
		else
			flash.now[:passsword_error]="Required field cannot be left blank"	
		end	
     render :action => 'edit'
	end	
  
  def activate
    logout_keeping_session!
    user = User.find_by_activation_code(params[:activation_code]) unless params[:activation_code].blank?
    case
    when (!params[:activation_code].blank?) && user && !user.active?
      user.activate!
      flash[:notice] = "Signup complete! Please sign in to continue."
      redirect_to '/login'
    when params[:activation_code].blank?
      flash[:error] = "The activation code was missing.  Please follow the URL from your email."
      redirect_back_or_default('/')
    else 
      flash[:error]  = "We couldn't find a user with that activation code -- check your email? Or maybe you've already activated -- try signing in."
      redirect_back_or_default('/')
    end
  end
  
  def forgot
    return unless request.post?
      unless (params[:email] && params[:email].blank?)
            if params[:email].match(/^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/)
                if @user =User.find_by_email(params[:email])
                    @user.forgot_password
                    @user.save!
                    UserMailer.deliver_forgot_password(@user) if @user.recently_forgot_password?
                    redirect_to login_path
                    flash[:notice] = "Password reset link has been sent to your email address." 
                    return
                else
                    flash.now[:email_error] = "Could not find a user with that Email." 
                  end	
           else
             flash.now[:email_error] = "Email address entered is invalid." 
           end
      else
        flash.now[:email_error]="Please enter your email address."
     end	 
      
    end
    
    def reset_password
			@user = User.find_by_password_reset_code(params[:id])
			unless @user.nil?
				return unless request.post?	
				unless params[:password].blank? || params[:password_confirmation].blank?
					if params[:password] == params[:password_confirmation]
            @user.password=params[:password]
            @user.password_confirmation=params[:password_confirmation]
            @user.password_reset_code=nil
            if @user.save
							flash[:notice] = "Password is successfully reseted"
              UserMailer.deliver_reset_password(@user)
							redirect_to login_path
						end
					else
						flash.now[:error] = "Mismatch in Password and Confirmation Password."
					end 
				else
					flash.now[:error]="Required field cannot be left blank"	
				end	
			else
				redirect_to login_path
				flash[:error]="Unable to use the Password Reset link more than ones."	
			end
		end
    
  def dashboard
		
	end	
	
 def favourite_gears
		@user = User.find_by_id(current_user.id)
		if params[:q].blank? && params[:sort_by].blank?
			@favourites = @user.favourites.paginate(:page=>params[:page], :per_page => 5,:order=>"created_at DESC")
		else
				if(params[:sort_by] == "Categories")
				sort_by = "categories.created_at"
			elsif(params[:sort_by] == "Color")	
				sort_by = "colors.created_at"
			elsif(params[:sort_by] == "Brand")	
				sort_by = "gears.brands.created_at"
			elsif(params[:sort_by] == "Gender")	
				sort_by = "gender"
			end	
			@favourites = @user.favourites.paginate(:all, :conditions=>["(gears.title LIKE '%%#{params[:q]}%%') or (gears.description LIKE '%%#{params[:q]}%%')"],:page=>params[:page], :per_page =>5,:include=>[:gear])
		end

end

def add_favourite
		@favourite=Favourite.new()
		@favourite.user_id = current_user.id
		@favourite.gear_id = params[:id]
		if @favourite.save
			flash[:notice] = "Successfully Saved"
		else
			flash[:error] = "Already in Favourite"
   	end		
    redirect_to favourites_path	
end	

def favourite_delete
	@favourite=Favourite.find_by_id(params[:id])
	 if @favourite
			@favourite.destroy
			respond_to do |format|
      flash[:notice] = 'Favourite was successfully deleted.'
      format.html { redirect_to(favourites_path) }
      format.xml  { head :ok }
		end
	else
			redirect_to(favourites_path)
  end
end

def delete_user_favourite_gears
	 if !params[:favourite_ids].blank?
      favourite_ids = params[:favourite_ids].split(',')
      favourite_ids.each do |favourite_id|
        favourite = Favourite.find(favourite_id)
        favourite.destroy
      end
		flash[:notice]	= "Selected favourite gear(s) deleted successfully." 
    end
    #load_email_domains
		@user = User.find_by_id(current_user.id)
		@favourites = @user.favourites.paginate(:page=>params[:page], :per_page => 5,:order=>"created_at DESC")
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @favourites }
      format.js do          
        render :update do |page|
        page.redirect_to favourites_path
        end
      end
    end
	end

def my_wishlist
	@user = User.find_by_id(current_user.id)
	if params[:q].blank? && params[:sort_by].blank?
			@wishlists = @user.wishlists.paginate(:page=>params[:page], :per_page => 5,:order=>"created_at DESC")
		else
				if(params[:sort_by] == "Categories")
				sort_by = "categories.created_at"
			elsif(params[:sort_by] == "Color")	
				sort_by = "colors.created_at"
			elsif(params[:sort_by] == "Brand")	
				sort_by = "gears.brands.created_at"
			elsif(params[:sort_by] == "Gender")	
				sort_by = "gender"
			end	
			@wishlists = @user.wishlists.paginate(:all, :conditions=>["(gears.title LIKE '%%#{params[:q]}%%') or (gears.description LIKE '%%#{params[:q]}%%')"],:page=>params[:page], :per_page =>5,:include=>[:gear])
		end
	end	
	
	def add_wishlist
		@wishlist=Wishlist.new()
		@wishlist.user_id = current_user.id
		@wishlist.gear_id = params[:id]
		if @wishlist.save
			flash[:notice] = "Successfully Saved"
		else
			flash[:error] = "Already in Wishlist"
   	end		
    redirect_to wishlists_path		
	end	

def wishlist_delete
	@wishlist=Wishlist.find_by_id(params[:id])
	 if @wishlist
			@wishlist.destroy
			respond_to do |format|
      flash[:notice] = 'Wishlist was successfully deleted.'
      format.html { redirect_to(wishlists_path) }
      format.xml  { head :ok }
		end
	else
			redirect_to(wishlists_path)
  end
end

def delete_wishlist_gears
	 if !params[:wishlist_ids].blank?
				wishlist_ids = params[:wishlist_ids].split(',')
				wishlist_ids.each do |wishlist_id|
					wishlist = Wishlist.find(wishlist_id)
					wishlist.destroy
				end
			flash[:notice]	= "Selected favourite gear(s) deleted successfully." 
			end
			#load_email_domains
			@user = User.find_by_id(current_user.id)
			@wishlists = @user.wishlists.paginate(:page=>params[:page], :per_page => 5,:order=>"created_at DESC")
			respond_to do |format|
				format.html # index.html.erb
				format.xml  { render :xml => @wishlist }
				format.js do          
					render :update do |page|
					page.redirect_to wishlists_path
					end
				end
		end
	end	
	
	def link_user_accounts
		if facebook_session
			existing_fb_user = User.find_by_fb_user(facebook_session.user)
		else
			existing_fb_user = nil
		end	
		if existing_fb_user.nil?
			User.create_from_fb_connect(facebook_session.user)
			user = User.find_by_fb_user_id(facebook_session.user.uid.to_i)
		else
			#user = User.find_by_fb_user(facebook_session.user)
			user = User.find_by_fb_user_id(facebook_session.user.id)
			#existing_fb_user.link_fb_connect(facebook_session.user.id)
			#self.current_user.link_fb_connect(facebook_session.user.id) unless self.current_user.fb_user_id == facebook_session.user.id
			#user = self.current_user
		end		
		if (user.email.nil? || user.email.blank?) || (user.confirmed_at.nil?) || (!user.confirmation_code.nil?)
			redirect_to verify_email_path(user.id)
		else
			self.current_user = user
			redirect_to user_gears_path
		end
	end
	
	def load_recently_created_gears
		@recent_gears = current_user.gears.all :limit=>5,:order=>'created_at desc'
	end
	
	def color_update
		@user = current_user
		@user.preference.update_attributes(:colors=>params[:color_ids])
		@colors = Color.find :all
		@u_colors = !@user.preference.colors.nil? ? @user.preference.colors.split(",") : []
	  render :update do |page|
			page.replace_html "tab4",:partial=>"colors" 
			page.show "update_msg_4"
		end	
	end	
	
	def featured_vendors_update
		@user = current_user
		@user.preference.update_attributes(:featured_vendors=>params[:featured_vendor_ids])
		@featured_vendors = Vendor.featured
		@u_featured_vendors = !@user.preference.featured_vendors.nil? ? @user.preference.featured_vendors.split(",") : []
	  render :update do |page|
			page.replace_html "tab2",:partial=>"featured_vendors" 
			page.show "update_msg_2"
		end	
	end	
	
	def vendors_update
		@user = current_user
		@user.preference.update_attributes(:vendors=>params[:vendor_ids])
		@vendors = Vendor.find :all
		@u_vendors = !@user.preference.vendors.nil? ? @user.preference.vendors.split(",") : []
	  render :update do |page|
			page.replace_html "tab3",:partial=>"vendors" 
			page.show "update_msg_3"
		end	
	end	
	
	def price_ranges_update
		@user = current_user
		@user.preference.update_attributes(:price_ranges=>params[:price_range_ids])
		@price_ranges=PriceRangeSetting.find(:all)
		@u_price_ranges = !@user.preference.price_ranges.nil? ? @user.preference.price_ranges.split(",") : []
	  render :update do |page|
			page.replace_html "tab5",:partial=>"price_ranges" 
			page.show "update_msg_5"
		end	
	end	
	
	def locations_update
		@user = current_user
		@user.preference.update_attributes(:locations=>params[:location_ids])
		@locations=Location.find(:all)
		@u_locations = !@user.preference.locations.nil? ? @user.preference.locations.split(",") : []
	  render :update do |page|
			page.replace_html "tab6",:partial=>"locations" 
			page.show "update_msg_6"
		end	
	end	
	
	def brands_update
		@user = current_user
		@user.preference.update_attributes(:brands=>params[:brand_ids])
		@brands=Brand.find(:all)
		@u_brands = !@user.preference.brands.nil? ? @user.preference.brands.split(",") : []
	  render :update do |page|
			page.replace_html "tab7",:partial=>"brands" 
			page.show "update_msg_7"
		end	
	end	
	
	def initialize_keys
    @api_key = FB_CONFIG[:api_key]
    @secret_key = FB_CONFIG[:secret_key]    
    @code_gen = "http://www.facebook.com/code_gen.php?v=1.0&api_key=#{@api_key}"
    @allow_system = "http://www.facebook.com/authorize.php?api_key=#{@api_key}&v=1.0&ext_perm=publish_stream "
  end
	
	def replace_credentials
		@exist_account = Network.find :first,:conditions=>['user_id = ? and network_type =?',current_user.id,'Facebook']
    @network = params[:network]
    render :update do |page|
      case params[:network]
      when 'facebook'
			  page.replace_html "message_network", ''
        page.replace_html "network_details",:partial=>'facebook'
      when 'twitter'
			  page.replace_html "message_network", ''
        page.replace_html "network_details", :partial=>"username_password"
      when ''
			  page.replace_html "message_network", ''
        page.replace_html "network_details", ''
      end      
    end
	end	
	
	def add_twitter_account
		 if (!params[:username].blank? and !params[:password].blank?)
      check_username = Network.find :all,:conditions=>["username = ? and user_id = ? and network_type = ?",params[:username],current_user.id,params[:network][:network_type]]
      if check_username.empty?
				Network.create!(:user_id=>current_user.id,:username=>params[:username],:encrypted_password=>params[:password].encrypt,:network_type=>params[:network][:network_type])
				@networks = Network.find :all
        render :update do |page|
				page.replace_html "tab8", :partial=>"networks"
				page.replace_html "message_network", "<font color='green'><center>Successfully added</center></font>"
				end
      else
				@networks = Network.find :all
        render :update do |page|
					page.replace_html "message_network", "<font color='red'><center>Oops! This username already exists.</center></font>"
					page.replace_html "network_list", :partial=>"network_list"
				end	
      end
    else
			@networks = Network.find :all
			render :update do |page|
				page.replace_html "message_network", "<font color='red'><center>Required fields must be entered.</center></font>"
				page.replace_html "network_list", :partial=>"network_list"
			end
    end
	end	
	
	def network_delete
		Network.find_by_id(params[:id]).destroy
		@networks = Network.find :all
		render :update do |page|
			page.replace_html "tab8", :partial=>"networks"
			page.replace_html "message_network", "<font color='green'><center>Network deleted Successfully</center></font>"
		end
	end	
	
	def generate_code
	end	
	
	def get_session
		user_token = params[:user_token]
    begin
      fb_session = Facebooker::Session.create(@api_key, @secret_key)
      @session_hash = fb_session.post "facebook.auth.getSession", :auth_token => user_token
      session[:s_key] = @session_hash['session_key']
      session[:uid] = @session_hash['uid']
      @user_info = fb_session.post("facebook.users.getInfo",:uids=>session[:uid],:fields=>'name')
      @info = @user_info[0]
      session[:uname] = @info['name']
      fb_network = Network.find_by_username(@session_hash['uid'])
      fb_network = fb_network ? fb_network : Network.new
      fb_network.update_attributes(:user_id=> current_user.id, :network_type=>'facebook',:username=>@session_hash['uid'], :fb_session_key=>@session_hash['session_key'], :fb_user_token=> user_token, :fb_user_name=>@info['name'])
    rescue
      flash.now[:error_notice] = "Sorry, Invalid code."
      render :action=>'generate_code'
    end
	end	
	
	def create_test_session
    begin
      fb_session = Facebooker::Session.create(@api_key, @secret_key)
      fb_session.post("facebook.stream.publish",:message=>"Your facebook account is successfully connected with Aleurier.", :session_key=>session[:s_key], :target_id=>session[:uid])
      @msg = "Your facebook account is successfully connected with Aleurier. Thanks - Aleurier Team"
    rescue
      @msg = "Your facebook account is successfully connected with Aleurier. Thanks - Aleurier Team"
    end      
  end

	def email_verification
		return unless request.post?
		if !params[:email].blank?
		email = params[:email]
		email_regex = /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/i
		if !(email.match(email_regex).nil?)
			is_user = User.exists?(params[:id])
			if is_user
			user = User.find(params[:id])
			users_email = User.find(:all).collect{|x|x.email}.compact					
					if !users_email.include?(email)
						user.email = email
						user.confirmation_code = user.make_token
						user.save
						UserMailer.deliver_send_verification_mail(user)
						flash[:notice] = "Confirmation email has been sent.Please confirm your email address by clicking on the link sent to you."
					else
						flash[:email_verify_error] = "This email is registered already.Provide another email address to be associated with your account"
					end	#if include?(email)
			else
				flash[:email_verify_error] = "There is no user found"
			end	#if user exists
		else
				flash[:email_verify_error] = "Please provide valid email address"
		end	#if invalid email provided
		else
			flash[:email_verify_error] = "Please provide email address"
		end	#if no email provided	
	end	

  def email_confirmation
    user = User.find_by_confirmation_code(params[:confirmation_code]) if !params[:confirmation_code].blank?
    if !user.nil?
      user.update_attributes(:confirmed_at => Time.now,:confirmation_code=>nil)
      flash[:notice] = "Your email has been confirmed.Please login to continue"
      redirect_to login_path
    else
      flash[:error] = "Invalid confirmation code"
      redirect_to confirm_email_path(params[:confirmation_code])  
    end  
  end   
	
	def add_gear_to_favorite
		if Gear.exists?(params[:gear_id])
			@gear = Gear.find(params[:gear_id])
			render :update do |page|
				if current_user.favorite_gears.include?(@gear)
					flash_message_content = "Gear already in your Favorites."
				else
					current_user.favourites.create(:gear_id => params[:gear_id])
					flash_message_content = "Gear added to your Favorites."
				end		
				page.call('visible_element', 'flash_overlay')
				page.replace_html 'flash_overlay', "<center><font color='green' size='1'>#{flash_message_content}</font></center>"
				page.visual_effect :highlight, 'flash_overlay'
				page.delay(3) do					
					page.call('toggle_display', 'flash_overlay')
				end									
			end
		end
	end	
	
	def add_gear_to_wishlist
		if Gear.exists?(params[:gear_id])
			@gear = Gear.find(params[:gear_id])
			render :update do |page|
				if current_user.wishlist_gears.include?(@gear)				
					flash_message_content = "Gear already in your Wishlist."
				else
					current_user.wishlists.create(:gear_id => params[:gear_id])
					flash_message_content = "Gear added to your Wishlist."
				end		
				page.call('visible_element', 'flash_overlay')
				page.replace_html 'flash_overlay', "<center><font color='green' size='1'>#{flash_message_content}</font></center>"
				page.visual_effect :highlight, 'flash_overlay'
				page.delay(3) do
					#page.visual_effect :fade, 'flash_overlay'
					page.call('toggle_display', 'flash_overlay')
				end									
			end					
		end
	end	

end