require 'digest/sha1'

class VendorsController < ApplicationController
	 layout "vendor"
	 include VendorAuthenticatedSystem
	 
	 before_filter :login_required,:only=>[:dashboard,:edit,:update,:show,:change_password,:payments,:pricing_plans]
	 before_filter :check_id_exist,:only=>[:edit,:delete_account]
	
	def index
		# vendor landing page
		@pricing_plans = PricingPlan.find(:all)
		redirect_to vendor_gears_path if !current_vendor.nil? && current_vendor.is_verified
	end
	 
	def check_id_exist
   v =  Vendor.find_by_id(params[:id])
   if v.nil?
		redirect_to(vendor_dashboard_path)
		end   
  end 
	 
	def new
		@vendor = Vendor.new
		respond_to do |format|
		format.html # new.html.erb
		format.xml  { render :xml => @vendor }
		end
	end	
	
	def create
		@vendor = Vendor.new(params[:vendor])
		if !params[:attach].nil?
		@attachment= Attachment.new(:uploaded_data=>params[:attach][:image_attachment]) 
	end
		@vendor.attachment = @attachment
		respond_to do |format|
      if (!@attachment.nil? ? (@attachment.valid? && @vendor.save) : (@vendor.save))
        flash[:notice] = 'Thanks for registering in Aleurier. An E-mail has been sent to your E-mail ID.Aleurier admin will contact you for further verifications'
				VendorMailer.deliver_signup_notification(@vendor)
				AdminMailer.deliver_vendor_signup_notification(@vendor)
        format.html { redirect_to(vendor_login_path) }
        format.xml  { render :xml => @vendor, :status => :created, :location => @vendor }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @vendor.errors, :status => :unprocessable_entity }
      end
    end
	end	
	
	def login
		return unless request.post?
		logout_keeping_session!
		unless params[:username].blank? || params[:password].blank?
					vendor = Vendor.authenticate(params[:username], params[:password])
					if vendor
						 if vendor.is_verified? 
							 if !vendor.is_deleted?
								self.current_vendor = vendor
									if params[:remember_me] 
									new_cookie_flag = (params[:remember_me] == "1")
									handle_remember_cookie! new_cookie_flag
									else
									cookies.delete :auth_token
									end
									flash.now[:notice] = "Logged in successfully"
									redirect_to vendor_gears_path
								else
									flash.now[:error] = "Your Account has been deleted.If you want to login contact Admin"	
								end	
						else
							flash.now[:error] = "You are not been verified by Admin"	
						end	
					else
						flash.now[:error] = "Please enter valid Username and Password !"	
					end	
		else
			flash.now[:error] = "Enter Username and Password"
		end
	end	
		
	def logout
		logout_killing_session!
		flash[:notice] = "Successfully Logged out"
		redirect_to vendor_login_path		
  end 		
	
	def dashboard
		
	end	
	
	def forgot
		return unless request.post?
		
		if params[:email].nil?
				#forgot password
				unless (params[:user_text] && params[:user_text].blank?)
						if @vendor = params[:user_text].include?('@') ? Vendor.find_by_email(params[:user_text]) : Vendor.find_by_username(params[:user_text])
							if !@vendor.is_deleted
								@vendor.forgot_password
								@vendor.save
								VendorMailer.deliver_forgot_password(@vendor) if @vendor.recently_forgot_password?
								redirect_to vendor_login_path
								flash[:notice] = "Password reset link has been sent to your email address" 
								return
						else
								flash.now[:user_text_error] = "Your account has been deleted from Aleurier" 	
						end		
						else
						 flash.now[:user_text_error] = "Could not find a user with that Email/Username" 
						end	
				else
				 flash.now[:user_text_error]="Required field cannot be left blank"
				end		 
		end
		
		if params[:user_text].nil?
				#forgot username
				 unless (params[:email] && params[:email].blank?)
				if @vedor = Vendor.find_by_email(params[:email]) 
					if !@vedor.is_deleted
						@vedor.forgot_username
						@vedor.save
						VendorMailer.deliver_forgot_username(@vedor) if @vedor.recently_forgot_username?
						redirect_to vendor_login_path
						flash[:notice] = "Username reset link has been sent to your email address" 
					else
						flash[:email_error] = "Your account has been deleted from Aleurier" 
					end	
				else
					flash.now[:email_error] = "Could not find a vendor with that email address"
					end				
			else
				flash.now[:email_error]="Enter your email"
			end
		end
		 
	end	
	
		def reset_password
			@vendor = Vendor.find_by_password_reset_code(params[:id])
			unless @vendor.nil?
				return unless request.post?	
				unless params[:password].blank? || params[:password_confirmation].blank?
					if params[:password] == params[:password_confirmation]
						if @vendor.update_attributes(:password=>params[:password], :password_confirmation=>params[:password_confirmation], :password_reset_code=> "NULL")
							flash[:notice] = "Password is successfully reseted"
							VendorMailer.deliver_reset_password(@vendor)
							redirect_to vendor_login_path
						end
					else
						flash.now[:error] = "Mismatch in Password and Confirmation Password."
					end 
				else
					flash.now[:error]="Required field cannot be left blank"	
				end	
			else
				redirect_to vendor_login_path
				flash[:error]="Unable to use the Password Reset link more than ones."	
			end
		end
		
			def reset_username
			@vendor = Vendor.find_by_username_reset_code(params[:id])
			unless @vendor.nil?
				return unless request.post?	
				unless params[:username].blank? 
						if @vendor.update_attributes(:username=>params[:username], :username_reset_code=> "NULL")
							flash[:notice] = "Username is successfully reseted"
							VendorMailer.deliver_reset_username(@vendor)
							redirect_to vendor_login_path
						end
				else
					flash.now[:error]="Required field cannot be left blank"	
				end	
			else
				redirect_to vendor_login_path
				flash[:error]="Unable to use the Password Reset link more than ones."	
			end
		end
		
	def  show
		
	end		
	
	def  edit
  	@vendor = Vendor.find_by_id(params[:id])
		if current_vendor.id != @vendor.id
			redirect_to vendor_dashboard_path
		end	
	end	
	
	def update
		@vendor = Vendor.find_by_id(params[:id])
		if !params[:attach].nil?
		@attachment= Attachment.new(:uploaded_data=>params[:attach][:image_attachment]) 
		@vendor.attachment = @attachment
		end
		if @vendor.update_attributes(params[:vendor])
			flash[:notice] = "Successfully Updated"
			redirect_to edit_vendor_path(@vendor.id)
		else
			render :action=>'edit'
    end			
	end	
	
	def change_password
		return unless request.post?
		unless params[:old_password].blank? || params[:password].blank? || params[:password_confirmation].blank?
		  if Vendor.authenticate(current_vendor.username, params[:old_password])
				if params[:password].length > 5
					if params[:password] == params[:password_confirmation]
						if current_vendor.update_attributes(:password=>params[:password], :password_confirmation=>params[:password_confirmation])
							flash[:notice] = "Password is successfully reseted"
						end
					else
						flash.now[:error] = "Mismatch in Password and Confirmation Password."
					end 
				else
					flash.now[:error] = "Password Must have at least 6 characters."
				end	
			else
				flash.now[:error] = "Your current password is incorrect."
      end				
		else
			flash.now[:error]="Required field cannot be left blank."	
		end	
	end	
	
	def delete_account
		@vendor = Vendor.find_by_id(params[:id])
		if current_vendor.id != @vendor.id
			redirect_to vendor_dashboard_path
		end	
	end
	
	def account_delete
		@vendor = Vendor.find_by_id(params[:id])
		@vendor.update_attributes(:is_deleted=>true)
		logout_killing_session!
		$account_deleted = true		
		redirect_to vendor_login_path
	end	
	
	def pricing_plans
		#~ puts params.inspect
		@pricing_plans = PricingPlan.find(:all)
	end
	
	def change_plan
		if PricingPlan.exists?(params[:id]) && plan_already_exists?(params[:id])
			@current_plan = current_vendor.subscription_plan
			@choosed_plan = PricingPlan.find(params[:id])
			@cc_detail = !current_vendor.vendor_cc_detail.nil? ? current_vendor.vendor_cc_detail : VendorCcDetail.new
			@updated_credit_card = current_vendor.has_updated_credit_card_info if !@cc_detail.new_record?
			
			basic_plan = PricingPlan.find(:first)
			
			@has_upgrade = (@current_plan.id < @choosed_plan.id) ? true : false
			
			@has_downgrade_to_basic_plan = (basic_plan.id == @choosed_plan.id) ? true : false
			
		else
			redirect_to :controller => 'vendors', :action => 'pricing_plans'
		end
	end
	
	#Not to be used - kept for reference.Method called,if credit card detail is already been provided by vendor and only confirming the credit card details for upgrading to new plan.	
	def upgrade_plan1
		redirect_to :action => 'pricing_plans' if request.get?
		if PricingPlan.exists?(params[:plan_id])
			@choosed_plan = PricingPlan.find(params[:plan_id])
			@current_plan = current_vendor.pricing_plan
			@subscription = current_vendor.subscriptions.new
			@cc_detail = current_vendor.vendor_cc_details.last			
			amt = (@choosed_plan.initial_fee)*100			
			assign_credit_card			
			@response = creditcard_gateway.purchase(amt, @card, purchase_options)
			puts @response.inspect
			if @response.success?
				credit_card_success				
				find_next_renewal = @choosed_plan.free_for + 1			
				update_billing_end_date(find_next_renewal)
				@subscription.update_attributes(:pricing_plan_id=>@choosed_plan.id,:prev_pricing_plan_id=>@current_plan.id,:billing_starting_date=>Date.today,:next_renewal_at=>Time.now.advance(:months =>find_next_renewal))			
				current_vendor.update_pricing_plan(params[:plan_id])
				update_more_payment_details(@subscription,@cc_detail)				
				flash[:notice] = 'Plan was successfully upgraded.'
				redirect_to :controller => 'vendors', :action => 'pricing_plans'
			else
				flash[:error] = 'Provide Valid Payment details'
				redirect_to :controller => 'vendors', :action => 'pricing_plans'
			end	
		end		
	end
	
	#Method called,if credit card detail is already been provided by vendor and only confirming the credit card details for upgrading to new plan.	
	def upgrade_plan
		if PricingPlan.exists?(params[:plan_id])
			@choosed_plan = PricingPlan.find(params[:plan_id])
			@current_plan = current_vendor.pricing_plan
			@current_subscription = current_vendor.subscriptions.last
			@subscription = current_vendor.subscriptions.new
			@cc_detail = current_vendor.vendor_cc_detail
			basic_plan = PricingPlan.find(:first)
			
			is_upgrade = (@current_plan.id < @choosed_plan.id) ? true : false
			
			is_downgrade_to_basic_plan = (basic_plan.id == @choosed_plan.id) ? true : false
			
			if is_downgrade_to_basic_plan
				@current_subscription.update_attributes(:billing_ending_date =>@current_subscription.next_renewal_at)
				current_vendor.update_pricing_plan(params[:plan_id])
				flash[:notice] = 'Plan was successfully changed.'
				redirect_to :controller => 'vendors', :action => 'pricing_plans'
				return
			end	
			
			if is_upgrade #flow for upgrading to higher plans			
				initial_pay = @choosed_plan.initial_fee - current_vendor.pricing_plan.initial_fee
				
				options = {
				:name => current_vendor.contact_person,
				:profile_id => @cc_detail.recurring_profile_id,
				:email => current_vendor.email,
				:starting_at => @current_subscription.next_renewal_at,
				:periodicity => :monthly,
				:comment => "Upgrading to #{@choosed_plan.name}",
				:billing_address => current_vendor.address,
				:initial_payment =>initial_pay*100
				}
		  else
				options = {
				:name => current_vendor.contact_person,
				:profile_id => @cc_detail.recurring_profile_id,
				:email => current_vendor.email,
				:starting_at => @current_subscription.next_renewal_at,
				:periodicity => :monthly,
				:comment => "Upgrading to #{@choosed_plan.name}",
				:billing_address => current_vendor.address
				}
		  end	
				recurring_amt = (@choosed_plan.monthly_fee)*100									
				
				recurring_response = creditcard_gateway.update_recurring(recurring_amt, '', options)			
				
				if recurring_response.success?
					find_next_renewal = @choosed_plan.free_for + 1			
					update_billing_end_date(find_next_renewal)
					@subscription.update_attributes(:pricing_plan_id=>@choosed_plan.id,:prev_pricing_plan_id=>@current_plan.id,:billing_starting_date=>Date.today,:next_renewal_at=>Time.now.advance(:months =>find_next_renewal))			
					current_vendor.update_pricing_plan(params[:plan_id])
					flash[:notice] = 'Plan was successfully changed.'
					redirect_to :controller => 'vendors', :action => 'pricing_plans'
				else
					flash[:error] = 'Provide Valid Payment details'
					redirect_to :controller => 'vendors', :action => 'pricing_plans'
				end
		end			
	end	
	
	#Method called for validating the credit card details provided by vendor and also for upgrading to new plan.
	def update_credit_card
		@current_plan = current_vendor.pricing_plan
		@choosed_plan = PricingPlan.find(params[:new_plan_id])		
		@subscription = current_vendor.subscriptions.new
		@cc_detail = VendorCcDetail.new
		
		find_next_renewal = @choosed_plan.free_for + 1
		
		billing_starting_from = Time.now.advance(:months =>find_next_renewal)
		billing_starting_at = (Time.now.advance(:months =>find_next_renewal)).strftime("%Y-%m-%dT00:00:00")
		
		card ||= ActiveMerchant::Billing::CreditCard.new(
    :number => params[:cc_detail][:cc_last_4digit],
    :verification_value => params[:cc_detail][:ccv_number],
    :month => params[:date][:month],
    :year => params[:date][:year],
		:first_name =>current_vendor.contact_person, #Have to find some other solution for filling this firstname and last name.This is temporarily done.
		:last_name =>current_vendor.contact_person
		)	
		
		options = {
		:name => current_vendor.contact_person,
		:email => current_vendor.email,
		:starting_at => billing_starting_at,
		:periodicity => :monthly,
		:comment => 'Credit Card details updating',
		:billing_address => current_vendor.address,
		:initial_payment =>(@choosed_plan.initial_fee)*100
		}
		
		recurring_amt = (@choosed_plan.monthly_fee)*100
		
		if card.valid?			
			recurring_response = creditcard_gateway.recurring(recurring_amt, card, options)
			if !recurring_response.params['profile_id'].nil?
				recurring_response_profile_id = recurring_response.params['profile_id']
 				@cc_detail.update_attributes(:recurring_profile_id=>recurring_response_profile_id,:vendor_id=>current_vendor.id,:cc_last_4digit=>(params[:cc_detail][:cc_last_4digit])[-4..-1],:exp_year=>params[:date][:year],:exp_month=>params[:date][:month],:ccv_number=>params[:cc_detail][:ccv_number],:card_type=>card.type)								
				update_billing_end_date(find_next_renewal)			
				@subscription.update_attributes(:pricing_plan_id=>@choosed_plan.id,:prev_pricing_plan_id=>@current_plan.id,:billing_starting_date=>Date.today,:next_renewal_at=>billing_starting_from)			
				current_vendor.update_pricing_plan(params[:new_plan_id])
				flash[:notice] = 'Your plan was successfully updated.'
				redirect_to :controller => 'vendors', :action => 'pricing_plans'			
			else
				flash[:error] = "Provide valid details"
				render :action => 'change_plan', :id => params[:new_plan_id]
			end	
		else
			flash[:error] = "Provide Valid Card details"
			render :action => 'change_plan', :id => params[:new_plan_id]
		end		
	end	
	
	def update_billing_end_date(end_date_value)
		prev_subscription = current_vendor.subscriptions.find(:last)
		prev_subscription.update_attributes(:billing_ending_date=>Time.now.advance(:months =>end_date_value),:next_renewal_at=>nil) if !prev_subscription.nil?
	end	
	
	def update_credit_card1
		@current_plan = current_vendor.pricing_plan
		@choosed_plan = PricingPlan.find(params[:new_plan_id])
		@updated_credit_card = current_vendor.has_updated_credit_card_info
		@subscription = current_vendor.subscription
		@status, @error_type = check_input_parameters(params)
		if @status	# save subscription
			@subscription.update_attributes(:cc_last_4digit => params[:subscription][:cc_last_4digit].last(4), :ccv_number => params[:subscription][:ccv_number], :exp_month => params[:date][:month], :exp_year => params[:date][:year], :card_type => params[:subscription][:card_type], :next_renewal_at => Time.now)			
		end
		if @status
			current_vendor.update_pricing_plan(params[:new_plan_id])
			flash[:notice] = 'Plan was successfully updated.'
			redirect_to :controller => 'vendors', :action => 'pricing_plans'
		else
			render :action => 'change_plan', :id => params[:new_plan_id]
		end		
	end
	
	def link_vendor_accounts
		current_user = nil
		if current_vendor.nil?
				#register with fb
				Vendor.create_from_fb_connect(facebook_session.user)
				flash[:notice] = 'Thanks for registering in Aleurier.Aleurier admin will contact you for further verifications'
				redirect_to vendor_login_path
		else
				#connect accounts				
				if !current_vendor.is_verified
					flash[:notice] = 'Your account has not been verified by Admin'			
					redirect_to vendor_login_path
				else
					current_vendor.link_fb_connect(facebook_session.user.id) unless self.current_vendor.fb_user_id == facebook_session.user.id					
					if current_vendor.email.blank?
						flash[:notice] = 'Please fill in your email detail for further notifications.Update your profile details as a first step'
						redirect_to edit_vendor_path(current_vendor.id)
					else
						redirect_to vendor_gears_path
					end	
				end	#verified condn
		end #current vendor.nil?
end
	
	#To do - pending
	def payments
		@payments = current_vendor.payments
		@recent_gears = current_vendor.gears.all :limit=>5,:order=>'created_at desc'
	end	
	
	def purchase_options
    {
      :ip =>  request.remote_ip,
      :billing_address => {
        :name     => current_vendor.contact_person,
        :address1 =>current_vendor.address,
        #:city     => params[:city],
        #:state    =>Carmen::state_code(params[:state], Carmen::country_code(params[:country])),
        #:country  => Carmen::country_code(params[:country]),
        #:zip      => params[:zip]
      }
    }
  end	
	
	def credit_card_success		
		@payment=Payment.new
    @payment.vendor_id=current_vendor.id
		@payment.transaction_id=@response.params["transaction_id"]
		@payment.amount = @response.params["amount"].to_f		
    @payment.responses=@response
    @payment.save!   	
  end	
	
	def update_more_payment_details(subscription,cc_detail)
	@payment.subscription_id = subscription.id
	@payment.pricing_plan_id = subscription.pricing_plan_id
	@payment.transaction_type = cc_detail.card_type
	@payment.credit_card_mask = cc_detail.cc_last_4digit
	@payment.expiration_month = cc_detail.exp_month
	@payment.expiration_year = cc_detail.exp_year 
	@payment.description = "Initial payment for plan #{@choosed_plan.name}"
	@payment.save
	end	

	def ipn_callback
	 fn = File.open(RAILS_ROOT + "/public/ipn.txt",'a')
	 fn.write("#{params.inspect} PARAMS \n") 
	 fn.write("OVER \n") 
	 fn.close
	 render :nothing=>true
	end	

end
