module Admin::ArtistsHelper
end
