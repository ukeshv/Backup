module Admin::ColorsHelper
end
