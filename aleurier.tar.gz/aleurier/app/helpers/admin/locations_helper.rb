module Admin::LocationsHelper
end
