module Admin::PriceRangeSettingsHelper
end
