module Admin::VendorsHelper
end
