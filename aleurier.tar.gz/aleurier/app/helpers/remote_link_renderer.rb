class RemoteLinkRenderer < WillPaginate::LinkRenderer

  def to_html
    links = @options[:page_links] ? windowed_links : []
    
    prev_class = @collection.previous_page.nil? ? 'previous-off' : 'previous'
    next_class = @collection.next_page.nil? ? 'next-off' : 'next'
    first_class = (current_page==1) ? 'first-off' : 'first'
    last_class = (current_page == @collection.total_pages) ? 'last-off' : 'last'
    #~ last_class = @collection.previous_page.nil? ? 'previous-off' : 'previous'
    
    links.unshift(page_link_or_span(@collection.previous_page, prev_class, @options[:previous_label]))
    links.push(page_link_or_span(@collection.next_page, next_class, @options[:next_label]))
    
    links.unshift(page_link_or_span(1, first_class, '&laquo; First'))
    links.push(page_link_or_span(@collection.total_pages, last_class, 'Last &raquo;'))

    html = links.join(@options[:separator])
    @options[:container] ? @template.content_tag(:ul, html, html_attributes) : html
  end

 def prepare(collection, options, template)    
   @remote = options.delete(:remote) || {}
   super
 end
 
protected
 #~ def page_link(page, text, attributes = {})
   #~ @template.link_to_remote(text, {:url => url_for(page), :method => :get}.merge(@remote))
   #~ #replace :method => :post if you need POST action
 #~ end
 
 def windowed_links
    visible_page_numbers.map { |n| page_link_or_span(n, (n == current_page ? 'active' : nil)) }
  end

  def page_link_or_span(page, span_class, text = nil)
    text ||= page.to_s
    if page && page != current_page
      page_link(page, text, :class => span_class)
    else
      page_span(page, text, :class => span_class)
    end
  end

  def page_link(page, text, attributes = {})
    @template.content_tag(:li, @template.link_to(text, url_for(page)), attributes)
  end

  def page_span(page, text, attributes = {})
    @template.content_tag(:li, text, attributes)
  end
 
end

