module User::CubesHelper

def no_of_owner_items(cube)
	ownerd_item=0
	cube.gears.each { |gear| 
		ownerd_item=ownerd_item+1	 if gear.owner_type=="User"
	}
	return ownerd_item
end

def no_of_non_owner_items(cube)
	non_ownerd_item=0
	cube.gears.each { |gear| 
		non_ownerd_item=non_ownerd_item+1	 if gear.owner_type=="Vendor"
	}
	return non_ownerd_item
end

def count_no_of_vendors(cube)
	no_of_vendors=[]
	cube.gears.each { |gear| 
		no_of_vendors<<gear.owner_id if gear.owner_type=="Vendor"
	}
	return no_of_vendors.uniq.length
end

def count_gears_total_price(cube)
	total_price=0.0
	cube.gears.each { |gear| 
			total_price=total_price+ gear.price if gear.owner_type=="Vendor"
	}
	return  "$#{total_price}"
end

def vendors_url(cube)
	no_of_vendors_url=[]
	cube.gears.each { |gear| 
		no_of_vendors_url<<gear.url if gear.owner_type=="Vendor"
	}
	return no_of_vendors_url.uniq.join(",")
end

#To check if the result collection has valid gear or not.
def gear_status(collection, index_number)
	if collection[index_number].nil?
		return nil, false 
	else
		return collection[index_number], true
	end
end

def get_gear_and_status(category_obj)
	category_gears = category_obj.gears
	if category_gears.empty?
		return nil, false
	else
		prefered_gear = User.preferred_gears(current_user, category_obj)
		if prefered_gear.nil?
			return category_gears.first, true
		else
			return prefered_gear, true
		end		
	end	
end

def get_gear_from_array(category_obj, index_of_array, gear_id_array)
	if gear_id_array[index_of_array].nil?
		if category_obj.gears.empty?
			return nil, false
		else
			return category_obj.gears.first, true
		end
	else
		return Gear.find(gear_id_array[index_of_array].to_i), true
	end
end

def display_cube_error(cube_obj, error_field)
	return (cube_obj.errors[error_field].class == 'Array')? "#{cube_obj.errors[error_field].first} - #{cube_obj.errors[error_field].last}" : cube_obj.errors[error_field]
end

def ist_date_format(cube_obj)
	cube_obj.created_at.strftime("%d/%m/%y")
end

def vendor_gear_in_look(user,categoryId)
	gears = []
	vendorIds = user.preference.vendors.split(',')
	featuredvendorIds = user.preference.featured_vendors.split(',')
	v_ids = (vendorIds + featuredvendorIds).uniq
	gears = Gear.find(:all, :conditions=>["category_id = ? and owner_id in (?) and owner_type = ?",categoryId,v_ids,"Vendor"])
	return gears.first
	end
end