module VendorsHelper

	def display_gear_count(pricing_plan_obj)				
			return "0 - #{pricing_plan_obj.max_gear_count}" if pricing_plan_obj.id == 1
			return "26 - #{pricing_plan_obj.max_gear_count}" if pricing_plan_obj.id == 2
			return "300 - #{pricing_plan_obj.max_gear_count}" if pricing_plan_obj.id == 3
			return "1000 +" if pricing_plan_obj.id == 4
	end	
	
end

