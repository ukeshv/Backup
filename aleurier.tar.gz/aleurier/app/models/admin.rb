require 'digest/sha1'

class Admin < ActiveRecord::Base
  include Authentication
  include Authentication::ByPassword
  include Authentication::ByCookieToken

  validates_presence_of  :username
  validates_uniqueness_of  :username
  validates_format_of  :username, :with => Authentication.name_regex,  :message => Authentication.bad_name_message, :allow_nil => true
  validates_length_of  :username, :maximum => 100

  validates_presence_of  :email
  validates_length_of  :email, :within => 6..100 #r@a.wk
  validates_uniqueness_of  :email
  validates_format_of  :email, :with => Authentication.email_regex, :message => Authentication.bad_email_message

  

  # HACK HACK HACK -- how to do attr_accessible from here?
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  attr_accessible :email, :username, :password, :password_confirmation



  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  #
  # uff.  this is really an authorization, not authentication routine.  
  # We really need a Dispatch Chain here or something.
  # This will also let us return a human error message.
  #
  def self.authenticate(username, password)
    return nil if username.blank? || password.blank?
    u = find_by_username(username) # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  #~ def username=(value)
    #~ write_attribute :username, (value ? value.downcase : nil)
  #~ end

  def email=(value)
    write_attribute :email, (value ? value.downcase : nil)
  end

  protected
    


end
