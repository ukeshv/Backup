class AdminMailer < ActionMailer::Base
  layout 'email'
	def vendor_signup_notification(vendor)
    @subject = 'New Vendor Account in Aleurier'
    @recipients  = APP_CONFIG[:admin_email]
    @from  =  APP_CONFIG[:admin_email]
    @sent_on     = Time.now
    @body[:vendor] = vendor
		@content_type = "text/html"
  end
	
	def vendor_activated_notification(vendor)
    @subject = 'Vendor Active Notification'
    @recipients  = "#{vendor.email}"
    @from  =  APP_CONFIG[:admin_email]
    @sent_on     = Time.now
    @body[:vendor] = vendor
		@content_type = "text/html"
  end

end
