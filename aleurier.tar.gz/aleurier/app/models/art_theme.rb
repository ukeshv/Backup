class ArtTheme < ActiveRecord::Base
	has_many :attachments, :as => :attachable,:dependent => :destroy
	belongs_to :artist
	
	
	validates_presence_of :title, :message=>"Art Theme title can't be blank"
	validates_uniqueness_of :title,:case_sensitive => false,:message=>"Art Theme title already exsists"
	validates_length_of :title, :within => 3..20, :too_long => "Art Theme title should be maximum 20 characters", :too_short => "Art Theme title should be minimun 3 characters"
	validates_format_of :title, :with =>  /^[a-zA-Z0-9\s\-]+$/ , :message=>"Art Theme title should be alphanumeric"
	
	#validates_presence_of :heart_count, :message=>"Art Theme heart_count can't be blank"
	
		#validate :check_greater_than_zero
		
		  before_validation :strip_field
			
	def strip_field
    self.title = self.title.strip if self.title
  end
	
	def check_greater_than_zero
		unless self.heart_count.nil?
		if self.heart_count <= 0
		errors.add("heart_count", "Heart Count Should be greater than zero")
		end
	end
	end
end
