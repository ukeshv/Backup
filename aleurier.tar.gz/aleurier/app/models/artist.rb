class Artist < ActiveRecord::Base
	validates_presence_of :name, :message=>"Artist name can't be blank"
	validates_uniqueness_of :name,:case_sensitive => false,:message=>"Artist name already exsists"
	validates_length_of :name, :within => 3..20, :too_long => "Artist name should contain maximum 20 characters", :too_short => "Artist name should contain minimum 3 characters"
	validates_format_of :name, :with => /^[a-zA-Z0-9][a-zA-Z0-9\s-]+[a-zA-Z0-9]$/ , :message=>"Artist name should be alphanumeric"
	
	
	validates_presence_of :link, :message=>"Link can't be blank"
	validates_uniqueness_of :link,:case_sensitive => false,:message=>"Link name already exsists"
	validates_format_of :link, :with => /^(http|https):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(([0-9]{1,5})?\/.*)?$/ix,:message=>"Link is invalid"
	
	named_scope :newest, lambda { |no|
		{ :order => "created_at desc", :limit => no }
	}
	
	named_scope :random_record, lambda { |no|
		{	:order => "RAND()", :limit => no	}
	}
	
		has_many :attachments, :as => :attachable,:dependent => :destroy
		has_many :songs
		has_many :art_themes
		
		  before_validation :strip_field
	
	def strip_field
    self.name = self.name.strip if self.name
    self.link = self.link.strip if self.link
  end
end
