class Attachment < ActiveRecord::Base
		  belongs_to :attachable,:polymorphic=>true
		
		 #~ has_attachment :storage => :file_system,   :path_prefix => 'public/attachments',                                
				   #~ :size => 0.kilobytes..5000.kilobytes,
				   #~ :thumbnails => { :thumb => '50x50>' },
				   #~ :max_size => 5000.kilobytes,
				   #~ :content_type => [:image]
					 has_attachment :storage => :file_system,
:resize_to => '320x200>',
:thumbnails => {:thumb => [37,37],:small=>[76,76],:large=>[144,144],:larger=>[154,154],:largest=>[188,146]},
:path_prefix => 'public/attachments',
:min_size => 0.kilobytes,
:max_size => 10.megabytes,
:content_type => ['image/pjpeg','image/jpeg', 'image/jpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg','audio/basic','audio/basic','audio/mid','audio/mid','audio/mpeg','audio/x-aiff','audio/x-aiff','audio/x-aiff','audio/x-mpegurl','audio/x-pn-realaudio','audio/x-pn-realaudio','audio/wav','audio/x-wav']
#:processor => :rmagick
					 
					  validates_as_attachment
	 #after_save :save_thumbnail


	attr_accessor :should_destroy,:should_destroy1
  

	
	def save_thumbnail
	content_type = self.content_type
 if content_type.split('/')[0]=="image"	
	 
    require 'RMagick'
    @photo=self
    if @photo
      maxw =  120
      maxh =  80
      aspectratio = maxw.to_f / maxh.to_f
      pic = Magick::Image.read(RAILS_ROOT + "/public#{self.public_filename}").first
      picw = @photo.width
      pich = @photo.height
      picratio = picw.to_f / pich.to_f 
      if picratio > aspectratio then
        scaleratio = maxw.to_f / picw
      else
        scaleratio = maxh.to_f / pich
      end
      begin
        thumb = scaleratio < 1 ? pic.resize(37,37) : pic        
        small = scaleratio < 1 ? pic.resize(76,76) : pic        
        large = scaleratio < 1 ? pic.resize(144,144) : pic        
        larger = scaleratio < 1 ? pic.resize(154,154) : pic        
        largest = scaleratio < 1 ? pic.resize(188,146) : pic        
        thumb_temp_path =(RAILS_ROOT + "/public/#{self.public_filename(:thumb)}")	
        small_temp_path =(RAILS_ROOT + "/public/#{self.public_filename(:small)}")
        large_temp_path =(RAILS_ROOT + "/public/#{self.public_filename(:large)}")
        larger_temp_path =(RAILS_ROOT + "/public/#{self.public_filename(:larger)}")
        largest_temp_path =(RAILS_ROOT + "/public/#{self.public_filename(:largest)}")
        FileUtils.mkdir_p(File.dirname(thumb_temp_path))
        FileUtils.mkdir_p(File.dirname(small_temp_path))
        FileUtils.mkdir_p(File.dirname(large_temp_path))
        FileUtils.mkdir_p(File.dirname(larger_temp_path))
        FileUtils.mkdir_p(File.dirname(largest_temp_path))
        thumb.write(thumb_temp_path)
        small.write(small_temp_path)
        large.write(large_temp_path)
        larger.write(larger_temp_path)
        largest.write(largest_temp_path)
      rescue
        logger.info "Thumbnail cannot be generated"
      end
    end
  end	
end


  def crop(x1, x2, y1, y2)
    require 'RMagick'
    image_path = "#{RAILS_ROOT}/public#{self.public_filename}"
    image = Magick::Image.read(image_path).first
    width, height = x2.to_i-x1.to_i, y2.to_i-y1.to_i
    cropped = image.crop(x1.to_i, y1.to_i, width, height, true)
    cropped.write(image_path)
    self.width = width
    self.height = height
    self.size = cropped.filesize
    self.save
  end
  
end
