class Brand < ActiveRecord::Base
	
	validates_presence_of :name,:message=>"Brand name can't be blank"
	validates_uniqueness_of :name, :case_sensitive => false, :message=>"Brand name already exsists"

	validates_format_of :name, :with =>  /^[a-zA-Z0-9\s\-]+$/ , :message=>"Brand name should be alphanumeric"
	validates_length_of :name, :within => 3..20, :too_long => "Brand name should contain maximum 20 characters", :too_short => "Brand name should contain minimun 3 characters"
	
	has_many :gears
	before_validation :strip_field
			
	def strip_field
    self.name = self.name.strip if self.name
  end
end
