class Category < ActiveRecord::Base
	validates_presence_of :name, :message=>"Category name can't be blank"
	#validates_format_of :name, :with => /^[a-zA-Z0-9][a-zA-Z0-9\s]+[a-zA-Z0-9]$/, :message=>"Category name should be alphanumeric"
	validates_uniqueness_of :name,:case_sensitive => false,:message=>"Category name already exsists"
	validates_length_of :name, :within => 3..20, :too_long => "Category name should contain maximum 20 characters", :too_short => "Category name should contain minimun 3 characters"
	#~ validates_format_of :name, :with => /^[a-zA-Z0-9][a-zA-Z0-9\s-]+[a-zA-Z0-9]$/ , :message=>"Category name should be alphanumeric"
	validates_format_of :name, :with =>  /^[a-zA-Z0-9\s\-]+$/ , :message=>"Category name should be alphanumeric"

	has_many :gears
  before_validation :strip_field
	
	has_one :attachment, :as => :attachable,:dependent => :destroy
  belongs_to :attachable,:polymorphic=>true
	
	def strip_field
    self.name = self.name.strip if self.name
  end
end
