class CcDetailBackup < ActiveRecord::Base
end
