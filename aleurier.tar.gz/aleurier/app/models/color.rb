class Color < ActiveRecord::Base
	validates_presence_of :name, :message=>"Color name can't blank"
	validates_uniqueness_of :name, :case_sensitive => false,:message=>"Color name already exists"
	validates_length_of :name, :within => 3..20, :too_long => "Color name should contain maximum 20 characters", :too_short => "Color name should contain minimun 3 characters"
	#~ validates_format_of :name, :with => /^[a-zA-Z0-9][a-zA-Z0-9\s-]+[a-zA-Z0-9]$/ , :message=>"Color name should be alphanumeric"
	validates_format_of :name, :with =>  /^[a-zA-Z0-9\s\-]+$/ , :message=>"Color name should be alphanumeric"
	
	has_many :gears
  before_validation :strip_field
  	
	
	def strip_field
    self.name = self.name.strip if self.name
  end
end
