class Cube < ActiveRecord::Base
belongs_to :user
has_many :gears,:through=>:cube_gears, :order=>"cube_gears.updated_at desc"
has_many :cube_gears,:dependent => :destroy
validates_presence_of :title, :message=>"Cube look title can't blank"
validates_presence_of :description, :message=>"Cube look description can't blank"
validates_uniqueness_of :title, :case_sensitive => false,:message=>"Cube look title already exists"
validates_length_of :title, :within => 3..30, :too_long => "Cube look title should be contain maximum 30 characters", :too_short => "Cube look title should contain minimun 3 characters"
validates_length_of :description, :within => 3..140, :too_long => "Cube look description should be contain maximum 140 characters", :too_short => "Cube look description should contain minimun 3 characters"
	
	def cube_look_gears
		gears = []
		category_ids = []
		self.gears.each do |gear|
			gears << gear
			category_ids << gear.category_id
		end		
		return gears, category_ids
	end	
	
	def update_gears(modified_gear_ids, user_id)
		self.cube_gears = [] # remove all the old gears in the matrix
		gear_position = 1
		modified_gear_ids.each do |gear_id|
			self.gears << Gear.find(gear_id)
			update_gear_position(self.id, gear_id, gear_position, user_id)
			gear_position += 1
		end	
	end	
	
	def update_gear_position(cube_id, gear_id, position, user_id)
    @cube_gear = CubeGear.find(:first, :conditions => ['cube_id = ? && gear_id = ?', cube_id, gear_id])
    @cube_gear.update_attributes(:user_id => user_id, :position => position )
  end 
	
end
