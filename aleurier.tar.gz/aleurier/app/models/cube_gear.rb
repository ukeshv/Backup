class CubeGear < ActiveRecord::Base
	belongs_to :cube
	belongs_to :gear	
end
