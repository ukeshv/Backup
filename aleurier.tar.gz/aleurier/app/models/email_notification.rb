class EmailNotification < ActiveRecord::Base
	belongs_to :cube
	
	def self.sent_share_email
		@email_notifications = EmailNotification.find(:all,:conditions=>["is_sent is false"])
		if !@email_notifications.empty?
			@email_notifications.each do |email_notification|
				UserMailer.deliver_share_email(email_notification)
				email_notification.update_attributes(:is_sent=>true)
			end	
		end	
	end	
	
end
