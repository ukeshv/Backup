class Gear < ActiveRecord::Base
	attr_accessor :step
	
	validates_presence_of :title, :message=>"Please enter a title."
	validates_format_of :title, :with =>  /^[a-zA-Z0-9][a-zA-Z0-9\s\-\_\']|[ ]+[a-zA-Z0-9]$/ , :message=>"Provide only alphanumeric, and allowed special characters like space,hyphen,underscore,apostrophe."
	validates_length_of :title, :within => 5..100,:too_short => "Must have at least 5 characters"
	
	validates_presence_of :category_id, :message=>"Please select a category."
	
	validates_presence_of :gender, :message=>"Please select a gender."
	
	validates_presence_of :price,:if => Proc.new { |gear| gear.step == 1 }, :message=>"Please enter a price."
	validates_numericality_of :price,:if => Proc.new { |gear| gear.step == 1 }, :message=>"Price is invalid"
	validates_format_of :price,:with=> /^\d+(\.\d{1,2})?$/,:if => Proc.new { |gear| gear.step == 1 }, :message=>"Price is invalid"
	
	#validates_format_of :url, :with => /(^$)|(^(http|https):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(([0-9]{1,5})?\/.*)?$)/ ,:if => Proc.new { |gear| !gear.url.blank? },  :message=>"Provide valid Url"
	validates_format_of :url, :with => /^(((ht|f)tp(s?)\:\/\/)?)[w|W]{3}([-.\w]*[0-9a-zA-Z])*(:(0-9)*)*(\/?)([a-zA-Z0-9\-\.\?\,\'\/\\\+&amp;%\$#_]*)?$/ ,:if => Proc.new { |gear| !gear.url.blank? },  :message=>"Provide valid Url"
	
	validates_format_of :sku, :with =>  /^[a-zA-Z0-9][a-zA-Z0-9]|[ ]+[a-zA-Z0-9]$/ ,:if => Proc.new { |gear| !gear.sku.blank? }, :message=>"Provide only alphanumeric"
	validate :check_greater_than_zero

  has_one :attachment, :as => :attachable,:dependent => :destroy
  belongs_to :attachable,:polymorphic=>true
	
	belongs_to :owner,:polymorphic=>true
	belongs_to :category
	belongs_to :location
	belongs_to :brand
	belongs_to :color
	has_many :favourites
	has_many :wishlists
	has_many :cubes, :through=>:cube_gears
	has_many :cube_gears,:dependent => :destroy
	
	def check_greater_than_zero
		unless self.price.nil?
		if (self.step == 1 && self.price <= 0.0)
		errors.add("price", "Price Should be greater than zero")
		end
	end
	end
	
	GENDER_TYPE = [["--Gender--",""],
    [ 'Male', 'male'],
    [ 'Female', 'female']
                ].freeze
	def get_local_path
		unless self.attachment.nil?
			return (File.exists?("#{RAILS_ROOT}/public#{self.attachment.public_filename(:large)}"))? self.attachment.public_filename(:large) : '/images/item_thumb.jpg'
		end
	end	
	
	def cart_url
		self.url.include?('http://') ? self.url : 'http://'+self.url
	end	
	
	def vendor_logo_url
		default_url = "/images/brand_logo.gif"
		return default_url unless self.owner_type == 'Vendor'
		return default_url if self.owner.attachment.nil?
		return self.owner.attachment.public_filename
	end	
	
end
