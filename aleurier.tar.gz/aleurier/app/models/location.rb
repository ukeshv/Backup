class Location < ActiveRecord::Base
	validates_presence_of :name, :message=>"Location name can't be blank"
	validates_uniqueness_of :name, :case_sensitive => false, :message=>"Location name already exsists"
	validates_length_of :name, :within => 3..20, :too_long => "Location name should contain maximum 20 characters", :too_short => "Location name should contain minimun 3 characters"
	#~ validates_format_of :name, :with =>  /^[a-zA-Z0-9][a-zA-Z0-9\s-]+[a-zA-Z0-9]$/ ,:message=>"Location name should be alphanumeric"
	validates_format_of :name, :with =>  /^[a-zA-Z0-9\s\-]+$/ , :message=>"Location name should be alphanumeric"
	
	has_many :gears
	before_validation :strip_field
			
	def strip_field
    self.name = self.name.strip if self.name
  end
end
