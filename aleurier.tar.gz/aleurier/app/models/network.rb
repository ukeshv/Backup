class Network < ActiveRecord::Base
	belongs_to :user
	  NETWORK_TYPE = [["--Select--",""], [ 'Facebook', 'facebook'],  [ 'Twitter', 'twitter'] ].freeze
end
