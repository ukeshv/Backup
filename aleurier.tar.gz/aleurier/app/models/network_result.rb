require 'soap/wsdlDriver'
require 'facebooker'
class NetworkResult < ActiveRecord::Base
		
	#Validations
	belongs_to :network
	belongs_to :cube
	
	def self.update_twitter_facebook_status
		tw_statuses = NetworkResult.find(:all,:conditions=>['status = ? and networks.network_type = ?',false,"twitter"],:include=>[:network])
		tw_statuses.each do |s|
			username = !s.network.nil? ? s.network.username : nil
			password = !s.network.nil? ? s.network.encrypted_password.decrypt : nil
			if !username.nil? && !password.nil?
				client = Twitter4r::Client.new(:login =>"#{username}", :password =>"#{password}")
					if client.authenticate?(username,password)                 
						res = Twitter4r::Status.create(:text =>s.message, :client => client)
						s.update_attributes(:is_sent=>true,:status=>true,:response=>"Success")
					else
						s.update_attributes(:is_sent=>true,:status=>false,:response=>"Failure")
					end #if end
			end		
    end	#do end	
		fb_statuses = NetworkResult.find(:all,:conditions=>['status = ? and networks.network_type = ?',false,"facebook"],:include=>[:network])
		fb_statuses.each do |s|
			username = !s.network.nil? ? s.network.username : nil
			fb_session_key = !s.network.nil? ? s.network.fb_session_key : nil
			if !username.nil? && !fb_session_key.nil?
				begin
				fb_session = Facebooker::Session.create(FB_CONFIG[:api_key],FB_CONFIG[:secret_key])
				post_msg = fb_session.post("facebook.stream.publish",:message=>s.message, :session_key=>fb_session_key, :target_id=>username)
				post_msg = post_msg.gsub("_","")
				post_msg.match(/^\d+$/) ? s.update_attributes(:is_sent=>true,:status=>true,:response=>"Success") : s.update_attributes(:is_sent=>true,:status=>false,:response=>"Failure")
				rescue
				s.update_attributes(:is_sent=>true,:status=>false,:response=>"Failure")
				end #begin end
			end	
		end #do end	
  end
end
