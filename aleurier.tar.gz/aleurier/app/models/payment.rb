class Payment < ActiveRecord::Base
	belongs_to :vendor
	belongs_to :pricing_plan
end
