class Preference < ActiveRecord::Base
	belongs_to:user
	
	#~ def sample(user_preferences,gear_id)
		#~ @gear=Gear.find_by_id(gear_id)
		#~ gear_color_id=@gear.color_id
		#~ gear_location_id=@gear.location_id
	  #~ color_ids=[]
	  #~ location_ids=[]
		#~ color_ids=user_preferences.colors.split(",") 
	  #~ location_ids=user_preferences.locations.split(",")
		#~ puts  "gears #{ @gear.inspect}" 
		#~ puts  "color_id s #{color_ids.inspect}"
		#~ puts  "location_ids s #{location_ids.inspect}"
		#~ puts "gear_color_id #{gear_color_id}"
		#~ puts "gear_location_id #{gear_location_id}"
		#~ puts "color #{ color_ids.include?(gear_color_id.to_s)}"
		#~ puts "location #{ location_ids.include?(gear_location_id.to_s)}"
    		
	 #~ if color_ids.include?(gear_color_id.to_s) || location_ids.include?(gear_location_id.to_s) ||  (@gear &&  @gear.location_id.nil?)
		 #~ return true
	 #~ else
		 #~ return false
	 #~ end
	 
	#~ end
end