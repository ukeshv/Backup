class PriceRangeSetting < ActiveRecord::Base
	validates_presence_of :level, :message=>"Level can't be blank"
	validates_uniqueness_of :level, :case_sensitive => false, :message=>"Level already exsists"
	validates_length_of :level, :within => 3..20, :too_long => "Level should contain maximum 20 characters", :too_short => "Level should contain minimun 3 characters"
	#~ validates_format_of :name, :with =>  /^[a-zA-Z0-9][a-zA-Z0-9\s-]+[a-zA-Z0-9]$/ ,:message=>"Location name should be alphanumeric"
	validates_format_of :level, :with =>  /^[a-zA-Z0-9\s\-]+$/ , :message=>"Level should be alphanumeric"
	validates_presence_of :min_price, :message=>"Min Price can't be blank"
	validates_presence_of :max_price, :message=>"Max Price can't be blank"
	validates_numericality_of :min_price, :message=>"Min Price is invalid"
	validates_numericality_of :max_price, :message =>"Max Price is invalid"
	
	validate :check_max_min_value
	
		before_validation :strip_field
			
	def strip_field
    self.level = self.level.strip if self.level
  end
	
	
	def check_max_min_value
		unless self.max_price.nil? || self.min_price.nil?
	if self.max_price != 0
		if self.min_price >= self.max_price 
			errors.add("min_price", "Min Price should be less than Max price")
			errors.add("max_price", "Max Price should be greater than Min price")
		elsif self.max_price <= self.min_price 
			errors.add("max_price", "Max Price should be greater than Min price")
			errors.add("min_price", "Min Price should be less than Max price")
		end
		end	
	end	
	end 
end
