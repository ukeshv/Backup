class PricingPlan < ActiveRecord::Base
		
	has_many :vendors
	has_many :subscriptions
	has_many :payments
	
	validates_presence_of :name, :message=>"Pricing Plan name can't be blank"
	validates_uniqueness_of :name,:case_sensitive => false,:message=>"Pricing Plan name already exsists"
	validates_length_of :name, :within => 3..20, :too_long => "Pricing Plan name should contain maximum 20 characters", :too_short => "Pricing Plan name should contain minimum 3 characters"
	#validates_format_of :name, :with => /^[a-zA-Z0-9][a-zA-Z0-9\s-]+[a-zA-Z0-9]$/ , :message=>"Pricing Plan name should be alphanumeric"	
		validates_format_of :name, :with =>  /^[a-zA-Z0-9\s\-]+$/ , :message=>"Pricing Plan name should be alphanumeric"
	
	validates_numericality_of :max_gear_count, :message=>"Max Gear count should be an integer"
	validates_numericality_of :initial_fee, :message=>"Initial Fee is invalid"
	validates_format_of :initial_fee,:with=> /^\d+(\.\d{1,2})?$/, :message=>"Initial Fee is invalid"
	validates_numericality_of :monthly_fee, :message=>"Monthly Fee is invalid"
	validates_format_of :monthly_fee,:with=> /^\d+(\.\d{1,2})?$/, :message=>"Monthly Fee is invalid"	
	
	#~ validate :check_greater_than_zero
	
	before_validation :strip_field	
	
	def strip_field
    self.name = self.name.strip if self.name
  end
	
	def check_greater_than_zero
		unless self.initial_fee.nil?
		if self.initial_fee <= 0.0
		errors.add("initial_fee", "Initial Fee Should be greater than zero")
		end
	end
	unless self.monthly_fee.nil?
		if self.monthly_fee <= 0.0
			errors.add("monthly_fee", "Monthly Fee Should be greater than zero")
		end
	end
	unless self.max_gear_count.nil?
		if self.max_gear_count == 0
		errors.add("max_gear_count", "Max Gear Count Should be greater than zero")
		end
		
	end

	end
	
end
