require 'digest/sha1'

class User < ActiveRecord::Base
  include Authentication
  include Authentication::ByPassword
  include Authentication::ByCookieToken

  #~ validates_presence_of     :login
  #~ validates_length_of       :login,    :within => 3..40
  #~ validates_uniqueness_of   :login
  #~ validates_format_of       :login,    :with => Authentication.login_regex, :message => Authentication.bad_login_message
  
  validates_presence_of :email, :message=>"Please enter a email address."
  validates_uniqueness_of :email, :case_sensitive => false, :message =>"This email is registered already."
  validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/, :message =>"Please enter a valid email address."
  
 #~ validates_presence_of :password, :message=>"Please enter a password."   
 #~ validates_length_of     :password,  :within => 6..100, :message=>"Must have at least 6 characters." 
 #validates_presence_of :conformation_password, :message=>"Please enter confirmation password."
 
 validates_presence_of :firstname, :message=>"Please enter firstname."
 validates_format_of :firstname, :with =>  /^[a-zA-Z0-9]+$/ , :message=>"Provide only letters and numbers without space."
 validates_length_of :firstname, :within => 5..20,:too_short => "Must have at least 5 characters"
 validates_presence_of :gender, :message=>"Please select a gender."
 
  #validates_acceptance_of :agreement, :message => "Please accept the terms to proceed."
  
   
  #validates_format_of       :firstname,     :with => Authentication.name_regex,  :message => Authentication.bad_name_message, :allow_nil => true
  #validates_length_of       :firstname,     :maximum => 100

  #validates_presence_of     :email, 
  #validates_length_of       :email,    :within => 6..100 #r@a.wk
#  validates_format_of       :email,    :with => Authentication.email_regex, :message => Authentication.bad_email_message

  before_create :make_activation_code 
  after_create:user_preference_create,:register_user_to_fb

  has_many :gears, :as => :owner,:dependent => :destroy
  has_many :favourites
  has_many :wishlists
  has_many :cubes
  has_one:preference
  has_many :favorite_gears, :source => :gear, :foreign_key => "gear_id", :through => :favourites, :class_name => "Gear", :dependent => :destroy  
  has_many :wishlist_gears, :source => :gear, :foreign_key => 'gear_id', :through => :wishlists, :class_name => "Gear", :dependent => :destroy
  
  # HACK HACK HACK -- how to do attr_accessible from here?
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  attr_accessible :login, :email, :name, :password, :password_confirmation,:firstname,:gender,:lastname,:confirmation_code,:confirmed_at

  GENDER_TYPE = [["--Gender--",""], [ 'Male', 'male'], [ 'Female', 'female']].freeze
  
  def user_preference_create
   Preference.create(:user_id=>self.id)
  end

  # Activates the user in the database.
  def activate!
    @activated = true
    self.activated_at = Time.now.utc
    self.activation_code = nil
    save(false)
  end

  # Returns true if the user has just been activated.
  def recently_activated?
    @activated
  end

  def active?
    # the existence of an activation code means they have not activated yet
    activation_code.nil?
  end

  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  #
  # uff.  this is really an authorization, not authentication routine.  
  # We really need a Dispatch Chain here or something.
  # This will also let us return a human error message.
  #
  def self.authenticate(email, password)
    return nil if email.blank? || password.blank?
    u = find :first, :conditions => ['email = ? and activated_at IS NOT NULL', email] # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  def login=(value)
    write_attribute :login, (value ? value.downcase : nil)
  end

  def email=(value)
    write_attribute :email, (value ? value.downcase : nil)
  end
   #Password Reset for Forgot password
	def forgot_password
	@forgotten_password = true
	self.make_password_reset_code
	end

	def reset_password
	# First update the password_reset_code before setting the 
	# reset_password flag to avoid duplicate email notifications.
	update_attributes(:password_reset_code => nil)
	@reset_password = true
	end

	def recently_reset_password?
	@reset_password
	end

	def recently_forgot_password?
	@forgotten_password
  end

  # Start facebook methods

  #find the user in the database, first by the facebook user id and if that fails through the email hash
  
  def self.find_by_fb_user(fb_user)
    User.find_by_fb_user_id(fb_user.uid) || User.find_by_email_hash(fb_user.email_hashes)
  end
  
  #Take the data returned from facebook and create a new user from it.
  #We don't get the email from Facebook and because a facebooker can only login through Connect we just generate a unique login name for them.
  #If you were using username to display to people you might want to get them to select one after registering through Facebook Connect
  
  def self.create_from_fb_connect(fb_user)
    new_facebooker = User.new(:firstname => fb_user.first_name, :lastname => fb_user.last_name, :password => "", :email => "")
    new_facebooker.gender = (fb_user.sex.nil? || fb_user.sex.blank?) ? "Male" : fb_user.sex
    new_facebooker.fb_user_id = fb_user.uid.to_i
    #We need to save without validations
    new_facebooker.save(false)
    new_facebooker.register_user_to_fb
  end

  #We are going to connect this user object with a facebook id. But only ever one account.
  
  def link_fb_connect(fb_user_id)
    unless fb_user_id.nil?
      #check for existing account
      existing_fb_user = User.find_by_fb_user_id(fb_user_id)
      #unlink the existing account
      unless existing_fb_user.nil?
        existing_fb_user.fb_user_id = nil
        existing_fb_user.save(false)
      end
      #link the new one
      self.fb_user_id = fb_user_id
      save(false)
    end
  end

  #The Facebook registers user method is going to send the users email hash and our account id to Facebook
  #We need this so Facebook can find friends on our local application even if they have not connect through connect
  #We hen use the email hash in the database to later identify a user from Facebook with a local user
  
  def register_user_to_fb
    users = {:email => email, :account_id => id}
    Facebooker::User.register([users])
    self.email_hash = Facebooker::User.hash_email(email)
    save(false)
    if !self.fb_user_id.nil?
      self.activated_at = Time.now.utc
      self.activation_code = nil
      save(false)
    end
  end
  
  def facebook_user?
    return !fb_user_id.nil? && fb_user_id > 0
  end

  def cube_look_gears
    cube_look_gears = []
    category_ids = []
    Category.find(:all).each do |category|
      gear = User.preferred_gears(self,category) #.find(:first, :conditions => ['category_id = ?', category.id]) # query to be modified based on requirement - from user's preference - change it
      #gear = self.gears.find(:first, :conditions => ['category_id = ?', category.id]) # query to be modified based on requirement - from user's preference - change it
      unless gear.nil? #Analyse if this line is needed or not - Seems not required,if above query changes
        cube_look_gears << gear 
        category_ids << category.id 
      end
    end
    #If gears fetched in above query is greater than 9,get only 9 gears and their categories and leave the remaining
    if (cube_look_gears.length > 9)
      return cube_look_gears[0..8], category_ids[0..8] 
    else      
      return cube_look_gears, category_ids
    end
  end  
  
  def self.preferred_gears(u,c)
    gears = []
      
      # get preferred normal vendors or else get all the normal vendors
      if !u.preference.vendors.nil?
      vendorIds = u.preference.vendors.split(',')
      else
      vendorIds = Vendor.find(:all,:conditions=>['pricing_plans.is_featured = ? and is_verified = ?',false,true],:include=>[:pricing_plan]).collect{|x|x.id}
     end  
    
      # get preferred featured vendors or else get all the featured vendors
      if !u.preference.featured_vendors.nil?
        featuredvendorIds = u.preference.featured_vendors.split(',')
      else
        featuredvendorIds = Vendor.find(:all,:conditions=>['pricing_plans.is_featured = ? and is_verified = ?',true,true],:include=>[:pricing_plan]).collect{|x|x.id}
      end     
      
      v_ids = (vendorIds + featuredvendorIds).uniq
    gear = Gear.find(:first, :conditions=>["category_id = ? and owner_id in (?) and owner_type = ?",c.id,v_ids,"Vendor"])
    return gear
  end  
  
  def self.popup_preferred_gears(u,c)
    gears = []
      
      # get preferred normal vendors or else get all the normal vendors
      if !u.preference.vendors.nil?
      vendorIds = u.preference.vendors.split(',')
      else
      vendorIds = Vendor.find(:all,:conditions=>['pricing_plans.is_featured = ? and is_verified = ?',false,true],:include=>[:pricing_plan]).collect{|x|x.id}
     end  
    
      # get preferred featured vendors or else get all the featured vendors
      if !u.preference.featured_vendors.nil?
        featuredvendorIds = u.preference.featured_vendors.split(',')
      else
        featuredvendorIds = Vendor.find(:all,:conditions=>['pricing_plans.is_featured = ? and is_verified = ?',true,true],:include=>[:pricing_plan]).collect{|x|x.id}
      end     
      
      v_ids = (vendorIds + featuredvendorIds).uniq
    gear = Gear.find(:all, :conditions=>["category_id = ? and owner_id in (?) and owner_type = ?",c.id,v_ids,"Vendor"])
    return gear
  end  
  
  def get_preferred_color_gears(u)
    gears = []    
    if u.preference.colors.nil?
      colorIds = u.preference.colors.split(',')
    else
      colorIds = Color.find(:all).collect{|x| x.id}
    end    
  end  
  
  # End facebook methods
  
  # Overwrite password_required for facebook
  def password_required?
    new_record? ? !facebook_user? && (crypted_password.blank? || !password.blank?) : !password.blank?
  end

	def secure_digest(*args)
	   Digest::SHA1.hexdigest(args.flatten.join('--'))
  end

	def make_token
	   secure_digest(Time.now, (1..10).map{ rand.to_s })
	end

  protected
    
  def make_activation_code
        self.activation_code = self.class.make_token
  end
      
  def make_password_reset_code
	    self.password_reset_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
  end

end
