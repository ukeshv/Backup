class UserMailer < ActionMailer::Base
  layout 'email'
  def signup_notification(user)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{user.email}"
    @sent_on     = Time.now
    @body[:user] = user
    @subject    = 'Thanks for signup in Aleurier'
    @body[:url]  = "#{APP_CONFIG[:site_url]}/activate/#{user.activation_code}"
    @content_type = "text/html"
  end
  
  def activation(user)
    #setup_email(user)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{user.email}"
    @sent_on     = Time.now
    @body[:user] = user
    @subject    = 'Your account has been activated!'
    @body[:url]  =  "#{APP_CONFIG[:site_url]}"
    @content_type = "text/html"
  end
  
  def forgot_password(user)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{user.email}"
    @sent_on     = Time.now
    @body[:user] = user
    @subject    = 'Request to Reset your password'
    @body[:url]  = "#{APP_CONFIG[:site_url]}/users/reset_password/#{user.password_reset_code}" 
    @content_type = "text/html"
  end  
  
  def reset_password(user)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{user.email}"
    @sent_on     = Time.now
    @body[:user] = user
    @subject    = 'Your password reseted successfully'
    @content_type = "text/html"
  end  
  
  def share_email(email_notification)
    @from        = "#{email_notification.cube.user.email}"
    @recipients  = "#{email_notification.email}"
    @sent_on     = Time.now
    @body[:email_notification] = email_notification
    @subject    = 'Email from Aleurier'
    @content_type = "text/html"
  end  
  
  #Facebook signup doesn't return email id.So we will fetch their email address and verify them.Called in users/email_verification method
  def send_verification_mail(user)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{user.email}"
    @sent_on     = Time.now
    @body[:user] = user
    @subject    = 'Aleurier - Verify your email address'
    @body[:url]  = "#{APP_CONFIG[:site_url]}/confirm_email/#{user.confirmation_code}"
    @content_type = "text/html"
  end  
  
  protected
    def setup_email(user)
      @recipients  = "#{user.email}"
      @from        = "ADMINEMAIL"
      @subject     = "[YOURSITE] "
      @sent_on     = Time.now
      @body[:user] = user
    end
end
