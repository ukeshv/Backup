class UserPreference < ActiveRecord::Base
end
