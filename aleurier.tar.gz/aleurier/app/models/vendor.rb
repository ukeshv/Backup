require 'digest/sha1'

class Vendor < ActiveRecord::Base
  include Authentication
  include Authentication::ByPassword
  include Authentication::ByCookieToken
	
	validates_presence_of :company, :message=>"Please enter a company name."
	validates_format_of :company, :with =>  /^[a-zA-Z0-9][a-zA-Z0-9\s\.\,\-\'\"]|[ ]+[a-zA-Z0-9]$/ , :message=>"Provide only alphanumeric, and allowed special characters like comma,dash,hyphen,dot,space,apostrophe."
	validates_length_of :company, :within => 5..100,:too_short => "Must have at least 5 characters", :too_long => "Company Name should not be more than 100 characters"
	

	
	validates_presence_of :contact_person, :message=>"Please enter a contact person name."
	validates_format_of :contact_person, :with =>  /^[a-zA-Z0-9][a-zA-Z0-9\s]|[ ]+[a-zA-Z0-9]$/ , :message=>"Provide only alphanumeric, and allowed special characters like space."
	validates_length_of :contact_person, :within => 5..50,:too_short => "Must have at least 5 characters" 

	validates_presence_of :address, :message=>"Please enter address." 
	
	#validates_length_of :address, :within => 2..150,:too_long => "Maximum of 150 characters in length."

  validates_presence_of :email, :message=>"Please enter a email address."
  validates_uniqueness_of :email, :case_sensitive => false, :message =>"This email is registered already."
  validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/, :message =>"Please enter a valid email address."
  #validates_format_of :email, :with => RE_EMAIL_OK, :message =>"Please enter a valid email address."
	
	validates_presence_of :phone_number, :message=>"Please enter your phone number."
	validates_length_of :phone_number,:within => 10..15,:too_short => "Please enter a valid phone number." ,:too_long => "Please enter a valid phone number." 
	validates_format_of :phone_number,  :with => /^[0-9]/, :message =>"PhoneNumber should be digits"
	 
	
	validates_format_of :website, :with =>
        /(^$)|(^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(([0-9]{1,5})?\/.*)?$)/ ,:if => Proc.new { |vendor| !vendor.website.blank? },  :message=>"Provide valid Website"
	
	validates_presence_of :username, :message=>"Please enter a username."
		validates_format_of :username, :with =>  /^[a-zA-Z0-9]+$/ , :message=>"Provide only letters and numbers without space."
	validates_length_of :username, :within => 5..20,:too_short => "Must have at least 5 characters"
	validates_uniqueness_of :username, :case_sensitive => false, :message =>"This username is registered already."
	
 
  has_one :attachment, :as => :attachable,:dependent => :destroy
  belongs_to :attachable,:polymorphic=>true	
	has_many :gears, :as => :owner,:dependent => :destroy
	
	has_many :subscriptions
	has_many :payments
	has_one :vendor_cc_detail
	belongs_to :pricing_plan
	
	named_scope :featured, :include => :pricing_plan,:conditions => "(pricing_plans.is_featured = true and vendors.is_verified = true)" # Featured Vendor
	named_scope :limit, lambda { |num| { :limit => num } }


	after_create :register_user_to_fb, :add_basic_plan #:create_basic_subscription
	 # Activates the user in the database.
  def activate!
    @activated = true
    self.activated_at = Time.now.utc
    self.activation_code = nil
    save(false)
  end

  # Returns true if the user has just been activated.
  def recently_activated?
    @activated
  end

  def active?
    # the existence of an activation code means they have not activated yet
    activation_code.nil?
  end

  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  #
  # uff.  this is really an authorization, not authentication routine.  
  # We really need a Dispatch Chain here or something.
  # This will also let us return a human error message.
  #
  def self.authenticate(username, password)
    return nil if username.blank? || password.blank?
    u = find :first, :conditions => ['username = ?', username] # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  
  #Password Reset for Forgot password
	def forgot_password
	@forgotten_password = true
	self.make_password_reset_code
	end

	def reset_password
	# First update the password_reset_code before setting the 
	# reset_password flag to avoid duplicate email notifications.
	update_attributes(:password_reset_code => nil)
	@reset_password = true
	end

	def recently_reset_password?
	@reset_password
	end

	def recently_forgot_password?
	@forgotten_password
end

 #Password Reset for Forgot password
	def forgot_username
	@forgotten_username = true
	self.make_username_reset_code
	end

	def reset_username
	# First update the password_reset_code before setting the 
	# reset_password flag to avoid duplicate email notifications.
	update_attributes(:username_reset_code => nil)
	@reset_username = true
	end

	def recently_reset_username?
	@reset_username
	end

	def recently_forgot_username?
	@forgotten_username
  end
	
		# facebook login methods start
		#find the user in the database, first by the facebook user id and if that fails through the email hash
		
	def self.find_by_fb_user(fb_user)
		Vendor.find_by_fb_user_id(fb_user.uid) || Vendor.find_by_email_hash(fb_user.email_hashes)
	end
	
	#Take the data returned from facebook and create a new user from it.
	#We don't get the email from Facebook and because a facebooker can only login through Connect we just generate a unique login name for them.
	#If you were using username to display to people you might want to get them to select one after registering through Facebook Connect
	
	def self.create_from_fb_connect(fb_user)
		new_facebooker = Vendor.new(:username => fb_user.first_name, :company => "facebooker_#{fb_user.uid}", :password => "", :email => "",:pricing_plan_id=>1)
		new_facebooker.fb_user_id = fb_user.uid.to_i
		#We need to save without validations
		new_facebooker.save(false)
		new_facebooker.register_user_to_fb
	end

	#We are going to connect this user object with a facebook id. But only ever one account.
	
	def link_fb_connect(fb_user_id)
		unless fb_user_id.nil?
			#check for existing account
			existing_fb_user = Vendor.find_by_fb_user_id(fb_user_id)
			#unlink the existing account
			unless existing_fb_user.nil?
				existing_fb_user.fb_user_id = nil
				existing_fb_user.save(false)
			end
			#link the new one
			self.fb_user_id = fb_user_id
			save(false)
		end
	end

	#The Facebook registers user method is going to send the users email hash and our account id to Facebook
	#We need this so Facebook can find friends on our local application even if they have not connect through connect
	#We hen use the email hash in the database to later identify a user from Facebook with a local user
	
	def register_user_to_fb
		users = {:email => email, :account_id => id}
		Facebooker::User.register([users])
		self.email_hash = Facebooker::User.hash_email(email)
		save(false)
	end
	
	def facebook_user?
		return !fb_user_id.nil? && fb_user_id > 0
	end

	#facebook login methods end
	
	#Assigning newly registering vendor to basic plan
	def add_basic_plan
		basic_plan = PricingPlan.find(:first)
		self.pricing_plan_id = basic_plan.id
		self.save
	end	
	
	def create_basic_subscription	# create subscription for vendor with basic plan id.
		Subscription.create(:vendor_id => self.id, :pricing_plan_id => 1)
		self.pricing_plan_id = 1
		self.save
	end
	
	def current_plan
		self.pricing_plan.name
	end
	
	def current_plan_id
		self.pricing_plan_id
	end
	
	def subscription_plan
		PricingPlan.find(self.pricing_plan_id)
	end
	
	def has_updated_credit_card_info
		cc_detail = self.vendor_cc_detail
		return ((cc_detail.cc_last_4digit.nil?) || (cc_detail.cc_last_4digit == ''))? false : true
	end	
	
	def update_pricing_plan(new_plan_id)
		self.update_attributes(:pricing_plan_id => new_plan_id)
	end	
	
  protected
    
    def make_activation_code
        self.activation_code = self.class.make_token
    end
    
     #Password Reset for Forgot password
	  def make_password_reset_code
	    self.password_reset_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
    end
		
		def make_username_reset_code
	    self.username_reset_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
    end

end
