class VendorCcDetail < ActiveRecord::Base
	
#Have to write validations for this model fields
belongs_to :vendor

end
