class VendorMailer < ActionMailer::Base
  layout 'email'
    def signup_notification(vendor)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{vendor.email}"
    @sent_on     = Time.now
    @body[:vendor] = vendor
    @subject    = 'Thanks for signup in Aleurier'  
    @content_type = "text/html"
  end
  
  def activation(vendor)
    setup_email(vendor)
    @subject    += 'Your account has been activated!'
    @body[:url]  = "http://YOURSITE/"
    @content_type = "text/html"
  end
  
  def forgot_password(vendor)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{vendor.email}"
    @sent_on     = Time.now
    @body[:vendor] = vendor
    @subject    = 'Request to Reset your password'
    @body[:url]  = "http://localhost:3000/vendor/reset_password/#{vendor.password_reset_code}" 
    @content_type = "text/html"
  end  
  
  def reset_password(vendor)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{vendor.email}"
    @sent_on     = Time.now
    @body[:vendor] = vendor
    @subject    = 'Your password reseted successfully'
    @content_type = "text/html"
  end  
  
  def forgot_username(vendor)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{vendor.email}"
    @sent_on     = Time.now
    @body[:vendor] = vendor
    @subject    = 'Request to Reset your username'
    @body[:url]  = "#{APP_CONFIG[:site_url]}/vendor/reset_username/#{vendor.username_reset_code}" 
    @content_type = "text/html"
  end  
  
  def reset_username(vendor)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{vendor.email}"
    @sent_on     = Time.now
    @body[:vendor] = vendor
    @subject    = 'Your username reseted successfully'
    @content_type = "text/html"
  end
  
   def share_with_friends(email,msg,user_name)
    @from        = APP_CONFIG[:admin_email]
    @recipients  = "#{email}"
    @sent_on     = Time.now
    @body[:msg] = msg
    @body[:user_name] = user_name
    @subject    = "Cube look shared from #{user_name}"
    @content_type = "text/html"
  end
  
  protected
    def setup_email(vendor)
      @recipients  = "#{vendor.email}"
      @from        = APP_CONFIG[:admin_email]
      @subject     = "[YOURSITE] "
      @sent_on     = Time.now
      @body[:vendor] = vendor
    end

end
