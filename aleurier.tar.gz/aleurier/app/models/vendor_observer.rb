class VendorObserver < ActiveRecord::Observer
  def after_create(vendor)
    #VendorMailer.deliver_signup_notification(vendor)
  end

  def after_save(vendor)  
    #VendorMailer.deliver_activation(vendor) if vendor.recently_activated?
		
    #VendorMailer.deliver_reset_password(vendor) if vendor.recently_reset_password?  
  end
end
