APP_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/settings.yml")[RAILS_ENV].symbolize_keys
FB_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/facebooker.yml")[RAILS_ENV].symbolize_keys