ActionController::Routing::Routes.draw do |map|
  map.admin_logout '/admin/logout', :controller => 'admins', :action => 'destroy'
  #~ map.login '/login', :controller => 'sessions', :action => 'new'
  #~ map.register '/register', :controller => 'admins', :action => 'create'
  map.admin '/admin', :controller => 'admins', :action => 'new'
  map.resources :admins,:collection=>{:dashboard=>:get}
  map.display11_edit_category_name '/test/:id', :controller => 'admin/categories', :action => 'test1'
  map.resources :users, :collection => {:link_user_accounts => :get}
  map.resources :vendors, :collection => {:link_vendor_accounts => :get}

  map.resource :session

  map.logout '/logout', :controller => 'sessions', :action => 'destroy'
  map.login '/login', :controller => 'sessions', :action => 'new'
  map.activate '/activate/:activation_code', :controller => 'users', :action => 'activate'
  map.reset_password '/users/reset_password/:id', :controller => 'users', :action => 'reset_password'
	map.forgot_password '/forgot_password', :controller => 'users', :action => 'forgot'
  map.change_password '/change_password' , :controller => 'users', :action => 'change_password'
  map.verify_email '/verify_email/:id' , :controller => 'users', :action => 'email_verification'
  map.confirm_email '/confirm_email/:confirmation_code' , :controller => 'users', :action => 'email_confirmation', :confirmation_code => nil  
  map.user_account_delete '/user_account_delete' , :controller => 'users', :action => 'delete_account'
  map.user_account_delete_reason '/user_account_delete_reason' , :controller => 'users', :action => 'account_delete_reason'
  map.profile_view_status_update '/profile_view_status_update' , :controller => 'users', :action => 'profile_view_status'
  map.favourites '/favourites' , :controller => 'users', :action => 'favourite_gears'
  map.favourite '/favourite/:id' , :controller => 'users', :action => 'favourite_delete'
  map.add_favourite 'add_favourite/:id', :controller => 'users', :action => 'add_favourite'
  map.delete_user_favourite_gears '/delete_user_favourite_gears', :controller => 'users', :action => 'delete_user_favourite_gears'
  map.root :controller => 'users', :action => 'index'
  #map.root :controller => 'vendors', :action => 'login'
  map.register '/register', :controller => 'users', :action => 'create'
  map.signup '/signup', :controller => 'users', :action => 'new'
  map.home_vendors '/vendor', :controller => 'home', :action => 'vendors'
  map.replace_credentials '/replace_credentials', :controller => 'users', :action => 'replace_credentials' 
  map.add_twitter_account '/add_twitter_account', :controller => 'users', :action => 'add_twitter_account'
  map.network_delete '/network/:id', :controller => "users", :action => "network_delete"
  map.generate_code 'generate_code', :controller =>"users", :action => "generate_code"
  map.get_session '/get_session', :controller => 'users', :action => 'get_session'
  map.create_test_session '/test_session', :controller => 'users', :action => 'create_test_session'
  
  # user  wishlist routes
  map.wishlists '/wishlist' , :controller => 'users', :action => 'my_wishlist'
  map.wishlist '/wishlist/:id' , :controller => 'users', :action => 'wishlist_delete'
  map.delete_wishlist_gears '/delete_wishlist_gears', :controller => 'users', :action => 'delete_wishlist_gears'
  map.add_wishlist 'add_wishlist/:id', :controller => 'users', :action => 'add_wishlist'
  #user wishlist routes
  # user  cubed_looks routes
  map.cubed_looks '/cubed_looks' , :controller => 'user/cubes', :action => 'index'
  #~ map.testy '/testy' , :controller => 'user/cubes', :action => 'testy'
  map.cubed_look '/cubed_look/:id' , :controller => 'user/cubes', :action => 'show'
  map.edit_cubed_look '/cubed_look/:id/edit' , :controller => 'user/cubes', :action => 'edit'
  map.cubed_look_delete '/cubed_look/delete/:id' , :controller => 'user/cubes', :action => 'destroy'
  map.cubed_look_share '/cubed_look/share/:id' , :controller => 'user/cubes', :action => 'share'
  map.cubed_look_share_cube '/cube/share/:id' , :controller => 'user/cubes', :action => 'share_cube'
  map.share_in_twitter_fb 'cube/share_twitter_fb/:id' , :controller => 'user/cubes', :action => 'share_twitter_fb'
  # user  cubed_looks routes
  map.resources :home
  map.resources :users, :collection => {:add_gear_to_favorite => :post, :add_gear_to_wishlist => :post}
  map.resources :vendors
  
  #user naming routes
  map.user_dashboard '/user/dashboard', :controller => 'users', :action => 'dashboard'
  
  #user gear naming routes
  map.user_delete_gears '/delete_user_gears', :controller => 'user/gears', :action => 'delete_user_gears'
  map.user_gear_image_modify 'user_gear/image/:id', :controller=> 'user/gears', :action => 'user_gear_image_modify' 
  map.user_crop_image 'user_crop/image/:id' , :controller=> 'user/gears', :action => 'crop' 
  
  #vendor naming routes
  map.vendor_login '/vendor/login', :controller => 'vendors', :action => 'login'
  map.vendor_logout '/vendor/logout', :controller => 'vendors', :action => 'logout'
  map.vendor_dashboard '/vendor/dashboard', :controller => 'vendors', :action => 'dashboard'
  map.vendor_forgot '/vendor/forgot', :controller => 'vendors', :action => 'forgot'
  map.vendor_reset '/vendor/reset_password/:id', :controller => 'vendors', :action => 'reset_password'
  map.vendor_reset_username '/vendor/reset_username/:id', :controller => 'vendors', :action => 'reset_username'
  map.vendor_change_password '/vendor/change_password' , :controller => 'vendors', :action => 'change_password'
  map.vendor_delete_account '/vendor/delete_account/:id' , :controller => 'vendors', :action => 'delete_account'
  map.account_delete_vendor '/vendor/account_delete/:id' , :controller => 'vendors', :action => 'account_delete'
  map.vendor_pricing_plans '/vendor/pricing_plans', :controller => 'vendors', :action => 'pricing_plans'
  map.vendor_change_plan '/vendor/change_plan/:id', :controller => 'vendors', :action => 'change_plan'
  map.vendor_payments '/vendor/payments', :controller => 'vendors', :action => 'payments'
  map.vendor_ipn_callback '/vendor/ipn_callback', :controller => 'vendors', :action => 'ipn_callback'
  
  #vendor gear naming routes
  map.delete_gears '/delete_gears', :controller => 'vendor/gears', :action => 'delete_gears'
  map.image_modification 'gear/image/:id', :controller=> 'vendor/gears', :action => 'image_modification' 
  map.crop_image 'crop/image/:id' , :controller=> 'vendor/gears', :action => 'crop' 
  map .mass_upload 'gear/mass_upload', :controller=> 'vendor/gears', :action => 'mass_upload'
  map.gears_preview 'gears_preview', :controller  => 'vendor/gears', :action =>'gears_preview'
  map.gears_final_upload 'gears_final_upload', :controller  => 'vendor/gears', :action =>'gears_final_upload'
  map.download_log 'download_log', :controller  => 'vendor/gears', :action =>'download_log'
  map.download_sample_csv 'download_sample_csv', :controller  => 'vendor/gears', :action =>'download_sample_csv'
  
  #vendor artist naming routes
  map.vendor_artists_tab '/vendor/artist/:tab', :controller => 'vendor/artists', :action => 'index'
  map.vendor_artists_list '/vendor/artist/:id/:list', :controller => 'vendor/artists', :action => 'show'
  
  map.preferences '/preferences/:type', :controller => 'user/preferences', :action => 'index'
  
  map.resources :artists, :collection => {:default_playlist_xml => :get, :load_new_playlist => :post, :heart_count => :post, :load_selected_song => :get, :below_heart_count => :post}
  
  map.artists_tab '/artist/:tab', :controller => 'artists', :action => 'index'
  map.artists_list '/artist/:id/:list', :controller => 'artists', :action => 'show'
  
  map.namespace(:vendor) do |vendor|
    vendor.resources :gears, :collection => {:display_credit_card => :get, :update_credit_card => :post}
    vendor.resources :artists
  end  
  map.gear_matrix '/gear_matrix', :controller => 'user/cubes', :action => 'matrix', :conditions => { :method => :get}
  map.edit_gear_matrix '/edit_gear_matrix/:id', :controller => 'user/cubes', :action => 'edit_matrix', :conditions => { :method => :get}
  map.add_to_closet '/add_to_closet/:id', :controller => 'user/cubes', :action => 'add_to_closet' # Add to closet in look
  map.namespace(:user) do |user|
    user.resources :gears
    user.resources :cubes, :collection => {:add_new_category => :post, :dropped_category => :post, :change_popup_gear_content => :post, :change_background_gear_content => :post}, :member => {:export_pdf => :get, :export_pdf_summary => :get}
    user.resources :preferences
  end  
  
  map.popup_matrix '/popup_matrix/:id', :controller => 'user/cubes', :action => 'popup_matrix' #PopUp Matrix Page
  map.public_view ':title_url', :controller =>'user/cubes', :action =>'public_view' # Cube Look show / Public View 
  
  map.resource :session
    map.namespace(:admin) do |admin|
      admin.resources :categories
      admin.resources :colors
      admin.resources :brands
      admin.resources :locations
      admin.resources :pricing_plans
      admin.resources :price_range_settings
      admin.resources :vendors, :member=>{:activate_vendor=>:get, :do_delete=>:get, :verify=>:get}
      admin.resources :users, :member=>{:activate_user=>:get,:deactivate_user=>:get, :do_delete=>:get, :donot_delete=>:get}
      admin.resources :artists do |artist|
        artist.resources :songs
        artist.resources :art_themes
      end
      
    end

    map.display_edit_category_name '/edit_category/:id', :controller => 'admin/categories', :action => 'edit'
    map.display_edit_color_name '/edit_color/:id', :controller => 'admin/colors', :action => 'edit'
    map.display_edit_brand_name '/edit_brand/:id', :controller => 'admin/brands', :action => 'edit'
    map.display_edit_location_name '/edit_location/:id', :controller => 'admin/locations', :action => 'edit'
  # The priority is based upon order of creation: first created -> highest priority.

  # Sample of regular route:
  #   map.connect 'products/:id', :controller => 'catalog', :action => 'view'
  # Keep in mind you can assign values other than :controller and :action

  # Sample of named route:
  #   map.purchase 'products/:id/purchase', :controller => 'catalog', :action => 'purchase'
  # This route can be invoked with purchase_url(:id => product.id)

  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   map.resources :products

  # Sample resource route with options:
  #   map.resources :products, :member => { :short => :get, :toggle => :post }, :collection => { :sold => :get }

  # Sample resource route with sub-resources:
  #   map.resources :products, :has_many => [ :comments, :sales ], :has_one => :seller
  
  # Sample resource route with more complex sub-resources
  #   map.resources :products do |products|
  #     products.resources :comments
  #     products.resources :sales, :collection => { :recent => :get }
  #   end

  # Sample resource route within a namespace:
  #   map.namespace :admin do |admin|
  #     # Directs /admin/products/* to Admin::ProductsController (app/controllers/admin/products_controller.rb)
  #     admin.resources :products
  #   end

  # You can have the root of your site routed with map.root -- just remember to delete public/index.html.
  # map.root :controller => "welcome"

  # See how all your routes lay out with "rake routes"

  # Install the default routes as the lowest priority.
  # Note: These default routes make all actions in every controller accessible via GET requests. You should
  # consider removing the them or commenting them out if you're using named routes and resources.
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
end
