class CreateUsers < ActiveRecord::Migration
  def self.up
    create_table "users", :force => true do |t|
      t.column :email,:string, :limit => 100      
      t.column :firstname,:string, :limit => 40
      t.column :lastname,:string, :limit => 40
      t.column :gender,:string, :limit => 10   
      
      t.column :crypted_password,:string, :limit => 40
      t.column :salt,:string, :limit => 40     
      t.column :password_reset_code,:string , :limit=>40      
      t.column :activation_code,:string, :limit => 40
      t.column :activated_at,:datetime
      
      t.column :is_cube_view_public,:boolean,:default=>false            
      t.column :status,:boolean,:default=>false
      t.column :is_deleted,:boolean,:default=>false      
      t.column :reason_for_deletion,:text
      t.column :deleted_at,:datetime
      
      t.column :remember_token,:string, :limit => 40
      t.column :remember_token_expires_at, :datetime
      
      t.column :created_at,:datetime
      t.column :updated_at,:datetime

    end
  end

  def self.down
    drop_table "users"
  end
end
