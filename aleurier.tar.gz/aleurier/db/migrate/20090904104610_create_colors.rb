class CreateColors < ActiveRecord::Migration
  def self.up
    create_table :colors do |t|
      t.column :name,:string, :limit => 100
      t.timestamps
    end
    Color.create!(:name=>"White")
  end

  def self.down
    drop_table :colors
  end
end
