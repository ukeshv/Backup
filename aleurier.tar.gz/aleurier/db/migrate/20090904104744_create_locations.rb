class CreateLocations < ActiveRecord::Migration
  def self.up
    create_table :locations do |t|
      t.column :name,:string, :limit => 100
      t.timestamps
    end
    Location.create!(:name=>"New York")
  end

  def self.down
    drop_table :locations
  end
end
