class CreatePricingPlans < ActiveRecord::Migration
  def self.up
    create_table :pricing_plans do |t|
       t.string :name, :limit => 100
       t.integer :max_gear_count
       t.float :initial_fee, :default=>0.0
       t.float :monthly_fee, :default=>0.0
       t.integer :free_for
       t.boolean :is_unlimited, :default=>false
       t.boolean :is_featured, :default=>false
       t.boolean :is_logo_on_cube, :default=>false
       
      t.timestamps
   end
   PricingPlan.create(:name => 'Basic', :max_gear_count => 25, :initial_fee => 0.0,:free_for=>0,:monthly_fee => 0.0, :is_unlimited => false, :is_featured => false, :is_logo_on_cube => false)
   PricingPlan.create(:name => 'Silver', :max_gear_count => 300, :initial_fee => 150,:free_for=>1,:monthly_fee => 25, :is_unlimited => false, :is_featured => false, :is_logo_on_cube => false)
   PricingPlan.create(:name => 'Gold', :max_gear_count => 1000, :initial_fee => 400,:free_for=>2,:monthly_fee => 50, :is_unlimited => false, :is_featured => true, :is_logo_on_cube => true)   
   PricingPlan.create(:name => 'Platinum', :max_gear_count => 1000, :initial_fee => 500,:free_for=>3,:monthly_fee => 100, :is_unlimited => true, :is_featured => true, :is_logo_on_cube => true)
  end

  def self.down
    drop_table :pricing_plans
  end
end
