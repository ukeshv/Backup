class CreatePriceRangeSettings < ActiveRecord::Migration
  def self.up
    create_table :price_range_settings do |t|
      t.string :level, :limit=>10
      t.integer :min_price, :default=>0
      t.integer :max_price, :default=>0

      t.timestamps
    end
  end

  def self.down
    drop_table :price_range_settings
  end
end
