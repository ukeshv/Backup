class CreateVendors < ActiveRecord::Migration
  def self.up
    create_table :vendors do |t|
      t.integer :pricing_plan_id
      t.string :company, :limit=>100
      t.string :contact_person, :limit=>40
      
      t.text :address
      t.string :email, :limit=>100
      t.string :phone_number, :limit=>20
      t.string :website
      
      t.string :username, :limit=>40
      t.string :username_reset_code, :limit=>40
      
      t.string :crypted_password, :limit=>40
      t.string :salt, :limit=>40
      t.string :password_reset_code, :limit=>40
      
      
      t.boolean :status
      t.boolean :is_verified, :default=>false
      t.boolean :is_deleted, :default=>false
      
      t.string :remember_token, :limit=>40
      t.datetime :remember_token_expires_at
      
      t.timestamps
    end
  end

  def self.down
    drop_table :vendors
  end
end
