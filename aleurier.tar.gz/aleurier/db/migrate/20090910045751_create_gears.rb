class CreateGears < ActiveRecord::Migration
  def self.up
    create_table :gears do |t|
      t.integer :owner_id
      t.string :owner_type, :limit=>20
      t.string :title, :limit=>50

      t.integer :category_id
      t.integer :brand_id
      t.integer :location_id
      t.integer :color_id
      
      t.string :size
      t.string :sku
      t.string :gender
      t.text :description
      t.string :url
      
      t.float :price, :default=>0.0
      t.timestamps
    end
  end

  def self.down
    drop_table :gears
  end
end
