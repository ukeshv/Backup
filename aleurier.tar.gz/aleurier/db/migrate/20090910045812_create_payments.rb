class CreatePayments < ActiveRecord::Migration
  def self.up
    create_table :payments do |t|
      t.integer :vendor_id
      t.integer :pricing_plan_id
      t.integer :subscription_id
      t.float :amount, :default=>0.0
      t.string :transaction_id
      t.string :transaction_type
      t.string :credit_card_mask, :limit => 4 
      t.string :expiration_month, :limit => 2
      t.string :expiration_year,  :limit => 4  
      t.datetime :start_date
      t.datetime :end_date
      t.text :responses
      t.text :description

      t.timestamps
    end
  end

  def self.down
    drop_table :payments
  end
end
