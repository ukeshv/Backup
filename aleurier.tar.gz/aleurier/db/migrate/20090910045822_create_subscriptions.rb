class CreateSubscriptions < ActiveRecord::Migration
  def self.up
    create_table :subscriptions do |t|
      t.integer :vendor_id
      t.integer :pricing_plan_id
      t.integer :prev_pricing_plan_id
      t.datetime :next_renewal_at
      t.datetime :billing_starting_date
      t.datetime :billing_ending_date

      t.timestamps
    end
  end

  def self.down
    drop_table :subscriptions
  end
end
