class CreateNetworkResults < ActiveRecord::Migration
  def self.up
    create_table :network_results do |t|
      t.integer :user_id
      t.text :message
      t.boolean :status
      t.boolean :is_sent, :default=>false
      t.string :response
      t.integer :network_id

      t.timestamps
    end
  end

  def self.down
    drop_table :network_results
  end
end
