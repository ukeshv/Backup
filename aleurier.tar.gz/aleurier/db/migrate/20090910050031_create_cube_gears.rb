class CreateCubeGears < ActiveRecord::Migration
  def self.up
    create_table :cube_gears do |t|
      t.integer :cube_id
      t.integer :gear_id
      t.integer :user_id, :position      
      t.timestamps
    end
  end

  def self.down
    drop_table :cube_gears
  end
end
