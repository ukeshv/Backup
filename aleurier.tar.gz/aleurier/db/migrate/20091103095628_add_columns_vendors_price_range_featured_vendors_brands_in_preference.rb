class AddColumnsVendorsPriceRangeFeaturedVendorsBrandsInPreference < ActiveRecord::Migration
 def self.up
    add_column :preferences, :brands, :string
    add_column :preferences, :vendors, :string
    add_column :preferences, :featured_vendors, :string
    add_column :preferences, :price_ranges, :string
  end

  def self.down
    remove_column :preferences, :brands
    remove_column :preferences, :vendors
    remove_column :preferences, :Featured_Vendors
    remove_column :preferences, :price_ranges
  end
end
