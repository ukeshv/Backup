class AddVendorsFb < ActiveRecord::Migration
  def self.up
  add_column :vendors, :fb_user_id, :integer
  add_column :vendors, :email_hash, :string
  #if mysql
  execute("alter table users modify fb_user_id bigint")
end

def self.down
  remove_column :vendors, :fb_user_id
  remove_column :vendors, :email_hash
end

end
