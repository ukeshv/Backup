class AddUserFields < ActiveRecord::Migration
  def self.up
    add_column :users,:confirmation_code,:string,:limit=>40
    add_column :users,:confirmed_at,:datetime
    add_column :users,:signup_type,:string
  end

  def self.down
    remove_column :users,:confirmation_code
    remove_column :users,:confirmed_at
    remove_column :users,:signup_type
  end
end
