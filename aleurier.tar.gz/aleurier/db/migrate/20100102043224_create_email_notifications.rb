class CreateEmailNotifications < ActiveRecord::Migration
  def self.up
    create_table :email_notifications do |t|
      t.column :cube_id, :integer
      t.column :email,:string, :limit => 100
      t.column :subject,:string, :limit => 100
      t.column :message,:text
      t.column :is_sent, :boolean,:default=>false
      t.timestamps
    end
    add_column :network_results, :cube_id, :integer
  end

  def self.down
    drop_table :email_notifications
    remove_column :network_results, :cube_id
  end
end
