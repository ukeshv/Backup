class CreateVendorCcDetails < ActiveRecord::Migration
  def self.up
    create_table :vendor_cc_details do |t|
       t.integer :vendor_id
       t.string :cc_last_4digit, :limit => 4 
       t.string :exp_year,  :limit => 4  
       t.string :exp_month, :limit => 2
       t.string :card_type
       t.string :ccv_number
       t.string :recurring_profile_id

      t.timestamps
    end
  end

  def self.down
    drop_table :vendor_cc_details
  end
end
