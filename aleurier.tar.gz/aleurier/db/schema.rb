# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20100129093800) do

  create_table "admins", :force => true do |t|
    t.string   "username",         :limit => 100, :default => ""
    t.string   "email",            :limit => 100
    t.string   "crypted_password", :limit => 40
    t.string   "salt",             :limit => 40
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "art_themes", :force => true do |t|
    t.string   "title",       :limit => 100
    t.text     "description"
    t.integer  "artist_id"
    t.integer  "heart_count",                :default => 0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "artists", :force => true do |t|
    t.string   "name",        :limit => 100
    t.string   "link"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "attachments", :force => true do |t|
    t.integer  "attachable_id"
    t.string   "attachable_type"
    t.string   "content_type"
    t.string   "filename"
    t.integer  "size"
    t.string   "thumbnail"
    t.integer  "width"
    t.integer  "height"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "parent_id"
  end

  create_table "brands", :force => true do |t|
    t.string   "name",       :limit => 100
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "categories", :force => true do |t|
    t.string   "name",       :limit => 100
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "cc_detail_backups", :force => true do |t|
    t.integer  "vendor_id"
    t.string   "cc_last_4digit",       :limit => 4
    t.string   "exp_year",             :limit => 4
    t.string   "exp_month",            :limit => 2
    t.string   "card_type"
    t.string   "ccv_number"
    t.string   "recurring_profile_id"
    t.integer  "vendor_cc_detail_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "colors", :force => true do |t|
    t.string   "name",       :limit => 100
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "cube_gears", :force => true do |t|
    t.integer  "cube_id"
    t.integer  "gear_id"
    t.integer  "user_id"
    t.integer  "position"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "cubes", :force => true do |t|
    t.integer  "user_id"
    t.string   "title"
    t.text     "description"
    t.boolean  "is_private",  :default => true
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "email_notifications", :force => true do |t|
    t.integer  "cube_id"
    t.string   "email",      :limit => 100
    t.string   "subject",    :limit => 100
    t.text     "message"
    t.boolean  "is_sent",                   :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "favourites", :force => true do |t|
    t.integer  "user_id"
    t.integer  "gear_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "gears", :force => true do |t|
    t.integer  "owner_id"
    t.string   "owner_type",  :limit => 20
    t.string   "title",       :limit => 50
    t.integer  "category_id"
    t.integer  "brand_id"
    t.integer  "location_id"
    t.integer  "color_id"
    t.string   "size"
    t.string   "sku"
    t.string   "gender"
    t.text     "description"
    t.string   "url"
    t.float    "price",                     :default => 0.0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "locations", :force => true do |t|
    t.string   "name",       :limit => 100
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "network_results", :force => true do |t|
    t.integer  "user_id"
    t.text     "message"
    t.boolean  "status"
    t.boolean  "is_sent",    :default => false
    t.string   "response"
    t.integer  "network_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "cube_id"
  end

  create_table "networks", :force => true do |t|
    t.integer  "user_id"
    t.string   "username"
    t.string   "encrypted_password"
    t.string   "network_type"
    t.string   "fb_session_key"
    t.string   "fb_user_token"
    t.string   "fb_user_name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "payments", :force => true do |t|
    t.integer  "vendor_id"
    t.integer  "pricing_plan_id"
    t.integer  "subscription_id"
    t.float    "amount",                        :default => 0.0
    t.string   "transaction_id"
    t.string   "transaction_type"
    t.string   "credit_card_mask", :limit => 4
    t.string   "expiration_month", :limit => 2
    t.string   "expiration_year",  :limit => 4
    t.datetime "start_date"
    t.datetime "end_date"
    t.text     "responses"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "preferences", :force => true do |t|
    t.integer  "user_id"
    t.string   "colors"
    t.string   "locations"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "brands"
    t.string   "vendors"
    t.string   "featured_vendors"
    t.string   "price_ranges"
  end

  create_table "price_range_settings", :force => true do |t|
    t.string   "level",      :limit => 10
    t.integer  "min_price",                :default => 0
    t.integer  "max_price",                :default => 0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "pricing_plans", :force => true do |t|
    t.string   "name",            :limit => 100
    t.integer  "max_gear_count"
    t.float    "initial_fee",                    :default => 0.0
    t.float    "monthly_fee",                    :default => 0.0
    t.integer  "free_for"
    t.boolean  "is_unlimited",                   :default => false
    t.boolean  "is_featured",                    :default => false
    t.boolean  "is_logo_on_cube",                :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "sessions", :force => true do |t|
    t.string   "session_id", :null => false
    t.text     "data"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "sessions", ["session_id"], :name => "index_sessions_on_session_id"
  add_index "sessions", ["updated_at"], :name => "index_sessions_on_updated_at"

  create_table "songs", :force => true do |t|
    t.string   "title",       :limit => 100
    t.text     "description"
    t.integer  "artist_id"
    t.integer  "heart_count",                :default => 0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "subscriptions", :force => true do |t|
    t.integer  "vendor_id"
    t.integer  "pricing_plan_id"
    t.integer  "prev_pricing_plan_id"
    t.datetime "next_renewal_at"
    t.datetime "billing_starting_date"
    t.datetime "billing_ending_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "user_preferences", :force => true do |t|
    t.integer  "user_id"
    t.integer  "preference_id"
    t.string   "preference_type"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.string   "email",                     :limit => 100
    t.string   "firstname",                 :limit => 40
    t.string   "lastname",                  :limit => 40
    t.string   "gender",                    :limit => 10
    t.string   "crypted_password",          :limit => 40
    t.string   "salt",                      :limit => 40
    t.string   "password_reset_code",       :limit => 40
    t.string   "activation_code",           :limit => 40
    t.datetime "activated_at"
    t.boolean  "is_cube_view_public",                      :default => false
    t.boolean  "status",                                   :default => false
    t.boolean  "is_deleted",                               :default => false
    t.text     "reason_for_deletion"
    t.datetime "deleted_at"
    t.string   "remember_token",            :limit => 40
    t.datetime "remember_token_expires_at"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "fb_user_id",                :limit => 8
    t.string   "email_hash"
    t.string   "confirmation_code",         :limit => 40
    t.datetime "confirmed_at"
    t.string   "signup_type"
  end

  create_table "vendor_cc_details", :force => true do |t|
    t.integer  "vendor_id"
    t.string   "cc_last_4digit",       :limit => 4
    t.string   "exp_year",             :limit => 4
    t.string   "exp_month",            :limit => 2
    t.string   "card_type"
    t.string   "ccv_number"
    t.string   "recurring_profile_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "vendors", :force => true do |t|
    t.integer  "pricing_plan_id"
    t.string   "company",                   :limit => 100
    t.string   "contact_person",            :limit => 40
    t.text     "address"
    t.string   "email",                     :limit => 100
    t.string   "phone_number",              :limit => 20
    t.string   "website"
    t.string   "username",                  :limit => 40
    t.string   "username_reset_code",       :limit => 40
    t.string   "crypted_password",          :limit => 40
    t.string   "salt",                      :limit => 40
    t.string   "password_reset_code",       :limit => 40
    t.boolean  "status"
    t.boolean  "is_verified",                              :default => false
    t.boolean  "is_deleted",                               :default => false
    t.string   "remember_token",            :limit => 40
    t.datetime "remember_token_expires_at"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "fb_user_id"
    t.string   "email_hash"
  end

  create_table "wishlists", :force => true do |t|
    t.integer  "user_id"
    t.integer  "gear_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

end
