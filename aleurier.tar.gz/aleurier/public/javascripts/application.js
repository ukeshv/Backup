// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults

var cubed_gear_count = 0; // number of items displayed in the cubed look, it will get update based on the delete/add.

function formValidator(){ 
	var email = document.getElementById('search');
	if(notEmpty(email, "Provide search text")){
		return true;
		}
  return false;
}
function notEmpty(elem, helperMsg){
	if(elem.value.trim().length == 0){
		$('search_text').innerHTML = helperMsg;
		$('search_text').style.display = 'block';
		return false;
	}
	return true;
}


function formValidator1(element){ 
	var email = document.getElementById('search');
	if(notEmpty_new(email, "Provide search text",element)){
		return true;
		}
  return false;
}
function notEmpty_new(elem, helperMsg,element){
	if(elem.value.trim().length == 0){ 
		$('search_text').innerHTML = helperMsg;
		$('search_text').style.display = 'block';
		$('flashnotice').style.display = 'none';
		document.getElementById(element).style.display = 'none';
		return false;
	}
	return true;
}

String.prototype.trim = function() {
a = this.replace(/^\s+/, '');
return a.replace(/\s+$/, '');
};

function validate_image(){
   if (document.getElementById('image').value != ""){
		var extn = document.getElementById('image').value.split('.').last()
		if ( extn == "jpg" || extn == "JPG" || extn == "GIF" || extn == "gif" || extn == "jpeg" || extn == "JPEG" || extn == "png" || extn == "PNG" ){			
		return true;
		}
		else{
		document.getElementById('image_error_msg').innerHTML="Image must be in .jpg, .gif, .jpeg, .png";
		return false;
		}	
    }
  else{
	return true;
	}		
		}
		
		function image_validation_without_blank(){  
		if (document.getElementById('image').value.trim().length == 0)
		{
			document.getElementById('image_error_msg').innerHTML="<font color='red'>Image  filed cann't be blank.</font>";
			return false;
		}
   else if (document.getElementById('image').value != ""){
		var extn = document.getElementById('image').value.split('.').last()
		if ( extn == "jpg" || extn == "JPG" || extn == "GIF" || extn == "gif" || extn == "jpeg" || extn == "JPEG" || extn == "png" || extn == "PNG" ){			
		return true;
		}
		else{
		document.getElementById('image_error_msg').innerHTML="<font color='red'>Image must be in .jpg, .gif, .jpeg, .png</font>";
		return false;
		}	
    }
  else{
	return true;
	}		
		}
		
function checkCheckBoxes() {
if (document.user.terms_privacy.checked == false)
		{
				document.getElementById('terms').innerHTML = 'Please accept terms and privacy.';
		   return false;
		}
	else
		{
		return true;
		}
	}
	
	 function check_all(current_obj_class)
  {
	var check_boxes= document.getElementsByClassName(current_obj_class);
	for(i=0;i<check_boxes.length;i++){
	check_boxes[i].checked=true;
	}
	}
    
  function uncheck_all(current_obj_class)
  {
    var check_boxes= document.getElementsByClassName(current_obj_class);
	for(i=0;i<check_boxes.length;i++){
	check_boxes[i].checked=false;
	}
	}
	
		
	function get_gears(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){	
	new Ajax.Request("/delete_gears/?gear_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	document.getElementById('select_one').style.display = 'block';
	document.getElementById('select_one').innerHTML = "<font color='red'>Select gear(s) to delete</font>"
	//document.getElementById('select_one').innerHTML += "<font color='red'>Select gear(s) to delete</font>"
	return false
	}
	}
	
	function get_user_gears(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){	
	new Ajax.Request("/delete_user_gears/?gear_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	document.getElementById('select_one').style.display = 'block';
	document.getElementById('select_one').innerHTML = "<font color='red'>Select gear(s) to delete</font>"
	return false
	}
	}
	
	function get_user_favourites_gears(current_obj_class)
	{  
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){	 
	new Ajax.Request("/delete_user_favourite_gears/?favourite_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	document.getElementById('select_one').style.display = 'block';
	document.getElementById('select_one').innerHTML = "<font color='red'>Select gear(s) to delete</font>"
	return false
	}
	}
	
	function get_user_wishlist_gears(current_obj_class)
	{  
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){	 
	new Ajax.Request("/delete_wishlist_gears/?wishlist_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	document.getElementById('select_one').style.display = 'block';
	document.getElementById('select_one').innerHTML = "<font color='red'>Select gear(s) to delete</font>"
	return false
	}
	}
	
	function validate_gear_image_in_new(){
   if (document.getElementById('image').value != ""){
		var extn = document.getElementById('image').value.split('.').last()
		if ( extn == "jpg" || extn == "JPG" || extn == "GIF" || extn == "gif" || extn == "jpeg" || extn == "JPEG" || extn == "png" || extn == "PNG" ){			
		return true;
		}
		else{
		document.getElementById('image_error_msg').innerHTML="Image must be in .jpg, .gif, .jpeg, .png";
		return false;
		}	
    }
  else{
	document.getElementById('image_error_msg').innerHTML="Please upload a valid image.";
	return false;
	}		
		}
		
	function validate_gear_image_in_edit(){
   if (document.getElementById('image').value != ""){
		var extn = document.getElementById('image').value.split('.').last()
		if ( extn == "jpg" || extn == "JPG" || extn == "GIF" || extn == "gif" || extn == "jpeg" || extn == "JPEG" || extn == "png" || extn == "PNG" ){			
		return true;
		}
		else{
		document.getElementById('image_error_msg').innerHTML="Image must be in .jpg, .gif, .jpeg, .png";
		return false;
		}	
    }
  else{
	return true;
	}		
		}

function ischecked(val)
{ 
  if (val.checked) {
		 new Ajax.Request("/profile_view_status_update/?status=true",{asynchronous:true,onComplete:function(request){Element.hide('ajax_image1');}, onLoading:function(request){Element.show('ajax_image1');}, evalScripts:true,insertion:Insertion.Top}); return false;
  }
	else
	{
	 new Ajax.Request("/profile_view_status_update/?status=false",{asynchronous:true,onComplete:function(request){Element.hide('ajax_image1');}, onLoading:function(request){Element.show('ajax_image1');}, evalScripts:true,insertion:Insertion.Top}); return false;
	}
}

  function validate_massUpload(){
        var val = true;        
        val = validate_csv(val);
        val = validate_zip(val);
        return val;
    }
	
function validate_csv(val){
   if (document.getElementById('gear_file').value != ""){
		var extn = document.getElementById('gear_file').value.split('.').last()
		if ( extn == "csv" || extn == "CSV" ){			
		val = true;
		}
		else{
		document.getElementById('csv_error').innerHTML="<font color='red'>Upload file must be csv format</font>";
		val = false;
		}	
    }
  else{
	document.getElementById('csv_error').innerHTML="<font color='red'>Required Field</font>";
	val = false;
	}		
	return val;
		}
		
function validate_zip(){
   if (document.getElementById('zip_file').value != ""){
		var extn = document.getElementById('zip_file').value.split('.').last()
		if ( extn == "zip" || extn == "ZIP" ){			
		val = true;
		}
		else{
		document.getElementById('zip_error').innerHTML="<font color='red'>Upload file must be zip format</font>";
		val = false;
		}	
    }
  else{
	document.getElementById('zip_error').innerHTML="<font color='red'>Required Field</font>";
	val = false;
	}		
	return val;
		}
		
	function tabChange(tab) { 
	if (tab=="email") {
	  $('cube_share_throught_email').show();
	  $('cube_share_throught_network').hide();

	}
	else
	{
		$('cube_share_throught_network').show();
	  $('cube_share_throught_email').hide();
	}
}
		
function vendors_url(urls_path) { 
var urls = urls_path.split(",");
	if (urls.length >=2)
	{ 
		for(i = 0; i < urls.length; i++){
		  NewWindow = window.open( urls[i] ,"_blank")  
		}
	}

}


// following methods used in cubed look page
var cubed_look_categories = new Array();
var bottom_scroll_categories = new Array();
function assign_available_remaining_categories(available_category_ids, remaining_category_ids)
{
	cubed_look_categories = available_category_ids.split(',');
	bottom_scroll_categories = remaining_category_ids.split(',');
}

function update_cubed_look_order(gear_ids)
{
       var array_ids = new Array;
       var x = gear_ids.split('&gear_ids[]=');
       //~ var index = function show(val, indx){
                       //~ if(indx==0)
                       //~ {
                               //~ var id_name = val.split('gear_ids[]=');
                               //~ $j('#list_' + id_name[1]).removeClass();
                               //~ $j('#list_' + id_name[1]).addClass('i0' + (indx+1));
                       //~ }
                       //~ else
                       //~ {   
                               //~ $j('#list_' + val).removeClass();
                               //~ $j('#list_' + val).addClass('i0' + (indx+1));
                       //~ }
       //~ }
       //~ x.forEach(index);
			
			for(var i=0; i<x.length; i++)
			{
				if(i==0)
			 {
					 var id_name = x[i].split('gear_ids[]=');
					 $j('#list_' + id_name[1]).removeClass();
					 $j('#list_' + id_name[1]).addClass('i0' + (i+1));
			 }
			 else
			 {   
							 $j('#list_' + x[i]).removeClass();
							 $j('#list_' + x[i]).addClass('i0' + (i+1));
			 }
			}			 
}

function extract_gear_ids(gear_ids)
{
       var array_ids = new Array;
       var x = new Array;
       x = gear_ids.split('&gear_ids[]=');
			for(var i=0; i<x.length; i++)
			{
				if(i==0)
			 {
							 var id_name = x[i].split('gear_ids[]=');                         
							 array_ids[i] = id_name[1]
			 }
			 else
			 {   
							 array_ids[i] = x[i]
			 }
			}
       return array_ids.toString();
}

function replace_new_gear(anchor_object, gear_id, category_id, available_category_ids, remaining_category_ids, matrix_position)
{	
	var params = $j('#gearlist').sortable('serialize', {key: 'gear_ids[]'});
	var displaying_gear_ids = extract_gear_ids(params);	
	var new_gear_id = anchor_object.getAttribute("gear_id");
       // $j('#list_' + gear_id).effect('explode', {}, 500, callback);
			$j('#list_' + new_gear_id).effect('explode', {}, 500, callback);
      function callback(){
               //~ var params = $j('#gearlist').sortable('serialize', {key: 'gear_ids[]'});
               $j.post('/user/cubes/add_new_category', {removed_category_id: category_id, remaining_category_ids: remaining_category_ids, displaying_category_ids: available_category_ids, position: matrix_position, displaying_gear_ids: displaying_gear_ids}, ajax_callback, "script");
                       function ajax_callback(data, textStatus)
                       {
                               //alert(data);
                       }
               //new Ajax.Request('/user/cubes/add_new_category', {parameters: 'removed_category_id='+ category_id, asynchronous:true, evalScripts:true, method:'post'}); return
       }
       return false;
}
// method called when any category dropped into cube look
function new_category_dropped(dropped_category_id)
{
	var params = $j('#gearlist').sortable('serialize', {key: 'gear_ids[]'});
	var displaying_gear_ids = extract_gear_ids(params);	
	
	$j.post('/user/cubes/dropped_category', {dropped_category_id: dropped_category_id, remaining_category_ids: bottom_scroll_categories.toJSON(), displaying_category_ids: cubed_look_categories.toJSON(), displaying_gear_ids: displaying_gear_ids}, ajax_callback, "script");
	function ajax_callback(data, textStatus)
	{
		// do something when ajax completed successfully.
	}
}

function arrange_gears_in_cube(gear_ids)
{
       var id_array = gear_ids.split(',');
			for(var i=0; i<id_array.length; i++)
			{
				$j('#list_' + id_array[i]).removeClass();
				$j('#list_' + id_array[i]).addClass('i0' + (i+1));
			}
}

function get_number_of_gears()
{
	var params = $j('#gearlist').sortable('serialize', {key: 'gear_ids[]'});
	var current_gear_ids = extract_gear_ids(params);
	var array_ids = current_gear_ids.split(',');
	return array_ids.length
}

function get_cubed_gear_ids()
{
	var params = $j('#gearlist').sortable('serialize', {key: 'gear_ids[]'});
	var current_gear_ids = extract_gear_ids(params);
	var array_ids = current_gear_ids.split(',');
	return array_ids;
}

function enable_disable_scroller_drag()
{
	if(cubed_look_categories.length >= 9)
	{
		// disable bottom category scroller
		$j(".draggable_items > li").draggable( 'disable' );
		//alert('dragging disabled');
	}
	else
	{
		// enable bottom category scroller
		$j(".draggable_items > li").draggable( 'enable' );
		//alert('dragging enabled');
	}
}

function disable_draggable_scroller()
{
	$j(".draggable_items > li").draggable( 'disable' );
	return false;
}

function enable_draggable_scroller()
{
	$j(".draggable_items > li").draggable( 'enable' );
	return false;
}

function cube_it_clicked(anchor_object)
{
	var gear_ids = get_cubed_gear_ids();
	$('cube_it_link').href = '/user/cubes/new' + '?gear_ids=' + gear_ids;
	
	if(gear_ids == '')
	{
		// lightbox should not open when there is no gear inside matrix
		// alert("CubedLook atleast have single gear to save.");
		Effect.Appear('empty_look');
		hide_flash_with_time('empty_look', 5);
	}
	else
	{
		$j(anchor_object).modal({width:600, height:500}).open(); 
	}
	return false;
}

function update_cube_it_clicked(cube_id, anchor_object)
{
	var gear_ids = get_cubed_gear_ids();	
	$('cube_it_link').href = '/user/cubes/' + cube_id + '/edit?gear_ids=' + gear_ids;
	
	if(gear_ids == '')
	{
		// lightbox should not open when there is no gear inside matrix
		// alert("CubedLook atleast have single gear to save.");
		Effect.Appear('empty_look');
		hide_flash_with_time('empty_look', 5);
	}
	else
	{
		$j(anchor_object).modal({width:600, height:500}).open(); 
	}
	return false;
}

function reload_to_cube_listing()
{
	self.parent.location.href = '/user/gears' 	
	self.parent.location.reload(true);
}

function reload_parent_to_other_page()
{
	// self.parent.location.href = '/user/cubes' -- for now it is redirected to user gears listing page, later it should changed to my_cubes page
	self.parent.location.href = '/user/gears' 	
	var t = setTimeout("self.parent.location.reload(true)", 10000);
	//self.parent.location.reload(true);
}

function reload_from_cc_update_to_gears_page()
{
	self.parent.location.href = '/vendor/gears' 	
	var t = setTimeout("self.parent.location.reload(true)", 10000);
}

function scroll_list_to(obj)
{
	var optional_values = obj.value.split(',');
	var position = optional_values[0];
	var category_id = optional_values[1];
	var exact_value = (position == 'select' || position == 1)? 0 : -((position-1) * 190);
	$('scroller_categories').style.left = exact_value + "px";
	$j("#category_" + category_id).slideDown("slow");
	//$("div").slideDown("slow");
	return false;
}

function add_to_cubed_look(category_id)
{
	$j.post('/user/cubes/dropped_category', {dropped_category_id: category_id, remaining_category_ids: bottom_scroll_categories.toJSON(), displaying_category_ids: cubed_look_categories.toJSON()}, ajax_callback, "script");
	function ajax_callback(data, textStatus)
	{
		// do something when ajax completed successfully.
	}
	return false;
}

function get_colors(current_obj_class){
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){	
		document.getElementById('color_error').style.display = 'none';
	new Ajax.Request("/users/color_update/?color_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	document.getElementById('update_msg_4').style.display = 'none';
	document.getElementById('color_error').style.display = 'block';
	document.getElementById('color_error').innerHTML = "<font color='red'>Select color(s)</font>"
	return false;
	}
}

function get_featured_vendors(current_obj_class){
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){	
		document.getElementById('fv_error').style.display = 'none';
	new Ajax.Request("/users/featured_vendors_update/?featured_vendor_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	document.getElementById('update_msg_2').style.display = 'none';
	document.getElementById('fv_error').style.display = 'block';
	document.getElementById('fv_error').innerHTML = "<font color='red'>Select featured vendor(s)</font>"
	return false;
	}
}

function get_vendors(current_obj_class){
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){	
		document.getElementById('v_error').style.display = 'none';
	new Ajax.Request("/users/vendors_update/?vendor_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	document.getElementById('update_msg_3').style.display = 'none';
	document.getElementById('v_error').style.display = 'block';
	document.getElementById('v_error').innerHTML = "<font color='red'>Select vendor(s)</font>"
	return false;
	}
}

function get_price_ranges(current_obj_class){
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){	
		document.getElementById('prs_error').style.display = 'none';
	new Ajax.Request("/users/price_ranges_update/?price_range_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	document.getElementById('update_msg_5').style.display = 'none';
	document.getElementById('prs_error').style.display = 'block';
	document.getElementById('prs_error').innerHTML = "<font color='red'>Select price range setting(s)</font>"
	return false;
	}
}

function get_locations(current_obj_class){
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){	
		document.getElementById('loc_error').style.display = 'none';
	new Ajax.Request("/users/locations_update/?location_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	document.getElementById('update_msg_6').style.display = 'none';
	document.getElementById('loc_error').style.display = 'block';
	document.getElementById('loc_error').innerHTML = "<font color='red'>Select location(s)</font>"
	return false;
	}
}

function get_brands(current_obj_class){
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){	
		document.getElementById('brd_error').style.display = 'none';
	new Ajax.Request("/users/brands_update/?brand_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	document.getElementById('update_msg_7').style.display = 'none';
	document.getElementById('brd_error').style.display = 'block';
	document.getElementById('brd_error').innerHTML = "<font color='red'>Select brand(s)</font>"
	return false;
	}
}


function goto_cube_look()
{
	self.parent.location.href = '/cubed_looks' 	
}


function open_three_urls(urls)
{
	var three_urls = new Array();
	three_urls = urls.split(',');
	var count = 0;
	var indexes = function show(indx, value)
	{
	 if (indx.length > 0){
	  url = indx.indexOf("http://")
		if (url == -1){
		window.open ('http://'+indx,"mywindow"+count);
		}
		else{
	  window.open (indx,"mywindow"+count);
		}
		
		count += 1;}
	}
	three_urls.forEach(indexes);
}

function popup_matrix_clicked(val){
$('matrix_'+val).simulate('click');
return false;
}


// js for gear popup view starts here

var popup_gear_ids = new Array();
var gear_position_array = new Array();
gear_position_array = [0,0,0,0,0,0,0,0,0];
var gear_position = 0, current_gear = 0;
var selected_gear_id = 0, gear_position_back_up = 0;

function load_array_with_gear_ids(ids)
{
	popup_gear_ids = ids.split(',');
}

function previous_click()
{
	gear_position_array[current_gear] -= 1;
	if(gear_position_array[current_gear] < 0)
	{
		gear_position_array[current_gear] = (popup_gear_ids.length - 1);
	}
	var popup_gear_ids_index = gear_position_array[current_gear];
	new Ajax.Request('/user/cubes/change_popup_gear_content', {asynchronous:true, evalScripts:true, method:'post', parameters:'gear_id=' + popup_gear_ids[popup_gear_ids_index]}); 
	return false;
}

function next_click()
{
	gear_position_array[current_gear] += 1;
	if(gear_position_array[current_gear] >= popup_gear_ids.length)
	{
		gear_position_array[current_gear] = 0;
	}	
	var popup_gear_ids_index = gear_position_array[current_gear];
	new Ajax.Request('/user/cubes/change_popup_gear_content', {asynchronous:true, evalScripts:true, method:'post', parameters:'gear_id=' + popup_gear_ids[popup_gear_ids_index]}); 
	return false;
}

function update_background_and_close()
{
	var popup_gear_ids_index = gear_position_array[current_gear];
	if(popup_gear_ids[popup_gear_ids_index] == selected_gear_id)
	{
		// user doesn't modified the selected gear
	}
	else
	{
		new Ajax.Request('/user/cubes/change_background_gear_content', {asynchronous:true, evalScripts:true, method:'post', parameters:'new_gear_id=' + popup_gear_ids[popup_gear_ids_index] + '&old_gear_id=' + selected_gear_id}); 
	}
	// return false;
}

function update_background_gear(new_gear_id, old_gear_id, gear_file_path)
{
	$('gear_image_' + old_gear_id).src = gear_file_path;
	$('gear_image_' + old_gear_id).id = 'gear_image_' + new_gear_id;
	$('list_' + old_gear_id).id = 'list_' + new_gear_id;
	
	var anchor_attr = $('background_gear_link_' + old_gear_id).attributes;
	for(var i=0; i<anchor_attr.length; i++)
	{
		if(anchor_attr[i].name == 'ondblclick')
		{
			anchor_attr[i].value = "update_current_gear(" + current_gear + "); return popup_matrix_clicked('" + new_gear_id + "');";
		}
	}
	$('background_gear_link_' + old_gear_id).id = 'background_gear_link_' + new_gear_id;
	
	$('gear_close_' + old_gear_id).setAttribute("gear_id", new_gear_id);		// update attribute gear_id with the new gear value
	$('gear_close_' + old_gear_id).id = 'gear_close_' + new_gear_id;
	
	$('matrix_' + old_gear_id).href = '/popup_matrix/' + new_gear_id;
	$('matrix_' + old_gear_id).id = 'matrix_' + new_gear_id;
	new Control.Modal($('matrix_' + new_gear_id), {className:'modal_container',width: 600,height: 0})
	selected_gear_id = new_gear_id;
}

function update_current_gear(position)
{
	current_gear = position;
	gear_position_back_up = gear_position_array[current_gear];
}

function reset_gear_position()
{
	gear_position_array[current_gear] = gear_position_back_up;
}
// js for gear popup view ends here

function visible_element(element_id)
{
	$(element_id).style.visibility = 'visible';
}

function toggle_display(element_id)
{	
	//$(element_id).style.display = 'inline';
	$(element_id).style.visibility = 'hidden';		
}



// script to auto-hide flash message with pre-defined timing
var secs=0;
var t, element_id;
var flash_duration = 0;

function hide_flash_with_time(id, duration)
{
	element_id = id;
	flash_duration = duration;
	start_counter();
}

function start_counter()
{
	secs += 1;
	if(secs >= flash_duration)
		stop_counter();
	else
		t=setTimeout("start_counter()", 1000);
}

function stop_counter()
{	
	new Effect.Highlight($(element_id));
	($(element_id)==null)? '' : Effect.Fade(element_id);
	secs = 0;
	clearTimeout(t);
}
// script to auto-hide flash message with pre-defined timing

function load_mp3_player(anchor_obj)	
{
	var playlist_type = anchor_obj.readAttribute('playlist_type');
	var so = new SWFObject('/flash/player.swf','player','310','120','9','#ffffff');
	so.addParam('allowfullscreen','true');
	so.addParam('allowscriptaccess','always');
	so.addParam('wmode','opaque');
	so.addParam('name','player');
	so.addVariable('file', '/artists/default_playlist_xml?playlist_type=' + playlist_type);
	so.addVariable('duration','33');
	so.addVariable('autostart','true');			
	so.addVariable('playlistfile','.xml');
	so.addVariable('playlistsize','100');
	so.addVariable('playlist','bottom');
	so.write('player_layout');
}

function toggle_button_class_from_list(type_of_playlist)
{
	var anchorObject = null;
	if(type_of_playlist == '' || type_of_playlist == 'random')
	{	anchorObject = $('random_playbutton');	}
	else if(type_of_playlist == 'newly_added')
	{	anchorObject = $('newest_playbutton');	}
	else if(type_of_playlist == 'current_artist')
	{	anchorObject = $('artist_playbutton');	}
	else if(type_of_playlist == 'most_hearted')
	{	anchorObject = $('hearted_playbutton');	}
	toggle_button_class(anchorObject);
}
 
function toggle_button_class(anchor_obj)
{
	initialise_play_buttons();
	anchor_obj.className = 'current';
	var current_item = anchor_obj.readAttribute('playlist_type');
	$('repeat_playlist').setAttribute('playlist_type', current_item);
}

var playbutton_ids = ['newest_playbutton', 'random_playbutton', 'artist_playbutton', 'hearted_playbutton'];

function initialise_play_buttons()
{
	for(var i=0; i<playbutton_ids.length; i++)
	{
		$(playbutton_ids[i]).className = 'playbuttons';
	}
}
 
function update_heart_count_display(new_heart_count)
{
	$('heart_count').text = new_heart_count;
}
 
 
function not_used()
{
	new Ajax.Request('/artists/heart_count', {parameters: 'attachment_id='+ attachment_id + '&update_count=true', asynchronous:true, evalScripts:true, method:'post'}); return false; 		
}

function postHeartCountUpdate(domObject)
{
	var song_id = domObject.readAttribute('song_id');
	new Ajax.Request('/artists/below_heart_count', {parameters: 'song_id=' + song_id, asynchronous:true, evalScripts:true, method:'post'}); return false; 		
}
