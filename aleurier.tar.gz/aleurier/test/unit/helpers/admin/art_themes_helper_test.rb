require 'test_helper'

class Admin::ArtThemesHelperTest < ActionView::TestCase
end
