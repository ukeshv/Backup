require 'test_helper'

class Admin::ArtistsHelperTest < ActionView::TestCase
end
