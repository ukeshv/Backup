require 'test_helper'

class Admin::BrandsHelperTest < ActionView::TestCase
end
