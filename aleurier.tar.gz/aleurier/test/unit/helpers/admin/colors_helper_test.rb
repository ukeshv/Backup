require 'test_helper'

class Admin::ColorsHelperTest < ActionView::TestCase
end
