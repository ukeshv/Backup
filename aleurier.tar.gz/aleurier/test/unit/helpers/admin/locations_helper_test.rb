require 'test_helper'

class Admin::LocationsHelperTest < ActionView::TestCase
end
