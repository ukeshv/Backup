require 'test_helper'

class Admin::PriceRangeSettingsHelperTest < ActionView::TestCase
end
