require 'test_helper'

class Admin::PricingPlansHelperTest < ActionView::TestCase
end
