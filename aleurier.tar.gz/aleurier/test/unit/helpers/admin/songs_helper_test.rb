require 'test_helper'

class Admin::SongsHelperTest < ActionView::TestCase
end
