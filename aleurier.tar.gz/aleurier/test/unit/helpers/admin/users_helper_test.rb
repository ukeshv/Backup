require 'test_helper'

class Admin::UsersHelperTest < ActionView::TestCase
end
