require 'test_helper'

class User::CubesHelperTest < ActionView::TestCase
end
