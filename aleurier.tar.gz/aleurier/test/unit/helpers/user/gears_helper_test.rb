require 'test_helper'

class User::GearsHelperTest < ActionView::TestCase
end
