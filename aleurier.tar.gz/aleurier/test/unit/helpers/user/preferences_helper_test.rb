require 'test_helper'

class User::PreferencesHelperTest < ActionView::TestCase
end
