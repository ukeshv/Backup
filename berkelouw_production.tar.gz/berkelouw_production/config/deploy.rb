require 'capistrano/ext/multistage'

# User account. admin is used so we don't have to allow
# root logins on the servers. RBAC is used to allow
# admin to restart the app servers.
set :spinner_user, nil
set :use_sudo, false
set :user, 'dberkavid'

# Application
set :application, "berkelouw"

# SCM
set :scm, :git
set :scm_username, "railsfactory"
set :scm_password, "qazwsx"
set :repository,  "git@github.com:davidberkelouw/berkelouw_production.git"

Dir[File.join(File.dirname(__FILE__), '..', 'vendor', 'gems', 'hoptoad_notifier-*')].each do |vendored_notifier|
  $: << File.join(vendored_notifier, 'lib')
end

require 'hoptoad_notifier/capistrano'