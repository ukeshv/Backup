# Be sure to restart your server when you modify this file

# Specifies gem version of Rails to use when vendor/rails is not present
RAILS_GEM_VERSION = '2.3.2' unless defined? RAILS_GEM_VERSION

# Bootstrap the Rails environment, frameworks, and default configuration
require File.join(File.dirname(__FILE__), 'boot')

Rails::Initializer.run do |config|
  # Settings in config/environments/* take precedence over those specified here.
  # Application configuration should go into files in config/initializers
  # -- all .rb files in that directory are automatically loaded.

  # Add additional load paths for your own custom dirs
  # config.load_paths += %W( #{RAILS_ROOT}/extras )

  # Specify gems that this application depends on and have them installed with rake gems:install
  # config.gem "bj"
  # config.gem "sqlite3-ruby", :lib => "sqlite3"
  # config.gem "aws-s3", :lib => "aws/s3"
  #config.gem "hpricot", :version => '0.6', :source => "http://code.whytheluckystiff.net"
  
	config.gem "fastercsv"
	config.gem 'mislav-will_paginate', :version => '~> 2.3.8', :lib => 'will_paginate', :source => 'http://gems.github.com'
	config.gem 'thinking-sphinx', :lib => 'thinking_sphinx', :version => '~> 1.3.18', :source => 'http://gemcutter.org'
	config.gem 'thinking-sphinx-raspell', :lib => 'thinking_sphinx/raspell', :version => '1.1.1', :source => 'http://gemcutter.org'
	config.gem "RedCloth", :version => '4.1.1', :source => 'http://gemcutter.org', :lib => 'redcloth' 
	config.gem 'isbn-tools', :lib=>"isbn/tools", :version => "~>0.1.0"  
	config.gem "authlogic"  
	config.gem "activemerchant", :lib => "active_merchant", :version => "1.5.1"  
	config.gem 'bullet', :source => 'http://gemcutter.org'  
	config.gem 'campaign_monitor_party', :source => 'http://gemcutter.org'  
	config.gem 'whenever', :lib => false, :source => 'http://gemcutter.org/'  
	config.gem 'metric_fu', :version => '1.3.0', :lib => 'metric_fu'
	config.gem 'reek', :version => '1.2.7.3'
	config.gem 'roodi', :version => '2.1.0'
	config.gem 'hoptoad_notifier'  
	config.gem 'pingfm', :version => '1.0.2'    
	config.gem 'handsoap', :version => '1.1.7'  
	config.gem 'flay', :version => '1.4.0'     
	config.gem 'rcov', :version => '0.9.8'  
	config.gem 'churn', :version => '0.0.12'  
	config.gem 'gem_plugin', :version => '0.2.3' 
	config.gem 'chronic', :version => '0.2.3'  
	config.gem 'andand', :version => '1.3.1'  
	config.gem 'sinatra', :version => '1.0'    
	config.gem 'recurrence', :version => '0.1.1'  
	config.gem 'daemons', :version => '1.1.0'  
	config.gem 'ean13', :version => '1.4.0'	 	 
	config.gem 'htmldoc', :version => '0.2.3'  
	config.gem 'flog', :version => '2.2.0'  
	config.gem 'after_commit', :version => '1.0.7'  
	config.gem 'riddle', :version => '1.0.12'   

  # Only load the plugins named here, in the order given (default is alphabetical).
  # :all can be used as a placeholder for all plugins not explicitly named
  # config.plugins = [ :exception_notification, :ssl_requirement, :all ]

  # Skip frameworks you're not going to use. To use Rails without a database,
  # you must remove the Active Record framework.
  # config.frameworks -= [ :active_record, :active_resource, :action_mailer ]

  # Activate observers that should always be running
  # config.active_record.observers = :cacher, :garbage_collector, :forum_observer

  # Set Time.zone default to the specified zone and make Active Record auto-convert to this zone.
  # Run "rake -D time" for a list of tasks for finding time zone names.
  #~ config.time_zone = 'Sydney'

  # The default locale is :en and all translations from config/locales/*.rb,yml are auto loaded.
  # config.i18n.load_path += Dir[Rails.root.join('my', 'locales', '*.{rb,yml}')]
  # config.i18n.default_locale = :de
  
  #~ config.logger = Logger.new(config.log_path, shift_age = 'daily')    
  
  
  ENV['RECAPTCHA_PUBLIC_KEY']  = '6LfTwLoSAAAAAI3h4HCpyVHqtNS5jGmq-7IgdvHi'
  ENV['RECAPTCHA_PRIVATE_KEY'] = '6LfTwLoSAAAAAD73GMFqwCxaSwiqKV9sOYRpvGGZ'
  # to set default time zone to 'Sydney', it affects both display and Time.now values
  ENV['TZ'] = 'Australia/Sydney'
	
	config.load_paths += %W( #{RAILS_ROOT}/app/sweepers )

  
end

RECEPIANTS_TO_ALERT_ON_BACKGROUND_JOB_ERROR = ['berkelouw@railsfactory.org']

Mime::Type.register 'application/pdf', :pdf
require 'htmldoc'

$pagination_count = 15

#Fixes CSS problems with Rail' built in validation cleverness.
#See http://ethilien.net/archives/fixing-divfieldwitherrors-in-ruby-on-rails/ for more info
ActionView::Base.field_error_proc = Proc.new { |html_tag, instance| "<span class=\"fieldWithErrors\">#{html_tag}</span>" }