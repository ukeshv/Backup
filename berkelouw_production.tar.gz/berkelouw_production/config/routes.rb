ActionController::Routing::Routes.draw do |map|
  map.resources :event_timings

  




  map.namespace :hq do |hq|
    hq.resources :orders, :collection => {:fulfill_multiple => :post, :close_all => :put, :process_all => :put, :enter_shipment => :get, :reports => :get, :fetch_reports => :post, :show_confirmation_form => :post, :confirm_title_page_order => :post, :hide_confirmation_form => :post, :not_available_with_title_page => :post, :update_order_item => :post}, :member => {:fulfill_single => :post, :progress_status => :put, :print_dispatch => :get,:download_receipt_pdf=>:get,:download_shipping_details_pdf=>:get, :download_partial_order_receipt => :get, :remove_order_item => :delete, :remove_unstock_item => :delete, :update_status => :get, :download_shipping_manifest_pdf=>:get, :order_transaction_detail => :get, :move_to_fail => :get, :edit_order_item => :post}    
    hq.resources :events, :collection => {:update_interval => :post, :product_relation_helper => :get, :display_products => :post}
    hq.resources :wishlists
    hq.resources :collection_styles
    hq.resources :collection_types
    hq.resources :tags
    hq.resources :genres, :collection => {:load_sub_genres => :post, :add_sub_genre => :post, :remove_sub_genre => :post}
    hq.resources :genre_types
    hq.resources :users
    hq.resources :posts, :collection => {:display_products => :post}
    hq.resources :store_photos
    hq.resources :stores
    hq.resources :placements
    hq.resources :placement_types
    hq.resources :placement_locations
    hq.resources :book_searches
    hq.resources :carts
    hq.resources :cart_items
    hq.resources :nielsen_updates
    hq.resources :collections
    hq.resources :features 
    hq.resources :publishing_statuses
    hq.resources :data_mismatch_types
    hq.resources :data_mismatches
    hq.resources :products_suppliers
    hq.resources :availability_statuses
    hq.resources :product_content_types
    hq.resources :product_categories
    hq.resources :address_types_addresses
    hq.resources :company_types
    hq.resources :companies
    hq.resources :address_types
    hq.resources :addresses
    hq.resources :contact_types
    hq.resources :contacts
    hq.resources :suppliers
    hq.resources :lists
    hq.resources :admins
    hq.resources :password_resets, :only => [ :new, :create, :edit, :update ]
    hq.resources :products,:collection=>{:import_rare_book => :get,:download_rare_book=>:post, :upload_rarebook_delete_csv => :post, :upload_book_net_data => :get, :upload_new_release_data => :get, :upload_new_release_pdf => :post, :update_ui => :post, :upload_alltime_book_data => :get}
    hq.resources :ftps, :collection => {:config => :get, :fetch_datas => :get, :update_download_status => :post, :downloads => :get, :data_files => :get}, :member => {:import_data_files => :get, :extract_file => :get}
    hq.resources :generic_products
  end
  
    #~ routes created for 301 redirects
  map.connect '/about/:store_name', :controller => 'redirect', :action => 'rose_bay'
  map.connect '/search_set', :controller => 'redirect', :action => 'home'
  map.connect '/rare_books', :controller => 'redirect', :action => 'rare_books'
  map.connect '/subscribe', :controller => 'redirect', :action => 'subscribe'
  map.connect '/whats_on', :controller => 'redirect', :action => 'home'   # not available in our app
  map.connect '/binding_and_repairs', :controller => 'redirect', :action => 'binding_and_repairs'
  map.connect '/book_club', :controller => 'redirect', :action => 'subscribe'
  map.connect '/contact', :controller => 'redirect', :action => 'contact'
  map.connect '/hampers', :controller => 'redirect', :action => 'home'
  map.connect '/search_menu.html', :controller => 'redirect', :action => 'search_menu'
  map.connect '/legal/delivery', :controller => 'redirect', :action => 'delivery'
  map.connect '/legal/privacy', :controller => 'redirect', :action => 'privacy'
  map.connect '/book_club/:book_club_slug', :controller => 'redirect', :action => 'book_club'
  map.connect '/subscribe_rare', :controller => 'redirect', :action => 'book_club', :book_club_slug => 'rare-books-catalogue'
  map.connect '/binding_and_repairs/brodart_products', :controller => 'redirect', :action => 'binding_and_repairs' 
  map.connect '/search_top.html', :controller => 'redirect', :action => 'browse_books' 
  map.connect '/whats_on/events', :controller => 'redirect', :action => 'events' 
  map.connect '/whats_on/books_by_the_metre', :controller => 'redirect', :action => 'books_by_the_metre' 
  map.connect '/whats_on/b-club', :controller => 'redirect', :action => 'book_club', :book_club_slug => 'the-b-club'
  map.connect '/whats_on/young_writers_programme_for_2', :controller => 'redirect', :action => 'home'   
  map.connect '/whats_on/secondhand_books', :controller => 'redirect', :action => 'home'   
  map.connect '/whats_on/the-pittwater', :controller => 'redirect', :action => 'home'   
  map.connect '/whats_on/new-releases', :controller => 'redirect', :action => 'home'   
  map.connect '/whats_on/members_only', :controller => 'redirect', :action => 'home'   
  map.connect '/advert.html', :controller => 'redirect', :action => 'home' 
  map.connect '/book_search_global', :controller => 'redirect', :action => 'book_search_global'   
  map.connect '/status', :controller => 'redirect', :action => 'home'   # to check order status in front end, currently we have no option to check statsu   
  map.connect '/lost_password', :controller => 'redirect', :action => 'lost_password'
  map.connect '/rare_books/latest_acquisitions_no_2982', :controller => 'redirect', :action => 'rare_books'    
  map.connect '/menu.html', :controller => 'redirect', :action => 'home'  
  map.connect '/file', :controller => 'redirect', :action => 'download_catalogue'  
  
  map.connect '/rare_books/:filename.:format', :controller => 'redirect', :action => 'download_file'  
  map.connect '/whats_on/:club_name/:filename.:format', :controller => 'redirect', :action => 'download_file'  
  
  map.place_order "/place_order", :controller => "checkout", :action => "place_order"
  map.checkout "/checkout", :controller => "checkout", :action => "index"
  map.login "/login", :controller => "user_sessions", :action => "new"
  map.logout "/logout", :controller => "user_sessions", :action => "destroy"
  map.wishlist "/wishlist", :controller => "wishlists", :action => "show"
  map.my_account "/my_account", :controller => "users", :action => "show"
  map.update_my_account "/my_account/update", :controller => "users", :action => "edit"
  map.admin_login "/hq", :controller => "hq/admins", :action => "new"
  map.admin_logout "/hq/logout", :controller => "hq/admins", :action => "destroy"
  map.index "/hq/admin",:controller=>"hq/admins",:action=>"new"
  map.new_admin "/hq/admin/new",:controller=>"hq/users",:action=>"new"
  map.new_customer "/hq/customer/new",:controller=>"hq/users",:action=>"new"
  map.new_manager "/hq/manager/new",:controller=>"hq/users",:action=>"new"
  map.available "/hq/order/available", :controller=>'hq/orders', :action=>'available'
  map.not_available "/hq/order/not_available", :controller=>'hq/orders', :action=>'not_available'
  map.available_in_suppliers "/hq/order/available_in_suppliers", :controller=>'hq/orders', :action=>'available_in_suppliers'
  map.failed_transaction "/hq/order/failed_transaction", :controller => 'hq/orders', :action => 'failed_transaction'
  map.clicked_link "/hq/order/clicked_link/:id", :controller=>'hq/orders', :action=>'clicked_link'
  
  
  map.rarebook_available_shippingcost_change "hq/order/available_shippingcost_change", :controller=>'hq/orders', :action=>'yes_and_change_shippingcost'
  map.rarebook_available "hq/order/rarebook_available/:id", :controller=>'hq/orders', :action=>'rarebook_available'
  map.rarebook_not_available "hq/order/rarebook_not_available", :controller=>'hq/orders', :action=>'rarebook_not_available'
  
  map.users "/users",:controller=>"user_sessions",:action=>"new", :conditions => {:method => :get} # this routes for the unknown action /users
  
  #Password Reset
  map.resources :password_resets, :only => [ :new, :create, :edit, :update ]
 
  map.returns "/returns", :controller => 'returns'
  map.conditions "/conditions", :controller => 'conditions'
  map.delivery "/delivery", :controller => 'delivery'
  map.privacy "/privacy", :controller => 'privacy'
  map.resources :partners, :only => [:index]
  map.resources :event_occurrences
  map.resources :subscriptions, :only => [:new, :create, :thanks], :member => {:thanks => :get}
  map.resources :lists, :only => [:show, :index]
  map.resources :email_enquiries
  map.resources :shipping_regions
  map.resources :product_data_suppliers
  map.resources :countries
  map.resources :booksoft_imports
  map.resources :orders, :member => {:download_receipt_pdf => :get}
  map.resources :addresses
  map.resources :wishlist_items
  map.resources :user_sessions
  map.resources :users
  map.resources :store_photos
  map.resources :stores, :only => [:index, :show]
  map.resources :book_searches, :only => [:new, :create, :thanks], :member => {:thanks => :get}
  map.resources :carts
  map.resources :collections
  map.resources :features
  map.resources :events
  
  
  map.page_error "page_error", :controller => "home", :action => "page_error"
  map.page_not_found "page_not_found", :controller => "home", :action => "page_not_found"
  map.internal_error "internal_error", :controller => "home", :action => "internal_error"
  map.book_club_slug "/bookclubs/:slug", :controller => "lists", :action => "show"
  map.store_slug "/stores/:slug", :controller => "stores", :action => "show"
  
  map.cart "/cart", :controller => "carts", :action => "show"
  map.update_cart "/cart/update", :controller => "carts", :action => "update"
  
  map.genre_slug "/browse/:category/:q/:name", :controller => "products", :action => "index", :f => 'genre'
  map.category_slug "/browse/:category/", :controller => "products", :action => "index", :f => 'category'
  
  map.rare_books "/catalogue/books/rare", :controller => "products", :action => "index", :category => 'rare-books'
  map.new_books "/catalogue/books/new", :controller => "products", :action => "index", :category => 'new-books'
  
  map.generic_products_slug "/catalogue/gift-vouchers/:isbn13/:title", :controller => "generic_products", :action => "show"
  map.product_slug "/catalogue/:category/:isbn13/:title", :controller => "products", :action => "show"
  map.hq_product_slug "hq/catalogue/:category/:isbn13/:title", :controller => "hq/products", :action => "show"
  map.hq_generic_product_slug "hq/:category/:isbn13/:title", :controller => "hq/generic_products", :action => "show"

  
  map.general_search "/search", :controller => "products", :action => "index"
  #~ map.general_search "/search", :controller => "products", :action => "index", :f => "category", :category => "books"
  map.get_value "/hq/events/recurring/get_value/:type", :controller => "hq/events", :action => "get_value"
  map.advanced_search "/search/advanced_search", :controller => "search", :action => "advanced_search"#, :category => 'rare-books'
  map.new_book_advanced_search "/search/new_book_advanced_search", :controller => "search", :action => "new_book_advanced_search", :category => 'books'
  map.update_status "orders/update_status/:id/:status",:controller=>"orders",:action=>"update_status"
  map.confirm_order_from_ready "/hq/orders/confirm_order_from_ready/:id",:controller=>"hq/orders",:action=>"confirm_order_from_ready"
  map.rarebook_order_confirmation "/rarebook_order_confirmation",:controller=>"orders",:action=>"rarebook_order_confirmation"
  
  map.resources :cart_items  
  #map.resources :books, :collection => {:rare => :get, :childrens => :get}
  map.post_preview '/hq/my_preview', :controller => "/hq/posts", :action => "my_preview"
  
  map.resources :contact_us
  map.contact_us "/contact_us", :controller => 'contact_us'
  map.resources :we_buy_books
  map.resources :stores
  map.resources :services, :collection => { :books_by_the_metre => :get, :bindings_and_repairs => :get, :brodart_services => :get }
  map.resources :posts, :as=> 'news'
  map.resources :reviews
  map.resources :products, :member => {:get_in_store_availability => :post}
  map.resources :genres
  map.resources :generic_products
  
  map.hq_genre_product '/hq/genre/:genre_id/product/:product_id', :controller => "hq/products", :action=> "delete_genre"
  map.hq_genre_generic_product '/hq/generic_products/genre/:genre_id/product/:product_id', :controller => "hq/generic_products", :action=> "delete_genre"
  
  map.hq_supplier_product '/hq/supplier/:supplier_id/product/:product_id', :controller => "hq/products", :action => "delete_supplier"
  
  # The priority is based upon order of creation: first created -> highest priority.

  # Sample of regular route:
  #   map.connect 'products/:id', :controller => 'catalog', :action => 'view'
  # Keep in mind you can assign values other than :controller and :action

  # Sample of named route:
  #   map.purchase 'products/:id/purchase', :controller => 'catalog', :action => 'purchase'
  # This route can be invoked with purchase_url(:id => product.id)

  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   map.resources :products

  # Sample resource route with options:
  #   map.resources :products, :member => { :short => :get, :toggle => :post }, :collection => { :sold => :get }

  # Sample resource route with sub-resources:
  #   map.resources :products, :has_many => [ :comments, :sales ], :has_one => :seller
  
  # Sample resource route with more complex sub-resources
  #   map.resources :products do |products|
  #     products.resources :comments
  #     products.resources :sales, :collection => { :recent => :get }
  #   end

  # Sample resource route within a namespace:
  #   map.namespace :admin do |admin|
  #     # Directs /admin/products/* to Admin::ProductsController (app/controllers/admin/products_controller.rb)
  #     admin.resources :products
  #   end

  # You can have the root of your site routed with map.root -- just remember to delete public/index.html.
  

  # See how all your routes lay out with "rake routes"

  # Install the default routes as the lowest priority.
  # Note: These default routes make all actions in every controller accessible via GET requests. You should
  # consider removing the them or commenting them out if you're using named routes and resources.
  
  map.root :controller => "home"

  map.connect "large/:product_name/:prod_isbn13.jpg", :controller=>'home', :action=>'rewrite_image', :id => 'large' 
  map.connect "medium/:product_name/:prod_isbn13.jpg", :controller=>'home', :action=>'rewrite_image', :id => 'medium' 
  map.connect "small/:product_name/:prod_isbn13.jpg", :controller=>'home', :action=>'rewrite_image', :id => 'small' 
  
  map.show_event '/events/:id/:title', :controller=>'events', :action=>'show'
  map.show_post '/news/:id/:title', :controller=>'posts', :action=>'show'
  map.show_collection '/collections/:id/:title', :controller=>'collections', :action=>'show'
  
  #~ map.connect '/small/:title/:isbn.:format', :controller=> 'home', :action => 'small_nielsen_image'
  #~ map.connect '/medium/:title/:isbn.:format', :controller=> 'home', :action => 'medium_nielsen_image'
  #~ map.connect '/large/:title/:isbn.:format', :controller=> 'home', :action => 'large_nielsen_image'  
  
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action.:format'
  map.connect ':controller/:action/:id.:format'


  
  
end
