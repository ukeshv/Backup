every 15.minutes do
  rake "db:get_yahoo_exchange_rates"
end

every 1.day, :at => '3:00 am' do
  rake "ts:index"
end

every :reboot do
  rake "ts:start"
end