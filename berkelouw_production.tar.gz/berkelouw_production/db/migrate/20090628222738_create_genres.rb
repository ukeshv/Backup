class CreateGenres < ActiveRecord::Migration
  def self.up
    create_table :genres do |t|
      t.string :code
      t.string :name
      t.integer :parent_id

      t.timestamps
    end
    
    require 'fastercsv'
    FasterCSV.foreach("#{RAILS_ROOT}/db/csvs/bic_codes.csv") do |row|
      puts "Code: " + row[0].to_s.strip
      puts "Parent code: " + row[0].to_s.strip[0..(row[0].to_s.strip.length-2)]
      g = Genre.new(
        :code => row[0].to_s.strip,
        :name => row[1].to_s.strip
      )
      g.save
      
    end
      
    #Loop through all of the newly imported Genres and amend their ParentID
    @genres = Genre.all()
    @genres.each do |g|
      parent_code = g.code[0..(g.code.length-2)]
      parent = Genre.find(:first, :conditions => "code = '#{parent_code}'")
      if parent
        puts parent_code + " assigned parent code: " + parent.code.to_s + " ParentID: " + parent.id.to_s
        g.update_attribute :parent_id, parent.id
      else
        puts " ===============   WARING: ParentID not found. This code: " + g.code.to_s + " Parent Code: " + parent_code + " ============="
      end
    end
  end

  def self.down
    drop_table :genres
  end
end
