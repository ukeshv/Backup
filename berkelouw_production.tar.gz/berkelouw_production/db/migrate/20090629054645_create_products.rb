class CreateProducts < ActiveRecord::Migration
  def self.up
    create_table :products do |t|
      
      #Internal categorising
      t.integer :product_department_id #new books, rare books, used books, stationary etc
      t.integer :product_data_supplier_id #Nielsen, BookNet, Ingrams etc
      
      
      #Nielsen specific fields - comments provided by Nielsen Field Spec doc.
      


      #3.1 Product Identification ==============================================

      #Title example:
      #LA: The  TL: Lord of the Rings PVNO1: Part 3 PT1: The Return of the King
      
      
      t.string :isbn13, :limit => 13 #ISBN-13
      t.string :la, :limit => 20 #Leading text of tile e.g The, A, An
      t.text :tl, :limit => 500 #Main text of title
      t.text :pt1, :limit => 500 #Title of this volume or part
      t.text :pvno1, :limit => 400 #Volume or part number
      t.text :pt2, :limit => 500 #Title of this volume or part
      t.text :pvno2, :limit => 400 #Volume or part number
      t.text :st, :limit => 500 #Subtitle
      t.text :ys, :limit => 300 #Year element of title
      t.text :sn, :limit => 300 #Series title
      t.string :nws, :limit => 150 #Series part / volume number
      t.string :issn, :limit => 20 #Series ISSN  
      
      
      #3.5 Authors and Contributors ==============================================
      #3 possible
      
      t.string :cr1, :limit => 20 #The ONIX role this contributor takes – Code (from ONIX list 17)
      t.string :crt1, :limit => 200 #The ONIX role this contributor takes – Text
      t.string :cci1, :limit => 20 #Corporate Indicator (Y if a corporate name)
      t.text :cns1, :limit => 2000 #1st of 3 possible Authors or other contributor - A shorter form of name, with appropriate punctuation
      
      t.string :cr2, :limit => 20 #The ONIX role this contributor takes – Code (from ONIX list 17)
      t.string :crt2, :limit => 200 #The ONIX role this contributor takes – Text
      t.string :cci2, :limit => 20 #Corporate Indicator (Y if a corporate name)
      t.text :cns2, :limit => 2000 #2nd of 3 possible Authors or other contributor - A shorter form of name, with appropriate punctuation
      
      t.string :cr3, :limit => 20 #The ONIX role this contributor takes – Code (from ONIX list 17)
      t.string :crt3, :limit => 200 #The ONIX role this contributor takes – Text
      t.string :cci3, :limit => 20 #Corporate Indicator (Y if a corporate name)
      t.text :cns3, :limit => 2000 #3rd of 3 possible Authors or other contributor - A shorter form of name, with appropriate punctuation
  
      
      
      #3.6 Physical & Edition Details ==============================================   
      
      #Product dimensions      
      t.string :hmm, :limit => 20 #height in mm
      t.string :wmm, :limit => 20 #width in mm
      t.string :smm, :limit => 20 #depth (spine width) mm
      t.string :wg, :limit => 20 #weight in grams
      
      
      
      
      
      #Deeper detail
      
      t.string :edsl, :limit => 200 #Full Edition Statement – edition number output as an ordinal number, plus edition code description in full eg 2nd revised edition
      t.string :pfc, :limit => 20 #Product Format – Code (from ONIX list 7)
      t.string :pfct, :limit => 200 #Product Format – Text description associated with the code
      
      #There are 10 possible entries for the following PCTC and PCTCT fields
      t.string :pctc1, :limit => 10 #1st of 10 possible Product Content types – Code (from ONIX list 81)
      t.string :pctct1, :limit => 200 #2nd of 10 possible Product Content types – Text description associated with the code – e.g. audiobook
      t.string :pctc2, :limit => 10 
      t.string :pctct2, :limit => 200
      t.string :pctc3, :limit => 10
      t.string :pctct3, :limit => 200
      t.string :pctc4, :limit => 10
      t.string :pctct4, :limit => 200
      t.string :pctc5, :limit => 10
      t.string :pctct5, :limit => 200
      t.string :pctc6, :limit => 10
      t.string :pctct6, :limit => 200
      t.string :pctc7, :limit => 10
      t.string :pctct7, :limit => 200
      t.string :pctc8, :limit => 10
      t.string :pctct8, :limit => 200
      t.string :pctc9, :limit => 10
      t.string :pctct9, :limit => 200
      t.string :pctc10, :limit => 10
      t.string :pctct10, :limit => 200
      
      t.string :pagnum, :limit => 100 #Number of pages
      t.string :noi, :limit => 60 #Number of items
      t.string :run, :limit => 20 #Running time
      t.text :ill, :limit => 500 #Illustrations and other contents note. eg 25 black & white diagrams
      t.string :ms1, :limit => 50 #1st of 2 possible Map scale as stored
      t.string :ms2, :limit => 50 #2nd of 2 possible Map scale as stored
      t.string :nop, :limit => 20 #Number of pieces, if all pieces have the same form
      t.text :cis, :limit => 6000 #A statement of the contained items e.g. contains Paperback and 4 Audio Cassettes
      
      
      
      
      #3.7 E-Publication Information ==============================================     
      
      t.text :ept, :limit => 300 #E-publication Type as stored
      t.text :epf, :limit => 300 #E-publication Format as stored
      t.text :epfs, :limit => 1000 #Constructed statement: E-publication Type Description
      t.string :epss, :limit => 40 #Constructed statement: File Size / space / Units
      
      
      
      
      
      #3.8 Language & Translation Details ==============================================
      
      #There may be 5 occurrences of TCF and TFT
      t.string :tfc1, :limit => 20 #Language translated from (original language) – Code (may be up to 5 occurrences) (from ONIX list 74)
      t.string :tft1, :limit => 200 #Language translated from (original language) – Text (may be up to 5 occurrences)
      t.string :tfc2, :limit => 20
      t.string :tft2, :limit => 200
      t.string :tfc3, :limit => 20
      t.string :tft3, :limit => 200
      t.string :tfc4, :limit => 20
      t.string :tft4, :limit => 200
      t.string :tfc5, :limit => 20
      t.string :tft5, :limit => 200
      
      
      t.string :ts, :limit => 200 #Translation statement (all original languages listed)
      
      
      
      
      #3.9 Audience (Readership) Group ==============================================
      
      #There may be up to 10 occurrences of OAC & OAT
      t.string :oac1, :limit => 20
      t.string :oat1, :limit => 200
      t.string :oac2, :limit => 20
      t.string :oat2, :limit => 200
      t.string :oac3, :limit => 20
      t.string :oat3, :limit => 200
      t.string :oac4, :limit => 20
      t.string :oat4, :limit => 200
      t.string :oac5, :limit => 20
      t.string :oat5, :limit => 200
      t.string :oac6, :limit => 20
      t.string :oat6, :limit => 200
      t.string :oac7, :limit => 20
      t.string :oat7, :limit => 200
      t.string :oac8, :limit => 20
      t.string :oat8, :limit => 200
      t.string :oac9, :limit => 20
      t.string :oat9, :limit => 200
      t.string :oac10, :limit => 20
      t.string :oat10, :limit => 200
      
      
      
      
      
      #3.10 Subject Indexing & Classification ==============================================
      
      t.string :bic2sc1, :limit => 20 #1st of 5 possible BIC codes - will reference genres table
      t.string :bic2st1, :limit => 200 #1st BIC category in text format
      t.string :bic2sc2, :limit => 20 #2nd of 5 possible BIC codes - will reference genres table
      t.string :bic2st2, :limit => 200 #2nd BIC category in text format
      t.string :bic2sc3, :limit => 20 #3rd of 5 possible BIC codes - will reference genres table
      t.string :bic2st3, :limit => 200 #3rd BIC category in text format
      t.string :bic2sc4, :limit => 20 #4th of 5 possible BIC codes - will reference genres table
      t.string :bic2st4, :limit => 200 #4th BIC category in text format
      t.string :bic2sc5, :limit => 20 #5th of 5 possible BIC codes - will reference genres table
      t.string :bic2st5, :limit => 200 #5th BIC category in text format
      
      t.string :bic2qc1, :limit => 20 #1st of 5 possible BIC QUALIFIER codes
      t.string :bic2qt1, :limit => 200 #1st of 5 possible BIC QUALIFIER codes as text
      t.string :bic2qc2, :limit => 20
      t.string :bic2qt2, :limit => 200
      t.string :bic2qc3, :limit => 20
      t.string :bic2qt3, :limit => 200
      t.string :bic2qc4, :limit => 20
      t.string :bic2qt4, :limit => 200
      t.string :bic2qc5, :limit => 20
      t.string :bic2qt5, :limit => 200
     
      
      
      #3.12 Product Links ==============================================
      
      t.string :repis13, :limit => 20 #ISBN-13 of book which it replaces
      t.string :repbis13, :limit => 20 #ISBN-13 of book which it is replaced by
      t.string :pubais13, :limit => 20 #Publisher suggested alternative for this ISBN
      t.string :epris13, :limit => 20 #E-Publication rendering of this ISBN-13
      t.string :epbis13, :limit => 20 #E-Publication based on this ISBN-13
      
      
      
      #3.13 Prize Information ==============================================
      
      t.text :psf #Structured Prize details for all Prizes combined
      
      
      
      
      #3.14 Descriptions, Contents, Promotional Information ==============================================
      
      t.text :aussd #Brief description
      t.text :ausld #Full description
      t.text :ausbiog #Author biog - Asutralian bias if available
      t.text :austoc #Table of contents - Asutralian bias if available
      t.text :kirkukrev #UK Kirkus Reviews
      t.text :kirkusrev #US Kirkus Reviews
      
      
      
      #3.15 Publisher & Imprint ==============================================
      
      t.string :impn #Imprint
      t.string :impid #BookData Code for Imprint
      t.string :pubn #Publisher Name
      t.string :pubid #BookData Code for Publisher
      t.string :pop #Place of publication
      t.string :cop #Country of publication
      
      
     
  
      #3.16 Publication Date & Publishing Status ==============================================
      
      t.date :pubpd #Publication date
      t.date :embd #Embargo Date, Equivalent meanings to 'On Sale Date', 'Launch Date'
      t.date :mopd #Date the system was informed that the record is no longer available
      t.string :pubsc, :limit => 20 #ONIX Publishing Status - Code (from ONIX list 64)
      t.string :pubst, :limit => 200 #ONIX Publishing Status - Text
      
     
      
      
      #3.19 Prices ==============================================
      
      #UK Price info
      t.string :gbpccpra, :limit => 20 #The area as stored on the BookData system – GB, US, AUS, NZ, SA, EUR, CAN etc
      t.string :gbpccprrrp, :limit => 20 #The Current Retail Price Of The Record (inc Taxes)
      t.text :gbpccprsn, :limit => 300 #The name of the supplier of this price information
      t.string :gbpccprc, :limit => 20 #The currency as stored on BookData System – GBP, AUD, USD etc
      t.string :gbpccprtop, :limit => 20 #The actual tax amount (may be zero)
      t.string :gbpccprrrplt, :limit => 20 #RRP minus any tax (may be the RRP if zero tax)
      t.string :gbpccprpn, :limit => 100 #Any supplementary notes regarding tax information
      t.date :gbpccplcd #Price last change date
      
      #USA Price info - field details as above for UK
      t.string :usdccpra, :limit => 20
      t.string :usdccprrrp, :limit => 20
      t.text :usdccprsn, :limit => 300
      t.string :usdccprc, :limit => 20
      t.string :usdccprtop, :limit => 20
      t.string :usdccprrrplt, :limit => 20
      t.string :usdccprpn, :limit => 100
      t.date :usdccplcd
      
      #Australian Price info - field details as above for UK
      t.string :audccpra, :limit => 20
      t.string :audccprrrp, :limit => 20
      t.text :audccprsn, :limit => 300
      t.string :audccprc, :limit => 20
      t.string :audccprtop, :limit => 20
      t.string :audccprrrplt, :limit => 20
      t.string :audccprpn, :limit => 100
      t.date :audccplcd
      
      
      
      #3.20 Product Availability ==============================================
      
      t.string :ausnbdaa, :limit => 20 #The area as stored on BookData System – GB, US, AUS, NZ, SA, EUR, CA etc
      t.text :ausnbdasn, :limit => 300 #The name of the supplier of this availability
      t.date :ausnbdead #Availability Date
      t.date :ausnbdpacd #Availability Confirmed date
      t.string :ausnbdot, :limit => 20 #Order Time
      t.string :ausnbdpq, :limit => 20 #Pack Quantity
      t.date :ausnbdpaslcd #Available last change date
      t.string :ausnbdpac, :limit => 20 #ONIX Product Availability – Code (from ONIX list 65)
      t.string :ausnbdpat, :limit => 100 #ONIX Product Availability – Text
      
      
      
      
      #3.21 Distributors ==============================================
      
      t.string :ausadn1, :limit => 300 #1st of 2 Distributor names
      t.string :ausadi1, :limit => 30 #1st of 2 The Identifier of the 'distributor' – needed to ‘link’ to an organisation file
      t.string :ausadn2, :limit => 300
      t.string :ausadi2, :limit => 30
      
  
      
      
      #3.22 Wholesaler Information ==============================================
      
      t.string :wslruk, :limit => 200 #A list of stock flags for UK Wholesalers
      t.string :wslrexuk, :limit => 200 #A list stock flags for US and other non-UK Wholesalers
        
      
      
      
      #3.23 Cover images (jackets) ==============================================
      
      t.string :imagflag, :limit => 10 #Has image? 'y' if so
      
      #non Nielsen fields - internal use
      t.boolean :divert_image #if Nielsen tell us that an image needs to be replaced immediately and the image in question is likely to remain in cache on the CDN for some time, we can divert to an alternative location
      t.string :divert_image_url, :limit => 200 #the actual location of the image we should divert to
      
      t.timestamps      
    end
    
    #Add indexes
    add_index :products, :ausadi1
    add_index :products, :ausadi2
    add_index :products, :pubpd   
    add_index :products, :bic2sc1
    add_index :products, :bic2sc2
    add_index :products, :bic2sc3
    add_index :products, :bic2sc4
    add_index :products, :bic2sc5      
    add_index :products, :isbn13
    add_index :products, :product_department_id
    add_index :products, :product_data_supplier_id
    
  end

  def self.down
    
    #remove indexes
    remove_index :products, :ausadi1
    remove_index :products, :ausadi2
    remove_index :products, :pubpd   
    remove_index :products, :bic2sc1
    remove_index :products, :bic2sc2
    remove_index :products, :bic2sc3
    remove_index :products, :bic2sc4
    remove_index :products, :bic2sc5      
    remove_index :products, :isbn13
    remove_index :products, :product_department_id
    remove_index :products, :product_data_supplier_id
    
    drop_table :products
  end
end
