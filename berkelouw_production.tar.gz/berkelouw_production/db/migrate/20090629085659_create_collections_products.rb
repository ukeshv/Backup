class CreateCollectionsProducts < ActiveRecord::Migration
  def self.up
    create_table :collections_products, :id => false do |t|
      t.integer :collection_id, :null => false
      t.integer :product_id, :null => false
    end
  end

  def self.down
    drop_table :collections_products
  end
end
