class CreateShops < ActiveRecord::Migration
  def self.up
    create_table :shops do |t|
      t.string :name
      t.text :description
      t.integer :manager_id
      t.string :address1
      t.string :address2
      t.string :suburb
      t.string :state
      t.string :postcode
      t.string :country
      t.text :opening_hours
      t.string :tel
      t.string :fax
      t.string :email

      t.timestamps
    end
  end

  def self.down
    drop_table :shops
  end
end
