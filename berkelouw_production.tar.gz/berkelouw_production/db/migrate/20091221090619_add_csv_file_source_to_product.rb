class AddCsvFileSourceToProduct < ActiveRecord::Migration
  def self.up
    add_column :products, :csv_file_source, :string, :limit => 100
  end

  def self.down
    remove_column :products, :csv_file_source
  end
end
