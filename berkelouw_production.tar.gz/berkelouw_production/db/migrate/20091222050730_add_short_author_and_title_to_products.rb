class AddShortAuthorAndTitleToProducts < ActiveRecord::Migration
  def self.up
    #creating these EXTRA columns to the products table because currently, Nielsen recommends 4 - 500 chars 
    #for both fields and as such, we have to use a non indexable (at least not with ease)
    #TEXT type column. We'll duplicate the data in this case so that we can index the first 200 chars of both fields
    
    add_column :products, :short_author, :string, :limit => 200
    add_column :products, :short_title, :string, :limit => 200
    add_index :products, :short_author
    add_index :products, :short_title
  end

  def self.down
    remove_index :products, :short_author
    remove_index :products, :short_title
    
    remove_column :products, :short_author
    remove_column :products, :short_title
  end
end
