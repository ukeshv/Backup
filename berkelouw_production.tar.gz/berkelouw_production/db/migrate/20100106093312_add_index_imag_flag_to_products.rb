class AddIndexImagFlagToProducts < ActiveRecord::Migration
  def self.up
    add_index :products, :imagflag
  end

  def self.down
    remove_index :products, :imagflag
  end
end
