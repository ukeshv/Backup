class AddBerkelouwNameToGenres < ActiveRecord::Migration
  def self.up
    add_column :genres, :berkelouw_name, :string
  end

  def self.down
    remove_column :genres, :berkelouw_name
  end
end
