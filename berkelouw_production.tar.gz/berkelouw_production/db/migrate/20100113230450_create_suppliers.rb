class CreateSuppliers < ActiveRecord::Migration
  def self.up
    create_table :suppliers do |t|
      t.integer :nbd_org_id, :uniqe => true
      t.string :nbd_org_name
      t.boolean :use
      t.integer :preference
      t.integer :contact_id

      t.timestamps
    end
    
    add_index :suppliers, :nbd_org_id
    add_index :suppliers, :contact_id
  end

  def self.down
    remove_index :suppliers, :nbd_org_id
    remove_index :suppliers, :contact_id
    
    drop_table :suppliers
  end
end
