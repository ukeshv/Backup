class CreateContacts < ActiveRecord::Migration
  def self.up
    create_table :contacts do |t|
      t.string :first_name
      t.string :last_name
      t.string :email
      t.string :work_telephone
      t.string :home_telephone
      t.string :mobile
      t.string :fax
      t.integer :contact_type_id

      t.timestamps
    end
    
    add_index :contacts, :contact_type_id
  end

  def self.down
    remove_index :contacts, :contact_type_id
    
    drop_table :contacts
  end
end
