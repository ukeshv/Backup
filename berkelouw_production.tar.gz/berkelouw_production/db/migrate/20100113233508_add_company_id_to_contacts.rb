class AddCompanyIdToContacts < ActiveRecord::Migration
  def self.up
    add_column :contacts, :company_id, :integer
    add_index :contacts, :company_id
  end

  def self.down
    remove_index :contacts, :company_id
    
    remove_column :contacts, :company_id
  end
end
