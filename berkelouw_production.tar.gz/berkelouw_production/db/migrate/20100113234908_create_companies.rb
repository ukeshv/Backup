class CreateCompanies < ActiveRecord::Migration
  def self.up
    create_table :companies do |t|
      t.string :name, :unique => true
      t.string :telephone
      t.string :fax
      t.string :website
      t.string :email
      t.integer :contact_id
      t.integer :company_type_id

      t.timestamps
    end
    
    add_index :companies, :contact_id
    add_index :companies, :company_type_id
  end

  def self.down
    remove_index :companies, :contact_id
    remove_index :companies, :company_type_id
    
    drop_table :companies
  end
end
