class AddCompanyIdToSupplier < ActiveRecord::Migration
  def self.up
    add_column :suppliers, :company_id, :integer, :unique => true
    add_index :suppliers, :company_id
  end

  def self.down
    remove_index :suppliers, :company_id
    remove_column :suppliers, :company_id
  end
end
