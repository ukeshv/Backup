class CreateAddressTypesAddresses < ActiveRecord::Migration
  def self.up
    create_table :address_types_addresses, :id => false do |t|
      t.references :address_type
      t.references :address

      t.timestamps
    end
    
    add_index :address_types_addresses, :address_type_id
    add_index :address_types_addresses, :address_id
  end

  def self.down
    remove_index :address_types_addresses, :address_type_id
    remove_index :address_types_addresses, :address_id
    
    drop_table :address_types_addresses
  end
end
