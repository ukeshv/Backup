class AddCompanyIdToAddresses < ActiveRecord::Migration
  def self.up
    add_column :addresses, :company_id, :integer
    add_index :addresses, :company_id
  end

  def self.down
    remove_index :addresses, :company_id
    remove_column :addresses, :company_id
  end
end
