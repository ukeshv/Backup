class CreateProductContentTypes < ActiveRecord::Migration
  def self.up
    create_table :product_content_types do |t|
      t.string :code, :unique => true
      t.string :name
      t.text :description
      t.boolean :use, :default => 1

      t.timestamps
    end
    
    add_index :product_content_types, :code
  end

  def self.down
    remove_index :product_content_types, :code
    
    drop_table :product_content_types
  end
end