class RemoveShortAuthorShortTitleFromProducts < ActiveRecord::Migration
  def self.up
    #Ditching Short versions as now redundant with the introduction of Sphinx
    #and the ability to index text
    
    remove_index :products, :short_author
    remove_index :products, :short_title
    
    remove_column :products, :short_author
    remove_column :products, :short_title
  end

  def self.down
    
    add_column :products, :short_author, :string, :limit => 200
    add_column :products, :short_title, :string, :limit => 200
    
    add_index :products, :short_author
    add_index :products, :short_title
  end
end
