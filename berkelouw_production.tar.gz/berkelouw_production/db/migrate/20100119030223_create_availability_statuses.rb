class CreateAvailabilityStatuses < ActiveRecord::Migration
  def self.up
    create_table :availability_statuses do |t|
      t.integer :code, :unique => true
      t.string :name
      t.text :description

      t.timestamps
    end
    
    add_index :availability_statuses, :code
    
  end

  def self.down
    remove_index :availability_statuses, :code
    drop_table :availability_statuses
  end
end
