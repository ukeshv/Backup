class CreateProductsSuppliers < ActiveRecord::Migration
  def self.up
    create_table :products_suppliers, :id => false do |t|
      t.references :product
      t.references :supplier

      t.timestamps
    end
    
    add_index :products_suppliers, :product_id
    add_index :products_suppliers, :supplier_id
  end

  def self.down
    remove_index :products_suppliers, :product_id
    remove_index :products_suppliers, :supplier_id
    
    drop_table :products_suppliers
  end
end
