class CreateDataMismatches < ActiveRecord::Migration
  def self.up
    create_table :data_mismatches do |t|
      t.integer :data_mismatch_type_id
      t.integer :product_id
      t.string :mismatch_data

      t.timestamps
    end
    
    add_index :data_mismatches, :product_id
    add_index :data_mismatches, :data_mismatch_type_id
  end

  def self.down
    
    remove_index :data_mismatches, :product_id
    remove_index :data_mismatches, :data_mismatch_type_id
    
    drop_table :data_mismatches
  end
end
