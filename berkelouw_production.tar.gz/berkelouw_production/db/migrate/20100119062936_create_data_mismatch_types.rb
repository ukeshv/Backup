class CreateDataMismatchTypes < ActiveRecord::Migration
  def self.up
    create_table :data_mismatch_types do |t|
      t.string :name
      t.text :description

      t.timestamps
    end
  end

  def self.down
    drop_table :data_mismatch_types
  end
end
