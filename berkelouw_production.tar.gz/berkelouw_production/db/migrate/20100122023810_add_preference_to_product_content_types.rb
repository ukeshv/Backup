class AddPreferenceToProductContentTypes < ActiveRecord::Migration
  def self.up
    add_column :product_content_types, :preference, :integer
  end

  def self.down
    remove_column :product_content_types, :preference
  end
end
