class AddProductContentTypeIdToProducts < ActiveRecord::Migration
  def self.up
    add_column :products, :product_content_type_id, :integer, :default => 0
    add_index :products, :product_content_type_id
  end

  def self.down
    remove_index :products, :product_content_type_id
    remove_column :products, :product_content_type_id
  end
end
