class AddUseAndPreferenceToAvailabilityStatus < ActiveRecord::Migration
  def self.up
    add_column :availability_statuses, :use, :boolean, :default => 1
    add_column :availability_statuses, :preference, :integer, :default => 0
  end

  def self.down
    remove_column :availability_statuses, :use
    remove_column :availability_statuses, :preference
  end
end
