class AddAvailabilityStatusIdToProduct < ActiveRecord::Migration
   def self.up
    add_column :products, :availability_status_id, :integer, :default => 0
    add_index :products, :availability_status_id
  end

  def self.down
    remove_index :products, :availability_status_id
    remove_column :products, :availability_status_id
  end
end
