class CreateProductCategories < ActiveRecord::Migration
  def self.up
    create_table :product_categories do |t|
      t.string :name, :unique => true
      t.boolean :use, :default => 1
      t.integer :preference, :default => 1

      t.timestamps
    end
    
    add_index :product_categories, :use

  end

  def self.down
    remove_index :product_categories, :use
    
    drop_table :product_categories
  end
end
