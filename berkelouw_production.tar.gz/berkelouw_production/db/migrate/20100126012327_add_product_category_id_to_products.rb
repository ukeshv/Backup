class AddProductCategoryIdToProducts < ActiveRecord::Migration
  def self.up
    add_column :products, :product_category_id, :integer
    
    add_index :products, :product_category_id
  end

  def self.down
    remove_index :products, :product_category_id
    
    remove_column :products, :product_category_id
  end
end
