class CreatePublishingStatuses < ActiveRecord::Migration
  def self.up
    create_table :publishing_statuses do |t|
      t.string :code, :unique => true
      t.string :name, :unique => true
      t.string :description
      t.boolean :use, :default => 1
      t.integer :preference, :default => 0

      t.timestamps
    end
    
    add_index :publishing_statuses, :code
  end

  def self.down
    remove_index :publishing_statuses, :code
    drop_table :publishing_statuses
  end
end
