class AddPublishingStatusIdToProduct < ActiveRecord::Migration
  def self.up
    add_column :products, :publishing_status_id, :integer, :default => 0
    add_index :products, :publishing_status_id
  end

  def self.down
    remove_index :products, :publishing_status_id
    remove_column :products, :publishing_status_id  
  end
end
