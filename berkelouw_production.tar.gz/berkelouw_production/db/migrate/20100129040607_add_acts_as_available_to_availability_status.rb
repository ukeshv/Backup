class AddActsAsAvailableToAvailabilityStatus < ActiveRecord::Migration
  def self.up
    add_column :availability_statuses, :acts_as_available, :boolean, :default => 0
    add_index :availability_statuses, :acts_as_available
  end

  def self.down
    remove_index :availability_statuses, :acts_as_available
    remove_column :availability_statuses, :acts_as_available
  end
end
