class AddActsAsAvailableToPublishingStatuses < ActiveRecord::Migration
   def self.up
    add_column :publishing_statuses, :acts_as_available, :boolean, :default => 0
    add_index :publishing_statuses, :acts_as_available
  end

  def self.down
    remove_index :publishing_statuses, :acts_as_available
    remove_column :publishing_statuses, :acts_as_available
  end
end
