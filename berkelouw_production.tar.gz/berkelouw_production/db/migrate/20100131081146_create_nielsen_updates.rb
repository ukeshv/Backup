class CreateNielsenUpdates < ActiveRecord::Migration
  def self.up
    create_table :nielsen_updates do |t|
      t.string :source_file
      t.date :start_ftp_download
      t.date :finish_ftp_download
      t.string :update_type #add, del, upd
      t.date :start_data_update
      t.date :end_data_update
      t.integer :number_of_records_updated
      t.boolean :success, :default => 0
      t.text :error
      t.text :notes

      t.timestamps
    end
  end

  def self.down
    drop_table :nielsen_updates
  end
end
