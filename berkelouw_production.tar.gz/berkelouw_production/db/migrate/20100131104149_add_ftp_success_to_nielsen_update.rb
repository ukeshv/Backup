class AddFtpSuccessToNielsenUpdate < ActiveRecord::Migration
  def self.up
    add_column :nielsen_updates, :ftp_success, :boolean, :default => 0
  end

  def self.down
    remove_column :nielsen_updates, :ftp_success
  end
end
