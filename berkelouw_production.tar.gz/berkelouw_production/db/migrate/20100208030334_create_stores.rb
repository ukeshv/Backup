class CreateStores < ActiveRecord::Migration
  def self.up
    create_table :stores do |t|
      t.string :name
      t.text :description
      t.integer :manager_id
      t.string :address1
      t.string :address2
      t.string :suburb
      t.string :state
      t.string :postcode
      t.string :country
      t.text :opening_hours
      t.string :tel
      t.string :fax
      t.string :email
      t.string :booknet_name
      t.string :image_file_name
      t.string :image_content_type
      t.integer :image_file_size
      t.datetime :image_updated_at
      
      t.timestamps
    end

    add_index :stores, :manager_id
    
  end

  def self.down
    remove_index :stores, :manager_id
    drop_table :stores
  end
end
