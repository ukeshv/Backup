class CreatePlacementLocations < ActiveRecord::Migration
  def self.up
    create_table :placement_locations do |t|
      t.string :name

      t.timestamps
    end
  end

  def self.down
    drop_table :placement_locations
  end
end
