class CreatePlacementLocationsPlacementTypes < ActiveRecord::Migration
  def self.up
    create_table :placement_locations_placement_types, :id => false do |t|
      t.references :placement_location
      t.references :placement_type
      t.timestamps
    end
  end

  def self.down
    drop_table :placement_locations_placement_types
  end
end
