class CreatePlacements < ActiveRecord::Migration
  def self.up
    create_table :placements do |t|
      t.integer :collection_id
      t.integer :feature_id
      t.integer :placement_location_id
      t.integer :specific_placement_location_id
      t.integer :display_order
      t.integer :created_by
      t.integer :updated_by
      t.timestamps
    end
    
    add_index :placements, :collection_id
    add_index :placements, :feature_id
    add_index :placements, :placement_location_id
    add_index :placements, :specific_placement_location_id
    
  end

  def self.down
    drop_table :placements
  end
end
