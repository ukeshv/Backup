class AddPermanentToCollection < ActiveRecord::Migration
  def self.up
    add_column :collections, :permanent, :boolean, :default => 0
    add_index :collections, :permanent
  end

  def self.down
    remove_index :collections, :permanent
    remove_column :collections, :permanent
  end
end
