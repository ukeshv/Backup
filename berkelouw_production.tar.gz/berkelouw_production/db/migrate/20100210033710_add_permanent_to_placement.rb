class AddPermanentToPlacement < ActiveRecord::Migration
  def self.up
    add_column :placements, :permanent, :boolean, :default => 0
    add_index :placements, :permanent
  end

  def self.down
    remove_index :placements, :permanent
    remove_column :placements, :permanent
  end
end
