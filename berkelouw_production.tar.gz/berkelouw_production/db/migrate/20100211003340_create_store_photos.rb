class CreateStorePhotos < ActiveRecord::Migration
  def self.up
   
   create_table :store_photos do |t|
     t.integer :store_id
     t.string :photo_type
     t.string :photo_file_name
     t.string :photo_content_type
     t.integer :photo_file_size
     t.datetime :photo_updated_at      
   end
   
  add_index :store_photos, :store_id
    
  end

  def self.down
    remove_index :store_photos, :store_id
    drop_table :store_photos
  end
end
