class AddSlugToStore < ActiveRecord::Migration
  def self.up
    add_column :stores, :slug, :string
    add_index :stores, :slug
  end

  def self.down
    remove_index :stores, :slug
    remove_column :stores, :slug
  end
end
