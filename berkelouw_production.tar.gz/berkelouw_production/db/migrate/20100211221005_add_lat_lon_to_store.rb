class AddLatLonToStore < ActiveRecord::Migration
  def self.up
    add_column :stores, :latitude, :float
    add_column :stores, :longitude, :float
  end

  def self.down
    remove_column :stores, :latitude
    remove_column :stores, :longitude
  end
end
