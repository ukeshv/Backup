class AlterFeature < ActiveRecord::Migration
  def self.up
    add_column :features, :link_text, :string
    change_column :features, :title, :text
  end

  def self.down
    remove_column :features, :link_text
    change_column :features, :title, :string
  end
end
