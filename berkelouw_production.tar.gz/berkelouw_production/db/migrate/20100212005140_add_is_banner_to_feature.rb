class AddIsBannerToFeature < ActiveRecord::Migration
  def self.up
    add_column :features, :is_banner, :boolean, :default => 0
    add_column :features, :text_align, :string
    add_column :features, :height, :integer, :default => 200
  end

  def self.down
    remove_column :features, :is_banner
    remove_column :features, :text_align
    remove_column :features, :height
  end
end
