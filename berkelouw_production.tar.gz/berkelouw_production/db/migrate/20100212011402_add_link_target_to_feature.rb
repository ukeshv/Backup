class AddLinkTargetToFeature < ActiveRecord::Migration
  def self.up
    add_column :features, :open_in_new_window, :boolean, :default => 0
  end

  def self.down
    remove_column :features, :open_in_new_window
  end
end
