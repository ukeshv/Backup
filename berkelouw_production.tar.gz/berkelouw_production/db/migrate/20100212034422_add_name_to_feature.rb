class AddNameToFeature < ActiveRecord::Migration
  def self.up
    add_column :features, :name, :string
  end

  def self.down
    remove_column :features, :name
  end
end
