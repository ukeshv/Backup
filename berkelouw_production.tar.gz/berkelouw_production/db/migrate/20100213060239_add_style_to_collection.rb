class AddStyleToCollection < ActiveRecord::Migration
  def self.up
    add_column :collections, :css_style, :string, :default => 'wood'
  end

  def self.down
    remove_column :collections, :css_style
  end
end
