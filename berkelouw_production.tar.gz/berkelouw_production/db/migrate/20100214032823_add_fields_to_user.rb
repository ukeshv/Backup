class AddFieldsToUser < ActiveRecord::Migration
  def self.up           

    add_column :users, :email, :string, :unique => true, :null => false
    add_column :users, :crypted_password, :string, :null => false
    add_column :users, :password_salt, :string, :null => false
    add_column :users, :persistence_token, :string, :null => false
    add_column :users, :single_access_token, :string, :null => false
    add_column :users, :perishable_token, :string, :null => false
    add_column :users, :login_count, :integer, :default => 0, :null => false
    add_column :users, :failed_login_count, :integer, :default => 0, :null => false
    add_column :users, :last_request_at, :datetime
    add_column :users, :last_login_at, :datetime
    add_column :users, :current_login_at, :datetime
    add_column :users, :last_login_ip, :string
    add_column :users, :current_login_ip, :string
    
    add_column :users, :address_1, :string
    add_column :users, :address_2, :string
    add_column :users, :suburb, :string
    add_column :users, :state, :string
    add_column :users, :postcode, :string
    add_column :users, :country, :string
    add_column :users, :country_code, :string
    
    add_index :users, :email
    add_index :users, :persistence_token
    add_index :users, :last_request_at  
    
  end

  def self.down
    
    remove_index :users, :email
    remove_index :users, :persistence_token
    remove_index :users, :last_request_at  
    
    remove_column :users, :email
    remove_column :users, :crypted_password
    remove_column :users, :password_salt
    remove_column :users, :persistence_token
    remove_column :users, :single_access_token
    remove_column :users, :perishable_token
    remove_column :users, :login_count
    remove_column :users, :failed_login_count
    remove_column :users, :last_request_at
    remove_column :users, :last_login_at
    remove_column :users, :current_login_at
    remove_column :users, :last_login_ip
    remove_column :users, :current_login_ip
    
    remove_column :users, :address_1
    remove_column :users, :address_2
    remove_column :users, :suburb
    remove_column :users, :state
    remove_column :users, :postcode
    remove_column :users, :country
    remove_column :users, :country_code
 
  end
end
