class AddDisplayNameTopLelvelToGenre < ActiveRecord::Migration
  def self.up
    add_column :genres, :is_top_level, :boolean, :default => 0
    
    add_index :genres, :is_top_level
    add_index :genres, :code
    
  end

  def self.down
    remove_index :genres, :is_top_level
    remove_index :genres, :code
    
    remove_column :genres, :is_top_level
  end
end
