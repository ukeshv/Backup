class AddGenreTypeToGenres < ActiveRecord::Migration
  def self.up
    add_column :genres, :genre_type_id, :integer
    add_index :genres, :genre_type_id
  end

  def self.down
    remove_index :genres, :genre_type_id
    remove_column :genres, :genre_type_id
  end
end
