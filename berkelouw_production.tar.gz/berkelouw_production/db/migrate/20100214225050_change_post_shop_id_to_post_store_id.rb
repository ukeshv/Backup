class ChangePostShopIdToPostStoreId < ActiveRecord::Migration
  def self.up
    rename_column :posts, :shop_id, :store_id
  end

  def self.down
    rename_column :posts, :store_id, :shop_id
  end
end
