class AddPostIdToPlacement < ActiveRecord::Migration
  def self.up
    add_column :placements, :post_id, :integer
    add_index :placements, :post_id
  end

  def self.down
    remove_index :placements, :post_id
    remove_column :placements, :post_id
  end
end
