class CreateCollectionTypes < ActiveRecord::Migration
  def self.up
    create_table :collection_types do |t|
      t.string :name

      t.timestamps
    end
    
    #Create some base types if they dont exist
      
      types = ["Grouped bookshelf", "Individual bookshelf", "Grouped collection", "Individual collection"]
      types.each do |t|
        CollectionType.find_or_create_by_name(t)
      end
    
  end

  def self.down
    drop_table :collection_types
  end
end
