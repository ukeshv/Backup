class CreateCollectionStyles < ActiveRecord::Migration
  def self.up
    create_table :collection_styles do |t|
      t.string :name
      t.string :background_repeat
      t.string :background_color

      t.timestamps
    end
  end

  def self.down
    drop_table :collection_styles
  end
end
