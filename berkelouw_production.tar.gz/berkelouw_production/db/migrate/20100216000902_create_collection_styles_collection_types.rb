class CreateCollectionStylesCollectionTypes < ActiveRecord::Migration
  def self.up
    create_table :collection_styles_collection_types, :id => false do |t|
      t.references :collection_style
      t.references :collection_type
      t.timestamps
    end
    add_index :collection_styles_collection_types, :collection_style_id
    add_index :collection_styles_collection_types, :collection_type_id
  end

  def self.down
    drop_table :collection_styles_collection_types
  end
end
