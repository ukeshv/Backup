class AddCollectionTypeIdToPlacement < ActiveRecord::Migration
  def self.up
    add_column :placements, :collection_type_id, :integer
    add_index :placements, :collection_type_id
  end

  def self.down
    remove_index :placements, :collection_type_id
    remove_column :placements, :collection_type_id
  end
end
