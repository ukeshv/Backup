class AddBackgroundPositionToCollectionStyle < ActiveRecord::Migration
  def self.up
    add_column :collection_styles, :background_position, :string
  end

  def self.down
     remove_column :collection_styles, :background_position
  end
end
