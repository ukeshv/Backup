class AddPlacementCollectionStyleId < ActiveRecord::Migration
  def self.up 
    add_column    :placements,  :collection_style_id, :integer
    add_index     :placements,  :collection_style_id
  end

  def self.down
      
    remove_index  :placements,  :collection_style_id
    remove_column :placements,  :collection_style_id
    
  end
end
