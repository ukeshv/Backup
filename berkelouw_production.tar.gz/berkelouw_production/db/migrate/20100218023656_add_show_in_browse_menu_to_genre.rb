class AddShowInBrowseMenuToGenre < ActiveRecord::Migration
  def self.up
    add_column      :genres, :show_in_browse_menu, :boolean, :default => 0
    add_index       :genres, :show_in_browse_menu
  end

  def self.down
    remove_index    :genres, :show_in_browse_menu
    remove_column   :genres, :show_in_browse_menu
  end
end
