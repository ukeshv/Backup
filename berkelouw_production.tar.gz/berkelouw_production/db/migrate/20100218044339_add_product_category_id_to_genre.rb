class AddProductCategoryIdToGenre < ActiveRecord::Migration
  def self.up
    add_column  :genres, :product_category_id, :integer
    add_index   :genres, :product_category_id
  end

  def self.down
    remove_index   :genres, :product_category_id
    remove_column  :genres, :product_category_id
  end
end
