class CreateOrders < ActiveRecord::Migration
  def self.up
    create_table :orders do |t|
      t.integer :user_id
      t.string :email
      t.string :phone_number
      t.string :ship_to_first_name
      t.string :ship_to_last_name
      t.string :ship_to_address_1
      t.string :ship_to_address_2
      t.string :ship_to_suburb
      t.string :ship_to_state
      t.string :ship_to_postcode
      t.string :ship_to_country
      t.string :customer_ip
      t.string :status, :default => 'open'
      t.string :error_message

      t.timestamps
    end
    
    add_index :orders, :user_id
    add_index :orders, :customer_ip
  end

  def self.down
    remove_index :orders, :user_id
    remove_index :orders, :customer_ip
    drop_table :orders
  end
end
