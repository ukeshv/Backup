class CreateOrderItems < ActiveRecord::Migration
  def self.up
    create_table :order_items do |t|
      t.integer :order_id
      t.integer :product_id
      t.integer :price#price is stored in cence for active merchant
      t.integer :quantity

      t.timestamps
    end
    
    add_index :order_items, :order_id
    add_index :order_items, :product_id
  end

  def self.down
    remove_index :order_items, :order_id
    remove_index :order_items, :product_id
    drop_table :order_items
  end
end
