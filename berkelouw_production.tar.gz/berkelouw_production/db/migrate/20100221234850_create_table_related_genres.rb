class CreateTableRelatedGenres < ActiveRecord::Migration
  def self.up
    create_table "related_genres", :force => true, :id => false do |t|
      t.column "sub_genre_id", :integer
      t.column "parent_genre_id", :integer
    end
    add_index :related_genres, :sub_genre_id
    add_index :related_genres, :parent_genre_id
  end

  def self.down
    remove_index :related_genres, :sub_genre_id
    remove_index :related_genres, :parent_genre_id
    drop_table :related_genres
  end
end
