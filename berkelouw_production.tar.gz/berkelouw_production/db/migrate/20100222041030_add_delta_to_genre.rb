class AddDeltaToGenre < ActiveRecord::Migration
  def self.up
    add_column :genres, :delta, :boolean, :default => true, :null => false
  end

  def self.down
    remove_column :genres, :delta
  end
end