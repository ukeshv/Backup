class AddRareFieldsToProduct < ActiveRecord::Migration
  #begrudgingly creating separate date field to hold booksoft exported date in string format
    
  def self.up
    add_column      :products,    :rare_pubpd,    :string
  end

  def self.down
    remove_column   :products,    :rare_pubpd
  end
end
