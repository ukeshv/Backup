class CreateBooksoftImports < ActiveRecord::Migration
  def self.up
    create_table :booksoft_imports do |t|
      t.integer :user_id
      t.string :source_file
      t.text :error_message
      t.boolean :success, :default => 0
      t.string :update_type
      t.text :notes
      t.integer :records_affected
      t.datetime :update_start
      t.datetime :update_end

      t.timestamps
    end
    
    add_index :booksoft_imports, :user_id
  end

  def self.down
    remove_index :booksoft_imports, :user_id
    drop_table :booksoft_imports
  end
end
