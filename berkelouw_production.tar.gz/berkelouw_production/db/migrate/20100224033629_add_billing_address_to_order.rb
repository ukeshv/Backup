class AddBillingAddressToOrder < ActiveRecord::Migration
  def self.up
    add_column :orders, :billing_first_name, :string
    add_column :orders, :billing_last_name, :string
    add_column :orders, :billing_email, :string
    add_column :orders, :billing_phone, :string
    add_column :orders, :billing_address_1, :string
    add_column :orders, :billing_address_2, :string
    add_column :orders, :billing_suburb, :string
    add_column :orders, :billing_state, :string
    add_column :orders, :billing_postcode, :string
    add_column :orders, :billing_country, :string
    add_column :orders, :billing_country_code, :string
    
    add_column :orders, :ship_to_country_code, :string
  end

  def self.down
    remove_column :orders, :billing_first_name
    remove_column :orders, :billing_last_name
    remove_column :orders, :billing_email
    remove_column :orders, :billing_phone
    remove_column :orders, :billing_address_1
    remove_column :orders, :billing_address_2
    remove_column :orders, :billing_suburb
    remove_column :orders, :billing_state
    remove_column :orders, :billing_postcode
    remove_column :orders, :billing_country
    remove_column :orders, :billing_country_code
    
    remove_column :orders, :ship_to_country_code
  end
end
