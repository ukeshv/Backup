class CreateCountries < ActiveRecord::Migration
  def self.up
    create_table :countries do |t|
      t.string :name
      t.string :code
      t.integer :shipping_region_id

      t.timestamps
    end
    
    add_index :countries, :shipping_region_id
    
  end

  def self.down
    remove_index :countries, :shipping_region_id
    drop_table :countries
  end
end
