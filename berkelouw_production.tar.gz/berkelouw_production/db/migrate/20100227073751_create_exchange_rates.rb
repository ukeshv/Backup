class CreateExchangeRates < ActiveRecord::Migration
  def self.up
    create_table :exchange_rates do |t|
      t.string :code
      t.float :rate
      t.timestamps
    end
    
    add_index :exchange_rates, :code
  end

  def self.down
    drop_table :exchange_rates
  end
end
