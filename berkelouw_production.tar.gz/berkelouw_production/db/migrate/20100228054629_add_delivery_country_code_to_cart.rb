class AddDeliveryCountryCodeToCart < ActiveRecord::Migration
  def self.up
    add_column :carts, :delivery_country_code, :string, :default => "AU"
  end

  def self.down
    remove_column :carts, :delivery_country_code
  end
end
