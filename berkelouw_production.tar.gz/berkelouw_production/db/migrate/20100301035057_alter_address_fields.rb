class AlterAddressFields < ActiveRecord::Migration
  def self.up
     rename_column :addresses, :address1, :address_1
     rename_column :addresses, :address2, :address_2
     rename_column :addresses, :city, :suburb
  end

  def self.down
    rename_column :addresses, :address_1, :address1
     rename_column :addresses, :address_2, :address2
     rename_column :addresses, :suburb, :city
  end
end
