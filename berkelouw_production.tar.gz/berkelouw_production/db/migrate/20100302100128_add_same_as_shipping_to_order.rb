class AddSameAsShippingToOrder < ActiveRecord::Migration
  def self.up
    add_column :orders, :same_as_shipping, :boolean, :default => 1
  end

  def self.down
    remove_column :orders, :same_as_shipping
  end
end
