class AddEndDateAndPriceToEvent < ActiveRecord::Migration
  def self.up
    add_column :events, :end_date, :datetime
    add_column :events, :price, :string
    
    add_index :events, :event_date
    add_index :events, :end_date
  end

  def self.down
    remove_index :events, :event_date
    remove_index :events, :end_date
    
    remove_column :events, :price
    remove_column :events, :end_date
  end
end
