class RenameEventProductId < ActiveRecord::Migration
  def self.up
    remove_column :events, :product_id
    add_column :events, :isbn13, :string
    
    add_index :events, :isbn13
  end

  def self.down
    remove_index :events, :isbn13
    
    remove_column :events, :isbn13
    add_column :events, :product_id, :integer 
  end
end
