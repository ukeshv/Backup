class AddProductTitleAndProductIdToEvent < ActiveRecord::Migration
  def self.up
    add_column :events, :product_id, :integer
    
    add_index :events, :product_id
  end

  def self.down
    remove_index :events, :product_id
    
    remove_column :events, :product_id
  end
end
