class AddLocationNameToEvent < ActiveRecord::Migration
  def self.up
    add_column :events, :location_name, :string
    add_column :events, :sold_out, :boolean, :default => 0
  end

  def self.down
    remove_column :events, :location_name
    remove_column :events, :sold_out
  end
end
