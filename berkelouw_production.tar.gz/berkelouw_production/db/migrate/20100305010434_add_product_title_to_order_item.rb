class AddProductTitleToOrderItem < ActiveRecord::Migration
  def self.up
    add_column :order_items, :product_name, :text
    add_column :order_items, :discounts, :string #store any discounts that apply to this item (members, bookclub etc)
  end

  def self.down
    remove_column :order_items, :product_name
    remove_column :order_items, :discounts
  end
end