class AddMaskedCardNumberToOrderAndOrderTransaction < ActiveRecord::Migration
  def self.up
    add_column :orders, :masked_card_number, :string
    add_column :order_transactions, :masked_card_number, :string
  end

  def self.down
    remove_column :orders, :masked_card_number
    remove_column :order_transactions, :masked_card_number
  end
end
