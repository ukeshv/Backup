class ChangeOrderITemPriceType < ActiveRecord::Migration
  def self.up
    change_column :order_items, :price, :float
  end

  def self.down
    change_column :order_items, :price, :integer
  end
end
