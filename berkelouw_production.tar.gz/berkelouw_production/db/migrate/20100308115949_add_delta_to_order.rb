class AddDeltaToOrder < ActiveRecord::Migration
  def self.up
    add_column :orders, :delta, :boolean, :default => true, :null => false
  end

  def self.down
    remove_column :orders, :delta
  end
end