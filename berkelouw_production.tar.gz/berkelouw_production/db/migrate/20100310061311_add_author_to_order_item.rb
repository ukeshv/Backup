class AddAuthorToOrderItem < ActiveRecord::Migration
  
  def self.up
    add_column :order_items, :author, :text
  end

  def self.down
    remove_column :order_items, :author
  end
  
end
