class AddToAndFromNamesToEmailEnquiry < ActiveRecord::Migration
  def self.up
    add_column :email_enquiries, :to_name, :string
    add_column :email_enquiries, :from_name, :string
  end

  def self.down
    from_column :email_enquiries, :to_name
    from_column :email_enquiries, :from_name
  end
end
