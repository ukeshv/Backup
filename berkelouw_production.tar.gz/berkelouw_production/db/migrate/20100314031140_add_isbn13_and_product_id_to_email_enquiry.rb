class AddIsbn13AndProductIdToEmailEnquiry < ActiveRecord::Migration
  def self.up
    add_column :email_enquiries, :product_id, :integer
    add_column :email_enquiries, :isbn13, :string
    add_column :email_enquiries, :user_id, :integer
    
    add_index :email_enquiries, :product_id
    add_index :email_enquiries, :user_id
  end

  def self.down
    remove_index :email_enquiries, :product_id
    remove_index :email_enquiries, :user_id
    
    remove_column :email_enquiries, :product_id
    remove_column :email_enquiries, :isbn13
    remove_column :email_enquiries, :user_id
  end
end
