class AddTelephoneToEmailEnquiry < ActiveRecord::Migration
  def self.up
    add_column :email_enquiries, :telephone, :string
  end

  def self.down
    remove_column :email_enquiries, :telephone
  end
end
