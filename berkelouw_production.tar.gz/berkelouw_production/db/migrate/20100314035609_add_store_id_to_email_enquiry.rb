class AddStoreIdToEmailEnquiry < ActiveRecord::Migration
  def self.up
    add_column :email_enquiries, :store_id, :integer
    
    add_index :email_enquiries, :store_id
  end

  def self.down
    remove_index :email_enquiries, :store_id
    remove_column :email_enquiries, :store_id
  end
end
