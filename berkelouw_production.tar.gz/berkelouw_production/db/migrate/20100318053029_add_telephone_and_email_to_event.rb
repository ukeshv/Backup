class AddTelephoneAndEmailToEvent < ActiveRecord::Migration
  def self.up
    add_column :events, :telephone, :string
    add_column :events, :email, :string
    add_column :events, :rsvp, :date
  end

  def self.down
    remove_column :events, :telephone
    remove_column :events, :email
    remove_column :events, :rsvp
  end
end
