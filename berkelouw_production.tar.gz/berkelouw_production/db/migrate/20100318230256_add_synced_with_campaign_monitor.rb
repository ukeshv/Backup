class AddSyncedWithCampaignMonitor < ActiveRecord::Migration
  def self.up
    add_column :users, :synced_with_campaign_monitor, :boolean
  end

  def self.down
    remove_column :users, :synced_with_campaign_monitor
  end
end
