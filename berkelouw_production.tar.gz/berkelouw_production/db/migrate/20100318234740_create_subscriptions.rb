class CreateSubscriptions < ActiveRecord::Migration
  def self.up
    create_table :subscriptions do |t|
      t.string :email
      t.string :full_name
      t.integer :list_id

      t.timestamps
    end
    
    add_index :subscriptions, :email
  end

  def self.down
    remove_index :subscriptions, :email
    drop_table :subscriptions
  end
end
