class AddCmListIdToList < ActiveRecord::Migration
  def self.up
    add_column :lists, :cm_list_id, :string   
    add_index :lists, :cm_list_id
    
  end

  def self.down
    remove_index :lists, :cm_list_id
    remove_column :lists, :cm_list_id
  end
end