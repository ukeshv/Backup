class AddSyncedWithCmToSubscription < ActiveRecord::Migration
  def self.up
    add_column :subscriptions, :synced_with_campaign_monitor, :boolean
    add_index :subscriptions, :synced_with_campaign_monitor
  end

  def self.down
    remove_index :subscriptions, :synced_with_campaign_monitor
    remove_column :subscriptions, :synced_with_campaign_monitor
  end
end
