class AddCmCodeToSubscription < ActiveRecord::Migration
  def self.up
    add_column :subscriptions, :campain_monitor_response_code, :string
    add_index :subscriptions, :campain_monitor_response_code
  end

  def self.down
    remove_index :subscriptions, :campain_monitor_response_code
    remove_column :subscriptions, :campain_monitor_response_code
  end
end
