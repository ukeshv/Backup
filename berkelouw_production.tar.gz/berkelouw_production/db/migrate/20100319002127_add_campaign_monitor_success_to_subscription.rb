class AddCampaignMonitorSuccessToSubscription < ActiveRecord::Migration
  def self.up
    add_column :subscriptions, :campaign_monitor_success, :boolean, :default => 0
    add_index :subscriptions, :campaign_monitor_success
  end

  def self.down
    remove_index :subscriptions, :campaign_monitor_success
    remove_column :subscriptions, :campaign_monitor_success
  end
end
