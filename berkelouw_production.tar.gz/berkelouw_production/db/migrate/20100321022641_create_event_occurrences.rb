class CreateEventOccurrences < ActiveRecord::Migration
  def self.up
    create_table :event_occurrences do |t|
      t.datetime :start_date
      t.datetime :end_date
      t.integer :event_id

      t.timestamps
    end
    
    add_index :event_occurrences, :event_id
  end

  def self.down
    remove_index :event_occurrences, :event_id
    drop_table :event_occurrences
  end
end
