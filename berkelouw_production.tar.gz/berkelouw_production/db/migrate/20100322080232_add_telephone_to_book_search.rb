class AddTelephoneToBookSearch < ActiveRecord::Migration
  def self.up
    add_column :book_searches, :telephone, :string
    add_column :book_searches, :user_id, :integer
    
    add_index :book_searches, :user_id
  end

  def self.down
    remove_index :book_searches, :user_id
    
    remove_column :book_searches, :telephone
    remove_column :book_searches, :user_id
  end
end
