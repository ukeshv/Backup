class AddPublishDateToBookSearch < ActiveRecord::Migration
  def self.up
    add_column :book_searches, :publish_date, :string
  end

  def self.down
    remove_column :book_searches, :publish_date
  end
end
