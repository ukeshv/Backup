class AddRecurringToEvent < ActiveRecord::Migration
  def self.up
    add_column :events, :recurring, :boolean, :default => 0
  end

  def self.down
    remove_column :events, :recurring
  end
end
