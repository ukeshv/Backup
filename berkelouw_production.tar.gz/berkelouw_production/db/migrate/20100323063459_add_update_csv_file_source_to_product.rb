class AddUpdateCsvFileSourceToProduct < ActiveRecord::Migration
  def self.up
    add_column :products, :update_csv_file_source, :string
  end

  def self.down
    remove_column :products, :update_csv_file_source
  end
end
