class AddTelephoneToSubscription < ActiveRecord::Migration
  def self.up
    add_column :subscriptions, :telephone, :string
  end

  def self.down
    remove_column :subscriptions, :telephone
  end
end
