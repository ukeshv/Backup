class AddFurtherDetailsToSubscription < ActiveRecord::Migration
  def self.up
    add_column :subscriptions, :further_details, :text
  end

  def self.down
    add_column :subscriptions, :further_details
  end
end
