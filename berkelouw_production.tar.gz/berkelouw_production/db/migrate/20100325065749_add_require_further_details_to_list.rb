class AddRequireFurtherDetailsToList < ActiveRecord::Migration
  def self.up
    add_column :lists, :require_further_details, :boolean, :default => 0
    add_column :lists, :require_further_details_label, :string
  end

  def self.down
    remove_column :lists, :require_further_details
    remove_column :lists, :require_further_details_label
  end
end
