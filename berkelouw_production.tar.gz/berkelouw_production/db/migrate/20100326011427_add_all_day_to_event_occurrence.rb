class AddAllDayToEventOccurrence < ActiveRecord::Migration
  def self.up
    add_column :event_occurrences, :all_day, :boolean, :default => 0
    add_column :event_occurrences, :ignore_end_date, :boolean, :default => 0
  end

  def self.down
    remove_column :event_occurrences, :all_day
    remove_column :event_occurrences, :ignore_end_date
  end
end
