class CreateEventTimings < ActiveRecord::Migration
  def self.up
    create_table :event_timings do |t|
      t.datetime :start_date
      t.datetime :end_date
      t.integer :event_id
      t.boolean :all_day
      t.boolean :ignore_end_date

      t.timestamps
    end
    
    add_index :event_timings, :event_id
  end

  def self.down
    remove_index :event_timings, :event_id
    drop_table :event_timings
  end
end
