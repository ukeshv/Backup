class AddDefaultAdmins < ActiveRecord::Migration
  def self.up
    User.create(:name=>"admin1",:email=>"admin1@berkelouw.com.au",:password =>"admin123", :password_confirmation =>"admin123")
    User.create(:name=>"admin2",:email=>"admin2@berkelouw.com.au",:password =>"admin123", :password_confirmation =>"admin123")
    User.create(:name=>"admin3",:email=>"admin3@berkelouw.com.au",:password =>"admin123", :password_confirmation =>"admin123")
  end
  def self.down
  end
end
