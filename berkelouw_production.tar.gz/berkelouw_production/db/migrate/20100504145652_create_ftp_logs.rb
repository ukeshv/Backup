class CreateFtpLogs < ActiveRecord::Migration
  def self.up
    create_table :ftp_logs do |t|
      t.string :filename, :local_filepath, :remote_filepath, :status, :message
      t.integer :filesize
      t.boolean :is_extracted
      t.timestamps
    end
  end

  def self.down
    drop_table :ftp_logs
  end
end
