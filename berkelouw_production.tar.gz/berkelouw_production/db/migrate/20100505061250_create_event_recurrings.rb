class CreateEventRecurrings < ActiveRecord::Migration
  def self.up
    create_table :event_recurrings do |t|
    t.integer :event_id
    t.string :every
    t.string :on
    t.string :weekday
    t.string :interval
    t.datetime :until
    t.time :start_time
    t.time :end_time
    t.timestamps
    end
  end

  def self.down
    drop_table :event_recurrings
  end
end
