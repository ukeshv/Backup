class AddFieldsToFtpLogs < ActiveRecord::Migration
  def self.up
    add_column :ftp_logs, :is_imported, :boolean
    add_column :ftp_logs, :exported_file_path, :string
  end

  def self.down
    remove_column :ftp_logs, :is_imported
    remove_column :ftp_logs, :exported_file_path
  end
end
