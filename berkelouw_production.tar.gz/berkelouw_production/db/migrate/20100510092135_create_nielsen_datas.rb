class CreateNielsenDatas < ActiveRecord::Migration
  def self.up
    create_table :nielsen_datas do |t|
      t.string :filename, :remote_filepath, :local_filepath, :extracted_filepath, :update_type, :status, :message
      t.boolean :is_extracted, :is_dumped, :ftp_success
      t.integer :file_size, :updated_records_count
      t.date :ftp_downloaded_on
      t.timestamps
    end
  end

  def self.down
    drop_table :nielsen_datas
  end
end