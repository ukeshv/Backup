class CreateNielsenJobs < ActiveRecord::Migration
  def self.up
    create_table :nielsen_jobs do |t|
      t.string :job_name, :env, :status, :stderr
      t.datetime :started_at, :finished_at
      t.timestamps
    end
  end

  def self.down
    drop_table :nielsen_jobs
  end
end
