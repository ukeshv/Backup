class AddColumnInOrderItem < ActiveRecord::Migration
  def self.up
    add_column :orders, :stage, :integer
    add_column :order_items, :deduction_percentage, :integer
    add_column :order_items, :deduction_amount, :float
    add_column :order_items, :status, :string
  end

  def self.down
    remove_column :orders, :stage
    remove_column :order_items, :deduction_percentage
    remove_column :order_items, :deduction_amount
    remove_column :order_items, :status
  end
end
