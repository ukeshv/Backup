class CreateGardenersStockAvailabilities < ActiveRecord::Migration
  def self.up
    create_table :gardeners_stock_availabilities do |t|
      t.string :isbn13 
      t.integer :available 
      t.timestamps
    end
  end

  def self.down
    drop_table :gardeners_stock_availabilities
  end
end
