class AddOverrideIsbn13InOtherItems < ActiveRecord::Migration
  def self.up
    add_column :order_items, :override_isbn13, :integer
  end

  def self.down
    remove_column :order_items, :override_isbn13
  end
end
