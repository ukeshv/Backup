class AddTaxInProducts < ActiveRecord::Migration
  def self.up
    add_column :products, :tax, :integer, :default => 10
  end

  def self.down
    remove_column :products, :tax
  end
end
