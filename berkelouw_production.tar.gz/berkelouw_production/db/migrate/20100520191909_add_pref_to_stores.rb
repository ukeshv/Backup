class AddPrefToStores < ActiveRecord::Migration
  def self.up
    add_column :stores, :preference, :integer, :default => 0
    add_column :order_items, :preference, :integer, :default => 0
    add_column :order_items, :in_store_check_completed, :boolean, :default => false
  end

  def self.down
    remove_column :stores, :preference
    remove_column :order_items, :preference
    remove_column :order_items, :in_store_check_completed
  end
end
