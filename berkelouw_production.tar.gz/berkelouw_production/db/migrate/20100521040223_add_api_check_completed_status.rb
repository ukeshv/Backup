class AddApiCheckCompletedStatus < ActiveRecord::Migration
  def self.up
    add_column :order_items, :is_api_check_completed, :boolean, :default => false
  end

  def self.down
    remove_column :order_items, :is_api_check_completed
  end
end
