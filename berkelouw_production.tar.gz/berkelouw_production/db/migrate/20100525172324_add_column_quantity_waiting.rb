class AddColumnQuantityWaiting < ActiveRecord::Migration
  def self.up
    add_column :orders, :quantity_waiting,:integer,:default=>0
    add_column :orders, :on_hold, :boolean, :default=>false
    add_column :order_items, :quantity_waiting,:integer,:default=>0
    add_column :order_items, :is_available_from, :string
  end

  def self.down
    remove_column :orders,:quantity_waiting
    remove_column :orders, :on_hold
    remove_column :order_items,:quantity_waiting
    remove_column :order_items, :is_available_from
  end
end
