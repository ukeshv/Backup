class AddFieldNewShippingCostInOrderItems < ActiveRecord::Migration
  def self.up
    add_column :order_items, :new_shipping_cost,:integer
  end

  def self.down
        remove_column :order_items,:new_shipping_cost
  end
end
