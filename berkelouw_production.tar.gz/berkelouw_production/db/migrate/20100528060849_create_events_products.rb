class CreateEventsProducts < ActiveRecord::Migration
  def self.up
    create_table :events_products, :id => false do |t|
      t.integer :event_id, :null => false
      t.integer :product_id, :null => false
    end
  end

  def self.down
    drop_table :events_products
  end
end
