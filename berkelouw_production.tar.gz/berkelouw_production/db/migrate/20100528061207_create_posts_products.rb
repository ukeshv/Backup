class CreatePostsProducts < ActiveRecord::Migration
  def self.up
    create_table :posts_products, :id => false do |t|
      t.integer :post_id, :null => false
      t.integer :product_id, :null => false
    end
  end

  def self.down
    drop_table :posts_products
  end
end
