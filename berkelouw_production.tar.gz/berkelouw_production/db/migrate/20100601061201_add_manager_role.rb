class AddManagerRole < ActiveRecord::Migration
  def self.up
        Role.create(:name=>"manager")
  end

  def self.down
  end
end
