class AddWaitingForStoreResponseInStoreItems < ActiveRecord::Migration
  def self.up
    add_column :order_items, :waiting_for_store_response, :boolean, :default => false
  end

  def self.down
    remove_column :order_items, :waiting_for_store_response
  end
end
