class AddIndexesAndFieldsForDataprocessing < ActiveRecord::Migration
  def self.up
    #~ add_column :products, :csv_supplier_id, :integer
    #~ add_column :products, :repeted_in_tmp_table, :string
    #~ add_index :products, :csv_supplier_id
    #~ add_index :products, :repeted_in_tmp_table
    
    # TODO : uncomment these code after few days of deployment of this file.
    
    #~ add_index :products, :ausnbdpac
    #~ add_index :products, :ausnbdpat
    #~ add_index :products, :pfc
    #~ add_index :products, :pfct
    #~ add_index :products, :pubsc
    #~ add_index :products, :pubst
    #~ add_index :products, :ausadn1
    #~ add_index :products, :ausadn2
    #~ add_index :products, :csv_file_source
    
    #~ add_index :suppliers, :nbd_org_name
    #~ add_index :availability_statuses, :name
    #~ add_index :product_content_types, :name
    #~ add_index :product_categories, :name
    #~ add_index :publishing_statuses, :name
  end

  def self.down
    #~ remove_column :products, :csv_supplier_id
    #~ remove_column :products, :repeted_in_tmp_table
    
    ### WARN: the remove may not work in production (as on 5th May 2010)
    # because I have created index from mysql directly, and those index names are different from what rails generate
    # this will work if fresh migration run in any new DB
    #~ remove_index :products, :ausnbdpac
    #~ remove_index :products, :ausnbdpat
    #~ remove_index :products, :pfc
    #~ remove_index :products, :pfct
    #~ remove_index :products, :pubsc
    #~ remove_index :products, :pubst
    #~ remove_index :products, :ausadn1
    #~ remove_index :products, :ausadn2
    #~ remove_index :products, :csv_file_source

    #~ remove_index :suppliers, :nbd_org_name
    #~ remove_index :availability_statuses, :name
    #~ remove_index :product_content_types, :name
    #~ remove_index :product_categories, :name
    #~ remove_index :publishing_statuses, :name
  end
end










 
