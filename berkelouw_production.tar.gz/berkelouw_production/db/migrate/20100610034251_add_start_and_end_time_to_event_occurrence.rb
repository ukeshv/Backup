class AddStartAndEndTimeToEventOccurrence < ActiveRecord::Migration
  #WARNING: THIS MIGRATION HAS BEEN CREATED TO ADD THE FOLLOWING COLUMNS TO THE DATABASE ON SHAUN'S LOCAL. FOR SOME REASON THE FIELDS ARE NOT 
  #PRESENT AND DON'T APPEAR TO BE IN ANY PREVIOUS MIGRATION
  #I WILL COMMENT THESE OUT AFTER I HAVE RUN THEM
  
  def self.up
    #add_column :event_occurrences, :start_time, :time
    #add_column :event_occurrences, :end_time, :time
  end

  def self.down
    #remove_column :event_occurrences, :start_time
    #remove_column :event_occurrences, :end_time
  end
end
