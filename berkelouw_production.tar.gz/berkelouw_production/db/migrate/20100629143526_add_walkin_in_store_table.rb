class AddWalkinInStoreTable < ActiveRecord::Migration
  def self.up
    add_column :stores, :walk_in, :boolean, :default=>false
    walk_in_stores = ["MONA VALE", "CRONULLA", "BERRIMA", "BOWRAL", "EUMUNDI", "ARMADALE"]
    walk_in_stores.each do |store_name|
      store = Store.find(:first, :conditions => ["booknet_name LIKE ?", "%#{store_name}%"])
      store.update_attribute('walk_in', true) if store
    end
  end

  def self.down
    remove_column :stores, :walk_in
  end
end
