class AddPriceAndDiscountToProducts < ActiveRecord::Migration
  def self.up
    add_column :products, :ingrams_onhand, :integer, :default => 0
    add_column :products, :ingrams_discount, :float, :default => 0.0
    add_column :products, :gardners_onhand, :integer, :default => 0
    add_column :products, :gardners_discount, :float, :default => 0.0
  end

  def self.down
    remove_column :products, :ingrams_onhand
    remove_column :products, :ingrams_discount
    remove_column :products, :gardners_onhand
    remove_column :products, :gardners_discount
  end
end
