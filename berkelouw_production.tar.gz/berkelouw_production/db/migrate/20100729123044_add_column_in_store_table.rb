class AddColumnInStoreTable < ActiveRecord::Migration
  def self.up
    add_column :stores, :stock_confirmation_email_address, :string
  end

  def self.down
    remove_column :stores, :stock_confirmation_email_address
  end
end
