class AddColumnShippingTime < ActiveRecord::Migration
  def self.up
    add_column :cart_items, :shipping_time, :string
    add_column :order_items, :shipping_time, :string
  end

  def self.down
    remove_column :cart_items, :shipping_time
    remove_column :order_items, :shipping_time
  end
end
