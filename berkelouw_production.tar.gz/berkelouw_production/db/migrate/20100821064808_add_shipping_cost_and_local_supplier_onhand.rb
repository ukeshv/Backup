class AddShippingCostAndLocalSupplierOnhand < ActiveRecord::Migration
  def self.up
    add_column :products, :shipping_cost, :float
    add_column :products, :local_supplier_onhand, :integer
  end

  def self.down
    remove_column :products, :shipping_cost
    remove_column :products, :local_supplier_onhand
  end
end
