class AddBookNetDataFieldsInProducts < ActiveRecord::Migration
  def self.up
    add_column :products, :best_seller_preference, :integer
    add_column :products, :new_release_preference, :integer
  end

  def self.down
    delete_column :products, :best_seller_preference
    delete_column :products, :new_release_preference
  end
end
