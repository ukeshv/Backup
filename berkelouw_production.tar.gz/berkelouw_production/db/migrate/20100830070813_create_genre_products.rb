class CreateGenreProducts < ActiveRecord::Migration
  def self.up
    create_table :genre_products do |t|
      t.integer :product_id
      t.integer :genre_id
      t.timestamps
    end
    
    add_index :genre_products, :product_id
    add_index :genre_products, :genre_id
    
  end

  def self.down
    remove_index :genre_products, :product_id
    remove_index :genre_products, :genre_id
    drop_table :genre_products
  end
end
