class AddPriceSupplierInOrderItems < ActiveRecord::Migration
  def self.up
    add_column :order_items, :price_supplier, :string
    add_column :cart_items, :price_supplier, :string
  end

  def self.down
    remove_column :order_items, :price_supplier    
    remove_column :cart_items, :price_supplier    
  end
end
