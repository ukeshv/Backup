class AddIngramsAndGarndersUpdatedAtInProducts < ActiveRecord::Migration
  def self.up
    add_column :products, :ingrams_updated_at, :datetime
    add_column :products, :gardners_updated_at, :datetime
  end

  def self.down
    remove_column :products, :ingrams_updated_at
    remove_column :products, :gardners_updated_at
  end
end
