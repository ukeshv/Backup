class AddAllTimeBestPrefInProducts < ActiveRecord::Migration
  def self.up
    add_column :products, :all_time_best_seller_preference, :int, :default => 0
  end

  def self.down
    remove_column :products, :all_time_best_seller_preference
  end
end
