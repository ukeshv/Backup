class CreateScriptHistories < ActiveRecord::Migration
  def self.up
    create_table :script_histories do |t|
      t.boolean :is_ingrams_initial
      t.boolean :is_gardners_initial
      t.datetime :start_time
      t.datetime :end_time
      t.boolean :is_hourly_ingrams
      t.boolean :is_hourly_gardners
      t.string :status
      t.string :error
      t.boolean :is_completed
      t.timestamps
    end
  end

  def self.down
    drop_table :script_histories
  end
end
