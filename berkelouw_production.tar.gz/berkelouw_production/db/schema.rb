# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20101018094033) do

  create_table "11730_12990_00_20101004_00_add", :force => true do |t|
    t.integer  "product_department_id"
    t.integer  "product_data_supplier_id"
    t.string   "isbn13",                   :limit => 13
    t.string   "la",                       :limit => 20
    t.text     "tl"
    t.text     "pt1"
    t.text     "pvno1"
    t.text     "pt2"
    t.text     "pvno2"
    t.text     "st"
    t.text     "ys"
    t.text     "sn"
    t.string   "nws",                      :limit => 150
    t.string   "issn",                     :limit => 20
    t.string   "cr1",                      :limit => 20
    t.string   "crt1",                     :limit => 200
    t.string   "cci1",                     :limit => 20
    t.text     "cns1"
    t.string   "cr2",                      :limit => 20
    t.string   "crt2",                     :limit => 200
    t.string   "cci2",                     :limit => 20
    t.text     "cns2"
    t.string   "cr3",                      :limit => 20
    t.string   "crt3",                     :limit => 200
    t.string   "cci3",                     :limit => 20
    t.text     "cns3"
    t.string   "hmm",                      :limit => 20
    t.string   "wmm",                      :limit => 20
    t.string   "smm",                      :limit => 20
    t.string   "wg",                       :limit => 20
    t.string   "edsl",                     :limit => 200
    t.string   "pfc",                      :limit => 20
    t.string   "pfct",                     :limit => 200
    t.string   "pctc1",                    :limit => 10
    t.string   "pctct1",                   :limit => 200
    t.string   "pctc2",                    :limit => 10
    t.string   "pctct2",                   :limit => 200
    t.string   "pctc3",                    :limit => 10
    t.string   "pctct3",                   :limit => 200
    t.string   "pctc4",                    :limit => 10
    t.string   "pctct4",                   :limit => 200
    t.string   "pctc5",                    :limit => 10
    t.string   "pctct5",                   :limit => 200
    t.string   "pctc6",                    :limit => 10
    t.string   "pctct6",                   :limit => 200
    t.string   "pctc7",                    :limit => 10
    t.string   "pctct7",                   :limit => 200
    t.string   "pctc8",                    :limit => 10
    t.string   "pctct8",                   :limit => 200
    t.string   "pctc9",                    :limit => 10
    t.string   "pctct9",                   :limit => 200
    t.string   "pctc10",                   :limit => 10
    t.string   "pctct10",                  :limit => 200
    t.string   "pagnum",                   :limit => 100
    t.string   "noi",                      :limit => 60
    t.string   "run",                      :limit => 20
    t.text     "ill"
    t.string   "ms1",                      :limit => 50
    t.string   "ms2",                      :limit => 50
    t.string   "nop",                      :limit => 20
    t.text     "cis"
    t.text     "ept"
    t.text     "epf"
    t.text     "epfs"
    t.string   "epss",                     :limit => 40
    t.string   "tfc1",                     :limit => 20
    t.string   "tft1",                     :limit => 200
    t.string   "tfc2",                     :limit => 20
    t.string   "tft2",                     :limit => 200
    t.string   "tfc3",                     :limit => 20
    t.string   "tft3",                     :limit => 200
    t.string   "tfc4",                     :limit => 20
    t.string   "tft4",                     :limit => 200
    t.string   "tfc5",                     :limit => 20
    t.string   "tft5",                     :limit => 200
    t.string   "ts",                       :limit => 200
    t.string   "oac1",                     :limit => 20
    t.string   "oat1",                     :limit => 200
    t.string   "oac2",                     :limit => 20
    t.string   "oat2",                     :limit => 200
    t.string   "oac3",                     :limit => 20
    t.string   "oat3",                     :limit => 200
    t.string   "oac4",                     :limit => 20
    t.string   "oat4",                     :limit => 200
    t.string   "oac5",                     :limit => 20
    t.string   "oat5",                     :limit => 200
    t.string   "oac6",                     :limit => 20
    t.string   "oat6",                     :limit => 200
    t.string   "oac7",                     :limit => 20
    t.string   "oat7",                     :limit => 200
    t.string   "oac8",                     :limit => 20
    t.string   "oat8",                     :limit => 200
    t.string   "oac9",                     :limit => 20
    t.string   "oat9",                     :limit => 200
    t.string   "oac10",                    :limit => 20
    t.string   "oat10",                    :limit => 200
    t.string   "bic2sc1",                  :limit => 20
    t.string   "bic2st1",                  :limit => 200
    t.string   "bic2sc2",                  :limit => 20
    t.string   "bic2st2",                  :limit => 200
    t.string   "bic2sc3",                  :limit => 20
    t.string   "bic2st3",                  :limit => 200
    t.string   "bic2sc4",                  :limit => 20
    t.string   "bic2st4",                  :limit => 200
    t.string   "bic2sc5",                  :limit => 20
    t.string   "bic2st5",                  :limit => 200
    t.string   "bic2qc1",                  :limit => 20
    t.string   "bic2qt1",                  :limit => 200
    t.string   "bic2qc2",                  :limit => 20
    t.string   "bic2qt2",                  :limit => 200
    t.string   "bic2qc3",                  :limit => 20
    t.string   "bic2qt3",                  :limit => 200
    t.string   "bic2qc4",                  :limit => 20
    t.string   "bic2qt4",                  :limit => 200
    t.string   "bic2qc5",                  :limit => 20
    t.string   "bic2qt5",                  :limit => 200
    t.string   "repis13",                  :limit => 20
    t.string   "repbis13",                 :limit => 20
    t.string   "pubais13",                 :limit => 20
    t.string   "epris13",                  :limit => 20
    t.string   "epbis13",                  :limit => 20
    t.text     "psf"
    t.text     "aussd"
    t.text     "ausld"
    t.text     "ausbiog"
    t.text     "austoc"
    t.text     "kirkukrev"
    t.text     "kirkusrev"
    t.string   "impn"
    t.string   "impid"
    t.string   "pubn"
    t.string   "pubid"
    t.string   "pop"
    t.string   "cop"
    t.date     "pubpd"
    t.date     "embd"
    t.date     "mopd"
    t.string   "pubsc",                    :limit => 20
    t.string   "pubst",                    :limit => 200
    t.string   "gbpccpra",                 :limit => 20
    t.string   "gbpccprrrp",               :limit => 20
    t.text     "gbpccprsn"
    t.string   "gbpccprc",                 :limit => 20
    t.string   "gbpccprtop",               :limit => 20
    t.string   "gbpccprrrplt",             :limit => 20
    t.string   "gbpccprpn",                :limit => 100
    t.date     "gbpccplcd"
    t.string   "usdccpra",                 :limit => 20
    t.string   "usdccprrrp",               :limit => 20
    t.text     "usdccprsn"
    t.string   "usdccprc",                 :limit => 20
    t.string   "usdccprtop",               :limit => 20
    t.string   "usdccprrrplt",             :limit => 20
    t.string   "usdccprpn",                :limit => 100
    t.date     "usdccplcd"
    t.string   "audccpra",                 :limit => 20
    t.string   "audccprrrp",               :limit => 20
    t.text     "audccprsn"
    t.string   "audccprc",                 :limit => 20
    t.string   "audccprtop",               :limit => 20
    t.string   "audccprrrplt",             :limit => 20
    t.string   "audccprpn",                :limit => 100
    t.date     "audccplcd"
    t.string   "ausnbdaa",                 :limit => 20
    t.text     "ausnbdasn"
    t.date     "ausnbdead"
    t.date     "ausnbdpacd"
    t.string   "ausnbdot",                 :limit => 20
    t.string   "ausnbdpq",                 :limit => 20
    t.date     "ausnbdpaslcd"
    t.string   "ausnbdpac",                :limit => 20
    t.string   "ausnbdpat",                :limit => 100
    t.string   "ausadn1",                  :limit => 300
    t.string   "ausadi1",                  :limit => 30
    t.string   "ausadn2",                  :limit => 300
    t.string   "ausadi2",                  :limit => 30
    t.string   "wslruk",                   :limit => 200
    t.string   "wslrexuk",                 :limit => 200
    t.string   "imagflag",                 :limit => 10
    t.boolean  "divert_image"
    t.string   "divert_image_url",         :limit => 200
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "csv_file_source",          :limit => 100
    t.integer  "product_content_type_id"
    t.integer  "availability_status_id",                  :default => 0
    t.integer  "product_category_id"
    t.integer  "publishing_status_id",                    :default => 0
    t.float    "discount",                                :default => 0.0
    t.string   "rare_pubpd"
    t.string   "update_csv_file_source"
    t.integer  "tax",                                     :default => 10,   :null => false
    t.integer  "ingrams_onhand",                          :default => 0,    :null => false
    t.float    "ingrams_discount",                        :default => 0.0,  :null => false
    t.integer  "gardners_onhand",                         :default => 0,    :null => false
    t.float    "gardners_discount",                       :default => 0.0,  :null => false
    t.boolean  "active",                                  :default => true, :null => false
    t.float    "shipping_cost"
    t.integer  "local_supplier_onhand"
    t.integer  "best_seller_preference"
    t.integer  "new_release_preference"
  end

  add_index "11730_12990_00_20101004_00_add", ["ausadi1"], :name => "index_products_on_ausadi1"
  add_index "11730_12990_00_20101004_00_add", ["ausadi2"], :name => "index_products_on_ausadi2"
  add_index "11730_12990_00_20101004_00_add", ["availability_status_id"], :name => "index_products_on_availability_status_id"
  add_index "11730_12990_00_20101004_00_add", ["bic2sc1"], :name => "index_products_on_bic2sc1"
  add_index "11730_12990_00_20101004_00_add", ["bic2sc2"], :name => "index_products_on_bic2sc2"
  add_index "11730_12990_00_20101004_00_add", ["bic2sc3"], :name => "index_products_on_bic2sc3"
  add_index "11730_12990_00_20101004_00_add", ["bic2sc4"], :name => "index_products_on_bic2sc4"
  add_index "11730_12990_00_20101004_00_add", ["bic2sc5"], :name => "index_products_on_bic2sc5"
  add_index "11730_12990_00_20101004_00_add", ["imagflag"], :name => "index_products_on_imagflag"
  add_index "11730_12990_00_20101004_00_add", ["isbn13"], :name => "index_products_on_isbn13"
  add_index "11730_12990_00_20101004_00_add", ["isbn13"], :name => "unique_isbn13", :unique => true
  add_index "11730_12990_00_20101004_00_add", ["product_category_id"], :name => "index_products_on_product_category_id"
  add_index "11730_12990_00_20101004_00_add", ["product_content_type_id"], :name => "index_products_on_product_content_type_id"
  add_index "11730_12990_00_20101004_00_add", ["product_data_supplier_id"], :name => "index_products_on_product_data_supplier_id"
  add_index "11730_12990_00_20101004_00_add", ["product_department_id"], :name => "index_products_on_product_department_id"
  add_index "11730_12990_00_20101004_00_add", ["publishing_status_id"], :name => "index_products_on_publishing_status_id"
  add_index "11730_12990_00_20101004_00_add", ["pubpd"], :name => "index_products_on_pubpd"

  create_table "address_types", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "address_types_addresses", :id => false, :force => true do |t|
    t.integer  "address_type_id"
    t.integer  "address_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "address_types_addresses", ["address_id"], :name => "index_address_types_addresses_on_address_id"
  add_index "address_types_addresses", ["address_type_id"], :name => "index_address_types_addresses_on_address_type_id"

  create_table "addresses", :force => true do |t|
    t.string   "address_1"
    t.string   "address_2"
    t.string   "suburb"
    t.string   "state"
    t.string   "postcode"
    t.string   "country"
    t.integer  "contact_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "company_id"
    t.integer  "user_id"
    t.string   "country_code"
    t.string   "first_name"
    t.string   "last_name"
    t.string   "phone_number"
  end

  add_index "addresses", ["company_id"], :name => "index_addresses_on_company_id"
  add_index "addresses", ["contact_id"], :name => "index_addresses_on_contact_id"
  add_index "addresses", ["user_id"], :name => "index_addresses_on_user_id"

  create_table "availability_statuses", :force => true do |t|
    t.integer  "code"
    t.string   "name"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "use",               :default => true
    t.integer  "preference",        :default => 0
    t.boolean  "acts_as_available", :default => false
  end

  add_index "availability_statuses", ["acts_as_available"], :name => "index_availability_statuses_on_acts_as_available"
  add_index "availability_statuses", ["code"], :name => "index_availability_statuses_on_code"

  create_table "book_searches", :force => true do |t|
    t.string   "title"
    t.string   "isbn"
    t.string   "author"
    t.string   "email"
    t.string   "name"
    t.text     "comment"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "telephone"
    t.integer  "user_id"
    t.string   "publish_date"
  end

  add_index "book_searches", ["user_id"], :name => "index_book_searches_on_user_id"

  create_table "booksoft_imports", :force => true do |t|
    t.integer  "user_id"
    t.string   "source_file"
    t.text     "error_message"
    t.boolean  "success",          :default => false
    t.string   "update_type"
    t.text     "notes"
    t.integer  "records_affected"
    t.datetime "update_start"
    t.datetime "update_end"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "booksoft_imports", ["user_id"], :name => "index_booksoft_imports_on_user_id"

  create_table "cart_items", :force => true do |t|
    t.integer  "cart_id"
    t.integer  "product_id"
    t.integer  "quantity"
    t.float    "price"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "shipping_time"
    t.string   "price_supplier"
  end

  add_index "cart_items", ["cart_id"], :name => "index_cart_items_on_cart_id"
  add_index "cart_items", ["product_id"], :name => "index_cart_items_on_product_id"

  create_table "carts", :force => true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "delivery_country_code", :default => "AU"
  end

  create_table "collection_styles", :force => true do |t|
    t.string   "name"
    t.string   "background_repeat"
    t.string   "background_color"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "background_image_file_name"
    t.string   "background_image_content_type"
    t.integer  "background_image_file_size"
    t.datetime "background_image_updated_at"
    t.string   "background_position"
  end

  create_table "collection_styles_collection_types", :id => false, :force => true do |t|
    t.integer  "collection_style_id"
    t.integer  "collection_type_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "collection_styles_collection_types", ["collection_style_id"], :name => "index_collection_styles_collection_types_on_collection_style_id"
  add_index "collection_styles_collection_types", ["collection_type_id"], :name => "index_collection_styles_collection_types_on_collection_type_id"

  create_table "collection_types", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "collections", :force => true do |t|
    t.string   "name"
    t.integer  "display_order"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "permanent",     :default => false
    t.string   "css_style",     :default => "wood"
  end

  add_index "collections", ["permanent"], :name => "index_collections_on_permanent"

  create_table "collections_products", :id => false, :force => true do |t|
    t.integer "collection_id", :null => false
    t.integer "product_id",    :null => false
  end

  create_table "companies", :force => true do |t|
    t.string   "name"
    t.string   "telephone"
    t.string   "fax"
    t.string   "website"
    t.string   "email"
    t.integer  "contact_id"
    t.integer  "company_type_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "companies", ["company_type_id"], :name => "index_companies_on_company_type_id"
  add_index "companies", ["contact_id"], :name => "index_companies_on_contact_id"

  create_table "company_types", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "contact_types", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "contacts", :force => true do |t|
    t.string   "first_name"
    t.string   "last_name"
    t.string   "email"
    t.string   "work_telephone"
    t.string   "home_telephone"
    t.string   "mobile"
    t.string   "fax"
    t.integer  "contact_type_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "company_id"
  end

  add_index "contacts", ["company_id"], :name => "index_contacts_on_company_id"
  add_index "contacts", ["contact_type_id"], :name => "index_contacts_on_contact_type_id"

  create_table "countries", :force => true do |t|
    t.string   "name"
    t.string   "code"
    t.integer  "shipping_region_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "countries", ["shipping_region_id"], :name => "index_countries_on_shipping_region_id"

  create_table "data_mismatch_types", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "data_mismatches", :force => true do |t|
    t.integer  "data_mismatch_type_id"
    t.integer  "product_id"
    t.string   "mismatch_data"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "data_mismatches", ["data_mismatch_type_id"], :name => "index_data_mismatches_on_data_mismatch_type_id"
  add_index "data_mismatches", ["product_id"], :name => "index_data_mismatches_on_product_id"

  create_table "delayed_jobs", :force => true do |t|
    t.integer  "priority",   :default => 0
    t.integer  "attempts",   :default => 0
    t.text     "handler"
    t.text     "last_error"
    t.datetime "run_at"
    t.datetime "locked_at"
    t.datetime "failed_at"
    t.string   "locked_by"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "email_enquiries", :force => true do |t|
    t.string   "from"
    t.string   "to"
    t.string   "cc"
    t.string   "subject"
    t.text     "body"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "to_name"
    t.string   "from_name"
    t.integer  "product_id"
    t.string   "isbn13"
    t.integer  "user_id"
    t.string   "telephone"
    t.integer  "store_id"
  end

  add_index "email_enquiries", ["product_id"], :name => "index_email_enquiries_on_product_id"
  add_index "email_enquiries", ["store_id"], :name => "index_email_enquiries_on_store_id"
  add_index "email_enquiries", ["user_id"], :name => "index_email_enquiries_on_user_id"

  create_table "event_occurrences", :force => true do |t|
    t.date     "start_date"
    t.date     "end_date"
    t.time     "start_time"
    t.time     "end_time"
    t.integer  "event_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "all_day",         :default => false
    t.boolean  "ignore_end_date", :default => false
  end

  add_index "event_occurrences", ["event_id"], :name => "index_event_occurrences_on_event_id"

  create_table "event_recurrings", :force => true do |t|
    t.integer  "event_id"
    t.string   "every"
    t.string   "on"
    t.string   "weekday"
    t.string   "interval"
    t.datetime "until"
    t.time     "start_time"
    t.time     "end_time"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "event_timings", :force => true do |t|
    t.datetime "start_date"
    t.datetime "end_date"
    t.integer  "event_id"
    t.boolean  "all_day"
    t.boolean  "ignore_end_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "event_timings", ["event_id"], :name => "index_event_timings_on_event_id"

  create_table "events", :force => true do |t|
    t.integer  "store_id"
    t.string   "name"
    t.text     "description"
    t.datetime "event_date"
    t.string   "address_1"
    t.string   "address_2"
    t.string   "suburb"
    t.string   "state"
    t.string   "country"
    t.string   "postcode"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
    t.datetime "end_date"
    t.string   "price"
    t.string   "isbn13"
    t.integer  "product_id"
    t.string   "location_name"
    t.boolean  "sold_out",           :default => false
    t.string   "telephone"
    t.string   "email"
    t.date     "rsvp"
    t.float    "latitude"
    t.float    "longitude"
    t.text     "rsvp_text"
    t.boolean  "recurring",          :default => false
    t.boolean  "feature_event",      :default => false
  end

  add_index "events", ["end_date"], :name => "index_events_on_end_date"
  add_index "events", ["event_date"], :name => "index_events_on_event_date"
  add_index "events", ["isbn13"], :name => "index_events_on_isbn13"
  add_index "events", ["product_id"], :name => "index_events_on_product_id"

  create_table "events_products", :id => false, :force => true do |t|
    t.integer "event_id",   :null => false
    t.integer "product_id", :null => false
  end

  create_table "exchange_rates", :force => true do |t|
    t.string   "code"
    t.float    "rate"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "exchange_rates", ["code"], :name => "index_exchange_rates_on_code"

  create_table "features", :force => true do |t|
    t.text     "title"
    t.text     "description"
    t.string   "url"
    t.integer  "display_order"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
    t.string   "link_text"
    t.boolean  "is_banner",          :default => false
    t.string   "text_align"
    t.integer  "height",             :default => 200
    t.boolean  "open_in_new_window", :default => false
    t.string   "name"
  end

  create_table "ftp_logs", :force => true do |t|
    t.string   "filename"
    t.string   "local_filepath"
    t.string   "remote_filepath"
    t.string   "status"
    t.string   "message"
    t.integer  "filesize"
    t.boolean  "is_extracted"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "is_imported"
    t.string   "exported_file_path"
  end

  create_table "gardeners_stock_availabilities", :force => true do |t|
    t.string   "isbn13"
    t.integer  "available"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "genre_products", :force => true do |t|
    t.integer  "product_id"
    t.integer  "genre_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "genre_products", ["genre_id"], :name => "index_genre_products_on_genre_id"
  add_index "genre_products", ["product_id"], :name => "index_genre_products_on_product_id"

  create_table "genre_types", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "genres", :force => true do |t|
    t.string   "code"
    t.string   "name"
    t.integer  "parent_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "berkelouw_name"
    t.boolean  "is_top_level",        :default => false
    t.integer  "genre_type_id"
    t.boolean  "show_in_browse_menu", :default => false
    t.integer  "product_category_id"
    t.boolean  "delta",               :default => true,  :null => false
  end

  add_index "genres", ["code"], :name => "index_genres_on_code"
  add_index "genres", ["genre_type_id"], :name => "index_genres_on_genre_type_id"
  add_index "genres", ["is_top_level"], :name => "index_genres_on_is_top_level"
  add_index "genres", ["product_category_id"], :name => "index_genres_on_product_category_id"
  add_index "genres", ["show_in_browse_menu"], :name => "index_genres_on_show_in_browse_menu"

  create_table "lists", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.float    "price"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "cm_list_id"
    t.string   "slug"
    t.boolean  "is_email_only",                 :default => false
    t.boolean  "require_further_details",       :default => false
    t.string   "require_further_details_label"
  end

  add_index "lists", ["cm_list_id"], :name => "index_lists_on_cm_list_id"

  create_table "nielsen_datas", :force => true do |t|
    t.string   "filename"
    t.string   "remote_filepath"
    t.string   "local_filepath"
    t.string   "extracted_filepath"
    t.string   "update_type"
    t.string   "status"
    t.string   "message"
    t.boolean  "is_extracted"
    t.boolean  "is_dumped"
    t.boolean  "ftp_success"
    t.integer  "file_size"
    t.integer  "updated_records_count"
    t.date     "ftp_downloaded_on"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "nielsen_jobs", :force => true do |t|
    t.string   "job_name"
    t.string   "env"
    t.string   "status"
    t.string   "stderr"
    t.datetime "started_at"
    t.datetime "finished_at"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "nielsen_updates", :force => true do |t|
    t.string   "source_file"
    t.date     "start_ftp_download"
    t.date     "finish_ftp_download"
    t.string   "update_type"
    t.date     "start_data_update"
    t.date     "end_data_update"
    t.integer  "number_of_records_updated"
    t.boolean  "success",                   :default => false
    t.text     "error"
    t.text     "notes"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "ftp_success",               :default => false
  end

  create_table "order_histories", :force => true do |t|
    t.integer  "order_id"
    t.integer  "user_id"
    t.string   "status"
    t.string   "updated_by"
    t.text     "params"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "order_item_histories", :force => true do |t|
    t.integer  "order_item_id"
    t.integer  "user_id"
    t.string   "status"
    t.string   "updated_by"
    t.text     "params"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "order_items", :force => true do |t|
    t.integer  "order_id"
    t.integer  "product_id"
    t.float    "price"
    t.integer  "quantity"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.text     "product_name"
    t.string   "discounts"
    t.integer  "quantity_waiting_for",       :default => 1000
    t.string   "isbn13"
    t.text     "author"
    t.integer  "deduction_percentage"
    t.float    "deduction_amount"
    t.string   "status"
    t.integer  "override_isbn13"
    t.integer  "preference",                 :default => 0
    t.boolean  "in_store_check_completed",   :default => false
    t.boolean  "is_api_check_completed",     :default => false
    t.integer  "quantity_waiting",           :default => 0
    t.string   "is_available_from"
    t.integer  "new_shipping_cost"
    t.boolean  "waiting_for_store_response", :default => false
    t.string   "shipping_time"
    t.string   "price_supplier"
    t.string   "replacement_isbn13"
  end

  add_index "order_items", ["isbn13"], :name => "index_order_items_on_isbn13"
  add_index "order_items", ["order_id"], :name => "index_order_items_on_order_id"
  add_index "order_items", ["product_id"], :name => "index_order_items_on_product_id"
  add_index "order_items", ["quantity_waiting_for"], :name => "index_order_items_on_quantity_waiting_for"

  create_table "order_transactions", :force => true do |t|
    t.integer  "order_id"
    t.integer  "amount"
    t.boolean  "success"
    t.string   "reference"
    t.text     "message"
    t.string   "action"
    t.text     "params"
    t.boolean  "test"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "masked_card_number"
  end

  create_table "orders", :force => true do |t|
    t.integer  "user_id"
    t.string   "email"
    t.string   "phone_number"
    t.string   "ship_to_first_name"
    t.string   "ship_to_last_name"
    t.string   "ship_to_address_1"
    t.string   "ship_to_address_2"
    t.string   "ship_to_suburb"
    t.string   "ship_to_state"
    t.string   "ship_to_postcode"
    t.string   "ship_to_country"
    t.string   "customer_ip"
    t.string   "status",               :default => "open"
    t.string   "error_message"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.date     "card_expires_on"
    t.string   "card_type"
    t.string   "billing_first_name"
    t.string   "billing_last_name"
    t.string   "billing_email"
    t.string   "billing_phone"
    t.string   "billing_address_1"
    t.string   "billing_address_2"
    t.string   "billing_suburb"
    t.string   "billing_state"
    t.string   "billing_postcode"
    t.string   "billing_country"
    t.string   "billing_country_code"
    t.string   "ship_to_country_code"
    t.string   "order_number"
    t.boolean  "same_as_shipping",     :default => true
    t.string   "masked_card_number"
    t.boolean  "delta",                :default => true,   :null => false
    t.float    "total"
    t.float    "shipping_cost"
    t.integer  "quantity_waiting_for", :default => 1000
    t.integer  "stage"
    t.integer  "quantity_waiting",     :default => 0
    t.boolean  "on_hold",              :default => false
    t.text     "notes"
    t.datetime "status_updated_at"
    t.integer  "cart_id"
    t.boolean  "is_processed",         :default => true
  end

  add_index "orders", ["customer_ip"], :name => "index_orders_on_customer_ip"
  add_index "orders", ["order_number"], :name => "index_orders_on_order_number"
  add_index "orders", ["quantity_waiting_for"], :name => "index_orders_on_quantity_waiting_for"
  add_index "orders", ["user_id"], :name => "index_orders_on_user_id"

  create_table "placement_locations", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "placement_locations_placement_types", :id => false, :force => true do |t|
    t.integer  "placement_location_id"
    t.integer  "placement_type_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "placement_types", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "placements", :force => true do |t|
    t.integer  "collection_id"
    t.integer  "feature_id"
    t.integer  "placement_location_id"
    t.integer  "specific_placement_location_id"
    t.integer  "display_order"
    t.integer  "created_by"
    t.integer  "updated_by"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "permanent",                      :default => false
    t.integer  "post_id"
    t.integer  "collection_type_id"
    t.integer  "collection_style_id"
  end

  add_index "placements", ["collection_id"], :name => "index_placements_on_collection_id"
  add_index "placements", ["collection_style_id"], :name => "index_placements_on_collection_style_id"
  add_index "placements", ["collection_type_id"], :name => "index_placements_on_collection_type_id"
  add_index "placements", ["feature_id"], :name => "index_placements_on_feature_id"
  add_index "placements", ["permanent"], :name => "index_placements_on_permanent"
  add_index "placements", ["placement_location_id"], :name => "index_placements_on_placement_location_id"
  add_index "placements", ["post_id"], :name => "index_placements_on_post_id"
  add_index "placements", ["specific_placement_location_id"], :name => "index_placements_on_specific_placement_location_id"

  create_table "posts", :force => true do |t|
    t.string   "title"
    t.text     "post"
    t.integer  "author_id"
    t.integer  "store_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
    t.integer  "updated_by"
  end

  create_table "posts_products", :id => false, :force => true do |t|
    t.integer "post_id",    :null => false
    t.integer "product_id", :null => false
  end

  create_table "product_categories", :force => true do |t|
    t.string   "name"
    t.boolean  "use",        :default => true
    t.integer  "preference", :default => 1
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "slug"
  end

  add_index "product_categories", ["slug"], :name => "index_product_categories_on_slug"
  add_index "product_categories", ["use"], :name => "index_product_categories_on_use"

  create_table "product_content_types", :force => true do |t|
    t.string   "code"
    t.string   "name"
    t.text     "description"
    t.boolean  "use",         :default => true
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "preference"
  end

  add_index "product_content_types", ["code"], :name => "index_product_content_types_on_code"

  create_table "product_data_suppliers", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "products", :force => true do |t|
    t.integer  "product_department_id"
    t.integer  "product_data_supplier_id"
    t.string   "isbn13",                          :limit => 13
    t.string   "la",                              :limit => 20
    t.text     "tl"
    t.text     "pt1"
    t.text     "pvno1"
    t.text     "pt2"
    t.text     "pvno2"
    t.text     "st"
    t.text     "ys"
    t.text     "sn"
    t.string   "nws",                             :limit => 150
    t.string   "issn",                            :limit => 20
    t.string   "cr1",                             :limit => 20
    t.string   "crt1",                            :limit => 200
    t.string   "cci1",                            :limit => 20
    t.text     "cns1"
    t.string   "cr2",                             :limit => 20
    t.string   "crt2",                            :limit => 200
    t.string   "cci2",                            :limit => 20
    t.text     "cns2"
    t.string   "cr3",                             :limit => 20
    t.string   "crt3",                            :limit => 200
    t.string   "cci3",                            :limit => 20
    t.text     "cns3"
    t.string   "hmm",                             :limit => 20
    t.string   "wmm",                             :limit => 20
    t.string   "smm",                             :limit => 20
    t.string   "wg",                              :limit => 20
    t.string   "edsl",                            :limit => 200
    t.string   "pfc",                             :limit => 20
    t.string   "pfct",                            :limit => 200
    t.string   "pctc1",                           :limit => 10
    t.string   "pctct1",                          :limit => 200
    t.string   "pctc2",                           :limit => 10
    t.string   "pctct2",                          :limit => 200
    t.string   "pctc3",                           :limit => 10
    t.string   "pctct3",                          :limit => 200
    t.string   "pctc4",                           :limit => 10
    t.string   "pctct4",                          :limit => 200
    t.string   "pctc5",                           :limit => 10
    t.string   "pctct5",                          :limit => 200
    t.string   "pctc6",                           :limit => 10
    t.string   "pctct6",                          :limit => 200
    t.string   "pctc7",                           :limit => 10
    t.string   "pctct7",                          :limit => 200
    t.string   "pctc8",                           :limit => 10
    t.string   "pctct8",                          :limit => 200
    t.string   "pctc9",                           :limit => 10
    t.string   "pctct9",                          :limit => 200
    t.string   "pctc10",                          :limit => 10
    t.string   "pctct10",                         :limit => 200
    t.string   "pagnum",                          :limit => 100
    t.string   "noi",                             :limit => 60
    t.string   "run",                             :limit => 20
    t.text     "ill"
    t.string   "ms1",                             :limit => 50
    t.string   "ms2",                             :limit => 50
    t.string   "nop",                             :limit => 20
    t.text     "cis"
    t.text     "ept"
    t.text     "epf"
    t.text     "epfs"
    t.string   "epss",                            :limit => 40
    t.string   "tfc1",                            :limit => 20
    t.string   "tft1",                            :limit => 200
    t.string   "tfc2",                            :limit => 20
    t.string   "tft2",                            :limit => 200
    t.string   "tfc3",                            :limit => 20
    t.string   "tft3",                            :limit => 200
    t.string   "tfc4",                            :limit => 20
    t.string   "tft4",                            :limit => 200
    t.string   "tfc5",                            :limit => 20
    t.string   "tft5",                            :limit => 200
    t.string   "ts",                              :limit => 200
    t.string   "oac1",                            :limit => 20
    t.string   "oat1",                            :limit => 200
    t.string   "oac2",                            :limit => 20
    t.string   "oat2",                            :limit => 200
    t.string   "oac3",                            :limit => 20
    t.string   "oat3",                            :limit => 200
    t.string   "oac4",                            :limit => 20
    t.string   "oat4",                            :limit => 200
    t.string   "oac5",                            :limit => 20
    t.string   "oat5",                            :limit => 200
    t.string   "oac6",                            :limit => 20
    t.string   "oat6",                            :limit => 200
    t.string   "oac7",                            :limit => 20
    t.string   "oat7",                            :limit => 200
    t.string   "oac8",                            :limit => 20
    t.string   "oat8",                            :limit => 200
    t.string   "oac9",                            :limit => 20
    t.string   "oat9",                            :limit => 200
    t.string   "oac10",                           :limit => 20
    t.string   "oat10",                           :limit => 200
    t.string   "bic2sc1",                         :limit => 20
    t.string   "bic2st1",                         :limit => 200
    t.string   "bic2sc2",                         :limit => 20
    t.string   "bic2st2",                         :limit => 200
    t.string   "bic2sc3",                         :limit => 20
    t.string   "bic2st3",                         :limit => 200
    t.string   "bic2sc4",                         :limit => 20
    t.string   "bic2st4",                         :limit => 200
    t.string   "bic2sc5",                         :limit => 20
    t.string   "bic2st5",                         :limit => 200
    t.string   "bic2qc1",                         :limit => 20
    t.string   "bic2qt1",                         :limit => 200
    t.string   "bic2qc2",                         :limit => 20
    t.string   "bic2qt2",                         :limit => 200
    t.string   "bic2qc3",                         :limit => 20
    t.string   "bic2qt3",                         :limit => 200
    t.string   "bic2qc4",                         :limit => 20
    t.string   "bic2qt4",                         :limit => 200
    t.string   "bic2qc5",                         :limit => 20
    t.string   "bic2qt5",                         :limit => 200
    t.string   "repis13",                         :limit => 20
    t.string   "repbis13",                        :limit => 20
    t.string   "pubais13",                        :limit => 20
    t.string   "epris13",                         :limit => 20
    t.string   "epbis13",                         :limit => 20
    t.text     "psf"
    t.text     "aussd"
    t.text     "ausld"
    t.text     "ausbiog"
    t.text     "austoc"
    t.text     "kirkukrev"
    t.text     "kirkusrev"
    t.string   "impn"
    t.string   "impid"
    t.string   "pubn"
    t.string   "pubid"
    t.string   "pop"
    t.string   "cop"
    t.date     "pubpd"
    t.date     "embd"
    t.date     "mopd"
    t.string   "pubsc",                           :limit => 20
    t.string   "pubst",                           :limit => 200
    t.string   "gbpccpra",                        :limit => 20
    t.string   "gbpccprrrp",                      :limit => 20
    t.text     "gbpccprsn"
    t.string   "gbpccprc",                        :limit => 20
    t.string   "gbpccprtop",                      :limit => 20
    t.string   "gbpccprrrplt",                    :limit => 20
    t.string   "gbpccprpn",                       :limit => 100
    t.date     "gbpccplcd"
    t.string   "usdccpra",                        :limit => 20
    t.string   "usdccprrrp",                      :limit => 20
    t.text     "usdccprsn"
    t.string   "usdccprc",                        :limit => 20
    t.string   "usdccprtop",                      :limit => 20
    t.string   "usdccprrrplt",                    :limit => 20
    t.string   "usdccprpn",                       :limit => 100
    t.date     "usdccplcd"
    t.string   "audccpra",                        :limit => 20
    t.string   "audccprrrp",                      :limit => 20
    t.text     "audccprsn"
    t.string   "audccprc",                        :limit => 20
    t.string   "audccprtop",                      :limit => 20
    t.string   "audccprrrplt",                    :limit => 20
    t.string   "audccprpn",                       :limit => 100
    t.date     "audccplcd"
    t.string   "ausnbdaa",                        :limit => 20
    t.text     "ausnbdasn"
    t.date     "ausnbdead"
    t.date     "ausnbdpacd"
    t.string   "ausnbdot",                        :limit => 20
    t.string   "ausnbdpq",                        :limit => 20
    t.date     "ausnbdpaslcd"
    t.string   "ausnbdpac",                       :limit => 20
    t.string   "ausnbdpat",                       :limit => 100
    t.string   "ausadn1",                         :limit => 300
    t.string   "ausadi1",                         :limit => 30
    t.string   "ausadn2",                         :limit => 300
    t.string   "ausadi2",                         :limit => 30
    t.string   "wslruk",                          :limit => 200
    t.string   "wslrexuk",                        :limit => 200
    t.string   "imagflag",                        :limit => 10
    t.boolean  "divert_image"
    t.string   "divert_image_url",                :limit => 200
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "csv_file_source",                 :limit => 100
    t.integer  "product_content_type_id"
    t.integer  "availability_status_id",                         :default => 0
    t.integer  "product_category_id"
    t.integer  "publishing_status_id",                           :default => 0
    t.float    "discount",                                       :default => 0.0
    t.string   "rare_pubpd"
    t.string   "update_csv_file_source"
    t.integer  "tax",                                            :default => 10,   :null => false
    t.integer  "ingrams_onhand",                                 :default => 0,    :null => false
    t.float    "ingrams_discount",                               :default => 0.0,  :null => false
    t.integer  "gardners_onhand",                                :default => 0,    :null => false
    t.float    "gardners_discount",                              :default => 0.0,  :null => false
    t.boolean  "active",                                         :default => true, :null => false
    t.float    "shipping_cost"
    t.integer  "local_supplier_onhand"
    t.integer  "best_seller_preference"
    t.integer  "new_release_preference"
    t.integer  "all_time_best_seller_preference",                :default => 0
  end

  add_index "products", ["ausadi1"], :name => "index_products_on_ausadi1"
  add_index "products", ["ausadi2"], :name => "index_products_on_ausadi2"
  add_index "products", ["availability_status_id"], :name => "index_products_on_availability_status_id"
  add_index "products", ["bic2sc1"], :name => "index_products_on_bic2sc1"
  add_index "products", ["bic2sc2"], :name => "index_products_on_bic2sc2"
  add_index "products", ["bic2sc3"], :name => "index_products_on_bic2sc3"
  add_index "products", ["bic2sc4"], :name => "index_products_on_bic2sc4"
  add_index "products", ["bic2sc5"], :name => "index_products_on_bic2sc5"
  add_index "products", ["imagflag"], :name => "index_products_on_imagflag"
  add_index "products", ["isbn13"], :name => "index_products_on_isbn13"
  add_index "products", ["isbn13"], :name => "unique_isbn13", :unique => true
  add_index "products", ["product_category_id"], :name => "index_products_on_product_category_id"
  add_index "products", ["product_content_type_id"], :name => "index_products_on_product_content_type_id"
  add_index "products", ["product_data_supplier_id"], :name => "index_products_on_product_data_supplier_id"
  add_index "products", ["product_department_id"], :name => "index_products_on_product_department_id"
  add_index "products", ["publishing_status_id"], :name => "index_products_on_publishing_status_id"
  add_index "products", ["pubpd"], :name => "index_products_on_pubpd"

  create_table "products_suppliers", :id => false, :force => true do |t|
    t.integer  "product_id"
    t.integer  "supplier_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "products_suppliers", ["product_id"], :name => "index_products_suppliers_on_product_id"
  add_index "products_suppliers", ["supplier_id"], :name => "index_products_suppliers_on_supplier_id"

  create_table "products_suppliers_2010_10_04", :id => false, :force => true do |t|
    t.integer  "product_id"
    t.integer  "supplier_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "products_suppliers_2010_10_04", ["product_id"], :name => "index_products_suppliers_on_product_id"
  add_index "products_suppliers_2010_10_04", ["supplier_id"], :name => "index_products_suppliers_on_supplier_id"

  create_table "publishing_statuses", :force => true do |t|
    t.string   "code"
    t.string   "name"
    t.string   "description"
    t.boolean  "use",               :default => true
    t.integer  "preference",        :default => 0
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "acts_as_available", :default => false
  end

  add_index "publishing_statuses", ["acts_as_available"], :name => "index_publishing_statuses_on_acts_as_available"
  add_index "publishing_statuses", ["code"], :name => "index_publishing_statuses_on_code"

  create_table "related_genres", :id => false, :force => true do |t|
    t.integer "sub_genre_id"
    t.integer "parent_genre_id"
  end

  add_index "related_genres", ["parent_genre_id"], :name => "index_related_genres_on_parent_genre_id"
  add_index "related_genres", ["sub_genre_id"], :name => "index_related_genres_on_sub_genre_id"

  create_table "reviews", :force => true do |t|
    t.string   "title"
    t.text     "review"
    t.integer  "user_id"
    t.integer  "product_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "roles", :force => true do |t|
    t.string   "name",              :limit => 40
    t.string   "authorizable_type", :limit => 40
    t.integer  "authorizable_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "roles_users", :id => false, :force => true do |t|
    t.integer  "user_id"
    t.integer  "role_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "script_histories", :force => true do |t|
    t.boolean  "is_ingrams_initial"
    t.boolean  "is_gardners_initial"
    t.datetime "start_time"
    t.datetime "end_time"
    t.boolean  "is_hourly_ingrams"
    t.boolean  "is_hourly_gardners"
    t.string   "status"
    t.string   "error"
    t.boolean  "is_completed"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "shipping_regions", :force => true do |t|
    t.string   "name"
    t.float    "price_one_item"
    t.float    "price_additional_items"
    t.string   "delivery_time"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "shops", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.integer  "manager_id"
    t.string   "address1"
    t.string   "address2"
    t.string   "suburb"
    t.string   "state"
    t.string   "postcode"
    t.string   "country"
    t.text     "opening_hours"
    t.string   "tel"
    t.string   "fax"
    t.string   "email"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
  end

  create_table "store_photos", :force => true do |t|
    t.integer  "store_id"
    t.string   "photo_type"
    t.string   "photo_file_name"
    t.string   "photo_content_type"
    t.integer  "photo_file_size"
    t.datetime "photo_updated_at"
  end

  add_index "store_photos", ["store_id"], :name => "index_store_photos_on_store_id"

  create_table "stores", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.integer  "manager_id"
    t.string   "address1"
    t.string   "address2"
    t.string   "suburb"
    t.string   "state"
    t.string   "postcode"
    t.string   "country"
    t.text     "opening_hours"
    t.string   "tel"
    t.string   "fax"
    t.string   "email"
    t.string   "booknet_name"
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "slug"
    t.float    "latitude"
    t.float    "longitude"
    t.integer  "preference",                       :default => 0
    t.boolean  "walk_in",                          :default => false
    t.string   "stock_confirmation_email_address"
  end

  add_index "stores", ["manager_id"], :name => "index_stores_on_manager_id"
  add_index "stores", ["slug"], :name => "index_stores_on_slug"

  create_table "subscriptions", :force => true do |t|
    t.string   "email"
    t.string   "full_name"
    t.integer  "list_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "synced_with_campaign_monitor"
    t.boolean  "subscribed",                    :default => true
    t.string   "campain_monitor_response_code"
    t.boolean  "campaign_monitor_success",      :default => false
    t.integer  "address_id"
    t.string   "telephone"
    t.text     "further_details"
  end

  add_index "subscriptions", ["campaign_monitor_success"], :name => "index_subscriptions_on_campaign_monitor_success"
  add_index "subscriptions", ["campain_monitor_response_code"], :name => "index_subscriptions_on_campain_monitor_response_code"
  add_index "subscriptions", ["email"], :name => "index_subscriptions_on_email"
  add_index "subscriptions", ["synced_with_campaign_monitor"], :name => "index_subscriptions_on_synced_with_campaign_monitor"

  create_table "suppliers", :force => true do |t|
    t.integer  "nbd_org_id"
    t.string   "nbd_org_name"
    t.boolean  "use"
    t.integer  "preference"
    t.integer  "contact_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "company_id"
    t.integer  "shipping_time", :default => 10
    t.boolean  "delta",         :default => true, :null => false
  end

  add_index "suppliers", ["company_id"], :name => "index_suppliers_on_company_id"
  add_index "suppliers", ["contact_id"], :name => "index_suppliers_on_contact_id"
  add_index "suppliers", ["nbd_org_id"], :name => "index_suppliers_on_nbd_org_id"

  create_table "taggings", :force => true do |t|
    t.integer  "post_id"
    t.integer  "tag_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tags", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "user_sessions", :force => true do |t|
    t.string   "login"
    t.string   "password"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "email",                                           :null => false
    t.string   "crypted_password",                                :null => false
    t.string   "password_salt",                                   :null => false
    t.string   "persistence_token",                               :null => false
    t.string   "single_access_token",                             :null => false
    t.string   "perishable_token",                                :null => false
    t.integer  "login_count",                  :default => 0,     :null => false
    t.integer  "failed_login_count",           :default => 0,     :null => false
    t.datetime "last_request_at"
    t.datetime "last_login_at"
    t.datetime "current_login_at"
    t.string   "last_login_ip"
    t.string   "current_login_ip"
    t.string   "address_1"
    t.string   "address_2"
    t.string   "suburb"
    t.string   "state"
    t.string   "postcode"
    t.string   "country"
    t.string   "country_code"
    t.string   "first_name"
    t.string   "last_name"
    t.string   "telephone"
    t.boolean  "newsletter",                   :default => false
    t.boolean  "synced_with_campaign_monitor"
  end

  add_index "users", ["email"], :name => "index_users_on_email"
  add_index "users", ["last_request_at"], :name => "index_users_on_last_request_at"
  add_index "users", ["persistence_token"], :name => "index_users_on_persistence_token"

  create_table "wishlist_items", :force => true do |t|
    t.integer  "wishlist_id"
    t.integer  "product_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "wishlists", :force => true do |t|
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

end
