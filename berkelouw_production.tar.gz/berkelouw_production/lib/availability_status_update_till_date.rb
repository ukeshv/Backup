class AvailabilityStatusUpdateTillDate
	def initialize
		ActiveRecord::Base.connection.execute("select id into @available_availability_status_id from availability_statuses where name='Available' limit 1")
		ActiveRecord::Base.connection.execute("select id into @not_yet_available_availability_status_id from availability_statuses where name='Not yet available' limit 1")
		ActiveRecord::Base.connection.execute("select id into @forthcoming_publishing_status_id from publishing_statuses where name='Forthcoming' limit 1")
		count = (ActiveRecord::Base.connection.execute("select count(id) from products").fetch_row)[0].to_i
		i = 0
		increment = 1000
		while i <= count do 
			puts i
			ActiveRecord::Base.connection.execute("update products set availability_status_id = @available_availability_status_id where publishing_status_id = @forthcoming_publishing_status_id and availability_status_id = @not_yet_available_availability_status_id and pubpd IS NOT NULL and pubpd <= CURDATE() and id > #{i} and id <= #{increment}")
		  sleep 5
		  i += increment 
		end
	end
end
