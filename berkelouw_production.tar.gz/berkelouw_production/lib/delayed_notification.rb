class DelayedNotification 
	attr_accessor :order_id
	
	def initialize(order_id)
	 self.order_id=order_id
  end

  def perform
		order=Order.find(self.order_id)
		order.purchase_background_availability_check
  end
	
	def on_permanent_failure
		order=Order.find(self.order_id)
		delayed_jobs=DelayedJob.all
		delayed_jobs && delayed_jobs.each do |dj|
			if dj.handler.squish.scan(/\d+$/).last.to_i==self.order_id
				OrderMailer.deliver_delayed_job_for_order_error(order,dj)
				return
			end
		end
  end
	
end
