require 'rubygems'
ENV['RAILS_ENV'] = ARGV[0]
require File.dirname(__FILE__) + '/../config/boot'
require RAILS_ROOT + '/config/environment' 

# Ftp file downloader script
NielsenData.file_downloader
NielsenData.image_downloader

