FIELDS = %w{isbn13 la tl pt1 pvno1 pt2 pvno2 st ys sn nws issn cr1 crt1 cci1 cns1 cr2 crt2 cci2 cns2 cr3 crt3 cci3 cns3 hmm wmm smm wg edsl pfc pfct pctc1 pctct1 pctc2 pctct2 pctc3 pctct3 pctc4 pctct4 pctc5 pctct5 pctc6 pctct6 pctc7 pctct7 pctc8 pctct8 pctc9 pctct9 pctc10 pctct10 pagnum noi run ill ms1 ms2 nop cis ept epf epfs epss tfc1 tft1 tfc2 tft2 tfc3 tft3 tfc4 tft4 tfc5 tft5 ts oac1 oat1 oac2 oat2 oac3 oat3 oac4 oat4 oac5 oat5 oac6 oat6 oac7 oat7 oac8 oat8 oac9 oat9 oac10 oat10 bic2sc1 bic2st1 bic2sc2 bic2st2 bic2sc3 bic2st3 bic2sc4 bic2st4 bic2sc5 bic2st5 bic2qc1 bic2qt1 bic2qc2 bic2qt2 bic2qc3 bic2qt3 bic2qc4 bic2qt4 bic2qc5 bic2qt5 repis13 repbis13 pubais13 epris13 epbis13 psf aussd ausld ausbiog austoc kirkukrev kirkusrev impn impid pubn pubid pop cop @pubpd @embd @mopd pubsc pubst gbpccpra gbpccprrrp gbpccprsn gbpccprc gbpccprtop gbpccprrrplt gbpccprpn @gbpccplcd usdccpra usdccprrrp usdccprsn usdccprc usdccprtop usdccprrrplt usdccprpn @usdccplcd audccpra audccprrrp audccprsn audccprc audccprtop audccprrrplt audccprpn @audccplcd ausnbdaa ausnbdasn @ausnbdead @ausnbdpacd ausnbdot ausnbdpq @ausnbdpaslcd ausnbdpac ausnbdpat ausadn1 ausadi1 ausadn2 ausadi2 wslruk wslrexuk imagflag}
RELATION_FIELDS = %w{product_category_id product_content_type_id availability_status_id publishing_status_id csv_supplier_id}

def fields_matching_csv(csv)
	head = `head -1 #{csv}`
	fields = head.gsub(/\r/,'').gsub(/\n/,'').downcase.split(',')
  fields = fields.map{|x| (FIELDS.include?(x) ? x : (FIELDS.include?("@#{x}") ? "@#{x}" : '@dummy'))}
	writelog fields.inspect
	return fields
end

def writelog(message)
 puts "#{Time.current} - #{message}"
end 

def process_sql(sql, update=true)
	writelog " - SQL - #{sql}"
	if update	
		ActiveRecord::Base.connection.update_sql(sql).to_i
	else
		ActiveRecord::Base.connection.execute(sql)
	end	
end

require 'rubygems'
ENV['RAILS_ENV'] = ARGV[0] || 'development'
require File.dirname(__FILE__) + '/../config/boot'
require RAILS_ROOT + '/config/environment' 

date = Date.current
#~ table_name = "tmp_#{date.strftime("%Y_%m_%d")}"
#~ 
#~ 
#~ 
#~ table_name = "products"
#~ 
#~ 
#~ 
#~ 
#~ 
#~ 
date_folder = date.strftime("%Y-%m-%d")
path = ENV['RAILS_ENV'] == 'development' ? "#{RAILS_ROOT}/db/ftp_extracts/add" : '/var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs'
process_sql("DROP TABLE IF EXISTS #{table_name}")
process_sql("CREATE TABLE #{table_name} LIKE products_new")
writelog "start data processing (#{path}/*.add) for date - #{date}. Action (add)"		
csv_files = Dir.glob("#{path}/*.add").sort
csv_files.each do |csv|
	puts csv.inspect
	csv_fields = fields_matching_csv(csv)
	csv_name = csv.split('/').last
	process_sql("select id into @default_product_category_id from product_categories where name='books' limit 1")
	process_sql("select id into @default_product_content_type_id from product_content_types where name='Undefined' limit 1") 
	process_sql("select id into @default_publishing_status_id from publishing_statuses where name='Unspecified' limit 1") 
	process_sql("set @default_availability_status_id = 0") 
	process_sql("set @default_csv_supplier_id = NULL") 
	process_sql("LOAD DATA LOCAL INFILE '#{csv}' INTO TABLE #{table_name} FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES (#{csv_fields.join(',')}) set pubpd = str_to_date(@pubpd, '%d/%m/%Y'),
	embd = str_to_date(@embd, '%d/%m/%Y'),
	mopd = str_to_date(@mopd, '%d/%m/%Y'),
	gbpccplcd = str_to_date(@gbpccplcd, '%d/%m/%Y'),
	usdccplcd = str_to_date(@usdccplcd, '%d/%m/%Y'),
	audccplcd = str_to_date(@audccplcd, '%d/%m/%Y'),
	ausnbdead = str_to_date(@ausnbdead, '%d/%m/%Y'),
	ausnbdpacd = str_to_date(@ausnbdpacd, '%d/%m/%Y'),
	ausnbdpaslcd = str_to_date(@ausnbdpaslcd, '%d/%m/%Y'),
 product_category_id = @default_product_category_id, product_content_type_id = @default_product_content_type_id, 
	availability_status_id = @default_availability_status_id, publishing_status_id = @default_publishing_status_id, 
	created_at = NOW(), updated_at = NOW(), csv_file_source = '#{csv_name}'")
end	



#~ mysqldump test_berkelouw tmp_2010_06_03 > tmp_product_without_association_initial_load_2010_06_03.sql

#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_00.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_01.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_02.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_03.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_04.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_05.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_06.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_07.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_08.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_09.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_10.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_11.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_12.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_13.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_14.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_15.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_16.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_17.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_18.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_19.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_20.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_21.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_22.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_23.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_24.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_25.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_26.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_27.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_28.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_29.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_30.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_31.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_32.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_33.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_34.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_35.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_36.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_37.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_38.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_39.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_40.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_41.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_42.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_00_20100423_43.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_00.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_01.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_02.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_03.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_04.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_05.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_06.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_07.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_08.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_09.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_10.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_11.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_12.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_13.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_14.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_15.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_16.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_17.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_18.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_19.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_20.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_21.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_22.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_23.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_24.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_25.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_26.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_27.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_28.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_29.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_30.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_31.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_32.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_33.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_34.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_35.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_36.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_37.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_38.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_39.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_40.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_41.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_42.add.zip
#~ unzip /var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs/11730_12036_01_20100423_43.add.zip




#~ *** glibc detected *** ruby: free(): invalid next size (fast): 0x0918ddd8 ***
#~ ======= Backtrace: =========
#~ /lib/libc.so.6[0xb7dfc845]
#~ /lib/libc.so.6(cfree+0x9c)[0xb7dfe6ec]
#~ ruby(st_free_table+0x44)[0x80c01d4]
#~ ruby[0x8076485]
#~ ruby[0x8076f20]
#~ ruby[0x80770b6]
#~ ruby(ruby_xmalloc+0xb5)[0x80772c5]
#~ ruby[0x80561c4]
#~ ruby[0x8058c29]
#~ ruby[0x80592dc]
#~ ruby[0x805db61]
#~ ruby[0x805d772]
#~ ruby[0x805ffc9]
#~ ruby[0x8060220]
#~ ruby[0x806ae29]
#~ ruby[0x806a034]
#~ ruby[0x806aad3]
#~ ruby[0x805ffc9]
#~ ruby[0x8060220]
#~ ruby[0x806abf1]
#~ ruby[0x806a034]
#~ ruby[0x805da73]
#~ ruby[0x805d772]
#~ ruby[0x806a41c]
#~ ruby[0x805dd50]
#~ ruby[0x805ffc9]
#~ ruby[0x8060220]
#~ ruby[0x806ae29]
#~ ruby[0x806a034]
#~ ruby[0x806a41c]
#~ ruby[0x805dd50]
#~ ruby[0x805ffc9]
#~ ruby[0x8060220]
#~ ruby[0x806ae29]
#~ ruby[0x805ffc9]
#~ ruby[0x8060220]
#~ ruby(rb_call_super+0x68)[0x805d438]
#~ ruby[0x805d5fe]
#~ ruby[0x805d772]
#~ ruby[0x805ffc9]
#~ ruby[0x8060220]
#~ ruby[0x806abf1]
#~ ruby[0x806aa7d]
#~ ruby[0x805ffc9]
#~ ruby[0x8060220]
#~ ruby[0x806ae29]
#~ ruby[0x805d772]
#~ ruby[0x805e850]
#~ ruby(rb_yield+0x50)[0x80690e0]
#~ ruby(rb_ary_each+0x31)[0x80d5671]
#~ ruby[0x80600cf]
#~ ruby[0x8060220]
#~ ruby[0x806abf1]
#~ ruby[0x806a034]
#~ ruby[0x806d7cd]
#~ ruby(ruby_exec+0x16)[0x806d806]
#~ ruby(ruby_run+0x21)[0x806d831]
#~ ruby[0x80555af]
#~ /lib/libc.so.6(__libc_start_main+0xe5)[0xb7da8455]
#~ ruby[0x80554d1]
#~ ======= Memory map: ========
#~ 08048000-08106000 r-xp 00000000 ca:01 102107     /usr/bin/ruby
#~ 08106000-08107000 rw-p 000be000 ca:01 102107     /usr/bin/ruby
#~ 08107000-092d4000 rw-p 08107000 00:00 0          [heap]
#~ b5700000-b5721000 rw-p b5700000 00:00 0 
#~ b5721000-b5800000 ---p b5721000 00:00 0 
#~ b583c000-b5848000 r-xp 00000000 ca:01 345040     /lib/libgcc_s.so.1
#~ b5848000-b5849000 rw-p 0000b000 ca:01 345040     /lib/libgcc_s.so.1
#~ b5849000-b5852000 r-xp 00000000 ca:01 345102     /lib/libnss_files-2.7.so
#~ b5852000-b5854000 rw-p 00008000 ca:01 345102     /lib/libnss_files-2.7.so
#~ b5854000-b5867000 r-xp 00000000 ca:01 345092     /lib/libnsl-2.7.so
#~ b5867000-b5869000 rw-p 00012000 ca:01 345092     /lib/libnsl-2.7.so
#~ b5869000-b586b000 rw-p b5869000 00:00 0 
#~ b5873000-b5a17000 r-xp 00000000 ca:01 134515     /usr/lib/libmysqlclient.so.15.0.0
#~ b5a17000-b5a5b000 rw-p 001a3000 ca:01 134515     /usr/lib/libmysqlclient.so.15.0.0
#~ b5a5b000-b5a5c000 rw-p b5a5b000 00:00 0 
#~ b5a5c000-b5a6f000 r-xp 00000000 ca:01 298047     /usr/lib/ruby/gems/1.8/gems/mysql-2.8.1/lib/mysql_api.so
#~ b5a6f000-b5a70000 rw-p 00013000 ca:01 298047     /usr/lib/ruby/gems/1.8/gems/mysql-2.8.1/lib/mysql_api.so
#~ b5a70000-b710e000 rw-p b5a70000 00:00 0 
#~ b710e000-b710f000 r-xp 00000000 ca:01 281187     /usr/lib/ruby/1.8/i686-linux/digest/sha1.so
#~ b710f000-b7110000 rw-p 00000000 ca:01 281187     /usr/lib/ruby/1.8/i686-linux/digest/sha1.so
#~ b7110000-b7160000 r-xp 00000000 ca:01 283270     /usr/lib/ruby/site_ruby/1.8/i686-linux/redcloth_scan.so
#~ b7160000-b7161000 rw-p 0004f000 ca:01 283270     /usr/lib/ruby/site_ruby/1.8/i686-linux/redcloth_scan.so
#~ b7161000-b7169000 r-xp 00000000 ca:01 281179     /usr/lib/ruby/1.8/i686-linux/zlib.so
#~ b7169000-b716a000 rw-p 00007000 ca:01 281179     /usr/lib/ruby/1.8/i686-linux/zlib.so
#~ b716a000-b75e0000 rw-p b716a000 00:00 0 
#~ b75e0000-b75f4000 r-xp 00000000 ca:01 134665     /usr/lib/libz.so.1.2.3.3
#~ b75f4000-b75f5000 rw-p 00013000 ca:01 134665     /usr/lib/libz.so.1.2.3.3
#~ b75f5000-b772f000 r-xp 00000000 ca:01 166691     /usr/lib/i686/cmov/libcrypto.so.0.9.8
#~ b772f000-b7745000 rw-p 0013a000 ca:01 166691     /usr/lib/i686/cmov/libcrypto.so.0.9.8
#~ b7745000-b7748000 rw-p b7745000 00:00 0 
#~ b7748000-b778b000 r-xp 00000000 ca:01 166690     /usr/lib/i686/cmov/libssl.so.0.9.8
#~ b778b000-b778f000 rw-p 00042000 ca:01 166690     /usr/lib/i686/cmov/libssl.so.0.9.8
#~ b778f000-b7790000 r-xp 00000000 ca:01 281183     /usr/lib/ruby/1.8/i686-linux/digest/md5.so
#~ b7790000-b7791000 rw-p 00000000 ca:01 281183     /usr/lib/ruby/1.8/i686-linux/digest/md5.so
#~ b7791000-b7792000 r-xp 00000000 ca:01 281199     /usr/lib/ruby/1.8/i686-linux/fcntl.so
#~ b7792000-b7793000 rw-p 00000000 ca:01 281199     /usr/lib/ruby/1.8/i686-linux/fcntl.so
#~ b7793000-b7796000 r-xp 00000000 ca:01 281197     /usr/lib/ruby/1.8/i686-linux/digest.so
#~ b7796000-b7797000 rw-p 00002000 ca:01 281197     /usr/lib/ruby/1.8/i686-linux/digest.so
#~ b7797000-b77d7000 r-xp 00000000 ca:01 281204     /usr/lib/ruby/1.8/i686-linux/openssl.so
#~ b77d7000-b77d9000 rw-p 0003f000 ca:01 281204     /usr/lib/ruby/1.8/i686-linux/openssl.so
#~ b77d9000-b77e2000 r-xp 00000000 ca:01 281194     /usr/lib/ruby/1.8/i686-linux/socket.so
#~ b77e2000-b77e3000 rw-p 00009000 ca:01 281194     /usr/lib/ruby/1.8/i686-linux/socket.so
#~ b77e3000-b7a58000 rw-p b77e3000 00:00 0 
#~ b7a58000-b7a5b000 r-xp 00000000 ca:01 281196     /usr/lib/ruby/1.8/i686-linux/racc/cparse.so
#~ b7a5b000-b7a5c000 rw-p 00002000 ca:01 281196     /usr/lib/ruby/1.8/i686-linux/racc/cparse.so
#~ b7a5c000-b7a60000 r-xp 00000000 ca:01 281201     /usr/lib/ruby/1.8/i686-linux/strscan.so
#~ b7a60000-b7a61000 rw-p 00003000 ca:01 281201     /usr/lib/ruby/1.8/i686-linux/strscan.so
#~ b7a61000-b7a68000 r--s 00000000 ca:01 180801     /usr/lib/gconv/gconv-modules.cache
#~ b7a68000-b7a6b000 r-xp 00000000 ca:01 281181     /usr/lib/ruby/1.8/i686-linux/iconv.so
#~ b7a6b000-b7a6c000 rw-p 00002000 ca:01 281181     /usr/lib/ruby/1.8/i686-linux/iconv.so
#~ b7a6c000-b7a76000 r-xp 00000000 ca:01 281188     /usr/lib/ruby/1.8/i686-linux/bigdecimal.so
#~ b7a76000-b7a77000 rw-p 00009000 ca:01 281188     /usr/lib/ruby/1.8/i686-linux/bigdecimal.so
#~ b7a77000-b7ab0000 r-xp 00000000 ca:01 281202     /usr/lib/ruby/1.8/i686-linux/nkf.so
#~ b7ab0000-b7ab3000 rw-p 00038000 ca:01 281202     /usr/lib/ruby/1.8/i686-linux/nkf.so
#~ b7ab3000-b7cc6000 rw-p b7ab3000 00:00 0 
#~ b7cc6000-b7ce0000 r-xp 00000000 ca:01 281207     /usr/lib/ruby/1.8/i686-linux/syck.so
#~ b7ce0000-b7ce1000 rw-p 0001a000 ca:01 281207     /usr/lib/ruby/1.8/i686-linux/syck.so
#~ b7ce1000-b7ce5000 r-xp 00000000 ca:01 281191     /usr/lib/ruby/1.8/i686-linux/stringio.so
#~ b7ce5000-b7ce6000 rw-p 00003000 ca:01 281191     /usr/lib/ruby/1.8/i686-linux/stringio.so
#~ b7ce6000-b7d7a000 rw-p b7ce6000 00:00 0 
#~ b7d7a000-b7d8e000 r-xp 00000000 ca:01 345090     /lib/libpthread-2.7.so
#~ b7d8e000-b7d90000 rw-p 00013000 ca:01 345090     /lib/libpthread-2.7.so
#~ b7d90000-b7d92000 rw-p b7d90000 00:00 0 
#~ b7d92000-b7eca000 r-xp 00000000 ca:01 345097     /lib/libc-2.7.so
#~ b7eca000-b7ecb000 r--p 00138000 ca:01 345097     /lib/libc-2.7.so
#~ b7ecb000-b7ecd000 rw-p 00139000 ca:01 345097     /lib/libc-2.7.so
#~ b7ecd000-b7ed0000 rw-p b7ecd000 00:00 0 
#~ b7ed0000-b7ef4000 r-xp 00000000 ca:01 345082     /lib/libm-2.7.so
#~ b7ef4000-b7ef6000 rw-p 00023000 ca:01 345082     /lib/libm-2.7.so
#~ b7ef6000-b7ef7000 rw-p b7ef6000 00:00 0 
#~ b7ef7000-b7f00000 r-xp 00000000 ca:01 345086     /lib/libcrypt-2.7.so
#~ b7f00000-b7f02000 rw-p 00008000 ca:01 345086     /lib/libcrypt-2.7.so
#~ b7f02000-b7f29000 rw-p b7f02000 00:00 0 
#~ b7f29000-b7f2b000 r-xp 00000000 ca:01 345094     /lib/libdl-2.7.so
#~ b7f2b000-b7f2d000 rw-p 00001000 ca:01 345094     /lib/libdl-2.7.so
#~ b7f2d000-b7f34000 r-xp 00000000 ca:01 345100     /lib/librt-2.7.so
#~ b7f34000-b7f36000 rw-p 00006000 ca:01 345100     /lib/librt-2.7.so
#~ b7f36000-b7f37000 rw-p b7f36000 00:00 0 
#~ b7f37000-b7f39000 r-xp 00000000 ca:01 281193     /usr/lib/ruby/1.8/i686-linux/etc.so
#~ b7f39000-b7f3a000 rw-p 00001000 ca:01 281193     /usr/lib/ruby/1.8/i686-linux/etc.so
#~ b7f3a000-b7f3d000 r-xp 00000000 ca:01 281211     /usr/lib/ruby/1.8/i686-linux/thread.so
#~ b7f3d000-b7f3e000 rw-p 00002000 ca:01 281211     /usr/lib/ruby/1.8/i686-linux/thread.so
#~ b7f3e000-b7f41000 rw-p b7f3e000 00:00 0 
#~ b7f41000-b7f42000 r-xp b7f41000 00:00 0          [vdso]
#~ b7f42000-b7f5c000 r-xp 00000000 ca:01 345085     /lib/ld-2.7.so
#~ b7f5c000-b7f5e000 rw-p 0001a000 ca:01 345085     /lib/ld-2.7.so
#~ bf686000-bfd82000 rw-p bf686000 00:00 0          [stack]

#~ REPAIR TABLE `tmp_2010_06_03`  
#~ test_berkelouw.tmp_2010_06_03  	repair  	info  	Key 1 - Found wrong stored record at 1969282772
#~ test_berkelouw.tmp_2010_06_03 	repair 	info 	Found link that points at 3473120096001616238 (out...
#~ test_berkelouw.tmp_2010_06_03 	repair 	info 	Found link that points at 3458767079308931378 (out...
#~ test_berkelouw.tmp_2010_06_03 	repair 	info 	Key 12 - Found wrong stored record at 1319321072
#~ test_berkelouw.tmp_2010_06_03 	repair 	status 	Operation failed
