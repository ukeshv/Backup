module BookdataAdditionalMethods
   require 'rubygems'
   require 'mysql'   
	FIELDS = %w{isbn13 la tl pt1 pvno1 pt2 pvno2 st ys sn nws issn cr1 crt1 cci1 cns1 cr2 crt2 cci2 cns2 cr3 crt3 cci3 cns3 hmm wmm smm wg edsl pfc pfct pctc1 pctct1 pctc2 pctct2 pctc3 pctct3 pctc4 pctct4 pctc5 pctct5 pctc6 pctct6 pctc7 pctct7 pctc8 pctct8 pctc9 pctct9 pctc10 pctct10 pagnum noi run ill ms1 ms2 nop cis ept epf epfs epss tfc1 tft1 tfc2 tft2 tfc3 tft3 tfc4 tft4 tfc5 tft5 ts oac1 oat1 oac2 oat2 oac3 oat3 oac4 oat4 oac5 oat5 oac6 oat6 oac7 oat7 oac8 oat8 oac9 oat9 oac10 oat10 bic2sc1 bic2st1 bic2sc2 bic2st2 bic2sc3 bic2st3 bic2sc4 bic2st4 bic2sc5 bic2st5 bic2qc1 bic2qt1 bic2qc2 bic2qt2 bic2qc3 bic2qt3 bic2qc4 bic2qt4 bic2qc5 bic2qt5 repis13 repbis13 pubais13 epris13 epbis13 psf aussd ausld ausbiog austoc kirkukrev kirkusrev impn impid pubn pubid pop cop @pubpd @embd @mopd pubsc pubst gbpccpra gbpccprrrp gbpccprsn gbpccprc gbpccprtop gbpccprrrplt gbpccprpn @gbpccplcd usdccpra usdccprrrp usdccprsn usdccprc usdccprtop usdccprrrplt usdccprpn @usdccplcd audccpra audccprrrp audccprsn audccprc audccprtop audccprrrplt audccprpn @audccplcd ausnbdaa ausnbdasn @ausnbdead @ausnbdpacd ausnbdot ausnbdpq @ausnbdpaslcd ausnbdpac ausnbdpat ausadn1 ausadi1 ausadn2 ausadi2 wslruk wslrexuk imagflag}
	RELATION_FIELDS = %w{product_category_id product_content_type_id availability_status_id publishing_status_id csv_supplier_id}
  PRODUCT_TABLE = 'products'
  PRODUCT_SUPPLIER_TABLE = 'products_suppliers'
	
  #########################
	#     Add CSV supportive methods       #
  #########################

	def insert_records_from_tmp_table(table_name) # 2
		csv_fields = (FIELDS+RELATION_FIELDS).map{|x| x.sub('@','')} + ['csv_file_source', 'created_at', 'updated_at']
    csv_name = self.csv_name
		#~ process_sql("insert into #{PRODUCT_TABLE} (#{csv_fields.join(',')}) (select #{(csv_fields).join(',')} from #{table_name}) ON DUPLICATE KEY UPDATE #{PRODUCT_TABLE}.update_csv_file_source = '#{table_name}'", true) 
    # Query splitted into many parts, in such that it will inserts 1000 data every time
    writelog("Newly updated query starts running..")    
    connection_obj = Mysql.new("localhost", "#{DATABASE_CONFIG['username']}", "#{DATABASE_CONFIG['password']}", "#{DATABASE_CONFIG['database']}")
    total_count = connection_obj.query("select count(*) from #{table_name}").fetch_row[0].to_i				
		processed_rows = 0				
		while processed_rows < total_count
			#~ result_obj = connection_obj.query("select #{(csv_fields).join(',')} from #{table_name} where id > #{processed_rows} limit 1000")
      process_sql("insert into #{PRODUCT_TABLE} (#{csv_fields.join(',')}) (select #{(csv_fields).join(',')} from #{table_name} where id > #{processed_rows} limit 1000) ON DUPLICATE KEY UPDATE #{PRODUCT_TABLE}.update_csv_file_source = '#{table_name}'", true) 
			processed_rows += 1000
		end		
    connection_obj.close        
    writelog("Newly updated query finished")
    
    # NOTE: this sql (ON DUPLICATE KEY UPDATE) will not return the currect inserted count. so we need to find out seperately
    inserted_record_count = count_from(PRODUCT_TABLE, "#{PRODUCT_TABLE}.update_csv_file_source IS NULL and #{PRODUCT_TABLE}.csv_file_source = '#{csv_name}'") 
		insertable_record_count =  count_from(table_name)
        update_genre_products_data(table_name)		
    return drop_tmp_table(table_name, insertable_record_count, inserted_record_count, 'Inserted')
	end

	def fix_records_in_tmp_table_by_update(table_name) # 3
    writelog "Fixing issue in tmp table #{table_name}, action 'add'"
		updatable_count = count_from(PRODUCT_TABLE, "#{PRODUCT_TABLE}.update_csv_file_source = '#{table_name}'")
		#~ updated_count = process_sql("update #{PRODUCT_TABLE}, #{table_name} SET  #{updatable_product_fields_as_query_string(table_name)} where #{PRODUCT_TABLE}.update_csv_file_source = '#{table_name}' and #{PRODUCT_TABLE}.isbn13 = #{table_name}.isbn13", true)
    updated_count =  slow_update(table_name, updatable_count, "#{PRODUCT_TABLE}.update_csv_file_source = '#{table_name}'")
    return drop_tmp_table(table_name, updatable_count, updated_count, 'Updated (to fix csv action: add)')
	end
  

  #########################
	#     Upd CSV supportive methods       #
  #########################
  
  def slow_update(table_name, max, additional_where_cause=nil)
    count = i = 0    
    additional_where_cause = additional_where_cause ? " and #{additional_where_cause} " : ''
    while i < max do
		  count += process_sql("update #{PRODUCT_TABLE}, #{table_name} SET  #{updatable_product_fields_as_query_string(table_name)} where #{table_name}.id > #{i} and #{table_name}.id <= #{i + 500} and #{PRODUCT_TABLE}.isbn13 = #{table_name}.isbn13 #{additional_where_cause}", true)
      i += 500  
    end
    count    
  end
  
  def update_records_from_tmp_table(table_name) # 2
    updatable_record_count =  count_from(table_name)
    updated_record_count = slow_update(table_name, updatable_record_count) # updatable_record_count = Max id. In tmp table
		updatable_record_count =  count_from(table_name) 
		update_genre_products_data(table_name)
		return drop_tmp_table(table_name, updatable_record_count, updated_record_count, 'Updated')
  end

	def fix_records_in_tmp_table_by_insert(table_name) # 3
    writelog "Fixing issue in in tmp table #{table_name}, action 'upd'"
    csv_fields = (FIELDS+RELATION_FIELDS).map{|x| x.sub('@','')} + ['csv_file_source', 'created_at', 'updated_at']
    unmatched_isbns_in_tmp_table = process_sql("select #{table_name}.isbn13 from #{PRODUCT_TABLE} right join #{table_name} on #{PRODUCT_TABLE}.isbn13 = #{table_name}.isbn13 where #{PRODUCT_TABLE}.isbn13 IS NULL")
    isbns = mysql_column_to_ruby_array(unmatched_isbns_in_tmp_table)
    if isbns.blank?
      writelog "The non-updated records in tmp table (#{table_name}) must be identical in #{PRODUCT_TABLE}. So ignoring this issue. No need of fix."
      return true
    else  
      inserted_record_count = process_sql("insert into #{PRODUCT_TABLE}(#{csv_fields.join(',')}) select #{csv_fields.join(',')} from #{table_name} where #{table_name}.isbn13 in (#{isbns.join(',')})", true)
      return drop_tmp_table(table_name, isbns.length, inserted_record_count, 'Inserted (to fix csv action: upd)')
    end  
	end


  #########################
	#Product Supplier supportive methods#
  #########################
  
 def update_product_supplier(tmp_product_supplier_table)
  writelog "About to generate new products_supplier_table AS #{tmp_product_supplier_table}"
  process_sql("DROP TABLE IF EXISTS #{tmp_product_supplier_table}")
  process_sql("CREATE TABLE #{tmp_product_supplier_table} LIKE #{PRODUCT_SUPPLIER_TABLE}")
  process_sql("INSERT INTO #{tmp_product_supplier_table} (product_id, supplier_id, created_at, updated_at) select id,csv_supplier_id,NOW(),NOW() from #{PRODUCT_TABLE} where csv_supplier_id is not null and csv_supplier_id > 0")
  process_sql("select id into @default_rarebook_id from suppliers where nbd_org_id=99999999 limit 1")
  process_sql("INSERT INTO #{tmp_product_supplier_table} (product_id, supplier_id, created_at, updated_at) select id,@default_rarebook_id,NOW(),NOW() from #{PRODUCT_TABLE} where product_category_id = 2")
  writelog "products_supplier_table created AS #{tmp_product_supplier_table}, and loaded with data from #{PRODUCT_TABLE}"
 end


	#########################
	#                     Helpers                        #
	#########################

def mysql_column_to_ruby_array(mysql_result)
  x = true
  isbns = []
  while x do 
    x = mysql_result.fetch_row
    isbns << x[0] unless x.blank?
  end	
  isbns
end

	def fields_matching_csv(csv)
		head = `head -1 #{csv}`
		fields = head.gsub(/\r/,'').gsub(/\n/,'').downcase.split(',')
  	fields = fields.map{|x| (FIELDS.include?(x) ? x : (FIELDS.include?("@#{x}") ? "@#{x}" : '@dummy'))}
		writelog "csv #{csv} fields - #{fields.inspect}"
		return fields
	end


  def writelog(message, sql=false)
    if sql
      puts "<div class='sql'> #{Time.current} - #{message}</div>"
    else  
	    puts "<div class='other'> #{Time.current} - #{message}</div>"
    end  
  end 
 
  def updatable_product_fields_as_query_string(table_name)
		csv_fields = (FIELDS+RELATION_FIELDS).map{|x| x.sub('@','')}
    csv_name = self.csv_name
		str = ["#{PRODUCT_TABLE}.csv_file_source = '#{csv_name}'", "#{PRODUCT_TABLE}.update_csv_file_source = NULL",  "#{PRODUCT_TABLE}.updated_at = #{table_name}.updated_at"]
		csv_fields.each{ |x| str << "#{PRODUCT_TABLE}.#{x} = #{table_name}.#{x}"}
		str.join(',')
	end
	
	def create_tmp_table_with_csv(csv, table_name, only_isbn=false) # 1
		csv_fields = self.csv_fields
    csv_name = self.csv_name
		if only_isbn
      process_sql("DROP TABLE IF EXISTS #{table_name}")
			process_sql("CREATE TABLE #{table_name} LIKE #{PRODUCT_TABLE}")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (ausnbdpac)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (ausnbdpat)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (pfc)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (pfct)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (pubsc)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (pubst)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (ausadn1)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (ausadn2)")
      #~ process_sql("ALTER TABLE #{table_name} ADD INDEX (csv_file_source)")
			process_sql("LOAD DATA LOCAL INFILE '#{csv}' INTO TABLE #{table_name} FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES (isbn13#{', @dummy'*(csv_fields.length-1)});")
			writelog("created tmp table (#{table_name}), and loaded only ISBN names from csv - #{csv}")
		else
		  process_sql("DROP TABLE IF EXISTS #{table_name}")
			process_sql("CREATE TABLE #{table_name} LIKE #{PRODUCT_TABLE}") 
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (ausnbdpac)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (ausnbdpat)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (pfc)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (pfct)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (pubsc)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (pubst)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (ausadn1)")
			#~ process_sql("ALTER TABLE #{table_name} ADD INDEX (ausadn2)")
      #~ process_sql("ALTER TABLE #{table_name} ADD INDEX (csv_file_source)")
			process_sql("select id into @default_product_category_id from product_categories where name='books' limit 1")
			process_sql("select id into @default_product_content_type_id from product_content_types where name='Undefined' limit 1") 
			process_sql("select id into @default_publishing_status_id from publishing_statuses where name='Unspecified' limit 1") 
			process_sql("select id into @default_availability_status_id from availability_statuses where code=0 limit 1") 
			process_sql("set @default_csv_supplier_id = NULL") 
			process_sql("LOAD DATA LOCAL INFILE '#{csv}' INTO TABLE #{table_name} FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES (#{csv_fields.join(',')}) set pubpd = str_to_date(@pubpd, '%d/%m/%Y'),
			embd = str_to_date(@embd, '%d/%m/%Y'),
			mopd = str_to_date(@mopd, '%d/%m/%Y'),
			gbpccplcd = str_to_date(@gbpccplcd, '%d/%m/%Y'),
			usdccplcd = str_to_date(@usdccplcd, '%d/%m/%Y'),
			audccplcd = str_to_date(@audccplcd, '%d/%m/%Y'),
			ausnbdead = str_to_date(@ausnbdead, '%d/%m/%Y'),
			ausnbdpacd = str_to_date(@ausnbdpacd, '%d/%m/%Y'),
			ausnbdpaslcd = str_to_date(@ausnbdpaslcd, '%d/%m/%Y'),
			product_category_id = @default_product_category_id, product_content_type_id = @default_product_content_type_id, 
			availability_status_id = @default_availability_status_id, publishing_status_id = @default_publishing_status_id,
			created_at = NOW(), updated_at = NOW(), csv_file_source = '#{csv_name}'")
			
			process_sql("UPDATE #{table_name} join product_content_types on #{table_name}.pfc = product_content_types.code set #{table_name}.product_content_type_id = product_content_types.id where #{table_name}.pfc is not null and #{table_name}.pfc <> '' and (#{table_name}.product_content_type_id = @default_product_content_type_id or #{table_name}.product_content_type_id = 0) and csv_file_source = '#{csv_name}'")
			process_sql("UPDATE #{table_name} join product_content_types on #{table_name}.pfct = product_content_types.name set #{table_name}.product_content_type_id = product_content_types.id where #{table_name}.pfct is not null and #{table_name}.pfct <> '' and  (#{table_name}.product_content_type_id = @default_product_content_type_id or #{table_name}.product_content_type_id = 0) and csv_file_source = '#{csv_name}'")
			
			process_sql("UPDATE #{table_name} join availability_statuses on #{table_name}.ausnbdpac = availability_statuses.code set #{table_name}.availability_status_id = availability_statuses.id where #{table_name}.ausnbdpac is not null and #{table_name}.ausnbdpac <> '' and (#{table_name}.availability_status_id = @default_availability_status_id or #{table_name}.availability_status_id = 0) and csv_file_source = '#{csv_name}'")
			process_sql("UPDATE #{table_name} join availability_statuses on #{table_name}.ausnbdpat = availability_statuses.name set #{table_name}.availability_status_id = availability_statuses.id where #{table_name}.ausnbdpat is not null and #{table_name}.ausnbdpat <> '' and  (#{table_name}.availability_status_id = @default_availability_status_id or #{table_name}.availability_status_id = 0) and csv_file_source = '#{csv_name}'")

			process_sql("UPDATE #{table_name} join publishing_statuses on #{table_name}.pubsc = publishing_statuses.code set #{table_name}.publishing_status_id = publishing_statuses.id where #{table_name}.pubsc is not null and #{table_name}.pubsc <> '' and (#{table_name}.publishing_status_id = @default_publishing_status_id or #{table_name}.publishing_status_id = 0) and csv_file_source = '#{csv_name}'")
			process_sql("UPDATE #{table_name} join publishing_statuses on #{table_name}.pubst = publishing_statuses.name set #{table_name}.publishing_status_id = publishing_statuses.id where #{table_name}.pubst is not null and #{table_name}.pubst <> '' and (#{table_name}.publishing_status_id = @default_publishing_status_id or #{table_name}.publishing_status_id = 0) and csv_file_source = '#{csv_name}'")

			process_sql("UPDATE #{table_name} join suppliers on #{table_name}.ausadi1 = suppliers.nbd_org_id set #{table_name}.csv_supplier_id = suppliers.id where #{table_name}.ausadi1 is not null and #{table_name}.ausadi1 <> '' and (#{table_name}.csv_supplier_id is null or #{table_name}.csv_supplier_id = 0) and csv_file_source = '#{csv_name}'")
			process_sql("UPDATE #{table_name} join suppliers on #{table_name}.ausadn1 = suppliers.nbd_org_name set #{table_name}.csv_supplier_id = suppliers.id where #{table_name}.ausadn1 is not null and #{table_name}.ausadn1 <> '' and (#{table_name}.csv_supplier_id is null or #{table_name}.csv_supplier_id = 0) and csv_file_source = '#{csv_name}'")
			#~ process_sql("UPDATE #{table_name} join suppliers on #{table_name}.ausadi2 = suppliers.nbd_org_id set #{table_name}.csv_supplier_id = suppliers.id where #{table_name}.ausadi2 is not null and #{table_name}.ausadi2 <> '' and (#{table_name}.csv_supplier_id is null or #{table_name}.csv_supplier_id = 0) and csv_file_source = '#{csv_name}'")
			#~ process_sql("UPDATE #{table_name} join suppliers on #{table_name}.ausadn2 = suppliers.nbd_org_name set #{table_name}.csv_supplier_id = suppliers.id where #{table_name}.ausadn2 is not null and #{table_name}.ausadn2 <> '' and (#{table_name}.csv_supplier_id is null or #{table_name}.csv_supplier_id = 0) and csv_file_source = '#{csv_name}'")

		  writelog("created tmp table (#{table_name}), and loaded all columns from csv - #{csv}, and relation fields from appropriate tables")
		end
	end

	def drop_tmp_table(table_name, processable_count, processed_count, action)
		if processable_count == processed_count
			process_sql("drop table #{table_name}")
			writelog "#{action} #{processed_count} / #{processable_count} records in #{PRODUCT_TABLE} successfully from tmp table '#{table_name}'. And tmp table destroyed"
      return true
		else
			writelog "oops! #{action} #{processed_count} / #{processable_count} records in #{PRODUCT_TABLE} from tmp table '#{table_name}'. plz check issue manually"
			writelog "Tmp table #{table_name} NOT destroyed. please varify issue in that table..."
      return false
		end
	end

	def process_sql(sql, update=false)
		#writelog("- SQL - #{sql}", true)
		if update	
			ActiveRecord::Base.connection.update_sql(sql).to_i
		else       
			ActiveRecord::Base.connection.execute(sql)
		end	
	end

	def count_from(table_name, conditions=nil)
      if conditions
		 (process_sql("select count(id) from #{table_name} where #{conditions}").fetch_row)[0].to_i
      else
		 (process_sql("select count(id) from #{table_name}").fetch_row)[0].to_i
      end   
   end

def update_genre_products_data(table_name)
    db_connection = Mysql.new("localhost", "#{DATABASE_CONFIG['username']}", "#{DATABASE_CONFIG['password']}", "#{DATABASE_CONFIG['database']}")
    writelog "updating Genre_products data from the #{table_name}" 
    temp_result_set = db_connection.query("SELECT isbn13, bic2sc1, bic2sc2, bic2sc3, bic2sc4, bic2sc5 FROM #{table_name}") 
    process_sql("select id into @default_product_category_id from product_categories where name='books' limit 1")
    temp_result_set.each_hash  { |temp_product|  
      product_sql="SELECT id FROM #{PRODUCT_TABLE} WHERE (isbn13 = '#{temp_product['isbn13']}')"
      product_result = db_connection.query(product_sql)
      product_result.each_hash  { |product|     
        genre_sql = "SELECT id FROM genres WHERE (code = '#{temp_product['bic2sc1']}' OR code = '#{temp_product['bic2sc2']}' OR code = '#{temp_product['bic2sc3']}' OR code = '#{temp_product['bic2sc4']}' OR code = '#{temp_product['bic2sc5']}' AND product_category_id = @default_product_category_id)" 	 
        genre_result_set = db_connection.query(genre_sql)    
        db_connection.query("DELETE FROM genre_products WHERE product_id = #{product['id']}")
        genre_result_set.each_hash  { |genre| 	   	   	 
          db_connection.query("INSERT INTO genre_products(product_id, genre_id) VALUES (#{product['id']}, #{genre['id']})")  
        }
      }
    }
    writelog "genre_products successfully updated." 
   db_connection.close  
  end 
  
  def delete_genre_products_data(table_name)
    db_connection = Mysql.new("localhost", "#{DATABASE_CONFIG['username']}", "#{DATABASE_CONFIG['password']}", "#{DATABASE_CONFIG['database']}")
    writelog "deleting Genre_products data from the #{table_name} & Delete products from #{PRODUCT_TABLE} table" 
    temp_result_set = db_connection.query("SELECT isbn13 FROM #{table_name} ORDER BY id ASC") 
    deleted_count = 0
    temp_result_set.each_hash  { |temp_product|  
      product_sql="SELECT id FROM #{PRODUCT_TABLE} WHERE (isbn13 = '#{temp_product['isbn13']}')"
	    delete_product_result = db_connection.query(product_sql)
	    delete_product_result.each_hash  { |delete_product| 	   	   	 
        puts delete_sql="DELETE from genre_products where product_id='#{delete_product['id']}'"
        delete_product_query_sql=db_connection.query(delete_sql)
				puts delete_product_sql="DELETE from #{PRODUCT_TABLE} where id='#{delete_product['id']}' LIMIT 1"
        delete_product_query_sql=db_connection.query(delete_product_sql)
        deleted_count = deleted_count + 1
      }
	  }
    db_connection.close  
    return deleted_count
  end   
 
  
end

#~ CREATE TABLE IF NOT EXISTS `products_new` (
  #~ `id` int(11) NOT NULL auto_increment,
  #~ `product_department_id` int(11) default NULL,
  #~ `product_data_supplier_id` int(11) default NULL,
  #~ `isbn13` varchar(13) default NULL,
  #~ `la` varchar(20) default NULL,
  #~ `tl` text,
  #~ `pt1` text,
  #~ `pvno1` text,
  #~ `pt2` text,
  #~ `pvno2` text,
  #~ `st` text,
  #~ `ys` text,
  #~ `sn` text,
  #~ `nws` varchar(150) default NULL,
  #~ `issn` varchar(20) default NULL,
  #~ `cr1` varchar(20) default NULL,
  #~ `crt1` varchar(200) default NULL,
  #~ `cci1` varchar(20) default NULL,
  #~ `cns1` text,
  #~ `cr2` varchar(20) default NULL,
  #~ `crt2` varchar(200) default NULL,
  #~ `cci2` varchar(20) default NULL,
  #~ `cns2` text,
  #~ `cr3` varchar(20) default NULL,
  #~ `crt3` varchar(200) default NULL,
  #~ `cci3` varchar(20) default NULL,
  #~ `cns3` text,
  #~ `hmm` varchar(20) default NULL,
  #~ `wmm` varchar(20) default NULL,
  #~ `smm` varchar(20) default NULL,
  #~ `wg` varchar(20) default NULL,
  #~ `edsl` varchar(200) default NULL,
  #~ `pfc` varchar(20) default NULL,
  #~ `pfct` varchar(200) default NULL,
  #~ `pctc1` varchar(10) default NULL,
  #~ `pctct1` varchar(200) default NULL,
  #~ `pctc2` varchar(10) default NULL,
  #~ `pctct2` varchar(200) default NULL,
  #~ `pctc3` varchar(10) default NULL,
  #~ `pctct3` varchar(200) default NULL,
  #~ `pctc4` varchar(10) default NULL,
  #~ `pctct4` varchar(200) default NULL,
  #~ `pctc5` varchar(10) default NULL,
  #~ `pctct5` varchar(200) default NULL,
  #~ `pctc6` varchar(10) default NULL,
  #~ `pctct6` varchar(200) default NULL,
  #~ `pctc7` varchar(10) default NULL,
  #~ `pctct7` varchar(200) default NULL,
  #~ `pctc8` varchar(10) default NULL,
  #~ `pctct8` varchar(200) default NULL,
  #~ `pctc9` varchar(10) default NULL,
  #~ `pctct9` varchar(200) default NULL,
  #~ `pctc10` varchar(10) default NULL,
  #~ `pctct10` varchar(200) default NULL,
  #~ `pagnum` varchar(100) default NULL,
  #~ `noi` varchar(60) default NULL,
  #~ `run` varchar(20) default NULL,
  #~ `ill` text,
  #~ `ms1` varchar(50) default NULL,
  #~ `ms2` varchar(50) default NULL,
  #~ `nop` varchar(20) default NULL,
  #~ `cis` text,
  #~ `ept` text,
  #~ `epf` text,
  #~ `epfs` text,
  #~ `epss` varchar(40) default NULL,
  #~ `tfc1` varchar(20) default NULL,
  #~ `tft1` varchar(200) default NULL,
  #~ `tfc2` varchar(20) default NULL,
  #~ `tft2` varchar(200) default NULL,
  #~ `tfc3` varchar(20) default NULL,
  #~ `tft3` varchar(200) default NULL,
  #~ `tfc4` varchar(20) default NULL,
  #~ `tft4` varchar(200) default NULL,
  #~ `tfc5` varchar(20) default NULL,
  #~ `tft5` varchar(200) default NULL,
  #~ `ts` varchar(200) default NULL,
  #~ `oac1` varchar(20) default NULL,
  #~ `oat1` varchar(200) default NULL,
  #~ `oac2` varchar(20) default NULL,
  #~ `oat2` varchar(200) default NULL,
  #~ `oac3` varchar(20) default NULL,
  #~ `oat3` varchar(200) default NULL,
  #~ `oac4` varchar(20) default NULL,
  #~ `oat4` varchar(200) default NULL,
  #~ `oac5` varchar(20) default NULL,
  #~ `oat5` varchar(200) default NULL,
  #~ `oac6` varchar(20) default NULL,
  #~ `oat6` varchar(200) default NULL,
  #~ `oac7` varchar(20) default NULL,
  #~ `oat7` varchar(200) default NULL,
  #~ `oac8` varchar(20) default NULL,
  #~ `oat8` varchar(200) default NULL,
  #~ `oac9` varchar(20) default NULL,
  #~ `oat9` varchar(200) default NULL,
  #~ `oac10` varchar(20) default NULL,
  #~ `oat10` varchar(200) default NULL,
  #~ `bic2sc1` varchar(20) default NULL,
  #~ `bic2st1` varchar(200) default NULL,
  #~ `bic2sc2` varchar(20) default NULL,
  #~ `bic2st2` varchar(200) default NULL,
  #~ `bic2sc3` varchar(20) default NULL,
  #~ `bic2st3` varchar(200) default NULL,
  #~ `bic2sc4` varchar(20) default NULL,
  #~ `bic2st4` varchar(200) default NULL,
  #~ `bic2sc5` varchar(20) default NULL,
  #~ `bic2st5` varchar(200) default NULL,
  #~ `bic2qc1` varchar(20) default NULL,
  #~ `bic2qt1` varchar(200) default NULL,
  #~ `bic2qc2` varchar(20) default NULL,
  #~ `bic2qt2` varchar(200) default NULL,
  #~ `bic2qc3` varchar(20) default NULL,
  #~ `bic2qt3` varchar(200) default NULL,
  #~ `bic2qc4` varchar(20) default NULL,
  #~ `bic2qt4` varchar(200) default NULL,
  #~ `bic2qc5` varchar(20) default NULL,
  #~ `bic2qt5` varchar(200) default NULL,
  #~ `repis13` varchar(20) default NULL,
  #~ `repbis13` varchar(20) default NULL,
  #~ `pubais13` varchar(20) default NULL,
  #~ `epris13` varchar(20) default NULL,
  #~ `epbis13` varchar(20) default NULL,
  #~ `psf` text,
  #~ `aussd` text,
  #~ `ausld` text,
  #~ `ausbiog` text,
  #~ `austoc` text,
  #~ `kirkukrev` text,
  #~ `kirkusrev` text,
  #~ `impn` varchar(255) default NULL,
  #~ `impid` varchar(255) default NULL,
  #~ `pubn` varchar(255) default NULL,
  #~ `pubid` varchar(255) default NULL,
  #~ `pop` varchar(255) default NULL,
  #~ `cop` varchar(255) default NULL,
  #~ `pubpd` date default NULL,
  #~ `embd` date default NULL,
  #~ `mopd` date default NULL,
  #~ `pubsc` varchar(20) default NULL,
  #~ `pubst` varchar(200) default NULL,
  #~ `gbpccpra` varchar(20) default NULL,
  #~ `gbpccprrrp` varchar(20) default NULL,
  #~ `gbpccprsn` text,
  #~ `gbpccprc` varchar(20) default NULL,
  #~ `gbpccprtop` varchar(20) default NULL,
  #~ `gbpccprrrplt` varchar(20) default NULL,
  #~ `gbpccprpn` varchar(100) default NULL,
  #~ `gbpccplcd` date default NULL,
  #~ `usdccpra` varchar(20) default NULL,
  #~ `usdccprrrp` varchar(20) default NULL,
  #~ `usdccprsn` text,
  #~ `usdccprc` varchar(20) default NULL,
  #~ `usdccprtop` varchar(20) default NULL,
  #~ `usdccprrrplt` varchar(20) default NULL,
  #~ `usdccprpn` varchar(100) default NULL,
  #~ `usdccplcd` date default NULL,
  #~ `audccpra` varchar(20) default NULL,
  #~ `audccprrrp` varchar(20) default NULL,
  #~ `audccprsn` text,
  #~ `audccprc` varchar(20) default NULL,
  #~ `audccprtop` varchar(20) default NULL,
  #~ `audccprrrplt` varchar(20) default NULL,
  #~ `audccprpn` varchar(100) default NULL,
  #~ `audccplcd` date default NULL,
  #~ `ausnbdaa` varchar(20) default NULL,
  #~ `ausnbdasn` text,
  #~ `ausnbdead` date default NULL,
  #~ `ausnbdpacd` date default NULL,
  #~ `ausnbdot` varchar(20) default NULL,
  #~ `ausnbdpq` varchar(20) default NULL,
  #~ `ausnbdpaslcd` date default NULL,
  #~ `ausnbdpac` varchar(20) default NULL,
  #~ `ausnbdpat` varchar(100) default NULL,
  #~ `ausadn1` varchar(300) default NULL,
  #~ `ausadi1` varchar(30) default NULL,
  #~ `ausadn2` varchar(300) default NULL,
  #~ `ausadi2` varchar(30) default NULL,
  #~ `wslruk` varchar(200) default NULL,
  #~ `wslrexuk` varchar(200) default NULL,
  #~ `imagflag` varchar(10) default NULL,
  #~ `divert_image` tinyint(1) default NULL,
  #~ `divert_image_url` varchar(200) default NULL,
  #~ `created_at` datetime default NULL,
  #~ `updated_at` datetime default NULL,
  #~ `csv_file_source` varchar(100) default NULL,
  #~ `product_content_type_id` int(11) default NULL,
  #~ `availability_status_id` int(11) default '0',
  #~ `product_category_id` int(11) default NULL,
  #~ `publishing_status_id` int(11) default '0',
  #~ `discount` float default '0',
  #~ `rare_pubpd` varchar(255) default NULL,
  #~ `update_csv_file_source` varchar(255) default NULL,
  #~ `csv_supplier_id` int(11) default NULL,
  #~ `repeted_in_tmp_table` varchar(255) default NULL,
  #~ PRIMARY KEY  (`id`),
  #~ UNIQUE KEY `unique_isbn13` (`isbn13`),
  #~ KEY `index_products_on_ausadi1` (`ausadi1`),
  #~ KEY `index_products_on_ausadi2` (`ausadi2`),
  #~ KEY `index_products_on_pubpd` (`pubpd`),
  #~ KEY `index_products_on_bic2sc1` (`bic2sc1`),
  #~ KEY `index_products_on_bic2sc2` (`bic2sc2`),
  #~ KEY `index_products_on_bic2sc3` (`bic2sc3`),
  #~ KEY `index_products_on_bic2sc4` (`bic2sc4`),
  #~ KEY `index_products_on_bic2sc5` (`bic2sc5`),
  #~ KEY `index_products_on_product_department_id` (`product_department_id`),
  #~ KEY `index_products_on_product_data_supplier_id` (`product_data_supplier_id`),
  #~ KEY `index_products_on_imagflag` (`imagflag`),
  #~ KEY `index_products_on_product_content_type_id` (`product_content_type_id`),
  #~ KEY `index_products_on_availability_status_id` (`availability_status_id`),
  #~ KEY `index_products_on_product_category_id` (`product_category_id`),
  #~ KEY `index_products_on_publishing_status_id` (`publishing_status_id`),
  #~ KEY `csv_supplier_id` (`csv_supplier_id`),
  #~ KEY `repeted_in_csv` (`repeted_in_tmp_table`)
#~ )


#~ ALTER TABLE `suppliers` ADD INDEX ( `nbd_org_name` ) ;
#~ ALTER TABLE `availability_statuses` ADD INDEX ( `name` ); 
#~ ALTER TABLE `product_content_types` ADD INDEX ( `name` ); 
#~ ALTER TABLE `product_categories` ADD INDEX ( `name` );
#~ ALTER TABLE `publishing_statuses` ADD INDEX ( `name` ); 



## TODO:
#~ reset proper avilability status for these records.
#~ Query run in berkelouw_staging_MyISAM_15jun  on 19th Jun Sat morning. Before updating all availability_status_id to 23 from 0
#~ mysql> select id,ausnbdpac,ausnbdpat from products where availability_status_id = 23;
#~ +---------+----------------------+------------+
#~ | id      | ausnbdpac            | ausnbdpat  |
#~ +---------+----------------------+------------+
#~ |   34278 | Available            |            | 
                    #~ | NULL       | 
#~ |  948122 | GB                   | 8.99       | 
#~ | 1664585 | Turpin Distribution  | GBP        | 
#~ | 2023883 | Not available        |            | 
#~ | 2136116 | 0.00                 | 13.99      | 
#~ | 2147830 | To order             |            | 
                    #~ | NULL       | 
#~ | 4410078 | United States        | 01/09/2010 | 
#~ +---------+----------------------+------------+
#~ 9 rows in set (0.00 sec)
  




