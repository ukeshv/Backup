class NielsenDownloads
 	include FileUtils
  attr_accessor :error, :success
  
  def initialize(download_content, date=Date.current-1)
   return unless correct_download_content_requested(download_content)
   
   folder =  download_content == 'data' ? NIELSEN_CSV_DOWNLOAD_PATH : NIELSEN_IMAGE_DOWNLOAD_PATH
   return unless correct_folder_exists(folder)
   
   # TODO this check will not be needed if it is added in deployment script
   FileUtils.mkdir_p NIELSEN_LARGE_IMAGE_DOWNLOAD_PATH unless Dir.glob(NIELSEN_LARGE_IMAGE_DOWNLOAD_PATH).blank?
   FileUtils.mkdir_p NIELSEN_MEDIUM_IMAGE_DOWNLOAD_PATH unless Dir.glob(NIELSEN_MEDIUM_IMAGE_DOWNLOAD_PATH).blank?
   FileUtils.mkdir_p NIELSEN_SMALL_IMAGE_DOWNLOAD_PATH unless Dir.glob(NIELSEN_SMALL_IMAGE_DOWNLOAD_PATH).blank?
   
   constrain = date.respond_to?(:strftime)  ?  date.strftime('%Y%m%d') : date.to_s
   tmp_dir = "#{RAILS_ROOT}/tmp/nielsen_#{download_content}_#{Time.current.strftime('%Y_%m_%d_%H_%M_%S')}"
   
   FileUtils.mkdir_p tmp_dir

   system("cd #{tmp_dir} && wget ftp://BerkelouwRSS01:ld223hm469@ftp.recordsupply.nielsenbookdata.com/#{download_content}/*_#{constrain}_*.zip")
  
	 Dir.glob("#{tmp_dir}/*.zip").sort.each do |zip|
    system("unzip #{zip} -d #{download_content == 'images' ? find_folder_for_zip(zip) : folder}")
   end
   
   self.success = SUCCESS
 end

 def find_folder_for_zip(zip)
   img_folder = "#{zip.split('/').last.sub('.zip','')}"
   if img_folder.index('11730') == 0
    img_folder = "#{NIELSEN_LARGE_IMAGE_DOWNLOAD_PATH}/#{img_folder}"
   elsif img_folder.index('13270') == 0
    img_folder = "#{NIELSEN_MEDIUM_IMAGE_DOWNLOAD_PATH}/#{img_folder}"
   elsif  img_folder.index('11980') == 0
    img_folder = "#{NIELSEN_SMALL_IMAGE_DOWNLOAD_PATH}/#{img_folder}"
   end
   img_folder
 end

  def correct_download_content_requested(download_content)
    if download_content != 'data' &&  download_content != 'images'
     puts "plz select correct type. What should be downloaded (data or images) ??" 
     self.error = OPTION_ERROR
     return false
    end
    return true
  end

  def correct_folder_exists(folder)
   if Dir.glob(folder).blank?
     puts "plz create Folder: #{folder}" 
     self.error = PATH_ERROR
     return false
   end
    return true
  end

  def send_email(error)
    RECEPIANTS_TO_ALERT_ON_BACKGROUND_JOB_ERROR.each{|email| FtpMailer.deliver_error_mail(email,error)}
  end	
end
