class DataProcessing
 include FileUtils
 include BookdataAdditionalMethods
 attr_accessor :csv_fields, :csv_name
 
  def initialize(date=Date.current-1)
   auto_backup = AUTO_BACKUP_FILE_PATH
   FileUtils.rm auto_backup if File.exists?(auto_backup)
   
   #system("mysqldump -u app_user -pU1T4Tn8v  berkelouw_production_MyISAM | gzip > #{auto_backup}")
   #writelog "#{auto_backup} backuped at #{Time.current} before starting cronjob"
   
   start(NIELSEN_CSV_DOWNLOAD_PATH, 'add')
   start(NIELSEN_CSV_DOWNLOAD_PATH, 'upd')
   start(NIELSEN_CSV_DOWNLOAD_PATH, 'del')
   start_processing_product_supplier(date)
   #~ system("rake ts:reindex RAILS_ENV=production")
 end

 def start(dir, action)
  csv_files = (Dir.glob("#{dir}/*.#{action}")).sort
  writelog "Total #{csv_files.length} CSVs to process (#{action}) - #{csv_files.inspect}"
  csv_files.each do |csv|
   self.csv_fields = fields_matching_csv(csv)
   self.csv_name = csv.split('/').last
   table_name = csv.split('/').last.gsub(".","_")
   
   #Don't process this csv if already processed.
   next if csv_already_processed?
   
   #create_tmp_table
   create_tmp_table_with_csv(csv, table_name, action == 'del')
  
   case action
    when 'add'
    start_processing_add_csv(table_name, action)  
    when 'upd'
    start_processing_update_csv(table_name, action)
    when 'del' 
    start_processing_delete_csv(table_name, action)
   end
   
   system("mv #{csv} #{csv}.finished")
  end 
 end

 def csv_already_processed?
   # Though the csv_file_source use to be updated when a upd CSV loaded.
   # practically there is no chance  that all data of a CSV will be revised in next 2 days.
   # This check is to prevent accidental load more than once (which generally could possible, till the data exists in FTP, i.e 2 days).
   # so the purpose of this check will be solved.
   # And inspite of all, if a csv is processed twice, still it will not harm the data, but will unnecessaryly re-update all existing data.
   if Product.exists?(:csv_file_source => self.csv_name)
     writelog "#{self.csv_name} already processed. So skiping this csv" 
     return true
   end
   return false 
 end
 
  
 def start_processing_add_csv(table_name, action)  
  # insert all records in actial table from tmp table 
  # on duplicate key will mark the duplicate records in actual table on insert
  # if inserted record in actual table <> record in tmp table then we need a fix
  # update those marked records in actual table with values in tmp table to fix the issue
  result = insert_records_from_tmp_table(table_name)  
  fix_records_in_tmp_table_by_update(table_name) unless result
 end 


 def start_processing_update_csv(table_name, action) 
  # first update all records matching isbn from tmp table to actual table
  # if updated record in actual table <> record in tmp table then we need a fix
  # using right join find out the records not update in tmp table and do insert for those records to fix the issue
  result = update_records_from_tmp_table(table_name)   
  fix_records_in_tmp_table_by_insert(table_name) unless result
 end


 def start_processing_delete_csv(table_name, action)
  writelog "Deleting records in #{PRODUCT_TABLE} matching from tmp table #{table_name}"
  markable_record_count =  count_from(table_name)
  #updated_count = process_sql("delete from #{PRODUCT_TABLE} where #{PRODUCT_TABLE}.isbn13 in (select isbn13 from #{table_name})", true)
	#IMP*****delete products has been removed in the below delete_genre_products_data data itself
  updated_count = delete_genre_products_data(table_name)
  drop_tmp_table(table_name, markable_record_count, updated_count, 'Deleted')
 end
 
 def start_processing_product_supplier(date)
  tmp_product_supplier_table = "#{PRODUCT_SUPPLIER_TABLE}_#{Date.current.strftime("%Y_%m_%d")}"
  update_product_supplier(tmp_product_supplier_table)
  # verify new table do have data in it
  if (process_sql("select count(*) from #{tmp_product_supplier_table}").fetch_row)[0].to_i > 0 # NOTE: count(id) will not work for this table
   process_sql("rename table #{PRODUCT_SUPPLIER_TABLE} to #{tmp_product_supplier_table}_backup")
   process_sql("rename table #{tmp_product_supplier_table} to #{PRODUCT_SUPPLIER_TABLE}")
  end
 end  
  
end