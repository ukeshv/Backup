class NewImageExtract
	include FileUtils
	
	def initialize(test=false)
	 ['small','medium','large'].each do |process|
		 start(process, test)
	 end
	end

 def start(process, test)
	puts "processing folders: #{root_path(process)}/*" 
	Dir.glob("#{root_path(process)}/*").sort.each do |img_dir|
		writelog "processing Dir: #{img_dir}"
		operation_success = organize_in_folders_from(process, img_dir,test)
		if operation_success
			test ? writelog("printing-command: FileUtils.mv(#{img_dir}, '#{img_dir}.finished')") : FileUtils.mv(img_dir, "#{img_dir}.finished") 
		end	
		writelog "Dir: #{img_dir} - processed\n"
	end
	writelog "All Image Directories processed"
 end
 
	def organize_in_folders_from(process, img_dir,test)
		image_files = Dir.glob("#{img_dir}/*.jpg")
		writelog "Total Images in the directory: #{img_dir} - #{image_files.count}\n"
		image_files = image_files[0..5].compact if test
		image_files.each do |image|
      update_product_table(image.sub("#{img_dir}/",'').sub('.jpg',''))
			path = image.sub("#{img_dir}/",'').sub('.jpg','').sub(" ",'').split(//).join('/')
			if test
				writelog("printing-command: FileUtils.mkdir_p 	#{target_path(process)}/#{path}")
				writelog("printing-command: FileUtils.cp(#{image}, #{target_path(process)}/#{path}/#{image.split('/').last})")
			else	
				FileUtils.mkdir_p 	"#{target_path(process)}/#{path}"
				FileUtils.cp(image, "#{target_path(process)}/#{path}/#{image.split('/').last}")
			end
		end
	end

  def root_path(process)
		if process == 'small'
		  NIELSEN_SMALL_IMAGE_DOWNLOAD_PATH
		elsif process == 'medium'
		  NIELSEN_MEDIUM_IMAGE_DOWNLOAD_PATH
		else
		  NIELSEN_LARGE_IMAGE_DOWNLOAD_PATH
		end
	end
	
	def target_path(process)
		if process == 'small'
		  NIELSEN_SMALL_IMAGE_ORGANIZED_PATH
		elsif process == 'medium'
		  NIELSEN_MEDIUM_IMAGE_ORGANIZED_PATH
		else
		  NIELSEN_LARGE_IMAGE_ORGANIZED_PATH
		end
	end

  def update_product_table(isbn13)	      
    db_connection = Mysql.new("localhost", "#{DATABASE_CONFIG['username']}", "#{DATABASE_CONFIG['password']}", "#{DATABASE_CONFIG['database']}")
    puts update_sql = "UPDATE products SET imagflag = 'Y' WHERE isbn13 = '#{isbn13}' LIMIT 1"
    writelog "Updating Image availability in products table for the product #{isbn13} - #{update_sql}"     
    db_connection.query(update_sql) 		 
  end
	
	def writelog(message)
		puts "- #{Time.current} - #{message}"
	end
end
