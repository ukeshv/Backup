#NOTE: do not place '/' at end of path declared in this file

# errors
PATH_ERROR = 'path error'
OPTION_ERROR = 'option error'


# success
SUCCESS = 'success'


#nielsen csv processing
NIELSEN_CSV_DOWNLOAD_PATH = "#{RAILS_ROOT}/db/ftp_csv_downloads"


#nielsen image processing
NIELSEN_IMAGE_DOWNLOAD_PATH = "#{RAILS_ROOT}/db/ftp_image_downloads"
NIELSEN_LARGE_IMAGE_DOWNLOAD_PATH = "#{RAILS_ROOT}/db/ftp_image_downloads/LargeImages"
NIELSEN_MEDIUM_IMAGE_DOWNLOAD_PATH = "#{RAILS_ROOT}/db/ftp_image_downloads/MediumImages"
NIELSEN_SMALL_IMAGE_DOWNLOAD_PATH = "#{RAILS_ROOT}/db/ftp_image_downloads/SmallImages"


#nielsen images saved in directory structure at:
NIELSEN_LARGE_IMAGE_ORGANIZED_PATH = "#{RAILS_ROOT}/../../shared/Large_Nielsen_Images"
NIELSEN_MEDIUM_IMAGE_ORGANIZED_PATH = "#{RAILS_ROOT}/../../shared/Medium_Nielsen_Images"
NIELSEN_SMALL_IMAGE_ORGANIZED_PATH = "#{RAILS_ROOT}/../../shared/Small_Nielsen_Images"

#Auto back-up file path
AUTO_BACKUP_FILE_PATH = "#{RAILS_ROOT}/../../berkelouw_production_MyISAM_before_cron.tar.gz"

# Log file path
CSV_LOG_PATH = "#{RAILS_ROOT}/../../csv_process.log"
IMAGE_LOG_PATH = "#{RAILS_ROOT}/../../image_process.log"