

require 'rubygems'
require 'net/ftp'
require 'fileutils'

URL = 'ftp.recordsupply.nielsenbookdata.com'
username = 'BerkelouwRSS01'
passwd = "ld223hm469"
directory = '/images/'
root_path = '/home/vadivelan/Projects/berkelouw_books'
local_filename = "#{root_path}/images"
large_image_directory = "#{root_path}/Large_Nielsen_Images/"
medium_image_directory = "#{root_path}/Medium_Nielsen_Images/"
small_image_directory = "#{root_path}/Small_Nielsen_Images/"

FileUtils.mkdir(local_filename) unless File.directory?(local_filename) 			

ftp=Net::FTP.new(URL)
#~ ftp.connect(URL)
ftp.login(username,passwd)
puts "logged in"
ftp.chdir(directory)
puts "dir changed"
file_list = ftp.nlst
puts file_list.inspect  
  file_list[0..0].each do |filename|
    puts "downloading.....  #{local_filename}/#{filename}"
    current_file_name = "#{local_filename}/#{filename}"
    unless File.exists?(current_file_name)
      ftp.getbinaryfile(filename, current_file_name)
      # download completed..
      
      # file extraction starts here....
      if File.exists?(current_file_name)
        destination_path = large_image_directory if filename[0..4] == "11730"
        destination_path = medium_image_directory if filename[0..4] == "13270"
        destination_path = small_image_directory if filename[0..4] == "11980"
        
        directory_path_upto_filename = "#{destination_path}#{filename.gsub(".zip", "")}"
        FileUtils.mkdir(directory_path_upto_filename) unless File.directory?(directory_path_upto_filename) 		
        
        system("unzip #{current_file_name} -d #{directory_path_upto_filename}")
      end      
    end
  puts "#{filename} downloaded"
  end
ftp.close 


#~ 11730 => large
#~ 13270 => medium
#~ 11980 => small
