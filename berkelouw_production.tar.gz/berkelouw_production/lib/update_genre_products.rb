require 'rubygems'
require 'mysql'   
db_connection = Mysql.new('localhost', 'app_stag', 'tvdJdP2S7', 'berkelouw_staging')   
#db_connection = Mysql.new('192.168.1.71', 'root', 'root', 'berkelouw_development')   
#db_connection = Mysql.new('localhost', 'app_user', 'U1T4Tn8v', 'berkelouw_staging')   

# rs with products
product_result_set = db_connection.query('SELECT id, product_category_id, bic2sc1, bic2sc2, bic2sc3, bic2sc4, bic2sc5, bic2st1, product_category_id FROM products WHERE id > 0 ORDER BY id ASC')   

product_result_set.each_hash  { |product|     
    product['bic2st1'] = product['bic2st1'].gsub(/['"\\\x0]/,'\\\\\0')
    genre_sql = "SELECT id FROM genres WHERE (product_category_id = '#{product['product_category_id']}')  AND (code = '#{product['bic2sc1']}' OR code = '#{product['bic2sc2']}' OR code = '#{product['bic2sc3']}' OR code = '#{product['bic2sc4']}' OR code = '#{product['bic2sc5']}' OR '#{product['bic2st1']}' REGEXP name)" 	 
    genre_result_set = db_connection.query(genre_sql)    
    #collected genres with 
    db_connection.query("DELETE FROM genre_products WHERE product_id = #{product['id']}")  
    genre_result_set.each_hash  { |genre| 	   	   	 
      db_connection.query("INSERT INTO genre_products(product_id, genre_id) VALUES (#{product['id']}, #{genre['id']})")  
    }
    puts "PID: #{product['id']} - #{Time.now} updated"
 }  
db_connection.close  
