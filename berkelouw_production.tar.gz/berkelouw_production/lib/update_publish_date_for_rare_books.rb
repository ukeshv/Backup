require 'rubygems'
require 'mysql'   
#db_connection = Mysql.new('localhost', 'app_stag', 'tvdJdP2S7', 'berkelouw_staging')   
db_connection = Mysql.new('192.168.1.71', 'root', 'root', 'berkelouw_development')   
#db_connection = Mysql.new('localhost', 'app_user', 'U1T4Tn8v', 'berkelouw_staging')   

# rs with products 
product_result_set = db_connection.query('SELECT id, pubpd, rare_pubpd FROM products WHERE product_category_id = 2')   # ORDER BY id ASC

product_result_set.each_hash  { |product|               
    puts new_pubpd = product['rare_pubpd'].scan(/\d+/)[0]
    new_pubpd = "#{new_pubpd}-01-01"
    puts update_sql = "UPDATE products set pubpd = '#{new_pubpd}' WHERE id = #{product['id']}" 
    db_connection.query(update_sql)       
    puts "PID: #{product['id']} - #{Time.now} updated"
 }  
db_connection.close  
