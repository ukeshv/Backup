require 'rubygems'
ENV['RAILS_ENV'] = ARGV[0] || 'development'
require File.dirname(__FILE__) + '/../config/boot'
require RAILS_ROOT + '/config/environment' 

#then I'll proceed with data job now, and will get you a app running on these new data, which u can test and let me know tomorrow morning

def writelog(message)
puts "#{Time.current} - #{message}"
end 

def process_sql(sql, update=true)
writelog " - SQL - #{sql}"
if update	
ActiveRecord::Base.connection.update_sql(sql).to_i
else
ActiveRecord::Base.connection.execute(sql)
end	
end


table_name = "products"
path = ENV['RAILS_ENV'] == 'development' ? "#{RAILS_ROOT}/db/ftp_extracts/add" : '/var/www/apps/berkelouw_live/shared/NielsenBookData/CSVs'

process_sql("select id into @default_product_category_id from product_categories where name='books' limit 1")
process_sql("select id into @default_product_content_type_id from product_content_types where name='Undefined' limit 1") 
process_sql("select id into @default_publishing_status_id from publishing_statuses where name='Unspecified' limit 1") 
process_sql("set @default_availability_status_id = 0") 
process_sql("set @default_csv_supplier_id = NULL") 

csv_files = Dir.glob("#{path}/*.add").sort
csv_files.each do |csv|
	puts "updating data of CSV - #{csv}"
	csv_name = csv.split('/').last

	process_sql("UPDATE #{table_name} join product_content_types on #{table_name}.pfc = product_content_types.code set #{table_name}.product_content_type_id = product_content_types.id where #{table_name}.pfc is not null and (#{table_name}.product_content_type_id = @default_product_content_type_id or #{table_name}.product_content_type_id = 0) and csv_file_source = '#{csv_name}'")
	process_sql("UPDATE #{table_name} join product_content_types on #{table_name}.pfct = product_content_types.name set #{table_name}.product_content_type_id = product_content_types.id where #{table_name}.pfct is not null and (#{table_name}.product_content_type_id = @default_product_content_type_id or #{table_name}.product_content_type_id = 0) and csv_file_source = '#{csv_name}'")
	
	process_sql("UPDATE #{table_name} join availability_statuses on #{table_name}.ausnbdpac = availability_statuses.code set #{table_name}.availability_status_id = availability_statuses.id where #{table_name}.ausnbdpac is not null and (#{table_name}.availability_status_id = @default_availability_status_id or #{table_name}.availability_status_id = 0) and csv_file_source = '#{csv_name}'")
	process_sql("UPDATE #{table_name} join availability_statuses on #{table_name}.ausnbdpat = availability_statuses.name set #{table_name}.availability_status_id = availability_statuses.id where #{table_name}.ausnbdpat is not null and (#{table_name}.availability_status_id = @default_availability_status_id or #{table_name}.availability_status_id = 0) and csv_file_source = '#{csv_name}'")

	process_sql("UPDATE #{table_name} join publishing_statuses on #{table_name}.pubsc = publishing_statuses.code set #{table_name}.publishing_status_id = publishing_statuses.id where #{table_name}.pubsc is not null and (#{table_name}.publishing_status_id = @default_publishing_status_id or #{table_name}.publishing_status_id = 0) and csv_file_source = '#{csv_name}'")
	process_sql("UPDATE #{table_name} join publishing_statuses on #{table_name}.pubst = publishing_statuses.name set #{table_name}.publishing_status_id = publishing_statuses.id where #{table_name}.pubst is not null and (#{table_name}.publishing_status_id = @default_publishing_status_id or #{table_name}.publishing_status_id = 0) and csv_file_source = '#{csv_name}'")

	process_sql("UPDATE #{table_name} join suppliers on #{table_name}.ausadi1 = suppliers.nbd_org_id set #{table_name}.csv_supplier_id = suppliers.id where #{table_name}.ausadi1 is not null and (#{table_name}.csv_supplier_id is null or #{table_name}.csv_supplier_id = 0) and csv_file_source = '#{csv_name}'")
	process_sql("UPDATE #{table_name} join suppliers on #{table_name}.ausadn1 = suppliers.nbd_org_name set #{table_name}.csv_supplier_id = suppliers.id where #{table_name}.ausadn1 is not null and (#{table_name}.csv_supplier_id is null or #{table_name}.csv_supplier_id = 0) and csv_file_source = '#{csv_name}'")
	process_sql("UPDATE #{table_name} join suppliers on #{table_name}.ausadi2 = suppliers.nbd_org_id set #{table_name}.csv_supplier_id = suppliers.id where #{table_name}.ausadi2 is not null and (#{table_name}.csv_supplier_id is null or #{table_name}.csv_supplier_id = 0) and csv_file_source = '#{csv_name}'")
	process_sql("UPDATE #{table_name} join suppliers on #{table_name}.ausadn2 = suppliers.nbd_org_name set #{table_name}.csv_supplier_id = suppliers.id where #{table_name}.ausadn2 is not null and (#{table_name}.csv_supplier_id is null or #{table_name}.csv_supplier_id = 0) and csv_file_source = '#{csv_name}'")


  system("mv #{csv} #{csv}.finished")
end	

products_suppliers_table_name = "tmp_p_s_#{Date.current.strftime('%Y_%m_%d')}"
process_sql("DROP TABLE IF EXISTS #{products_suppliers_table_name}")
process_sql("CREATE TABLE #{products_suppliers_table_name} LIKE products_suppliers")
process_sql("INSERT INTO #{products_suppliers_table_name} (product_id, supplier_id, created_at, updated_at) select id,csv_supplier_id,NOW(),NOW() from #{table_name} where csv_supplier_id is not null and csv_supplier_id > 0")
