var _genreEdit = {};


function loadRareSubGenres(genreId)	{
	jQuery.ajax({data:'genre_id=' + _genreEdit.currentGenreId, dataType:'script', type:'post', url:'/hq/genres/load_sub_genres'});
}

function addSelectedGenreAsSubGenre()	{
	toggleElement('spinner');
	var subGenreId = $('#genre_sub_genre').find('option:selected').val();
	jQuery.ajax({data:'sub_genre_id=' + subGenreId + '&genre_id=' + _genreEdit.currentGenreId, dataType:'script', type:'post', url:'/hq/genres/add_sub_genre'});
}
