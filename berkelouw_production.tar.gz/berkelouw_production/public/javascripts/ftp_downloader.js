var _ftp = {};
_ftp.monitorProgress = true;
_ftp.currentDownloadFilename = 'started';
_ftp.currentDownloadRecordId = 'started';
_ftp.currentProcessRecordId = 0;
_ftp.timeOutLimit = 15;
_ftp.emptyRequestSubmission = 0;

function postRequestToFetchDatas()	{
	$.ajax({
		type: "POST",
		url: "/hq/ftps/fetch_datas",
		// data: "name=John&location=Boston",
		//success: function(msg){
			//alert( "Data Saved: " + msg );
		//}
	});
	enableMonitorProgress();
	_ftp.timeOut = setTimeout("postRequestToUpdateProgressStatus()", 500);
}

function initiateProgressUpdater()	{
	_ftp.timeOut = setTimeout("postRequestToUpdateProgressStatus()", 500);
}

function postRequestToUpdateProgressStatus()	{
	if(_ftp.monitorProgress)
	{
		$.ajax({
			type: "POST",
			url: "/hq/ftps/update_download_status",
			data: "filename=" + _ftp.currentDownloadFilename + "&id=" + _ftp.currentDownloadRecordId + "&job_id=" + _ftp.currentProcessRecordId			
		});
		_ftp.timeOut = setTimeout("postRequestToUpdateProgressStatus()", 2000);
	}
	else
	{
		// clears time out value
		_ftp.timeOut = 0;
	}	
}

function initializeProgressBar(completedValue)	{	
	$("#progressbar").progressbar({ value: completedValue });
}

function updatePercentage(percentage)	{
	if(percentage == 100)	{
		resetFilename();
	}
	$('#downloadStatusIndicator').html(percentage + "%");
}

function checkDownloadPercentage(percentage)	{
	if(percentage == 100)
	{
		disableMonitorProgress();
	}
}

function disableMonitorProgress()	{
	_ftp.monitorProgress = false;	
}

function enableMonitorProgress()	{
	_ftp.monitorProgress = true;
}

function assignCurrentDownload(filename, id, job_id)	{
	_ftp.currentDownloadFilename = filename;
	_ftp.currentDownloadRecordId = id;
	_ftp.currentProcessRecordId = job_id;
}

function resetFilename()	{
	_ftp.currentDownloadFilename = '';
}

function updateStatusMessage(content)	{
	$('#downloadStatusMessage').html(content);
}

function timeOutMethod()	{
	_ftp.emptyRequestSubmission += 1;
	if(_ftp.emptyRequestSubmission > _ftp.timeOutLimit)
	{
		_ftp.currentDownloadFilename = 'time_out';
		_ftp.currentDownloadRecordId = 'time_out';
	}
}

function assignCurrentJobId(job_id)	{
	_ftp.currentProcessRecordId = job_id;
}

