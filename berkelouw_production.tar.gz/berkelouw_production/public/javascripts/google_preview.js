(function () {
    var GBS_HOST = "http://books.google.com/";
    var GBS_LANG = "en";
    var h = true,
        j = null,
        k = false,
        l, m = this,
        r = function (a, b, c) {
            a = a.split(".");
            c = c || m;
            !(a[0] in c) && c.execScript && c.execScript("var " + a[0]);
            for (var d; a.length && (d = a.shift());) if (!a.length && b !== undefined) c[d] = b;
            else c = c[d] ? c[d] : (c[d] = {})
        },
        s = function () {},
        aa = function (a) {
            var b = typeof a;
            if (b == "object") if (a) {
                if (a instanceof Array || !(a instanceof Object) && Object.prototype.toString.call(a) == "[object Array]" || typeof a.length == "number" && typeof a.splice != "undefined" && typeof a.propertyIsEnumerable != "undefined" && !a.propertyIsEnumerable("splice")) return "array";
                if (!(a instanceof Object) && (Object.prototype.toString.call(a) == "[object Function]" || typeof a.call != "undefined" && typeof a.propertyIsEnumerable != "undefined" && !a.propertyIsEnumerable("call"))) return "function"
            } else return "null";
            else if (b == "function" && typeof a.call == "undefined") return "object";
            return b
        },
        t = function (a) {
            return aa(a) == "array"
        },
        u = function (a) {
            var b = aa(a);
            return b == "array" || b == "object" && typeof a.length == "number"
        },
        v = function (a) {
            return typeof a == "string"
        },
        ba = function (a) {
            return aa(a) == "function"
        },
        ca = function (a) {
            a = aa(a);
            return a == "object" || a == "array" || a == "function"
        },
        z = function (a) {
            if (a.hasOwnProperty && a.hasOwnProperty(y)) return a[y];
            a[y] || (a[y] = ++da);
            return a[y]
        },
        y = "closure_uid_" + Math.floor(Math.random() * 2147483648).toString(36),
        da = 0,
        ea = function (a, b) {
            var c = b || m;
            if (arguments.length > 2) {
                var d = Array.prototype.slice.call(arguments, 2);
                return function () {
                    var e = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(e, d);
                    return a.apply(c, e)
                }
            } else return function () {
                return a.apply(c, arguments)
            }
        },
        A = function (a) {
            var b = Array.prototype.slice.call(arguments, 1);
            return function () {
                var c = Array.prototype.slice.call(arguments);
                c.unshift.apply(c, b);
                return a.apply(this, c)
            }
        },
        fa = Date.now ||
        function () {
            return +new Date
        },
        B = function (a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.P = b.prototype;
            a.prototype = new c
        };
    var ga = function (a) {
        for (var b = 1; b < arguments.length; b++) {
            var c = String(arguments[b]).replace(/\$/g, "$$$$");
            a = a.replace(/\%s/, c)
        }
        return a
    },
        ha = /^[a-zA-Z0-9\-_.!~*'()]*$/,
        ia = function (a) {
            a = String(a);
            if (!ha.test(a)) return encodeURIComponent(a);
            return a
        },
        oa = function (a, b) {
            if (b) return a.replace(ja, "&amp;").replace(ka, "&lt;").replace(la, "&gt;").replace(ma, "&quot;");
            else {
                if (!na.test(a)) return a;
                if (a.indexOf("&") != -1) a = a.replace(ja, "&amp;");
                if (a.indexOf("<") != -1) a = a.replace(ka, "&lt;");
                if (a.indexOf(">") != -1) a = a.replace(la, "&gt;");
                if (a.indexOf('"') != -1) a = a.replace(ma, "&quot;");
                return a
            }
        },
        ja = /&/g,
        ka = /</g,
        la = />/g,
        ma = /\"/g,
        na = /[&<>\"]/,
        qa = function (a, b) {
            for (var c = 0, d = String(a).replace(/^[\s\xa0]+|[\s\xa0]+$/g, "").split("."), e = String(b).replace(/^[\s\xa0]+|[\s\xa0]+$/g, "").split("."), f = Math.max(d.length, e.length), g = 0; c == 0 && g < f; g++) {
                var i = d[g] || "",
                    n = e[g] || "",
                    o = RegExp("(\\d*)(\\D*)", "g"),
                    x = RegExp("(\\d*)(\\D*)", "g");
                do {
                    var q = o.exec(i) || ["", "", ""],
                        p = x.exec(n) || ["", "", ""];
                    if (q[0].length == 0 && p[0].length == 0) break;
                    c = pa(q[1].length == 0 ? 0 : parseInt(q[1], 10), p[1].length == 0 ? 0 : parseInt(p[1], 10)) || pa(q[2].length == 0, p[2].length == 0) || pa(q[2], p[2])
                } while (c == 0)
            }
            return c
        },
        pa = function (a, b) {
            if (a < b) return -1;
            else if (a > b) return 1;
            return 0
        };
    var C = Array.prototype,
        ra = C.indexOf ?
        function (a, b, c) {
            return C.indexOf.call(a, b, c)
        } : function (a, b, c) {
            c = c == j ? 0 : c < 0 ? Math.max(0, a.length + c) : c;
            if (v(a)) {
                if (!v(b) || b.length != 1) return -1;
                return a.indexOf(b, c)
            }
            for (c = c; c < a.length; c++) if (c in a && a[c] === b) return c;
            return -1
        },
        sa = C.forEach ?
        function (a, b, c) {
            C.forEach.call(a, b, c)
        } : function (a, b, c) {
            for (var d = a.length, e = v(a) ? a.split("") : a, f = 0; f < d; f++) f in e && b.call(c, e[f], f, a)
        },
        ta = function () {
            return C.concat.apply(C, arguments)
        },
        ua = function (a) {
            if (t(a)) return ta(a);
            else {
                for (var b = [], c = 0, d = a.length; c < d; c++) b[c] = a[c];
                return b
            }
        },
        va = function (a) {
            for (var b = 1; b < arguments.length; b++) {
                var c = arguments[b],
                    d;
                if (t(c) || (d = u(c)) && c.hasOwnProperty("callee")) a.push.apply(a, c);
                else if (d) for (var e = a.length, f = c.length, g = 0; g < f; g++) a[e + g] = c[g];
                else a.push(c)
            }
        };
    var wa = function (a, b) {
        this.x = a !== undefined ? a : 0;
        this.y = b !== undefined ? b : 0
    };
    wa.prototype.l = function () {
        return new wa(this.x, this.y)
    };
    var D = function (a, b) {
        this.width = a;
        this.height = b
    };
    D.prototype.l = function () {
        return new D(this.width, this.height)
    };
    D.prototype.floor = function () {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        alert(this.height)
        return this
    };
    D.prototype.round = function () {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var xa = function (a, b, c) {
        for (var d in a) b.call(c, a[d], d, a)
    },
        ya = function (a) {
            var b = [],
                c = 0;
            for (var d in a) b[c++] = a[d];
            return b
        },
        za = function (a) {
            var b = [],
                c = 0;
            for (var d in a) b[c++] = d;
            return b
        },
        Aa = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"],
        Ba = function (a) {
            for (var b, c, d = 1; d < arguments.length; d++) {
                c = arguments[d];
                for (b in c) a[b] = c[b];
                for (var e = 0; e < Aa.length; e++) {
                    b = Aa[e];
                    if (Object.prototype.hasOwnProperty.call(c, b)) a[b] = c[b]
                }
            }
        };
    var E, Ca, Da, Ea, Fa, Ga, Ha = function () {
        return m.navigator ? m.navigator.userAgent : j
    },
        Ia = function () {
            return m.navigator
        };
    Fa = Ea = Da = Ca = E = k;
    var F;
    if (F = Ha()) {
        var Ja = Ia();
        E = F.indexOf("Opera") == 0;
        Ca = !E && F.indexOf("MSIE") != -1;
        Ea = (Da = !E && F.indexOf("WebKit") != -1) && F.indexOf("Mobile") != -1;
        Fa = !E && !Da && Ja.product == "Gecko"
    }
    var Ka = E,
        La = Ca,
        Ma = Fa,
        Na = Da,
        Oa = Ea,
        Pa = Ia();
    Ga = (Pa && Pa.platform || "").indexOf("Mac") != -1;
    var Qa = !! Ia() && (Ia().appVersion || "").indexOf("X11") != -1,
        Ra = "",
        G;
    if (Ka && m.opera) {
        var Sa = m.opera.version;
        Ra = typeof Sa == "function" ? Sa() : Sa
    } else {
        if (Ma) G = /rv\:([^\);]+)(\)|;)/;
        else if (La) G = /MSIE\s+([^\);]+)(\)|;)/;
        else if (Na) G = /WebKit\/(\S+)/;
        if (G) {
            var Ta = G.exec(Ha());
            Ra = Ta ? Ta[1] : ""
        }
    }
    var Ua = Ra,
        Va = {},
        Wa = function (a) {
            return Va[a] || (Va[a] = qa(Ua, a) >= 0)
        };
    var Ya = function (a, b) {
        xa(b, function (c, d) {
            if (d == "style") a.style.cssText = c;
            else if (d == "class") a.className = c;
            else if (d == "for") a.htmlFor = c;
            else if (d in Xa) a.setAttribute(Xa[d], c);
            else a[d] = c
        })
    },
        Xa = {
            cellpadding: "cellPadding",
            cellspacing: "cellSpacing",
            colspan: "colSpan",
            rowspan: "rowSpan",
            valign: "vAlign",
            height: "height",
            width: "width",
            usemap: "useMap",
            frameborder: "frameBorder",
            type: "type"
        },
        Za = function (a) {
            var b = a.document;
            if (Na && !Wa("500") && !Oa) {
                if (typeof a.innerHeight == "undefined") a = window;
                b = a.innerHeight;
                var c =
                a.document.documentElement.scrollHeight;
                if (a == a.top) if (c < b) b -= 15;
                return new D(a.innerWidth, b)
            }
            a = b.compatMode == "CSS1Compat";
            if (Ka && !Wa("9.50")) a = k;
            a = a ? b.documentElement : b.body;
            return new D(a.clientWidth, a.clientHeight)
        },
        ab = function () {
            return $a(document, arguments)
        },
        $a = function (a, b) {
            var c = b[0],
                d = b[1];
            if (La && d && (d.name || d.type)) {
                c = ["<", c];
                d.name && c.push(' name="', oa(d.name), '"');
                if (d.type) {
                    c.push(' type="', oa(d.type), '"');
                    var e = {};
                    Ba(e, d);
                    d = e;
                    delete d.type
                }
                c.push(">");
                c = c.join("")
            }
            var f = a.createElement(c);
            if (d) if (v(d)) f.className = d;
            else Ya(f, d);
            if (b.length > 2) {
                d = function (g) {
                    if (g) f.appendChild(v(g) ? a.createTextNode(g) : g)
                };
                for (c = 2; c < b.length; c++) {
                    e = b[c];
                    u(e) && !(ca(e) && e.nodeType > 0) ? sa(bb(e) ? ua(e) : e, d) : d(e)
                }
            }
            return f
        },
        H = function (a) {
            return document.createElement(a)
        },
        cb = function (a) {
            return a && a.parentNode ? a.parentNode.removeChild(a) : j
        },
        bb = function (a) {
            if (a && typeof a.length == "number") if (ca(a)) return typeof a.item == "function" || typeof a.item == "string";
            else if (ba(a)) return typeof a.item == "function";
            return k
        };
    var db = function () {},
        fb = function (a, b, c) {
            switch (typeof b) {
            case "string":
                eb(a, b, c);
                break;
            case "number":
                c.push(isFinite(b) && !isNaN(b) ? b : "null");
                break;
            case "boolean":
                c.push(b);
                break;
            case "undefined":
                c.push("null");
                break;
            case "object":
                if (b == j) {
                    c.push("null");
                    break
                }
                if (t(b)) {
                    var d = b.length;
                    c.push("[");
                    for (var e = "", f = 0; f < d; f++) {
                        c.push(e);
                        fb(a, b[f], c);
                        e = ","
                    }
                    c.push("]");
                    break
                }
                c.push("{");
                d = "";
                for (e in b) if (b.hasOwnProperty(e)) {
                    f = b[e];
                    if (typeof f != "function") {
                        c.push(d);
                        eb(a, e, c);
                        c.push(":");
                        fb(a, f, c);
                        d = ","
                    }
                }
                c.push("}");
                break;
            case "function":
                break;
            default:
                throw Error("Unknown type: " + typeof b);
            }
        },
        gb = {
            '"': '\\"',
            "\\": "\\\\",
            "/": "\\/",
            "\u0008": "\\b",
            "\u000c": "\\f",
            "\n": "\\n",
            "\r": "\\r",
            "\t": "\\t",
            "\u000b": "\\u000b"
        },
        hb = /\uffff/.test("\uffff") ? /[\\\"\x00-\x1f\x7f-\uffff]/g : /[\\\"\x00-\x1f\x7f-\xff]/g,
        eb = function (a, b, c) {
            c.push('"', b.replace(hb, function (d) {
                if (d in gb) return gb[d];
                var e = d.charCodeAt(0),
                    f = "\\u";
                if (e < 16) f += "000";
                else if (e < 256) f += "00";
                else if (e < 4096) f += "0";
                return gb[d] = f + e.toString(16)
            }), '"')
        };
    var I = function (a, b, c) {
        v(b) ? ib(a, c, b) : xa(b, A(ib, a))
    },
        ib = function (a, b, c) {
            a.style[jb(c)] = b
        },
        lb = function (a, b, c) {
            var d, e = Ma && (Ga || Qa) && Wa("1.9");
            if (b instanceof wa) {
                d = b.x;
                b = b.y
            } else {
                d = b;
                b = c
            }
            kb("left", e, a, d);
            kb("top", e, a, b)
        },
        ob = function (a, b, c) {
            if (b instanceof D) {
                c = b.height;
                b = b.width
            } else {
                if (c == undefined) throw Error("missing height argument");
                c = c
            }
            mb(a, b);
            nb(a, c)
        },
        kb = function (a, b, c, d) {
            if (typeof d == "number") d = (b ? Math.round(d) : d) + "px";
            c.style[a] = d
        },
        nb = A(kb, "height", h),
        mb = A(kb, "width", h),
        pb = {},
        jb = function (a) {
            return pb[a] || (pb[a] = String(a).replace(/\-([a-z])/g, function (b, c) {
                return c.toUpperCase()
            }))
        },
        qb = function (a, b) {
            var c = a.style;
            if ("opacity" in c) c.opacity = b;
            else if ("MozOpacity" in c) c.MozOpacity = b;
            else if ("filter" in c) c.filter = b === "" ? "" : "alpha(opacity=" + b * 100 + ")"
        };
    var rb = "StopIteration" in m ? m.StopIteration : Error("StopIteration"),
        sb = function () {};
    sb.prototype.next = function () {
        throw rb;
    };
    sb.prototype.la = function () {
        return this
    };
    var tb = function (a) {
        if (typeof a.s == "function") return a.s();
        if (v(a)) return a.split("");
        if (u(a)) {
            for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
            return b
        }
        return ya(a)
    },
        ub = function (a, b, c) {
            if (typeof a.forEach == "function") a.forEach(b, c);
            else if (u(a) || v(a)) sa(a, b, c);
            else {
                var d;
                if (typeof a.v == "function") d = a.v();
                else if (typeof a.s != "function") if (u(a) || v(a)) {
                    d = [];
                    for (var e = a.length, f = 0; f < e; f++) d.push(f);
                    d = d
                } else d = za(a);
                else d = void 0;
                e = tb(a);
                f = e.length;
                for (var g = 0; g < f; g++) b.call(c, e[g], d && d[g], a)
            }
        };
    var J = function (a) {
        this.h = {};
        this.c = [];
        var b = arguments.length;
        if (b > 1) {
            if (b % 2) throw Error("Uneven number of arguments");
            for (var c = 0; c < b; c += 2) this.p(arguments[c], arguments[c + 1])
        } else if (a) {
            if (a instanceof J) {
                b = a.v();
                c = a.s()
            } else {
                b = za(a);
                c = ya(a)
            }
            for (var d = 0; d < b.length; d++) this.p(b[d], c[d])
        }
    };
    l = J.prototype;
    l.a = 0;
    l.Q = 0;
    l.s = function () {
        vb(this);
        for (var a = [], b = 0; b < this.c.length; b++) a.push(this.h[this.c[b]]);
        return a
    };
    l.v = function () {
        vb(this);
        return this.c.concat()
    };
    l.m = function (a) {
        return K(this.h, a)
    };
    l.remove = function (a) {
        if (K(this.h, a)) {
            delete this.h[a];
            this.a--;
            this.Q++;
            this.c.length > 2 * this.a && vb(this);
            return h
        }
        return k
    };
    var vb = function (a) {
        if (a.a != a.c.length) {
            for (var b = 0, c = 0; b < a.c.length;) {
                var d = a.c[b];
                if (K(a.h, d)) a.c[c++] = d;
                b++
            }
            a.c.length = c
        }
        if (a.a != a.c.length) {
            var e = {};
            for (c = b = 0; b < a.c.length;) {
                d = a.c[b];
                if (!K(e, d)) {
                    a.c[c++] = d;
                    e[d] = 1
                }
                b++
            }
            a.c.length = c
        }
    };
    J.prototype.o = function (a, b) {
        if (K(this.h, a)) return this.h[a];
        return b
    };
    J.prototype.p = function (a, b) {
        if (!K(this.h, a)) {
            this.a++;
            this.c.push(a);
            this.Q++
        }
        this.h[a] = b
    };
    J.prototype.l = function () {
        return new J(this)
    };
    J.prototype.la = function (a) {
        vb(this);
        var b = 0,
            c = this.c,
            d = this.h,
            e = this.Q,
            f = this,
            g = new sb;
        g.next = function () {
            for (;;) {
                if (e != f.Q) throw Error("The map has changed since the iterator was created");
                if (b >= c.length) throw rb;
                var i = c[b++];
                return a ? i : d[i]
            }
        };
        return g
    };
    var K = function (a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    var wb = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^/?#]*)@)?([\\w\\d\\-\\u0100-\\uffff.%]*)(?::([0-9]+))?)?([^?#]+)?(?:\\?([^#]*))?(?:#(.*))?$");
    var L = function (a, b) {
        var c;
        if (a instanceof L) {
            this.B(b == j ? a.g : b);
            xb(this, a.k);
            yb(this, a.K);
            zb(this, a.u);
            Ab(this, a.t);
            Bb(this, a.H);
            Cb(this, a.e.l());
            Db(this, a.D)
        } else if (a && (c = String(a).match(wb))) {
            this.B( !! b);
            xb(this, c[1] || "", h);
            yb(this, c[2] || "", h);
            zb(this, c[3] || "", h);
            Ab(this, c[4]);
            Bb(this, c[5] || "", h);
            Cb(this, c[6] || "", h);
            Db(this, c[7] || "", h)
        } else {
            this.B( !! b);
            this.e = new M(j, this, this.g)
        }
    };
    l = L.prototype;
    l.k = "";
    l.K = "";
    l.u = "";
    l.t = j;
    l.H = "";
    l.D = "";
    l.ra = k;
    l.g = k;
    l.toString = function () {
        if (this.d) return this.d;
        var a = [];
        this.k && a.push(N(this.k, Eb), ":");
        if (this.u) {
            a.push("//");
            this.K && a.push(N(this.K, Eb), "@");
            var b;
            b = this.u;
            b = v(b) ? encodeURIComponent(b) : j;
            a.push(b);
            this.t != j && a.push(":", String(this.t))
        }
        this.H && a.push(N(this.H, Fb));
        (b = String(this.e)) && a.push("?", b);
        this.D && a.push("#", N(this.D, Gb));
        return this.d = a.join("")
    };
    l.l = function () {
        var a = this.k,
            b = this.K,
            c = this.u,
            d = this.t,
            e = this.H,
            f = this.e.l(),
            g = this.D,
            i = new L(j, this.g);
        a && xb(i, a);
        b && yb(i, b);
        c && zb(i, c);
        d && Ab(i, d);
        e && Bb(i, e);
        f && Cb(i, f);
        g && Db(i, g);
        return i
    };
    var xb = function (a, b, c) {
        O(a);
        delete a.d;
        a.k = c ? b ? decodeURIComponent(b) : "" : b;
        if (a.k) a.k = a.k.replace(/:$/, "");
        return a
    },
        yb = function (a, b, c) {
            O(a);
            delete a.d;
            a.K = c ? b ? decodeURIComponent(b) : "" : b;
            return a
        },
        zb = function (a, b, c) {
            O(a);
            delete a.d;
            a.u = c ? b ? decodeURIComponent(b) : "" : b;
            return a
        },
        Ab = function (a, b) {
            O(a);
            delete a.d;
            if (b) {
                b = Number(b);
                if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
                a.t = b
            } else a.t = j;
            return a
        },
        Bb = function (a, b, c) {
            O(a);
            delete a.d;
            a.H = c ? b ? decodeURIComponent(b) : "" : b;
            return a
        },
        Cb = function (a, b, c) {
            O(a);
            delete a.d;
            if (b instanceof M) {
                a.e = b;
                a.e.J = a;
                a.e.B(a.g)
            } else {
                c || (b = N(b, Hb));
                a.e = new M(b, a, a.g)
            }
            return a
        },
        P = function (a, b, c) {
            O(a);
            delete a.d;
            a.e.p(b, c);
            return a
        },
        Ib = function (a, b, c) {
            O(a);
            delete a.d;
            t(c) || (c = [String(c)]);
            var d = a.e;
            b = b;
            c = c;
            Q(d);
            R(d);
            b = S(d, b);
            if (d.m(b)) {
                var e = d.b.o(b);
                if (t(e)) d.a -= e.length;
                else d.a--
            }
            if (c.length > 0) {
                d.b.p(b, c);
                d.a += c.length
            }
            return a
        },
        Db = function (a, b, c) {
            O(a);
            delete a.d;
            a.D = c ? b ? decodeURIComponent(b) : "" : b;
            return a
        },
        O = function (a) {
            if (a.ra) throw Error("Tried to modify a read-only Uri");
        };
    L.prototype.B = function (a) {
        this.g = a;
        this.e && this.e.B(a)
    };
    var Jb = /^[a-zA-Z0-9\-_.!~*'():\/;?]*$/,
        N = function (a, b) {
            var c = j;
            if (v(a)) {
                c = a;
                Jb.test(c) || (c = encodeURI(a));
                if (c.search(b) >= 0) c = c.replace(b, Kb)
            }
            return c
        },
        Kb = function (a) {
            a = a.charCodeAt(0);
            return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
        },
        Eb = /[#\/\?@]/g,
        Fb = /[\#\?]/g,
        Hb = /[\#\?@]/g,
        Gb = /#/g,
        M = function (a, b, c) {
            this.j = a || j;
            this.J = b || j;
            this.g = !! c
        },
        Q = function (a) {
            if (!a.b) {
                a.b = new J;
                if (a.j) for (var b = a.j.split("&"), c = 0; c < b.length; c++) {
                    var d = b[c].indexOf("="),
                        e = j,
                        f = j;
                    if (d >= 0) {
                        e = b[c].substring(0, d);
                        f = b[c].substring(d + 1)
                    } else e = b[c];
                    e = decodeURIComponent(e.replace(/\+/g, " "));
                    e = S(a, e);
                    a.add(e, f ? decodeURIComponent(f.replace(/\+/g, " ")) : "")
                }
            }
        };
    l = M.prototype;
    l.b = j;
    l.a = j;
    l.add = function (a, b) {
        Q(this);
        R(this);
        a = S(this, a);
        if (this.m(a)) {
            var c = this.b.o(a);
            t(c) ? c.push(b) : this.b.p(a, [c, b])
        } else this.b.p(a, b);
        this.a++;
        return this
    };
    l.remove = function (a) {
        Q(this);
        a = S(this, a);
        if (this.b.m(a)) {
            R(this);
            var b = this.b.o(a);
            if (t(b)) this.a -= b.length;
            else this.a--;
            return this.b.remove(a)
        }
        return k
    };
    l.m = function (a) {
        Q(this);
        a = S(this, a);
        return this.b.m(a)
    };
    l.v = function () {
        Q(this);
        for (var a = this.b.s(), b = this.b.v(), c = [], d = 0; d < b.length; d++) {
            var e = a[d];
            if (t(e)) for (var f = 0; f < e.length; f++) c.push(b[d]);
            else c.push(b[d])
        }
        return c
    };
    l.s = function (a) {
        Q(this);
        if (a) {
            a = S(this, a);
            if (this.m(a)) {
                var b = this.b.o(a);
                if (t(b)) return b;
                else {
                    a = [];
                    a.push(b)
                }
            } else a = []
        } else {
            b = this.b.s();
            a = [];
            for (var c = 0; c < b.length; c++) {
                var d = b[c];
                t(d) ? va(a, d) : a.push(d)
            }
        }
        return a
    };
    l.p = function (a, b) {
        Q(this);
        R(this);
        a = S(this, a);
        if (this.m(a)) {
            var c = this.b.o(a);
            if (t(c)) this.a -= c.length;
            else this.a--
        }
        this.b.p(a, b);
        this.a++;
        return this
    };
    l.o = function (a, b) {
        Q(this);
        a = S(this, a);
        if (this.m(a)) {
            var c = this.b.o(a);
            return t(c) ? c[0] : c
        } else return b
    };
    l.toString = function () {
        if (this.j) return this.j;
        if (!this.b) return "";
        for (var a = [], b = 0, c = this.b.v(), d = 0; d < c.length; d++) {
            var e = c[d],
                f = ia(e);
            e = this.b.o(e);
            if (t(e)) for (var g = 0; g < e.length; g++) {
                b > 0 && a.push("&");
                a.push(f);
                e[g] !== "" && a.push("=", ia(e[g]));
                b++
            } else {
                b > 0 && a.push("&");
                a.push(f);
                e !== "" && a.push("=", ia(e));
                b++
            }
        }
        return this.j = a.join("")
    };
    var R = function (a) {
        delete a.S;
        delete a.j;
        a.J && delete a.J.d
    };
    M.prototype.l = function () {
        var a = new M;
        if (this.S) a.S = this.S;
        if (this.j) a.j = this.j;
        if (this.b) a.b = this.b.l();
        return a
    };
    var S = function (a, b) {
        var c = String(b);
        if (a.g) c = c.toLowerCase();
        return c
    };
    M.prototype.B = function (a) {
        if (a && !this.g) {
            Q(this);
            R(this);
            ub(this.b, function (b, c) {
                var d = c.toLowerCase();
                if (c != d) {
                    this.remove(c);
                    this.add(d, b)
                }
            }, this)
        }
        this.g = a
    };
    var T = function () {};
    T.prototype.aa = k;
    T.prototype.L = function () {
        if (!this.aa) {
            this.aa = h;
            this.n()
        }
    };
    T.prototype.n = function () {};
    var Lb, U = function (a, b) {
        this.type = a;
        this.currentTarget = this.target = b
    };
    B(U, T);
    U.prototype.n = function () {
        delete this.type;
        delete this.target;
        delete this.currentTarget
    };
    U.prototype.z = k;
    U.prototype.O = h;
    var V = function (a, b) {
        a && this.M(a, b)
    };
    B(V, U);
    l = V.prototype;
    l.target = j;
    l.relatedTarget = j;
    l.offsetX = 0;
    l.offsetY = 0;
    l.clientX = 0;
    l.clientY = 0;
    l.screenX = 0;
    l.screenY = 0;
    l.button = 0;
    l.keyCode = 0;
    l.charCode = 0;
    l.ctrlKey = k;
    l.altKey = k;
    l.shiftKey = k;
    l.metaKey = k;
    l.ta = k;
    l.ba = j;
    l.M = function (a, b) {
        var c = this.type = a.type;
        this.target = a.target || a.srcElement;
        this.currentTarget = b;
        var d = a.relatedTarget;
        if (d) {
            if (Ma) try {
                d = d.nodeName && d
            } catch (e) {
                d = j
            }
        } else if (c == "mouseover") d = a.fromElement;
        else if (c == "mouseout") d = a.toElement;
        this.relatedTarget = d;
        this.offsetX = a.offsetX !== undefined ? a.offsetX : a.layerX;
        this.offsetY = a.offsetY !== undefined ? a.offsetY : a.layerY;
        this.clientX = a.clientX !== undefined ? a.clientX : a.pageX;
        this.clientY = a.clientY !== undefined ? a.clientY : a.pageY;
        this.screenX = a.screenX || 0;
        this.screenY = a.screenY || 0;
        this.button = a.button;
        this.keyCode = a.keyCode || 0;
        this.charCode = a.charCode || (c == "keypress" ? a.keyCode : 0);
        this.ctrlKey = a.ctrlKey;
        this.altKey = a.altKey;
        this.shiftKey = a.shiftKey;
        this.metaKey = a.metaKey;
        this.ta = Ga ? a.metaKey : a.ctrlKey;
        this.ba = a;
        delete this.O;
        delete this.z
    };
    La && Wa("8");
    V.prototype.n = function () {
        V.P.n.call(this);
        this.relatedTarget = this.currentTarget = this.target = this.ba = j
    };
    var W = function (a, b) {
        this.fa = b;
        this.q = [];
        if (a > this.fa) throw Error("[goog.structs.SimplePool] Initial cannot be greater than max");
        for (var c = 0; c < a; c++) this.q.push(this.i ? this.i() : {})
    };
    B(W, T);
    W.prototype.i = j;
    W.prototype.$ = j;
    W.prototype.r = function () {
        if (this.q.length) return this.q.pop();
        return this.i ? this.i() : {}
    };
    var Nb = function (a, b) {
        a.q.length < a.fa ? a.q.push(b) : Mb(a, b)
    },
        Mb = function (a, b) {
            if (a.$) a.$(b);
            else if (ba(b.L)) b.L();
            else for (var c in b) delete b[c]
        };
    W.prototype.n = function () {
        W.P.n.call(this);
        for (var a = this.q; a.length;) Mb(this, a.pop());
        delete this.q
    };
    var Ob;
    var Pb = (Ob = "ScriptEngine" in m && m.ScriptEngine() == "JScript") ? m.ScriptEngineMajorVersion() + "." + m.ScriptEngineMinorVersion() + "." + m.ScriptEngineBuildVersion() : "0";
    var Qb = function () {},
        Rb = 0;
    l = Qb.prototype;
    l.key = 0;
    l.A = k;
    l.R = k;
    l.M = function (a, b, c, d, e, f) {
        if (ba(a)) this.da = h;
        else if (a && a.handleEvent && ba(a.handleEvent)) this.da = k;
        else throw Error("Invalid listener argument");
        this.G = a;
        this.ia = b;
        this.src = c;
        this.type = d;
        this.capture = !! e;
        this.U = f;
        this.R = k;
        this.key = ++Rb;
        this.A = k
    };
    l.handleEvent = function (a) {
        if (this.da) return this.G.call(this.U || this.src, a);
        return this.G.handleEvent.call(this.G, a)
    };
    var Sb, Tb, Ub, Vb, Wb, Xb, Yb, Zb, $b, ac, bc;
    (function () {
        function a() {
            return {
                a: 0,
                f: 0
            }
        }
        function b() {
            return []
        }
        function c() {
            var p = function (w) {
                return g.call(p.src, p.key, w)
            };
            return p
        }
        function d() {
            return new Qb
        }
        function e() {
            return new V
        }
        var f = Ob && !(qa(Pb, "5.7") >= 0),
            g;
        Xb = function (p) {
            g = p
        };
        if (f) {
            Sb = function () {
                return i.r()
            };
            Tb = function (p) {
                Nb(i, p)
            };
            Ub = function () {
                return n.r()
            };
            Vb = function (p) {
                Nb(n, p)
            };
            Wb = function () {
                return o.r()
            };
            Yb = function () {
                Nb(o, c())
            };
            Zb = function () {
                return x.r()
            };
            $b = function (p) {
                Nb(x, p)
            };
            ac = function () {
                return q.r()
            };
            bc = function (p) {
                Nb(q, p)
            };
            var i = new W(0, 600);
            i.i = a;
            var n = new W(0, 600);
            n.i = b;
            var o = new W(0, 600);
            o.i = c;
            var x = new W(0, 600);
            x.i = d;
            var q = new W(0, 600);
            q.i = e
        } else {
            Sb = a;
            Tb = s;
            Ub = b;
            Vb = s;
            Wb = c;
            Yb = s;
            Zb = d;
            $b = s;
            ac = e;
            bc = s
        }
    })();
    var X = {},
        Y = {},
        Z = {},
        cc = {},
        dc = function (a, b, c, d, e) {
            if (b) if (t(b)) {
                for (var f = 0; f < b.length; f++) dc(a, b[f], c, d, e);
                return j
            } else {
                d = !! d;
                var g = Y;
                b in g || (g[b] = Sb());
                g = g[b];
                if (!(d in g)) {
                    g[d] = Sb();
                    g.a++
                }
                g = g[d];
                var i = z(a),
                    n;
                g.f++;
                if (g[i]) {
                    n = g[i];
                    for (f = 0; f < n.length; f++) {
                        g = n[f];
                        if (g.G == c && g.U == e) {
                            if (g.A) break;
                            return n[f].key
                        }
                    }
                } else {
                    n = g[i] = Ub();
                    g.a++
                }
                f = Wb();
                f.src = a;
                g = Zb();
                g.M(c, f, a, b, d, e);
                c = g.key;
                f.key = c;
                n.push(g);
                X[c] = g;
                Z[i] || (Z[i] = Ub());
                Z[i].push(g);
                if (a.addEventListener) {
                    if (a == m || !a.Z) a.addEventListener(b, f, d)
                } else a.attachEvent(ec(b), f);
                return c
            } else throw Error("Invalid event type");
        },
        fc = function (a, b, c, d, e) {
            if (t(b)) {
                for (var f = 0; f < b.length; f++) fc(a, b[f], c, d, e);
                return j
            }
            a = dc(a, b, c, d, e);
            X[a].R = h;
            return a
        },
        gc = function (a, b, c, d, e) {
            if (t(b)) {
                for (var f = 0; f < b.length; f++) gc(a, b[f], c, d, e);
                return j
            }
            d = !! d;
            a: {
                f = Y;
                if (b in f) {
                    f = f[b];
                    if (d in f) {
                        f = f[d];
                        a = z(a);
                        if (f[a]) {
                            a = f[a];
                            break a
                        }
                    }
                }
                a = j
            }
            if (!a) return k;
            for (f = 0; f < a.length; f++) if (a[f].G == c && a[f].capture == d && a[f].U == e) return hc(a[f].key);
            return k
        },
        hc = function (a) {
            if (!X[a]) return k;
            var b = X[a];
            if (b.A) return k;
            var c = b.src,
                d = b.type,
                e = b.ia,
                f = b.capture;
            if (c.removeEventListener) {
                if (c == m || !c.Z) c.removeEventListener(d, e, f)
            } else c.detachEvent && c.detachEvent(ec(d), e);
            c = z(c);
            e = Y[d][f][c];
            if (Z[c]) {
                var g = Z[c],
                    i = ra(g, b);
                i >= 0 && C.splice.call(g, i, 1).length == 1;
                g.length == 0 && delete Z[c]
            }
            b.A = h;
            e.ga = h;
            ic(d, f, c, e);
            delete X[a];
            return h
        },
        ic = function (a, b, c, d) {
            if (!d.N) if (d.ga) {
                for (var e = 0, f = 0; e < d.length; e++) if (d[e].A) {
                    var g = d[e].ia;
                    g.src = j;
                    Yb(g);
                    $b(d[e])
                } else {
                    if (e != f) d[f] = d[e];
                    f++
                }
                d.length = f;
                d.ga = k;
                if (f == 0) {
                    Vb(d);
                    delete Y[a][b][c];
                    Y[a][b].a--;
                    if (Y[a][b].a == 0) {
                        Tb(Y[a][b]);
                        delete Y[a][b];
                        Y[a].a--
                    }
                    if (Y[a].a == 0) {
                        Tb(Y[a]);
                        delete Y[a]
                    }
                }
            }
        },
        jc = function (a, b, c) {
            var d = 0,
                e = a == j,
                f = b == j,
                g = c == j;
            c = !! c;
            if (e) xa(Z, function (n) {
                for (var o = n.length - 1; o >= 0; o--) {
                    var x = n[o];
                    if ((f || b == x.type) && (g || c == x.capture)) {
                        hc(x.key);
                        d++
                    }
                }
            });
            else {
                a = z(a);
                if (Z[a]) {
                    a = Z[a];
                    for (e = a.length - 1; e >= 0; e--) {
                        var i = a[e];
                        if ((f || b == i.type) && (g || c == i.capture)) {
                            hc(i.key);
                            d++
                        }
                    }
                }
            }
            return d
        },
        ec = function (a) {
            if (a in cc) return cc[a];
            return cc[a] = "on" + a
        },
        lc = function (a, b, c, d, e) {
            var f = 1;
            b =
            z(b);
            if (a[b]) {
                a.f--;
                a = a[b];
                if (a.N) a.N++;
                else a.N = 1;
                try {
                    for (var g = a.length, i = 0; i < g; i++) {
                        var n = a[i];
                        if (n && !n.A) f &= kc(n, e) !== k
                    }
                } finally {
                    a.N--;
                    ic(c, d, b, a)
                }
            }
            return Boolean(f)
        },
        kc = function (a, b) {
            var c = a.handleEvent(b);
            a.R && hc(a.key);
            return c
        };
    Xb(function (a, b) {
        if (!X[a]) return h;
        var c = X[a],
            d = c.type,
            e = Y;
        if (!(d in e)) return h;
        e = e[d];
        var f, g;
        if (Lb === undefined) Lb = La && !m.addEventListener;
        if (Lb) {
            var i;
            if (!(i = b)) a: {
                i = "window.event".split(".");
                for (var n = m; f = i.shift();) if (n[f]) n = n[f];
                else {
                    i = j;
                    break a
                }
                i = n
            }
            f = i;
            i = h in e;
            n = k in e;
            if (i) {
                if (f.keyCode < 0 || f.returnValue != undefined) return h;
                a: {
                    var o = k;
                    if (f.keyCode == 0) try {
                        f.keyCode = -1;
                        break a
                    } catch (x) {
                        o = h
                    }
                    if (o || f.returnValue == undefined) f.returnValue = h
                }
            }
            o = ac();
            o.M(f, this);
            f = h;
            try {
                if (i) {
                    for (var q = Ub(), p = o.currentTarget; p; p =
                    p.parentNode) q.push(p);
                    g = e[h];
                    g.f = g.a;
                    for (var w = q.length - 1; !o.z && w >= 0 && g.f; w--) {
                        o.currentTarget = q[w];
                        f &= lc(g, q[w], d, h, o)
                    }
                    if (n) {
                        g = e[k];
                        g.f = g.a;
                        for (w = 0; !o.z && w < q.length && g.f; w++) {
                            o.currentTarget = q[w];
                            f &= lc(g, q[w], d, k, o)
                        }
                    }
                } else f = kc(c, o)
            } finally {
                if (q) {
                    q.length = 0;
                    Vb(q)
                }
                o.L();
                bc(o)
            }
            return f
        }
        d = new V(b, this);
        try {
            f = kc(c, d)
        } finally {
            d.L()
        }
        return f
    });
    var mc = function (a, b) {
        this.V = b || "en"
    },
        nc = function (a) {
            var b = H("img");
            b.src = ga("http://books.google.com/intl/%s/googlebooks/images/gbs_preview_button1.gif", a.V);
            b.border = 0;
            I(b, "cursor", "pointer");
            return b
        },
        oc = function (a, b, c) {
            this.V = c || "en";
            c = H("a");
            c.href = b;
            a.appendChild(c);
            a = nc(this);
            c.appendChild(a)
        };
    B(oc, mc);
    var pc = function (a, b, c) {
        this.V = c || "en";
        c = nc(this);
        a.appendChild(c);
        I(a, "cursor", "pointer");
        dc(a, "click", b)
    };
    B(pc, mc);
    var rc = function (a) {
        var b = document.getElementsByTagName("body")[0],
            c = H("div");
        qb(c, 0.5);
        I(c, {
            backgroundColor: "#333",
            position: "absolute",
            zIndex: 200
        });
        this.ma = c;
        var d = Za(window);
        ob(c, b.scrollWidth, Math.max(b.scrollHeight, d.height));
        lb(c, 0, 0);
        b.appendChild(c);
        this.I = H("div");
        I(this.I, {
            position: "absolute",
            zIndex: 201
        });
        b.appendChild(this.I);
        this.C = H("div");
        ob(this.C, 618, 600);
        I(this.C, {
            backgroundColor: "#333",
            position: "absolute",
            zIndex: 202
        });
        lb(this.C, 3, 3);
        qb(this.C, 0.3);
        this.I.appendChild(this.C);
        this.w =
        H("div");
        lb(this.w, 0, 0);
        I(this.w, {
            position: "absolute",
            padding: "8px",
            border: "1px solid #2c4462",
            backgroundColor: "#b4cffe",
            zIndex: 203
        });
        b = H("div");
        I(b, {
            backgroundColor: "#d8e8fd",
            fontSize: "16px",
            fontFamily: "Arial, sans-serif",
            fontWeight: "bold",
            padding: "2px 2px 2px 5px"
        });
        this.w.appendChild(b);
        c = H("img");
        c.src = "http://books.google.com/googlebooks/images/dialog_close_x.gif";
        c.width = 15;
        c.height = 15;
        I(c, {
            cursor: "pointer",
            position: "absolute",
            right: "11px",
            top: "11px"
        });
        fc(c, "click", ea(this.close, this));
        b.appendChild(c);
        c = H("div");
        c.innerHTML = "&nbsp;";
        b.appendChild(c);
        this.Y = H("div");
        this.w.appendChild(this.Y);
        ob(this.Y, 600, 556);
        this.I.appendChild(this.w);
        qc(this.Y, a);
        b = Za(window);
        a = Math.max(0, (b.height - 500) / 2);
        c = !Na && document.compatMode == "CSS1Compat" ? document.documentElement : document.body;
        a = Math.floor(a + (new wa(c.scrollLeft, c.scrollTop)).y);
        b = Math.max(0, (b.width - 618) / 2);
        b = Math.floor(b);
        lb(this.I, b, a)
    };
    rc.prototype.close = function () {
        sa([this.w, this.ma, this.C], cb)
    };
    var sc = function (a, b) {
        this.J = new L(a);
        this.na = b ? b : "callback";
        this.X = 5E3
    },
        tc = 0;
    sc.prototype.send = function (a, b, c, d) {
        if (!document.documentElement.firstChild) {
            c && c(a);
            return j
        }
        d = d || "_" + (tc++).toString(36) + fa().toString(36);
        m._callbacks_ || (m._callbacks_ = {});
        var e = H("script"),
            f = j;
        if (this.X > 0) f = m.setTimeout(uc(d, e, a, c), this.X);
        c = this.J.l();
        for (var g in a) if (!a.hasOwnProperty || a.hasOwnProperty(g)) Ib(c, g, a[g]);
        if (b) {
            m._callbacks_[d] = vc(d, e, b, f);
            Ib(c, this.na, "_callbacks_." + d)
        }
        Ya(e, {
            type: "text/javascript",
            id: d,
            charset: "UTF-8",
            src: c.toString()
        });
        document.getElementsByTagName("head")[0].appendChild(e);
        return {
            ua: d,
            X: f
        }
    };
    var uc = function (a, b, c, d) {
        return function () {
            wc(a, b, k);
            d && d(c)
        }
    },
        vc = function (a, b, c, d) {
            return function () {
                m.clearTimeout(d);
                wc(a, b, h);
                c.apply(undefined, arguments)
            }
        },
        wc = function (a, b, c) {
            m.setTimeout(function () {
                cb(b)
            }, 0);
            if (m._callbacks_[a]) if (c) delete m._callbacks_[a];
            else m._callbacks_[a] = s
        };
    var xc = function () {};
    B(xc, T);
    l = xc.prototype;
    l.Z = h;
    l.W = j;
    l.addEventListener = function (a, b, c, d) {
        dc(this, a, b, c, d)
    };
    l.removeEventListener = function (a, b, c, d) {
        gc(this, a, b, c, d)
    };
    l.dispatchEvent = function (a) {
        a = a;
        if (v(a)) a = new U(a, this);
        else if (a instanceof U) a.target = a.target || this;
        else {
            var b = a;
            a = new U(a.type, this);
            Ba(a, b)
        }
        b = 1;
        var c, d = a.type,
            e = Y;
        if (d in e) {
            e = e[d];
            d = h in e;
            var f;
            if (d) {
                c = [];
                for (f = this; f; f = f.W) c.push(f);
                f = e[h];
                f.f = f.a;
                for (var g = c.length - 1; !a.z && g >= 0 && f.f; g--) {
                    a.currentTarget = c[g];
                    b &= lc(f, c[g], a.type, h, a) && a.O != k
                }
            }
            if (k in e) {
                f = e[k];
                f.f = f.a;
                if (d) for (g = 0; !a.z && g < c.length && f.f; g++) {
                    a.currentTarget = c[g];
                    b &= lc(f, c[g], a.type, k, a) && a.O != k
                } else for (c = this; !a.z && c && f.f; c =
                c.W) {
                    a.currentTarget = c;
                    b &= lc(f, c, a.type, k, a) && a.O != k
                }
            }
            a = Boolean(b)
        } else a = h;
        return a
    };
    l.n = function () {
        xc.P.n.call(this);
        jc(this);
        this.W = j
    };
    var yc = function (a) {
        this.url = a;
        this.ja = j;
        this.ea = h
    };
    B(yc, xc);
    yc.prototype.T = function () {
        if (this.ea) this.ea = k;
        else throw {};
    };
    yc.prototype.r = function () {
        return this.ja
    };
    var $ = function (a) {
        yc.call(this, a);
        this.sa = new sc(a);
        this.F = h
    };
    B($, yc);
    $.prototype.T = function (a, b) {
        $.P.T.call(this, a, b);
        this.F = k;
        this.sa.send({}, ea(this.qa, this, a), ea(this.pa, this, b))
    };
    $.prototype.qa = function (a, b) {
        if (!this.F) {
            this.ja = b;
            this.dispatchEvent("success");
            a && a(this.r());
            this.F = h
        }
    };
    $.prototype.pa = function (a) {
        if (!this.F) {
            this.dispatchEvent("error");
            a && a();
            this.F = h
        }
    };
    var Ac = function (a, b, c, d) {
        t(a) || (a = [a]);
        this.ca = a;
        this.ka = b;
        this.ha = c;
        b = new L(zc);
        P(b, "bibkeys", a.join(","));
        P(b, "hl", GBS_LANG);
        P(b, "source", d || "previewlib");
        (new $(b)).T(ea(this.oa, this))
    },
        zc = (GBS_HOST || "http://books.google.com/") + "books?jscmd=viewapi";
    Ac.prototype.oa = function (a) {
        for (var b = 0; b < this.ca.length; b++) {
            var c = a[this.ca[b]];
            if (c) {
                var d = c.preview_url,
                    e;
                if (e = d) {
                    e = c.preview;
                    c = c.embeddable;
                    c !== undefined || (c = h);
                    e = (e == "full" || e == "partial") && c
                }
                if (e) {
                    this.ka && this.ka(d);
                    return
                }
            }
        }
        this.ha && this.ha()
    };
    r("GBS_insertPreviewButtonLink", function (a, b) {
        var c = A(Bc, (b || {}).alternativeUrl);
        Cc(a, c, "GBS_insertPreviewButtonLink")
    }, void 0);
    r("GBS_insertPreviewButtonPopup", function (a) {
        Cc(a, Dc, "GBS_insertPreviewButtonPopup")
    }, void 0);
    r("GBS_insertEmbeddedViewer", function (a, b, c) {
        Cc(a, A(Ec, b, c), "GBS_insertEmbeddedViewer")
    }, void 0);
    var Cc = function (a, b, c) {
        var d = Fc();
        new Ac(a, function (e) {
            b(d, e)
        }, j, c)
    },
        Bc = function (a, b, c) {
            if (a) a = a;
            else {
                a = new L(c);
                if (Gc) {
                    c = new L(GBS_HOST);
                    xb(a, c.k);
                    zb(a, c.u);
                    Ab(a, c.t);
                    Bb(a, "/books/p/" + Gc)
                }
                P(a, "hl", Hc || "en");
                a = a.toString()
            }
            new oc(b, a, Hc)
        },
        Dc = function (a, b) {
            var c = A(Ic, b);
            new pc(a, c, Hc)
        },
        Ec = function (a, b, c, d) {
            var e = H("div");
            c.appendChild(e);
            ob(e, a, b);
            qc(e, d)
        },
        qc = function (a, b) {
            var c = ab("iframe", {
                frameBorder: "0",
                width: "100%",
                height: "100%"
            });
            a.appendChild(c);
            var d = new L(b);
            P(d, "output", "embed");
            if (Jc) {
                var e = [];
                fb(new db, Jc, e);
                Db(d, ia(e.join("")))
            }
            c.src = d.toString()
        },
        Ic = function (a) {
            new rc(a)
        },
        Hc = "en";
    r("GBS_setLanguage", function (a) {
        Hc = a
    }, void 0);
    r("GBS_setViewerOptions", function (a) {
        Jc = a
    }, void 0);
    var Gc = j;
    r("GBS_setCobrandName", function (a) {
        Gc = a
    }, void 0);
    var Jc = {},
        Fc = function () {
            var a = "__GBS_Button" + Kc++;
            document.write(ga('<span id="%s"></span>', a));
            return v(a) ? document.getElementById(a) : a
        },
        Kc = 0;
    dc(window, "unload", function () {
        jc()
    });
})();