require 'test_helper'

class AddressTypesAddressesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:address_types_addresses)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create address_types_addresses" do
    assert_difference('AddressTypesAddresses.count') do
      post :create, :address_types_addresses => { }
    end

    assert_redirected_to address_types_addresses_path(assigns(:address_types_addresses))
  end

  test "should show address_types_addresses" do
    get :show, :id => address_types_addresses(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => address_types_addresses(:one).to_param
    assert_response :success
  end

  test "should update address_types_addresses" do
    put :update, :id => address_types_addresses(:one).to_param, :address_types_addresses => { }
    assert_redirected_to address_types_addresses_path(assigns(:address_types_addresses))
  end

  test "should destroy address_types_addresses" do
    assert_difference('AddressTypesAddresses.count', -1) do
      delete :destroy, :id => address_types_addresses(:one).to_param
    end

    assert_redirected_to address_types_addresses_path
  end
end
