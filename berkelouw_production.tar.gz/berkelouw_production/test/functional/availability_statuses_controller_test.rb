require 'test_helper'

class AvailabilityStatusesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:availability_statuses)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create availability_status" do
    assert_difference('AvailabilityStatus.count') do
      post :create, :availability_status => { }
    end

    assert_redirected_to availability_status_path(assigns(:availability_status))
  end

  test "should show availability_status" do
    get :show, :id => availability_statuses(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => availability_statuses(:one).to_param
    assert_response :success
  end

  test "should update availability_status" do
    put :update, :id => availability_statuses(:one).to_param, :availability_status => { }
    assert_redirected_to availability_status_path(assigns(:availability_status))
  end

  test "should destroy availability_status" do
    assert_difference('AvailabilityStatus.count', -1) do
      delete :destroy, :id => availability_statuses(:one).to_param
    end

    assert_redirected_to availability_statuses_path
  end
end
