require 'test_helper'

class BookSearchesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:book_searches)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create book_search" do
    assert_difference('BookSearch.count') do
      post :create, :book_search => { }
    end

    assert_redirected_to book_search_path(assigns(:book_search))
  end

  test "should show book_search" do
    get :show, :id => book_searches(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => book_searches(:one).to_param
    assert_response :success
  end

  test "should update book_search" do
    put :update, :id => book_searches(:one).to_param, :book_search => { }
    assert_redirected_to book_search_path(assigns(:book_search))
  end

  test "should destroy book_search" do
    assert_difference('BookSearch.count', -1) do
      delete :destroy, :id => book_searches(:one).to_param
    end

    assert_redirected_to book_searches_path
  end
end
