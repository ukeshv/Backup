require 'test_helper'

class BooksoftImportsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:booksoft_imports)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create booksoft_import" do
    assert_difference('BooksoftImport.count') do
      post :create, :booksoft_import => { }
    end

    assert_redirected_to booksoft_import_path(assigns(:booksoft_import))
  end

  test "should show booksoft_import" do
    get :show, :id => booksoft_imports(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => booksoft_imports(:one).to_param
    assert_response :success
  end

  test "should update booksoft_import" do
    put :update, :id => booksoft_imports(:one).to_param, :booksoft_import => { }
    assert_redirected_to booksoft_import_path(assigns(:booksoft_import))
  end

  test "should destroy booksoft_import" do
    assert_difference('BooksoftImport.count', -1) do
      delete :destroy, :id => booksoft_imports(:one).to_param
    end

    assert_redirected_to booksoft_imports_path
  end
end
