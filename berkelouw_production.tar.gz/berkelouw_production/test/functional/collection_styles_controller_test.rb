require 'test_helper'

class CollectionStylesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:collection_styles)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create collection_style" do
    assert_difference('CollectionStyle.count') do
      post :create, :collection_style => { }
    end

    assert_redirected_to collection_style_path(assigns(:collection_style))
  end

  test "should show collection_style" do
    get :show, :id => collection_styles(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => collection_styles(:one).to_param
    assert_response :success
  end

  test "should update collection_style" do
    put :update, :id => collection_styles(:one).to_param, :collection_style => { }
    assert_redirected_to collection_style_path(assigns(:collection_style))
  end

  test "should destroy collection_style" do
    assert_difference('CollectionStyle.count', -1) do
      delete :destroy, :id => collection_styles(:one).to_param
    end

    assert_redirected_to collection_styles_path
  end
end
