require 'test_helper'

class DataMismatchTypesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:data_mismatch_types)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create data_mismatch_type" do
    assert_difference('DataMismatchType.count') do
      post :create, :data_mismatch_type => { }
    end

    assert_redirected_to data_mismatch_type_path(assigns(:data_mismatch_type))
  end

  test "should show data_mismatch_type" do
    get :show, :id => data_mismatch_types(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => data_mismatch_types(:one).to_param
    assert_response :success
  end

  test "should update data_mismatch_type" do
    put :update, :id => data_mismatch_types(:one).to_param, :data_mismatch_type => { }
    assert_redirected_to data_mismatch_type_path(assigns(:data_mismatch_type))
  end

  test "should destroy data_mismatch_type" do
    assert_difference('DataMismatchType.count', -1) do
      delete :destroy, :id => data_mismatch_types(:one).to_param
    end

    assert_redirected_to data_mismatch_types_path
  end
end
