require 'test_helper'

class DataMismatchesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:data_mismatches)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create data_mismatch" do
    assert_difference('DataMismatch.count') do
      post :create, :data_mismatch => { }
    end

    assert_redirected_to data_mismatch_path(assigns(:data_mismatch))
  end

  test "should show data_mismatch" do
    get :show, :id => data_mismatches(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => data_mismatches(:one).to_param
    assert_response :success
  end

  test "should update data_mismatch" do
    put :update, :id => data_mismatches(:one).to_param, :data_mismatch => { }
    assert_redirected_to data_mismatch_path(assigns(:data_mismatch))
  end

  test "should destroy data_mismatch" do
    assert_difference('DataMismatch.count', -1) do
      delete :destroy, :id => data_mismatches(:one).to_param
    end

    assert_redirected_to data_mismatches_path
  end
end
