require 'test_helper'

class EmailEnquiriesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:email_enquiries)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create email_enquiry" do
    assert_difference('EmailEnquiry.count') do
      post :create, :email_enquiry => { }
    end

    assert_redirected_to email_enquiry_path(assigns(:email_enquiry))
  end

  test "should show email_enquiry" do
    get :show, :id => email_enquiries(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => email_enquiries(:one).to_param
    assert_response :success
  end

  test "should update email_enquiry" do
    put :update, :id => email_enquiries(:one).to_param, :email_enquiry => { }
    assert_redirected_to email_enquiry_path(assigns(:email_enquiry))
  end

  test "should destroy email_enquiry" do
    assert_difference('EmailEnquiry.count', -1) do
      delete :destroy, :id => email_enquiries(:one).to_param
    end

    assert_redirected_to email_enquiries_path
  end
end
