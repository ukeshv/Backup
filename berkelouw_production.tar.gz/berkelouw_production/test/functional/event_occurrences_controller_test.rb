require 'test_helper'

class EventOccurrencesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:event_occurrences)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create event_occurrence" do
    assert_difference('EventOccurrence.count') do
      post :create, :event_occurrence => { }
    end

    assert_redirected_to event_occurrence_path(assigns(:event_occurrence))
  end

  test "should show event_occurrence" do
    get :show, :id => event_occurrences(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => event_occurrences(:one).to_param
    assert_response :success
  end

  test "should update event_occurrence" do
    put :update, :id => event_occurrences(:one).to_param, :event_occurrence => { }
    assert_redirected_to event_occurrence_path(assigns(:event_occurrence))
  end

  test "should destroy event_occurrence" do
    assert_difference('EventOccurrence.count', -1) do
      delete :destroy, :id => event_occurrences(:one).to_param
    end

    assert_redirected_to event_occurrences_path
  end
end
