require 'test_helper'

class EventTimingsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:event_timings)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create event_timing" do
    assert_difference('EventTiming.count') do
      post :create, :event_timing => { }
    end

    assert_redirected_to event_timing_path(assigns(:event_timing))
  end

  test "should show event_timing" do
    get :show, :id => event_timings(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => event_timings(:one).to_param
    assert_response :success
  end

  test "should update event_timing" do
    put :update, :id => event_timings(:one).to_param, :event_timing => { }
    assert_redirected_to event_timing_path(assigns(:event_timing))
  end

  test "should destroy event_timing" do
    assert_difference('EventTiming.count', -1) do
      delete :destroy, :id => event_timings(:one).to_param
    end

    assert_redirected_to event_timings_path
  end
end
