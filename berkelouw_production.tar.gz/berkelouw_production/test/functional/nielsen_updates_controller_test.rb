require 'test_helper'

class NielsenUpdatesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:nielsen_updates)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create nielsen_update" do
    assert_difference('NielsenUpdate.count') do
      post :create, :nielsen_update => { }
    end

    assert_redirected_to nielsen_update_path(assigns(:nielsen_update))
  end

  test "should show nielsen_update" do
    get :show, :id => nielsen_updates(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => nielsen_updates(:one).to_param
    assert_response :success
  end

  test "should update nielsen_update" do
    put :update, :id => nielsen_updates(:one).to_param, :nielsen_update => { }
    assert_redirected_to nielsen_update_path(assigns(:nielsen_update))
  end

  test "should destroy nielsen_update" do
    assert_difference('NielsenUpdate.count', -1) do
      delete :destroy, :id => nielsen_updates(:one).to_param
    end

    assert_redirected_to nielsen_updates_path
  end
end
