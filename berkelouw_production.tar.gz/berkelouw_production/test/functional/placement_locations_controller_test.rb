require 'test_helper'

class PlacementLocationsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:placement_locations)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create placement_location" do
    assert_difference('PlacementLocation.count') do
      post :create, :placement_location => { }
    end

    assert_redirected_to placement_location_path(assigns(:placement_location))
  end

  test "should show placement_location" do
    get :show, :id => placement_locations(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => placement_locations(:one).to_param
    assert_response :success
  end

  test "should update placement_location" do
    put :update, :id => placement_locations(:one).to_param, :placement_location => { }
    assert_redirected_to placement_location_path(assigns(:placement_location))
  end

  test "should destroy placement_location" do
    assert_difference('PlacementLocation.count', -1) do
      delete :destroy, :id => placement_locations(:one).to_param
    end

    assert_redirected_to placement_locations_path
  end
end
