require 'test_helper'

class PlacementTypesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:placement_types)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create placement_type" do
    assert_difference('PlacementType.count') do
      post :create, :placement_type => { }
    end

    assert_redirected_to placement_type_path(assigns(:placement_type))
  end

  test "should show placement_type" do
    get :show, :id => placement_types(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => placement_types(:one).to_param
    assert_response :success
  end

  test "should update placement_type" do
    put :update, :id => placement_types(:one).to_param, :placement_type => { }
    assert_redirected_to placement_type_path(assigns(:placement_type))
  end

  test "should destroy placement_type" do
    assert_difference('PlacementType.count', -1) do
      delete :destroy, :id => placement_types(:one).to_param
    end

    assert_redirected_to placement_types_path
  end
end
