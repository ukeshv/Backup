require 'test_helper'

class ProductContentTypesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:product_content_types)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create product_content_type" do
    assert_difference('ProductContentType.count') do
      post :create, :product_content_type => { }
    end

    assert_redirected_to product_content_type_path(assigns(:product_content_type))
  end

  test "should show product_content_type" do
    get :show, :id => product_content_types(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => product_content_types(:one).to_param
    assert_response :success
  end

  test "should update product_content_type" do
    put :update, :id => product_content_types(:one).to_param, :product_content_type => { }
    assert_redirected_to product_content_type_path(assigns(:product_content_type))
  end

  test "should destroy product_content_type" do
    assert_difference('ProductContentType.count', -1) do
      delete :destroy, :id => product_content_types(:one).to_param
    end

    assert_redirected_to product_content_types_path
  end
end
