require 'test_helper'

class ProductDataSuppliersControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:product_data_suppliers)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create product_data_supplier" do
    assert_difference('ProductDataSupplier.count') do
      post :create, :product_data_supplier => { }
    end

    assert_redirected_to product_data_supplier_path(assigns(:product_data_supplier))
  end

  test "should show product_data_supplier" do
    get :show, :id => product_data_suppliers(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => product_data_suppliers(:one).to_param
    assert_response :success
  end

  test "should update product_data_supplier" do
    put :update, :id => product_data_suppliers(:one).to_param, :product_data_supplier => { }
    assert_redirected_to product_data_supplier_path(assigns(:product_data_supplier))
  end

  test "should destroy product_data_supplier" do
    assert_difference('ProductDataSupplier.count', -1) do
      delete :destroy, :id => product_data_suppliers(:one).to_param
    end

    assert_redirected_to product_data_suppliers_path
  end
end
