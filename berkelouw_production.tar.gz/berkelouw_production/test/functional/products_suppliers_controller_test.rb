require 'test_helper'

class ProductsSuppliersControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:products_suppliers)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create products_suppliers" do
    assert_difference('ProductsSuppliers.count') do
      post :create, :products_suppliers => { }
    end

    assert_redirected_to products_suppliers_path(assigns(:products_suppliers))
  end

  test "should show products_suppliers" do
    get :show, :id => products_suppliers(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => products_suppliers(:one).to_param
    assert_response :success
  end

  test "should update products_suppliers" do
    put :update, :id => products_suppliers(:one).to_param, :products_suppliers => { }
    assert_redirected_to products_suppliers_path(assigns(:products_suppliers))
  end

  test "should destroy products_suppliers" do
    assert_difference('ProductsSuppliers.count', -1) do
      delete :destroy, :id => products_suppliers(:one).to_param
    end

    assert_redirected_to products_suppliers_path
  end
end
