require 'test_helper'

class ShippingRegionsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:shipping_regions)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create shipping_region" do
    assert_difference('ShippingRegion.count') do
      post :create, :shipping_region => { }
    end

    assert_redirected_to shipping_region_path(assigns(:shipping_region))
  end

  test "should show shipping_region" do
    get :show, :id => shipping_regions(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => shipping_regions(:one).to_param
    assert_response :success
  end

  test "should update shipping_region" do
    put :update, :id => shipping_regions(:one).to_param, :shipping_region => { }
    assert_redirected_to shipping_region_path(assigns(:shipping_region))
  end

  test "should destroy shipping_region" do
    assert_difference('ShippingRegion.count', -1) do
      delete :destroy, :id => shipping_regions(:one).to_param
    end

    assert_redirected_to shipping_regions_path
  end
end
