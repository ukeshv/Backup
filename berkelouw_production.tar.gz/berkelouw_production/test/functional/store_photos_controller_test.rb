require 'test_helper'

class StorePhotosControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:store_photos)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create store_photo" do
    assert_difference('StorePhoto.count') do
      post :create, :store_photo => { }
    end

    assert_redirected_to store_photo_path(assigns(:store_photo))
  end

  test "should show store_photo" do
    get :show, :id => store_photos(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => store_photos(:one).to_param
    assert_response :success
  end

  test "should update store_photo" do
    put :update, :id => store_photos(:one).to_param, :store_photo => { }
    assert_redirected_to store_photo_path(assigns(:store_photo))
  end

  test "should destroy store_photo" do
    assert_difference('StorePhoto.count', -1) do
      delete :destroy, :id => store_photos(:one).to_param
    end

    assert_redirected_to store_photos_path
  end
end
