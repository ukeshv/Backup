require 'test_helper'

class SuppliersControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:suppliers)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create suppliers" do
    assert_difference('Suppliers.count') do
      post :create, :suppliers => { }
    end

    assert_redirected_to suppliers_path(assigns(:suppliers))
  end

  test "should show suppliers" do
    get :show, :id => suppliers(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => suppliers(:one).to_param
    assert_response :success
  end

  test "should update suppliers" do
    put :update, :id => suppliers(:one).to_param, :suppliers => { }
    assert_redirected_to suppliers_path(assigns(:suppliers))
  end

  test "should destroy suppliers" do
    assert_difference('Suppliers.count', -1) do
      delete :destroy, :id => suppliers(:one).to_param
    end

    assert_redirected_to suppliers_path
  end
end
