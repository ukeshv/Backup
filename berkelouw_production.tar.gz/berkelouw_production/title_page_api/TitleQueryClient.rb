require 'rubygems'
gem 'soap4r'
#!/usr/bin/env ruby
#~ require 'defaultDriver.rb'
require File.dirname(__FILE__) + '/defaultDriver.rb' 

class TitlePageApi
	
	def establish_connection
		#~ endpoint_url = ARGV.shift
		obj = TitleQueryPortType.new(API_CONFIG['TITLE_PAGE_ENDPOINT_URL'])
		# run ruby with -d to see SOAP wiredumps.
		obj.wiredump_dev = STDERR if $DEBUG
		obj
	end

# SYNOPSIS
#   Login(userName, password)
#
# ARGS
#   userName        C_String - {http://www.w3.org/2001/XMLSchema}string
#   password        C_String - {http://www.w3.org/2001/XMLSchema}string
#
# RETURNS
#   token           C_String - {http://www.w3.org/2001/XMLSchema}string
#
	def login(product_object)
		status = false
		search_result = [0, []]
		obj = establish_connection
		userName = API_CONFIG['TITLE_PAGE_USERNAME']
    password = API_CONFIG['TITLE_PAGE_PASSWORD']
		token = obj.Login(userName, password)
		if token.nil?
			status = false
			error_message = 'Invalid Titlepage API authentication details'
		else
			status, availability, price = search_by_ISBN13(obj, token, product_object.isbn13)
			error_message = "Search by isbn13 completed"
			search_result[0] = availability if status
			search_result[1] = price if status			
		end		
		return status, error_message, search_result
	end

# SYNOPSIS
#   SearchByISBN(token, iSBN)
#
# ARGS
#   token           C_String - {http://www.w3.org/2001/XMLSchema}string
#   iSBN            C_String - {http://www.w3.org/2001/XMLSchema}string
#
# RETURNS
#   searchResults   SearchResults - {urn:TitleQuery}SearchResults
##~ token = iSBN = nil
		#~ search_results = obj.SearchByISBN13(token, iSBN)
		
	def search_by_ISBN13(obj, token, iSBN)				
		availability_count = 0
		product_price = [0, 0]
		search_results = obj.SearchByISBN13(token, iSBN)
		if search_results.nil?
			search_status = false
		else			
			product = search_results.product
			supply_detail = product.supplyDetail
			price = supply_detail.price
			availability_count = supply_detail.productAvailability
			search_status = (availability_count.to_i > 0)? true : false
			product_price = [price.priceTypeCode, price.priceAmount]
		end				
		return search_status, availability_count, product_price
	end	

# SYNOPSIS
#   SearchByISBN13(token, iSBN13)
#
# ARGS
#   token           C_String - {http://www.w3.org/2001/XMLSchema}string
#   iSBN13          C_String - {http://www.w3.org/2001/XMLSchema}string
#
# RETURNS
#   searchResults   SearchResults - {urn:TitleQuery}SearchResults
#
	def search_by_ISBN
		token = iSBN13 = nil
		obj.searchByISBN(token, iSBN)
	end	


# SYNOPSIS
#   SearchByEAN(token, eAN)
#
# ARGS
#   token           C_String - {http://www.w3.org/2001/XMLSchema}string
#   eAN             C_String - {http://www.w3.org/2001/XMLSchema}string
#
# RETURNS
#   searchResults   SearchResults - {urn:TitleQuery}SearchResults
#
	def search_by_EAN
		token = eAN = nil
		obj.searchByEAN(token, eAN)
	end	
	
# SYNOPSIS
#   Logout(token)
#
# ARGS
#   token           C_String - {http://www.w3.org/2001/XMLSchema}string
#
# RETURNS
#   N/A
#
	def logout
		token = nil
		obj.logout(token)
	end	

end



