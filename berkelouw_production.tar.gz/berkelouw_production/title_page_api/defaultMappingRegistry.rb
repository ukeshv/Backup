require File.dirname(__FILE__) + '/default.rb' 
#~ require 'default.rb'
require 'soap/mapping'

module DefaultMappingRegistry
  EncodedRegistry = ::SOAP::Mapping::EncodedRegistry.new
  LiteralRegistry = ::SOAP::Mapping::LiteralRegistry.new
  NsTitleQuery = "urn:TitleQuery"

  EncodedRegistry.register(
    :class => ProductIdentifier,
    :schema_type => XSD::QName.new(NsTitleQuery, "ProductIdentifier"),
    :schema_element => [
      ["productIDType", ["SOAP::SOAPString", XSD::QName.new(nil, "ProductIDType")]],
      ["iDValue", ["SOAP::SOAPString", XSD::QName.new(nil, "IDValue")]]
    ]
  )

  EncodedRegistry.register(
    :class => Title,
    :schema_type => XSD::QName.new(NsTitleQuery, "Title"),
    :schema_element => [
      ["titleType", ["SOAP::SOAPString", XSD::QName.new(nil, "TitleType")]],
      ["titleText", ["SOAP::SOAPString", XSD::QName.new(nil, "TitleText")]],
      ["titlePrefix", ["SOAP::SOAPString", XSD::QName.new(nil, "TitlePrefix")]],
      ["titleWithoutPrefix", ["SOAP::SOAPString", XSD::QName.new(nil, "TitleWithoutPrefix")]],
      ["subtitle", ["SOAP::SOAPString", XSD::QName.new(nil, "Subtitle")]]
    ]
  )

  EncodedRegistry.register(
    :class => Contributor,
    :schema_type => XSD::QName.new(NsTitleQuery, "Contributor"),
    :schema_element => [
      ["sequenceNumber", ["SOAP::SOAPInteger", XSD::QName.new(nil, "SequenceNumber")]],
      ["contributorRole", ["SOAP::SOAPString", XSD::QName.new(nil, "ContributorRole")]],
      ["personName", ["SOAP::SOAPString", XSD::QName.new(nil, "PersonName")]],
      ["personNameInverted", ["SOAP::SOAPString", XSD::QName.new(nil, "PersonNameInverted")]],
      ["titlesBeforeNames", ["SOAP::SOAPString", XSD::QName.new(nil, "TitlesBeforeNames")]],
      ["keyNames", ["SOAP::SOAPString", XSD::QName.new(nil, "KeyNames")]]
    ]
  )

  EncodedRegistry.register(
    :class => Stock,
    :schema_type => XSD::QName.new(NsTitleQuery, "Stock"),
    :schema_element => [
      ["onHand", ["SOAP::SOAPString", XSD::QName.new(nil, "OnHand")]],
      ["onOrder", ["SOAP::SOAPString", XSD::QName.new(nil, "OnOrder")]]
    ]
  )

  EncodedRegistry.register(
    :class => Price,
    :schema_type => XSD::QName.new(NsTitleQuery, "Price"),
    :schema_element => [
      ["priceTypeCode", ["SOAP::SOAPString", XSD::QName.new(nil, "PriceTypeCode")]],
      ["priceAmount", ["SOAP::SOAPDecimal", XSD::QName.new(nil, "PriceAmount")]]
    ]
  )

  EncodedRegistry.register(
    :class => SupplyDetail,
    :schema_type => XSD::QName.new(NsTitleQuery, "SupplyDetail"),
    :schema_element => [
      ["supplierName", ["SOAP::SOAPString", XSD::QName.new(nil, "SupplierName")]],
      ["supplierRole", ["SOAP::SOAPString", XSD::QName.new(nil, "SupplierRole")]],
      ["productAvailability", ["SOAP::SOAPString", XSD::QName.new(nil, "ProductAvailability")]],
      ["expectedShipDate", ["SOAP::SOAPString", XSD::QName.new(nil, "ExpectedShipDate")]],
      ["stock", ["Stock", XSD::QName.new(nil, "Stock")]],
      ["packQuantity", ["SOAP::SOAPInteger", XSD::QName.new(nil, "PackQuantity")]],
      ["price", ["Price", XSD::QName.new(nil, "Price")]]
    ]
  )

  EncodedRegistry.set(
    ArrayOfContributor,
    ::SOAP::SOAPArray,
    ::SOAP::Mapping::EncodedRegistry::TypedArrayFactory,
    { :type => XSD::QName.new(NsTitleQuery, "Contributor") }
  )

  EncodedRegistry.set(
    ArrayOfProductIdentifier,
    ::SOAP::SOAPArray,
    ::SOAP::Mapping::EncodedRegistry::TypedArrayFactory,
    { :type => XSD::QName.new(NsTitleQuery, "ProductIdentifier") }
  )

  EncodedRegistry.register(
    :class => Product,
    :schema_type => XSD::QName.new(NsTitleQuery, "Product"),
    :schema_element => [
      ["productIdentifiers", ["ArrayOfProductIdentifier", XSD::QName.new(nil, "ProductIdentifiers")]],
      ["title", ["Title", XSD::QName.new(nil, "Title")]],
      ["contributors", ["ArrayOfContributor", XSD::QName.new(nil, "Contributors")]],
      ["supplyDetail", ["SupplyDetail", XSD::QName.new(nil, "SupplyDetail")]]
    ]
  )

  EncodedRegistry.register(
    :class => SearchResults,
    :schema_type => XSD::QName.new(NsTitleQuery, "SearchResults"),
    :schema_element => [
      ["iSBN", ["SOAP::SOAPString", XSD::QName.new(nil, "ISBN")]],
      ["eAN", ["SOAP::SOAPString", XSD::QName.new(nil, "EAN")]],
      ["iSBN13", ["SOAP::SOAPString", XSD::QName.new(nil, "ISBN13")]],
      ["product", ["Product", XSD::QName.new(nil, "Product")]]
    ]
  )

  LiteralRegistry.register(
    :class => ProductIdentifier,
    :schema_type => XSD::QName.new(NsTitleQuery, "ProductIdentifier"),
    :schema_element => [
      ["productIDType", ["SOAP::SOAPString", XSD::QName.new(nil, "ProductIDType")]],
      ["iDValue", ["SOAP::SOAPString", XSD::QName.new(nil, "IDValue")]]
    ]
  )

  LiteralRegistry.register(
    :class => Title,
    :schema_type => XSD::QName.new(NsTitleQuery, "Title"),
    :schema_element => [
      ["titleType", ["SOAP::SOAPString", XSD::QName.new(nil, "TitleType")]],
      ["titleText", ["SOAP::SOAPString", XSD::QName.new(nil, "TitleText")]],
      ["titlePrefix", ["SOAP::SOAPString", XSD::QName.new(nil, "TitlePrefix")]],
      ["titleWithoutPrefix", ["SOAP::SOAPString", XSD::QName.new(nil, "TitleWithoutPrefix")]],
      ["subtitle", ["SOAP::SOAPString", XSD::QName.new(nil, "Subtitle")]]
    ]
  )

  LiteralRegistry.register(
    :class => Contributor,
    :schema_type => XSD::QName.new(NsTitleQuery, "Contributor"),
    :schema_element => [
      ["sequenceNumber", ["SOAP::SOAPInteger", XSD::QName.new(nil, "SequenceNumber")]],
      ["contributorRole", ["SOAP::SOAPString", XSD::QName.new(nil, "ContributorRole")]],
      ["personName", ["SOAP::SOAPString", XSD::QName.new(nil, "PersonName")]],
      ["personNameInverted", ["SOAP::SOAPString", XSD::QName.new(nil, "PersonNameInverted")]],
      ["titlesBeforeNames", ["SOAP::SOAPString", XSD::QName.new(nil, "TitlesBeforeNames")]],
      ["keyNames", ["SOAP::SOAPString", XSD::QName.new(nil, "KeyNames")]]
    ]
  )

  LiteralRegistry.register(
    :class => Stock,
    :schema_type => XSD::QName.new(NsTitleQuery, "Stock"),
    :schema_element => [
      ["onHand", ["SOAP::SOAPString", XSD::QName.new(nil, "OnHand")]],
      ["onOrder", ["SOAP::SOAPString", XSD::QName.new(nil, "OnOrder")]]
    ]
  )

  LiteralRegistry.register(
    :class => Price,
    :schema_type => XSD::QName.new(NsTitleQuery, "Price"),
    :schema_element => [
      ["priceTypeCode", ["SOAP::SOAPString", XSD::QName.new(nil, "PriceTypeCode")]],
      ["priceAmount", ["SOAP::SOAPDecimal", XSD::QName.new(nil, "PriceAmount")]]
    ]
  )

  LiteralRegistry.register(
    :class => SupplyDetail,
    :schema_type => XSD::QName.new(NsTitleQuery, "SupplyDetail"),
    :schema_element => [
      ["supplierName", ["SOAP::SOAPString", XSD::QName.new(nil, "SupplierName")]],
      ["supplierRole", ["SOAP::SOAPString", XSD::QName.new(nil, "SupplierRole")]],
      ["productAvailability", ["SOAP::SOAPString", XSD::QName.new(nil, "ProductAvailability")]],
      ["expectedShipDate", ["SOAP::SOAPString", XSD::QName.new(nil, "ExpectedShipDate")]],
      ["stock", ["Stock", XSD::QName.new(nil, "Stock")]],
      ["packQuantity", ["SOAP::SOAPInteger", XSD::QName.new(nil, "PackQuantity")]],
      ["price", ["Price", XSD::QName.new(nil, "Price")]]
    ]
  )

  LiteralRegistry.register(
    :class => Product,
    :schema_type => XSD::QName.new(NsTitleQuery, "Product"),
    :schema_element => [
      ["productIdentifiers", ["ArrayOfProductIdentifier", XSD::QName.new(nil, "ProductIdentifiers")]],
      ["title", ["Title", XSD::QName.new(nil, "Title")]],
      ["contributors", ["ArrayOfContributor", XSD::QName.new(nil, "Contributors")]],
      ["supplyDetail", ["SupplyDetail", XSD::QName.new(nil, "SupplyDetail")]]
    ]
  )

  LiteralRegistry.register(
    :class => SearchResults,
    :schema_type => XSD::QName.new(NsTitleQuery, "SearchResults"),
    :schema_element => [
      ["iSBN", ["SOAP::SOAPString", XSD::QName.new(nil, "ISBN")]],
      ["eAN", ["SOAP::SOAPString", XSD::QName.new(nil, "EAN")]],
      ["iSBN13", ["SOAP::SOAPString", XSD::QName.new(nil, "ISBN13")]],
      ["product", ["Product", XSD::QName.new(nil, "Product")]]
    ]
  )
end
