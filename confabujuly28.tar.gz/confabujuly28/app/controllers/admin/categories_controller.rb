class Admin::CategoriesController < ApplicationController
	before_filter :admin_login_required
	layout 'admin'
	
  def index
    if request.xhr?
    	render :update do |page|
	@categories = Category.paginate :all,:conditions=>["name LIKE '%%#{params[:category]}%%' or description LIKE '%%#{params[:category]}%%'"],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:category]
	page.replace_html 'replace',:partial=>'category'
      end
   else
    @categories = Category.paginate :page=>params[:page],:per_page=>15,:order=>'created_at asc'
  end
  end
  
 
  def new
    load_categories
    @category = Category.new

    respond_to do |format|
    format.html # new.html.erb
    format.xml  { render :xml => @category }
    end
  end
  
  def create
    load_categories

    @category = Category.create(:name=>params[:category][:name],:description=>params[:category][:description])

     respond_to do |format|
     if @category.save
     flash[:notice] = 'Category was successfully created.'
     format.html { redirect_to(admin_categories_url) }
     format.xml  { render :xml => @category, :status => :created, :location => @category }
     else
     format.html { render :action => "new" }
     format.xml  { render :xml => @category.errors, :status => :unprocessable_entity }
    end
    end
  end
  
    def show
    @category = Category.find(params[:id])

    respond_to do |format|
    format.html # show.html.erb
    format.xml  { render :xml => @category }
    end
   end
   
   def edit
      @category = Category.find(params[:id])
   end
  
  def update
    load_categories
    @category = Category.find(params[:id])

    respond_to do |format|
    if @category.update_attributes(params[:category])
    flash[:notice] = 'Category was successfully updated.'
    format.html { redirect_to(admin_categories_url) }
    format.xml  { head :ok }
    else
    format.html { render :action => "edit" }
    format.xml  { render :xml => @category.errors, :status => :unprocessable_entity }
    end
  end
  end
  

    
  def destroy
    @category = Category.find(params[:id])
        @category.destroy 
    respond_to do |format|
      format.html { redirect_to(admin_categories_url) }
      format.xml  { head :ok }
    end
  end
  
   def delete_categories
    if !params[:category].blank?
      params[:category].each do |category_id|
        category = Category.find(category_id)
	if category.rooms.nil? || category.rooms.empty?
        category.destroy 
       flash[:notice] = 'Categories(s) was successfully deleted.'
        else
	flash[:error] = 'Select category which has no rooms.'
	end
      end
    else
    flash[:error] = 'Select Categories(s) to delete.'  
    end

    respond_to do |format|
      format.html { redirect_to(admin_categories_url) }
      format.xml  { render :xml => @content_types }
    end
   end 

  
  def load_categories
	@categories = Category.find(:all)
  end


end
