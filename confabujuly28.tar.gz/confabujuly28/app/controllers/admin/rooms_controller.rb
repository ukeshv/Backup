class Admin::RoomsController < ApplicationController
	before_filter :admin_login_required
	layout 'admin'
	
  def index
    @rooms= Room.paginate :page=>params[:page],:per_page=>15,:order=>'created_at desc'
    respond_to do |format|
    format.html # index.html.erb
    format.xml  { render :xml => @rooms }
    end
  end

  def upgrades
    @room = Room.find(params[:id])
    @room_upgrades = @room.room_upgrades.paginate :page=>params[:page],:per_page=>15,:order=>'created_at desc'
  end

  def destroy
    @room = Room.find(params[:id])
    @room.destroy
    flash[:notice] = "Room deleted successfully"    
    respond_to do |format|
      format.html { redirect_to(admin_rooms_url) }
      format.xml  { head :ok }
    end
  end

   def delete_rooms
    if !params[:room].blank?
      params[:room].each do |room_id|
        room = Room.find(room_id)
        room.destroy 
      end
    flash[:notice] = 'Room(s) was successfully deleted.'
    else
    flash[:error] = 'Select Room(s) to delete.'  
    end

    respond_to do |format|
      format.html { redirect_to(admin_rooms_url) }
      format.xml  { render :xml => @rooms }
    end
   end 

end
