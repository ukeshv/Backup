class Admin::SettingsController < ApplicationController
	before_filter :admin_login_required
	layout 'admin'

def price_settings
	@price_setting = PriceSetting.find :first
end

def price_settings_update
		@price_setting = PriceSetting.find(params[:id])

    respond_to do |format|
      if @price_setting.update_attributes(params[:price_setting])
        flash[:notice] = 'Price Settings was successfully updated.'
        format.html { redirect_to(admin_price_settings_url) }
        format.xml  { head :ok }
      else
        format.html { render :action => "price_settings" }
        format.xml  { render :xml => @price_setting.errors, :status => :unprocessable_entity }
      end
    end
end	

def room_settings
	@room_setting = RoomSetting.find :first
end

def room_settings_update
		@room_setting = RoomSetting.find(params[:id])

    respond_to do |format|
      if @room_setting.update_attributes(params[:room_setting])
        flash[:notice] = 'Room Settings was successfully updated.'
        format.html { redirect_to(admin_room_settings_url) }
        format.xml  { head :ok }
      else
        format.html { render :action => "room_settings" }
        format.xml  { render :xml => @room_setting.errors, :status => :unprocessable_entity }
      end
    end
end

end
