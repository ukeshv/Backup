class AdminsController < ApplicationController
	layout 'admin'

def login
return unless request.post?
@admin = Admin.authenticate(params[:login],params[:password])
	if @admin
		session[:admin] = @admin.id
		redirect_to admin_price_settings_path
		else
			flash.now[:error] = "provide valid login/password"
			render :action => 'login'
	end  
end	

def logout
		@admin = nil
		session[:admin] = nil
    flash[:notice] = "You have been logged out."
    redirect_to admin_path
end	

end
