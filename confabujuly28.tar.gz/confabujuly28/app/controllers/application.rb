class ApplicationController < ActionController::Base
  include ExceptionNotifiable
  include AuthenticatedSystem
  include RoleRequirementSystem
	include ActiveMerchant::Billing


  helper :all # include all helpers, all the time
  protect_from_forgery :secret => 'b0a876313f3f9195e9bd01473bc5cd06'
  filter_parameter_logging :password, :password_confirmation
  before_filter :generate_current_chat_user
  rescue_from ActiveRecord::RecordNotFound, :with => :record_not_found

  def admin_login_required
    if session[:admin]
      @admin = Admin.find(session[:admin])
    else
      redirect_to admin_path
    end   
  end  
  
  def room_expiry_date
    date = Date.today
    room_setting = RoomSetting.find(:first)
    expiry_date = date+room_setting.default_expiry_days
    return expiry_date
  end	

  def average_for_room(post) 
    post = Post.find_by_id(post.id)
    room = post.room
    all_post = room.posts
    avg_posts = []
    all_post.each do |each_post|
      avg_posts << each_post.rating_average.to_f if each_post.rated?
    end  
    average_room = avg_posts.sum/avg_posts.length
    room.update_attribute(:ratings,average_room)
  end

  def generate_current_chat_user
    session[:current_chat_user]= rand(99999) unless session[:current_chat_user]
  end
  
  def login_status
		#puts params.inspect
    if params[:room]
    session[:protect_room] = params[:room] 
		elsif params[:title_url]
		session[:title_url] = params[:title_url] 
    end
  end    

  protected
  
  # Automatically respond with 404 for ActiveRecord::RecordNotFound
  def record_not_found
    render :file => File.join(RAILS_ROOT, 'public', '404.html'), :status => 404
  end
	
	private
	
	def gateway
		ActiveMerchant::Billing::Base.mode = :test 
    @gateway ||= PaypalExpressGateway.new(
      :login => 'rortes_1247119133_biz_api1.gmail.com',
      :password => '1247119143',
      :signature => 'ABg4oz3Aj33WY5yRBTUaj5.se4GoAipizOiYf4ecmZHfrxQn4NmVJc8T'
     )
  end


end

