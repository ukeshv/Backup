class CategoriesController < ApplicationController
	layout 'users'
 	
  def index
		conditions = "(expiry_date > #{Date.today.to_formatted_s(:db)} OR expiry_date is NULL)"
		#UGLY UGLY collections for left side navigation
			    recent_rooms_conditions = "((expiry_date > #{Date.today.to_formatted_s(:db)} OR expiry_date is NULL) AND ((is_class_room=1 AND is_class_room_verified=1) OR (is_class_room=0 AND is_class_room_verified=0)) AND (category_id is NOT NULL))"
					
		@categories = Category.find(:all,:limit=>5,:order=>"created_at DESC")
		@recent_rooms = Room.all(:conditions=>recent_rooms_conditions, :order=>'created_at DESC', :limit=>5)
		@popular_rooms = Room.all(:conditions=>conditions, :order=>'ratings DESC', :limit=>5)		
  end
	
	def show
		conditions = "(expiry_date > #{Date.today.to_formatted_s(:db)} OR expiry_date is NULL)"
		#UGLY UGLY collections for left side navigation
			    recent_rooms_conditions = "((expiry_date > #{Date.today.to_formatted_s(:db)} OR expiry_date is NULL) AND ((is_class_room=1 AND is_class_room_verified=1) OR (is_class_room=0 AND is_class_room_verified=0)) AND (category_id is NOT NULL))"
		@categories = Category.find(:all,:limit=>5,:order=>"created_at DESC")
		@recent_rooms = Room.all(:conditions=>recent_rooms_conditions, :order=>'created_at DESC', :limit=>5)
		@popular_rooms = Room.all(:conditions=>conditions, :order=>'ratings DESC', :limit=>5)		
		
    order = 'title'
    order = 'created_at DESC' if params[:order] && params[:order]=='recent'
    order = 'ratings DESC' if params[:order] && params[:order]=='popular'
		if params[:id].nil?
			@rooms =  Room.paginate(:conditions=>["category_id IS NULL"], :order=>order, :page=>params[:page] || 1, :per_page=>10)
		else
		   @category=Category.find_by_id(params[:id])
			if @category
			    @rooms =  @category.rooms.paginate(:order=>order, :page=>params[:page] || 1, :per_page=>10)
			else
				flash[:error]="There is no category available to display."
			#	@rooms =  Room.paginate(:conditions=>["category_id IS NULL"], :order=>order, :page=>params[:page] || 1, :per_page=>10)
			end
		end
 	  render :template=>'rooms/index'
	end
end
