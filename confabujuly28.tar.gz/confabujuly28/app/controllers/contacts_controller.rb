class ContactsController < ApplicationController
	layout :change_layout
	protect_from_forgery :except=>['import_contacts', 'invite_contacts','send_invite', 'networks']
	def index
		@user_contacts = current_user.user_contacts
  end
  
  
	def show
   		@user_contact = User.find(params[:id])
     @price_setting = PriceSetting.find :first
	end
	
	#Block part is removed.
	
=begin
	def update		
		@user_contact = UserContact.find(params[:id])
		@user_contact.update_attributes(:is_block => true)
    respond_to do |format|
      format.html { redirect_to(contacts_url) }
      format.xml  { head :ok }
    end		
	end
=end

  def import		
    
		@import_contacts = []
		@c_contacts = []
	end
	
	def import_contacts
  
		require 'rubygems'	
		require 'soap/wsdlDriver'
    
      if (params[:import][:username].nil? || params[:import][:username].empty?) && (params[:import][:password].nil? || params[:import][:password].empty?)
			flash[:error] = "Username and Password can not be empty"
			render :action => 'import'
		elsif params[:import][:username].nil? || params[:import][:username].empty? 
			flash[:error] = "Username can not be empty"
			render :action => 'import'
		elsif params[:import][:password].nil? || params[:import][:password].empty?
			flash[:error] = "Password can not be empty"      
			render :action => 'import'
		else
			@confabu_contacts = []
			@import_contacts = []
			begin
				driver = SOAP::WSDLDriverFactory.new("http://socialapi.railsfactory.com/contacts/wsdl").create_rpc_driver
				import_contacts = driver.Getcontacts("#{params[:import][:username]}","#{params[:import][:password]}","#{params[:import][:network].upcase}","5372F3436401EED6EA41826B1030CB9227700CBB3F20B98F")			
				@import_contacts = eval(import_contacts) if import_contacts        
				 if @import_contacts[1].length > 0				
					 @user_contacts = current_user.user_contacts
					 @import_contacts[1].each do |import_contact|
            confabu_user = User.find_by_email(import_contact[1])
						@confabu_contacts << confabu_user if (@user_contacts.nil? || !@user_contacts.collect{|x|x.contact_id}.include?(confabu_user)) && !confabu_user.nil?					
          end				
        end
				@contacts = @user_contacts + @confabu_contacts
				 if @contacts.length > 0
					 @import_contacts[1].each{|x|x.delete_if{@contacts.collect{|y|y.email}.include?(x[1])}}
				 end
      #@import_contacts[1] = @import_contacts[1].flatten
			rescue
    end
    			#~ @confabu_contacts = []
          @confabu_contacts.delete_if{|x| current_user.email == x.email}
                 #@user_contacts = current_user.user_contacts
              @c_contacts = []
         for confabu_contact in @confabu_contacts
         								 if !@user_contacts.empty?
                           i=0
                   for user_contact in @user_contacts
                              if  user_contact.contact.email == confabu_contact.email 
                                i+=1
                              end
                            end
                            if i==0
                               @c_contacts << confabu_contact
                            end
                else
                  
                  @c_contacts << confabu_contact
                  end
                  end
                  
                  
        @import_contacts = [] if @import_contacts.length == 0
			render :action => 'import'
		end
	end
  
  def invite_contacts
  
    a   = '[\w\.%\+\-]+'                          # what you actually see in practice
    #RE_EMAIL_NAME   = '0-9A-Z!#\$%\&\'\*\+_/=\?^\-`\{|\}~\.' # technically allowed by RFC-2822
    b  = '(?:[A-Z0-9\-]+\.)+'
    c  = '(?:[A-Z]{2}|com|org|net|edu|gov|mil|biz|info|mobi|name|aero|jobs|museum)'
    d  = /\A#{a}@#{b}#{c}\z/i
    flag = 0
    if params[:multiple_emails]
    @multiple_emails = params[:multiple_emails]
    @emails = params[:multiple_emails].split(',')
    for email in @emails
    if email =~ d
      else
        flag = 1
      end
      end
  
    else
    @emails = params[:emails]
  end  
 
  if flag == 0
    unless @emails.nil? || @emails.empty?
      @emails.each do |email|
       
          UserMailer.deliver_invite_mail(current_user, email, params[:msg])
      end
      flash[:notice] = "Invites has been successfully sent to the contacts selected"		
    end 
		@c_contacts = []
		@import_contacts = []
    if @multiple_emails
        redirect_to invite_path
    else
    render :action => 'import'
    end 
else
  		@c_contacts = []
		@import_contacts = []
  flash[:error] = "Invitation not sent"
  if @mutiple_emails
    render :action => 'import'
  else
  render :action =>'invite'

  end
  
end
  end
  
  def add_contacts
    @contacts = params[:contacts]
    unless @contacts.nil? || @contacts.empty?
      @contacts.each do |contact|
        UserContact.create(:user_id=>current_user.id, :contact_id=>contact, :created_at=>Time.now, :updated_at=>Time.now)
      end
      flash[:notice] = "Contacts added successfully"		
    end
 		@c_contacts = []
		@import_contacts = []
    render :action => 'import'
  end
	
	def add_as_contact
		@contact = params[:id]
		UserContact.create(:user_id=>current_user.id, :contact_id=>@contact, :created_at=>Time.now, :updated_at=>Time.now)
		flash[:notice] = "Contact added Successfully"
		redirect_to contacts_path
	end

  
	def destroy		  
    @user_contact = UserContact.find(params[:id])
    @user_contact.destroy
flash[:notice] = "Contact deleted Successfully"
    respond_to do |format|
      format.html { redirect_to(contacts_url) }
      format.xml  { head :ok }
    end		
	end
  
def networks
  @networks = Network.find :all,:conditions=>['user_id = ?',current_user.id]
	return unless request.post?
	if (!params[:username].blank? and !params[:password].blank?)
	@network = Network.new()
	@network.user_id = current_user.id
	@network.username = params[:username]
	@network.encrypted_password = params[:password].encrypt
	@network.network_type = params[:network][:network_type]
	@network.save
	flash[:notice] = "Network added Successfully"
	else
	flash[:error] = "Username and password can't be blank"
	end	
	redirect_to networks_path
end

def network_delete
	Network.find_by_id(params[:id]).destroy
	flash[:notice] = "Network deleted Successfully"
	redirect_to networks_path
end	
 
	
	protected
	
	def change_layout
		(action_name == 'show') ? 'popup' : 'users'
	end
end
