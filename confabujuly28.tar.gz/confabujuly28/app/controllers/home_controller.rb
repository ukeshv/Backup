class HomeController < ApplicationController
  #layout "users", :except =>['index']
 layout :change_layout, :except =>['feedback','post_feedback']
 before_filter :login_required ,:only=>[:dashboard]

 def dashboard

   #~ render :text =>"this is the dashboard" 
	conditions = "(expiry_date > #{Date.today.to_formatted_s(:db)} OR expiry_date is NULL)"
  order='created_at DESC'
  recent_rooms_conditions = "((expiry_date > #{Date.today.to_formatted_s(:db)} OR expiry_date is NULL) AND ((is_class_room=1 AND is_class_room_verified=1) OR (is_class_room=0 AND is_class_room_verified=0)) AND (category_id is NOT NULL))"
	#UGLY UGLY collections for left side navigation
	#@categories = Category.all(:order=>'name')
	@categories = Category.all(:order=>'created_at DESC')
	@recent_rooms = Room.all(:conditions=>recent_rooms_conditions, :order=>'created_at DESC', :limit=>5)
	@popular_rooms = Room.all(:conditions=>conditions, :order=>'ratings DESC', :limit=>5)		
  #@posts = current_user.posts
	conditions = ""
  if params[:order] == 'room_name'
  conditions = ""
  order = 'rooms.title ASC'
  join = 'INNER JOIN rooms on posts.room_id = rooms.id' 
  elsif params[:order] == 'category'
  order = 'categories.name ASC'
  join = 'INNER JOIN rooms on posts.room_id = rooms.id INNER JOIN categories ON rooms.category_id = categories.id' 
  elsif params[:order] == 'text'
    conditions = "content != ''"
    order = 'created_at DESC'
   # order = 'content ASC'
  elsif params[:order] == 'image'
    conditions = "attachable_type ='post' and content_type LIKE '%image%'"
    join = 'INNER JOIN attachments on posts.id = attachments.attachable_id ' 
  elsif params[:order] == 'video'
    conditions = "attachable_type ='post' and content_type = '%video%'"
    join = 'INNER JOIN attachments on posts.id = attachments.attachable_id' 
  elsif params[:order] == 'file'
    conditions = "attachable_type ='post' and content_type LIKE '%application%'"
    join = 'INNER JOIN attachments on posts.id = attachments.attachable_id' 
  elsif params[:order] == 'link'
    conditions = "link != '' "
     #order = 'link ASC'
     order = 'created_at DESC'
  end
  #@posts =  current_user.posts.find(:all,:conditions=>conditions, :order=>order, :joins =>join).reverse
  @posts =  current_user.posts.paginate(:all,:conditions=>conditions, :order=>order, :joins =>join,:page=>params[:page] || 1, :per_page=>10)
  
  #@posts =  Post.paginate(:conditions=>conditions, :order=>order, :page=>params[:page] || 1, :per_page=>10)


 end
 
 def index
     room = Room.new
     @room_name =  room.generate_code
    if current_user
    redirect_to dashboard_path
    end
   # render :layout =>"home"
  end
 def blog
 end
 def faq
 end
 def terms
 end
 def about
 end
 def contact_us
   
 end
 def message

  AdminNotifier.deliver_post_message_notification(params[:name], params[:email],params[:message])
  flash[:notice]="successfully mail send"
  redirect_to :action=>'contact_us'
 
  end
 
 
 	def change_layout
	#(action_name=="dashboard" ) ? "users" : "home"
  if action_name=="dashboard"
      "users"
  else
     "home"
  end
end

def feedback
 
end

  #Method called to send a feedback/report about a post under room and popup form will be displayed
  def post_feedback
  
  end 
 
  
end
