class NotesController < ApplicationController
	before_filter :login_required
 	layout "users", :except=>['new']
  protect_from_forgery :except=>['update','create']
  
  def index
	conditions = "(expiry_date > #{Date.today.to_formatted_s(:db)} OR expiry_date is NULL)"
	#UGLY UGLY collections for left side navigation
	    recent_rooms_conditions = "((expiry_date > #{Date.today.to_formatted_s(:db)} OR expiry_date is NULL) AND ((is_class_room=1 AND is_class_room_verified=1) OR (is_class_room=0 AND is_class_room_verified=0)) AND (category_id is NOT NULL))"
			
	@categories = Category.all(:order=>'name')
	@recent_rooms = Room.all(:conditions=>recent_rooms_conditions, :order=>'created_at DESC', :limit=>5)
	@popular_rooms = Room.all(:conditions=>conditions, :order=>'ratings DESC', :limit=>5)		
  
  conditions = ""
	order = 'created_at DESC'
  if params[:order] == 'text'
    conditions = "content IS NOT NULL"
		join=''
  elsif params[:order] == 'image'
    conditions = "attachable_type ='Note' AND content_type LIKE '%image%'"
    join = 'INNER JOIN attachments on notes.id = attachments.attachable_id ' 
  elsif params[:order] == 'video'
    conditions = "(attachable_type ='Note' AND content_type LIKE '%video%')"
    join = 'LEFT JOIN attachments on notes.id = attachments.attachable_id' 
  elsif params[:order] == 'file'
    conditions = "attachable_type ='Note' AND content_type LIKE '%application%'"
    join = 'INNER JOIN attachments on notes.id = attachments.attachable_id' 
  elsif params[:order] == 'link'
    conditions = "link IS NOT NULL"
		join=''
	end
  @notes =  current_user.notes.paginate(:conditions=>conditions, :order=>order, :joins =>join, :page=>params[:page] || 1, :per_page=>10)
  end
 	
	def create		
		params[:comment_text]=params[:comment_text].strip
		params[:link]=params[:link].strip
		params[:comment_text]=params[:comment_text].strip
		
		if (params[:comment_text].empty? && params[:link].empty? && params[:attach][:image_attachment].blank? && params[:attach][:document_attachment].blank? && params[:attach][:video_attachment].blank? &&  params[:embed_video].blank?)
					flash[:error] ="Cann't be blank."    
				  redirect_to notes_path
			else
					
					if !params[:attach][:image_attachment].blank? || !params[:attach][:document_attachment].blank? || !params[:attach][:video_attachment].blank? ||  !params[:embed_video].blank?
						
								if params[:attach][:video_attachment].blank? && !params[:embed_video].blank?
											if params[:embed_video].include? 'value="http://'
												embed_video=params[:embed_video]
												embed_video=embed_video.match /(.+)http:(.+)/
												embed_video=embed_video.captures[1].inspect	 
												embed_video=embed_video.split(/"/)
												video="http:"+embed_video[1].to_s
											post = Note.create(:user =>current_user, :content=>params[:comment_text], :link=>params[:link],:embed_video=>video)
										attachment=Attachment.create(:attachable_id=>post.id,:attachable_type=>"Note",:content_type=>"embed_video") 
										flash[:message] ="Note created successfully"    
										redirect_to notes_path	
										end
									else
											if !params[:attach][:video_attachment].blank? && !params[:embed_video].blank?
													flash[:error] ="Either video or embed video only accpted."    
													redirect_to notes_path
											else
														post = Note.create(:user =>current_user, :content=>params[:comment_text], :link=>params[:link])
														params[:attach].each do |a|
															post.attachments << Attachment.new(:uploaded_data=>a.last) unless a.last.to_s.empty?
														end		
														flash[:message] ="Note created successfully"  
													 redirect_to notes_path	
											end					
								end					
					else
					post = Note.create(:user =>current_user, :content=>params[:comment_text], :link=>params[:link])
					flash[:message] ="Note created successfully"  
					redirect_to notes_path	
          end	
			end

  end
	
	def download
		#send_file(Attachment.find(params[:file]).public_filename)
 		file = Attachment.find(params[:id])		
		send_file("#{RAILS_ROOT}/public"+file.public_filename, :type=>file.content_type, :disposition => 'disposition')
	end
	
	def copy_notes
		post = Post.find(params[:id])	
	  if post.embed_video && !post.embed_video.nil?
					note = Note.create(:post_id=>post.id, :content=>post.content, :link=>post.link, :user_id=>current_user.id,:embed_video=>post.embed_video)
		attachment=Attachment.create(:attachable_id=>note.id,:attachable_type=>"Note",:content_type=>"embed_video")
		flash[:message]="Notes successfully copied."
		redirect_to room_path(post.room_id)		
		else
			note = Note.create(:post_id=>post.id, :content=>post.content, :link=>post.link, :user_id=>current_user.id)
				post.attachments.each do |attachment|		  
			file = Attachment.create(:attachable_id=>note.id, :attachable_type=>"Note", :content_type=>attachment.content_type, :filename=> attachment.filename, :thumbnail=>attachment.thumbnail, :size=>attachment.size, :height=>attachment.height, :width=>attachment.width)
			src_file = find_file_path(attachment)
			dest_file = find_file_path(file)
			system("cp -rf #{src_file} #{dest_file}")
		end
		flash[:message]="Notes successfully copied."
		redirect_to room_path(post.room_id)
		end
	end
	
	def find_file_path(attachment)
		file = attachment.public_filename
		file = file.split("/")
		file.pop
		file = "#{RAILS_ROOT}/public"+file.join("/")
	end
	
	def destroy
	    @note = Note.find(params[:id])
			if @note
	    @note.destroy
	    flash[:message] ="Note deleted successfully"    
	    respond_to do |format|
	      format.html { redirect_to(notes_path) }
	      format.xml  { head :ok }
			end
		end
	end
end
