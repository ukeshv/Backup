class PostsController < ApplicationController
 	layout "users", :except=>['new', 'reply_form', 'reply']
  protect_from_forgery :except=>['update','create', 'reply_form','reply','feedback', 'rating_for_post']
  before_filter :login_required ,:only=>[:reply_form]
  def index
		conditions = "(expiry_date > #{Date.today.to_formatted_s(:db)} OR expiry_date is NULL)"
		#UGLY UGLY collections for left side navigation
			    recent_rooms_conditions = "((expiry_date > #{Date.today.to_formatted_s(:db)} OR expiry_date is NULL) AND ((is_class_room=1 AND is_class_room_verified=1) OR (is_class_room=0 AND is_class_room_verified=0)) AND (category_id is NOT NULL))"
		@categories = Category.all(:order=>'name')
		@recent_rooms = Room.all(:conditions=>recent_rooms_conditions, :order=>'created_at DESC', :limit=>5)
		@popular_rooms = Room.all(:conditions=>conditions, :order=>'ratings DESC', :limit=>5)		
		
		conditions="id !=0 "
	  conditions += " AND content LIKE '%#{params[:q]}%'" if params[:q]
		order = 'created_at DESC'
		@posts =  Post.paginate(:conditions=>conditions, :order=>order, :page=>params[:page] || 1, :per_page=>10)
    end
 	
	def create
		# TODO - save link if provided		

		if params[:choice] 
      if params[:choice] == 'text'
   		  post = Post.create(:user =>current_user, :room_id => params[:id], :content=>params[:comment_text])
			elsif  params[:choice] == 'link'
   		  post = Post.create(:user =>current_user, :room_id => params[:id], :link=>params[:link])
			elsif   params[:choice] == 'image'
   		  post = Post.create(:user =>current_user, :room_id => params[:id])
			  post.attachments << Attachment.new(:uploaded_data=>params[:attach][:image_attachment])
			elsif   params[:choice] == 'video'
				if  params[:embed_video] && ! params[:embed_video].empty?
					  	if params[:embed_video].include? 'value="http://'
								embed_video=params[:embed_video]
								embed_video=embed_video.match /(.+)http:(.+)/
								embed_video=embed_video.captures[1].inspect	 
								embed_video=embed_video.split(/"/)
								video="http:"+embed_video[1].to_s
						    post = Post.create(:user =>current_user, :room_id => params[:id],:embed_video=>video)	
							  attachment=Attachment.create(:attachable_id=>post.id,:attachable_type=>"Post",:content_type=>"embed_video")
						end
				elsif params[:attach] && params[:attach][:video_attachment] && !params[:attach][:video_attachment].blank? 
				post = Post.create(:user =>current_user, :room_id => params[:id])				
				post.attachments << Attachment.new(:uploaded_data=>params[:attach][:video_attachment])
				end
			elsif   params[:choice] == 'document'
   		  post = Post.create(:user =>current_user, :room_id => params[:id])
			  post.attachments << Attachment.new(:uploaded_data=>params[:attach][:document_attachment])
			end
	  end
	  redirect_to room_path(params[:id]) and return
  end
	
	def download
 		#post = Post.find(params[:id])
		attachment = Attachment.find(params[:id])
		send_file("#{RAILS_ROOT}/public"+attachment.public_filename, :type=>attachment.content_type, :disposition => 'disposition')
	end
	
	def reply
		commentable = Post.find(params[:id])		
    comment = commentable.comments.create( :comment => params[:reply], :user_id=>current_user.id)
		ReplyNotifier.deliver_post_reply_notification(comment, commentable)
	end
  
  def send_feedback		
  from = params[:email] 
	 message = params[:message]
	 sender_name = params[:name]
	 room = Room.find(params[:id])
   ReplyNotifier.deliver_post_feedback_notification(from, message, sender_name, room)
	 flash[:notice] = "Your feedback has been successfully send to admin"
   redirect_to rooms_path
  end
  
	def send_post_feedback		
  from = params[:email] 
	 message = params[:message]
	 sender_name = params[:name]
	 p = Post.find(params[:id])
   #ReplyNotifier.deliver_post_feedback_message_notification(from, message, sender_name, p)
 	 flash[:error] = "Your feedback has been successfully send to admin"
   redirect_to(room_path(p.room))
  end
	
  def destroy
    @post = Post.find(params[:id])
    @post.destroy
    flash[:notice] = "Post deleted successfully"    
    respond_to do |format|
      format.html { redirect_to(dashboard_path) }
      format.xml  { head :ok }
    end
  end
	
	def rating_for_post
		 if !current_user.nil?
			post = Post.find(params[:id])
			post.rate(params[:rate], current_user)
			average_for_room(post)
			render :update do |page|
				page.replace_html "thumb_image_#{post.id}", :partial=>'thumbs_display', :locals=> {:post=>post, :check=>true}
				page.replace_html "rating_flash_#{post.id}", :partial=>'message'
			end	
		else
			render :update do |page|
				page.redirect_to login_path
			end	
			
		end
	end
  
	
end
