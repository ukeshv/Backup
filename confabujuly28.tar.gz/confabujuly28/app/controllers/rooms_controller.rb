class RoomsController < ApplicationController
  layout "users", :except=>['new', 'edit']
  protect_from_forgery :except=>['update','create','upgrades_update','protect_room','chat_room_messages']
	before_filter :login_status,:login_required ,:only=>[:join, :exit_room, :protect_room]
  
  def index
		
		conditions = "((expiry_date > '#{Date.today.to_formatted_s(:db)}' OR expiry_date is NULL) AND ((is_class_room=1 AND is_class_room_verified=1) OR (is_class_room=0 AND is_class_room_verified=0)))" if params[:order] != "my_room"   	
		
    recent_rooms_conditions = "(category_id is NOT NULL)"
		
		recent_rooms_conditions += " AND ((expiry_date > '#{Date.today.to_formatted_s(:db)}' OR expiry_date is NULL)) AND ((is_class_room=1 AND is_class_room_verified=1) OR (is_class_room=0 AND is_class_room_verified=0))"  if params[:order] != "my_room"
    
		#UGLY UGLY collections for left side navigation
		@categories = Category.all(:order=>'name')
		@recent_rooms = Room.all(:conditions=>recent_rooms_conditions, :order=>'created_at DESC', :limit=>5)
		@popular_rooms = Room.all(:conditions=>conditions, :order=>'ratings DESC', :limit=>5)		
		
		if params[:order] && params[:order]=='my_room'
			order = 'created_at DESC'
			@rooms = current_user.rooms.paginate(:conditions=>conditions, :order=>order, :page=>params[:page] || 1, :per_page=>10)			
		else
      #conditions += " AND (title LIKE '%#{params[:q]}%' OR description Like '%#{params[:q]}%')" if params[:q]
			conditions += " AND (title LIKE '%#{params[:q]}%')" if params[:q]
			#order = 'title'
			order = 'created_at DESC'
			order = 'created_at DESC' if params[:order] && params[:order]=='recent'
			conditions =recent_rooms_conditions if params[:order] && params[:order]=='recent'
			order = 'ratings DESC' if params[:order] && params[:order]=='popular'        
			@rooms =  Room.paginate(:conditions=>conditions, :order=>order, :page=>params[:page] || 1, :per_page=>10)
		end
  end
  
  def new
    @categories = Category.find(:all)
    @room = Room.new
  end
	
  def create
    
    @categories = Category.find(:all)
    @room = Room.new(params[:room])
    @room.check_status = 1
    if @room.is_class_room == true
      @room.check_status = 2
      @room.category_id = 2
      @room.title=params[:room][:school]+" "+params[:room][:class_name]+" "+"by"+" "+params[:room][:teacher]
    end
	  flag=true
    default_room_setting = RoomSetting.first
    if current_user
      @room.expiry_date = Date.current + default_room_setting.default_room_life_time.to_i
    else
      @room.expiry_date = Date.current + default_room_setting.default_expiry_days.to_i
    end
    @room.total_storage_size = default_room_setting.default_storage_size.to_i
    @room.total_user_limit =  default_room_setting.default_max_users.to_i
    if params[:room] && params[:room][:email] && !params[:room][:email].empty? && params[:room][:email].length >=6
      email_name = '[\w\.%\+\-]+'
      domain_head = '(?:[A-Z0-9\-]+\.)+'
       domain_tld ='(?:[A-Z]{2}|com|org|net|edu|gov|mil|biz|info|mobi|name|aero|jobs|museum)'
      email_ok = /\A#{email_name}@#{domain_head}#{domain_tld}\z/i
        if params[:room][:email].match(email_ok).nil?
         flag=false
        end  
      end
      
     if flag
    if @room.save
        if current_user
          @room_user = RoomUser.create!(:user_id => current_user.id, :room_id =>@room.id, :is_owner =>true)
        else
          @room_user = RoomUser.create!(:room_id =>@room.id, :is_owner =>false)
        end
        if @room.is_class_room
           RoomNotifier.deliver_send_verification_code(@room)
        end
        flash[:notice] = "New Room Created Successfully"
        render :update do |page|
          if @room.school==""
            page.redirect_to show_room_path(@room.title_url.to_s)
          else
            page.redirect_to show_room_path(@room.title_url.to_s)
          end
        end
      else	
        show_hide_error_messages(@room,'room')
      end
    else
      render :update do |page|
        page.show "email_room"
       page.replace_html "email_room", :text=>"email invalid format"
     end
    end
  end 
  
  def show_hide_error_messages(obj,replacing_id)
		render :update do |page|
      for h in obj.errors.entries
        if !obj.errors["#{h[0]}"].nil?
          if "#{h[0]}" == "room"
          else
            page.show "#{h[0]}_" +  replacing_id
            page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
          end
        end
        page.hide "title_"+ replacing_id if obj.errors["title"].nil?
        page.hide "description_"+ replacing_id if obj.errors["description"].nil?
        page.hide "category_id_"+ replacing_id if obj.errors["category_id"].nil?
        page.hide "email_"+ replacing_id if obj.errors["email"].nil?
        page.hide "school_"+ replacing_id if obj.errors["school"].nil?
        page.hide "teacher_"+ replacing_id if obj.errors["teacher"].nil?
        page.hide "class_name_"+ replacing_id if obj.errors["class_name"].nil?
      end
		end
  end
  
  
  def show
		session[:last_saved_id] = nil #assigning nil to session .this session is related to chat box messages id
    conditions = "(expiry_date > '#{Date.today.to_formatted_s(:db)}' OR expiry_date is NULL)"
    #UGLY UGLY collections for left side navigation
    
      recent_rooms_conditions = "((expiry_date > '#{Date.today.to_formatted_s(:db)}' OR expiry_date is NULL) AND ((is_class_room=1 AND is_class_room_verified=1) OR (is_class_room=0 AND is_class_room_verified=0)) AND (category_id is NOT NULL))"
      
    @categories = Category.all(:order=>'name')
    @recent_rooms = Room.all(:conditions=>recent_rooms_conditions, :order=>'created_at DESC', :limit=>5)
    @popular_rooms = Room.all(:conditions=>conditions, :order=>'ratings DESC', :limit=>5)
    if params[:title_url]
      @room = Room.find_by_title_url(params[:title_url])
    else
      @room = Room.find(params[:id])
    end
		render :action=>"invalid_room" and return  if @room.nil?
		@page_title = "Confabu - #{@room.title}"
		@meta_content = @room.description
    @posts = @room.posts if @room
    @chat_room_online_user = current_user ? ChatRoomOnlineUser.find(:first,:conditions=>["user_id=? and room_id=?",current_user.id, @room.id]) : ChatRoomOnlineUser.find(:first,:conditions=>["guest_name=? and room_id=?","Guest#{session[:current_chat_user]}", @room.id])
    if @chat_room_online_user
      @chat_room_online_user.update_attributes(:updated_at=>Time.now)
    else
      @chat_room_online_user = ChatRoomOnlineUser.create(:room_id=>@room.id, :user_id=>(current_user ? current_user.id : 0), :guest_name=>(current_user ? current_user.fullname : "Guest#{session[:current_chat_user]}"))
    end
    @chat_room_messages = @room.chat_room_messages.find(:all, :order=>'created_at ASC', :limit=>10)
    session[:chat_room_messages] = @chat_room_messages.length
    @chat_room_members = ChatRoomOnlineUser.find(:all, :conditions=>["id!=? and updated_at>=?", @chat_room_online_user.id, (Time.now-60)])
    if current_user
      if !@room.has_user?(current_user.id)
        if @room.is_private?
          render :action=>"check_room"
        end
      end
    else
      if @room.is_private?
        render :action=>"check_room"
      end
    end
  end

	def append_chat
		online_user = ChatRoomOnlineUser.find(params[:send])
		message = params[:message].strip if params[:message]
    if message && message.length > 0      
			render :update do |page|			
			page.insert_html :bottom,'chat_discussions', "<div class='chatitem clearfix'><div class='chatname' style='width:150px;' align='left'>#{online_user.guest_name}</div><div class='chatmsg' align='left'>
#{h(message)}</div><div class='chattime' style='width:100px;margin-top:-18px;' align='right'>#{Time.now.strftime('%I:%M:%S %p')}</div></div>"
			page.call 'focus'
		end
		user_name = current_user ? current_user.fullname : "Guest#{session[:current_chat_user]}"
		sent_msg = ChatRoomMessage.create(:room_id => online_user.room_id,:user_id => online_user.user_id,:guest_name =>user_name,:message => message)
		online_user.update_attributes(:updated_at=>Time.now) if online_user
    end		
	end	

  def chat_room_messages
    online_user = params[:send] || params[:id]
    @chat_room_online_user = ChatRoomOnlineUser.find(online_user)
    @room=Room.find(@chat_room_online_user.room_id)
    @chat_room_members = ChatRoomOnlineUser.find(:all, :conditions=>["id!=? and updated_at>=?", @chat_room_online_user.id, (Time.now-60)])
    @chat_room_members
		current_chat_user = current_user ? current_user.fullname : "Guest#{session[:current_chat_user]}"
		if session[:last_saved_id].nil?
			@chat_room_messages = @room.chat_room_messages.find(:all, :conditions=>['guest_name != ?',current_chat_user],:order=>'created_at ASC')
		else
			@chat_room_messages = @room.chat_room_messages.find(:all, :conditions=>['id > ? AND guest_name != ?',session[:last_saved_id],current_chat_user],:order=>'created_at ASC')
		end	
		session[:last_saved_id] = @chat_room_messages.last.id if !@chat_room_messages.last.nil?
    msg_length = @chat_room_messages.length
    if session[:chat_room_messages] != msg_length
      @open_chatbox = true
      session[:chat_room_messages] = msg_length
    end
    render :update do |page|
      page.insert_html :bottom,'chat_discussions', :partial=>'/rooms/updated_chat_window', :object => @chat_room_messages
			page.replace_html 'online_users', :partial=>'/rooms/online_users'
      page.call 'openChatWindow' if @open_chatbox
      page.call 'focus'      
      @open_chatbox = false
    end
  end

  def chat_room_messages1
    online_user = params[:send] || params[:id]
    @chat_room_online_user = ChatRoomOnlineUser.find(online_user)
    @room=Room.find(@chat_room_online_user.room_id)
    @chat_room_members = ChatRoomOnlineUser.find(:all, :conditions=>["id!=? and updated_at>=?", @chat_room_online_user.id, (Time.now-60)])
    @chat_room_members
    message = params[:message].strip if params[:message]
    if message && message.length > 0
      chat_room_message = ChatRoomMessage.new
      chat_room_message.room_id = @chat_room_online_user.room_id
      chat_room_message.user_id = @chat_room_online_user.user_id
      chat_room_message.guest_name = @chat_room_online_user.guest_name
      chat_room_message.message = message
      chat_room_message.save
      @chat_room_online_user.update_attributes(:updated_at=>Time.now) if @chat_room_online_user
      @clear_text = true
    end
    @chat_room_messages = @room.chat_room_messages.find(:all, :order=>'created_at ASC')
    msg_length = @chat_room_messages.length
    if session[:chat_room_messages] != msg_length
      @clear_text = true
      session[:chat_room_messages] = msg_length
    end
    render :update do |page|
      page.replace_html 'chat_window_expand', :partial=>'/rooms/updated_chat_window'
      page.call 'openChatWindow' if @clear_text
      page.call 'focus'      
      @clear_text = false
    end
  end
  
  
  def activate   
    room = Room.find_by_email_verification_code(params[:id]) unless params[:id].blank?
    case
    when (!params[:id].blank?) && room && !room.email_verification_code.nil?
     # room.do_activate
      room.update_attributes(:is_class_room_verified=>true,:email_verification_code=>"NULL")
      RoomNotifier.deliver_room_activation(room)
      flash[:notice] = "Class room verification completed!."
      redirect_to rooms_path
    when params[:id].blank?
      flash[:error] = "The verification code was missing.  Please follow the URL from your email."
      redirect_to rooms_path
    else 
      flash[:error]  = "We couldn't find a room with that verification code -- check your email? Or maybe you've already activated."
      redirect_to rooms_path
    end
  
  end

  def edit
    @categories = Category.find(:all)
    @room = Room.find(params[:id])
	end

  def update
		@room  = Room.find(params[:id])
		@room.update_attributes(params[:room])
		render :update do |page|
		  page.redirect_to room_path(@room)
		end
  end
  
  def delete
  end
  
  def protect_room		
    conditions = "(expiry_date > '#{Date.today.to_formatted_s(:db)}' OR expiry_date is NULL)"
     recent_rooms_conditions = "((expiry_date > '#{Date.today.to_formatted_s(:db)}' OR expiry_date is NULL) AND ((is_class_room=1 AND is_class_room_verified=1) OR (is_class_room=0 AND is_class_room_verified=0)) AND (category_id is NOT NULL))"
     
    @room = Room.find_by_id(params[:room])
    pwd = params[:pwd]
    @val = @room.authenticated?(pwd)
    @categories = Category.all(:order=>'name')
    @recent_rooms = Room.all(:conditions=>recent_rooms_conditions, :order=>'created_at DESC', :limit=>5)
    @popular_rooms = Room.all(:conditions=>conditions, :order=>'ratings DESC', :limit=>5)	
    if !@val
      flash[:message] = "Password incorrect. Please provide the correct password to visit the room"
      render :action=>"check_room"
    else
			RoomUser.find_or_create_by_user_id_and_room_id(:room_id=>@room.id, :user_id=>current_user.id)
      if @room.title_url
				redirect_to :action=>"show" , :title_url=>@room.title_url.to_s
			else
				redirect_to :action=>"show" , :id=>@room.id
	    end	
			flash[:message] = "You have successfully joined this room"  
    end    
	end
  
	def join		
		conditions = "(expiry_date > '#{Date.today.to_formatted_s(:db)}' OR expiry_date is NULL)"
    
    recent_rooms_conditions = "((expiry_date > '#{Date.today.to_formatted_s(:db)}' OR expiry_date is NULL) AND ((is_class_room=1 AND is_class_room_verified=1) OR (is_class_room=0 AND is_class_room_verified=0)) AND (category_id is NOT NULL))"
    
		@recent_rooms = Room.all(:conditions=>recent_rooms_conditions, :order=>'created_at DESC', :limit=>5)
    @popular_rooms = Room.all(:conditions=>conditions, :order=>'ratings DESC', :limit=>5)	
		@categories = Category.all(:order=>'name')
		if params[:title_url]
			@room = Room.find_by_title_url(params[:title_url])
		else
			@room = Room.find(params[:id])
		end
		if @room.is_private?					
			render :action=>"check_room"		
		else
			RoomUser.find_or_create_by_user_id_and_room_id(:room_id=>@room.id, :user_id=>current_user.id) 
			flash[:message] = "You have successfully joined this room"  
			redirect_to :action=>"show" , :title_url=>@room.title_url.to_s
		end
	end
	
  def check_room_for_user(room)
    
  end
  
  def upgrades
    if params[:id] =~ /^\d+$/
      @room = Room.find(params[:id])
    else
			@room = Room.find_by_title_url(params[:id])
    end
		@days_limit = 1
		@user_limit = 1
		@storage_limit =  1
		@price_setting = PriceSetting.find :first
		#render :layout=>'popup'
	end	

	def upgrades_update
		@room = Room.find(params[:id])
		@price_setting = PriceSetting.find :first
		
		@room_upgrade = RoomUpgrade.new
		@room_upgrade.room_id = @room.id
		@room_upgrade.user_id = current_user.id
		@room_upgrade.no_of_users = params[:additional_users].to_i
		@room_upgrade.additional_days = params[:additional_days].to_i
		@room_upgrade.storage_size = params[:additional_storage].to_i
		if @room_upgrade.valid?
			session[:additional_days] = params[:additional_days].to_i
			session[:additional_users] = params[:additional_users].to_i
			session[:additional_storage] = params[:additional_storage].to_i
			session[:total_amt] = ((session[:additional_days] * @price_setting.per_day) + (params[:additional_users].to_i * @price_setting.per_user) + (params[:additional_storage].to_i * @price_setting.per_GB_storage))		
		
			paypal_checkout
		else			
			flash[:message] = "provide valid details"
			render :action=> 'upgrades'
		end	
=begin
		@room = Room.find(params[:id])
		@price_setting = PriceSetting.find :first
		@room_upgrade = RoomUpgrade.new
		@room_upgrade.room_id = @room.id
		@room_upgrade.user_id = current_user.id
		@room_upgrade.no_of_users = params[:additional_users].to_i
		@room_upgrade.additional_days = params[:additional_days].to_i
		@room_upgrade.storage_size = params[:additional_storage].to_i
		if @room_upgrade.save
			@room_upgrade.update_attributes(:additional_days_amount=>@room_upgrade.additional_days*@price_setting.per_day,:additional_users_amount=>@room_upgrade.no_of_users*      @price_setting.per_user,:additional_storage_amount=>@room_upgrade.storage_size*@price_setting.per_GB_storage)
			@room.total_user_limit = @room.total_user_limit.to_i + params[:additional_users].to_i if params[:additional_users].to_i != 0
			@room.total_storage_size = @room.total_storage_size.to_i + params[:additional_storage].to_i if params[:additional_storage].to_i != 0
			@room.expiry_date = (@room.expiry_date ? @room.expiry_date.advance(:days=>params[:additional_days].to_i) : Date.current) if params[:additional_days].to_i != 0
			@room.save
			#render :update do |page|
			#	page.alert("saved")
			#end	
			flash[:message] = "Room Updated"
			redirect_to :action => 'show'
		else
			#render :update do |page|
			#	page.alert("provide valid details")
			#end	
			flash[:message] = "provide valid details"
			render :action=> 'upgrades'
		end	
=end
	end	
	
	def paypal_checkout
		session[:room] = @room
    setup_response = gateway.setup_purchase(session[:total_amt],
      :ip                => request.remote_ip,
      :return_url        => url_for(:action=>'confirm', :only_path => false),
      :cancel_return_url => url_for(:action => 'show', :id=>session[:room].id, :only_path => false)
    )
    redirect_to gateway.redirect_url_for(setup_response.token)    
	end
	
		
  def confirm    
    render :action => 'error' unless params[:token]
		if params[:token]
			details_response = gateway.details_for(params[:token])
				if !details_response.success?
					@message = details_response.message
					 render :action => 'error'
					 return
				end
			session[:address] = details_response.address
		end
  end

  def complete    
    purchase = gateway.purchase((session[:total_amt] * 100),
      :ip       => request.remote_ip,
      :payer_id =>params[:payer_id],
      :token    => params[:token]
    )
    
    if !purchase.success?
      @message = purchase.message
      render :action => 'error'
      return
    end
    
    if purchase.success?
			@price_setting = PriceSetting.find :first
			@room_upgrade = RoomUpgrade.new
			@room_upgrade.room_id = session[:room].id
			@room_upgrade.user_id = current_user
			@room_upgrade.no_of_users = session[:additional_users]
			@room_upgrade.additional_days = session[:additional_days]
			@room_upgrade.storage_size = session[:additional_storage]
			@room_upgrade.save
			@room_upgrade.update_attributes(:additional_days_amount=>@room_upgrade.additional_days * @price_setting.per_day,:additional_users_amount=>@room_upgrade.no_of_users*      @price_setting.per_user,:additional_storage_amount=>@room_upgrade.storage_size*@price_setting.per_GB_storage)
			
			@room = session[:room]
			@room.total_user_limit = @room.total_user_limit.to_i + params[:additional_users].to_i if params[:additional_users].to_i != 0
			@room.total_storage_size = @room.total_storage_size.to_i + params[:additional_storage].to_i if params[:additional_storage].to_i != 0
			@room.expiry_date = (@room.expiry_date ? @room.expiry_date.advance(:days=>params[:additional_days].to_i) : Date.current) if params[:additional_days].to_i != 0
			@room.save
			
			@payment = Payment.new
			@payment.room_id=session[:room]
			@payment.transaction_id=purchase.params["transaction_id"]
			@payment.transaction_type=purchase.params["transaction_type"]
			@payment.amount = purchase.params["gross_amount"].to_f
			@payment.user_id = current_user			
			@payment.responses=purchase
			@payment.name  = session[:address]['name']
			@payment.address  = session[:address]['address1']
			@payment.city  = session[:address]['city']
			@payment.state  = session[:address]['state']
			@payment.country  = session[:address]['country']
			@payment.zip  = session[:address]['zip']
			@payment.save!
			
      flash[:message] = "Payment Successful.."
			redirect_to room_path(@room.id)
      
			session[:additional_days] = nil
			session[:additional_users] = nil
			session[:additional_storage] = nil
			session[:total_amt] = nil
			session[:address] = nil
			session[:room] = nil
		end
	end
	
	def error
		session[:additional_days] = nil
		session[:additional_users] = nil
		session[:additional_storage] = nil
		session[:total_amt] = nil
		session[:address] = nil
		session[:room] = nil
	end
	
	def exit_room
		room = Room.find(params[:id])
		room_user = RoomUser.find(:first, :conditions=>['user_id=? and room_id=?',current_user.id, params[:id]])
		if room_user
			RoomUser.delete(room_user.id)
			flash[:message] = "You are successfully exited from the room '#{room.title}'"
		end
		redirect_to "/rooms?order=my_room" 
	end
	
  def room_new
    room = Room.new()
    room.title = params[:room]
    room.expiry_date = room_expiry_date
    if room.save
      redirect_to show_room_path(room.title_url.to_s)
    else
      redirect_to '/'
      flash[:error] = "Room Name Already Exists."
    end

  end

	def destroy
	    @room = Room.find(params[:id])
			if @room
	    @room.destroy
	    flash[:message] = "Room deleted successfully"    
	    respond_to do |format|
	      format.html { redirect_to "/rooms?order=my_room" }
	      format.xml  { head :ok }
       end
		end
	end
end
