module Admin::RoomsHelper
end
