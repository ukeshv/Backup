module ApplicationHelper
  
  # Sets the page title and outputs title if container is passed in.
  # eg. <%= title('Hello World', :h2) %> will return the following:
  # <h2>Hello World</h2> as well as setting the page title.
  
    def facebook_session
      session[:facebook_session]
    end

  def facebook_user
    (session[:facebook_session] && session[:facebook_session].session_key) ? session[:facebook_session].user : nil
  end
  
  #~ def fb_connected?
   #~ (session[:connect] ? true : false)
#~ end
#Temporarily commented for login issue ticket no 2918
  #def title(str, container = nil)
    #@page_title = str
    #content_tag(container, str) if container
  #end
  
  # Outputs the corresponding flash message if any are set
  def flash_messages
    messages = []
    %w(notice warning error).each do |msg|
      messages << content_tag(:span, html_escape(flash[msg.to_sym]), :class=>"#{msg}") unless flash[msg.to_sym].blank?
    end
    messages
  end
  
	def formated_time(createdTime)
    updated_date=createdTime.to_date
    today_date=Date.today.to_date
    if (updated_date==today_date)      
      updated_time=createdTime.to_time
      time=Time.now
      sec=time-updated_time
      if(sec<60)
        return sec.to_i.to_s+" seconds ago"
      end      
      min=(sec/60).to_i
      if(min<60)
        return min.to_i.to_s+" minutes ago"
      else
        hrs=(min/60).to_i
        return hrs.to_i.to_s+" hours ago"
      end      
    else
      now=Date.today.to_time
      up_time=createdTime.to_time
      diff=now-up_time
      hrs=diff/(60*60)
      if((hrs.to_i)>24)
        days=hrs.to_i/24
        return days.to_s+" days ago"
      else              
        return hrs.to_i.to_s+" hours ago"
      end
    end    
  end  
	
end
