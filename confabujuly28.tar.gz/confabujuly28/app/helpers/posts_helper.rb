module PostsHelper

	def is_user_rated(post_id)
  	return false if !current_user
		post_ids = Post.find_rated_by(current_user).collect{|p|  p.id }
		return true if post_ids.include?(post_id)
		return false 
	end

end
