module RoomsHelper

	 def room_space(room)
			size = []
			room.posts.each do |p|
				 atts = p.attachments
				 atts.each do |att|
						size << att.size
					end	
			 end	 
			 total_byte = size.sum
			 total_kb = total_byte/1024
			 total_mb = total_kb/1024
			 return total_kb.to_f
	 end


end
