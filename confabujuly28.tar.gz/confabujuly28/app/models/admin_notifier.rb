class AdminNotifier < ActionMailer::Base
    def post_message_notification(name, email,post)  	
    @recipients =  APP_CONFIG[:admin_email]    
    @sender=name
   	@from = email
    @subject = '[Confabu] Contact us'
    @message= post        
    @content_type = "text/html"   
  end


end
