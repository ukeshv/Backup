class Attachment < ActiveRecord::Base
  has_attachment :content_type => ['application/pdf', 'application/msword', 'text/plain','image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg'],
	:storage => :file_system,
:resize_to => '320x200>',
:thumbnails => {:thumb => '48X48'},
:path_prefix => 'public/attachments',
:min_size => 0.kilobytes,
:max_size => 10.megabytes,
:processor => :rmagick
  belongs_to :attachable,:polymorphic=>true
	after_save :save_thumbnail
  
  # TO DO - This after save method need to run only for images not for all uploads.
  #after_save :save_thumbnail

	def save_thumbnail
	    require 'RMagick'
			if content_type && !content_type.empty? && content_type.split('/')[0]=="image"
	    @photo=self
	    if @photo
	      begin
	      maxw =  120
	      maxh =  80
	      aspectratio = maxw.to_f / maxh.to_f
	      pic = Magick::Image.read(RAILS_ROOT + "/public#{self.public_filename}").first
	      picw = @photo.width
	      pich = @photo.height
	      picratio = picw.to_f / pich.to_f 
	      if picratio > aspectratio then
		scaleratio = maxw.to_f / picw
	      else
		scaleratio = maxh.to_f / pich
		end

		thumb = scaleratio < 1 ? pic.resize(48,48) : pic
		temp_path=(RAILS_ROOT + "/public/#{self.public_filename(:thumb)}")
		FileUtils.mkdir_p(File.dirname(temp_path))
		thumb.write(temp_path)
	      rescue
		logger.info "Thumbnail cannot be generated"
	      end
	    end
	    end
	  end

end
