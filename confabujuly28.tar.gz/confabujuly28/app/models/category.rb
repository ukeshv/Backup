class Category < ActiveRecord::Base
  has_many :rooms
  has_many :notes
  
	validates_presence_of :name, :message=>'Provide Category Name'
	validates_uniqueness_of :name,:message=>'Name already used.Provide different name'
end
