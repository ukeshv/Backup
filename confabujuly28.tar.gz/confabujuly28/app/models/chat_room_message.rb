class ChatRoomMessage < ActiveRecord::Base
  belongs_to :room
end
