class ChatRoomOnlineUser < ActiveRecord::Base
  belongs_to :room
end
