class Comment < ActiveRecord::Base

  include ActsAsCommentable::Comment

  belongs_to :commentable, :polymorphic => true

  # NOTE: install the acts_as_votable plugin if you
  # want user to vote on the quality of comments.
  #acts_as_voteable

  # NOTE: Comments belong to a user
  belongs_to :user
=begin
	def owner_image
    self.user.attachments.first.public_filename rescue '/images/pic_thumbconfabu.gif'
  end
=end
  
    def owner_image
		if self.user
			if self.user.attachments.length > 0
				if File.exists? RAILS_ROOT + "/public#{self.user.attachments.last.public_filename(:thumb)}"
					self.user.attachments.last.public_filename(:thumb) rescue '/images/pic_thumbconfabu.gif'
				else
				'/images/pic_thumbconfabu.gif'
				end  
		  else
			 '/images/pic_thumbconfabu.gif'
		  end
    else
			 '/images/pic_thumbconfabu.gif'
		 end
    #self.user.attachments.last.public_filename(:thumb) rescue '/images/pic_thumb2.jpg'
  end
  def owner_name
    self.user.fullname rescue 'Guest'
  end

end