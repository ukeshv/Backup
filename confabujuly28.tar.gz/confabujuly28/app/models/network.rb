class Network < ActiveRecord::Base
belongs_to :user

NETWORK_TYPE = [[ 'Facebook', 'Facebook'],
    [ 'Twitter', 'Twitter']].freeze
		
end
