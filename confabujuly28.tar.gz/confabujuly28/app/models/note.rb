class Note < ActiveRecord::Base
  belongs_to :post
  belongs_to :user
  belongs_to :category
  has_many :attachments, :as => :attachable,:dependent => :destroy
  belongs_to :attachable,:polymorphic=>true
  
	before_save :cleanup
	
  def owner_image
    self.user.attachments.first.public_filename(:thumb) rescue '/images/pic_thumbconfabu.gif'
  end
	
	def cleanup
		self.content = nil if self.content.to_s.empty?
		self.link = nil if self.link.to_s.empty?
	end
	
end
