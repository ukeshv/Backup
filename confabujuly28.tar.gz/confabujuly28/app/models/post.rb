class Post < ActiveRecord::Base
  belongs_to :room
  belongs_to :user
  has_many :attachments, :as => :attachable,:dependent => :destroy
  belongs_to :attachable,:polymorphic=>true
  has_many :notes
	
	acts_as_rated
	acts_as_commentable
  
	def link
		if self[:link] && !self[:link].empty? && !self[:link].include?("http://")
			"http://#{self[:link]}"
		else
			self[:link]
		end
	end
	
  def owner_image
		if self.user
			if self.user.attachments.length > 0
				if File.exists? RAILS_ROOT + "/public#{self.user.attachments.last.public_filename(:thumb)}"
					self.user.attachments.last.public_filename(:thumb) rescue '/images/pic_thumbconfabu.gif'
				else
				'/images/pic_thumbconfabu.gif'
				end  
		  else
			 '/images/pic_thumbconfabu.gif'
		  end
    else
			 '/images/pic_thumbconfabu.gif'
		 end
    #self.user.attachments.last.public_filename(:thumb) rescue '/images/pic_thumb2.jpg'
  end
  
  def owner_name
    self.user.fullname.to_s.titleize rescue 'Guest'
  end
  
	def copied?
		Note.find(:first, :conditions=>['user_id= ? and post_id = ?', self.user.id, self.id])
	end
	
  
end
