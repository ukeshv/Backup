class PriceSetting < ActiveRecord::Base

#validations
validates_presence_of :per_day,:message=>"Provide Per Day Price"
validates_presence_of :per_GB_storage,:message=>"Provide Per GB Storage Price"
validates_presence_of :per_user,:message=>"Provide Per User Price"

#~ validates_format_of :per_day,:with=> /^\d+(\.\d{2})?$/,:message=>"Provide valid Per Day Price"
#~ validates_format_of :per_GB_storage,:with=> /^\d+(\.\d{2})?$/,:message=>"Provide valid Per GB Storage Price"
#~ validates_format_of :per_user,:with=> /^\d+(\.\d{2})?$/,:message=>"Provide valid Per User Price"

#price setting regulr ar exp need to add

end
