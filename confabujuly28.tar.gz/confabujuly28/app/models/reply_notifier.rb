class ReplyNotifier < ActionMailer::Base	
	 
	def post_reply_notification(comment, post)  		
    @recipients = post.user.email
		@from = comment.user.email
    @subject = '[Confabu] New Reply for the post - '+ post.content
		@body[:comment]= comment        
		@body[:post]= post        
    @content_type = "text/html"   
  end
	
  def post_feedback_notification(from, message, sender_name, room)		
    @recipients = APP_CONFIG[:admin_email] 
		@from = from
    @subject = '[Confabu] New feedback for the post - '#+ post.content
		@body[:message]= message        
		@body[:sender]= sender_name        
		@body[:room]= room
    @content_type = "text/html"   
  end
	
  def post_feedback_message_notification(from, message, sender_name, post)		
    @recipients = APP_CONFIG[:admin_email] 
		@from = from
    @subject = '[Confabu] New feedback for the post - '#+ post.content
		@body[:message]= message        
		@body[:sender]= sender_name        
		@body[:post]= post
    @content_type = "text/html"   
  end
	
end
