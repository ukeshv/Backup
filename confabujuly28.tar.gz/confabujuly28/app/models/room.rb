require 'digest/sha1'

class Room < ActiveRecord::Base
  include Authentication
  
  has_many :room_upgrades
  has_many :posts, :dependent=>:destroy
  belongs_to :category
  has_many :users,:through => :room_users
  has_many :room_users,  :dependent=>:destroy
  has_many :chat_room_messages
  has_many :chat_room_online_users
  has_many :payments
  
  attr_accessor :check_status
  attr_accessor :password, :password_confirmation
  
  validates_presence_of :title,:if => Proc.new { |user| user.validate_signup?(1) }
  validates_length_of :title, :maximum => 100,:if => Proc.new { |user| user.validate_signup?(1) }
  validates_uniqueness_of :title,:if => Proc.new { |user| user.validate_signup?(1) }

  validates_presence_of :description ,:if => Proc.new { |user| user.validate_signup?(1) }
  validates_presence_of :category_id ,:if => Proc.new { |user| user.validate_signup?(1) }
        
  validates_presence_of     :password,                   :if => :password_required? , :if => :check_private? 
  validates_presence_of     :password_confirmation,      :if => :password_required? , :if => :check_private? 
  validates_confirmation_of :password,                   :if => :password_required? , :if => :check_private? 
  validates_length_of       :password, :within => 6..40, :if => :password_required? , :if => :check_private?

  validates_presence_of :email, :if => :check_class?
  validates_length_of :email, :within => 6..100, :if => :check_class?
  #validates_format_of :email, :with => RE_EMAIL_OK, :message => MSG_EMAIL_BAD
  
  validates_presence_of :school, :if => :check_class? 
  validates_presence_of :teacher, :if =>:check_class? 
  validates_presence_of :class_name, :if =>:check_class?
  
  before_save :encrypt_password, :if=> :check_private?
  before_save :make_activation_code, :if =>:check_class?
  
  before_save :update_title_url
  
  def validate_signup?( step1 )          
    if (check_status == step1)
      return true
    else
      return false
    end
  end  

  def title
    self[:title]  ||=  "No Title"
  end
  
  def update_title_url
    if self.title_changed? || self.new_record?
      self.title_url = new_title_url = (self.title.to_s.strip.downcase.gsub(/[^a-zA-Z 0-9]/, "")).gsub(/[\s _]/,'-')
      while Room.first(:conditions=>["title_url = ? and id != ?", new_title_url, self.id.to_i])
				count ||= 0
        new_title_url = "#{self.title_url}#{count+=1}"
      end
      self.title_url = new_title_url
    end
  end
  
  
  def check_class?
    if is_class_room?    
      return true
    else
      return false
    end
  end
  
  def check_private?
    if is_private?   
      return true
    else
      return false
    end
  end
  
  # Encrypts the password with the user salt
  def encrypt(password)
    self.password_digest(password, salt)
  end
      
  def authenticated?(password)
    crypted_password == encrypt(password)
  end
      
  # before filter
  def encrypt_password
    return if password.blank?
    self.salt = self.class.make_token if new_record?
    self.crypted_password = encrypt(password)
  end
  def password_required?
    crypted_password.blank? || !password.blank?
  end
      
  def password_digest(password, salt)
    digest = REST_AUTH_SITE_KEY
    REST_AUTH_DIGEST_STRETCHES.times do
      digest = secure_digest(digest, salt, password, REST_AUTH_SITE_KEY)
    end
    digest
  end
      
  def secure_digest(*args)
    Digest::SHA1.hexdigest(args.flatten.join('--'))
  end
  
  #TODO it should be converted as an association
  def owner
    for room_user in self.room_users
      return room_user.user if room_user.is_owner
    end
    return nil
  end
  
  def do_activate
    self.is_class_room_verified = true
    self.email_verification_code = "NULL"

  end
  
  #TODO it should be converted as an association
  def owner
    for room_user in self.room_users
      return room_user.user if room_user.is_owner
    end
    return nil
  end
  
  def has_user?(userid)
    RoomUser.find(:first, :conditions=>['user_id= ? and room_id = ?', userid, self.id ])
  end
  
  def has_owner?(userid)
    RoomUser.find(:first, :conditions=>['user_id= ? and room_id = ? and   is_owner = ?', userid, self.id, true ])    
  end
  
  def owner_image
    room_owner = RoomUser.find(:first, :conditions=>['room_id = ? and   is_owner = ?',self.id, true ])    
    # room_owner.user.attachments.first.public_filename(:thumb) rescue '/images/pic_thumb2.jpg'
    if !room_owner.nil?
      if File.exists? RAILS_ROOT + "/public#{room_owner.user.attachments.last.public_filename(:thumb) rescue '/images/pic_thumbconfabu.jpg'}"
        room_owner.user.attachments.last.public_filename(:thumb) rescue '/images/pic_thumbconfabu.jpg'
      else
        '/images/pic_thumbconfabu.gif'
      end 
    else
      '/images/pic_thumbconfabu.gif'
    end
  end
  
  def generate_code
    Digest::SHA1.hexdigest("--#{Time.now.to_s}--").first(8)  
  end

  def self.expiry_date_delete
    @rooms = Room.find(:all,:conditions=>['expiry_date is not NULL'])
    if (!@rooms.empty?)
      for room in @rooms          
        room.destroy if (room.expiry_date == Date.today && room.users.empty?)
      end  
    end  
  end  

  
  protected
    
  def make_activation_code
    self.email_verification_code = self.class.make_token
  end
  
end
