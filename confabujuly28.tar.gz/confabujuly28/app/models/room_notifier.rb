class RoomNotifier < ActionMailer::Base
    def send_verification_code(room)
    setup_email(room)
    @subject << 'Please activate your new room'
    @body[:url] = "#{APP_CONFIG[:site_url]}/rooms/activate/#{room.email_verification_code}"
  end
  
  def room_activation(room)
    setup_email(room)
    @subject << 'Your room has been activated'
    #@body[:url] = "#{APP_CONFIG[:site_url]}/rooms/activate/#{room.email_verification_code}"
  end
  
    protected
  
  def setup_email(room)
    @recipients = "#{room.email}"
    @from = APP_CONFIG[:admin_email]
    @subject = "[#{APP_CONFIG[:site_name]}] "
    @sent_on = Time.now
    @body[:room] = room
  end
  
 

end
