class RoomSetting < ActiveRecord::Base
	
#validations
validates_presence_of :default_expiry_days,:message=>"Provide Default Expiry Days"
validates_presence_of :default_room_life_time,:message=>"Provide Default Room Life Time"
validates_presence_of :default_storage_size,:message=>"Provide Default Storage Size"
validates_presence_of :default_max_users,:message=>"Provide Default Max Users"

validates_numericality_of :default_expiry_days,:message=>"Provide a valid number"
validates_numericality_of :default_room_life_time,:message=>"Provide a valid number"
validates_numericality_of :default_storage_size,:message=>"Provide a valid number"
validates_numericality_of :default_max_users,:message=>"Provide a valid number"
end
