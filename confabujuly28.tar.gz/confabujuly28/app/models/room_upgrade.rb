class RoomUpgrade < ActiveRecord::Base
  belongs_to :room
  belongs_to :user
  
  #Validations
  validates_numericality_of :no_of_users,:message=>"Provide valid No of users"
  validates_numericality_of :storage_size,:message=>"Provide valid Storage Size"
  validates_numericality_of :additional_days,:message=>"Provide valid no of days"


 def after_save
   
 end
 
end
