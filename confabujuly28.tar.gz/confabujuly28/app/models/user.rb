require 'digest/sha1'

class User < ActiveRecord::Base
  include Authentication
  include Authentication::ByPassword
  include Authentication::ByCookieToken
  include Authorization::AasmRoles

  # Validations
  #~ validates_presence_of :login, :if => :not_using_openid?
  #~ validates_length_of :login, :within => 3..40, :if => :not_using_openid?
  #~ validates_uniqueness_of :login, :case_sensitive => false, :if => :not_using_openid?
  #~ validates_format_of :login, :with => RE_LOGIN_OK, :message => MSG_LOGIN_BAD, :if => :not_using_openid?
  validates_presence_of :fullname, :if => :not_using_openid? 
  validates_format_of :fullname, :with => RE_NAME_OK, :message => MSG_NAME_BAD, :allow_nil => true
  validates_length_of :fullname, :maximum => 100
  validates_presence_of :email, :if => :not_using_openid? 
  validates_length_of :email, :within => 6..100, :if => :not_using_openid? 
  validates_uniqueness_of :email, :case_sensitive => false, :if => :not_using_openid?
  validates_format_of :email, :with => RE_EMAIL_OK, :message => MSG_EMAIL_BAD, :if => :not_using_openid?
  validates_uniqueness_of :identity_url, :unless =>:using_facebook? , :if => :using_openid?
  validate :normalize_identity_url, :unless => :using_facebook?
  
  #validates_presence_of :password, :message=>"Password can't be blank", :if => :not_using_openid?
  #validates_presence_of :password_confirmation, :message=>"Password Confirmation can't be blank",  :if => :not_using_openid?
  #validates_length_of :password, :too_short=>"Password must be 6 to 40 characters",:too_long=>"Password must be 6 to 40 characters", :within => 6..40, :if => :not_using_openid?
  #validates_confirmation_of :password, :message=>"Password mismatch", :if => :not_using_openid?
  
  
  
  # Relationships
  #has_and_belongs_to_many :roles
  has_many :rooms, :through =>:room_users
  has_many :room_users
  has_many :room_upgrades
  has_one :user_notification
  has_one :user_setting
  has_many :attachments, :as => :attachable,:dependent => :destroy
  belongs_to :attachable,:polymorphic=>true
  has_many :networks
  has_many :posts
  has_many :notes
  has_many :users
	has_many :user_contacts
	has_many :payments

  before_save :cleanup
	after_create :add_user_settings
  # HACK HACK HACK -- how to do attr_accessible from here?
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  attr_accessible :login, :email, :name, :password, :password_confirmation, :identity_url, :fullname, :description

  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  def self.authenticate(login, password)
    u = find_in_state :first, :active, :conditions => { :email => login } # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end
  
	def fullname
		self[:fullname] || "Unknown"
	end
	
  # Check if a user has a role.
  def has_role?(role)
    list ||= self.roles.map(&:name)
    list.include?(role.to_s) || list.include?('admin')
  end
  
  # Not using open id
  def not_using_openid?
    identity_url.blank? && fb_user_id.blank?
  end
  
  def using_openid?
  !identity_url.blank?
  end
  
  
  def using_facebook?
    !fb_user_id.blank?
  end
  
  
  # Overwrite password_required for open id
  def password_required?
    new_record? ? not_using_openid? && (crypted_password.blank? || !password.blank?) : !password.blank?
  end
  
  
  def add_user_settings
    UserNotification.create!(:user_id=>self.id)
    UserSetting.create!(:user_id=>self.id)  
  end
  
  def user_image
    
    if self.attachments.length > 0
    if File.exists? RAILS_ROOT + "/public#{self.attachments.last.public_filename(:thumb)}"
      self.attachments.last.public_filename(:thumb) rescue '/images/pic_thumbconfabu.gif'
    else
      '/images/pic_thumbconfabu.gif'
    end  
    else
      '/images/pic_thumbconfabu.gif'
    end
    
    #self.attachments.last.public_filename(:thumb) rescue '/images/pic_thumbconfabu.gif'
  end
  
	def cleanup
		self.fullname = nil if self.fullname.to_s.strip.empty?
	end

  protected
    
  def make_activation_code
    self.deleted_at = nil
    self.activation_code = self.class.make_token
  end
  
  def normalize_identity_url
    self.identity_url = OpenIdAuthentication.normalize_url(identity_url) unless not_using_openid?
  rescue URI::InvalidURIError
    errors.add_to_base("Invalid OpenID URL")
  end
end
