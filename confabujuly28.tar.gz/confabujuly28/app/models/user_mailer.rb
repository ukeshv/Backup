class UserMailer < ActionMailer::Base
  def signup_notification(user)
    setup_email(user)
    @subject << 'Please activate your new account'
    @body[:url] = "#{APP_CONFIG[:site_url]}/activate/#{user.activation_code}"
  end
  
  def activation(user)
    setup_email(user)
    @subject << 'Your account has been activated!'
    @body[:url] = APP_CONFIG[:site_url]
  end
  
  def invite_mail(user,to_email,msg)
    setup_user_for_invite(user,to_email)
    @subject += "Invitation to join Cofabu"
    @body[:msg] = msg
    @body[:url] = APP_CONFIG[:site_url]    
  end
  
  protected
  
  def setup_user_for_invite(user,to_email)
    @recipients = "#{to_email}"
    @from = "#{user.email}"
    @subject = "[#{APP_CONFIG[:site_name]}] "
    @sent_on = Time.now
    @body[:user] = user
  end
  
  def setup_email(user)
    @recipients = "#{user.email}"
    @from = APP_CONFIG[:admin_email]
    @subject = "[#{APP_CONFIG[:site_name]}] "
    @sent_on = Time.now
    @body[:user] = user
  end
end
