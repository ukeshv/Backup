class UserNotification < ActiveRecord::Base
  belongs_to :user
end
