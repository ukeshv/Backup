class UserSetting < ActiveRecord::Base
  belongs_to :user
end
