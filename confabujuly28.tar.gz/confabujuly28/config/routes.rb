ActionController::Routing::Routes.draw do |map| 

   map.namespace(:admin) do |admin|
    admin.resources :settings
    admin.resources :categories
    admin.resources :rooms
  end
  
  #Admin Page routings
  map.admin_price_settings '/admin_price_settings', :controller => 'admin/settings', :action => 'price_settings'
  map.admin_price_settings_update '/admin_price_settings_update/:id', :controller => 'admin/settings', :action => 'price_settings_update'
  map.admin_room_settings '/admin_room_settings', :controller => 'admin/settings', :action => 'room_settings'
  map.admin_room_settings_update '/admin_room_settings_update/:id', :controller => 'admin/settings', :action => 'room_settings_update'
  map.admin_room_upgrades '/admin_room_upgrades/:id', :controller => 'admin/rooms', :action => 'upgrades'
  
  # Restful Authentication Rewrites
  map.logout '/logout', :controller => 'sessions', :action => 'destroy'
  map.login '/login', :controller => 'sessions', :action => 'new'
  map.register '/register', :controller => 'users', :action => 'create'
  map.profile '/profile', :controller => 'users', :action => 'edit'
  map.preferences '/preferences', :controller =>'users', :action=>'preferences'
  map.notifications '/notifications', :controller =>'users', :action=>'notifications'
  
  map.user_profiles '/user_profiles/:id', :controller => 'users', :action => 'user_profiles'
  
  map.signup '/signup', :controller => 'users', :action => 'new'
  map.activate '/activate/:activation_code', :controller => 'users', :action => 'activate', :activation_code => nil
  map.forgot_password '/forgot_password', :controller => 'passwords', :action => 'new'
  map.change_password '/change_password/:reset_code', :controller => 'passwords', :action => 'reset'
  map.open_id_complete '/opensession', :controller => "sessions", :action => "create", :requirements => { :method => :get }
  map.open_id_create '/opencreate', :controller => "users", :action => "create", :requirements => { :method => :get }
  #~ map.validate_recaptcha 'valid/:id', :controller => 'home', :action => 'validate_recaptcha'
  #~ map.secure 'secure/:id', :controller => 'home', :action => 'secure'
  map.chat 'chat_bind', :controller=>'rooms', :action => 'chat_room_messages', :requirements => { :method => :post }
  map.chat_bind 'chat_bind/:id', :controller=>'rooms', :action => 'chat_room_messages', :requirements => { :method => :post }
  map.append_chat 'append_chat/:id', :controller=>'rooms', :action => 'append_chat', :requirements => { :method => :post }
  
  
  # Restful Authentication Resources
  map.resources :users
  map.resources :passwords
  map.resource :session
  #map.resource :home, :controller => 'home'
  map.resources :rooms, :collection=>'protect_room', :member=>{:exit_room=>:delete}	
  #map.resources :home #, :collection=>'feedback'
  map.resources :notes, :member=>{:download=>:get, :copy_notes=>:get}
  map.resources :contacts
  map.resources :posts, :member=>{:download=>:get, :reply=>:post, :send_feedback=>:post,:send_post_feedback=>:post}	  
	map.other_rooms '/categories/others', :controller=>'categories', :action=>'show', :id=>nil
  map.room_new '/room/new',:controller=>'rooms',:action=>'room_new'
  map.resources :categories
  map.dashboard '/dashboard', :controller=>"home", :action=>"dashboard"
  map.admin '/admin', :controller=>"admins", :action=>"login"
 # map.feedback_post '/feedback', :controller=>"posts", :action=>"feedback"
  map.admin_logout '/admin_logout', :controller=>"admins", :action=>"logout"
  map.import '/import', :controller => "contacts", :action => "import"
  map.import_contacts '/import_contacts', :controller => "contacts", :action => "import_contacts"
	map.invite '/invite', :controller=>"contacts", :action => "invite"
	map.invite_contacts '/invite_contacts', :controller=>"contacts", :action => "invite_contacts"
	map.add_contacts '/add_contacts', :controller=>"contacts", :action => "add_contacts"
	map.add_as_contact '/add_as_contact/:id', :controller=>"contacts", :action => "add_as_contact"
  map.networks '/networks', :controller =>"contacts", :action=>"networks"
  map.network_delete '/network/:id', :controller => "contacts", :action => "network_delete"
  map.send_invite '/send_invite', :controller =>"contacts", :action=>"send_invite"
  map.contactus '/contactus', :controller =>"home", :action=>"message"
  map.post_rating '/posts/rating/:id/:rate', :controller =>"posts" ,:action=>'rating_for_post'
  
  # Home Page
  map.root :controller => 'home', :action => 'index'

  
  
  map.join_room '/join/:title_url', :controller=>'rooms', :action=>'join'
	map.show_room ':title_url', :controller=>'rooms', :action=>'show'
	map.confirm '/rooms/confirm/:id', :controller=>'rooms', :action=>'confirm'
    map.connect '/fb/:action', :controller => 'fb_connect'
	
  map.room_upgrade '/room_upgrade/:id', :controller=>'rooms', :action=>'upgrades'
  map.room_upgrade_update '/room_upgrade_update/:id', :controller=>'rooms', :action=>'upgrades_update'
  # Install the default routes as the lowest priority.
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
  
  #~ map.dime '/:id', :controller => 'home', :action => 'dime'
  
end
