class CreateRooms < ActiveRecord::Migration
  def self.up
    create_table :rooms do |t|
      t.string :title, :limit=>100
      t.string :title_url, :limit=>50
      t.text :description
      t.integer :category_id
      t.boolean :is_private, :default =>0
      t.string :crypted_password, :limit=>40
      t.string :salt, :limit=>40
      t.boolean :is_class_room, :default =>0
      t.string :email, :limit=>100
      t.string :school, :limit=>100
      t.string :teacher, :limit=>100
      t.string :class_name, :limit=>50
      t.string :section, :limit=>25
      t.string :email_verification_code, :limit=>40
      t.boolean :is_class_room_verified, :default =>0
      t.date :expiry_date
      t.integer :total_storage_size
      t.timestamps
    end
    add_index "rooms", :category_id
  end

  def self.down
    drop_table :rooms
  end
end
