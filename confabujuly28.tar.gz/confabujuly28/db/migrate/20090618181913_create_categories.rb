class CreateCategories < ActiveRecord::Migration
  def self.up
    create_table :categories do |t|
      t.string :name, :limit=>50
      t.text :description
      t.timestamps
    end
    Category.create!(:name => "Design", :description=>"Description about the design category")
    Category.create!(:name =>"Education", :description=>"Description about the education category")
    Category.create!(:name =>"Events", :description=>"Description about the events category")
    Category.create!(:name => "Finance", :description=>"Description about the finance category")
    Category.create!(:name => "Startups", :description=>"Description about the startups category") 
  end

  def self.down
    drop_table :categories
  end
end
