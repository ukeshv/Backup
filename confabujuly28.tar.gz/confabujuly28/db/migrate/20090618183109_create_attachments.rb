class CreateAttachments < ActiveRecord::Migration
  def self.up
    create_table :attachments do |t|
      t.integer :attachment_id
      t.string :attachment_type, :limit=>100
      t.string :content_type
      t.string :filename, :limit=>150
      t.string :thumbnail, :limit=>100
      t.integer :size
      t.integer :height, :limit=>5
      t.integer :width, :limit=>5
      t.timestamps
    end
  end

  def self.down
    drop_table :attachments
  end
end
