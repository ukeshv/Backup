class CreateRoomUsers < ActiveRecord::Migration
  def self.up
    create_table :room_users do |t|
      t.integer :room_id
      t.integer :user_id
      t.timestamps
    end
     add_index "room_users", :room_id
     add_index "room_users", :user_id
  end

  def self.down
    drop_table :room_users
  end
end
