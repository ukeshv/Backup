class CreateRoomUpgrades < ActiveRecord::Migration
  def self.up
    create_table :room_upgrades do |t|
      t.integer :room_id
      t.integer :user_id
      t.string :payment_type, :limit=>100
      t.integer :no_of_users
      t.integer :storage_size
      t.integer :additional_days
      t.integer :personal_storage
      t.timestamps
    end
    add_index "room_upgrades", :room_id
    add_index "room_upgrades", :user_id
  end

  def self.down
    drop_table :room_upgrades
  end
end
