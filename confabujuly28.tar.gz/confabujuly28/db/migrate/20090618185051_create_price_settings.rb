class CreatePriceSettings < ActiveRecord::Migration
  def self.up
    create_table :price_settings do |t|
      t.float :per_day
      t.float :per_GB_storage
      t.float :per_user
      t.timestamps
    end
    PriceSetting.create!(:per_day =>0.2, :per_GB_storage=>2.0, :per_user =>0.02)
  end

  def self.down
    drop_table :price_settings
  end
end
