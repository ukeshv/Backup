class CreateRoomSettings < ActiveRecord::Migration
  def self.up
    create_table :room_settings do |t|
      t.integer :default_expiry_days
      t.integer :default_room_life_time
      t.integer :default_storage_size
      t.integer :default_max_users
      t.timestamps
    end
    RoomSetting.create!(:default_expiry_days=>30,:default_room_life_time=>30, :default_storage_size =>1, :default_max_users =>50)
  end

  def self.down
    drop_table :room_settings
  end
end
