class CreateUserContacts < ActiveRecord::Migration
  def self.up
    create_table :user_contacts do |t|
      t.integer :user_id
      t.integer :contact_id
      t.boolean :is_block
      t.string :verification_code, :limit=>40
      t.boolean :is_verified
      t.timestamps
    end
    add_index "user_contacts", :user_id
  end

  def self.down
    drop_table :user_contacts
  end
end
