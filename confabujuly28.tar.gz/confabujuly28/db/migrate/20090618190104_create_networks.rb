class CreateNetworks < ActiveRecord::Migration
  def self.up
    create_table :networks do |t|
      t.integer :user_id
      t.string :username, :limit=>50
      t.string :encrypted_password, :limit=>50
      t.string :network_type, :limit=>20
      t.timestamps
    end
    add_index "networks", :user_id
  end

  def self.down
    drop_table :networks
  end
end
