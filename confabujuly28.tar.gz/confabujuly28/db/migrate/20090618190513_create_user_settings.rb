class CreateUserSettings < ActiveRecord::Migration
  def self.up
    create_table :user_settings do |t|
      t.integer :user_id
      t.boolean :block_new_friend_request, :default=>0
      t.boolean :show_only_subscribed_rooms, :default=>0
      t.boolean :hide_profile_from_search, :default=>0

      t.timestamps
    end
    add_index "user_settings", :user_id
  end

  def self.down
    drop_table :user_settings
  end
end
