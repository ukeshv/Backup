class CreateUserNotifications < ActiveRecord::Migration
  def self.up
    create_table :user_notifications do |t|
      t.integer :user_id
      t.boolean :reaches_maximum_capacity, :default =>1
      t.boolean :reaches_maximum_size, :default=>1
      t.boolean :reaches_expiry_date, :default=>1
      t.boolean :post_on_your_room, :default=>1
      t.boolean :friend_request , :default=>1
      t.boolean :replies_to_your_post, :default=>1
      t.timestamps
    end
    add_index "user_notifications", :user_id
  end

  def self.down
    drop_table :user_notifications
  end
end
