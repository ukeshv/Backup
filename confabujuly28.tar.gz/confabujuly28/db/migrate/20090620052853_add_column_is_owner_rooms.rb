class AddColumnIsOwnerRooms < ActiveRecord::Migration
  def self.up
    add_column :room_users, :is_owner, :boolean, :default=>false, :null=>false
  end

  def self.down
    remove_column :room_users, :is_owner
  end
end
