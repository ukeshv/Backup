class AddRatingsCoulumnRooms < ActiveRecord::Migration
  def self.up
    add_column :rooms, :ratings, :float, :default=>0, :null=>false
  end

  def self.down
    remove_column :rooms, :ratings	  
  end
end
