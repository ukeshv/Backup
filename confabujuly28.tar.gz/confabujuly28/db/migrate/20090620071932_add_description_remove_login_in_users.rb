class AddDescriptionRemoveLoginInUsers < ActiveRecord::Migration
  def self.up
    add_column :users, :description, :text
    remove_column :users, :login
  end

  def self.down
    remove_column :users, :description
    add_column :users, :login, :string
  end
end
