class ChangeColoumnmInAttahcment < ActiveRecord::Migration
  def self.up
		rename_column :attachments, :attachment_id, :attachable_id
		rename_column :attachments, :attachment_type, :attachable_type
  end

  def self.down
		rename_column :attachments, :attachable_id, :attachment_id
		rename_column :attachments, :attachable_type, :attachment_type 
  end
end
