class AddColumnsRoomUpgrades < ActiveRecord::Migration
  def self.up
    add_column :room_upgrades,:additional_days_amount,:float
    add_column :room_upgrades,:additional_storage_amount,:float
    add_column :room_upgrades,:additional_users_amount,:float
  end

  def self.down
    remove_column :room_upgrades,:additional_days_amount
    remove_column :room_upgrades,:additional_storage_amount
    remove_column :room_upgrades,:additional_users_amount
  end
end
