class AddIsLinkColumnInPost < ActiveRecord::Migration
  def self.up
		add_column :posts, :link, :string
		add_column :notes, :link, :string
  end

  def self.down
		remove_column :posts, :link
		remove_column :notes, :link
  end
end
