class AddUserLimitInRoom < ActiveRecord::Migration
  def self.up
    add_column :rooms, :total_user_limit, :integer
  end

  def self.down
    remove_column :rooms, :total_user_limit
  end
end
