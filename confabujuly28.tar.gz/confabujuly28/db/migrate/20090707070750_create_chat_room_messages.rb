class CreateChatRoomMessages < ActiveRecord::Migration
  def self.up
    create_table :chat_room_messages do |t|
      t.integer :room_id
      t.integer :user_id, :default=>0
      t.string :guest_name, :limit=>100, :default=>0
      t.string :message
      t.timestamps
    end
  end

  def self.down
    drop_table :chat_room_messages
  end
end
