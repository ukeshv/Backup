class CreateChatRoomOnlineUsers < ActiveRecord::Migration
  def self.up
    create_table :chat_room_online_users do |t|
      t.integer :room_id
      t.integer :user_id, :default=>0
      t.string :guest_name, :limit=>100, :default=>0
      t.timestamps
    end
  end

  def self.down
    drop_table :chat_room_online_users
  end
end
