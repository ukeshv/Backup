class AddEmbedVideoInNote < ActiveRecord::Migration
  def self.up
  add_column :notes, :embed_video, :text    
  end

  def self.down
  remove_column :notes, :embed_video
  end
end
