class AddEmbedVideoInPost < ActiveRecord::Migration
  def self.up
    add_column :posts, :embed_video, :text    
  end

  def self.down
  remove_column :posts, :embed_video
  end
end
