class CreatePayments < ActiveRecord::Migration
  def self.up
    create_table :payments do |t|
			t.integer :user_id
			t.integer :room_id
			t.float :amount
			t.string :transaction_id, :transaction_type
			
			#Details
			t.string :name, :address, :city, :state, :country, :zip			
			
      # Partial Credit Card 
      t.string :credit_card_mask, :limit => 4 
      t.string :expiration_month, :limit => 2
      t.string :expiration_year,  :limit => 4  
			
			t.text :responses 
      t.timestamps
    end
  end

  def self.down
    drop_table :payments
  end
end
