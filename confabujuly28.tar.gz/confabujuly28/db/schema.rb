# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20090718095108) do

  create_table "admins", :force => true do |t|
    t.string   "login",                     :limit => 40
    t.string   "fullname",                  :limit => 100, :default => ""
    t.string   "email",                     :limit => 100
    t.string   "crypted_password",          :limit => 40
    t.string   "salt",                      :limit => 40
    t.string   "remember_token",            :limit => 40
    t.string   "activation_code",           :limit => 40
    t.string   "state",                                    :default => "active", :null => false
    t.datetime "remember_token_expires_at"
    t.datetime "activated_at"
    t.datetime "deleted_at"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "attachments", :force => true do |t|
    t.integer  "attachable_id"
    t.string   "attachable_type", :limit => 100
    t.string   "content_type"
    t.string   "filename",        :limit => 150
    t.string   "thumbnail",       :limit => 100
    t.integer  "size"
    t.integer  "height",          :limit => 8
    t.integer  "width",           :limit => 8
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "categories", :force => true do |t|
    t.string   "name",        :limit => 50
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "chat_room_messages", :force => true do |t|
    t.integer  "room_id"
    t.integer  "user_id",                   :default => 0
    t.string   "guest_name", :limit => 100, :default => "0"
    t.string   "message"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "chat_room_online_users", :force => true do |t|
    t.integer  "room_id"
    t.integer  "user_id",                   :default => 0
    t.string   "guest_name", :limit => 100, :default => "0"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "comments", :force => true do |t|
    t.string   "title",            :limit => 50, :default => ""
    t.text     "comment"
    t.integer  "commentable_id"
    t.string   "commentable_type"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "comments", ["commentable_type"], :name => "index_comments_on_commentable_type"
  add_index "comments", ["commentable_id"], :name => "index_comments_on_commentable_id"
  add_index "comments", ["user_id"], :name => "index_comments_on_user_id"

  create_table "networks", :force => true do |t|
    t.integer  "user_id"
    t.string   "username",           :limit => 50
    t.string   "encrypted_password", :limit => 50
    t.string   "network_type",       :limit => 20
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "networks", ["user_id"], :name => "index_networks_on_user_id"

  create_table "notes", :force => true do |t|
    t.integer  "post_id"
    t.text     "content"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "link"
    t.integer  "user_id"
    t.text     "embed_video"
  end

  add_index "notes", ["post_id"], :name => "index_notes_on_post_id"

  create_table "open_id_authentication_associations", :force => true do |t|
    t.integer "issued"
    t.integer "lifetime"
    t.string  "handle"
    t.string  "assoc_type"
    t.binary  "server_url"
    t.binary  "secret"
  end

  create_table "open_id_authentication_nonces", :force => true do |t|
    t.integer "timestamp",  :null => false
    t.string  "server_url"
    t.string  "salt",       :null => false
  end

  create_table "passwords", :force => true do |t|
    t.integer  "user_id"
    t.string   "reset_code"
    t.datetime "expiration_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "payments", :force => true do |t|
    t.integer  "user_id"
    t.integer  "room_id"
    t.float    "amount"
    t.string   "transaction_id"
    t.string   "transaction_type"
    t.string   "name"
    t.string   "address"
    t.string   "city"
    t.string   "state"
    t.string   "country"
    t.string   "zip"
    t.string   "credit_card_mask", :limit => 4
    t.string   "expiration_month", :limit => 2
    t.string   "expiration_year",  :limit => 4
    t.text     "responses"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "posts", :force => true do |t|
    t.integer  "room_id"
    t.integer  "user_id"
    t.text     "content"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "link"
    t.text     "embed_video"
  end

  add_index "posts", ["room_id", "user_id"], :name => "index_posts_on_room_id_and_user_id"

  create_table "price_settings", :force => true do |t|
    t.float    "per_day"
    t.float    "per_GB_storage"
    t.float    "per_user"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "ratings", :force => true do |t|
    t.integer "rater_id"
    t.integer "rated_id"
    t.string  "rated_type"
    t.integer "rating",     :limit => 10, :precision => 10, :scale => 0
  end

  add_index "ratings", ["rater_id"], :name => "index_ratings_on_rater_id"
  add_index "ratings", ["rated_type", "rated_id"], :name => "index_ratings_on_rated_type_and_rated_id"

  create_table "room_settings", :force => true do |t|
    t.integer  "default_expiry_days"
    t.integer  "default_room_life_time"
    t.integer  "default_storage_size"
    t.integer  "default_max_users"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "room_upgrades", :force => true do |t|
    t.integer  "room_id"
    t.integer  "user_id"
    t.string   "payment_type",              :limit => 100
    t.integer  "no_of_users"
    t.integer  "storage_size"
    t.integer  "additional_days"
    t.integer  "personal_storage"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.float    "additional_days_amount"
    t.float    "additional_storage_amount"
    t.float    "additional_users_amount"
  end

  add_index "room_upgrades", ["room_id"], :name => "index_room_upgrades_on_room_id"
  add_index "room_upgrades", ["user_id"], :name => "index_room_upgrades_on_user_id"

  create_table "room_users", :force => true do |t|
    t.integer  "room_id"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "is_owner",   :default => false, :null => false
  end

  add_index "room_users", ["room_id"], :name => "index_room_users_on_room_id"
  add_index "room_users", ["user_id"], :name => "index_room_users_on_user_id"

  create_table "rooms", :force => true do |t|
    t.string   "title",                   :limit => 100
    t.string   "title_url",               :limit => 50
    t.text     "description"
    t.integer  "category_id"
    t.boolean  "is_private",                             :default => false
    t.string   "crypted_password",        :limit => 40
    t.string   "salt",                    :limit => 40
    t.boolean  "is_class_room",                          :default => false
    t.string   "email",                   :limit => 100
    t.string   "school",                  :limit => 100
    t.string   "teacher",                 :limit => 100
    t.string   "class_name",              :limit => 50
    t.string   "section",                 :limit => 25
    t.string   "email_verification_code", :limit => 40
    t.boolean  "is_class_room_verified",                 :default => false
    t.date     "expiry_date"
    t.integer  "total_storage_size"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.float    "ratings",                                :default => 0.0,   :null => false
    t.integer  "total_user_limit"
  end

  add_index "rooms", ["category_id"], :name => "index_rooms_on_category_id"

  create_table "sessions", :force => true do |t|
    t.string   "session_id", :null => false
    t.text     "data"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "sessions", ["session_id"], :name => "index_sessions_on_session_id"
  add_index "sessions", ["updated_at"], :name => "index_sessions_on_updated_at"

  create_table "user_contacts", :force => true do |t|
    t.integer  "user_id"
    t.integer  "contact_id"
    t.boolean  "is_block"
    t.string   "verification_code", :limit => 40
    t.boolean  "is_verified"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "user_contacts", ["user_id"], :name => "index_user_contacts_on_user_id"

  create_table "user_notifications", :force => true do |t|
    t.integer  "user_id"
    t.boolean  "reaches_maximum_capacity", :default => true
    t.boolean  "reaches_maximum_size",     :default => true
    t.boolean  "reaches_expiry_date",      :default => true
    t.boolean  "post_on_your_room",        :default => true
    t.boolean  "friend_request",           :default => true
    t.boolean  "replies_to_your_post",     :default => true
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "user_notifications", ["user_id"], :name => "index_user_notifications_on_user_id"

  create_table "user_settings", :force => true do |t|
    t.integer  "user_id"
    t.boolean  "block_new_friend_request",   :default => false
    t.boolean  "show_only_subscribed_rooms", :default => false
    t.boolean  "hide_profile_from_search",   :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "user_settings", ["user_id"], :name => "index_user_settings_on_user_id"

  create_table "users", :force => true do |t|
    t.string   "identity_url"
    t.string   "fullname",                  :limit => 100, :default => ""
    t.string   "email",                     :limit => 100
    t.integer  "personal_storage_size"
    t.string   "crypted_password",          :limit => 40
    t.string   "salt",                      :limit => 40
    t.string   "remember_token",            :limit => 40
    t.string   "activation_code",           :limit => 40
    t.string   "state",                                    :default => "passive", :null => false
    t.datetime "remember_token_expires_at"
    t.datetime "activated_at"
    t.datetime "deleted_at"
    t.integer  "fb_user_id",                :limit => 8
    t.datetime "created_at"
    t.datetime "updated_at"
    t.text     "description"
  end

end
