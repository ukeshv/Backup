function chatButtonCollapse() {
    var expand = document.getElementById('chat_bnt_expand');
    var collapse = document.getElementById('chat_bnt_collapse');    
    var chat = document.getElementById('chat_window_expand');
    expand.hide();
    chat.show();
    collapse.show();    
}

function chatButtonExpand() {
    var expand = document.getElementById('chat_bnt_expand');
    var collapse = document.getElementById('chat_bnt_collapse');
    var chat = document.getElementById('chat_window_expand');
    expand.show();
    chat.hide();
    collapse.hide();
}

function ismaxlength(obj){
    var mlength=obj.getAttribute? parseInt(obj.getAttribute("maxlength")) : ""
    if (obj.getAttribute && obj.value.length>mlength)
        obj.value=obj.value.substring(0,mlength)
}
