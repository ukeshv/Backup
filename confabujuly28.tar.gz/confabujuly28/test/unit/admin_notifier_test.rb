require 'test_helper'

class AdminNotifierTest < ActionMailer::TestCase


  # replace this with your real tests
  test "the truth" do
    assert true
  end

end
