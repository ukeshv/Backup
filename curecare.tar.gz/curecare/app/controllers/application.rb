# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  include ExceptionNotifiable
  helper :all # include all helpers, all the time

  # See ActionController::RequestForgeryProtection for details
  # Uncomment the :secret if you're not using the cookie session store
  #protect_from_forgery # :secret => '91863312432632f0eebbfb015658b9e4'
  
  # See ActionController::Base for details 
  # Uncomment this to filter the contents of submitted sensitive data parameters
  # from your application log (in this case, all fields with names like "password"). 
  # filter_parameter_logging :password
  $DAYS={"MON"=>1,"TUE"=>2,"WED"=>3,"THU"=>4,"FRI"=>5,"SAT"=>6,"SUN"=>7}
  
  def valid_user
    patient_id = params[:patient_id]
    id = params[:id]
    doctor_id = params[:doctor_id]
    if (!doctor_id.nil? and !doctor_id.empty? and !current_doctor.nil?) || (!id.nil? and !id.empty? and !current_doctor.nil?)
      if (current_doctor.id.to_s==doctor_id) || (current_doctor.id.to_s==id)
        find_doctor = !doctor_id.nil? ? doctor_id : id
        @doctor = Doctor.find(find_doctor)
      else
        redirect_to doctor_awaiting_requests_path(current_doctor.id)
      end
    elsif (!patient_id.nil? and !patient_id.empty? and !current_patient.nil?) || (!id.nil? and !id.empty? and !current_patient.nil?)
      if (current_patient.id.to_s==patient_id) || (current_patient.id.to_s==id)
        find_patient = !patient_id.nil? ? patient_id :id
        @patient = Patient.find(find_patient)
      else
        redirect_to patient_appointments_path(current_patient.id)
      end  
    end    
  end
	
  def staff
    current_staff
  end 
	
  def duration(did,hid,date)
    a=Appointment.find :last
    Availability.find_all_by_doctor_id_and_hospital_id_and_day(a.doctor_id,a.hospital_id,a.appointment_date.wday)
    return
	end
  
  def doctor_appointment_exists?(start_time, end_time, day_value, doctor_id, hospital_id)
      doctor = Doctor.find(doctor_id)
      oneday_availabilities = doctor.availabilities.find(:all, :conditions => ['hospital_id = ? && day = ?', hospital_id, day_value])
      start_time=Time.parse(start_time).hour
      end_time=Time.parse(end_time).hour
      oneday_availabilities.each do |x|
          if ((start_time >= x.start_time.hour && start_time <= x.end_time.hour) && (end_time >= x.start_time.hour && end_time <= x.end_time.hour))
              #puts "this timing already taken"
          else
              #puts "available timing"
          end
      end
 end
    
  def check_timing?(timing_array)  
      @check = false
      start_times = []
      end_times = []
      timing_array.each do |each_timing|
          start_times << Time.parse(each_timing.split('to')[0]).hour
          end_times << Time.parse(each_timing.split('to')[1]).hour
        end
        #puts start_times.inspect
        #puts "---------------"
        #puts end_times.inspect
      (0..(start_times.length-1)).each do |t|            
          #~ puts t.inspect
          (0..(start_times.length-1)).each do |x|
              #~ puts "#{t} - #{x}"
              if t == x
                  #~ puts "no need to check same element"
              else
                #~ puts "#{start_times[t]} >= #{start_times[x]} && #{start_times[t]} <= #{end_times[x]}) && (#{end_times[t]} >= #{start_times[x]} && #{end_times[t]} <= #{end_times[x]}"
                   if((start_times[t] >= start_times[x] && start_times[t] <= end_times[x]) && (end_times[t] >= start_times[x] && end_times[t] <= end_times[x]))
                      @check = true
                  else
                  end
              end
          end
        end
    return @check
  end


end
