class AppointmentSignupsController < ApplicationController
	
  before_filter :find_doctor, :only=>[:new,:create,:get_one_now]
  before_filter :find_hospital, :only=>[:new,:create,:get_one_now]
  
  require 'net/http'
	
  def index
		
  end
	
  def new
    assignments
    render :update do |page|
      page.replace_html "modal_container", :partial=>"appointment_patient_signup"
    end			
  end
		
		
  def assignments
    @appointment_date=params[:appointment_date]
    @appointment_time=params[:appointment_time]
    @specialty=params[:specialty_id]
    @app_reason=params[:app_reason]
  end		
	
  def create    
    assignments    
    @user_login = UserLogin.new(params[:user_login])
    @patient = Patient.new(params[:patient])
    @patient.step = 2
    #@term_error = (!params[:term_error].nil? && !params[:term_error].empty?) ? params[:term_error] : nil    
    @patient.valid?        
    @user_login.valid?   
    if @user_login.errors.empty? && @patient.errors.empty? && @term_error.nil?
      @user_login.save  
      generate_activation_code
      @user_login.update_attribute('activation_code', @code)
      @patient.first_name=params[:patient][:first_name]
      @patient.last_name=params[:patient][:last_name]
      @patient.mobile_number=params[:patient][:mobile_number]
      @patient.user_login_id = @user_login.id
      @patient.save      
      #PatientMailer.deliver_pin_confirmation(@user_login)
      number = @patient.mobile_number.split(" ")
      mobile_number =  number[1] + number[2]
      country_code = "91"
      url = "http://api.clickatell.com/http/sendmsg?user="+$clickatell_user+"&password="+$clickatell_pwd+"&api_id="+$clickatell_apiid +"&to="+country_code+mobile_number+"&text="+"CureandCare+mobile+verification+pin+code+:+'"+@code+"'"
      result = Net::HTTP.get_response(URI.parse(url)).body
      flash[:notice] = "Thanks for signing up on Cure&Care! <br> We will sending you a SMS shortly to complete your registration"
      render :update do |page|
        page.replace_html "modal_container",:partial=>"/sms_confirmations/sms_pin_no"
      end
    else
      render :update do |page|
        page.replace_html "modal_container",:partial=>"appointment_patient_signup"
      end
    end
  end
	
  def show
		
  end
  
  def generate_activation_code
    alphanumerics = [('0'..'9'),('a'..'z')].map {|range| range.to_a}.flatten
    rand=(0...7).map { alphanumerics[Kernel.rand(alphanumerics.size)] }.join    
    encrypted_string= rand.encrypt
    @code=encrypted_string.decrypt
  end
  
  def get_one_now    
    @specialty=params[:specialty_id]
    @appointment_date=params[:appointment_date]
    @appointment_time=params[:appointment_time]
    @app_reason=params[:app_reason]    
    @user_login = UserLogin.find(params[:id])
    alphanumerics = [('0'..'9'),('a'..'z')].map {|range| range.to_a}.flatten
    rand=(0...7).map { alphanumerics[Kernel.rand(alphanumerics.size)] }.join    
    encrypted_string= rand.encrypt
    code=encrypted_string.decrypt   
    @user_login.update_attribute('activation_code', code)    
    number = @user_login.patient.mobile_number.split(" ")
      mobile_number =  number[1] + number[2]
    country_code = "91"
    url = "http://api.clickatell.com/http/sendmsg?user="+$clickatell_user+"&password="+$clickatell_pwd+"&api_id="+$clickatell_apiid +"&to="+country_code+mobile_number+"&text="+"CureandCare+mobile+verification+pin+code+:+'"+code+"'"
    result = Net::HTTP.get_response(URI.parse(url)).body
    flash[:notice] = "Thanks we will sending you a SMS shortly to complete your registration"
    render :update do |page|
      page.replace_html "modal_container",:partial=>"/sms_confirmations/sms_pin_no"
    end
  end
	
  private
    
  def find_doctor
    @doctor=Doctor.find(params[:doctor_id])  
  end
  
  def find_hospital
    @hospital=Hospital.find(params[:hospital_id])
  end
	
end
