class AppointmentsController < ApplicationController
  
  include UserLoginAuthenticatedSystem
  include GeoKit::Geocoders
  
  #protect_from_forgery :except=>[:create]
  before_filter :find_doctor, :only=>[:new,:create]
  before_filter :find_hospital, :only=>[:new,:create]
  
  def index
		
  end
	
  def new    
    @lat,@lng=find_lat_lng(@hospital.map_address)    
    @date=params[:date]
    appointment_date=@date.scan(/(....)(..)(..)/).flatten
    date=Date.new(appointment_date[0].to_i,appointment_date[1].to_i,appointment_date[2].to_i)
    @show_date=date.strftime("%A %B %d,%Y")
    @time=params[:time]
    appointment_time=@time.split("-")
    @show_time=appointment_time.join("")
    @doctor_specialities=@doctor.specialties
    @doctor_app_reason=@doctor.appointment_reasons    
  end
  
  def find_lat_lng(address)            
    res=MultiGeocoder.geocode(address)
    lat = res.lat
    lng = res.lng
    lat = (!lat.nil? && !lat.blank?) ? lat : "37.4419"
    lng = (!lng.nil? && !lng.blank?) ? lng : "-122.1419"    
    return lat, lng
  end
	
  def show

  end
	
  def assignments
    @appointment_date=params[:appointment_date]
    @appointment_time=params[:appointment_time]
    specialty_id=!params[:specialty_id].nil? ? params[:specialty_id] : (!params[:specialty][:id].nil? ? params[:specialty][:id] : nil)
    @specialty_id= 	specialty_id
    app_reason_id=!params[:app_reason].nil? ? params[:app_reason] : (!params[:appointment_reason][:id].nil? ? params[:appointment_reason][:id] : nil)
    @app_reason_id= app_reason_id
  end
	
  def create
    @user=current_user_login
    assignments
    slot_time=@doctor.doctor_hospitals.find(:first,:conditions=>['hospital_id = ?',@hospital.id])
    #slot_time=DoctorHospital.find(:first,:condition=>['doctor_id = ? && hospital_id = ?',@doctor.id,@hospital.id]).slot_duration
    date_time=@appointment_date +" "+@appointment_time if !@appointment_date.nil? && !@appointment_time.nil?
    @end_time = date_time.to_time + (60 * slot_time.slot_duration)
    @app_date=@appointment_date.to_date.strftime("%Y-%m-%d")
    app_reason=AppointmentReason.find(@app_reason_id) if !@app_reason_id.nil? && !@app_reason_id.empty?
    @app_reason=!app_reason.nil? ? app_reason.name : ""
    app_service=Specialty.find(@specialty_id) if !@specialty_id.nil? && !@specialty_id.empty?
    @app_service=!app_service.nil? ? app_service.name : ""
    !session[:change_appointment].nil? ? update_appointment : create_appointment
    #~ if !session[:change_appointment].nil?
      #~ @appointment_change = Appointment.find(session[:change_appointment])
      #~ @appointment_change.destroy
      #~ session[:change_appointment] = nil
    #~ end  
    #AppointmentMailer.deliver_appointment_confirmation(@user,@doctor,request,@appointment,@hospital)
    render :update do |page|
      page.replace_html "modal_container", :partial=>"/appointments/confirm_appointment"
    end
  end
  
  def update_appointment
    @appointment=Appointment.find(session[:change_appointment])
    @appointment.doctor_id=@doctor.id
    @appointment.hospital_id=@hospital.id
    @appointment.appointment_date=@app_date
    @appointment.reason_for_visit=@app_reason
    @appointment.service_for_visit=@app_service
    @appointment.start_time=@appointment_time
    @appointment.end_time=@end_time.to_time.strftime("%H:%M:%S")
    @appointment.patient_id=@user.patient.id
    @appointment.save
    @hosptial_patient = HospitalPatient.find(:first,:conditions=>["patient_id=? and hospital_id=?",@user.patient.id,@hospital.id])
    if @hosptial_patient.nil?
      @hosptial_patient = HospitalPatient.new()
      @hosptial_patient.patient_id=@user.patient.id    
      @hosptial_patient.hospital_id=@hospital.id
      @hosptial_patient.save
    end
    doctor_patient = DoctorPatient.find(:first,:conditions=>["doctor_id=? and patient_id=?",@doctor.id,@user.patient.id])
    if doctor_patient.nil? 
      doctor_patient = DoctorPatient.new()
      doctor_patient.doctor_id = @doctor.id
      doctor_patient.patient_id = @user.patient.id
      doctor_patient.type_of_relation = 3
      doctor_patient.save
    end
     session[:change_appointment] = nil
  end  
	
  def create_appointment
    @appointment=Appointment.new()
    @appointment.doctor_id=@doctor.id
    @appointment.hospital_id=@hospital.id
    @appointment.appointment_date=@app_date
    @appointment.reason_for_visit=@app_reason
    @appointment.service_for_visit=@app_service
    @appointment.start_time=@appointment_time
    @appointment.end_time=@end_time.to_time.strftime("%H:%M:%S")
    @appointment.patient_id=@user.patient.id
    @appointment.save
    @hosptial_patient = HospitalPatient.find(:first,:conditions=>["patient_id=? and hospital_id=?",@user.patient.id,@hospital.id])
    if @hosptial_patient.nil?
      @hosptial_patient = HospitalPatient.new()
      @hosptial_patient.patient_id=@user.patient.id    
      @hosptial_patient.hospital_id=@hospital.id
      @hosptial_patient.save
    end
    doctor_patient = DoctorPatient.find(:first,:conditions=>["doctor_id=? and patient_id=?",@doctor.id,@user.patient.id])
    if doctor_patient.nil? 
      doctor_patient = DoctorPatient.new()
      doctor_patient.doctor_id = @doctor.id
      doctor_patient.patient_id = @user.patient.id
      doctor_patient.type_of_relation = 3
      doctor_patient.save
    end
  end
	
  def cancel
    @appointment = Appointment.find(params[:id])
    if !params[:reason].nil?
      @appointment.update_attributes(:reason=>params[:reason],:is_cancel=>true)
      flash[:notice] = "Your appointment has been cancelled"
      redirect_to patient_appointments_path(@appointment.patient_id)
      AppointmentMailer.deliver_appointment_cancel_by_user(@appointment.patient.user_login,@appointment.doctor.user_login,request,@appointment,@appointment.hospital)
    end
  end  
  
  def update
		@appointment = Appointment.find(params[:id])
  end
  
  def change_appointment
    @appointment = Appointment.find(params[:id])
    session[:change_appointment] = @appointment.id
    redirect_to doctor_path(@appointment.doctor.id)
  end    

  def set_reminder
    @appointment = Appointment.find(params[:id])
    @appointment_reminder = @appointment.appointment_reminder if !@appointment.appointment_reminder.nil?
  end  

  def update_reminder
	  @appointment = Appointment.find(params[:id])
	  @reminder= @appointment.appointment_reminder.nil? ? AppointmentReminder.new : @appointment.appointment_reminder
	  @reminder.appointment_id =@appointment.id
	  @reminder.send_sms = params[:appointment_reminder][:send_sms]
	  @reminder.sms_to = params[:appointment_reminder][:send_sms] == "1" ? params[:sms_no] : ""
	  @reminder.send_email = params[:appointment_reminder][:send_email]
	  @reminder.email_to = params[:email]
	  @reminder.save
	  redirect_to :controller=>"patient_appointments", :action=>"show",:id=>@appointment.id,:patient_id=>@appointment.patient_id
  end  

  def get_direction
    @appointment = Appointment.find(params[:id])
    @lat,@lng=find_lat_lng(@appointment.hospital.map_address)
    if !params[:from_addr].nil? && !params[:to_addr].nil?
      render :update do |page|
        page.replace_html 'direction_map',:partial=>'direction_map'
      end  
    end  
  end  
	
  private
    
  def find_doctor
    @doctor=Doctor.find(params[:doctor_id])  
  end
  
  def find_hospital
    @hospital=Hospital.find(params[:hospital_id])
  end
	
end
