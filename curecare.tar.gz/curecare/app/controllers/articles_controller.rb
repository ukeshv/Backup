class ArticlesController < ApplicationController
	layout "home"
	include UserLoginAuthenticatedSystem
	 before_filter :find_patient
	def index
		
	end
	
	private
  
  def find_patient    
    @patient = !current_patient.nil? ? current_patient : nil
  end
	
end
