class AttachmentsController < ApplicationController
	layout :change_layout
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem
  before_filter :login_required, :only=>[:show, :update]  
  before_filter :valid_user
  before_filter :find_doctor, :only=>[:show,:update]
  before_filter :find_hospital, :only=>[:show,:update]
	
	def show
		
	end

  def update
		if @doctor
			doctor_update
    elsif @hospital
			hospital_update
	 end
	end	
	
	
	def doctor_update
		doctor_id = !@doctor.nil? ? @doctor.id : params[:doctor_id]
			#change password
			if params[:user_login]
				@edit_flag=false
				@user_login=UserLogin.find(@doctor.user_login_id)
				@user_login.email=(params[:user_login][:email])
				@user_login.password=(params[:user_login][:password])
				@user_login.password_confirmation=(params[:user_login][:password_confirmation])
				if @user_login.valid?
					@user_login.save
					PatientMailer.deliver_change_password(@user_login)
					flash[:notice]='Your new password has been sent to your email address.'
					redirect_to doctor_attachment_path(doctor_id)
				else
					@edit_flag=true
					render :action=>'show'
				end	
			elsif params[:attachment_metadata]	
				#update photo
				exist_photo=DoctorPhoto.find_by_doctor_id(doctor_id)
				exist_photo.destroy if !exist_photo.nil?
				@attachable_file = DoctorPhoto.new(params[:attachment_metadata])
				@attachable_file.doctor_id=doctor_id
				if @attachable_file.save
					flash[:notice] = 'Attachment was successfully created.'
					redirect_to doctor_attachment_path(doctor_id)
				else
					flash[:notice] = 'Attachment was failed.'
					# render :action => :show
				end
			end
  end

		def hospital_update
			hospital_id = !@hospital.nil? ? @hospital.id : params[:hospital_id]
				#change password
				if params[:user_login]
					@edit_flag=false
					@user_login=UserLogin.find(@hospital.user_login_id)
					@user_login.email=(params[:user_login][:email])
					@user_login.password=(params[:user_login][:password])
					@user_login.password_confirmation=(params[:user_login][:password_confirmation])
					if @user_login.valid?
						@user_login.save
						PatientMailer.deliver_change_password(@user_login)
						flash[:notice]='Your new password has been sent to your email address.'
						redirect_to hospital_attachment_path(hospital_id)
					else
						@edit_flag=true
						render :action=>'show'
					end	
				elsif params[:attachment_metadata]	
					#update photo
					exist_photo=HospitalPhoto.find_by_hospital_id(hospital_id)
					exist_photo.destroy if !exist_photo.nil?
					@attachable_file = HospitalPhoto.new(params[:attachment_metadata])
					@attachable_file.hospital_id=hospital_id
					if @attachable_file.save
						flash[:notice] = 'Attachment was successfully created.'
						redirect_to hospital_attachment_path(hospital_id)
					else
						flash[:notice] = 'Attachment was failed.'
						# render :action => :show
					end
				end
		end
		
		
	def change_layout
    if @doctor
      "doctor"
    else
      "hospital"
    end
  end	
	
	 private
    
  def find_doctor
    @doctor=!params[:doctor_id].nil? ? Doctor.find(params[:doctor_id]) : nil 
  end
	
	def find_hospital
    @hospital= !params[:hospital_id].nil? ? Hospital.find(params[:hospital_id]) : nil
  end
end
