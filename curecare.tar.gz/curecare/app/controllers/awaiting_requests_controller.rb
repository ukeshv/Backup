class AwaitingRequestsController < ApplicationController
  layout :change_layout, :except=>[:show]
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:index]
  before_filter :valid_user
  before_filter :find_doctor, :only=>[:index,:update]  
  before_filter :find_hospital, :only=>[:index,:update]
  #protect_from_forgery :except=>[:create]
  def index
    if @doctor
			@doctor_staff=!staff.nil? ? staff : nil
      @appointments=@doctor.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',1,0])
      @reschedule_appointments = @doctor.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ? and rescheduled_date IS NOT NULL',4,0])
      @cancellation_appointments=@doctor.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',3,0])
    elsif @hospital      
	    @hospital_staff=!staff.nil? ? staff : nil
			@appointments=@hospital.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',1,0])
      @reschedule_appointments = @hospital.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ? and rescheduled_date IS NOT NULL',4,0])
      @cancellation_appointments=@hospital.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',3,0])
    end    
  end
  
  def change_layout
    if @doctor
      "doctor"
    else
      "hospital"
    end
	
  end	
	
  
  def update
      #@appointment =Appointment.find_by_id(params[:id])
		if @doctor
			doctor_appointment
		elsif @hospital
			hospital_appointment
		end
		
  end
	
  def show
    @appointment=Appointment.find_by_id(params[:id])
    @date = Date.today
  end
	
	def doctor_appointment
    if params[:submit_flag] == '4'
      if !params[:awaiting_requests].blank?
        appointments = params[:awaiting_requests]
        appointments.each do |appointment_id|
          @appointment = Appointment.find(appointment_id)
          @appointment.update_attributes(:flag=>4)
          AppointmentMailer.deliver_appointment_confirmation(@appointment.patient.user_login,@doctor,request,@appointment,@appointment.hospital)
        end
      end
      flash[:notice]="Selected Appointments are confirmed"
    elsif params[:submit_flag] == '3'
      d=Date.today
      date=d.strftime('%Y-%m-%d')
      if !params[:awaiting_requests].blank?
        appointments = params[:awaiting_requests]
        appointments.each do |appointment_id|
          @appointment = Appointment.find(appointment_id)
          @appointment.update_attributes(:flag=>3,:cancelled_date=>date)
          AppointmentMailer.deliver_appointment_reject(@appointment.patient.user_login,@doctor,request,@appointment,@appointment.hospital)
        end
      end
      flash[:notice]="Selected Appointments are cancelled"
    elsif (params[:submit_flag] == "2" || params[:submit_flag] == "")
      if !params[:rescheduled_date].nil? || !params[:rescheduled_date].blank?
            @rescheduled_date=params[:rescheduled_date]
            @appointment_time=params[:time] ? params[:time] : ""
            date_time=@rescheduled_date +" "+@appointment_time if !@rescheduled_date.nil? && !@appointment_time.nil?
            @appointment = Appointment.find(params[:id])
            slot_time=@appointment.doctor.doctor_hospitals.find(:first,:conditions=>['hospital_id = ?',@appointment.hospital.id])
            @end_time = date_time.to_time + (60 * slot_time.slot_duration)            
            @appointment.rescheduled_date = @rescheduled_date
            @appointment.start_time = @appointment_time.blank? ? @appointment.start_time : @appointment_time 
            @appointment.end_time = @appointment_time.blank? ? @appointment.end_time : @end_time
            @appointment.flag = 4
            @appointment.save
            #@appointment.update_attributes(:flag=>4,:rescheduled_date=>params[:rescheduled_date])
            AppointmentMailer.deliver_appointment_reschedule(@appointment.patient.user_login,@doctor,request,@appointment,@appointment.hospital)
      end   
       flash[:notice]="Selected Appointments was updated."
    end	
    redirect_to doctor_awaiting_requests_path(@doctor)
	end
	
	def hospital_appointment
		if params[:submit_flag] == '4'
      if !params[:awaiting_requests].blank?
        appointments = params[:awaiting_requests]
        appointments.each do |appointment_id|
          @appointment = Appointment.find(appointment_id)
          @appointment.update_attributes(:flag=>4)
          AppointmentMailer.deliver_hospital_appointment_confirmation(@appointment.patient.user_login,@doctor,request,@appointment,@appointment.doctor)
        end
      end
      flash[:notice]="Selected Appointments are confirmed"
    elsif params[:submit_flag] == '3'
      d=Date.today
      date=d.strftime('%Y-%m-%d')
      if !params[:awaiting_requests].blank?
        appointments = params[:awaiting_requests]
        appointments.each do |appointment_id|
          @appointment = Appointment.find(appointment_id)
          @appointment.update_attributes(:flag=>3,:cancelled_date=>date)
          AppointmentMailer.deliver_hospital_appointment_reject(@appointment.patient.user_login,@hospital,request,@appointment,@appointment.doctor)
        end
      end
      flash[:notice]="Selected Appointments are rejected"
    elsif (params[:submit_flag] == "2" || params[:submit_flag] == "")
      if !params[:rescheduled_date].nil? || !params[:rescheduled_date].blank?
          @rescheduled_date=params[:rescheduled_date]
          @appointment_time=params[:time] ? params[:time] : ""
          date_time=@rescheduled_date +" "+@appointment_time if !@rescheduled_date.nil? && !@appointment_time.nil?
          @appointment = Appointment.find(params[:id])
          slot_time=@appointment.hospital.doctor_hospitals.find(:first,:conditions=>['doctor_id = ?',@appointment.doctor.id])
          @end_time = date_time.to_time + (60 * slot_time.slot_duration)            
          @appointment.rescheduled_date = @rescheduled_date
          @appointment.start_time = @appointment_time.blank? ? @appointment.start_time : @appointment_time 
          @appointment.end_time = @appointment_time.blank? ? @appointment.end_time : @end_time
          @appointment.flag = 4
          @appointment.save
        #~ @appointment = Appointment.find(params[:id])
        #~ @appointment.update_attributes(:flag=>4,:rescheduled_date=>params[:rescheduled_date])
        AppointmentMailer.deliver_hospital_appointment_reschedule(@appointment.patient.user_login,@hospital,request,@appointment,@appointment.doctor)
      end   
       flash[:notice]="Selected Appointments was updated."
    end	
    redirect_to hospital_awaiting_requests_path(@hospital)
	end
  
  def convert_to_date_format(str_date)    
    if str_date
      date = str_date.scan(/(....)(..)(..)/)
      date = date.flatten
      year = date[0].to_i
      month = date[1].to_i
      day = date[2].to_i    
      date = Date.new(year,month,day)
      return date
    end
  end
	
  def reload_availabilities
    date = convert_to_date_format(params[:date])    
    @date = !date.nil? ? date : Date.today   
    @appointment=Appointment.find_by_id(params[:id])
    render :update do |page|      
      page.replace_html 'appointment_availabilities_slot', :partial=>'awaiting_requests/time_availabilities'
    end  
  end
  
  def hospital_reload_availabilities
    date = convert_to_date_format(params[:date])    
    @date = !date.nil? ? date : Date.today   
    @appointment=Appointment.find_by_id(params[:id])
    render :update do |page|      
      page.replace_html 'hospital_appointment_availabilities_slot', :partial=>'awaiting_requests/hospital_time_availabilities'
    end  
  end
	
  private
    
  def find_doctor
    @doctor= !params[:doctor_id].nil? ? Doctor.find(params[:doctor_id]) : nil
  end
	
  def find_hospital
    @hospital= !params[:hospital_id].nil? ? Hospital.find(params[:hospital_id]) : nil
  end
	
  
end
