class CancellationPoliciesController < ApplicationController
  layout 'doctor'  
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:show, :update]
	before_filter :valid_user
  before_filter :find_doctor, :only=>[:show,:update]
  
  def show
    
  end
  
  def update
    @doctor.cancellation_of_appointment=params[:doctor][:cancellation_of_appointment]
    @doctor.cancellation_time_limit=params[:doctor][:cancellation_time_limit]
    if @doctor.save	 
      flash[:notice]="Minimum notice period has been updated."
      redirect_to doctor_cancellation_policy_path(@doctor)
    else
      flash.now[:error]="Minimum notice period has not been updated."
      render :action=>'show'
    end
  end
  
  private
    
  def find_doctor
    @doctor=Doctor.find(params[:doctor_id])  
  end
end
