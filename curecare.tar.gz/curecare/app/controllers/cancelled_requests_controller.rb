class CancelledRequestsController < ApplicationController
  layout :change_layout
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:index]
  before_filter :valid_user
  before_filter :find_doctor, :only=>[:index,:update]
  before_filter :find_hospital, :only=>[:index,:update]
	
  def index
		if @doctor
			@doctor_staff=!staff.nil? ? staff : nil
			@appointments=@doctor.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',3,0])
			@appoints=@doctor.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',1,0])
			@reschedule_appointments = @doctor.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ? and rescheduled_date IS NOT NULL',4,0])
		elsif @hospital
			@hospital_staff=!staff.nil? ? staff : nil
			@appointments=@hospital.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',3,0])
			@appoints=@hospital.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',1,0])
			@reschedule_appointments = @hospital.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ? and rescheduled_date IS NOT NULL',4,0])
		end
  end
  
  def update
    #@appointment=Appointment.find_by_id(params[:id])
		if @doctor
			doctor_appointment
		elsif @hospital
			hospital_appointment
			end  
  end
  
	def doctor_appointment
		 if params[:submit_flag] == '4'
			if !params[:cancel_requests].blank?
				appointments = params[:cancel_requests]
				appointments.each do |appointment_id|
					@appointment = Appointment.find(appointment_id)
					@appointment.destroy
				end
			end
      flash[:notice]="Selected Appointment are deleted"
    else
			if !params[:cancel_requests].blank?
				appointments = params[:cancel_requests]
				appointments.each do |appointment_id|
					@appointment = Appointment.find(appointment_id)
					@appointment.update_attributes(:flag=>1,:cancelled_date=>nil)
				end
			end
      flash[:notice]="Selected Appointment are rejected"
    end	
      redirect_to doctor_cancelled_requests_path(@doctor)
	end
	
	def hospital_appointment
		 if params[:submit_flag] == '4'
			if !params[:cancel_requests].blank?
				appointments = params[:cancel_requests]
				appointments.each do |appointment_id|
					@appointment = Appointment.find(appointment_id)
					@appointment.destroy
				end
			end
      flash[:notice]="Selected Appointment are deleted"
    else
			if !params[:cancel_requests].blank?
				appointments = params[:cancel_requests]
				appointments.each do |appointment_id|
					@appointment = Appointment.find(appointment_id)
					@appointment.update_attributes(:flag=>1,:cancelled_date=>nil)
				end
			end
      flash[:notice]="Selected Appointment are rejected"
    end	
    redirect_to hospital_cancelled_requests_path(@hospital)
	end
	
	
	
	def change_layout
    if @doctor
      "doctor"
    else
      "hospital"
    end
	
  end
	
  private
    
   def find_doctor
    @doctor= !params[:doctor_id].nil? ? Doctor.find(params[:doctor_id]) : nil
  end
	
  def find_hospital
    @hospital= !params[:hospital_id].nil? ? Hospital.find(params[:hospital_id]) : nil
  end
	
end
