class CitiesController < ApplicationController
end
