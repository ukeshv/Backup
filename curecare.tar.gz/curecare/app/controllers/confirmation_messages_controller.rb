class ConfirmationMessagesController < ApplicationController
  layout 'doctor'  
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:show, :update]
	before_filter :valid_user
  before_filter :find_doctor, :only=>[:show,:update]
  
  def show
    
  end
  
  def update
    @doctor.notification_message=params[:doctor][:notification_message]
    if @doctor.save
      flash[:notice]='Custom message has been modified'
      redirect_to doctor_confirmation_message_path(@doctor)
    else
      flash.now[:error]='Custom message not modified.'
      render :action=>'show'
    end
  end
  
  private
    
  def find_doctor
    @doctor=Doctor.find(params[:doctor_id])  
  end
end
