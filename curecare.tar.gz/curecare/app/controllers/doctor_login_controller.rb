# This controller handles the login/logout function of the site.  
class DoctorLoginController < ApplicationController
  layout "doctor"
  # Be sure to include AuthenticationSystem in Application Controller instead
  include DoctorAuthenticatedSystem

  # render new.rhtml
  def new
  end
  
  def create
    if params[:email].nil? or params[:password].nil? or params[:email].empty? or params[:password].empty? 
      flash.now[:error]="Email and Password Cannot be blank"
    else
      flash.now[:email_error]=DoctorLogin.authenticate_email?(params[:email])      
      if flash.now[:email_error].nil?        
        flash.now[:password_error]=DoctorLogin.authenticate_email_password?(params[:email], params[:password])
        if flash.now[:password_error].nil?          
          @doctor = DoctorLogin.authenticate(params[:email], params[:password])
          if @doctor            
            self.current_doctor=@doctor
            redirect_to doctor_appointment_requests_path(@doctor.doctor.id) and return true
          else
            flash.now[:error]="Your account not yet activated"
          end
        end
      end 
    end
    render :action=>"new"
  end
 
  
  def destroy
    self.current_doctor if logged_in? #.forget_me if logged_in?
    cookies.delete :auth_token
    reset_session
    flash[:notice] = "You have been logged out."
    redirect_to new_doctor_login_path
  end
end
