class DoctorsController < ApplicationController
  layout :change_layout
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem
  cache_sweeper :fragment_cache_sweeper, :only => [:create]
  before_filter :login_required, :except=>[:show,:index,:new,:create,:activate,:rotate_availability_calender]
  before_filter :find_doctor, :only=>[:show, :rotate_availability_calender]
  before_filter :find_patient, :only=>[:index]
	
  def index
    @all_doctors=Doctor.find(:all,:order=>'created_at desc',:limit=>5)
    if !params[:speciality_id].nil? && params[:city_id].nil?		
      @speciality= Specialty.find(params[:speciality_id]) 
      @doctors=@speciality.doctors.find(:all,:order=>'first_name')
      @Popular_cities=City.find(:all,:conditions=>['flag = ?',1])      
      @doctors=@doctors.paginate :page => params[:page], :per_page => 5
    elsif !params[:speciality_id].nil? && !params[:city_id].nil?
      @city=City.find(params[:city_id])
      @speciality=Specialty.find(params[:speciality_id])
      doc_speciality_ids=@speciality.doctor_ids if !@speciality.nil?			
      doctors_specialities= !doc_speciality_ids.nil? ? doc_speciality_ids : []
      hospitals=Hospital.find_all_by_city_id(params[:city_id])			
      @hospitals = []
      hospitals = hospitals.collect{|x| @hospitals<<x.doctor_ids}if !hospitals.nil?			
      doc_hospital_ids=@hospitals.flatten if !@hospitals.nil?			
      doctors_hospitals=!doc_hospital_ids.nil? ? doc_hospital_ids : []
      doctors=doctors_specialities & doctors_hospitals
      @doctors=[]
      doctors.each{|x|
        @doctors << Doctor.find(x,:order=>'first_name')
      }
      @doctors=@doctors.paginate :page => params[:page], :per_page => 5
    elsif (!params[:search_text].nil? && !params[:search_text].empty?) && (params[:location_text].nil? ||  params[:location_text].empty?)
      search=params[:search_text]+"%"
      search_specialty=Specialty.find(:all,:conditions=>["name like '"+search+"%'"])
      @doctors=[]
      search_specialty.each{|x| @doctors<< x.doctors} if !search_specialty.nil?
      search_doctor=Doctor.find(:all,:conditions=>["first_name like '"+search+"%' || last_name like '"+search+"%'"],:order=>'first_name')
      search_doctor.each{|x| @doctors<< x} if !search_doctor.nil?
      @doctors=@doctors.flatten if !@doctors.nil? && !@doctors.empty?
      @Popular_cities=City.find(:all,:conditions=>['flag = ?',1])      
      @doctors=@doctors.paginate :page => params[:page], :per_page => 5
    elsif !params[:search_text].nil? && !params[:search_text].empty? && !params[:location_text].nil? && !params[:location_text].empty?
      search=params[:search_text]+"%"
      search_specialty=Specialty.find(:all,:conditions=>["name like '"+search+"%'"])
      doctors_specialities=[]
      search_specialty.each{|x| doctors_specialities<< x.doctor_ids} if !search_specialty.nil?
      search_doctor=Doctor.find(:all,:select=>'id',:conditions=>["first_name like '"+search+"%' || last_name like '"+search+"%'"],:order=>'first_name')
      search_doctor.each{|x| doctors_specialities<< x.id} if !search_doctor.nil?			        								
      doctors_specialities=doctors_specialities.flatten.uniq if doctors_specialities				
      @location=params[:location_text]+"%"
      cities=City.find(:all,:select=>'id',:conditions=>["name like '"+@location+"%'"])
      hospitals=[]
      cities.each{|c| hospitals<<c.hospital_ids}
      hospitals=hospitals.flatten
      doctors_hospitals=[]
      hospitals.each{|x| 
        hospital=Hospital.find(x)				
        doctors_hospitals << hospital.doctor_ids if !hospital.nil?
      }				
      doctors_hospitals=doctors_hospitals.flatten.uniq if doctors_hospitals				
      doctors=doctors_specialities & doctors_hospitals
      @doctors=[]
      doctors.each{|x| 
        doctor = Doctor.find(x,:order=>'first_name')
        @doctors<< doctor if doctor
      }
      @doctors=@doctors.paginate :page => params[:page], :per_page => 5		
    elsif params[:search_text].nil? && !params[:location_text].empty?
      @location=params[:location_text]+"%"
      cities=City.find(:all,:select=>'id',:conditions=>["name like '"+@location+"%'"])
      hospitals=[]
      cities.each{|c| hospitals<<c.hospital_ids}
      hospitals=hospitals.flatten
      doctors_hospitals=[]
      hospitals.each{|x| 
        hospital=Hospital.find(x)				
        doctors_hospitals << hospital.doctor_ids if !hospital.nil?
      }				
      doctors_hospitals=doctors_hospitals.flatten.uniq if doctors_hospitals				
      @doctors=[]
      doctors_hospitals.each{|x| 
        doctor = Doctor.find(x,:order=>'first_name')
        @doctors<< doctor if doctor
      }
      @doctors=@doctors.paginate :page => params[:page], :per_page => 5	
    else
      @doctors = Doctor.paginate :page => params[:page], :per_page => 5
    end	
  end
  
  # render new.rhtml
  def new
  end

  def create
    cookies.delete :auth_token
    # protects against session fixation attacks, wreaks havoc with 
    # request forgery protection.
    # uncomment at your own risk
    # reset_session
    @user_login = UserLogin.new(params[:user_login])
    @user_login.save
    if @user_login.errors.empty?
      #self.current_doctor = @doctor
      @user_login.doctor = Doctor.create()
      DoctorMailer.deliver_email_confirmation(@user_login,request)
      flash[:notice] = "Thanks for signing up! <br> Please check your email to complete your registration"
      redirect_to new_user_login_path
    else
      render :action => 'new'
    end
  end
  
  def activate
    self.current_user_login = params[:activation_code].blank? ? false : UserLogin.find_by_activation_code(params[:activation_code])    
    if logged_in? && !current_user_login.active?       
      current_user_login.activate
      flash[:notice] = "Your account has been activated"
      #redirect_to doctor_awaiting_requests_path(self.current_user_login.doctor.id)
      redirect_to doctor_service_profile_path(self.current_user_login.doctor.id)
    else
      flash[:notice] = "This is an invalid activation code."
      redirect_to new_user_login_path
    end
  end
  
  def show
    @patient=current_patient
    @date=Date.today
    @doctor_hospitals=@doctor.doctor_hospitals
    @availabilites=@doctor.availabilities
    @speciality=Specialty.find(:first,:conditions=>["name like '"+Doctor.title(@doctor.id).name+"%%'"]) if Doctor.title(@doctor.id)   
    @city=!Doctor.location(@doctor.id).nil? ? City.find(:first,:conditions=>["name like '"+Doctor.location(@doctor.id).city.name+"%%'"]) : nil    
    
  end

  def rotate_availability_calender
    @date=params[:date].to_date
    @doctor_hospitals=@doctor.doctor_hospitals
    @availabilites=@doctor.availabilities
    render :update do |page|
      page.replace_html "availability_calendar", :partial=>"consulting_hours"
    end
  end
  
  def change_layout    
    if (action_name=="new" || action_name=="create")
      "login"
    elsif (action_name=='index')
      "home"
    elsif (action_name=="show")
      if logged_in?
        "patient" 
      else
        "home" 
      end
    else
      "doctor"
    end
  end
	
  private
    
  def find_doctor
    @doctor=Doctor.find(params[:id])  
  end
  
  def find_patient    
    @patient = !current_patient.nil? ? current_patient : nil
  end
  
  
	
end
