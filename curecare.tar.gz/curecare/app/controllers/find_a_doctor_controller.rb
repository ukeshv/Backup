class FindADoctorController < ApplicationController
  layout "home"
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :except=>[:index]
  before_filter :valid_user
  before_filter :find_patient
  
  
  def index
    @specialities=Specialty.find(:all)
    @doctors=Doctor.find(:all,:order=>'created_at desc',:limit=>5)
    @hospitals=Hospital.find(:all,:limit=>5)
  end
  
  private
  
  def find_patient    
    @patient = !current_patient.nil? ? current_patient : nil
  end
  
end
