class FindHospitalsController < ApplicationController
  layout "home"
  include UserLoginAuthenticatedSystem
  before_filter :login_required, :except=>[:index,:show]
  before_filter :find_patient
	
  def index
    #@doctors=Doctor.find(:all,:order=>'created_at desc',:limit=>5)
    hospitals=Hospital.find(:all,:order=>'created_at desc')
    @hospitals=hospitals.paginate :page => params[:page], :per_page =>10
  end
  
  def show
    @new_hospitals = Hospital.find(:all,:order=>'created_at desc')
    if (!params[:search_text].nil? && !params[:search_text].empty?) && (params[:location_text].nil? ||  params[:location_text].empty?)
      search=params[:search_text]+"%"
      @hospitals = Hospital.find(:all,:conditions=>["name like '"+search+"%'"],:order=>'name')      
      @hospitals = @hospitals.flatten.paginate :page => params[:page], :per_page => 5
    elsif !params[:search_text].nil? && !params[:search_text].empty? && !params[:location_text].nil? && !params[:location_text].empty?
      location=params[:location_text]+"%"
      search=params[:search_text]+"%"
      cities=City.find(:all,:select=>'id',:conditions=>["name like '"+location+"%'"])      
      @hospitals=[]
      cities.each{|c| @hospitals << c.hospitals.find(:all,:conditions=>["name like '"+search+"%'"])}
      @hospitals = @hospitals.flatten.paginate :page => params[:page], :per_page => 5
    elsif params[:search_text].nil? && !params[:location_text].empty?      
      location=params[:location_text]+"%"
      cities=City.find(:all,:select=>'id',:conditions=>["name like '"+location+"%'"])
      @hospitals=[]
      cities.each{|c| @hospitals << c.hospitals}      
      @hospitals = @hospitals.flatten.paginate :page => params[:page], :per_page => 5      
    else
      @hospitals = Hospital.paginate :page => params[:page], :per_page => 5
    end	
  end
	
  private
  
  def find_patient    
    @patient = !current_patient.nil? ? current_patient : nil
  end
end
