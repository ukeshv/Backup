class HolidaysController < ApplicationController
  layout :change_layout
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:index,:create, :destroy,:edit_holiday,:update]
  before_filter :valid_user
  before_filter :find_doctor, :only=>[:index,:create,:destroy,:edit_holiday,:update]
  before_filter :find_hospital, :only=>[:index,:create,:destroy,:edit_holiday,:update]
  
  def index
    if @doctor
      @holidays_list=@doctor.holidays
    elsif @hospital
      @hospital_holidays_list=@hospital.hospital_holidays
    end
  end
	

  def create
    if @doctor
      doctor_holiday_create
    elsif @hospital
      hospital_holiday_create
    end
  end	
  
  def doctor_holiday_create
    holidays=!@doctor.holidays.nil? ? @doctor.holidays.find(:all,:conditions=>["(? between start_date and end_date) or (? between start_date and end_date)",params[:start_date].to_date,params[:end_date].to_date]) : []    
    if holidays.empty?
      @holiday=Holiday.new()
      @holiday.start_date=params[:start_date]
      @holiday.end_date=params[:end_date]
      @holiday.note=params[:holiday][:note]
      if @holiday.valid? 
        @doctor.holidays<<@holiday
				flash[:notice]= ((@holiday.end_date-@holiday.start_date+1)>1) ? 'Your holidays has been saved.' : 'Your holiday has been saved.'
        redirect_to doctor_holidays_path(@doctor)
      else
        @holidays_list=@doctor.holidays
        flash.now[:error]='Your holiday has not been saved.'
        render :action=>'index'
      end
    else
      @holidays_list=@doctor.holidays
      flash.now[:error]='Selected dates were already exists in holidays.Please select another date. '
      render :action=>'index'
    end
  end
	
  def hospital_holiday_create
    hospital_holidays=!@hospital.hospital_holidays.nil? ? @hospital.hospital_holidays.find(:all,:conditions=>["(? between start_date and end_date) or (? between start_date and end_date)",params[:start_date].to_date,params[:end_date].to_date]) : []        
    if hospital_holidays.empty?
      @hospital_holiday=HospitalHoliday.new()
      @hospital_holiday.start_date=params[:start_date]
      @hospital_holiday.end_date=params[:end_date]
      @hospital_holiday.note=params[:hospital_holiday][:note]
      if @hospital_holiday.valid? 
        @hospital.hospital_holidays<<@hospital_holiday
				flash[:notice]=  ((@hospital_holiday.end_date-@hospital_holiday.start_date+1)>1) ? 'Your holidays has been saved.' : 'Your holiday has been saved.'
        redirect_to hospital_holidays_path(@hospital)
      else
        @hospital_holidays_list=@hospital.hospital_holidays
        flash.now[:error]='Your holiday has not been saved.'
        render :action=>'index'
      end
    else
      @hospital_holidays_list=@hospital.hospital_holidays
      flash.now[:error]='Selected dates were already exists in holidays.Please select another date. '
      render :action=>'index'
    end
  end
	
  def edit_holiday
    if @doctor
      @holiday=Holiday.find_by_id(params[:holiday_id])
        render :update do |page|
        page.replace_html "doctor_holiday", :partial=>"edit_doctor_holiday"
      end
    elsif @hospital
      @holiday=HospitalHoliday.find_by_id(params[:holiday_id])
       render :update do |page|
       page.replace_html "hospital_holiday", :partial=>"edit_hospital_holiday"
       end
    end 
  end


  def update
    if @doctor
      @holiday=Holiday.find_by_id(params[:id])
      @holiday.update_attributes(:start_date=>params[:start_date],:end_date=>params[:end_date],:note=>params[:holiday][:note])
      flash[:notice]="Your holiday has been saved."
      redirect_to  doctor_holidays_path(@doctor)
    elsif @hospital
      @hos_holiday=HospitalHoliday.find_by_id(params[:id])
      @hos_holiday.update_attributes(:start_date=>params[:start_date],:end_date=>params[:end_date],:note=>params[:hospital_holiday][:note])
      flash[:notice]="Your holiday has been saved."
      redirect_to  hospital_holidays_path(@hospital)
    end
   end
   
   
  
	
  def destroy
    if params[:all_check] && !params[:all_check].empty?
      flash[:notice]='Your holiday has been deleted.'
        params[:all_check].each{|h|
        if @doctor
          @holiday=Holiday.find(h)
          @holiday.destroy
        end
        if @hospital
          @hospital_holiday=HospitalHoliday.find(h)
          @hospital_holiday.destroy
        end 
        }
        if @doctor          
          redirect_to  doctor_holidays_path(@doctor)
        end
        if @hospital          
          redirect_to  hospital_holidays_path(@hospital)
        end 
    end
  end

  def change_layout
    if @doctor
      "doctor"
    else
      "hospital"
    end
  end

  
  private
    
  def find_doctor
    @doctor= !params[:doctor_id].nil? ? Doctor.find(params[:doctor_id]) : nil
  end
	
  def find_hospital
    @hospital= !params[:hospital_id].nil? ? Hospital.find(params[:hospital_id]) : nil
  end
end
