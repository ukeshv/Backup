class HomeController < ApplicationController
  layout "home" ,:except=>[:work_in_progress]
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem
  #protect_from_forgery :except=>[:work_in_progress]
  before_filter :find_patient
  
  
  def index
    @specialities=Specialty.find(:all)
    @doctors=Doctor.find(:all,:order=>'created_at desc',:limit=>5)
    @hospitals=Hospital.find(:all,:order=>'created_at desc',:limit=>5)
  end
  
  
  def show    
    @all_doctors=Doctor.find(:all,:order=>'created_at desc',:limit=>5)    
    if (!params[:search_text].nil? && !params[:search_text].empty?) && (params[:location_text].nil? ||  params[:location_text].empty?)
      search=params[:search_text]+"%"
      search_specialty=Specialty.find(:all,:conditions=>["name like '"+search+"%'"])
      @doctors=[]
      search_specialty.each{|x| @doctors<< x.doctors} if !search_specialty.nil?
      search_doctor=Doctor.find(:all,:conditions=>["first_name like '"+search+"%' || last_name like '"+search+"%'"],:order=>'first_name')
      search_doctor.each{|x| @doctors<< x} if !search_doctor.nil?
      @doctors=@doctors.flatten if !@doctors.nil? && !@doctors.empty?
      @Popular_cities=City.find(:all,:conditions=>['flag = ?',1])
      @cities=City.find(:all,:conditions=>['flag = ?',0])      
      search_hospital=Hospital.find(:all,:conditions=>["name like '"+search+"%'"],:order=>'name')
      @doctors = search_hospital + @doctors       
      @doctors=@doctors.paginate :page => params[:page], :per_page => 5
    elsif !params[:search_text].nil? && !params[:search_text].empty? && !params[:location_text].nil? && !params[:location_text].empty?
      search=params[:search_text]+"%"
      search_specialty=Specialty.find(:all,:conditions=>["name like '"+search+"%'"])
      doctors_specialities=[]
      search_specialty.each{|x| doctors_specialities<< x.doctor_ids} if !search_specialty.nil?
      search_doctor=Doctor.find(:all,:select=>'id',:conditions=>["first_name like '"+search+"%' || last_name like '"+search+"%'"],:order=>'first_name')
      search_doctor.each{|x| doctors_specialities<< x.id} if !search_doctor.nil?			        								
      doctors_specialities=doctors_specialities.flatten.uniq if doctors_specialities				
      @location=params[:location_text]+"%"
      cities=City.find(:all,:select=>'id',:conditions=>["name like '"+@location+"%'"])
      hospitals=[]
      cities.each{|c| hospitals<<c.hospital_ids
        @hospitals = Hospital.find(:all,:conditions=>["name like '"+search+"%' and city_id=#{c.id}"],:order=>'name')
      }
      hospitals=hospitals.flatten
      doctors_hospitals=[]
      hospitals.each{|x|         
        hospital=Hospital.find(x,:order=>'name')				
        doctors_hospitals << hospital.doctor_ids if !hospital.nil?
      }				
      doctors_hospitals=doctors_hospitals.flatten.uniq if doctors_hospitals				
      doctors=doctors_specialities & doctors_hospitals
      @doctors=[]
      doctors.each{|x| 
        doctor = Doctor.find(x,:order=>'first_name')
        @doctors<< doctor if doctor
      }
      @doctors = @doctors + @hospitals if @hospitals
      @doctors=@doctors.paginate :page => params[:page], :per_page => 5		    	
    elsif params[:serach_text].nil? && !params[:location_text].empty?
      @location=params[:location_text]+"%"
      cities=City.find(:all,:select=>'id',:conditions=>["name like '"+@location+"%'"])
      hospitals=[]
      cities.each{|c| hospitals<<c.hospital_ids
        @hospitals = Hospital.find(:all,:conditions=>["city_id=#{c.id}"],:order=>'name')
      }
      hospitals=hospitals.flatten
      doctors_hospitals=[]
      hospitals.each{|x| 
        hospital=Hospital.find(x,:order=>'name')				
        doctors_hospitals << hospital.doctor_ids if !hospital.nil?
      }				
      doctors_hospitals=doctors_hospitals.flatten.uniq if doctors_hospitals				
      @doctors=[]
      doctors_hospitals.each{|x| 
        doctor = Doctor.find(x,:order=>'first_name')
        @doctors<< doctor if doctor
      }
      @doctors = @doctors + @hospitals if @hospitals
      @doctors=@doctors.paginate :page => params[:page], :per_page => 5
    else
      @doctors = Doctor.paginate :page => params[:page], :per_page => 5
    end	
  end
  
  def work_in_progress
  end
	
  private
  
  def find_patient    
    @patient = !current_patient.nil? ? current_patient : nil
  end
  
end
