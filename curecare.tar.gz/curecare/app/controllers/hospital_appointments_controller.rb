class HospitalAppointmentsController < ApplicationController
  layout 'hospital', :except=>[:new]  
  include UserLoginAuthenticatedSystem
  before_filter :login_required, :only=>[:index], :except=>[:auto_complete_for_patient_name]
  before_filter :valid_user, :except=>[:auto_complete_for_patient_name]
  before_filter :find_hospital, :only=>[:index,:rotate_calendar,:new,:create]
  before_filter :find_doctor, :only=>[:new,:create]
  before_filter :find_staff
  #protect_from_forgery :except=>[:auto_complete_for_patient_name, :index]  
  
  def auto_complete_for_patient_name
    @patients = []    
    search = params[:patient][:name].gsub(" ","") + '%'    
    @patients = Patient.find(:all,:conditions=>["first_name like '"+search.to_s+"%' or last_name like '"+search.to_s+"%'"])    
    render :partial=> "entries" 
  end

  def index
    @date = !params[:date].nil? ? params[:date].to_date : Date.today       
    @hospital_doctors = @hospital.doctors.paginate :page => params[:page], :per_page => 5, :order=>'first_name'    
    @doctors = @hospital_doctors
    @doctor_availabilities=[]
    @hospital_doctors.each{|hd|
      @doctor_availabilities << hd.availabilities.find(:all,:order=>"start_time")             
    }     
  end
  
  def rotate_calendar    
    if !params[:sid].nil? && !params[:sid].empty? && params[:sid] != "all"
      @hosp_doctors = @hospital.doctors       
      @doctors = @hospital.doctors.paginate :page => params[:page], :per_page => 5, :order=>'first_name'
      @specialty = Specialty.find(params[:sid])    
      @specialty_doctors = @specialty.doctors                
      @hospital_doctors = @hosp_doctors & @specialty_doctors
      @hospital_doctors = @hospital_doctors.paginate :page => params[:page], :per_page => 5, :order=>'first_name' 
    else
      @hospital_doctors = @hospital.doctors.paginate :page => params[:page], :per_page => 5, :order=>'first_name' 
      @doctors = @hospital_doctors
    end    
    @date= params[:date].to_date if params[:date]    
    render :update do |page|
      page.replace_html "calendar_content", :partial=>"appointments"
    end
  end
  
  def new        
    if params[:date]
      date = params[:date]
      date = date.scan(/(....)(..)(..)(..)(..)(..)(..)/).flatten
      show_date = Date.new(date[0].to_i,date[1].to_i,date[2].to_i)
      start_time = date[3] + ":" + date[4]
      end_time = date[5] + ":" + date[6]
      @start_time = "#{show_date} #{start_time}".to_time.strftime("%I:%M %p")
      @end_time = "#{show_date} #{end_time}".to_time.strftime("%I:%M %p")
      @date = show_date.strftime("%d/%m/%Y")
      @week = !params[:week_no].nil? ? params[:week_no] : nil
      @day = !params[:day].nil? ? params[:day] : nil
    end
  end
  
  def create    
    assignments
    if !@patient_email.nil? && !@patient_email.empty?
      @user = UserLogin.find(:first,:conditions=>"email like '"+@patient_email+"%%'")
      @patient = !@user.nil? ? @user.patient : nil
      if @patient.nil?     
        create_new_patient_account
        PatientMailer.deliver_doctor_appointment_patient_confirmation(@user,request,@patient_pwd)
      end
      create_appointment        
      AppointmentMailer.deliver_appointment_confirmation(@user,@doctor,request,@appointment,@hospital)
      flash[:notice] = "Appointment booked successfully"             
      redirect_to hospital_appointments_path(@hospital.id,:date=>@date.strftime("%Y-%m-%d"))
    else
      flash[:notice] = "Appointment booking failed"                         
    end
  end
  
  def assignments
    @hospital_id = params[:hospital_id]
    @doctor_id = params[:doctor_id]    
    @patient_email = params[:patient_email]
    date = params[:date]
    date = date.split("/")    
    @date = Date.new(date[2].to_i,date[1].to_i,date[0].to_i)    
    @name = params[:patient][:name]
    @for_reason = params[:for]
    @phone = params[:patient_phone]
    @start_time = params[:start_time]
    @end_time = params[:end_time]
    @week = !params[:week].nil? ? params[:week] : nil
    @day = !params[:day].nil? ? params[:day] : nil
    @route_date = !@day.nil? ? (@date-@day.to_i).strftime("%Y%m%d") : @date
    url_date = @date.strftime("%Y%m%d")
    start_time = "#{@date} #{@start_time}".to_time.strftime("%H:%M")
    end_time = "#{@date} #{@end_time}".to_time.strftime("%H:%M")
    app_date = "#{url_date} #{start_time} #{end_time}"
    @app_date = app_date.gsub(" ","").gsub(":","")
  end
  
  def create_new_patient_account
    @user = UserLogin.new()
    generate_random_password
    @user.email = @patient_email
    @user.password = @password
    @user.password_confirmation=@password
    @user.save
    @patient_pwd = @password
    @patient = Patient.new()
    @patient.first_name = @name
    @patient.user_login_id = @user.id
    @patient.mobile_number = @phone
    @patient.save
  end
  
  def generate_random_password
    alphanumerics = [('0'..'9'),('a'..'z')].map {|range| range.to_a}.flatten
    rand=(0...7).map { alphanumerics[Kernel.rand(alphanumerics.size)] }.join    
    encrypted_string= rand.encrypt
    @password=encrypted_string.decrypt
  end
  
  def create_appointment
    @appointment = Appointment.new()
    @appointment.doctor_id = @doctor_id
    @appointment.patient_id = @patient.id
    @appointment.hospital_id = @hospital_id
    @appointment.appointment_date = @date
    @appointment.start_time = @start_time
    @appointment.end_time = @end_time
    @appointment.reason_for_visit = @for_reason
    @appointment.flag = 4
    @appointment.save
    @hosptial_patient = HospitalPatient.find(:first,:conditions=>["patient_id=? and hospital_id=?",@patient.id,@hospital_id])
    if @hosptial_patient.nil?
      @hosptial_patient = HospitalPatient.new()
      @hosptial_patient.patient_id=@patient.id
      @hosptial_patient.hospital_id=@hospital_id
      @hosptial_patient.save   
    end
    doctor_patient = DoctorPatient.find(:first,:conditions=>["doctor_id=? and patient_id=?",@doctor_id,@patient.id])
    if doctor_patient.nil? 
      doctor_patient = DoctorPatient.new()
      doctor_patient.doctor_id = @doctor_id
      doctor_patient.patient_id = @patient.id
      doctor_patient.type_of_relation = 1
      doctor_patient.save
    end    
  end
  
  private
  
  def find_doctor
    @doctor=Doctor.find(params[:doctor_id])  
  end
  
  def find_hospital
    @hospital=Hospital.find(params[:hospital_id])
  end
	
  def find_staff
    @hospital_staff=!staff.nil? ? staff : nil
  end
  
	
end
