class HospitalDoctorsController < ApplicationController
  layout "hospital"
  
  include UserLoginAuthenticatedSystem  
  cache_sweeper :fragment_cache_sweeper, :only => [:create, :update]
  before_filter :login_required, :only=>[:index]
  before_filter :valid_user
  before_filter :find_doctor, :only=>[:index, :new, :create, :edit, :update, :destroy_holidays,:edit_holiday]
  before_filter :find_hospital, :only=>[:index, :new, :create, :edit, :update, :destroy_holidays, :specialty_doctor,:destroy_doctors,:edit_holiday]
  
  
  def index
    @doctors = @hospital.doctors.find(:all,:order=>"first_name")    
  end
  
  def specialty_doctor     
    if params[:sid] != "all"
      @hospital_doctors = @hospital.doctors    
      @specialty = Specialty.find(params[:sid])    
      @specialty_doctors = @specialty.doctors    
      @doctors = @hospital_doctors & @specialty_doctors        
    else
      @doctors = @hospital.doctors.find(:all,:order=>"first_name")    
    end    
    render :update do |page|
      page.replace_html "list", :partial=>"list_doctors"
    end 
  end
  
  def destroy_doctors       
    if params[:all_check]
      params[:all_check].each{|c| 
        availabilities = Availability.find(:all,:conditions=>["doctor_id=? and hospital_id=?",c,@hospital.id])      
        availabilities.each{|a| a.destroy}
        doctor_hospitals = DoctorHospital.find(:all,:conditions=>["doctor_id=? and hospital_id=?",c,@hospital.id])      
        doctor_hospitals.each{|dh| dh.destroy}        
      }      
      if !params[:speciality][:id].nil? && !params[:speciality][:id].empty?
        @hospital_doctors = @hospital.doctors    
        @specialty = Specialty.find(params[:speciality][:id])    
        @specialty_doctors = @specialty.doctors    
        @doctors = @hospital_doctors & @specialty_doctors        
      else  
        @doctors = @hospital.doctors.find(:all,:order=>"first_name")    
      end
      render :update do |page|
        page.replace_html "list", :partial=>"list_doctors"
      end 
    end   
  end
  
  def new       
    @sub_tab = params[:sub_tab]
    if @sub_tab == "profile"       
      @doctor_titles = ['Dr', 'Mr', 'Mrs', 'Miss']
      @specialities = Specialty.find(:all,:order=>"name")    
      @doctor_specialities = @doctor_memberships = @doctor_educations = []       
    elsif @sub_tab == "contact"       
      find_all_cities
    end
  end
  
  def create         
    @sub_tab = params[:sub_tab]
    @user_login = UserLogin.new(params[:user_login])              
    if @sub_tab == "profile"     
      create_profile
    elsif @sub_tab == "contact"
      find_all_cities
      create_contact_details      
    elsif @sub_tab == "availability"
      create_availability
    elsif @sub_tab == "notification"
      create_notification
    elsif @sub_tab == "holiday"
      create_holidays
    end
  end
  
  def create_profile
    profile_assignments
    if @user_login.valid? && @user_login.errors.empty?                
      @user_login.save
      @user_login.doctor = Doctor.create(:salutation=>@doctor_salutation, :first_name=> @doctor_first_name, :last_name=> @doctor_last_name, :suffix=> @doctor_suffix, :professional_summary=> @doctor_professional_summary)        
      @user_login.doctor.doctor_specialties << @doctor_specialities      
      @user_login.doctor.educations << @doctor_educations      
      @user_login.doctor.professional_memberships << @doctor_memberships    
      DoctorMailer.deliver_email_confirmation(@user_login,request)        
      flash[:notice] = "Doctor profile created successfully and check email to activate the doctor account"
      redirect_to hospital_doctor_edit_profile_path(@hospital.id, @user_login.doctor.id, "profile")
    else               
      flash.now[:error]="Doctor profile has not been created."
      render :action => 'new'
    end
  end
  
  def profile_assignments
    @doctor_titles = ['Dr', 'Mr', 'Mrs', 'Miss']
    @specialities = Specialty.find(:all,:order=>"name")            
    @doctor_salutation = params[:doctor][:salutation]
    @doctor_first_name = params[:doctor][:first_name]
    @doctor_last_name = params[:doctor][:last_name]
    @doctor_suffix = params[:doctor][:suffix]
    @doctor_professional_summary = params[:doctor][:professional_summary]  
    
    @doctor_specialities = []
    set_primary=0
    params[:speciality].collect{|x| 
      @doctor_specialities << DoctorSpecialty.new(:specialty_id => x['id'],:flag=> set_primary==0 ? 1 : 0)
      set_primary += 1
    }   
    @doctor_educations = []
    params[:education].collect{|x| @doctor_educations << Education.new(:detail => x['detail']) if !x['detail'].nil? and !x['detail'].empty?}   
    
    @doctor_memberships = []
    params[:professional_membership].collect{|x| @doctor_memberships << ProfessionalMembership.new(:detail => x['detail']) if !x['detail'].nil? and !x['detail'].empty?}   

  end  
  
  def create_contact_details
    contact_details_assignments        
    if @user_login.errors.empty? && @doctor_contacts.errors.empty?
      @user_login.save
      @doctor_contacts.user_login_id = @user_login.id
      @doctor_contacts.save
      DoctorMailer.deliver_email_confirmation(@user_login,request)        
      flash[:notice] = "Doctor contact details created successfully."
      redirect_to hospital_doctor_edit_profile_path(@hospital.id, @user_login.doctor.id, "contact")
    else          
      flash.now[:error]="Doctor contact details has not been created."
      @doctor = @doctor_contacts
      render :action => 'new'
    end
  end
 
  def contact_details_assignments    
    @doctor_address = params[:doctor][:address]
    @doctor_city = params[:doctor][:city_id]
    @doctor_state = params[:doctor][:state]
    @doctor_pincode = params[:doctor][:pincode]
    @doctor_email = params[:doctor][:email]
    @doctor_home_number = params[:doctor][:home_number]
    @doctor_website = params[:doctor][:website]
    @doctor_emergency_number = params[:doctor][:emergency_number]
    @doctor_contacts = !@doctor.nil? ? @doctor : Doctor.new(params[:doctor])
    @doctor_contacts.step = 3
    @user_login.valid?
    @doctor_contacts.valid?
  end
  
  def create_availability    
    availability_assignments
    @consulting_times = params[:time] 
    if @user_login.valid? and @slot_error_val=="0"
      @user_login.save        
      @doctor = @user_login.doctor = Doctor.create()
      for i in 0..@start_times.length-1           
        @consulting_details << Availability.new(:start_time=>@start_times[i].to_s,:end_time=>@end_times[i].to_s,:day=>@consulting_days[i].to_s,:add_another=>@another[i].to_s,:hospital_id=>@hospital.id)
      end    
      @doctor_hospital = DoctorHospital.new(:hospital_id=>@hospital.id,:slot_duration=>@hospital_slot_duration)            
      @doctor.doctor_hospitals << @doctor_hospital       
      @doctor.availabilities << @consulting_details
      flash[:notice]="Doctor availability has added successfully"
      redirect_to hospital_doctor_edit_profile_path(@hospital.id, @user_login.doctor.id, "availability")
    else       
      flash.now[:error]="Doctor availability has not created."
      render :action => "new" and return true 
    end
  end
  
  def availability_assignments    
    @req_lable = 1        
    @hospital_slot_duration = params[:slot][:time]
    @slot_error_val = params[:slot_error_val]
    consulting_days = []
    params[:day].each{|key,value| consulting_days << key if value=="1"}                
    @consulting_details = []
    @start_times = []
    @end_times = []
    @consulting_days = []
    @another = []
    for day in consulting_days                  
      params[:time][day]['start'].collect{|s| 
        @start_times <<  s 
        @consulting_days << day.to_i        
      }
      params[:time][day]['start'].each_index{|k| @another << k} 
      params[:time][day]['end'].collect{|e| @end_times << e}      
    end  
    @req_lable = @req_lable + @another.max.to_i
  end
  
  def create_notification
    @doctor = !@doctor.nil? ? @doctor : Doctor.new(params[:doctor])
    @doctor.step = 2
    @user_login.valid?
    @doctor.valid?     
    if @user_login.errors.empty? && @doctor.errors.empty?
      @user_login.save
      @doctor.user_login_id = @user_login.id
      @doctor.save
      DoctorMailer.deliver_email_confirmation(@user_login,request)        
      flash[:notice] = "Doctor notifications created successfully."
      redirect_to hospital_doctor_edit_profile_path(@hospital.id, @user_login.doctor.id, "notification")
    else          
      flash.now[:error]="Doctor notifications has not been created."      
      render :action => 'new'
    end
  end
  
  def create_holidays    
    @holiday=Holiday.new()
    @holiday.start_date=params[:start_date]
    @holiday.end_date=params[:end_date]
    @holiday.note=params[:holiday][:note]
    @user_login.valid?
    @holiday.valid?  
    if @user_login.errors.empty? && @holiday.errors.empty?
      @user_login.save
      @doctor = @user_login.doctor = Doctor.create()
      @doctor.holidays<<@holiday
      flash[:notice] = "Doctor holidays has created successfully."
      redirect_to hospital_doctor_edit_profile_path(@hospital.id, @user_login.doctor.id, "holiday")
    else          
      flash.now[:error]="Doctor holidays has not created."      
      render :action => 'new'
    end
  end
  
  def find_availabilities        
    @availabilities = Availability.find(:all,:conditions=>["doctor_id=? and hospital_id=?",@doctor.id,@hospital.id],:order=>"day,start_time")          
    @doctor_hospital = DoctorHospital.find(:first,:conditions=>["doctor_id=? and hospital_id=?",@doctor.id,@hospital.id])          
    @req_lable = 1
    @consulting_times = Hash.new    
    avail_days = []
    max_lables = []
    @availabilities.each{|d| avail_days << d.day}          
    avail_days = avail_days.uniq if !avail_days.nil?    
    avail_days.each{|t|
      day_times = []    
      @availabilities.each{|d|               
        if d.day == t          
          start_time = d.start_time.strftime("%I:%M %p")
          end_time = d.end_time.strftime("%I:%M %p")                
          day_times << [start_time, end_time]            
        end 
        max_lables << day_times.length
      }            
      @req_lable = max_lables.max.to_i
      @consulting_times[t] = day_times
    }      
  end
  
 
  def edit
    @sub_tab = params[:sub_tab]
    @user_login = @doctor.user_login if @doctor
    if @sub_tab == "profile"
      @doctor_titles = ['Dr', 'Mr', 'Mrs', 'Miss']
      @specialities = Specialty.find(:all,:order=>"name")  
      @doctor_salutation = @doctor.salutation
      @doctor_educations = @doctor.educations
      @doctor_memberships = @doctor.professional_memberships
      @doctor_specialities = @doctor.doctor_specialties               
    elsif @sub_tab == "contact"       
      find_all_cities
    elsif @sub_tab == "availability"
      find_availabilities
    elsif @sub_tab == "holiday"
      @holidays_list=@doctor.holidays
    end    
  end
  
  def update
    @sub_tab = params[:sub_tab]
    @user_login = @doctor.user_login if @doctor
    if @sub_tab == "profile" 
      profile_assignments       
      update_profile
    elsif @sub_tab == "contact"
      find_all_cities      
      update_contact_details
    elsif @sub_tab == "availability"
      update_availabilities
    elsif @sub_tab == "notification"
      update_notifications
    elsif @sub_tab == "holiday"
      @holidays_list=@doctor.holidays
      update_holidays
    end
    
  end
  
  def update_profile
    if @doctor.update_attributes(params[:doctor])               
      @doctor.doctor_specialties.destroy_all            
      @doctor.doctor_specialties << @doctor_specialities      
      @doctor.educations.destroy_all  
      @doctor.educations << @doctor_educations      
      @doctor.professional_memberships.destroy_all            
      @doctor.professional_memberships << @doctor_memberships    
      flash[:notice]="Doctor profile updated successfully."
      redirect_to hospital_doctor_edit_profile_path(@hospital.id, @doctor.id, "profile")
    else
      flash.now[:error]="Doctor profile has not been updated."
      render :action=>'edit'
    end
  end
  
  def update_contact_details
    @doctor.step = 3    
    if @doctor.update_attributes(params[:doctor])               
      flash[:notice]="Doctor contact details updated successfully."
      redirect_to hospital_doctor_edit_profile_path(@hospital.id, @doctor.id, "contact")
    else
      flash.now[:error]="Doctor contact details has not been updated."
      render :action=>'edit'
    end
  end
  
  def update_notifications
    @doctor.step = 2    
    if @doctor.update_attributes(params[:doctor])               
      flash[:notice]="Doctor notifications updated successfully."
      redirect_to hospital_doctor_edit_profile_path(@hospital.id, @doctor.id, "notification")
    else
      flash.now[:error]="Doctor notifications has not been updated."
      render :action=>'edit'
    end
  end
  
  def update_availabilities    
    availability_assignments
    avail_validation = validate_availability_time(@doctor,@start_times,@end_times,@consulting_days,@another,@hospital)
    @consulting_times = Hash.new        
    unique_days = @consulting_days.uniq if !@consulting_days.nil?
    unique_days.each{|u|
      day_times = [] 
      for i in 0..@consulting_days.length-1
        if u == @consulting_days[i]
          day_times << [@start_times[i], @end_times[i]]      
        end
      end
      @consulting_times[u] = day_times
    }   
    if avail_validation == true and @slot_error_val=="0"   
      @doctor_hospital = DoctorHospital.find(:first,:conditions=>["doctor_id=? and hospital_id=?",@doctor.id,@hospital.id])          
      for i in 0..@start_times.length-1           
        @consulting_details << Availability.new(:start_time=>@start_times[i].to_s,:end_time=>@end_times[i].to_s,:day=>@consulting_days[i].to_s,:add_another=>@another[i].to_s,:hospital_id=>@hospital.id)
      end    
      @doctor_hospital.destroy if @doctor_hospital
      @doctor_hospital = DoctorHospital.new(:hospital_id=>@hospital.id,:slot_duration=>@hospital_slot_duration)            
      @doctor.doctor_hospitals << @doctor_hospital
      @availabilities = Availability.find(:all, :conditions=>["doctor_id=? and hospital_id=?",@doctor.id,@hospital.id])
      @availabilities.each{|a|a.destroy} if !@availabilities.nil? and !@availabilities.empty?
      @doctor.availabilities << @consulting_details
      flash[:notice]="Doctor availability updated successfully."
      redirect_to hospital_doctor_edit_profile_path(@hospital.id, @doctor.id, "availability")
    else              
      flash.now[:error]="Doctor availability has not been updated."
      render :action => "edit" and return true 
    end
  end
  
  def update_holidays    
       if params[:holiday_id]
        @holiday=Holiday.find_by_id(params[:holiday_id])
        holidays = []
      else
        holidays=!@doctor.holidays.nil? ? @doctor.holidays.find(:all,:conditions=>["(? between start_date and end_date) or (? between start_date and end_date)",params[:start_date].to_date,params[:end_date].to_date]) : []    
      @holiday=Holiday.new()
      end
      @holiday.start_date=params[:start_date]
      @holiday.end_date=params[:end_date]
      @holiday.note=params[:holiday][:note]
      if holidays.empty? && @holiday.valid? 
        @doctor.holidays << @holiday
        flash[:notice]="Doctor holidays included successfully."
        redirect_to hospital_doctor_edit_profile_path(@hospital.id, @doctor.id, "holiday")
      else
        str = holidays.empty? ? "Doctor holidays has not been updated." : "Selected dates were already exists in holidays.Please select another date."
        flash.now[:error]= str      
        render :action=>'edit'
    end    
  end
  
  def destroy_holidays
    @holidays_list=@doctor.holidays if !@doctor.nil?
     if params[:all_check] && !params[:all_check].empty?
      flash[:notice]='Your holiday has been deleted.'
      params[:all_check].each{|h| 
      @holiday=Holiday.find(h)
      @holiday.destroy
      }
    render :update do |page|
      page.replace_html "holidays_list", :partial=>"show_holidays"
    end  
  end
  end
   
   def edit_holiday
    @holiday=Holiday.find(params[:holiday_id])
    render :update do |page|
    page.replace_html "doctor_holiday", :partial=>"edit_doctor_holiday"
    end
  end
  
   
  
  def find_all_cities
    @cities = City.find(:all,:order=>"name")                    
  end
  
  def validate_availability_time(doctor_id,start_times,end_times,consulting_days,another,hospital)   
    val = true
    doctor = Doctor.find(doctor_id)
    if !hospital.nil? and !hospital.id.nil?
      available_times = doctor.availabilities.find(:all,:conditions=>["hospital_id != ?",hospital.id])
    else
      available_times = doctor.availabilities
    end    
    days = []    
    available_times.collect{|x| days << x.day }
    days = days.uniq if days
    avail_hash = {}
    days.each{|d|      
      st_times = []
      ed_times = []
      available_times.collect{|x|                 
        if d == x.day 
          for t in x.start_time.strftime("%H")..x.end_time.strftime("%H")
            st_times << t if t!= (x.start_time.strftime("%H")..x.end_time.strftime("%H")).end
            ed_times << t if t== (x.start_time.strftime("%H")..x.end_time.strftime("%H")).end
          end     
        end            
      }
      avail_hash[d]=st_times,ed_times
    }        
    @errors = Hash.new
    for i in 0..start_times.length-1
      if avail_hash.keys.include?(consulting_days[i])        
        st = avail_hash[consulting_days[i]][0].include?(Time.parse(start_times[i]).strftime("%H"))
        ed = avail_hash[consulting_days[i]][1].include?(Time.parse(end_times[i]).strftime("%H"))              
        if st==true || ed==true
          val = false
          error = "error_#{consulting_days[i]}_#{another[i]}"
          @errors[error] = "Time range between #{start_times[i]} to #{end_times[i]} has already choosen to other location"
        end
      end
    end
    return val
  end
  
  private
    
  def find_doctor
    @doctor= !params[:doctor_id].nil? ? Doctor.find(params[:doctor_id]) : nil
  end
        
  def find_hospital
    @hospital= !params[:hospital_id].nil? ? Hospital.find(params[:hospital_id]) : nil
  end
  
end

