class HospitalsController < ApplicationController
  include UserLoginAuthenticatedSystem
  cache_sweeper :fragment_cache_sweeper, :only => [:create]
  before_filter :login_required, :except=>[:show,:new,:create,:activate,:rotate_availability_calender]  
  layout :change_layout
  before_filter :find_hospital, :only=>[:show, :rotate_availability_calender]  

  def index
  end

  def show
    @patient=current_patient
    @date=Date.today
    @hospital_doctors=@hospital.doctor_hospitals
    @availabilites=@hospital.availabilities
  end

  def new
		
  end
	
  def create
    cookies.delete :auth_token
    # protects against session fixation attacks, wreaks havoc with 
    # request forgery protection.
    # uncomment at your own risk
    # reset_session
    @user_login = UserLogin.new(params[:user_login])
    @user_login.save
    if @user_login.errors.empty?
      #self.current_doctor = @doctor
      @user_login.hospital = Hospital.create(:email=>@user_login.email)
      HospitalMailer.deliver_email_confirmation(@user_login,request)
      flash[:notice] = "Thanks for signing up! <br> Please check your email to complete your registration"
      redirect_to new_user_login_path
    else
      render :action => 'new'
    end
  end
	

  def rotate_availability_calender
    @date=params[:date].to_date
    @hospital_doctors=@hospital.doctor_hospitals
    @availabilites=@hospital.availabilities
    render :update do |page|
      page.replace_html "availability_calendar", :partial=>"consulting_hours"
    end
  end
  
  def activate
    self.current_user_login = params[:activation_code].blank? ? false : UserLogin.find_by_activation_code(params[:activation_code])
    if logged_in? && !current_user_login.active?
      current_user_login.activate
      flash[:notice] = "Your account has been activated"      
      redirect_to hospital_service_profile_path(self.current_user_login.hospital.id)
    else
      flash[:notice] = "This is an invalid activation code."
      redirect_to new_user_login_path
    end
  end
	
  def change_layout
    if (action_name == "new" || action_name == "create")
      "login"
    elsif(action_name == "show")
      "home"
    else
      "hospital"
    end
  end
  
  
  private
  def find_hospital
    @hospital=Hospital.find(params[:id])  
  end
  
  def find_layout
    ["show"].include?(action_name) ? "home" : "hospital"
  end
  
end
