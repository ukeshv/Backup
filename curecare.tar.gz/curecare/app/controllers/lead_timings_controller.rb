class LeadTimingsController < ApplicationController
  layout 'doctor'  
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:show, :update]
	before_filter :valid_user
  before_filter :find_doctor, :only=>[:show,:update]
  
  def show
    
  end
  
  def update
    @doctor.min_lead_time=params[:doctor][:min_lead_time]
    @doctor.max_lead_time=params[:doctor][:max_lead_time]
    @doctor.step = 4
    if @doctor.valid?	 
      @doctor.save
      flash[:notice]='Minimum and Maximum lead time has been saved.'
      redirect_to doctor_lead_timing_path(@doctor)
    else
      flash.now[:error]='Minimum and Maximum lead time has not been saved.'
      render :action=>'show'
    end
  end	
  
  private
    
  def find_doctor
    @doctor=Doctor.find(params[:doctor_id])  
  end
end
