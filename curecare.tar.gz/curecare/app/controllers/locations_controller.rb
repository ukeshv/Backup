class LocationsController < ApplicationController
  layout 'doctor' 
  #protect_from_forgery :except=>[:auto_complete_for_hospital_name,:find_hospital_address]
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  cache_sweeper :fragment_cache_sweeper, :only => [:create,:update]
  before_filter :login_required, :only=>[:index,:show, :update], :except=>[:auto_complete_for_hospital_name,:find_hospital_address]
  before_filter :valid_user, :except=>[:auto_complete_for_hospital_name,:find_hospital_address]
  before_filter :find_doctor, :only=>[:index,:create, :assignments, :edit, :show,:update,:add_new_locations]
  
  def auto_complete_for_hospital_name
    @hospitals = []    
    search = params[:hospital][:name].gsub(" ","") + '%'    
    @hospitals = Hospital.find(:all,:conditions=>["name like '"+search.to_s+"%'"])    
    render :partial=> "entries" 
  end
  
  def find_hospital_address    
    search = params[:hospital_name]    
    @hospital = Hospital.find(:first,:conditions=>["name like '"+search.to_s+"'"])        
  end
  
  def index     
    @cities = City.find(:all,:order=>"name")                    
    @req_lable = 1
    @hospital = Hospital.new
    @hospitals = @doctor.hospitals.length>0 ? @doctor.hospitals : nil        
  end
  
  def create 
    if !params[:hospital][:name].nil? and !params[:hospital][:city_id].nil? and !params[:hospital][:address].nil?
      ex_hospital = Hospital.find(:first, :conditions=>["name=? and city_id=? and address=?", params[:hospital][:name], params[:hospital][:city_id], params[:hospital][:address]])
    end    
    hospital = !ex_hospital.nil? ? ex_hospital : Hospital.new
    assignments(hospital)
    avail_validation = validate_availability_time(@doctor,@start_times,@end_times,@consulting_days,@another,nil)
    @consulting_times = params[:time] 
    if @hospital.valid? and avail_validation == true and @slot_error_val=="0"
      @hospital.save  
      create_new_hospital_account(@hospital)  if (@hospital.user_login_id.nil?)
      for i in 0..@start_times.length-1           
        @consulting_details << Availability.new(:start_time=>@start_times[i].to_s,:end_time=>@end_times[i].to_s,:day=>@consulting_days[i].to_s,:add_another=>@another[i].to_s,:hospital_id=>@hospital.id)
      end    
      @doctor_hospital = DoctorHospital.new(:hospital_id=>@hospital.id,:slot_duration=>@hospital_slot_duration)            
      @doctor.doctor_hospitals << @doctor_hospital       
      @doctor.availabilities << @consulting_details
      flash[:notice]="#{@hospital.name} has been added successfully to your practice locations"
      redirect_to doctor_locations_path(@doctor.id)
    else  
      flash.now[:error]="Please fill the required details below."
      render :action => "index" and return true 
    end    
  end
  
  def create_new_hospital_account(hosp)    
    @user = UserLogin.new()
    generate_random_password
    @user.email = hosp.email
    @user.password = @password
    @user.password_confirmation=@password
    @user.save
    hospital = Hospital.find(hosp.id)    
    hospital.update_attributes(:user_login_id => @user.id)
    @hospital_pwd = @password 
    HospitalMailer.deliver_hospital_account(@user,request,@hospital_pwd)
  end
  
  def generate_random_password
    alphanumerics = [('0'..'9'),('a'..'z')].map {|range| range.to_a}.flatten
    rand=(0...7).map { alphanumerics[Kernel.rand(alphanumerics.size)] }.join    
    encrypted_string= rand.encrypt
    @password=encrypted_string.decrypt
  end
  
  
  def validate_availability_time(doctor_id,start_times,end_times,consulting_days,another,hospital)   
    val = true
    doctor = Doctor.find(doctor_id)
    if !hospital.nil? and !hospital.id.nil?
      available_times = doctor.availabilities.find(:all,:conditions=>["hospital_id != ?",hospital.id])
    else
      available_times = doctor.availabilities
    end    
    days = []    
    available_times.collect{|x| days << x.day }
    days = days.uniq if days
    avail_hash = {}
    days.each{|d|      
      st_times = []
      ed_times = []
      available_times.collect{|x|                 
        if d == x.day 
          for t in x.start_time.strftime("%H")..x.end_time.strftime("%H")
            st_times << t if t!= (x.start_time.strftime("%H")..x.end_time.strftime("%H")).end
            ed_times << t if t== (x.start_time.strftime("%H")..x.end_time.strftime("%H")).end
          end     
        end            
      }
      avail_hash[d]=st_times,ed_times
    }           
    @errors = Hash.new
    
    # same day validation here
      real = consulting_days
      b = real.to_s
      a = real.uniq
      vall = []
      index_values = []
      for i in 0..a.length-1
        arry = b.scan("#{a[i]}")
        vall <<  arry.uniq if arry.length > 1	
      end
      vall = vall.flatten

      for k in 0..vall.length-1
        val_now = vall[k].to_i
        count = 0 
        loc_arry = []
        for j in real		
            if val_now == j
              loc_arry << count		
            end
            count +=1
            end
        index_values << loc_arry
      end 
    for iv in index_values
      inner_index_arry = iv
      first_array = []
      sec_array = []
      for inner_index in 0..iv.length-1        
        if inner_index == 0                   
          for fa in Time.parse(start_times[inner_index_arry[inner_index]]).strftime("%H")..Time.parse(end_times[inner_index_arry[inner_index]]).strftime("%H")            
            first_array << fa.to_i
          end          
        else                    
          for sa in Time.parse(start_times[inner_index_arry[inner_index]]).strftime("%H")..Time.parse(end_times[inner_index_arry[inner_index]]).strftime("%H")            
            sec_array << sa.to_i
          end          
        end  
          for i in 0..(sec_array.length-1)                            
              val = (first_array.include?(sec_array[i]) ? ((sec_array.index(sec_array[i])==0 or sec_array.index(sec_array[i]) == sec_array.length-1) ? true : false ) : true)  if val == true
              error = "error_#{consulting_days[inner_index_arry[inner_index]]}_#{another[inner_index_arry[inner_index]]}"
             @errors[error] = "Time overlapping between #{start_times[inner_index_arry[inner_index]]} #{end_times[inner_index_arry[inner_index]]}"
          end	
      end
    end  

    if val == true 
        for i in 0..start_times.length-1
          if avail_hash.keys.include?(consulting_days[i])    
            st = avail_hash[consulting_days[i]][0].include?(Time.parse(start_times[i]).strftime("%H"))
            ed = avail_hash[consulting_days[i]][1].include?(Time.parse(end_times[i]).strftime("%H"))              
            if st==true || ed==true
              val = false
              error = "error_#{consulting_days[i]}_#{another[i]}"
              @errors[error] = "Time range between #{start_times[i]} to #{end_times[i]} has already choosen to other location"
            end
          end
        end
    end
      
    return val
  end
  
  def edit     
    @hospitals = @doctor.hospitals.length>0 ? @doctor.hospitals : nil    
    @cities = City.find(:all,:order=>"name")                    
    @req_lable = 1
    @hospital = Hospital.find(params[:id])
    @doctor_hospital = DoctorHospital.find(:first,:conditions=>["doctor_id=? and hospital_id=?",params[:doctor_id],params[:id]])    
    @hospital_availabilities = @hospital.availabilities.find(:all, :conditions=>["doctor_id=?",@doctor.id])
    @availabilities = !@hospital_availabilities.nil? ? @hospital_availabilities : []        
    @consulting_times = Hash.new    
    avail_days = []
    max_lables = []
    @availabilities.each{|d| avail_days << d.day}          
    avail_days = avail_days.uniq if !avail_days.nil?    
    avail_days.each{|t|
      day_times = []    
      @availabilities.each{|d|               
        if d.day == t          
          start_time = d.start_time.strftime("%I:%M %p")
          end_time = d.end_time.strftime("%I:%M %p")                
          day_times << [start_time, end_time]            
        end 
        max_lables << day_times.length
      }            
      @req_lable = max_lables.max.to_i
      @consulting_times[t] = day_times
    }        
  end 
  
  def update           
    @doctor_hospital = DoctorHospital.find(:first,:conditions=>["doctor_id=? and hospital_id=?",params[:doctor_id],params[:id]])            
    assignments(Hospital.find(params[:id]))  
    avail_validation = validate_availability_time(@doctor,@start_times,@end_times,@consulting_days,@another,@hospital)
    @consulting_times = Hash.new        
    unique_days = @consulting_days.uniq if !@consulting_days.nil?
    unique_days.each{|u|
      day_times = [] 
      for i in 0..@consulting_days.length-1
        if u == @consulting_days[i]
          day_times << [@start_times[i], @end_times[i]]      
        end
      end
      @consulting_times[u] = day_times
    }   
    
    #check timeslot in same location
    if @hospital.valid? and avail_validation == true and @slot_error_val=="0" 
      @hospital.save               
      for i in 0..@start_times.length-1           
        @consulting_details << Availability.new(:start_time=>@start_times[i].to_s,:end_time=>@end_times[i].to_s,:day=>@consulting_days[i].to_s,:add_another=>@another[i].to_s,:hospital_id=>@hospital.id)
      end    
      @doctor_hospital.destroy
      @doctor_hospital = DoctorHospital.new(:hospital_id=>@hospital.id,:slot_duration=>@hospital_slot_duration)            
      @doctor.doctor_hospitals << @doctor_hospital
      @availabilities = Availability.find(:all, :conditions=>["doctor_id=? and hospital_id=?",params[:doctor_id],params[:id]])
      @availabilities.each{|a|a.destroy} if !@availabilities.nil? and !@availabilities.empty?
      @doctor.availabilities << @consulting_details
      flash[:notice]="#{@hospital.name} details has been modified successfully"
      redirect_to doctor_locations_path(@doctor.id)
    else              
      flash.now[:error]= (avail_validation == false) ? "Time slot overlapping" : "Please fill the required details below."
      render :action => "edit" and return true 
    end
  end 
  
  def assignments(hosp)    
    @hospital = hosp
    @req_lable = 1  
    @slot_error_val = params[:slot_error_val]
    @cities = City.find(:all,:order=>"name")
    @hospitals = @doctor.hospitals.length>0 ? @doctor.hospitals : nil        
    @hospital.name = params[:hospital][:name]    
    @hospital.address = params[:hospital][:address]
    @hospital.city_id = params[:hospital][:city_id]
    @hospital.state = params[:hospital][:state]
    @hospital.pincode = params[:hospital][:pincode]
    @hospital.email = params[:hospital][:email]
    @hospital.phone_number = params[:hospital][:phone_number]
    @hospital.website = params[:hospital][:website]
    @hospital.step=1
    @hospital_slot_duration = params[:slot][:time]
    consulting_days = []
    params[:day].each{|key,value| consulting_days << key if value=="1"}                
    @consulting_details = []
    @start_times = []
    @end_times = []
    @consulting_days = []
    @another = []
    for day in consulting_days                  
      params[:time][day]['start'].collect{|s| 
        @start_times <<  s 
        @consulting_days << day.to_i        
      }
      params[:time][day]['start'].each_index{|k| @another << k} 
      params[:time][day]['end'].collect{|e| @end_times << e}      
    end  
    @req_lable = @req_lable + @another.max.to_i
  end
  
  def show  
    
  end 
  
  
  
  private
    
  def find_doctor
    @doctor=Doctor.find(params[:doctor_id])  
  end
  
end

