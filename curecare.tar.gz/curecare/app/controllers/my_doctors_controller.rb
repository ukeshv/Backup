class MyDoctorsController < ApplicationController
  layout "patient"
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:index]
	before_filter :valid_user
  before_filter :find_patient, :only=>[:index]
  
  def index
    @doctors=@patient.doctors.paginate :page => params[:page], :per_page => 5
  end
  
	def show
		@patient=current_patient
    @date=Date.today
		@doctor=Doctor.find(params[:id])
    @doctor_hospitals=@doctor.doctor_hospitals
    @availabilites=@doctor.availabilities
		render :template=>'/doctors/show'
	end
  
  private
    
  def find_patient
    @patient=Patient.find(params[:patient_id])  
  end
end
