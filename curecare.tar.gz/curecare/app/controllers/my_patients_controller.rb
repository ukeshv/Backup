class MyPatientsController < ApplicationController
  layout :change_layout, :except=>[:edit]
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:index], :except=>[:patient_details,:update,:letter_patient_details]
  before_filter :valid_user, :except=>[:patient_details,:update,:letter_patient_details]
  before_filter :find_doctor, :only=>[:index,:patient_details,:edit,:update,:letter_patient_details]
  before_filter :find_patient, :only=>[:patient_details,:edit,:update]
  before_filter :find_hospital, :only=>[:index,:letter_patient_details]
  before_filter :find_staff, :only=>[:index,:patient_details]
  
  def index
    if @doctor
      @patients = @doctor.patients.find(:all,:order=>"first_name").uniq    
    elsif @hospital
      @patients = @hospital.patients.find(:all,:order=>"first_name").uniq      
    end        
    @patient = @patients.first
    @doctor_notes = DoctorNote.find(:all,:conditions=>["patient_id=?",@patient.id])   if @patient
  end
  
  def change_layout
    if @doctor
      "doctor"
    else
      "hospital"
    end
  end

  
  def patient_details        
    @doctor_notes = DoctorNote.find(:all,:conditions=>["patient_id=?",@patient.id])   
    render :update do |page|
      page.replace_html "patient_details_area", :partial=>"details"
    end    
  end
  
  def letter_patient_details    
    let = params[:letter].gsub(" ","")    
    if @doctor
      @patients = @doctor.patients.find(:all,:conditions=>["first_name like '"+let+"%%'"],:order=>"first_name").uniq    
    elsif @hospital
      @patients = @hospital.patients.find(:all,:conditions=>["first_name like '"+let+"%%'"],:order=>"first_name").uniq    
    end    
    @patient = @patients.first    
    @doctor_notes = DoctorNote.find(:all,:conditions=>["patient_id=?",@patient.id])       
    render :update do |page|
      page.replace_html "patient_details_area", :partial=>"details"
    end  
  end
  
  def edit    
  
  end
  
  def update
    @patients=@doctor.patients    
    @doctor_note = DoctorNote.new()
    @doctor_note.doctor_id = @doctor.id
    @doctor_note.patient_id = @patient.id
    @doctor_note.on = Date.today
    @doctor_note.notes = params[:doctor_note][:notes]
    @doctor_note.save
    @doctor_notes = @doctor.doctor_notes.find(:all,:conditions=>["patient_id=?",@patient.id])   
    render :action=>"index"
  end
  
  
  private
    
  def find_doctor
    @doctor = !params[:doctor_id].nil? ? Doctor.find(params[:doctor_id]) : nil
  end
	
  def find_hospital
    @hospital = !params[:hospital_id].nil? ? Hospital.find(params[:hospital_id]) : nil
  end
  
  def find_patient
    @patient = Patient.find(params[:id])          
  end
  
  def find_staff
    @doctor_staff=!staff.nil? ? staff : nil
  end
  
  
end
