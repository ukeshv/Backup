class NotificationsController < ApplicationController
  layout 'doctor'  
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:show, :update]
	before_filter :valid_user
  before_filter :find_doctor, :only=>[:show,:update]
  
  def show
    
  end
  
  def update
    @doctor.notify_for_appointment=params[:doctor][:notify_for_appointment]
    @doctor.notify_for_cancellation=params[:doctor][:notify_for_cancellation]
    @doctor.notify_for_reschedule=params[:doctor][:notify_for_reschedule]
    @doctor.notification_email=params[:doctor][:notification_email]
    @doctor.notification_phone=params[:doctor][:notification_phone]
    @doctor.step = 2
    if @doctor.valid? 
      @doctor.save	 
      flash[:notice]='Your notifications are updated.'
      redirect_to doctor_notification_path(@doctor)
    else
      #flash.now[:error]='Your notifications are not updated.'
      render :action=>'show'
    end
  end
  
  private
    
  def find_doctor
    @doctor=Doctor.find(params[:doctor_id])  
  end
end
