class PasswordsController < ApplicationController
	layout 'login'
	include UserLoginAuthenticatedSystem  
	 before_filter :login_required,:except=>[:new,:create,:edit,:update]
	# Enter email address to recover password 
 def new
 end

 # Forgot password action
 
   def create
		return unless request.post?
    if params[:user_login][:email] =~ /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i
      @user = UserLogin.find_by_email(params[:user_login][:email])
      if @user
				@user.update_attribute(:password_reset_code,@user.forgot_password)
				PatientMailer.deliver_forgot_password(@user,request)
        flash[:notice] = "Mail has been sent to " + params[:user_login][:email] +"."
        redirect_to new_user_login_path
      else
        flash.now[:error] = "Your Email is not in Curencare Account. Please provide Curencare email"
        render :action => 'new'
      end        
    else
      flash.now[:error] = "Invalid Email"
      render :action => 'new'
    end
  end
 
 
 # Action triggered by clicking on the /reset_password/:id link recieved via email
 # Makes sure the id code is included
 # Checks that the id code matches a user in the database
 # Then if everything checks out, shows the password reset fields
 def edit
   if params[:id].nil?
     render :action => 'new'
     return
   end
   @user = UserLogin.find_by_password_reset_code(params[:id]) if params[:id]
   raise if @user.nil?
 rescue
   logger.error "Invalid Reset Code entered."
   flash[:error] = "Sorry - That is an invalid password reset code. Please check your code and try again."
   redirect_to new_user_login_path
 end
   
 # Reset password action /reset_password/:id
 # Checks once again that an id is included and makes sure that the password field isn't blank
 def update
		if params[:id].nil?
			render :action => 'new'
			return
		end
		if params[:password].blank?
			flash.now[:error] = "Password field cannot be blank."
			render :action => 'edit', :id => params[:id]
			return
		end
		@user = UserLogin.find_by_password_reset_code(params[:id]) if params[:id]
		raise if @user.nil?
		return if @user unless params[:password]
			if (params[:password] == params[:password_confirmation] && params[:password].length>5 && params[:password_confirmation].length>5) 
				@user.password_confirmation = params[:password_confirmation]
				@user.password = params[:password]
				@user.reset_password        
				flash[:notice]= @user.save ? "Password reset successfully" : "Password not reset"
			else			 
				flash.now[:error] = (params[:password].length<=5 && params[:password_confirmation].length<=5) ?  "Password should be 6 to 20 characters" : "Password mismatch"
				render :action => 'edit', :id => params[:id]
				return
			end  
		redirect_to new_user_login_path
		rescue
		flash[:notice] = "Sorry - That is an invalid password reset code. Please check your code and try again."
		redirect_to forgot_password_path
 end	
  
end
