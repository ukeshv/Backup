class PatientAppointmentsController < ApplicationController
  include UserLoginAuthenticatedSystem
  include GeoKit::Geocoders
  
  layout "patient"
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:index, :show]
	before_filter :valid_user
  before_filter :find_patient, :only=>[:index,:show]
  
  def index
		@all_doctors=Doctor.find(:all,:order=>'created_at desc',:limit=>5)
    #@appointments=Appointment.find(:all,:conditions=>['patient_id = ?',params[:patient_id]])
    @appointments=Appointment.paginate :conditions=>['patient_id = ? and is_cancel = ?',params[:patient_id],false],:page => params[:page], :per_page => 5,:order=>'created_at desc'
  end
  
  def show
    @appointments=Appointment.find(:all,:conditions=>['patient_id = ?',params[:patient_id]])
    @appointment=Appointment.find(params[:id])
    @lat,@lng=find_lat_lng(@appointment.hospital.map_address)
  end
  
  def find_lat_lng(address)            
    res=MultiGeocoder.geocode(address)
    lat = res.lat
    lng = res.lng
    lat = (!lat.nil? && !lat.blank?) ? lat : "37.4419"
    lng = (!lng.nil? && !lng.blank?) ? lng : "-122.1419"    
    return lat, lng
  end
  
  private
    
  def find_patient
    @patient=Patient.find(params[:patient_id])  
  end
end
