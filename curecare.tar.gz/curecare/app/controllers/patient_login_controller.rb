# This controller handles the login/logout function of the site.  
class PatientLoginController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem
  #protect_from_forgery :except=>[:create]
  before_filter :find_doctor, :only=>[:create]
  before_filter :find_hospital, :only=>[:create]
  def index

  end

  def create
    assignments
    if params[:book_app] == 'app_detail'
      patient_login
    else
      appointment_confirm
    end	 
  end
	
  def assignments
    @appointment_date=params[:appointment_date]
    @appointment_time=params[:appointment_time]
    specialty_id=!params[:specialty_id].nil? ? params[:specialty_id] : (!params[:specialty][:id].nil? ? params[:specialty][:id] : nil)
    @specialty_id= 	specialty_id
    app_reason_id=!params[:app_reason].nil? ? params[:app_reason] : (!params[:appointment_reason][:id].nil? ? params[:appointment_reason][:id] : "")
    @app_reason_id= app_reason_id
  end
	
  def patient_login
		
    render :update do |page|
      page.replace_html "modal_container", :partial=>"booking_login" 
    end
  end	
	
  def appointment_confirm
    slot_time=@doctor.doctor_hospitals.find(:first,:conditions=>['hospital_id = ?',@hospital.id])
    #slot_time=DoctorHospital.find(:first,:condition=>['doctor_id = ? && hospital_id = ?',@doctor.id,@hospital.id]).slot_duration
    date_time=@appointment_date +" "+@appointment_time if !@appointment_date.nil? && !@appointment_time.nil?
    @end_time = date_time.to_time + (60 * slot_time.slot_duration)
    @app_date=@appointment_date.to_date.strftime("%Y-%m-%d")
    app_reason=AppointmentReason.find(@app_reason_id) if !@app_reason_id.nil? && !@app_reason_id.empty?
    @app_reason=!app_reason.nil? ? app_reason.name : ""
    app_service=Specialty.find(@specialty_id) if !@specialty_id.nil? && !@specialty_id.empty?
    @app_service=!app_service.nil? ? app_service.name : ""
    if params[:email].nil? or params[:password].nil? or params[:email].empty? or params[:password].empty? 
      flash.now[:error]="Email and Password Cannot be blank"
    else
      flash.now[:email_error]=UserLogin.authenticate_email?(params[:email])      
      if flash.now[:email_error].nil?        
        flash.now[:password_error]=UserLogin.authenticate_email_password?(params[:email], params[:password])
        if flash.now[:password_error].nil?          
          @user = UserLogin.authenticate(params[:email], params[:password])          
          self.current_user_login=@user
          @login_through_control_model=true
          if @user.patient
            create_appointment
            #AppointmentMailer.deliver_appointment_confirmation(@user,@doctor,request,@appointment,@hospital)
            render :update do |page|
              page.replace_html "modal_container", :partial=>"/appointments/confirm_appointment"
            end
            return true
          else
            flash.now[:error]="Account doesnt exist"
          end
        end
      end 
    end
    render :update do |page|
      page.replace_html "modal_container", :partial=>"/patient_login/booking_login" 
    end
  end	
	
  def create_appointment
    @appointment=Appointment.new()
    @appointment.doctor_id=@doctor.id
    @appointment.hospital_id=@hospital.id
    @appointment.appointment_date=@app_date
    @appointment.reason_for_visit=@app_reason
    @appointment.service_for_visit=@app_service
    @appointment.start_time=@appointment_time
    @appointment.end_time=@end_time.to_time.strftime("%H:%M:%S")
    @appointment.patient_id=@user.patient.id
    @appointment.save
    @hosptial_patient = HospitalPatient.find(:first,:conditions=>["patient_id=? and hospital_id=?",@user.patient.id,@hospital.id])
    if @hosptial_patient.nil?
      @hosptial_patient = HospitalPatient.new()
      @hosptial_patient.patient_id=@user.patient.id    
      @hosptial_patient.hospital_id=@hospital.id
      @hosptial_patient.save   
    end
    doctor_patient = DoctorPatient.find(:first,:conditions=>["doctor_id=? and patient_id=?",@doctor.id,@user.patient.id])
    if doctor_patient.nil? 
      doctor_patient = DoctorPatient.new()
      doctor_patient.doctor_id = @doctor.id
      doctor_patient.patient_id = @user.patient.id
      doctor_patient.type_of_relation = 3
      doctor_patient.save
    end
  end
	
	
  def update
		
  end
  # render new.rhtml
  def new

  end
	
  private
    
  def find_doctor
    @doctor=Doctor.find(params[:doctor_id])  
  end
  
  def find_hospital
    @hospital=Hospital.find(params[:hospital_id])
  end
	
	
end
