class PatientsController < ApplicationController
  layout :change_layout
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem
  before_filter :login_required, :only=>[:show, :edit, :update]
  before_filter :valid_user
  
  def change_layout
    if (action_name=="new" || action_name=="create")
      "login"
    else
      "patient"
    end	 
  end
  
  # render new.rhtml
  def new
  end

  def create
    cookies.delete :auth_token
    # protects against session fixation attacks, wreaks havoc with 
    # request forgery protection.
    # uncomment at your own risk
    # reset_session
    @user_login = UserLogin.new(params[:user_login])
    @user_login.save
    if @user_login.errors.empty?
      #self.current_doctor = @doctor      
      @user_login.patient = Patient.create() 
      #@patient=Patient.new()
      #@patient.user_login_id=@user_login.id
      #pp=@patient.save
      PatientMailer.deliver_email_confirmation(@user_login,request)
      flash[:notice] = "Thanks for signing up! <br> Please check your email to complete your registration"
      redirect_to new_user_login_path
    else
      render :action => 'new'
    end
  end
	
  def activate
    self.current_user_login = params[:activation_code].blank? ? false : UserLogin.find_by_activation_code(params[:activation_code])
    if logged_in? && !current_user_login.active?
      current_user_login.activate
      flash[:notice] = "Your account has been activated"
      #redirect_to patient_appointments_path(self.current_user_login.patient.id)
      redirect_to patient_path(self.current_user_login.patient.id)
    else
      flash[:notice] = "This is an invalid activation code."
      redirect_to new_user_login_path
    end
  end
	
  def show
    @patient_detail=@patient=Patient.find(params[:id])
    @personal_detail_show_display="block"
    @personal_detail_form_display="none"
    @signin_detail_show_display="block"
    @signin_detail_form_display="none"
  end

  def edit
	 
  end


  def update
    @patient_detail=@patient=Patient.find(params[:id])
    if params[:detail]=='personal' 
      @patient.title=(params[:patient][:title])
      @patient.first_name=(params[:patient][:first_name])
      @patient.last_name=(params[:patient][:last_name])
      @patient.address=(params[:patient][:address])
      @patient.city=(params[:patient][:city])
      @patient.state=(params[:patient][:state])
      @patient.pincode=(params[:patient][:pincode])
      @patient.home_number=(params[:patient][:home_number])
      @patient.mobile_number=(params[:patient][:mobile_number])
      @patient.step = 1
      if @patient.valid?
        @patient.save
        flash[:notice]="Personal details updated successfully"
        redirect_to patient_path(@patient.id)
      else
        @patient_detail=Patient.find(params[:id])
        @personal_detail_show_display="none"
        @personal_detail_form_display="block"
        @signin_detail_show_display="block"
        @signin_detail_form_display="none"
        render :action=>'show'
      end	
    else
      @user_login=UserLogin.find(@patient.user_login_id)
      @user_login.email=(params[:user_login][:email])
      @user_login.password=(params[:user_login][:password])
      @user_login.password_confirmation=(params[:user_login][:password_confirmation])
      if @user_login.valid?
        @user_login.save
        PatientMailer.deliver_change_password(@user_login)
        flash[:notice]='Your new password has been sent to your email address.'
        redirect_to patient_path(@patient.id)
      else
        @signin_detail_show_display="none"
        @signin_detail_form_display="block"
        @personal_detail_show_display="block"
        @personal_detail_form_display="none"
        render :action=>'show'
      end	
    end
  end
end