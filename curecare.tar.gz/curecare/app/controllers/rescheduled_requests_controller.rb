class RescheduledRequestsController < ApplicationController
  layout :change_layout, :except=>[:show]
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:index]
  before_filter :valid_user
  before_filter :find_doctor, :only=>[:index,:update]
  before_filter :find_hospital, :only=>[:index,:update]
	
  def index
		if @doctor
			@doctor_staff=!staff.nil? ? staff : nil
			@appointments=@doctor.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ? and rescheduled_date IS NOT NULL',4,0])
			@appoints=@doctor.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',1,0])
			@cancellation_appointments=@doctor.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',3,0])
		elsif @hospital
			@hospital_staff=!staff.nil? ? staff : nil
			@appointments=@hospital.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ? and rescheduled_date IS NOT NULL',4,0])
			@appoints=@hospital.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',1,0])
			@cancellation_appointments=@hospital.appointments.find(:all,:conditions=>['flag = ? and is_cancel = ?',3,0])
		end
  end
  
  def update
    #@appointment=Appointment.find_by_id(params[:id])
		if @doctor
			doctor_appointment
		elsif @hospital
			hospital_appointment
		end
   
  end
  
  def show
    @appointment=Appointment.find_by_id(params[:id])
  end
	
	def change_layout
    if @doctor
      "doctor"
    else
      "hospital"
    end
	end
	
	def doctor_appointment
		 if params[:submit_flag] == '4'
			 if !params[:reschedule_requests].blank?
        appointments = params[:reschedule_requests]
        appointments.each do |appointment_id|
          @appointment = Appointment.find(appointment_id)
          @appointment.update_attributes(:flag=>4)
					@flag=1
          AppointmentMailer.deliver_appointment_confirmation(@appointment.patient.user_login,@doctor,request,@appointment,@appointment.hospital,@flag)
        end
      end
      flash[:notice]="Selected Appointments are confirmed"
    elsif params[:submit_flag] == '3'
      d=Date.today
      date=d.strftime('%Y-%m-%d')
			 if !params[:reschedule_requests].blank?
        appointments = params[:reschedule_requests]
        appointments.each do |appointment_id|
          @appointment = Appointment.find(appointment_id)
          @appointment.update_attributes(:flag=>3,:cancelled_date=>date)
					@flag=1
          AppointmentMailer.deliver_appointment_reject(@appointment.patient.user_login,@doctor,request,@appointment,@appointment.hospital,@flag)
          @appointment.update_attributes(:rescheduled_date=>nil)
        end
      end
      flash[:notice]="Selected Appointments are cancelled"
    elsif (params[:submit_flag] == "2" || params[:submit_flag] == "")
      if !params[:rescheduled_date].nil? || !params[:rescheduled_date].blank?
            @appointment = Appointment.find(params[:id])
            @appointment.update_attributes(:flag=>2,:rescheduled_date=>params[:rescheduled_date])
            AppointmentMailer.deliver_appointment_reschedule(@appointment.patient.user_login,@doctor,request,@appointment,@appointment.hospital)
      end   
       flash[:notice]="Selected Appointments was updated."
    end	
    redirect_to doctor_rescheduled_requests_path(@doctor)
	end
	
	
	def hospital_appointment
		 if params[:submit_flag] == '4'
			 if !params[:reschedule_requests].blank?
        appointments = params[:reschedule_requests]
        appointments.each do |appointment_id|
          @appointment = Appointment.find(appointment_id)
          @appointment.update_attributes(:flag=>4)
					@flag=1
          AppointmentMailer.deliver_hospital_appointment_confirmation(@appointment.patient.user_login,@hospital,request,@appointment,@appointment.doctor,@flag)
        end
      end
      flash[:notice]="Selected Appointments are confirmed"
    elsif params[:submit_flag] == '3'
      d=Date.today
      date=d.strftime('%Y-%m-%d')
			if !params[:reschedule_requests].blank?
        appointments = params[:reschedule_requests]
        appointments.each do |appointment_id|
          @appointment = Appointment.find(appointment_id)
          @appointment.update_attributes(:flag=>3,:cancelled_date=>date)
					@flag=1
          AppointmentMailer.deliver_hospital_appointment_reject(@appointment.patient.user_login,@hospital,request,@appointment,@appointment.doctor,@flag)
          @appointment.update_attributes(:rescheduled_date=>nil)
        end
      end
      flash[:notice]="Selected Appointments are rejected"
		elsif (params[:submit_flag] == "2" || params[:submit_flag] == "")
      if !params[:rescheduled_date].nil? || !params[:rescheduled_date].blank?
            @appointment = Appointment.find(params[:id])
            @appointment.update_attributes(:flag=>4,:rescheduled_date=>params[:rescheduled_date])
            AppointmentMailer.deliver_hospital_appointment_reschedule(@appointment.patient.user_login,@hospital,request,@appointment,@appointment.doctor)
      end   
       flash[:notice]="Selected Appointments was updated."
    end	
    redirect_to hospital_rescheduled_requests_path(@hospital)
	end
	
	
  private
    
 def find_doctor
    @doctor= !params[:doctor_id].nil? ? Doctor.find(params[:doctor_id]) : nil
  end
	
  def find_hospital
    @hospital= !params[:hospital_id].nil? ? Hospital.find(params[:hospital_id]) : nil
  end
end
