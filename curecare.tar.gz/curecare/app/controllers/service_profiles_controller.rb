class ServiceProfilesController < ApplicationController
  layout :change_layout
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem
  cache_sweeper :fragment_cache_sweeper, :only => [:update]
  before_filter :login_required, :only=>[:show, :update, :assignments]  
  before_filter :valid_user
  before_filter :find_doctor, :only=>[:show,:update]
  before_filter :find_hospital, :only=>[:show,:update]
  
  
  def show
    if @doctor
      @doctor_titles = ['Dr', 'Mr', 'Mrs', 'Miss']
      @specialities = Specialty.find(:all,:order=>"name")    
      @doctor_educations = @doctor.educations
      @doctor_memberships = @doctor.professional_memberships
      @doctor_specialities = @doctor.doctor_specialties   
    elsif @hospital
      @cities=City.find(:all,:order=>"name")      
      @hospital_availabilities = @hospital.hospital_availabilities
      find_availabilities if !@hospital_availabilities.nil? && !@hospital_availabilities.empty?
    end
  end
  
  def find_availabilities        
    @availabilities = HospitalAvailability.find(:all,:conditions=>["hospital_id=?",@hospital.id],:order=>"day,start_time")          
    @req_lable = 1
    @consulting_times = Hash.new    
    avail_days = []
    max_lables = []
    @availabilities.each{|d| avail_days << d.day}          
    avail_days = avail_days.uniq if !avail_days.nil?    
    avail_days.each{|t|
      day_times = []    
      @availabilities.each{|d|               
        if d.day == t          
          start_time = d.start_time.strftime("%I:%M %p")
          end_time = d.end_time.strftime("%I:%M %p")                
          day_times << [start_time, end_time]            
        end 
        max_lables << day_times.length
      }            
      @req_lable = max_lables.max.to_i
      @consulting_times[t] = day_times
    }      
  end
  
  
  def update 
    if @doctor 
      assignments 
      if @doctor.valid?           
        @doctor.save	        
        @doctor.doctor_specialties.destroy_all            
        @doctor.doctor_specialties << @doctor_specialities      
        @doctor.educations.destroy_all  
        @doctor.educations << @doctor_educations      
        @doctor.professional_memberships.destroy_all            
        @doctor.professional_memberships << @doctor_memberships    
        flash[:notice]="Your service profile has been updated."
        redirect_to doctor_service_profile_path(@doctor_id)  
      else
        flash.now[:error]="Your service profile has not been updated sucessfully."
        render :action=>'show'
      end
    elsif @hospital
      hospital_assignments
      if @hospital.valid?
        @hospital.save
				@hospital.hospital_availabilities.destroy_all
				@hospital.hospital_availabilities<<@availabilities
        flash[:notice]="Your service profile has been updated."
        redirect_to hospital_service_profile_path(@hospital.id)
      else
        flash.now[:error]="Your service profile has not been updated sucessfully."
        @cities=City.find(:all,:order=>"name")
        @hospital_availabilities = @hospital.hospital_availabilities
      find_availabilities if !@hospital_availabilities.nil? && !@hospital_availabilities.empty?
        render :action=>'show'
      end
    end
  end
  
  def assignments   
    if @doctor		
      @doctor_titles = ['Dr', 'Mr', 'Mrs', 'Miss']
      @specialities = Specialty.find(:all,:order=>"name")    
      @doctor_id = params[:doctor_id]
      @doctor = Doctor.find(@doctor_id)    
      @doctor_specialities = @doctor.doctor_specialties 
      @doctor_educations = @doctor.educations
      @doctor_memberships = @doctor.professional_memberships    
      @doctor.salutation = params[:doctor][:salutation]
      @doctor.first_name = params[:doctor][:first_name]
      @doctor.last_name = params[:doctor][:last_name]
      @doctor.suffix = params[:doctor][:suffix]
      @doctor.professional_summary = params[:doctor][:professional_summary]
      @doctor.step = 1 # Here the step assigned for avoiding unwanted validations in models.
      @doctor_specialities = []
      set_primary=0
      params[:speciality].collect{|x| 
        @doctor_specialities << DoctorSpecialty.new(:specialty_id => x['id'],:flag=> set_primary==0 ? 1 : 0)
        set_primary += 1
      }   
      @doctor_educations = []
      params[:education].collect{|x| @doctor_educations << Education.new(:detail => x['detail']) if !x['detail'].nil? and !x['detail'].empty?}   
      @doctor_memberships = []
      params[:professional_membership].collect{|x| @doctor_memberships << ProfessionalMembership.new(:detail => x['detail']) if !x['detail'].nil? and !x['detail'].empty?}   
    end	
  end
   
  def hospital_assignments
    @hospital=Hospital.find(params[:hospital_id])
    @hospital.name=params[:hospital][:name]
    @hospital.address=params[:hospital][:address]
    @hospital.city_id=params[:hospital][:city_id]
    @hospital.state=params[:hospital][:state]
    @hospital.pincode=params[:hospital][:pincode]
    @hospital.phone_number=params[:hospital][:phone_number]
    @hospital.website=params[:hospital][:website]
    @hospital.professional_summary=params[:hospital][:professional_summary]
    @hospital.step = 1
		consulting_days = []
		@availabilities=[]
    params[:day].each{|key,value| 
		if value=="1"
			@availabilities<<HospitalAvailability.new(:day=>key,:start_time=>params[:hospital_availablity][:start_time],:end_time=>params[:hospital_availablity][:end_time],:hospital_id=>@hospital.id)
			end
		} 
  end
  	 
	 
  def change_layout
    if @doctor
      "doctor"
    else
      "hospital"
    end
  end	
	
  private
    
  def find_doctor
    @doctor= !params[:doctor_id].nil? ? Doctor.find(params[:doctor_id]) : nil
  end
	
  def find_hospital
    @hospital= !params[:hospital_id].nil? ? Hospital.find(params[:hospital_id]) : nil
  end
	
	
end
