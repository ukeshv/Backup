class ServiceReasonsController < ApplicationController
  layout :change_layout 
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:show, :assignments, :update]
	before_filter :valid_user
  before_filter :find_doctor, :only=>[:show,:update]
  before_filter :find_hospital, :only=>[:show,:update]
  
  def show
		if @doctor
			@doctor_services = @doctor.appointment_services.length>0 ? @doctor.appointment_services : []
			@doctor_reasons = @doctor.appointment_reasons.length> 0 ? @doctor.appointment_reasons : []
		elsif @hospital
			@hospital_services = @hospital.hospital_services.length>0 ? @hospital.hospital_services : []
			@hospital_reasons = @hospital.hospital_reasons.length> 0 ? @hospital.hospital_reasons : []
		end
  end
  
  def update
    assignments
		if @doctor
    @doctor.appointment_services.destroy_all            
    @doctor.appointment_services << @doctor_services
    @doctor.appointment_reasons.destroy_all            
    @doctor.appointment_reasons << @doctor_reasons
		flash[:notice]='Your service reason has been updated sucessfully.'
    redirect_to doctor_service_reason_path(@doctor_id)   
    elsif @hospital
		@hospital.hospital_services.destroy_all            
    @hospital.hospital_services << @hospital_services
    @hospital.hospital_reasons.destroy_all            
    @hospital.hospital_reasons << @hospital_reasons
		flash[:notice]='Your service reason has been updated sucessfully.'
    redirect_to hospital_service_reason_path(@hospital_id) 	
    end			
  end
  
  def assignments
		if @doctor
    @doctor_id = params[:doctor_id]
    @doctor = Doctor.find(@doctor_id)
    @doctor_services = []
    params[:appointment_service].collect{|x| @doctor_services << AppointmentService.new(:name => x['name'])}       
    @doctor_reasons = []
    params[:appointment_reason].collect{|x| @doctor_reasons << AppointmentReason.new(:name => x['name'])}       
		elsif @hospital
		@hospital_id = params[:hospital_id]
    @hospital = Hospital.find(@hospital_id)
    @hospital_services = []
    params[:appointment_service].collect{|x| @hospital_services << HospitalService.new(:name => x['name'])}       
    @hospital_reasons = []
    params[:appointment_reason].collect{|x| @hospital_reasons << HospitalReason.new(:name => x['name'])}       
		end
		
  end
  
  def change_layout
    if @doctor
      "doctor"
    else
      "hospital"
    end
  end
	
  private
    
  def find_doctor
    @doctor=!params[:doctor_id].nil? ? Doctor.find(params[:doctor_id]) : nil 
  end
	
	 def find_hospital
    @hospital= !params[:hospital_id].nil? ? Hospital.find(params[:hospital_id]) : nil
  end
	
end
