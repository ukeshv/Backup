class SmsConfirmationsController < ApplicationController
  include UserLoginAuthenticatedSystem
  before_filter :find_doctor, :only=>[:activate]
  before_filter :find_hospital, :only=>[:activate]
  
  def new
		
  end
  
  
	
  def activate
    assignments
    @user = params[:activation_code].blank? ? false : UserLogin.find_by_activation_code(params[:activation_code])
    slot_time=@doctor.doctor_hospitals.find(:first,:conditions=>['hospital_id = ?',@hospital.id])
    date_time=@appointment_date +" "+@appointment_time if !@appointment_date.nil? && !@appointment_time.nil?
    @end_time = date_time.to_time + (60 * slot_time.slot_duration)
    @app_date=@appointment_date.to_date.strftime("%Y-%m-%d")
    app_reason=AppointmentReason.find(@app_reason) if !@app_reason_id.nil? && !@app_reason_id.empty?
    @app_reason=!app_reason.nil? ? app_reason.name : ""
    app_service=Specialty.find(@specialty) if !@specialty_id.nil? && !@specialty_id.empty?
    @app_service=!app_service.nil? ? app_service.name : ""
    @user_login = @user
    if  @user && !@user.active?
      @user.activate
      flash.now[:notice] = "Your account has been activated"
      self.current_user_login=@user
      create_appointment
      #AppointmentMailer.deliver_appointment_confirmation(@user,@doctor,request,@appointment,@hospital)
      render :update do |page|
        page.replace_html "modal_container", :partial=>"/appointments/confirm_appointment"
      end
    else
      flash.now[:notice] = " "
      flash.now[:error] = "This is an invalid activation code."
      render :update do |page|
        page.replace_html "modal_container", :partial=>"/sms_confirmations/sms_pin_no" 
      end
    end
  end
	
  def assignments
    @appointment_date=params[:appointment_date]
    @appointment_time=params[:appointment_time]
    @specialty=params[:specialty_id]
    @app_reason=params[:app_reason]
  end
	
  def create_appointment
    @appointment=Appointment.new()
    @appointment.patient_id=@user.patient.id
    @appointment.doctor_id=@doctor.id
    @appointment.hospital_id=@hospital.id
    @appointment.appointment_date=@app_date
    @appointment.reason_for_visit=@app_reason
    @appointment.service_for_visit=@app_service
    @appointment.start_time=@appointment_time
    @appointment.end_time=@end_time.to_time.strftime("%H:%M:%S")
    @appointment.save
    @hosptial_patient = HospitalPatient.find(:first,:conditions=>["patient_id=? and hospital_id=?",@user.patient.id,@hospital.id])
    if @hosptial_patient.nil?
      @hosptial_patient = HospitalPatient.new()
      @hosptial_patient.patient_id=@user.patient.id    
      @hosptial_patient.hospital_id=@hospital.id
      @hosptial_patient.save   
    end
    doctor_patient = DoctorPatient.find(:first,:conditions=>["doctor_id=? and patient_id=?",@doctor.id,@user.patient.id])
    if doctor_patient.nil? 
      doctor_patient = DoctorPatient.new()
      doctor_patient.doctor_id = @doctor.id
      doctor_patient.patient_id = @user.patient.id
      doctor_patient.type_of_relation = 3
      doctor_patient.save
    end
  end
	
	
  private
    
  def find_doctor
    @doctor=Doctor.find(params[:doctor_id])  
  end
  
  def find_hospital
    @hospital=Hospital.find(params[:hospital_id])
  end
	
end
