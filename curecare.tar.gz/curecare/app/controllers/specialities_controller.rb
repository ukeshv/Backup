class SpecialitiesController < ApplicationController
  
  def index
    @specialities = Specialty.find(:all,:order=>"name")    
    respond_to do |format|
      format.html do
        render
      end
      format.js do
        render :layout=>false
      end
    end
  end
end
