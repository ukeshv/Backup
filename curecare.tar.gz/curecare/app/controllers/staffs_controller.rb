class StaffsController < ApplicationController
  layout :change_layout
  
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem  
  before_filter :login_required, :only=>[:index,:create, :destroy,:activate]
  before_filter :valid_user
  before_filter :find_doctor, :only=>[:index,:show,:create,:destroy]
  before_filter :find_hospital, :only=>[:index,:show,:create,:destroy]
  
  def index
    if @doctor
      @staffs_list=@doctor.staffs
    elsif @hospital
      @staffs_list=@hospital.staffs
    end
  end
  
  # render new.rhtml
  def new
  end
  
  def show
    
  end
	
  def update

  end
  

  def create  
    assignments    
    if @staff.errors.empty? and @user_login.errors.empty?              
        @user_login.save                
      if @doctor        
        @doctor.staffs << @staff
        @staff.update_attribute('user_login_id',@user_login.id)
        PatientMailer.deliver_staff_confirmation(@user_login,request,@password)      
        flash[:notice]='Your staff has been added.'
        redirect_to doctor_staffs_path(@doctor)
      elsif @hospital        
        @hospital.staffs << @staff
        @staff.update_attribute('user_login_id',@user_login.id)
        PatientMailer.deliver_staff_confirmation(@user_login,request,@password)      
        flash[:notice]='Your staff has been added.'
        redirect_to hospital_staffs_path(@hospital)
      end
    else
      if @doctor
        @staffs_list=@doctor.staffs
      elsif @hospital
        @staffs_list=@hospital.staffs	
      end      
      render :action=>'index'
    end
  end
  
  def assignments
    @staff=Staff.new()
    @staff.first_name=params[:staff][:first_name]
    @staff.last_name=params[:staff][:last_name]
    @staff.email=params[:user_login][:email]  if params[:user_login]
    @staff.mobile_number=params[:staff][:mobile_number]
    @staff.appointment_notification_by_sms=params[:staff][:appointment_notification_by_sms]
    @staff.appointment_notification_by_email=params[:staff][:appointment_notification_by_email]
    @staff.add_flag=params[:staff][:add_flag]
    @staff.cancel_flag=params[:staff][:cancel_flag]
    @staff.reschedule_flag=params[:staff][:reschedule_flag]
    @staff.confirm_flag=params[:staff][:confirm_flag]
    @user_login=UserLogin.new()
        generate_random_password
        @user_login.email=params[:user_login][:email] if params[:user_login]
        @user_login.password=@password
        @user_login.password_confirmation=@password
    @staff.valid? 
    @user_login.valid?
    end
	
  def generate_random_password
    alphanumerics = [('0'..'9'),('a'..'z')].map {|range| range.to_a}.flatten
    rand=(0...7).map { alphanumerics[Kernel.rand(alphanumerics.size)] }.join    
    encrypted_string= rand.encrypt
    @password=encrypted_string.decrypt
  end
	
  def destroy
    @staff=Staff.find(params[:id])
    if @doctor
    @doctor_staff=@staff.doctor_staff
    @user_staff=@staff.user_login 
    @user_staff.destroy if @user_staff
    @doctor_staff.destroy
    @staff.destroy
    flash[:notice]='Your staff has been deleted.'
      redirect_to  doctor_staffs_path(@doctor)
    elsif @hospital
    @hospital_staff=@staff.hospital_staff
    @user_staff=@staff.user_login 
    @user_staff.destroy if @user_staff
    @hospital_staff.destroy
    @staff.destroy
    flash[:notice]='Your staff has been deleted.'
      redirect_to hospital_staffs_path(@hospital)	
    end	
  end
	
  def change_layout
    if @doctor
      "doctor"
    else
      "hospital"
    end
  end	
	
	
  def activate
    self.current_user_login = params[:activation_code].blank? ? false : UserLogin.find_by_activation_code(params[:activation_code])
    if logged_in? && !current_user_login.active?
      current_user_login.activate
      staff=current_user_login.staff
      if staff
        if !staff.doctor.nil?
          redirect_to doctor_awaiting_requests_path(staff.doctor.id)
        elsif !staff.hospital.nil?
          redirect_to hospital_awaiting_requests_path(staff.hospital.id)
        end
      end
			
      #flash[:notice] = "Your account has been activated"
      #redirect_to patient_appointments_path(self.current_user_login.patient.id)
      #redirect_to patient_path(self.current_user_login.staff.id)
    else
      flash[:notice] = "This is an invalid activation code."
      redirect_to new_user_login_path
    end
  end
	
  private
    
  def find_doctor
    @doctor= !params[:doctor_id].nil? ? Doctor.find(params[:doctor_id]) : nil
  end
	
  def find_hospital
    @hospital= !params[:hospital_id].nil? ? Hospital.find(params[:hospital_id]) : nil
  end


end


  
 
  
 