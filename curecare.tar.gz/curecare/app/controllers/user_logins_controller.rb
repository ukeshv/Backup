class UserLoginsController < ApplicationController
  layout "login"
  # Be sure to include AuthenticationSystem in Application Controller instead
  include UserLoginAuthenticatedSystem
  #protect_from_forgery
  # render new.rhtml
  def new
  end
  
  def create
    if params[:email].empty? and params[:password].empty? 
      flash.now[:error]="Email and Password cannot be blank"
    elsif params[:email].empty? and !params[:password].empty?
      @email_err = 1      
    elsif !params[:email].empty? and params[:password].empty?
      flash.now[:email_error]=UserLogin.authenticate_email?(params[:email])      
      @pwd_err = 1      
    else
      flash.now[:email_error]=UserLogin.authenticate_email?(params[:email])      
      if flash.now[:email_error].nil?        
        flash.now[:password_error]=UserLogin.authenticate_email_password?(params[:email], params[:password])
        if flash.now[:password_error].nil?          
          @user = UserLogin.authenticate(params[:email], params[:password])          
          if @user            
            get_profile(@user) and return true
          else
            flash.now[:error]="Your account not yet activated"
          end
        end
      end 
    end
    render :action=>"new"
  end
  
  def get_profile(user)
    self.current_user_login=user
    if user.doctor      
      redirect_to doctor_awaiting_requests_path(user.doctor.id)
    elsif user.patient
      redirect_to patient_appointments_path(user.patient.id)
    elsif user.hospital
      redirect_to hospital_awaiting_requests_path(user.hospital.id)
		else
     u=UserLogin.find_by_email(params[:email])
		 staff=u.staff
			 if !staff.doctor.nil?
				 redirect_to doctor_awaiting_requests_path(staff.doctor.id)
			 elsif !staff.hospital.nil? 
				 redirect_to hospital_awaiting_requests_path(staff.hospital.id)
			 end  
     end
  end
 
  
  def destroy
    self.current_user_login if logged_in? #.forget_me if logged_in?
    cookies.delete :auth_token
    reset_session
    flash[:notice] = "You have been logged out."
    redirect_to new_user_login_path
  end
end
