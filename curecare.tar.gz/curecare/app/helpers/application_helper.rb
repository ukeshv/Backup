# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  include GeoKit::Geocoders

  def get_available_timings(availabilities,date,day,doctor_hospital)
    available_times=[]
    for availability in availabilities
      if availability.day==day and availability.hospital_id==doctor_hospital.hospital_id and availability.doctor_id==doctor_hospital.doctor_id
        available_times<<availability
      end
    end
    time_pieces=[]
    time_pieces_string=""
    for available_time in available_times
      (available_time.start_time..available_time.end_time).step(60*doctor_hospital.slot_duration){|x| time_pieces<<x}
    end
    time_pieces.uniq.sort.each do |x|            
      time_pieces_string += yield x.strftime("%I:%M %p"), check_availabilty_with_appointments(x,date,doctor_hospital)
    end
    time_pieces_string
  end

  def check_availabilty_with_appointments(time,date,doctor_hospital)    
    check_time = "#{date.strftime("%b %d, %Y")} #{time.strftime('%I:%M %p')}"    
    lead_time_availability = appointment_availability(date,check_time, doctor_hospital)
    lead_time_availability = (lead_time_availability==true) ? nil : false    
    Appointment.find(:first, :conditions=>["doctor_id = ? and hospital_id = ? and start_time = ?  and appointment_date = ? or rescheduled_date = ?", doctor_hospital.doctor_id,doctor_hospital.hospital_id, time,date,date]) or Holiday.find(:first, :conditions=>["doctor_id = ? and start_date <= ? and end_date >= ?", doctor_hospital.doctor_id,date,date]) or lead_time_availability
    # Here need to check for the booking lead timing settings too.
  end
	
  def check_availabilties(time,date,doctor_hospital)
    Availability.find(:first, :conditions=>["doctor_id = ? and hospital_id = ? and day = ? and start_time <=? and end_time > ? ", doctor_hospital.doctor_id,doctor_hospital.hospital_id, date.wday, time, time]) and !(Holiday.find(:first, :conditions=>["doctor_id = ? and start_date >= ? and end_date <= ?", doctor_hospital.doctor_id,date,date]))
  end
	
  def get_appointment_details(time,date,doctor_hospital)
    @appointments=doctor_hospital.doctor.appointments
    status=nil
    value=check_availabilties(time,date,doctor_hospital) ?  "<td><a href='#'> Open </a></td>" : "<td>&nbsp;</td>"
    slot_duration=0
    appointment_start=@appointments.find(:first, :conditions=>["hospital_id = ? and start_time = ? and appointment_date = ? or rescheduled_date = ?",doctor_hospital.hospital_id,time,date,date])
    appointment_between=@appointments.find(:first, :conditions=>["hospital_id=? and start_time < ? and end_time > ? and appointment_date = ? or rescheduled_date = ?",doctor_hospital.hospital_id,time,time, date,date])
    if appointment_start
      value = "<td bgcolor='red' rowspan='#{appointment_start.number_of_slots}'>Booked</td>"
    elsif appointment_between
      value = nil
    end
    return value
  end
  
  
  def appointment_availability(date,start,doctor_hospital=nil)          
    today = (Time.now.utc + 330*60)
    @show = false
    if today <= start.to_time      
      min_time = !@doctor.nil? ? @doctor.min_lead_time : doctor_hospital.doctor.min_lead_time
      min_lead_time = min_time*60 if min_time 
      max_time = !@doctor.nil? ? @doctor.max_lead_time : doctor_hospital.doctor.max_lead_time
      max_lead_time = max_time*1440 if max_time            
      diff_minutes = time_diff_in_minutes(start.to_time)      
      time_range = (min_lead_time..max_lead_time)            
      if time_range.include?(diff_minutes)
        @show = true
      end          
    end
    return @show
  end
  
  def time_diff_in_minutes (time)    
    diff_seconds = (time - Time.now).round    
    diff_minutes = diff_seconds / 60    
    return diff_minutes
  end
  
   
  def find_lat_lng(address)            
    res=MultiGeocoder.geocode(address)
    lat = res.lat
    lng = res.lng
    lat = (!lat.nil? && !lat.blank?) ? lat : "37.4419"
    lng = (!lng.nil? && !lng.blank?) ? lng : "-122.1419"    
    return lat, lng
  end
  
  def particular_location(doctor,location)
    city = City.find(:first,:select=>'id',:conditions=>["name like '"+location+"%'"])
    hospital = doctor.hospitals.find(:first,:conditions=>["city_id=#{city.id}"])    
  end  
  
end