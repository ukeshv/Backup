module DoctorAppointmentsHelper 
  
  def check_availability(doctor,date_time)
    start_time = date_time.strftime("%H:%M")
    end_time = (date_time + (60*60)).strftime("%H:%M")    
    day = date_time.strftime("%w")
    date = date_time.to_date             
    st = "#{date} #{start_time}".to_time
    ed = "#{date} #{end_time}".to_time
    @doctor_availability = doctor.availabilities.find(:first,:conditions=>["doctor_id = ? and start_time <=? and end_time >= ? and day = ?", doctor.id, start_time, end_time, day])    
    if @doctor_availability            
      @doctor_appointments = doctor.confirmed_appointments.find(:all, :conditions=>["doctor_id = ? and start_time >=? and end_time <= ? and ((rescheduled_date is NOT NULL and rescheduled_date = '#{date}') or (appointment_date is NOT NULL and appointment_date = '#{date}'))", doctor.id, start_time, end_time])    
      @booked_slots = []      
      @doctor_appointments.each{|da| @booked_slots << da.start_time.strftime("%H:%M:%S")} if @doctor_appointments
      doctor_hospital = doctor.doctor_hospitals.find(:first,:conditions=>["doctor_id = ? and hospital_id = ?",@doctor_availability.doctor_id, @doctor_availability.hospital_id ])                
      time_slots = []
      @slots = []
      @doctor_slots = []
      @hospital_slots = []
      (st..ed).step(doctor_hospital ? 60*doctor_hospital.slot_duration : 60*60).each{|x| time_slots << x.utc}        
      if !time_slots.empty?          
        time_slots.each_index{|x| 
          check_slot = time_slots[x].to_time.strftime('%H:%M:%S')                    
          if !@booked_slots.include?(check_slot)            
            str =  "#{time_slots[x].to_time.strftime('%Y%m%d%H%M')} #{time_slots[x+1].to_time.strftime('%H%M')}" if ((x+1) < time_slots.length)
            @slots << str.gsub(" ","") if str             
            @doctor_slots << doctor.id if str 
            @hospital_slots << doctor_hospital.hospital_id if str   
          end            
        }          
      end        
    end
  end
  
end
