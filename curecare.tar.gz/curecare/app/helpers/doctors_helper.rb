module DoctorsHelper

  
  def other_locations(doctor,city_id)    
    doc_hospitals=doctor.hospital_ids
    (!doc_hospitals.nil? and !doc_hospitals.empty?) ? Hospital.find(:first,:conditions=> ["id in (?) and city_id = ?",doc_hospitals,city_id]) : nil				
  end
 
	
end