module HospitalDoctorsHelper
    
  def is_on_duty?(doc)
    holiday = doc.holidays.find(:first, :conditions=>["start_date <= ? and end_date >= ?", Date.today,Date.today])
    !holiday.nil? ? "On Leave" : "On Duty"
  end
  
  def find_doctor_specialities(doctors)
    @specialities = []
    doctors.each{|d|
      @specialities << d.specialties      
    }        
    @specialities = @specialities.flatten.uniq if @specialities    
    @specialities = @specialities.sort_by {|sp| sp.name} if @specialities    
  end
  
end
