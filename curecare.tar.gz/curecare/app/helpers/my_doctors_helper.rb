module MyDoctorsHelper
end
