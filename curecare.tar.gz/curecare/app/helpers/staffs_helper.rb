module StaffsHelper

def display_notification(n1,n2)
	str = []
	if n1== true
	str<< "SMS"
	end
	if n2==true
		str<< "Email"
	end
	return str.join(',')
end

def display_permission(n1,n2,n3,n4)
	str=[]
	if n1==true
	str<<"Add"
	end
	if n2==true
	str<<"Cancel"
	end
	if n3==true
	str<<"Reschedule"
	end
	if n4==true
	str<<"Confirm"
	end
	return str.join(',')
end

end