class Appointment < ActiveRecord::Base
	
  belongs_to :doctor
  belongs_to :patient
  belongs_to :hospital
  has_one :appointment_reminder
	
  def when
    if !self.rescheduled_date.nil?
      return self.rescheduled_date.strftime("%A %B %d,%Y")+' at '+self.start_time.strftime("%I:%M %p" )
    else    
      return self.appointment_date.strftime("%A %B %d,%Y")+' at '+self.start_time.strftime("%I:%M %p" )
    end
  end
	
  def booked
    return self.created_at.strftime("%d %B,%Y")+' at '+self.created_at.strftime("%I:%M %p" )
  end 
  
  def patient_details   
    str = []
    if !self.patient.full_name.nil?
      str << self.patient.full_name
    end
    if !reason_for_visit.nil?
      str << "- " + reason_for_visit
    end    
    if !self.hospital.name.nil?
      str << "<br/>At " + self.hospital.name
    end    
    str.join(" ")
  end
  
  def patient_short_details
    str = []
    if !self.patient.full_name.nil?
      str << self.patient.full_name
    end
    if !reason_for_visit.nil?
      str << "<br/>" + reason_for_visit
    end        
    str.join(" ")
  end
  
  def patient_phone_email
    str = []
    if !self.patient.full_name.nil?
      str << "<h5>" + self.patient.full_name + "</h5>"
    end
    if !self.patient.mobile_number.nil?
      str << "Phone: " + self.patient.mobile_number + "<br/>"
    end 
    if !self.patient.user_login.nil?
      str << "Email: " + self.patient.user_login.email + "<br/>"
    end 
    str.join(" ")
  end
  
  def self.sent_reminder
    @appointment_reminders = AppointmentReminder.find :all, :conditions=>["is_sent is false and ((appointments.rescheduled_date is NOT NULL and appointments.rescheduled_date = '#{Date.today+1}') or (appointments.appointment_date is NOT NULL and appointments.appointment_date = '#{Date.today+1}'))"],:include=>[:appointment]
    for @appointment_reminder in @appointment_reminders
     @appointment = Appointment.find(@appointment_reminder.appointment_id)
     if @appointment_reminder.send_email == true
     AppointmentMailer.deliver_send_reminder(@appointment,@appointment_reminder)
     end
     if @appointment_reminder.send_sms == true
       number = @appointment_reminder.sms_to.split(" ")
      mobile_number =  number[1] + number[2]
      country_code = "91"
       url = "http://api.clickatell.com/http/sendmsg?user="+$clickatell_user+"&password="+$clickatell_pwd+"&api_id="+$clickatell_apiid +"&to="+country_code+mobile_number+"&text="+"CureandCare+appointment+has+been+confirmed+tomorrow"
    result = Net::HTTP.get_response(URI.parse(url)).body
     end  
     @appointment_reminder.update_attribute(:is_sent,true)
    end  
  end  
  
end
