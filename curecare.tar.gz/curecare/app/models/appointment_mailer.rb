class AppointmentMailer < ActionMailer::Base
  
  
  def appointment_confirmation(patient,doctor,request,appointment,hospital,flag=nil)		
    @subject         = 'Your appointment details'
    @from            = "Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients      = "<#{patient.email}>"
    @sent_on         = Time.now
		@body[:flag] = flag
    @body[:patient]     = patient
    @body[:doctor]      = doctor
    @body[:hospital]    = hospital
    @body[:appointment] = appointment
    @body[:site_url] = "http://#{request.env['HTTP_HOST']}/"
    @content_type    = "text/html"    
  end
  
	def appointment_reject(patient,doctor,request,appointment,hospital,flag=nil)
		@subject = 'Your appointment rejected'
		@from = "Cure\&Care <#{$ADMIN_EMAIL}>"
		@recipients = "<#{patient.email}>"
		@sent_on = Time.now
		@body[:flag] = flag
		@body[:patient] = patient
		@body[:doctor] = doctor
		@body[:hospital] = hospital
		@body[:appointment] = appointment
		@body[:site_url] = "http://#{request.env['HTTP_HOST']}/"
    @content_type    = "text/html"    
	end
	
	def appointment_reschedule(patient,doctor,request,appointment,hospital)
		@subject = 'Your appointment rescheduled'
		@from = "Cure\&Care <#{$ADMIN_EMAIL}>"
		@recipients = "<#{patient.email}>"
		@sent_on = Time.now
		@body[:patient] = patient
		@body[:doctor] = doctor
		@body[:hospital] = hospital
		@body[:appointment] = appointment
		@body[:site_url] = "http://#{request.env['HTTP_HOST']}/"
    @content_type    = "text/html"   		
	end
	
	 def hospital_appointment_confirmation(patient,hospital,request,appointment,doctor,flag=nil)		
    @subject         = 'Your appointment details'
    @from            = "Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients      = "<#{patient.email}>"
    @sent_on         = Time.now
		@body[:flag] = flag
    @body[:patient]     = patient
    @body[:doctor]      = doctor
    @body[:hospital]    = hospital
    @body[:appointment] = appointment
    @body[:site_url] = "http://#{request.env['HTTP_HOST']}/"
    @content_type    = "text/html"    
  end
  
	def hospital_appointment_reject(patient,hospital,request,appointment,doctor,flag=nil)
		@subject = 'Your appointment rejected'
		@from = "Cure\&Care <#{$ADMIN_EMAIL}>"
		@recipients = "<#{patient.email}>"
		@sent_on = Time.now
		@body[:flag] = flag
		@body[:patient] = patient
		@body[:doctor] = doctor
		@body[:hospital] = hospital
		@body[:appointment] = appointment
		@body[:site_url] = "http://#{request.env['HTTP_HOST']}/"
    @content_type    = "text/html"    
	end
	
	def hospital_appointment_reschedule(patient,hospital,request,appointment,doctor)
		@subject = 'Your appointment rescheduled'
		@from = "Cure\&Care <#{$ADMIN_EMAIL}>"
		@recipients = "<#{patient.email}>"
		@sent_on = Time.now
		@body[:patient] = patient
		@body[:doctor] = doctor
		@body[:hospital] = hospital
		@body[:appointment] = appointment
		@body[:site_url] = "http://#{request.env['HTTP_HOST']}/"
    @content_type    = "text/html"   		
	end
	
	def appointment_cancel_by_user(patient,doctor,request,appointment,hospital,flag=nil)		
    @subject         = 'Your appointment details'
    @from            = "Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients      = "<#{doctor.email}>"
    @sent_on         = Time.now
		@body[:flag] = flag
    @body[:patient]     = patient
    @body[:doctor]      = doctor
    @body[:hospital]    = hospital
    @body[:appointment] = appointment
    @body[:site_url] = "http://#{request.env['HTTP_HOST']}/"
    @content_type    = "text/html"    
  end
	
	def send_reminder(appointment,appointment_reminder)
		@subject         = 'Appointment Reminder'
    @from            = "Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients      = appointment_reminder.email_to
    @sent_on         = Time.now
		@body[:appointment_reminder] = appointment_reminder
		@body[:appointment] = appointment
		@content_type    = "text/html"   
	end	
	
end
