class AppointmentReason < ActiveRecord::Base
	
	belongs_to :doctor
	
end
