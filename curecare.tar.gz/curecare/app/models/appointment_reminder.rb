class AppointmentReminder < ActiveRecord::Base
belongs_to :appointment
end
