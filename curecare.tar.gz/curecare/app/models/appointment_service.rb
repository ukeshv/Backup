class AppointmentService < ActiveRecord::Base
	
	belongs_to :doctor
	
end
