class Doctor < ActiveRecord::Base
  attr_accessor :step
  
  belongs_to :user_login
  belongs_to :city
  has_many :doctor_specialties
  has_many :specialties, :through=>:doctor_specialties
  has_many	:doctor_hospitals
  has_many :hospitals, :through=>:doctor_hospitals
  has_many :availabilities
  has_many	:holidays
  has_many	:doctor_patients, :conditions=>'doctor_patients.type_of_relation in (1,2)'
  has_many	:patients, :through=>:doctor_patients
  has_many	:educations
  has_many	:professional_memberships
  has_many	:staffs, :through=>:doctor_staffs
  has_many	:appointment_reasons
  has_many	:appointment_services
  has_many	:appointments
  has_many  :confirmed_appointments, :class_name => "Appointment", :conditions => 'flag=4'
  has_many      :doctor_notes
  has_one       :lead_timing	
  has_many :doctor_staffs
  has_many :staffs, :through=>:doctor_staffs
	
  validates_presence_of     :salutation, :if => Proc.new { |doctor| doctor.step == 1 }, :message => "Please select a salutation"
  validates_presence_of     :first_name, :if => Proc.new { |doctor| doctor.step == 1 }, :message => "First Name cannot be blank"
  validates_format_of :first_name,:if=> Proc.new {|doctor| doctor.step == 1}, :with => /^[a-zA-Z]+$/ , :message => "First name should be in alphabets"
  validates_length_of       :first_name, :if => Proc.new { |doctor| doctor.step == 1 }, :within => 3..25, :too_short => "First Name should be in the range of 3 to 25 characters"
  validates_presence_of     :last_name, :if => Proc.new { |doctor| doctor.step == 1}, :message => "Last Name cannot be blank"
  validates_format_of :last_name,:if=> Proc.new {|doctor| doctor.step == 1}, :with => /^[a-zA-Z]+$/ , :message => "Last name should be in alphabets"
  validates_length_of       :last_name, :if => Proc.new { |doctor| doctor.step == 1 }, :within => 3..25, :too_short => "Last Name should be in the range of 3 to 25 characters"
  validates_presence_of     :suffix, :if => Proc.new { |doctor| doctor.step == 1 }, :message => "Suffix cannot be blank" 
  validates_format_of :suffix,:if=> Proc.new {|doctor| doctor.step == 1}, :with => /[^0-9]$/ , :message => "Suffix should be in alphabets"
  validates_length_of       :suffix, :if => Proc.new { |doctor| doctor.step == 1 }, :within => 1..25, :too_short => "Suffix should be in the range of 1 to 25 characters"
  validates_presence_of     :notification_email, :if => Proc.new { |doctor| doctor.step == 2 }, :message => "Notification Email cannot be blank" 
  validates_format_of :notification_email, :with => /^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$/ , :if => Proc.new { |doctor| doctor.step == 2 },:message=>"Provide a valid Notification Email"  
  validates_presence_of     :notification_phone, :if => Proc.new { |doctor| doctor.step == 2 }, :message => "Notification Phone cannot be blank" 
  validates_format_of :notification_phone, :if => Proc.new { |doctor| doctor.step == 2 }, :with => /^[0-9]{10}$/, :message =>"Notification Phone should be in 10 digit"

  validates_presence_of :address,:if => Proc.new { |doctor| doctor.step == 3 }, :message => "Address cann't be blank"  
  validates_presence_of :city_id,:if => Proc.new { |doctor| doctor.step == 3 }, :message => "Please Select a City"
  validates_presence_of :emergency_number,:if => Proc.new { |doctor| doctor.step == 3 }, :message => "Emergency Contact cann't be blank"  
  validates_format_of :emergency_number,:if => Proc.new { |doctor| doctor.step == 3 }, :with => /^[0-9]{3}-? ?[0-9]{8}$/, :message =>"Please provide a valid phone number (Ex: 000-12345678 or 00012345678)"
  	
  validates_presence_of :pincode,:if => Proc.new { |doctor| doctor.step == 3 }, :message => "Pincode cann't be blank"  
  validates_format_of :pincode,:if => Proc.new { |doctor| doctor.step == 3 }, :with => /^[0-9]{6}$/, :message =>"Provide a valid Pincode"
  validates_presence_of :personal_email,:if => Proc.new { |doctor| doctor.step == 3 }, :message => "Email cann't be blank"  
  validates_format_of :personal_email,:if => Proc.new { |doctor| doctor.step == 3 }, :with => /^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$/ ,:message=>"Provide a valid email"  
  
  validates_presence_of :min_lead_time, :if => Proc.new {|doctor| doctor.step == 4}, :message => "Select the Min lead time"
  validates_presence_of :max_lead_time, :if => Proc.new {|doctor| doctor.step == 4}, :message => "Select the Max lead time"
	
  #Cancellation_hour
  Cancellation_hour= [
    ['5 Hours', '5' ],
    ['6 Hours', '6' ],
    ['7 Hours', '7' ],
    ['8 Hours', '8' ],
    ['9 Hours', '9' ],
    ['10 Hours', '10' ],
    ['11 Hours', '11' ],
    ['12 Hours', '12' ]
  ]
	
  #Min_lead_time
  Min_lead_time= [ ["Select",""],
    ['1 Hour', '1' ],
    ['2 Hours', '2' ],
    ['3 Hours', '3' ],
    ['4 Hours', '4' ],
    ['5 Hours', '5' ],
    ['6 Hours', '6' ],
    ['7 Hours', '7' ],
    ['8 Hours', '8' ],
    ['9 Hours', '9' ],
    ['10 Hours', '10' ],
    ['11 Hours', '11' ],
    ['12 Hours', '12' ]
  ]
	
  #Max_lead_time
  Max_lead_time= [ ["Select",""],
    ['1 Day', '1' ],
    ['2 Days', '2' ],
    ['3 Days', '3' ],
    ['4 Days', '4' ],
    ['5 Days', '5' ],
    ['6 Days', '6' ],
    ['7 Days', '7' ],
    ['8 Days', '8' ],
    ['9 Days', '9' ],
    ['10 Days', '10' ],
    ['11 Days', '11' ],
    ['12 Days', '12' ],
    ['13 Days', '13' ],
    ['14 Days', '14' ],
    ['15 Days', '15' ],
    ['16 Days', '16' ],
    ['17 Days', '17' ],
    ['18 Days', '18' ],
    ['19 Days', '19' ],
    ['20 Days', '20' ]
  ]
	
	
  def full_name
    if !first_name.nil? and !first_name.empty?
      "#{salutation}  #{first_name.capitalize} #{last_name}"
    else
      email =  self.user_login.email
      email = email.split("@")
      email = email[0].capitalize      
    end
  end
  
  def name
    if !first_name.nil? and !first_name.empty?
      "#{first_name.capitalize} #{last_name}"
    else
      email =  self.user_login.email
      email = email.split("@")
      email = email[0].capitalize      
    end
  end
  
  def contact_no
    !mobile_number.nil? ? mobile_number : (!home_number.nil? ? home_number : "-NA-")
  end
	 
  def self.title(id)
    specialty=DoctorSpecialty.find(:first,:select=>"specialty_id",:conditions=>['doctor_id = ?',id])    if id
    (!specialty.nil? && !specialty.specialty_id.nil?) ? Specialty.find(specialty.specialty_id) : nil
  end
	 
		 
  def self.location(id)
    hospital=DoctorHospital.find(:first,:select=>"hospital_id", :conditions=>['doctor_id = ?',id])  if id
    (!hospital.nil? && !hospital.hospital_id.nil?) ? Hospital.find(hospital.hospital_id) : nil
  end
	
	
	
  def self.image(id)
    image_id=DoctorPhoto.find_by_doctor_id(id)
    !image_id.nil? ? image_id.public_filename : "/images/mugshot-M.gif"
  end
end