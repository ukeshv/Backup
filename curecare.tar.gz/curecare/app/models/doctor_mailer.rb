class DoctorMailer < ActionMailer::Base
  def email_confirmation(doctor, request)
    @subject         = 'Please confirm your registration'
    @from            = "Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients      = "<#{doctor.email}>"
    @sent_on         = Time.now
    @body[:doctor]     = doctor
    @body[:url]      = "http://#{request.env['HTTP_HOST']}/doctor/activate/#{doctor.activation_code}"
    @body[:site_url] = "http://#{request.env['HTTP_HOST']}/"
    @content_type    = "text/html"
  end
end
