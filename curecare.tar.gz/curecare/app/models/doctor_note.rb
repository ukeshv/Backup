class DoctorNote < ActiveRecord::Base
  belongs_to :doctor
end
