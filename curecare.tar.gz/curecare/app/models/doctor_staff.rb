class DoctorStaff < ActiveRecord::Base
	belongs_to :doctor
	belongs_to :staff
end
