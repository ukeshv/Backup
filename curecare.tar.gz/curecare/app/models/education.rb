class Education < ActiveRecord::Base
	
	belongs_to :doctor
	
end
