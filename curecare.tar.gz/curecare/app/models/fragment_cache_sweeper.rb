class FragmentCacheSweeper < ActionController::Caching::Sweeper

  observe Hospital, Doctor

  def after_create(record)    
    expire_cache_for(record)
  end

  def after_save(record)    
    expire_cache_for(record)
  end

  def after_update(record)    
    expire_cache_for(record)
  end

  def after_destroy(record)    
    expire_cache_for(record)
  end
  
  private
  def expire_cache_for(record)    
    if record.class == Hospital    
      expire_fragment('home_featured_hospitals')
    elsif record.class == Doctor
      expire_fragment('home_featured_doctors')
      expire_fragment('home_new_on_cureandcare')
    end
    
  end


end
