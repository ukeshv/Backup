class Holiday < ActiveRecord::Base
	belongs_to :doctor
	validates_presence_of     :note, :message => "Notes cannot be blank"
end
