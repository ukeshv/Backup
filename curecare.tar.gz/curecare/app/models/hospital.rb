class Hospital < ActiveRecord::Base
  attr_accessor :step	
  belongs_to :user_login
  belongs_to :city
  has_many :doctor_hospitals
  has_many :doctors, :through=>:doctor_hospitals
  has_many :availabilities
  has_many :appointments
  has_many	:hospital_patients
  has_many	:patients, :through=>:hospital_patients
  has_many :hospital_availabilities
  has_many :hospital_holidays
  has_many :hospital_reasons
  has_many :hospital_services
  has_many :hospital_staffs
  has_many :staffs, :through=>:hospital_staffs
	
  validates_presence_of :name, :if => Proc.new { |hospital| hospital.step == 1 }, :message => "Practice Name cannot be blank"
  validates_length_of :name,:if => Proc.new { |hospital| hospital.step == 1 }, :within => 5..50, :too_short => "Practice Name should be in the range of 5 to 50 characters"
  validates_presence_of :address,:if => Proc.new { |hospital| hospital.step == 1 }, :message => "Address cannot be blank"  
  validates_presence_of :city_id,:if => Proc.new { |hospital| hospital.step == 1 }, :message => "Please select a city"
  validates_presence_of :phone_number,:if => Proc.new { |hospital| hospital.step == 1 }, :message => "Phone Number cannot be blank"  
  validates_format_of :phone_number,:if => Proc.new { |hospital| hospital.step == 1 }, :with => /^[0-9]{3}-? ?[0-9]{8}$/, :message =>"Please provide a valid phone number"
  #validates_length_of :phone_number, :within => 5..15, :too_short => "Please provide a valid phone number with in a range "
  validates_presence_of :pincode,:if => Proc.new { |hospital| hospital.step == 1 }, :message => "Pincode cannot be blank"  
  validates_format_of :pincode,:if => Proc.new { |hospital| hospital.step == 1 }, :with =>/^[0-9]{6}$/, :message =>"Provide a valid Pincode"
  validates_format_of :email,:if => Proc.new { |hospital| hospital.step == 1 }, :with => /^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$/ ,:message=>"Provide a valid Email Address"  

	
  def full_address_with_name
    str = []
    if !name.nil?
      str << name
    end
    if !address.nil?
      str << address
    end
    if !city_id.nil? &&  !pincode.nil?
      pin = "-" + pincode
      cty = self.city.name
      cp = "<br/>"+cty + pin
      str << cp
    end
    if !phone_number.nil?
      phone = "<br/> Tel:" + phone_number
      str <<  phone
    end
    str.join(",")
  end
  
  def full_address_without_name
    str = []
    if !address.nil?
      str << address
    end
    if !city_id.nil? &&  !pincode.nil?
      pin = "-" + pincode
      cty = self.city.name
      cp = "<br/>"+cty + pin
      str << cp
    end
    if !phone_number.nil?
      phone = "<br/> Tel:" + phone_number
      str <<  phone
    end
    str.join(",")
  end
	
  def map_address
    str = []    
    if !address.nil?
      add = address.split(",")
      str << add[add.length-1]      
    end
    if !city_id.nil? &&  !pincode.nil?
      pin = " " + pincode
      cty = self.city.name
      cp = " " +  cty + pin
      str << cp
    end        
    str.join(",")        
  end

  def self.image(id)
    image_id=HospitalPhoto.find_by_hospital_id(id)
    !image_id.nil? ? image_id.public_filename : "/images/mugshot-M.gif"
  end

end
