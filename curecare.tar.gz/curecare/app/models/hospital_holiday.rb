class HospitalHoliday < ActiveRecord::Base
		belongs_to :hospital
	validates_presence_of     :note, :message => "Notes cannot be blank"
end
