class HospitalLogin < ActiveRecord::Base
	has_one :hospital
end
