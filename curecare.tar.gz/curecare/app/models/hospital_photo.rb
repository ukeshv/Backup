class HospitalPhoto < ActiveRecord::Base
		 belongs_to :hospital
	 has_attachment :content_type => :image,
                 :storage => :file_system,
								 :path_prefix => 'public/doctor_images',
                 :min_size => 1.kilobytes,
                 :max_size => 3.megabytes,
                 :resize_to => '640x480>',
                 :thumbnails => { :thumb => '80x80>', :tiny => '40x40>' }

                          
  #VALIDATIONS 
 # validates_format_of :content_type, :with=>/^image/, :message=>"Uploading is limited to Pictures"
 validates_as_attachment
end
