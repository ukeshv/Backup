class HospitalReason < ActiveRecord::Base
	belongs_to :hospital
end
