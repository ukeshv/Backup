class HospitalService < ActiveRecord::Base
	belongs_to :hospital
end
