class HospitalStaff < ActiveRecord::Base
	belongs_to :staff
	belongs_to :hospital
end
