class LeadTiming < ActiveRecord::Base
  belongs_to :doctor
end
