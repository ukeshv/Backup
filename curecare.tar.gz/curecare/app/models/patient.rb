class Patient < ActiveRecord::Base
  attr_accessor :step
	
  belongs_to :user_login
  has_many :doctor_patients, :conditions=>'doctor_patients.type_of_relation in (3,4)'
  has_many	:hospital_patients
  has_many	:doctors, :through=>:doctor_patients
  has_many	:appointments	  
	  
  validates_presence_of     :first_name, :if => Proc.new { |patient| patient.step == 1 },  :message => "First Name cannot be blank"
  validates_length_of       :first_name, :if => Proc.new { |patient| patient.step == 1 }, :within => 3..25, :too_short => "First Name should be in the range of 3 to 25 characters"
  validates_format_of :first_name,:if=> Proc.new {|patient| patient.step == 1}, :with => /^[a-zA-Z][a-zA-Z\s\.]+[a-zA-Z]$/ , :message => "First Name should be in alphabets"
  validates_presence_of     :last_name, :if => Proc.new { |patient| patient.step == 1 },   :message => "Last Name cannot be blank"
  validates_length_of       :last_name, :if => Proc.new { |patient| patient.step == 1 }, :within => 3..25, :too_short => "Last Name should be in the range of 3 to 25 characters"
  validates_format_of :last_name,:if=> Proc.new {|patient| patient.step == 1}, :with => /^[a-zA-Z][a-zA-Z\s\.]+[a-zA-Z]$/ , :message => "Last Name should be in alphabets"
  validates_presence_of     :address, :if => Proc.new { |patient| patient.step == 1 },   :message => "Address cannot be blank"
  validates_length_of       :address, :if => Proc.new { |patient| patient.step == 1 }, :within => 5..50, :too_short => "Address should be in the range of 5 to 25 characters"
  validates_presence_of     :city, :if => Proc.new { |patient| patient.step == 1 },   :message => "City cannot be blank"
  validates_length_of       :city, :if => Proc.new { |patient| patient.step == 1 }, :within => 3..25, :too_short => "City should be in the range of 3 to 25 characters"
  validates_presence_of     :state, :if => Proc.new { |patient| patient.step == 1 },   :message => "State cannot be blank"
  validates_length_of       :state, :if => Proc.new { |patient| patient.step == 1 }, :within => 2..25, :too_short => "State should be in the range of 2 to 25 characters"
  validates_presence_of :pincode, :if => Proc.new { |patient| patient.step == 1 }, :message => "Pincode cannot be blank"  
  validates_format_of :pincode, :if => Proc.new { |patient| patient.step == 1 }, :with => /^([0-9]{6})$/, :message =>"Provide a valid Pincode"
  validates_length_of       :title, :if => Proc.new { |patient| patient.step == 1 }, :within => 1..15, :too_short => "Title should be in the range of 1 to 15 characters"  
  validates_format_of :mobile_number, :if => Proc.new { |patient| patient.step == 1 || 2 if patient.step}, :with => /^\+91\s([9]{1})([0-9]{4})(\s)([0-9]{5})$/, :message =>"Provide a valid Mobile No"
  validates_presence_of :home_number, :if => Proc.new { |patient| patient.step == 1 }, :message => "Residential No cannot be blank"  
  validates_format_of :home_number, :if => Proc.new { |patient| patient.step == 1 }, :with => /^[0-9]{3}-? ?[0-9]{8}$/, :message =>"Please provide a valid Residential No"
	
	
  def full_name    
    if !first_name.nil? and !first_name.empty?
      " #{first_name} #{last_name}"
    else
      email =  self.user_login.email
      email = email.split("@")
      email = email[0].capitalize      
    end
  end
  
  def full_address
    str = []
    if !address.nil?
      str << address
    end
    if !city.nil?
      str << city
    end
    if !state.nil?
      str << state
    end
    if !pincode.nil?
      str << pincode
    end
    str.join("<br/>")
  end
	
end