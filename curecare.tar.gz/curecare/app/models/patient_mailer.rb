class PatientMailer < ActionMailer::Base
  def email_confirmation(patient, request)
    @subject         = 'Please confirm your registration'
    @from            = "Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients      = "<#{patient.email}>"
    @sent_on         = Time.now
    @body[:patient]     = patient
    @body[:url]      = "http://#{request.env['HTTP_HOST']}/patient/activate/#{patient.activation_code}"
    @body[:site_url] = "http://#{request.env['HTTP_HOST']}/"
    @content_type    = "text/html"
  end
	
  def change_password(user)
    @subject = 'Your New Password '
    @from            = "Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients      = "<#{user.email}>"
    @sent_on         = Time.now
    @body[:user]     = user
    @content_type    = "text/html"
  end


  def pin_confirmation(patient)
		@subject         = 'Please confirm your registration'
    @from            = "Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients      = "<#{patient.email}>"
    @sent_on         = Time.now
    @body[:patient]     = patient
		@body[:activation] = patient.activation_code
    @content_type    = "text/html"
	end
	


  def doctor_appointment_patient_confirmation(patient, request, pwd)
    @subject         = 'Please confirm your registration'
    @from            = "Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients      = "<#{patient.email}>"
    @sent_on         = Time.now
    @body[:patient]     = patient
    @body[:url]      = "http://#{request.env['HTTP_HOST']}/patient/activate/#{patient.activation_code}"
    @body[:site_url] = "http://#{request.env['HTTP_HOST']}/"        
    @body[:password] = pwd
    @content_type    = "text/html"
  end
	
	def staff_confirmation(staff,request,pwd)
		@subject         = 'Please confirm your registration'
    @from            = "Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients      = "<#{staff.email}>"
    @sent_on         = Time.now
    @body[:staff]     = staff
    @body[:url]      = "http://#{request.env['HTTP_HOST']}/staff/activate/#{staff.activation_code}"
    @body[:site_url] = "http://#{request.env['HTTP_HOST']}/"        
    @body[:password] = pwd
    @content_type    = "text/html"
	end
	
  
  def forgot_password(user,request)
    #setup_email(user)
    @subject  = "Reset your Cure\&Care password"
    @from="Cure\&Care <#{$ADMIN_EMAIL}>"
    @recipients  = "<#{user.email}>"
    @sent_on     = Time.now
    @body[:user] = user
    @body[:url]  = "http://#{request.env['HTTP_HOST']}/reset_password/#{user.password_reset_code}"
    @body[:site_url]="http://#{request.env['HTTP_HOST']}/"
    @content_type = "text/html"
  end

end
