class ProfessionalMembership < ActiveRecord::Base
	
	belongs_to :doctor
	
end
