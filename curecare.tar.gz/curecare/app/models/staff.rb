class Staff < ActiveRecord::Base
	
	belongs_to :user_login
	has_one :doctor_staff
	has_one :doctor, :through=>:doctor_staff
	has_one :hospital_staff
	has_one :hospital, :through=>:hospital_staff
	
	
	 validates_presence_of     :email, :message => "Email cannot be blank"
   validates_format_of :email, :with => /^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$/ ,:message=>"Provide a valid Email Address"  
	 validates_presence_of     :first_name, :message => "First Name cannot be blank"
	 validates_length_of       :first_name, :within => 3..25, :too_short => "Range should be 3-25 characters"
	 validates_format_of :first_name, :with => /^[a-zA-Z]+$/ , :message => "First Name should be in alphabets"
   validates_presence_of     :last_name, :message => "Last Name cannot be blank"
	 validates_length_of       :last_name, :within => 3..25, :too_short => "Range should be 3-25 characters"
	 validates_format_of :last_name, :with => /^[a-zA-Z]+$/ , :message => "Last Name should be in alphabets"
   validates_presence_of     :mobile_number, :message => "Mobile Number cannot be blank"
	 validates_format_of :mobile_number, :with => /^[0-9]{10}$/, :message =>"Mobile Number should be in 10 digit"
	 #validates_length_of       :mobile_number, :within => 5..15, :too_short => "Contact should be in the range of 5 to 15 characters"
end
