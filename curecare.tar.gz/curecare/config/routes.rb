ActionController::Routing::Routes.draw do |map|
  # The priority is based upon order of creation: first created -> highest priority.

  # Sample of regular route:
  #   map.connect 'products/:id', :controller => 'catalog', :action => 'view'
  # Keep in mind you can assign values other than :controller and :action

  # Sample of named route:
  #   map.purchase 'products/:id/purchase', :controller => 'catalog', :action => 'purchase'
  # This route can be invoked with purchase_url(:id => product.id)

  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   map.resources :products

  # Sample resource route with options:
  #   map.resources :products, :member => { :short => :get, :toggle => :post }, :collection => { :sold => :get }

  # Sample resource route with sub-resources:
  #   map.resources :products, :has_many => [ :comments, :sales ], :has_one => :seller
  
  # Sample resource route with more complex sub-resources
  #   map.resources :products do |products|
  #     products.resources :comments
  #     products.resources :sales, :collection => { :recent => :get }
  #   end

  # Sample resource route within a namespace:
  #   map.namespace :admin do |admin|
  #     # Directs /admin/products/* to Admin::ProductsController (app/controllers/admin/products_controller.rb)
  #     admin.resources :products
  #   end

  # You can have the root of your site routed with map.root -- just remember to delete public/index.html.
  map.root :controller => "home"

  # See how all your routes lay out with "rake routes"
  map.resource :home, :controller=>'home'  
  map.resource :user_login
  map.resources :patient_logins, :controller=>'patient_login'
  map.resources :appointments
  map.resources :appointment_signups
  map.resources :sms_confirmations
  map.resource :hospital_login, :controller=>'hospital_login'
  map.resources :patients,:has_many =>[:my_doctors] do |patient|
    patient.resources :appointments, :controller=>'patient_appointments'
    patient.resources :appointment, :controller=>'appointments'
  end
  map.resources :doctors, :has_one=>[:service_profile, :service_reason, :lead_timing, :notification, :reminder, :confirmation_message, :cancellation_policy,:attachment], :has_many =>[:locations, :awaiting_requests, :rescheduled_requests, :cancelled_requests, :holidays, :staffs, :my_patients] do |doctor|
    doctor.resources :appointments, :controller=>'doctor_appointments'
  end
  map.resources :hospitals , :has_one=>[:service_profile,:attachment,:service_reason], :has_many =>[:awaiting_requests,:rescheduled_requests,:cancelled_requests,:holidays,:staffs, :my_patients] do |hospital|
    hospital.resources :appointments, :controller=>'hospital_appointments'
    hospital.resources :doctors, :controller=>"hospital_doctors"
  end
  map.resources :find_a_doctor
  map.resources :find_hospitals
  map.resources :articles
  map.resources :contact_details
	map.resources :passwords
  #map.resources :specialities,:has_many=>[:doctors]
  #map.resources :cities,:has_many=>[:doctors]
  map.resources :specialities do |specialty|
    specialty.resources :doctors
    specialty.resources :cities ,:has_many=>[:doctors]
  end
	
  map.forgot_password '/forgot_password', :controller => 'passwords', :action => 'new'
  map.reset_password '/reset_password/:id', :controller => 'passwords', :action => 'edit'
  map.activate_doctor 'doctor/activate/:activation_code', :controller => 'doctors', :action => 'activate', :activation_code => nil
  map.activate_patient 'patient/activate/:activation_code', :controller => 'patients', :action => 'activate', :activation_code => nil
  map.activate_hospital 'hospital/activate/:activation_code', :controller => 'hospitals', :action => 'activate', :activation_code => nil
  map.activate_staff 'staff/activate/:activation_code', :controller => 'staffs', :action => 'activate', :activation_code => nil
  map.book_appointment 'hospital/:hospital_id/doctor/:doctor_id/appointment/new/:date/:time', :controller=>'appointments', :action=>'new',:date => nil ,:time => nil 
  map.day_wise_appointmet 'doctor/:doctor_id/appointment/:date', :controller=>'doctor_appointments', :action => "index", :date=>nil
  #map.hospital_doctor_appointmet 'hospitals/:hospital_id/appointment/:date', :controller=>'hospital_appointments', :action => "index", :date=>nil
  map.doctor_new_appointment 'doctors/:doctor_id/hospitals/:hospital_id/appointments/:date', :controller=>'doctor_appointments', :action => "new", :date=>nil
  map.doctor_appointment_weekly 'doctors/:doctor_id/hospitals/:hospital_id/week/:week_no/day/:day/appointments/:date', :controller=>'doctor_appointments', :action => "new", :date=>nil#, :week_no=>nil
  map.hospital_doctor_appointment 'hospitals/:hospital_id/doctors/:doctor_id/week/:week_no/day/:day/appointments/:date', :controller=>'hospital_appointments', :action => "new", :date=>nil#, :week_no=>nil
  map.doctor_create_appointment 'doctors/:doctor_id/hospitals/:hospital_id/', :controller=>'doctor_appointments', :action => "create"
  map.hospital_doctor_create_appointment 'hospitals/:hospital_id/doctors/:doctor_id/', :controller=>'hospital_appointments', :action => "create"
  map.show_calendar 'doctors/:doctor_id/show_calendar/:date', :controller=>'doctor_appointments', :action => "show_calendar",:date=>nil
  map.activate_appointment_signup 'appointment/patient/:activation_code', :controller =>'sms_confirmations', :action => 'activate', :activation_code => nil
  map.search_doctor 'doctors/search/:search_text', :controller => 'doctors' , :action=>'index', :search_text => nil    
  map.location_doctor 'doctors/location/:location_text', :controller => 'doctors' , :action=>'index', :location_text => nil
  map.search_location 'doctors/search/:search_text/location/:location_text', :controller => 'doctors' , :action=>'index', :location_text => nil
  map.hospital_doctor 'hospitals/:hospital_id/doctors/specialty_doctor/:sid', :controller => 'hospital_doctors' , :action=>'specialty_doctor', :sid => nil
  map.hospital_doctor_profile 'hospitals/:hospital_id/doctors/new/:sub_tab', :controller => 'hospital_doctors', :action => 'new', :sub_tab=>nil
  map.hospital_doctor_create_profile 'hospitals/:hospital_id/doctors/create/:sub_tab', :controller => 'hospital_doctors', :action => 'create', :sub_tab=>nil
  map.hospital_doctor_edit_profile 'hospitals/:hospital_id/doctors/:doctor_id/edit/:sub_tab', :controller => 'hospital_doctors', :action => 'edit', :sub_tab=>nil
  map.hospital_doctor_update_profile 'hospitals/:hospital_id/doctors/:doctor_id/update/:sub_tab', :controller => 'hospital_doctors', :action => 'update', :sub_tab=>nil
  map.hospital_doctor_destroy_holiday 'hospitals/:hospital_id/doctors/:doctor_id/destroy/:holiday_id', :controller => 'hospital_doctors', :action => 'destroy_holidays'
  map.home_search 'home/search/:search_text', :controller => 'home', :action=>'show', :search_text=>nil 
  map.home_location 'home/location/:location_text', :controller => 'home', :action=>'show', :location_text=>nil 
  map.home_search_location 'home/search/:search_text/location/:location_text', :controller => 'home', :action=>'show', :location_text=>nil 
  map.hospital_search 'hospitals/search/:search_text', :controller => 'find_hospitals', :action=>'show', :search_text=>nil 
  map.hospital_location 'hospitals/location/:location_text', :controller => 'find_hospitals', :action=>'show', :location_text=>nil 
  map.hospital_search_location 'hospitals/search/:search_text/location/:location_text', :controller => 'find_hospitals', :action=>'show', :location_text=>nil 
  
  
  map.appointment_cancel 'appointment/:id/cancel', :controller=>'appointments', :action=>'cancel'
  map.change_appointment 'appointment/:id/change', :controller=>'appointments', :action=>'change_appointment'
  map.set_reminder_appointment 'appointment/:id/set_reminder', :controller=>'appointments', :action=>'set_reminder'
  map.update_reminder_appointment 'appointment/:id/update_reminder', :controller=>'appointments', :action=>'update_reminder'
  map.get_direction 'appointment/:id/get_direction', :controller=>'appointments', :action=>'get_direction'
  map.doctor_reload_availabilities 'doctor/:doctor_id/reload_availabilities/:id/:date', :controller => 'awaiting_requests', :action=> 'reload_availabilities', :date=>nil
  map.hospital_reload_availabilities 'hospital/:hospital_id/reload_availabilities/:id/:date', :controller => 'awaiting_requests', :action=> 'hospital_reload_availabilities', :date=>nil
  
  #reminder 
  # Install the default routes as the lowest priority.
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
end
