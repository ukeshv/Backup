class CreatePatientLogins < ActiveRecord::Migration
  def self.up
    create_table :patient_logins do |t|
      t.string :email      
      t.string :crypted_password, :salt, :limit => 40  
      t.string :activation_code, :limit => 5  
      t.datetime :activated_at
      t.string :password_reset_code, :limit => 40 
      t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :patient_logins
  end
end
