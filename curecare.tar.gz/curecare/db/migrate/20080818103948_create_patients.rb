class CreatePatients < ActiveRecord::Migration
  def self.up
    create_table :patients do |t|
      t.integer :user_login_id
      t.string :title
      t.string :first_name
      t.string :last_name
      t.string :home_number
      t.string :mobile_number
      t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :patients
  end
end
