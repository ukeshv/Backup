class CreateDoctors < ActiveRecord::Migration
  def self.up
    create_table :doctors do |t|
      t.integer :user_login_id
      t.string :salutation
      t.string :first_name
      t.string :last_name
      t.string :suffix
      t.string :home_number
      t.string :mobile_number
      t.string :professional_summary
      t.integer :min_lead_time, :default => 1
      t.integer :max_lead_time, :default => 1
      t.boolean :notify_for_appointment, :default => 0
      t.boolean :notify_for_cancellation, :default => 0
      t.boolean :notify_for_reschedule, :default => 0
      t.string :notification_email
      t.string :notification_phone
      t.boolean :enable_notification, :default => 0
      t.text :notification_message
      t.boolean :cancellation_of_appointment, :default => 1
      t.integer :cancellation_time_limit, :default => 8
      t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :doctors
  end
end
