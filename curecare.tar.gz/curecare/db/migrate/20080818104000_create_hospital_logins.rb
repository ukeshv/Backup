class CreateHospitalLogins < ActiveRecord::Migration
  def self.up
    create_table :hospital_logins do |t|

      t.timestamps
    end
  end

  def self.down
    drop_table :hospital_logins
  end
end
