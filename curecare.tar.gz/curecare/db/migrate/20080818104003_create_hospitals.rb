class CreateHospitals < ActiveRecord::Migration
  def self.up
    create_table :hospitals do |t|
      t.integer :hospital_login_id
      t.string :name
      t.string :address
      t.integer :city_id
      t.string :state
      t.string :pincode
      t.string :email
      t.string :phone_number
      t.string :website
      t.float :latitude, :limit => 53 
      t.float :longitude, :limit => 53
      t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :hospitals
  end
end
