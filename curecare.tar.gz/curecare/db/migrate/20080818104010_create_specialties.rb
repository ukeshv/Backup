class CreateSpecialties < ActiveRecord::Migration
  def self.up
    create_table :specialties do |t|
      t.string :name
      t.integer :flag, :default => 1
      t.timestamps
    end
    Specialty.create(:name=>'Anesthesiologist')
    Specialty.create(:name=>'Asthma-Allergy Specialist')    
    Specialty.create(:name=>'Audiologist Cardiac')
    Specialty.create(:name=>'Cardiologist')
    Specialty.create(:name=>'Cardiologist Pediatric')
    Specialty.create(:name=>'Colorectal Doctor')
    Specialty.create(:name=>'Dermatologist')
    Specialty.create(:name=>'Diabetes Specialist')
    Specialty.create(:name=>'Endocrinologist')
    Specialty.create(:name=>'Fibromyalgia Doctor')
    Specialty.create(:name=>'Gastroenterologist')
    Specialty.create(:name=>'General Practitioner')
    Specialty.create(:name=>'Geneticist')
    Specialty.create(:name=>'Geriatrician')
    Specialty.create(:name=>'OBGYN Hematologist')
    Specialty.create(:name=>'Infectious Disease')
    Specialty.create(:name=>'Specialist Integrative Doctor')    
    Specialty.create(:name=>'Nurse Practitioner')
    Specialty.create(:name=>'Nurse Midwife')    
    Specialty.create(:name=>'Medicine Specialist')
    Specialty.create(:name=>'Oncologist')
    Specialty.create(:name=>'Pediatric')
    Specialty.create(:name=>'Pediatric Oncologist')
    Specialty.create(:name=>'Neurologist')
    Specialty.create(:name=>'Pediatric Neurologist')
    Specialty.create(:name=>'Pathologist')
  end

  def self.down
    drop_table :specialties
  end
end
