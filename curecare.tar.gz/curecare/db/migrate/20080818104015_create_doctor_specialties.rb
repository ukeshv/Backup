class CreateDoctorSpecialties < ActiveRecord::Migration
  def self.up
    create_table :doctor_specialties do |t|
			t.integer :doctor_id
			t.integer :specialty_id
			t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :doctor_specialties
  end
end
