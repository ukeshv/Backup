class CreateEducations < ActiveRecord::Migration
  def self.up
    create_table :educations do |t|
			t.integer :doctor_id
			t.text :detail
			t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :educations
  end
end
