class CreateProfessionalMemberships < ActiveRecord::Migration
  def self.up
    create_table :professional_memberships do |t|
			t.integer :doctor_id
			t.text :detail
			t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :professional_memberships
  end
end
