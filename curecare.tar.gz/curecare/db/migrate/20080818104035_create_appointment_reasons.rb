class CreateAppointmentReasons < ActiveRecord::Migration
  def self.up
    create_table :appointment_reasons do |t|
			t.integer :doctor_id
			t.string :name
			t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :appointment_reasons
  end
end
