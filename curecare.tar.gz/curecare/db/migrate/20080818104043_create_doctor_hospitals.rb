class CreateDoctorHospitals < ActiveRecord::Migration
  def self.up
    create_table :doctor_hospitals do |t|
			t.integer :doctor_id
			t.integer :hospital_id
			t.integer :slot_duration
			t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :doctor_hospitals
  end
end
