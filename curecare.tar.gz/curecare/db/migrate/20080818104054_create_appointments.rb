class CreateAppointments < ActiveRecord::Migration
  def self.up
    create_table :appointments do |t|
			t.integer :doctor_id
			t.integer :patient_id
			t.integer :hospital_id
			t.date :appointment_date
			t.date :rescheduled_date
			t.time :start_time
			t.time :end_time
			t.string :service_for_visit
			t.string :reason_for_visit
			t.integer :doctor_status_flag
			t.integer :patient_status_flag
			t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :appointments
  end
end
