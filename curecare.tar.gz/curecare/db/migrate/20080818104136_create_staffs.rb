class CreateStaffs < ActiveRecord::Migration
  def self.up
    create_table :staffs do |t|
			t.integer :doctor_id
			t.string :first_name
			t.string :last_name
			t.string :email
			t.string :crypted_password,:salt, :limit => 40
			t.string :home_number
			t.string :mobile_number
			t.boolean :appointment_notification_by_sms, :default => 0
			t.boolean :appointment_notification_by_email, :default => 0
			t.boolean :add_flag, :default => 0
			t.boolean :cancel_flag, :default => 0
			t.boolean :reschedule_flag, :default => 0
			t.boolean :confirm_flag, :default => 0
			t.integer :permission
			t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :staffs
  end
end
