class CreateCities < ActiveRecord::Migration
  def self.up
    create_table :cities do |t|
      t.string :name
			t.integer :flag, :default => 1
      t.timestamps
    end
		City.create(:name=>'Agra')
		City.create(:name=>'Ahmedabad')
		City.create(:name=>'Allahabad')
		City.create(:name=>'Amritsar')
		City.create(:name=>'Aurangabad')
		City.create(:name=>'Bangalore')
		City.create(:name=>'Bhopal')
		City.create(:name=>'Chandigarh')
		City.create(:name=>'Chennai')
		City.create(:name=>'Delhi')
		City.create(:name=>'Faridabad')
		City.create(:name=>'Ghaziabad')
		City.create(:name=>'Howrah')
		City.create(:name=>'Hyderabad')
		City.create(:name=>'Indore')
		City.create(:name=>'Jabalpur')
		City.create(:name=>'Jaipur')
		City.create(:name=>'Kalyan-Dombivli')
		City.create(:name=>'Kanpur')
		City.create(:name=>'Kolkata')
		City.create(:name=>'Lucknow')
		City.create(:name=>'Ludhiana')
		City.create(:name=>'Meerut')
		City.create(:name=>'Mumbai')
		City.create(:name=>'Nagpur')
		City.create(:name=>'Nashik')
		City.create(:name=>'Navi Mumbai')
		City.create(:name=>'Patna')
		City.create(:name=>'Pimpri Chinchwad')
		City.create(:name=>'Pune')
		City.create(:name=>'Rajkot')
		City.create(:name=>'Ranchi')
		City.create(:name=>'Solapur')
		City.create(:name=>'Srinagar')
		City.create(:name=>'Surat')
		City.create(:name=>'Thane')
		City.create(:name=>'Vadodara')
		City.create(:name=>'Varanasi')
		City.create(:name=>'Visakhapatnam')
  end

  def self.down
    drop_table :cities
  end
end
