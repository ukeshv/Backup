class CreateAvailabilities < ActiveRecord::Migration
  def self.up
    create_table :availabilities do |t|
      t.integer :doctor_id
      t.integer :hospital_id
      t.integer :day
      t.time :start_time
      t.time :end_time
      t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :availabilities
  end
end
