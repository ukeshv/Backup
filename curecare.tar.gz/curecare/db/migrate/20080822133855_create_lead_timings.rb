class CreateLeadTimings < ActiveRecord::Migration
  def self.up
    create_table :lead_timings do |t|
      t.integer :doctor_id
      t.integer :cancellation_hours
      t.integer :booking_days      
      t.timestamps
    end
  end

  def self.down
    drop_table :lead_timings
  end
end
