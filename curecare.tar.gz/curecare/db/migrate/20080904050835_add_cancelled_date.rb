class AddCancelledDate < ActiveRecord::Migration
  def self.up
		add_column :appointments,:cancelled_date,:date
  end

  def self.down
		remove_column :appointments,:cancelled_date
  end
end
