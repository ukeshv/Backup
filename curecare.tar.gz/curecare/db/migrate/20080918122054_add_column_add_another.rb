class AddColumnAddAnother < ActiveRecord::Migration
  def self.up
    add_column :availabilities,:add_another,:integer
  end

  def self.down
    remove_column :availabilities,:add_another
  end
end
