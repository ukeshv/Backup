class AddPatientAddress < ActiveRecord::Migration
  def self.up
    add_column :patients,:address,:string
    add_column :patients,:city,:string
    add_column :patients,:state,:string
    add_column :patients,:pincode,:string
  end

  def self.down
		remove_column :patients,:address
		remove_column :patients,:city
		remove_column :patients,:state
		remove_column :patients,:pincode
  end
end
