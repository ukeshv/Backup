class CreateDoctorNotes < ActiveRecord::Migration
  def self.up
    create_table :doctor_notes do |t|
      t.integer :doctor_id
      t.integer :patient_id
      t.date    :on
      t.text    :notes
      t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :doctor_notes
  end
end
