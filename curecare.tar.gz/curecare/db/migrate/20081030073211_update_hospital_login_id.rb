class UpdateHospitalLoginId < ActiveRecord::Migration
  def self.up
    rename_column "hospitals", "hospital_login_id", "user_login_id" 
  end

  def self.down
    rename_column "hospitals", "user_login_id", "hospital_login_id" 
  end
end
