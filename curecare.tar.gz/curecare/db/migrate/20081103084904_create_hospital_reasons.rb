class CreateHospitalReasons < ActiveRecord::Migration
  def self.up
    create_table :hospital_reasons do |t|
			t.integer :hospital_id
			t.string :name
			t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :hospital_reasons
  end
end
