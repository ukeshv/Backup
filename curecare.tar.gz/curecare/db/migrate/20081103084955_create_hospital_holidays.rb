class CreateHospitalHolidays < ActiveRecord::Migration
  def self.up
    create_table :hospital_holidays do |t|
			t.integer :hospital_id
			t.date :start_date
			t.date :end_date
			t.string :note
			t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :hospital_holidays
  end
end
