class CreateDoctorStaffs < ActiveRecord::Migration
  def self.up
    create_table :doctor_staffs do |t|
      t.integer :doctor_id
      t.integer :staff_id
			t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :doctor_staffs
  end
end
