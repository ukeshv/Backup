class AddDoctorContactDetail < ActiveRecord::Migration
  def self.up
		add_column :doctors,:address,:string
		add_column :doctors,:city_id,:integer
		add_column :doctors,:state,:string
		add_column :doctors,:pincode,:string
		add_column :doctors,:personal_email,:string
		add_column :doctors,:website,:string
		add_column :doctors,:emergency_number,:string
		add_column :hospitals,:professional_summary,:string
  end

  def self.down
		remove_column :doctors,:address
		remove_column :doctors,:city_id
		remove_column :doctors,:state
		remove_column :doctors,:pincode
		remove_column :doctors,:personal_email
		remove_column :doctors,:website
		remove_column :doctors,:emergency_number
		remove_column :hospitals,:professional_summary
  end
end
