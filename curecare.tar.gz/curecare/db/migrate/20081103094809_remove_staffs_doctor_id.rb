class RemoveStaffsDoctorId < ActiveRecord::Migration
  def self.up
		remove_column :staffs,:doctor_id
  end

  def self.down
		add_column :staffs,:doctor_id
  end
end
