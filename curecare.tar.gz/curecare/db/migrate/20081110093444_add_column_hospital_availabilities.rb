class AddColumnHospitalAvailabilities < ActiveRecord::Migration
  def self.up
		add_column :hospital_availabilities,:add_another,:integer
  end

  def self.down
		remove_column :hospital_availabilities,:add_another
  end
end
