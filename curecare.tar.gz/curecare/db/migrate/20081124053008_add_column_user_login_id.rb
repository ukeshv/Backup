class AddColumnUserLoginId < ActiveRecord::Migration
  def self.up
		add_column :staffs,:user_login_id,:integer
		remove_column :staffs,:crypted_password
		remove_column :staffs,:salt
		
  end

  def self.down
		remove_column :staffs,:user_login_id
		add_column :staffs,:crypted_password
		add_column :staffs,:salt
  end
end
