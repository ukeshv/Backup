class CreateHospitalPatients < ActiveRecord::Migration
  def self.up
    create_table :hospital_patients do |t|
      t.integer :hospital_id
      t.integer :patient_id
      t.integer :type_of_relation
      t.integer :flag, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :hospital_patients
  end
end
