class ChangeDoctorMinMaxLeadtime < ActiveRecord::Migration
  def self.up
    change_column :doctors, :min_lead_time, :integer , :default => 0
    change_column :doctors, :max_lead_time, :integer , :default => 0
  end

  def self.down
    change_column :doctors, :min_lead_time, :integer , :default => 1
    change_column :doctors, :max_lead_time, :integer , :default => 1
  end
end
