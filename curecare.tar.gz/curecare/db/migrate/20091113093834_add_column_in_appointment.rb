class AddColumnInAppointment < ActiveRecord::Migration
  def self.up
    add_column :appointments, :reason, :string 
    add_column :appointments, :is_cancel, :boolean ,:default=>false
  end

  def self.down
    remove_column :appointments, :reason
    remove_column :appointments, :is_cancel
  end
end
