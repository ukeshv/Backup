class CreateAppointmentReminders < ActiveRecord::Migration
  def self.up
    create_table :appointment_reminders do |t|
      t.integer :appointment_id 
      t.boolean :send_sms ,:default=>false
      t.string :sms_to
      t.boolean :send_email ,:default=>false
      t.string :email_to
      t.boolean :is_sent, :default => false      
      t.boolean :flag, :default => false
      t.timestamps
    end
  end

  def self.down
    drop_table :appointment_reminders
  end
end
