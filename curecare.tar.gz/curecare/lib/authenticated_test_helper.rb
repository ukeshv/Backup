module AuthenticatedTestHelper
  # Sets the current patient in the session from the patient fixtures.
  def login_as(patient)
    @request.session[:patient_id] = patient ? patients(patient).id : nil
  end

  def authorize_as(user)
    @request.env["HTTP_AUTHORIZATION"] = user ? ActionController::HttpAuthentication::Basic.encode_credentials(users(user).login, 'test') : nil
  end
end
