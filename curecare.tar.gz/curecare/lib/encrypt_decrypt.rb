require 'openssl'

$key = "A75435F0B240012A9489000C2952E41F"

class String

  def encrypt(key=$key)
    e = OpenSSL::Cipher::Cipher.new 'DES-EDE3-CBC'
    e.encrypt key
    s = e.update self
    s << e.final
    s = s.unpack('H*')[0].upcase
    s
  end

  def decrypt(key=$key)
    e = OpenSSL::Cipher::Cipher.new 'DES-EDE3-CBC'
    e.decrypt key
    s = self.to_a.pack("H*").unpack("C*").pack("c*")
    s = e.update s
    s << e.final
    s
  end

end

