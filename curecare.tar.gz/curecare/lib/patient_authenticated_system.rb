module PatientAuthenticatedSystem
  protected
    # Returns true or false if the patient is logged in.
    # Preloads @current_patient with the patient model if they're logged in.
    def logged_in?
      !!current_patient
    end

    # Accesses the current patient from the session. 
    # Future calls avoid the database because nil is not equal to false.
    def current_patient
      @current_patient ||= (login_from_session || login_from_basic_auth || login_from_cookie) unless @current_patient == false
    end

    # Store the given patient id in the session.
    def current_patient=(new_patient)
      session[:patient_id] = new_patient ? new_patient.id : nil
      @current_patient = new_patient || false
    end

    # Check if the patient is authorized
    #
    # Override this method in your controllers if you want to restrict access
    # to only a few actions or if you want to check if the patient
    # has the correct rights.
    #
    # Example:
    #
    #  # only allow nonbobs
    #  def authorized?
    #    current_patient.login != "bob"
    #  end
    def authorized?
      logged_in?
    end

    # Filter method to enforce a login requirement.
    #
    # To require logins for all actions, use this in your controllers:
    #
    #   before_filter :login_required
    #
    # To require logins for specific actions, use this in your controllers:
    #
    #   before_filter :login_required, :only => [ :edit, :update ]
    #
    # To skip this in a subclassed controller:
    #
    #   skip_before_filter :login_required
    #
    def login_required
      authorized? || access_denied
    end

    # Redirect as appropriate when an access request fails.
    #
    # The default action is to redirect to the login screen.
    #
    # Override this method in your controllers if you want to have special
    # behavior in case the patient is not authorized
    # to access the requested action.  For example, a popup window might
    # simply close itself.
    def access_denied
      respond_to do |format|
        format.html do
          store_location
          redirect_to new_patient_login_path
        end
        format.any do
          request_http_basic_authentication 'Web Password'
        end
      end
    end

    # Store the URI of the current request in the session.
    #
    # We can return to this location by calling #redirect_back_or_default.
    def store_location
      session[:return_to] = request.request_uri
    end

    # Redirect to the URI stored by the most recent store_location call or
    # to the passed default.
    def redirect_back_or_default(default)
      redirect_to(session[:return_to] || default)
      session[:return_to] = nil
    end

    # Inclusion hook to make #current_patient and #logged_in?
    # available as ActionView helper methods.
    def self.included(base)
      base.send :helper_method, :current_patient, :logged_in?
    end

    # Called from #current_patient.  First attempt to login by the patient id stored in the session.
    def login_from_session
      self.current_patient = PatientLogin.find_by_id(session[:patient_id]) if session[:patient_id]
    end

    # Called from #current_patient.  Now, attempt to login by basic authentication information.
    def login_from_basic_auth
      authenticate_with_http_basic do |username, password|
        self.current_patient = PatientLogin.authenticate(username, password)
      end
    end

    # Called from #current_patient.  Finaly, attempt to login by an expiring token in the cookie.
    def login_from_cookie
      patient = cookies[:auth_token] && PatientLogin.find_by_remember_token(cookies[:auth_token])
      if patient && patient.remember_token?
        cookies[:auth_token] = { :value => patient.remember_token, :expires => patient.remember_token_expires_at }
        self.current_patient = patient
      end
    end
end
