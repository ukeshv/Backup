module UserLoginAuthenticatedSystem
  protected
  # Returns true or false if the user_login is logged in.
  # Preloads @current_user_login with the user_login model if they're logged in.
  def logged_in? 
    !!current_user_login
  end

  # Accesses the current user_login from the session. 
  # Future calls avoid the database because nil is not equal to false.
  def current_user_login
    @current_user_login ||= (login_from_session || login_from_basic_auth || login_from_cookie) unless @current_user_login == false
  end
    
  def current_doctor
    doctor = current_user_login.doctor if current_user_login
    doctor ? doctor : nil    
  end
    
  def current_patient
    patient = current_user_login.patient if current_user_login
    patient ? patient : nil
  end

  def current_staff
		staff = current_user_login.staff if current_user_login
		staff ? staff : nil
	end
	

  # Store the given user_login id in the session.
  def current_user_login=(new_user_login)
    session[:user_login_id] = new_user_login ? new_user_login.id : nil
	    if new_user_login.doctor
      session[:login_type]= "doctor"
    elsif new_user_login.hospital
      session[:login_type]= "hospital"
    elsif new_user_login.patient
      session[:login_type]= "patient"
    elsif new_user_login.staff     
			staff=new_user_login.staff
				if !staff.doctor.nil?
					session[:login_type]="doctor_staff"
				elsif !staff.hospital.nil?
          session[:login_type]="hospital_staff"
				end
    end
    @current_user_login = new_user_login || false
  end

  # Check if the user_login is authorized
  #
  # Override this method in your controllers if you want to restrict access
  # to only a few actions or if you want to check if the user_login
  # has the correct rights.
  #
  # Example:
  #
  #  # only allow nonbobs
  #  def authorized?
  #    current_user_login.login != "bob"
  #  end
  def authorized?
    logged_in?
  end

  # Filter method to enforce a login requirement.
  #
  # To require logins for all actions, use this in your controllers:
  #
  #   before_filter :login_required
  #
  # To require logins for specific actions, use this in your controllers:
  #
  #   before_filter :login_required, :only => [ :edit, :update ]
  #
  # To skip this in a subclassed controller:
  #
  #   skip_before_filter :login_required
  #
  def login_required
    authorized? || access_denied
  end

  # Redirect as appropriate when an access request fails.
  #
  # The default action is to redirect to the login screen.
  #
  # Override this method in your controllers if you want to have special
  # behavior in case the user_login is not authorized
  # to access the requested action.  For example, a popup window might
  # simply close itself.
  def access_denied
    respond_to do |format|
      format.html do
        store_location
        redirect_to new_user_login_path
      end
      format.any do
        request_http_basic_authentication 'Web Password'
      end
    end
  end

  # Store the URI of the current request in the session.
  #
  # We can return to this location by calling #redirect_back_or_default.
  def store_location
    session[:return_to] = request.request_uri
  end

  # Redirect to the URI stored by the most recent store_location call or
  # to the passed default.
  def redirect_back_or_default(default)
    redirect_to(session[:return_to] || default)
    session[:return_to] = nil
  end

  # Inclusion hook to make #current_user_login and #logged_in?
  # available as ActionView helper methods.
  def self.included(base)
    base.send :helper_method, :current_user_login, :logged_in?
  end

  # Called from #current_user_login.  First attempt to login by the user_login id stored in the session.
  def login_from_session
    self.current_user_login = UserLogin.find_by_id(session[:user_login_id]) if session[:user_login_id]
  end

  # Called from #current_user_login.  Now, attempt to login by basic authentication information.
  def login_from_basic_auth
    authenticate_with_http_basic do |username, password|
      self.current_user_login = UserLogin.authenticate(username, password)
    end
  end

  # Called from #current_user_login.  Finaly, attempt to login by an expiring token in the cookie.
  def login_from_cookie
    user_login = cookies[:auth_token] && UserLogin.find_by_remember_token(cookies[:auth_token])
    if user_login && user_login.remember_token?
      cookies[:auth_token] = { :value => user_login.remember_token, :expires => user_login.remember_token_expires_at }
      self.current_user_login = user_login
    end
  end
end
