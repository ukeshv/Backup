// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults
	function recognised_msg(){
		if (document.getElementById("route").innerHTML == ""){
			alert("We could not calculate directions!!!");}
			}
			
function set_validation(is_sms_enable,sms,is_email_enable,email){
 var val = true;        
 var val1 = validateSMS(val,is_sms_enable,sms);
	var val2 = validateEmail(val,is_email_enable,email);
	if((val1 == false) || (val2 == false))
		return false;
}

function validateSMS(val,is_sms_enable,sms){
   var reg= new RegExp(/^\+91\s([9]{1})([0-9]{4})(\s)([0-9]{5})$/);
	 var sms = document.getElementById(sms)
		if ((is_sms_enable == true) && (sms.value.length <=0)){
		Element.show('sms_error');
		val = false;
		}
		else if((is_sms_enable == true) && (reg.test(sms.value) == false)){
		Element.show('sms_error');
		val = false;
		}
		else{
		Element.hide('sms_error');
		document.getElementById(sms) = "";
		val = true;
		}
		return val;
}

function validateEmail(val,is_email_enable,email){
 var email = document.getElementById(email)
		if ((is_email_enable == true) && (email.value.length <=0)){
		Element.show('email_error');
		val = false;
		}
		else{
		Element.hide('email_error');
		val = true;
		}
		return val;
}

 function format_date(d) {
    var dt = new Date(d);
    var full_month=new Array("01","02","03","04","05","06","07","08","09","10","11","12")
    var full_day=new Array("","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31")
    date = full_day[dt.getDate()];    
    month = full_month[dt.getMonth()];
    year = dt.getFullYear();
    var str = ""+year+month+date+"";
    return str
  }
	
	
 function check_time(){
		if ($('time') && !($('time').value == "")) {
			return true;
		}
		else{
			alert("We cannot reschedule to this date");
			return false;
		}
	}