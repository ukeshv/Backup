/* To add another education text box*/
function add_another_education() {
    display(4,'show_education_link','hide_education_link','education_text');
    if ((document.getElementsByClassName('education_text').length)<5){
        var educationDiv = document.getElementById('education');
        var educationTxtDiv = new Element('div');    
        educationTxtDiv.className = "education_text";
        var inputEducationField=document.createElement('input');
        inputEducationField.setAttribute('type','text');
        inputEducationField.setAttribute('name','education[][detail]');        
        inputEducationField.style.width='500px';            
        inputEducationField.className='service_profile_education';
        educationTxtDiv.appendChild(inputEducationField);
        var anchorClose = document.createElement('a');
        anchorClose.href='#';
        anchorClose.onclick=function(){return  remove_education_field(this.parentNode)}
        anchorClose.innerHTML='<img src="/images/lay/close.png">';        
        educationTxtDiv.appendChild(anchorClose);
        var spanError = document.createElement('span');
        spanError.className='education_error';
        educationTxtDiv.appendChild(spanError);
        educationDiv.appendChild(educationTxtDiv); 
    }
}

/* To remove another education text box*/
function remove_education_field(dom_element){
    display(6,'show_education_link','hide_education_link','education_text');
    dom_element.parentNode.removeChild(dom_element);
    if ((document.getElementsByClassName('education_text').length)==0){
        add_another_education();
    }
    return false;
}

/* To add another membership text box*/
function add_another_membership() {
    display(4,'show_membership_link','hide_membership_link','membership_text');
    if ((document.getElementsByClassName('membership_text').length)<5){
        var membershipDiv = document.getElementById('membership');
        var membershipTxtDiv = new Element('div');    
        membershipTxtDiv.className = "membership_text";
        var inputMemberField=document.createElement('input');
        inputMemberField.setAttribute('type','text');
        inputMemberField.setAttribute('name','professional_membership[][detail]');        
        inputMemberField.style.width='500px';  
        inputMemberField.className="service_profile_membership";
        membershipTxtDiv.appendChild(inputMemberField);
        var anchorClose = document.createElement('a');
        anchorClose.href='#';
        anchorClose.onclick=function(){return  remove_membership_field(this.parentNode)}
        anchorClose.innerHTML='<img src="/images/lay/close.png">';
        membershipTxtDiv.appendChild(anchorClose);
        var spanError = document.createElement('span');
        spanError.className='membership_error';
        membershipTxtDiv.appendChild(spanError);
        membershipDiv.appendChild(membershipTxtDiv); 
    }
}

/* To remove another education text box*/
function remove_membership_field(dom_element){
    display(6,'show_membership_link','hide_membership_link','membership_text');
    dom_element.parentNode.removeChild(dom_element);
    if ((document.getElementsByClassName('membership_text').length)==0){
        add_another_membership();
    }
    return false;
}

/* To add another speciality select box*/
function add_another_speciality() {
    display(2,'show_speciality_link','hide_speciality_link','select_speciality');
    if ((document.getElementsByClassName('select_speciality').length)<3){
        var specialityDiv = document.getElementById('speciality');
        var specialitySelectDiv = new Element('div');    
        specialitySelectDiv.className = "select_speciality";
        specialitySelectDiv.style.width = '600px'
        var Select=document.createElement("select");
        Select.setAttribute('name','speciality[][id]'); 
        Select.setAttribute('id','speciality_id');
        Select.style.width="300px";
        Select.className='service_profile_speciality';
        Select.options.add(new Option('Select Speciality',''));      
        for(i=0;i<speciality.length;i++){
            Select.options.add(new Option(speciality[i][1],speciality[i][0]))
        }
        specialitySelectDiv.appendChild(Select);
        var anchorClose = document.createElement('a');
        anchorClose.href='#';
        anchorClose.onclick=function(){return  remove_speciality_field(this.parentNode)}
        anchorClose.innerHTML='<img src="/images/lay/close.png">';
        specialitySelectDiv.appendChild(anchorClose);
        var spanError = document.createElement('span');
        spanError.className='speciality_error';
        specialitySelectDiv.appendChild(spanError);
        specialityDiv.appendChild(specialitySelectDiv); 
    }
}

/* To remove another speciality select box*/
function remove_speciality_field(dom_element){
    display(4,'show_speciality_link','hide_speciality_link','select_speciality');
    dom_element.parentNode.removeChild(dom_element);
    if ((document.getElementsByClassName('select_speciality').length)==0){
        add_another_speciality();
    }
    return false;
}

/* To add another doctor service text box*/
function add_another_doctor_service() {
    display(9,'show_doctor_service_link','hide_doctor_service_link','doctor_service');
    if ((document.getElementsByClassName('doctor_service').length)<10){
        var serviceDiv = document.getElementById('service');
        var serviceTxtDiv = new Element('div');    
        serviceTxtDiv.className = "doctor_service";
        serviceTxtDiv.style.width = '600px'
        var inputServiceField=document.createElement('input');
        inputServiceField.setAttribute('type','text');
        inputServiceField.setAttribute('name','appointment_service[][name]');        
        inputServiceField.style.width='300px';            
        inputServiceField.className='doctor_service_text';
        serviceTxtDiv.appendChild(inputServiceField);
        var anchorClose = document.createElement('a');
        anchorClose.href='#';
        anchorClose.onclick=function(){return  remove_doctor_service_field(this.parentNode)}
        anchorClose.innerHTML='<img src="/images/lay/close.png">';        
        serviceTxtDiv.appendChild(anchorClose);
        var spanError = document.createElement('span');
        spanError.className='doctor_service_error';
        serviceTxtDiv.appendChild(spanError);
        serviceDiv.appendChild(serviceTxtDiv); 
    }
}

/* To remove another doctor service text box*/
function remove_doctor_service_field(dom_element){    
    display(11,'show_doctor_service_link','hide_doctor_service_link','doctor_service');    
    dom_element.parentNode.removeChild(dom_element);
    if ((document.getElementsByClassName('doctor_service').length)==0){
        add_another_doctor_service();
        validateServiceReason();
    }
    return false;
}

/* To add another doctor reason text box*/
function add_another_doctor_reason() {
    display(9,'show_doctor_reason_link','hide_doctor_reason_link','doctor_reason');
    if ((document.getElementsByClassName('doctor_reason').length)<10){
        var reasonDiv = document.getElementById('reason');
        var reasonTxtDiv = new Element('div');    
        reasonTxtDiv.className = "doctor_reason";
        reasonTxtDiv.style.width='600px';
        var inputreasonField=document.createElement('input');
        inputreasonField.setAttribute('type','text');
        inputreasonField.setAttribute('name','appointment_reason[][name]');        
        inputreasonField.style.width='300px';            
        inputreasonField.className='doctor_reason_text';
        reasonTxtDiv.appendChild(inputreasonField);
        var anchorClose = document.createElement('a');
        anchorClose.href='#';
        anchorClose.onclick=function(){return  remove_doctor_reason_field(this.parentNode)}
        anchorClose.innerHTML='<img src="/images/lay/close.png">';        
        reasonTxtDiv.appendChild(anchorClose);
        var spanError = document.createElement('span');
        spanError.className='doctor_reason_error';
        reasonTxtDiv.appendChild(spanError);
        reasonDiv.appendChild(reasonTxtDiv); 
    }
}

/* To remove another doctor reason text box*/
function remove_doctor_reason_field(dom_element){
    display(11,'show_doctor_reason_link','hide_doctor_reason_link','doctor_reason');
    dom_element.parentNode.removeChild(dom_element);
    if ((document.getElementsByClassName('doctor_reason').length)==0){
        add_another_doctor_reason();
        validateServiceReason();
    }
    return false;
}

/* To add another consulting times select box*/
function add_another_consulting_times(mainDiv,subDiv,ele,showLink,hideLink) {    
    display(2,showLink,hideLink,subDiv);
    var elements = document.getElementsByClassName(subDiv).length;
    if (elements<3){        
        var consultingTimeDiv = document.getElementById(mainDiv);
        var timeSelectDiv = new Element('div');    
        timeSelectDiv.className = subDiv;
        timeSelectDiv.style.width="70px";
        timeSelectDiv.style.height="70px";
        var startSelect=document.createElement("select");
        var sname = "time["+ele+"][start][]";
        startSelect.setAttribute('name',sname);
        var sid = "time_"+ele+"__start_";
        startSelect.setAttribute('id',sid);
        startSelect.style.width="50px";        
        startSelect.className='start_time';        
        for(i=0;i<consultingTimes.length;i++){
            startSelect.options.add(new Option(consultingTimes[i][1],consultingTimes[i][0]));
        }
        timeSelectDiv.appendChild(startSelect);
        var anchorClose = document.createElement('a');
        anchorClose.href='#';
        anchorClose.className = ('show_close_link_'+ele);
        anchorClose.onclick=function(){return  remove_consulting_times(this.parentNode,subDiv,showLink,hideLink,mainDiv,ele)}
        anchorClose.innerHTML='<img src="/images/lay/close.png">';
        timeSelectDiv.appendChild(anchorClose);
        var spanTo = document.createElement('span');
        spanTo.innerHTML = "<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To<br/>";
        timeSelectDiv.appendChild(spanTo);
        var endSelect=document.createElement("select");
        var ename = "time["+ele+"][end][]";
        endSelect.setAttribute('name',ename);
        var eid = "time_"+ele+"__end_";
        endSelect.setAttribute('id',eid);
        endSelect.style.width="50px";        
        endSelect.className='end_time';        
        for(i=0;i<consultingTimes.length;i++){
            endSelect.options.add(new Option(consultingTimes[i][1],consultingTimes[i][0]));
        }
        timeSelectDiv.appendChild(endSelect);        
        var spanError = document.createElement('span');
        spanError.className='select_consulting_times_error';
        timeSelectDiv.appendChild(spanError);
        consultingTimeDiv.appendChild(timeSelectDiv); 
        //include_side_lable();
    }
}

/* to include side lable like from to for consulting timings*/
function include_side_lable() {    
    var main_div = document.getElementById('side_lable_main');
    var lable_div = document.getElementsByClassName('side_lable');
    for(i=0;i<=6;i++){
        subDiv = "select_consulting_times_"+i;
        var elements = document.getElementsByClassName(subDiv).length;
        if (lable_div.length < elements && lable_div.length < 3){
            var new_div = document.createElement('div');
            new_div.className="side_lable";
            var h5From = document.createElement('h5');
            h5From.innerHTML="From";
            h5From.className="from";
            var h5To = document.createElement('h5');
            h5To.innerHTML="To";
            h5To.className="to";
            new_div.appendChild(h5From);
            new_div.appendChild(h5To);
            main_div.appendChild(new_div);
            break;
        }
    }    
}

/* To remove consulting times select box*/
function remove_consulting_times(dom_element,subDiv,showLink,hideLink,mainDiv,ele){    
    display(4,showLink,hideLink,subDiv);        
    dom_element.parentNode.removeChild(dom_element);    
    //remove_side_lable();    
    if ((document.getElementsByClassName(subDiv).length)==0){        
        add_another_consulting_times(mainDiv,subDiv,ele,showLink,hideLink);
    }
    return false;
}

/*to remove side lable like from to for consulting timings*/
function remove_side_lable(){
    var main_div = document.getElementById('side_lable_main');
    var lable_div = document.getElementsByClassName('side_lable');    
    var select_ele = new Array();
    for(i=0;i<=6;i++){
        subDiv = "select_consulting_times_"+i;
        var elements = document.getElementsByClassName(subDiv).length;      
        select_ele[i] = elements;        
    }     
    if (select_ele.include(lable_div.length) == false){                        
        var dom = lable_div[lable_div.length-1];
        dom.parentNode.removeChild(dom);            
    }    
}


/* To show and hide the Limited value div elements*/
function display(len,ref1,ref2,ref3){
    if ((document.getElementsByClassName(ref3).length)<len){        
        $(ref1).style.display='';
        $(ref2).style.display='none';
    }
    else
        {
            $(ref1).style.display='none';
            $(ref2).style.display='';
        }
    }
    
    /*To validate input fileds of Doctor Account Settings Service Profile page*/  
    function validateServiceProfile(){
        var val = true;        
        val = validateDoctorSalutation(val);
        val = validateDoctorFirstName(val);
        val = validateDoctorLastName(val);
        val = validateDoctorSuffix(val);
        val = validateDoctorSpeciality(val);                
        //val = validateDoctorEducation(val);
        //val = validateDoctorMembership(val);        
        return val;
    }
    
    /*To validate Doctor Account Settings Service Profile - Speciality*/
    function validateDoctorSpeciality(val) {  
        var speciality_boxes = document.getElementsByClassName("service_profile_speciality");
        var specialities_error_span = document.getElementsByClassName("speciality_error");
        for(j=0;j<speciality_boxes.length;j++)
            {
                var speciality_box = speciality_boxes[j];
                if (speciality_box.value=='' || speciality_box.value==null){
                    specialities_error_span[j].innerHTML="<font color='red'>Specialty is mandatory</font>";
                    specialities_error_span[j].style.display='';
                    val = false                        
                } 
                else {
                    specialities_error_span[j].style.display='none';                    
                }                
            }      
            return val;
        }
        
        /*To validate Doctor Account Settings Service Profile - Education*/
        function validateDoctorEducation(val) {
            var education_boxes = document.getElementsByClassName("service_profile_education");
            var education_error_span = document.getElementsByClassName("education_error");
            for(j=0;j<education_boxes.length;j++)
                {
                    var education_box = education_boxes[j];                    
                    if (education_box.value=='' || education_box.value==null){
                        education_error_span[j].innerHTML="<font color='red'>It cannot be blank</font>";
                        education_error_span[j].style.display='';
                        val = false;                        
                    } 
                    else {
                        education_error_span[j].style.display='none';                    
                    }                
                }      
                return val;
            }
            
            /*To validate Doctor Account Settings Service Profile - Membership*/
        function validateDoctorMembership(val) { 
            var mambership_boxes = document.getElementsByClassName("service_profile_membership");
            var membership_error_span = document.getElementsByClassName("membership_error");
            for(j=0;j<mambership_boxes.length;j++)
                {
                    var membership_box = mambership_boxes[j];
                    if (membership_box.value=='' || membership_box.value==null){
                        membership_error_span[j].innerHTML="<font color='red'>It cannot be blank</font>";
                        membership_error_span[j].style.display='';
                        val = false;                        
                    } 
                    else {
                        membership_error_span[j].style.display='none';                    
                    }                
                }      
                return val;
            }
            
        /*To validate Doctor Account Settings Service Profile - Salutation*/
        function validateDoctorSalutation(val) { 
            var salutation_box = document.getElementById("doctor_salutation");
            var doctor_salutation_error_span = document.getElementById("doctor_salutation_error");
            if (salutation_box.value=='' || salutation_box.value==null){
                doctor_salutation_error_span.innerHTML="<font color='red'>Select a Salutation</font>";
                doctor_salutation_error_span.style.display='';
                val = false;                        
            } 
            else {
                doctor_salutation_error_span.style.display='none';                    
            }
            return val;
        }
                
        /*To validate Doctor Account Settings Service Profile - First Name*/
        function validateDoctorFirstName(val) { 
            var doctor_first_name_box = document.getElementById("doctor_first_name");
            var doctor_first_name_error_span = document.getElementById("doctor_first_name_error");
            if (doctor_first_name_box.value=='' || doctor_first_name_box.value==null){
                doctor_first_name_error_span.innerHTML="<font color='red'>First Name cannot be blank</font>";
                doctor_first_name_error_span.style.display='';
                val = false;                        
            } 
            else {
                doctor_first_name_error_span.style.display='none';                    
            }
            return val;
        }
                
        /*To validate Doctor Account Settings Service Profile - Last Name*/
        function validateDoctorLastName(val) { 
            var doctor_last_name_box = document.getElementById("doctor_last_name");
            var doctor_last_name_error_span = document.getElementById("doctor_last_name_error");
            if (doctor_last_name_box.value=='' || doctor_last_name_box.value==null){
                doctor_last_name_error_span.innerHTML="<font color='red'>Last Name cannot be blank</font>";
                doctor_last_name_error_span.style.display='';
                val = false;                        
            } 
            else {
                doctor_last_name_error_span.style.display='none';                    
            }
            return val;
        }
                
        /*To validate Doctor Account Settings Service Profile - Suffix*/
        function validateDoctorSuffix(val) { 
            var doctor_suffix_box = document.getElementById("doctor_suffix");
            var doctor_suffix_error_span = document.getElementById("doctor_suffix_error");
            if (doctor_suffix_box.value=='' || doctor_suffix_box.value==null){
                doctor_suffix_error_span.innerHTML="<font color='red'>Suffix cannot be blank</font>";
                doctor_suffix_error_span.style.display='';
                val = false;                        
            } 
            else {
                doctor_suffix_error_span.style.display='none';                    
            }
            return val;
        }
                
        /*To validate input fileds of Doctor Account Settings Service Reasons page*/  
        function validateServiceReason(){
            var val = true;                                           
            val = validateDoctorService(val);
            val = validateDoctorReason(val);        
            return val;
        }
        
        /*To validate Doctor Account Settings Service Reason - Service*/
        function validateDoctorService(val) {
            var doctor_service_boxes = document.getElementsByClassName("doctor_service_text");
            var doctor_service_error_span = document.getElementsByClassName("doctor_service_error");
            for(j=0;j<doctor_service_boxes.length;j++)
                {
                    var alphaExp = /^[a-zA-Z]+$/;
                    var doctor_service_box = doctor_service_boxes[j];                    
                    if (doctor_service_box.value=='' || doctor_service_box.value==null){
                        doctor_service_error_span[j].innerHTML="<font color='red'>It cannot be blank</font>";
                        doctor_service_error_span[j].style.display='';
                        val = false;                        
                    } 
                    else if(doctor_service_box.value.gsub(" ","").match(alphaExp)==null){
                        doctor_service_error_span[j].innerHTML="<font color='red'>Only Letters</font>";
                        doctor_service_error_span[j].style.display='';
                        val = false; 
                    }
                    else {
                        doctor_service_error_span[j].style.display='none';                    
                    }                
                }      
                return val;
            }
                    
        /*To validate Doctor Account Settings Service Reason - Reason*/
        function validateDoctorReason(val) {
            var doctor_reason_boxes = document.getElementsByClassName("doctor_reason_text");
            var doctor_reason_error_span = document.getElementsByClassName("doctor_reason_error");
            for(j=0;j<doctor_reason_boxes.length;j++)
                {
                    var alphaExp = /^[a-zA-Z]+$/;
                    var doctor_reason_box = doctor_reason_boxes[j];                    
                    if (doctor_reason_box.value=='' || doctor_reason_box.value==null){
                        doctor_reason_error_span[j].innerHTML="<font color='red'>It cannot be blank</font>";
                        doctor_reason_error_span[j].style.display='';
                        val = false;                      
                    }
                    else if(doctor_reason_box.value.gsub(" ","").match(alphaExp)==null){
                        doctor_reason_error_span[j].innerHTML="<font color='red'>Only Letters</font>";
                        doctor_reason_error_span[j].style.display='';
                        val = false; 
                    }
                    else {
                        doctor_reason_error_span[j].style.display='none';                    
                    }                
                }      
                return val;
            }
                        
        /*To validate Locations and Consulting Hours consulting select boxes*/
        function validateLocationsConsultations() { 
            var val = true;
            val = validateConsultationTimings(val);                              
            //val = validateSlotDuration(val);
            return val;
        }
        
        /*To validate Locations and Consulting Hours consulting select boxes*/
        function validateLocationsConsultationsWithOutSlot() {
            var val = true;
            val = validateConsultationTimings(val);                                                        
            return val;
        }
        
                        
                        
        function validateConsultationTimings(val) { 
            var consultation_check_boxes = document.getElementsByClassName("consulting_days_chkbox");  
            var error = document.getElementById("select_consult_time_error");
            for(j=0;j<consultation_check_boxes.length;j++)
                { 
                    var consultation_check_box = consultation_check_boxes[j];                    
                    if (consultation_check_box.checked == true){                                         
                        var start_time = document.getElementById("time_"+j+"__start_");  
                        var end_time = document.getElementById("time_"+j+"__end_");                                          
                        if(start_time.selectedIndex!=0 && end_time.selectedIndex!=0 && start_time.selectedIndex < end_time.selectedIndex && start_time.selectedIndex != end_time.selectedIndex)      
                            { 
                                error.style.display='none';                                                    
                            }
                            else { 
                                start_time.style.border = "1px solid #F20909"; 
                                end_time.style.border = "1px solid #F20909"; 
                                error.style.display=''; 
                                val = false; 
                            }
                            
                        }
                    }   
                    validateSlotDuration();
                    return val;
                }
                
        function enableConsultingTimes() { 
            var consultation_check_boxes = document.getElementsByClassName("consulting_days_chkbox");                                                                          
            for(j=0;j<consultation_check_boxes.length;j++)
                { 
                    var consultation_check_box = consultation_check_boxes[j];    
                    var div_boxes = document.getElementById("consulting_times_"+j);
                    var org_show_link = document.getElementById("show_consulting_times_link_"+j); 
                    var dup_show_link = document.getElementById("dummy_show_consulting_times_link_"+j); 
                    var limited_link = document.getElementById("hide_consulting_times_link_"+j).style.display;
                    var close_links = document.getElementsByClassName("show_close_link_"+j);                                                                                    
                    var start_time = document.getElementById("time_"+j+"__start_");  
                    var end_time = document.getElementById("time_"+j+"__end_");  
                    if (consultation_check_box.checked == true){ 
                        start_time.removeAttribute("disabled");
                        end_time.removeAttribute("disabled");   
                        for(k=0;k<close_links.length;k++){
                            close_link = close_links[k];
                            close_link.style.display = '';
                        }
                        if (limited_link == "none"){
                            dup_show_link.style.display = 'none';
                            org_show_link.style.display = '';
                        }
                    }
                    else if (consultation_check_box.checked == false){ 
                        start_time.disabled ="disabled";
                        end_time.disabled ="disabled";
                        for(k=0;k<close_links.length;k++){ 
                            close_link = close_links[k];
                            close_link.style.display = 'none'; 
                        } 
                        if (limited_link == "none"){ 
                            dup_show_link.style.display = ''; 
                            org_show_link.style.display = 'none';     
                        }
                    }                                            
                }
            }
            
        function validateSlotDuration() {
            var slot_box = document.getElementById('slot_time');
            //var error = document.getElementById("slot_error")
            if(slot_box && slot_box.selectedIndex==0)
                { 
                    //slot_box.style.borderColor="red"                                                
                    //error.style.display='';                                                
                    $('slot_error_val').value = 1;
                    //val = true
                }
                else {
                    //slot_box.style.borderColor="black"
                    //error.style.display='none';
                }
                //return val
            }  
            
            function valSlotDuration() {
                var slot_box = document.getElementById('slot_time');                                            
                if(slot_box.selectedIndex==0)
                    {
                        slot_box.style.borderColor="red";                                                
                    }
                    else {
                        slot_box.style.borderColor="grey";                                                
                    }
                }
                                            
function getAutoLocation(text, li) { 
    var details = li.id;
    var details_ary = [];
    details_ary = details.split('~');                                            
    $('hospital_address').value = details_ary[0];
    $('hospital_city_id').selectedIndex = details_ary[1];
    $('hospital_state').value = details_ary[2];
    $('hospital_pincode').value = details_ary[3];
    $('hospital_email').value = details_ary[4];
    $('hospital_phone_number').value = details_ary[5];
    $('hospital_website').value = details_ary[6];                                            
}

function validateDoctorNotes() {
    var val = true;
    var notes = document.getElementById('doctor_note_notes');
    var error = document.getElementById("error");                                        
    if(notes.value.length <= 0)
        {                                                  
            error.style.display='';
            val = false;
        }
        else {                                                         
            error.style.display='none';
        }
        return val;
    }
    
    function getEmailPhone(text, li) {
        var details = li.id;
        var details_ary = [];
        details_ary = details.split('~');                                                                                            
        $('patient_phone').value = details_ary[0];
        $('patient_email').value = details_ary[1];
    }  
    
    /*To validate Doctor booking appointments*/
    function validateDoctorAppointment() { 
        var val = true;
        val = validateDoctorAppointmentName(val);                                                                                
        val = validateDoctorAppointmentPhone(val);                                                    
        val = validateDoctorAppointmentEmail(val);                                                                                                    
        return val;
    }
    
    function validateDoctorAppointmentName(val) {                                                
        var name = document.getElementById('patient_name');                                                
        var name_error = document.getElementById("name_error");                                                
        if(name.value.length <= 0)
            {                                                  
                name_error.style.display='';
                val = false;
            }
            
            else {                                                         
                name_error.style.display='none';                                                                                                            
            }
            return val;
        }
        
        
        function validateDoctorAppointmentPhone(val) {
            var phone = document.getElementById('patient_phone');
            var phone_error = document.getElementById("phone_error");                                        
            if(phone.value.length <= 0)
                {
                    phone_error.style.display='';                                                    
                    val = false;
                }
                else {                                                                                                                             
                    phone_error.style.display='none';                                                    
                }
                return val;
            }
            

    function validateDoctorAppointmentEmail(val) {
        var email = document.getElementById('patient_email').value;
        var email_error = document.getElementById("email_error");                                        
        var emailRegEx = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(email.length <= 0)
            {
                email_error.style.display='';                                                    
                val = false;
            }
            else if (email.length > 0 && email.match(emailRegEx)==null){  
                alert('Please enter a valid email address.');
                val = false;                                                               
            }
            
            else {                                                                                                                         
                email_error.style.display='none';                                                    
            }
            return val;
        }
        
        
      function check_note(){
       var notes = document.getElementById('holiday_note').value;
       if(notes.strip() == "")
              {                                                  
                    Element.show('note_error');
                    return false;
              }
              else 
              {     
                  Element.hide('note_error');
                  return true;
              }
        }


         function check_doctor_note(){
          var notes = document.getElementById('holiday_note').value;
          if(notes.strip() == "")
              {                                                  
                    Element.show('note_error');
                    return false;
              }
              else 
              {     
                  Element.hide('note_error');
                  return true;
              }
          }


        function check_hospital_note()
        {                                                              
          var notes = document.getElementById('hospital_holiday_note').value;                                                             
            if(notes.strip() == "")
              {                                                  
                    Element.show('note_error');
                    return false;
              }
              else 
              {     
                  Element.hide('note_error');
                  return true;
              }
              
        }

        function check_terms_of_service(){
        if (document.getElementById('term_of_service').checked){
        return true;
        }
        else{
          alert('Accept Terms of Use');
          return false;
        }	
      }
      
      
       function check_all(){ 
    var check_boxes= document.getElementsByClassName('checkbox');
    for(i=0;i<check_boxes.length;i++){     
      if ($('checkall').checked==true){
        if (check_boxes[i].disabled==false){
          check_boxes[i].checked=true;
        }
      }
      else{
        check_boxes[i].checked=false;
      }
    }
  }
	
	function valid_check(){
    var cn=document.getElementsByClassName("checkbox"); 
    var check=false;    
		for(i=0;i<cn.length;i++)
    {
			if (cn[i].checked == true)
			{
					check = true;
			}
		}
		if (check== true)
    {
     return confirm('Are you sure ?');     
    }
    else
    {
       alert("Please select a holiday");
       return false;
    }
	}
      

