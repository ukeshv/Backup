require 'test_helper'

class AppointmentMailerTest < ActionMailer::TestCase
  tests AppointmentMailer
  # replace this with your real tests
  def test_truth
    assert true
  end
end
