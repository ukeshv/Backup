require 'test_helper'

class HospitalMailerTest < ActionMailer::TestCase
  tests HospitalMailer
  # replace this with your real tests
  def test_truth
    assert true
  end
end
