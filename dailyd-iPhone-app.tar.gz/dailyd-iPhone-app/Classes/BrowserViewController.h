//
//  BrowserViewController.h
//  DailyD
//
//  Created by Ronak Shah on 16/03/11.
//  Copyright 2011 http://agileinfoways.com. All rights reserved.
//

#import "Globals.h"


@interface BrowserViewController : UIViewController {
	IBOutlet UIWebView *webView;
	NSString *strUrl;
	NSString *strSource;
	DailyDAppDelegate *appDelegate;
}
@property (nonatomic, retain) NSString *strUrl;
@property (nonatomic, retain) NSString *strSource;

-(IBAction)btnPrevPage_clicked;
-(IBAction)btnNextPage_clicked;
-(IBAction)btnReloadPage_clicked;

@end
