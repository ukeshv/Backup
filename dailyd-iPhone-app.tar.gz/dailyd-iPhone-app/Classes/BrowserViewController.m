//
//  BrowserViewController.m
//  DailyD
//
//  Created by Ronak Shah on 16/03/11.
//  Copyright 2011 http://agileinfoways.com. All rights reserved.
//

#import "BrowserViewController.h"


@implementation BrowserViewController
@synthesize strUrl;
@synthesize strSource;


-(IBAction)btnPrevPage_clicked{
	[webView goBack];
}
-(IBAction)btnNextPage_clicked{
	[webView goForward];
}
-(IBAction)btnReloadPage_clicked{
	[webView reload];
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	appDelegate = (DailyDAppDelegate *)[[UIApplication sharedApplication]delegate];
	self.navigationItem.title = self.strSource;
	NSLog(@"deal url %@",self.strUrl);
	NSLog(@"deal source %@",self.strSource);
	
	NSURL *url = [NSURL URLWithString:self.strUrl];
	NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
	[webView loadRequest:request];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
