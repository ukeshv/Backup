//
//  CatDealsViewController.h
//  DailyD
//
//  Created by Vimal Shah on 3/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface CatDealsViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,MBProgressHUDDelegate> {

	DailyDAppDelegate *appDelegate;
	
	IBOutlet UITableView *tblView;
	
	int selIndex;
    NSString *selLocationName;
    MBProgressHUD *HUD;
    int setCatId;
    int setLocId;
}

@property (nonatomic, retain)IBOutlet UITableView *tblView;

@property int selIndex;
@property (nonatomic, retain) NSString *selLocationName;
@property int setCatId;
@property int setLocId;

-(void)showDeals:(int)page;
@end
