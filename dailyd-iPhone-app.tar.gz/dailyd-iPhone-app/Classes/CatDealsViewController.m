//
//  CatDealsViewController.m
//  DailyD
//
//  Created by Vimal Shah on 3/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CatDealsViewController.h"
#import "DealCellView.h"
#import "WebService.h"

@implementation CatDealsViewController

@synthesize tblView;
@synthesize selIndex;
@synthesize selLocationName;
@synthesize setLocId;
@synthesize setCatId;
NSMutableArray *dealArray;

NSArray *tempArray;
WebService *service;
int page=1;
BOOL started;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	service=[[WebService alloc] init];
    dealArray=[[NSMutableArray alloc] init];
    NSLog(@"view did load");
	appDelegate = (DailyDAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    appDelegate.arrLocDeals=[[NSMutableArray alloc] init];
	self.tblView.backgroundColor = [UIColor lightGrayColor];
    
	if (self.selIndex == 0) {
		//[appDelegate arrAllCatDealsFromObjDict:appDelegate.arrDeals];
	}
    [self showDeals:1];
}

- (void)viewWillAppear:(BOOL)animated {
    if (self.selIndex == 0)
        self.navigationItem.title = [NSString stringWithFormat:@"הצג הכל - %@",self.selLocationName];
    
	/*
     else
     self.navigationItem.title = [NSString stringWithFormat:@"%@ - %@",[[appDelegate.arrMutableDealsByLocationsSubCategories objectAtIndex:self.selIndex-1] objectForKey:@"header"],self.selLocationName];*/
    
	[self.tblView deselectRowAtIndexPath:[self.tblView indexPathForSelectedRow] animated:YES];
    
}


-(void)showDeals:(int)page {
	// The hud will dispable all input on the view (use the higest view possible in the view hierarchy)
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	
    // Add HUD to screen
    [self.navigationController.view addSubview:HUD];
	
    // Regisete for HUD callbacks so we can remove it from the window at the right time
    HUD.delegate = self;
	
    HUD.labelText = @"Loading";
	HUD.detailsLabelText = @"dailyD!";
    // Show the HUD while the provided method executes in a new thread
    [HUD showWhileExecuting:@selector(loadingStart:) onTarget:self withObject:[NSNumber numberWithInt:page] animated:YES];
}

- (void)loadingStart:(NSNumber*)page {
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
    NSString *jsonString;
    
    //  jsonString = [service apiCategoriesLocation:appDelegate.setAPIUrl catId:[page intValue]];
    jsonString=[service apiDealsHome:appDelegate.setAPIUrl catId:self.setCatId locId:self.setLocId pageno:[page intValue]];
    
	//NSLog(@"json : %@",jsonString);
	NSError *error;
	SBJSON *json = [[SBJSON new] autorelease];
    tempArray   = [json objectWithString:jsonString error:&error];
    [appDelegate.arrLocDeals addObjectsFromArray:tempArray ];
	
	//[appDelegate arrDealsFromObjDictByCategoriesWithSubLocations:appDelegate.arrMutableDealsByCategoriesSubLocations];
	
	[self performSelectorOnMainThread:@selector(loadingComplete) withObject:nil waitUntilDone:YES];
	
	[pool release];
}

-(void) loadingComplete {
    NSArray *arrDict=tempArray;
    
    
    for (int i=0; i<arrDict.count; i++) {
        
        
        Deal *objDeal=[[Deal alloc] init];
        [objDeal setTitle:[[arrDict objectAtIndex:i] valueForKey:@"title"]];
        [objDeal setAddress:[[arrDict objectAtIndex:i] valueForKey:@"address"]];
        [objDeal setEnds_at:[[arrDict objectAtIndex:i] valueForKey:@"ends_at"]];
        
        //		NSLog(@"%@ in Original GMT\n\n", aDeal.ends_at);
        
        NSDate *dateInLocalGMT = [appDelegate parseDateString:[objDeal.ends_at substringToIndex:19] withGMTString:[objDeal.ends_at substringFromIndex:20]];
        [objDeal setDt_ends_at:dateInLocalGMT];
        [objDeal setPrice:[[[arrDict objectAtIndex:i] valueForKey:@"price"] intValue]];
        [objDeal setImage_url:[[arrDict objectAtIndex:i] valueForKey:@"image_url"]];
        [objDeal setValue:[[[arrDict objectAtIndex:i] valueForKey:@"value"] intValue]];
        [objDeal setSave:[[[arrDict objectAtIndex:i] valueForKey:@"save"] intValue]];
        [objDeal setDescription:[[arrDict objectAtIndex:i] valueForKey:@"description"]];
        [objDeal setDeal_url:[[arrDict objectAtIndex:i] valueForKey:@"deal_url"]];
        [objDeal setSource:[[arrDict objectAtIndex:i] valueForKey:@"source"]];
        
        NSArray *arrCat = [[arrDict objectAtIndex:i] valueForKey:@"categories"];
        Category *aCategory = [[Category alloc] init];
        aCategory.id = [[[arrCat objectAtIndex:0] valueForKey:@"id"] intValue];
        aCategory.name = [[arrCat objectAtIndex:0] valueForKey:@"name"];
        arrCat = [NSArray arrayWithObjects:aCategory, nil];
        [objDeal setCategories:arrCat];
        
        NSArray *arrLoc = [[arrDict objectAtIndex:i] valueForKey:@"locations"];
        Location *aLocation = [[Location alloc] init];
        aLocation.id = [[[arrLoc objectAtIndex:0] valueForKey:@"id"] intValue];
        aLocation.name = [[arrLoc objectAtIndex:0] valueForKey:@"name"];
        arrLoc = [NSArray arrayWithObjects:aLocation, nil];
        [objDeal setLocations:arrLoc];
        
        [dealArray addObject:objDeal];
    }
    
    //	NSLog(@"value   %@",appDelegate.arrMutableDealsByCategoriesSubLocations);
	[self.tblView reloadData];
}



#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	/*if (self.selIndex == 0)
     return [appDelegate.arrMutableDealsByCategoriesSubLocations count];
     else*/
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	/*if (self.selIndex == 0)
     return [[[appDelegate.arrMutableDealsByCategoriesSubLocations objectAtIndex:section] objectForKey:@"value"] count];
     else
     return [[[appDelegate.arrMutableDealsByCategoriesSubLocations objectAtIndex:self.selIndex-1] objectForKey:@"value"] count];*/
    return [appDelegate.arrLocDeals count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	return 100;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	if (self.selIndex == 0)
		return 30;
	else
		return 0;
}

/*
 - (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
 {
 // create the parent view that will hold header Label
 UIView* customView = [[UIView alloc] initWithFrame:CGRectMake(10.0, 10.0, 300.0, 30.0)];
 //CGFloat rd = 56/255;
 customView.backgroundColor = appDelegate.clrCell;
 //customView.backgroundColor = [UIColor clearColor];
 // create the button object
 UILabel * headerLabel = [[UILabel alloc] initWithFrame:CGRectZero];
 headerLabel.backgroundColor = [UIColor clearColor];
 headerLabel.opaque = NO;
 headerLabel.textColor = [UIColor blackColor];
 headerLabel.shadowOffset = CGSizeMake(0.0, 1.0);
 headerLabel.highlightedTextColor = [UIColor grayColor];
 headerLabel.font = [UIFont boldSystemFontOfSize:16];
 //[headerLabel setFont:[UIFont fontWithName:appDelegate.pref_font size:12]];    
 
 headerLabel.frame = CGRectMake(10.0, 0.0, 290.0, 30.0);
 headerLabel.textAlignment = UITextAlignmentRight;
 
 // If you want to align the header text as centered
 // headerLabel.frame = CGRectMake(150.0, 0.0, 300.0, 44.0);
 
 //if (self.selIndex == 0)
 //	headerLabel.text = [[appDelegate.arrMutableDealsByLocationsAllSections objectAtIndex:section] objectForKey:@"header"];
 
 [customView addSubview:headerLabel];
 
 return customView;
 
 }
 */
/*
 // Customize the appearance of table view cells.
 - (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
 
 static NSString *CellIdentifier = @"Cell";
 
 UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
 //    if (cell == nil) {
 //	cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
 //    }
 cell = [[[ClearLabelsCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
 cell.backgroundView = [[[GradientView alloc] init] autorelease];
 
 // Configure the cell.
 
 DealCellView *objCell = [[DealCellView alloc] init];
 [cell.contentView addSubview:objCell.view];
 [objCell.view setFrame:CGRectMake(0, 0, 320, 44)];
 
 Deal *objDeal;
 if (self.selIndex == 0) {
 objDeal = [[[appDelegate.arrMutableDealsByLocationsSubCategories objectAtIndex:indexPath.section] objectForKey:@"value"] objectAtIndex:indexPath.row];
 } else {
 objDeal = [[[appDelegate.arrMutableDealsByLocationsSubCategories objectAtIndex:selIndex-1] objectForKey:@"value"] objectAtIndex:indexPath.row];
 }
 
 [cell.contentView addSubview:objCell.activityIndicator];
 [objCell.activityIndicator startAnimating];
 
 objCell.lblPrice.text = [NSString stringWithFormat:@"%d",objDeal.price];
 [cell.contentView addSubview:objCell.lblPrice];
 
 objCell.lblDiscount.text = [NSString stringWithFormat:@"%d%%",objDeal.save];
 //	[NSString stringWithFormat:@"%d%%",objDeal.save];
 [cell.contentView addSubview:objCell.lblDiscount];
 
 objCell.lblTitle.text = objDeal.title;
 [cell.contentView addSubview:objCell.lblTitle];
 
 objCell.lblSite.text = objDeal.source;
 objCell.lblSite.textColor = appDelegate.clrSourceText;
 [cell.contentView addSubview:objCell.lblSite];
 
 [cell.contentView addSubview:objCell.imgDealImage];
 if (objDeal.imgDeal != nil) {
 //	UIImage *img = [appDelegate imageByScalingProportionallyToSize:CGSizeMake(100, 96) srcImg:objDeal.imgDeal];
 objCell.imgDealImage.image = objDeal.imgDeal;
 } else {
 objCell.imgDealImage.image = [UIImage imageNamed:@"100X80_thumb.png"];
 if (![objDeal.image_url isEqualToString:@""]) {
 NSMutableArray *arrObjects = [[NSMutableArray alloc] init];
 [arrObjects addObject:objDeal];
 [arrObjects addObject:objCell];
 [NSThread detachNewThreadSelector:@selector(loadImage:) toTarget:self withObject:arrObjects];
 }
 }
 
 //	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
 return cell;
 }*/
// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	//    if (cell == nil) {
    //	cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	//    }
	cell = [[[ClearLabelsCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	cell.backgroundView = [[[GradientView alloc] init] autorelease];
    
	// Configure the cell.
	
	DealCellView *objCell = [[DealCellView alloc] init];
	[cell.contentView addSubview:objCell.view];
	[objCell.view setFrame:CGRectMake(0, 0, 320, 44)];
	
	Deal *objDeal=[[[Deal alloc] init] autorelease];
    objDeal.image_url=[[appDelegate.arrLocDeals objectAtIndex:indexPath.row] valueForKey:@"image_url"];
    [cell.contentView addSubview:objCell.activityIndicator];
	[objCell.activityIndicator startAnimating];
    objCell.lblPrice.text = [NSString stringWithFormat:@"%@",[[appDelegate.arrLocDeals objectAtIndex:indexPath.row] valueForKey:@"price"]];
	[cell.contentView addSubview:objCell.lblPrice];
	
	objCell.lblDiscount.text = [NSString stringWithFormat:@"%@%%",[[appDelegate.arrLocDeals objectAtIndex:indexPath.row] valueForKey:@"save"]];
	[cell.contentView addSubview:objCell.lblDiscount];
	objCell.lblDistance.text=[NSString stringWithFormat:@"%@",[[appDelegate.arrLocDeals objectAtIndex:indexPath.row] valueForKey:@"value"]];
    [cell.contentView addSubview:objCell.lblDistance];
	objCell.lblTitle.text = [[appDelegate.arrLocDeals objectAtIndex:indexPath.row] valueForKey:@"title"];
	[cell.contentView addSubview:objCell.lblTitle];
	
	objCell.lblSite.text = [[appDelegate.arrLocDeals objectAtIndex:indexPath.row] valueForKey:@"source"];
	objCell.lblSite.textColor = appDelegate.clrSourceText;
	[cell.contentView addSubview:objCell.lblSite];
    
    [cell.contentView addSubview:objCell.imgDealImage];
	if (objDeal.imgDeal != nil) {
        //		UIImage *img = [appDelegate imageByScalingProportionallyToSize:CGSizeMake(100, 96) srcImg:objDeal.imgDeal];
		objCell.imgDealImage.image = objDeal.imgDeal;
	} else {
		objCell.imgDealImage.image = [UIImage imageNamed:@"100X80_thumb.png"];
		if (![objDeal.image_url isEqualToString:@""]) {
			NSMutableArray *arrObjects = [[NSMutableArray alloc] init];
			[arrObjects addObject:objDeal];
			[arrObjects addObject:objCell];
			[NSThread detachNewThreadSelector:@selector(loadImage:) toTarget:self withObject:arrObjects];
		}
	}
    
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}


- (void)loadImage :(NSMutableArray *)arrObjects {
    
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	Deal *objDeal = [arrObjects objectAtIndex:0];
	NSURL *url = [[NSURL alloc] initWithString:objDeal.image_url];
	UIImage *image = [[UIImage alloc] initWithData:[[NSData alloc] initWithContentsOfURL:url]]; 
	objDeal.imgDeal = image;
	
	[self performSelectorOnMainThread:@selector(loadImageComplete:) withObject:arrObjects waitUntilDone:YES];
	
	[pool drain];
}

- (void)loadImageComplete:(NSMutableArray *)arrObjects{
	
	Deal *objDeal = [arrObjects objectAtIndex:0];
	DealCellView *objCell = [arrObjects objectAtIndex:1];
    //	UIImage *img = [appDelegate imageByScalingProportionallyToSize:CGSizeMake(100, 96) srcImg:objDeal.imgDeal];
	objCell.imgDealImage.image = objDeal.imgDeal;
	[objCell.activityIndicator stopAnimating];
}


/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */


/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 */


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */


/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	/*Deal *objDeal;
     if (self.selIndex == 0) {
     objDeal = [[[appDelegate.arrMutableDealsByLocationsSubCategories objectAtIndex:indexPath.section] objectForKey:@"value"] objectAtIndex:indexPath.row];
     } else {
     objDeal = [[[appDelegate.arrMutableDealsByLocationsSubCategories objectAtIndex:selIndex-1] objectForKey:@"value"] objectAtIndex:indexPath.row];
     }*/
	self.navigationItem.title = @"בחזרה";
	
	appDelegate.objDealDetailViewController = [[DealDetailViewController alloc] initWithNibName:@"DealDetailViewController" bundle:nil];
	appDelegate.objDealDetailViewController.objSelectedDeal =  [dealArray objectAtIndex:indexPath.row];
	[self.navigationController pushViewController:appDelegate.objDealDetailViewController animated:YES];
	[appDelegate.objDealDetailViewController release];
	
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    NSLog(@"Dealloc called");
    [super dealloc];
    
}
- (void)hudWasHidden {
    // Remove HUD from screen when the HUD was hidded
    [HUD removeFromSuperview];
    started=NO;
    [HUD release];
}
#pragma UIScrollView delegate
- (void)scrollViewDidScroll:(UIScrollView *)aScrollView {
    CGPoint offset = aScrollView.contentOffset;
    CGRect bounds = aScrollView.bounds;
    CGSize size = aScrollView.contentSize;
    UIEdgeInsets inset = aScrollView.contentInset;
    float y = offset.y + bounds.size.height - inset.bottom;
    float h = size.height;
    // NSLog(@"offset: %f", offset.y);   
    // NSLog(@"content.height: %f", size.height);   
    // NSLog(@"bounds.height: %f", bounds.size.height);   
    // NSLog(@"inset.top: %f", inset.top);   
    // NSLog(@"inset.bottom: %f", inset.bottom);   
    // NSLog(@"pos: %f of %f", y, h);
    
    //float reload_distance = 10;
    if(y == h ) {
    if(!started){
        
        page++;
        started=YES;
        [self showDeals:page];
        [self.tblView reloadData];
        //  [self.tblView scrollsToTop];
        //  [self.tblView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
          }
    }
}


@end
