//
//  CategoriesViewController.h
//  DailyD
//
//  Created by Vimal Shah on 2/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface CategoriesViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {

	DailyDAppDelegate *appDelegate;

	IBOutlet UITableView *tblView;
	NSMutableArray *arrayValues;
}

@property (nonatomic, retain)IBOutlet UITableView *tblView;

@end
