//
//  CategoriesViewController.m
//  DailyD
//
//  Created by Vimal Shah on 2/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CategoriesViewController.h"


@implementation CategoriesViewController

@synthesize tblView;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	appDelegate = (DailyDAppDelegate *)[[UIApplication sharedApplication] delegate];
	self.navigationItem.title = @"קטגוריות";

	self.view.backgroundColor = appDelegate.clrTableViewBack;
	self.tblView.backgroundColor = [UIColor lightGrayColor];

//	arrayValues = [[NSMutableArray alloc] initWithObjects:@"0",@"0",@"0",@"0",nil];
	
}

//- (void)viewWillDisappear:(BOOL)animated {
//	
//	NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
//	[prefs setValue:appDelegate.arrPreferredCategories forKey:@"arrPreferredCategories"];
//	[prefs synchronize];
//	
//}

#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [appDelegate.arrMutableCategories count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	//    if (cell == nil) {
	cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	//    }
//	cell = [[[ClearLabelsCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
//	cell.backgroundView = [[[GradientView alloc] init] autorelease];

	// Configure the cell.
	Category *objCategory = [appDelegate.arrMutableCategories objectAtIndex:indexPath.row];
	
	cell.textLabel.text = objCategory.name;
	
	if (objCategory.preferred == 1) {
		[cell setAccessoryType:UITableViewCellAccessoryCheckmark];
	}
	
    return cell;
}


/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */


/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 */


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */


/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	NSUInteger row = [indexPath row];
	
	[self.tblView deselectRowAtIndexPath:indexPath animated:YES];
	
	Category *objCategory = [appDelegate.arrMutableCategories objectAtIndex:indexPath.row];

	if ([[self.tblView cellForRowAtIndexPath:indexPath ] accessoryType] == UITableViewCellAccessoryCheckmark)
	{
		[[self.tblView cellForRowAtIndexPath:indexPath] setAccessoryType:UITableViewCellAccessoryNone];
		[appDelegate checkCategory:objCategory c:0];
		Category *aCat = [appDelegate.arrMutableCategories objectAtIndex:row];
		[aCat setPreferred:0];
	}
	else
	{
		[[self.tblView cellForRowAtIndexPath:indexPath] setAccessoryType:UITableViewCellAccessoryCheckmark];
		[appDelegate checkCategory:objCategory c:1];
		Category *aCat = [appDelegate.arrMutableCategories objectAtIndex:row];
		[aCat setPreferred:1];
	}
	
//	NSLog(@"%@",arrayValues);
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
