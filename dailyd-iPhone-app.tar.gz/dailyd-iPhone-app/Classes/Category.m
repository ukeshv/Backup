//
//  Category.m
//  DailyD
//
//  Created by Vimal Shah on 2/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Category.h"


@implementation Category

@synthesize id;
@synthesize name;
@synthesize preferred;

- (void) dealloc {
	
	[name release];
	[super dealloc];
}

@end
