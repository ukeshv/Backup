//
//  Deal.h
//  DailyD
//
//  Created by Vimal Shah on 2/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface Deal : NSObject {

	NSString *title;
	int price;
	NSString *address;
	NSString *ends_at;
	NSDate *dt_ends_at;
	NSString *image_url;
	UIImage *imgDeal;
	int value;
	int save;
	int yousaved;
	NSArray *locations;
	NSString *description;
	NSArray *categories;
	NSString *deal_url;
	NSString *source;
	NSArray *lat;
    NSArray *lon;
}

@property (nonatomic, retain) NSString *title;
@property int price;
@property (nonatomic, retain) NSString *address;
@property (nonatomic, retain) NSString *ends_at;
@property (nonatomic, retain) NSDate *dt_ends_at;
@property (nonatomic, retain) NSString *image_url;
@property (nonatomic, retain) UIImage *imgDeal;
@property int value;
@property int save;
@property int yousaved;
@property (nonatomic, retain) NSArray *locations;
@property (nonatomic, retain) NSString *description;
@property (nonatomic, retain) NSArray *categories;
@property (nonatomic, retain) NSString *deal_url;
@property (nonatomic, retain) NSString *source;
@property (nonatomic, retain) NSArray *lat;
@property (nonatomic, retain) NSArray *lon;

@end
