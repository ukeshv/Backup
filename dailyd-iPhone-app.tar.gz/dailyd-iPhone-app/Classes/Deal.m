//
//  Deal.m
//  DailyD
//
//  Created by Vimal Shah on 2/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Deal.h"


@implementation Deal

@synthesize title;
@synthesize price;
@synthesize address;
@synthesize ends_at;
@synthesize dt_ends_at;
@synthesize image_url;
@synthesize imgDeal;
@synthesize value;
@synthesize save;
@synthesize yousaved;
@synthesize locations;
@synthesize description;
@synthesize categories;
@synthesize deal_url;
@synthesize source;
@synthesize lat;
@synthesize lon;

- (void) dealloc {
	
	[title release];
	[address release];
	[ends_at release];
	[dt_ends_at release];
	[image_url release];
	[imgDeal release];
	[locations release];
	[description release];
	[categories release];
	[deal_url release];
	[source release];
    [lat release];
    [lon release];
	[super dealloc];
}

@end
