//
//  DealCellView.h
//  DailyD
//
//  Created by Vimal Shah on 2/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DealCellView : UIViewController {

	IBOutlet UILabel *lblTitle;
	IBOutlet UIImageView *imgDealImage;
	IBOutlet UILabel *lblSite;
	IBOutlet UIActivityIndicatorView *activityIndicator;
	IBOutlet UILabel *lblPrice;
	IBOutlet UILabel *lblDiscount;
	IBOutlet UILabel *lblDistance;
}

@property (nonatomic, retain)IBOutlet UILabel *lblTitle;
@property (nonatomic, retain)IBOutlet UIImageView *imgDealImage;
@property (nonatomic, retain)IBOutlet UILabel *lblSite;
@property (nonatomic, retain)IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, retain)IBOutlet UILabel *lblPrice;
@property (nonatomic, retain)IBOutlet UILabel *lblDiscount;
@property (nonatomic, retain)IBOutlet UILabel *lblDistance;
@end
