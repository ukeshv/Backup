//
//  DealDetailViewController.h
//  DailyD
//
//  Created by Vimal Shah on 2/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface DealDetailViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {

	DailyDAppDelegate *appDelegate;

	Deal *objSelectedDeal;
	
	IBOutlet UIButton *btnSource;
	
	IBOutlet UITableView *tblView;
	IBOutlet UILabel *lblEnding;
	
	NSTimeInterval secondsBetween;
	int intsecondsBetween;
	
	NSTimer *tmEnding;
	
	UIAlertView *alertJoin;
}

@property (nonatomic, retain) Deal *objSelectedDeal;

@property (nonatomic, retain)IBOutlet UITableView *tblView;
@property (nonatomic, retain)IBOutlet UILabel *lblEnding;

- (IBAction)btnSource_clicked;

@end
