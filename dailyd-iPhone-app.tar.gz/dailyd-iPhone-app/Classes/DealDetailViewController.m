//
//  DealDetailViewController.m
//  DailyD
//
//  Created by Vimal Shah on 2/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DealDetailViewController.h"

#define FONT_SIZE 14.0f
#define CELL_CONTENT_WIDTH 300.0f
#define CELL_CONTENT_MARGIN 10.0f

@implementation DealDetailViewController

@synthesize objSelectedDeal;
@synthesize tblView,lblEnding;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	appDelegate = (DailyDAppDelegate *)[[UIApplication sharedApplication] delegate];
	self.navigationItem.title = [[self.objSelectedDeal.locations objectAtIndex:0] name];

	//	self.navigationItem.title = [NSString stringWithFormat:@"%@,%@",[[self.objSelectedDeal.locations objectAtIndex:0] name],[[self.objSelectedDeal.categories objectAtIndex:0] name]];
	[btnSource setTitle:self.objSelectedDeal.source forState:UIControlStateNormal];

	self.view.backgroundColor = appDelegate.clrTableViewBack;
	self.tblView.backgroundColor = [UIColor lightGrayColor];
//	self.tblView.separatorColor = [UIColor grayColor];

	UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, 67.0, 27.0)];
	[imgView setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]]];
	UIBarButtonItem *btnRight = [[UIBarButtonItem alloc] initWithCustomView:imgView];
	self.navigationItem.rightBarButtonItem = btnRight;
	[imgView release];
	
	secondsBetween = [self.objSelectedDeal.dt_ends_at timeIntervalSinceDate:[NSDate date]];
//	NSLog(@"secondsBetween %.0f",secondsBetween);
	
	intsecondsBetween = secondsBetween;
	
	lblEnding.text = [NSString stringWithFormat:@"%d:%d:%d",(intsecondsBetween/3600),((intsecondsBetween/60)%60),(intsecondsBetween%60)];
	tmEnding = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateLabel) userInfo:nil repeats:YES];
	[self performSelectorOnMainThread:@selector(updateLabel) withObject:nil waitUntilDone:YES];
	[[NSRunLoop currentRunLoop] addTimer:tmEnding forMode:UITrackingRunLoopMode];

}

- (void) updateLabel {
	if (intsecondsBetween > 0)
		intsecondsBetween--;
	lblEnding.text = [NSString stringWithFormat:@"%d:%d:%d",(intsecondsBetween/3600),((intsecondsBetween/60)%60),(intsecondsBetween%60)];
}
- (IBAction)btnSource_clicked {
	
//	alertJoin = [[UIAlertView alloc] initWithTitle:appDelegate.setAppAlertTitle message:@"את/ה מופנה לאתר להשתתפות בעסקה, פעולה זו תעביר אותך אל דפדפן האינטרנט" delegate:self cancelButtonTitle:@"בטל" otherButtonTitles:@"המשך", nil];
//	[alertJoin show];
//	[alertJoin release];
	
	BrowserViewController *objbroView = [[BrowserViewController alloc] init];
	objbroView.strUrl = self.objSelectedDeal.deal_url;
	objbroView.strSource = self.objSelectedDeal.source;
	[self.navigationController pushViewController:objbroView animated:YES];
	[objbroView release];
	
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	
	if (alertView == alertJoin) {
		if (buttonIndex == 0) {
		} else {
		//	NSURL *url = [NSURL URLWithString:self.objSelectedDeal.deal_url];
			
		//	[[UIApplication sharedApplication] openURL:url];
		}
	}
}


#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	switch (section) {
		case 0:
			return 2;
			break;
		case 1:
			return 1;
			break;
		case 2:
			return 1;
			break;
		default:
			return 0;
			break;
	}
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	switch (indexPath.section) {
		case 0:
		{
			switch (indexPath.row) {
				case 0:
				{
					return 250;
					break;
				}
				case 1:
				{
					return 70; 
					break;
				}
				default:
					return 0; 
					break;
			}
		}
        case 1:
        {
            return 40; 
            break;
        }
		case 2:
		{	
			switch (indexPath.row) {
				case 0:
				{
					NSString *text = self.objSelectedDeal.description;
					
					CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
					
					CGSize size = [text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
					
					CGFloat height = MAX(size.height, 44.0f);
					
					return height + (CELL_CONTENT_MARGIN * 2);
					break;
				}
				default:
					return 0; 
					break;
			}
		}
		default:
			return 0; 
			break;
	}
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	//    if (cell == nil) {
	cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	//    }
//	cell = [[[ClearLabelsCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
//	cell.backgroundView = [[[GradientView alloc] init] autorelease];

	// Configure the cell.
	switch (indexPath.section) {
		case 0:
		{	
            cell.selectionStyle = UITableViewCellSelectionStyleNone;

			switch (indexPath.row) {
				case 0:
				{
					
					UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 280, 80)];
					lblTitle.numberOfLines = 3;
					lblTitle.textAlignment = UITextAlignmentRight;
					lblTitle.textColor = [UIColor blackColor];
					lblTitle.backgroundColor = [UIColor clearColor];
					lblTitle.font = [UIFont systemFontOfSize:17.0];
					lblTitle.text = self.objSelectedDeal.title;
					[cell.contentView addSubview:lblTitle];
					
					UILabel *lblSource = [[UILabel alloc] initWithFrame:CGRectMake(10, 85, 280, 20)];
					lblSource.textAlignment = UITextAlignmentRight;
					lblSource.textColor = appDelegate.clrSourceText;
					lblSource.backgroundColor = [UIColor clearColor];
					lblSource.font = [UIFont systemFontOfSize:16.0];
					lblSource.text = self.objSelectedDeal.source;
					[cell.contentView addSubview:lblSource];
					
					UIImageView *imgViewDealContainer = [[UIImageView alloc] initWithFrame:CGRectMake(20, 110, 268, 131)];
					[imgViewDealContainer setImage:[UIImage imageNamed:@"picBgBig.png"]];
					[cell.contentView addSubview:imgViewDealContainer];
					
					
					UILabel *lblNW = [[UILabel alloc] initWithFrame:CGRectMake(20, 175, 95, 20)];
					lblNW.textAlignment = UITextAlignmentCenter;
					lblNW.textColor = [UIColor blackColor];
					lblNW.backgroundColor = [UIColor clearColor];
					lblNW.font = [UIFont boldSystemFontOfSize:15.0];
					lblNW.text = @"שח";
					[cell.contentView addSubview:lblNW];
					UILabel *lblPrice = [[UILabel alloc] initWithFrame:CGRectMake(20, 148, 95, 36)];
					lblPrice.textAlignment = UITextAlignmentCenter;
					lblPrice.adjustsFontSizeToFitWidth = YES;
					lblPrice.textColor = [UIColor blackColor];
					lblPrice.backgroundColor = [UIColor clearColor];
					lblPrice.font = [UIFont boldSystemFontOfSize:30.0];
					lblPrice.text = [NSString stringWithFormat:@"%d",self.objSelectedDeal.price];
					[cell.contentView addSubview:lblPrice];
					
//					UIImage *imgDeal = [appDelegate imageByScalingProportionallyToSize:CGSizeMake(170, 128) srcImg:self.objSelectedDeal.imgDeal];           
                    
                    
					UIImageView *imgViewDeal = [[UIImageView alloc] initWithFrame:CGRectMake(116, 112, 170, 128)];
					[imgViewDeal setContentMode:UIViewContentModeScaleToFill];
					[imgViewDeal setImage:self.objSelectedDeal.imgDeal];
                    
                    if (objSelectedDeal.imgDeal != nil) {
                        //		UIImage *img = [appDelegate imageByScalingProportionallyToSize:CGSizeMake(100, 96) srcImg:objDeal.imgDeal];
                       imgViewDeal.image = objSelectedDeal.imgDeal;
                    } else {
                        imgViewDeal.image = [UIImage imageNamed:@"100X80_thumb.png"];
                        if (![objSelectedDeal.image_url isEqualToString:@""]) {
                            NSMutableArray *arrObjects = [[NSMutableArray alloc] init];
                            UIActivityIndicatorView *act=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                            act.frame=CGRectMake(0, 0, 50, 50);
                            act.hidesWhenStopped=YES;
                            act.center=imgViewDeal.center;
                            [cell addSubview:act];
                            [act startAnimating];
                            [arrObjects addObject:objSelectedDeal];
                            [arrObjects addObject:imgViewDeal];
                            [arrObjects addObject:act];
                            [NSThread detachNewThreadSelector:@selector(loadImage:) toTarget:self withObject:arrObjects];
                        }
                    }
					[cell.contentView addSubview:imgViewDeal];
					break;
				}
				case 1:
				{
					UILabel *lblSave = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, 60, 25)];
					lblSave.textAlignment = UITextAlignmentCenter;
					lblSave.textColor = [UIColor darkGrayColor];
					lblSave.backgroundColor = [UIColor clearColor];
					lblSave.font = [UIFont systemFontOfSize:17.0];
					lblSave.text = @"חסכת";
					[cell.contentView addSubview:lblSave];
					UILabel *lblDiscount = [[UILabel alloc] initWithFrame:CGRectMake(60, 5, 60, 25)];
					lblDiscount.textAlignment = UITextAlignmentCenter;
					lblDiscount.textColor = [UIColor darkGrayColor];
					lblDiscount.backgroundColor = [UIColor clearColor];
					lblDiscount.font = [UIFont systemFontOfSize:17.0];
					lblDiscount.text = @"הנחה";
					[cell.contentView addSubview:lblDiscount];
					UILabel *lblValue = [[UILabel alloc] initWithFrame:CGRectMake(120, 5, 60, 25)];
					lblValue.textAlignment = UITextAlignmentCenter;
					lblValue.textColor = [UIColor darkGrayColor];
					lblValue.backgroundColor = [UIColor clearColor];
					lblValue.font = [UIFont systemFontOfSize:17.0];
					lblValue.text = @"ערך";
					[cell.contentView addSubview:lblValue];
					
					UILabel *lblSave1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 22, 60, 40)];
					lblSave1.textAlignment = UITextAlignmentCenter;
					lblSave1.adjustsFontSizeToFitWidth = YES;
					lblSave1.textColor = [UIColor blackColor];
					lblSave1.backgroundColor = [UIColor clearColor];
					lblSave1.font = [UIFont boldSystemFontOfSize:20.0];
					self.objSelectedDeal.yousaved = self.objSelectedDeal.value - self.objSelectedDeal.price;
					lblSave1.text = [NSString stringWithFormat:@"%d",self.objSelectedDeal.yousaved];
					[cell.contentView addSubview:lblSave1];
					UILabel *lblNW1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 46, 60, 20)];
					lblNW1.textAlignment = UITextAlignmentCenter;
					lblNW1.textColor = [UIColor blackColor];
					lblNW1.backgroundColor = [UIColor clearColor];
					lblNW1.font = [UIFont boldSystemFontOfSize:14.0];
					lblNW1.text = @"שח";
					[cell.contentView addSubview:lblNW1];
					UILabel *lblDiscount1 = [[UILabel alloc] initWithFrame:CGRectMake(60, 22, 60, 40)];
					lblDiscount1.textAlignment = UITextAlignmentCenter;
					lblDiscount1.adjustsFontSizeToFitWidth = YES;
					lblDiscount1.textColor = [UIColor blackColor];
					lblDiscount1.backgroundColor = [UIColor clearColor];
					lblDiscount1.font = [UIFont boldSystemFontOfSize:20.0];
					lblDiscount1.text = [NSString stringWithFormat:@"%d%%",self.objSelectedDeal.save];
					//			lblDiscount1.text = [NSString stringWithFormat:@"%d%%",((self.objSelectedDeal.save*100)/self.objSelectedDeal.value)];
					[cell.contentView addSubview:lblDiscount1];
					UILabel *lblValue1 = [[UILabel alloc] initWithFrame:CGRectMake(120, 22, 60, 40)];
					lblValue1.textAlignment = UITextAlignmentCenter;
					lblValue1.adjustsFontSizeToFitWidth = YES;
					lblValue1.textColor = [UIColor blackColor];
					lblValue1.backgroundColor = [UIColor clearColor];
					lblValue1.font = [UIFont boldSystemFontOfSize:20.0];
					lblValue1.text = [NSString stringWithFormat:@"%d",self.objSelectedDeal.value];
					[cell.contentView addSubview:lblValue1];
					UILabel *lblNW2 = [[UILabel alloc] initWithFrame:CGRectMake(120, 46, 60, 20)];
					lblNW2.textAlignment = UITextAlignmentCenter;
					lblNW2.textColor = [UIColor blackColor];
					lblNW2.backgroundColor = [UIColor clearColor];
					lblNW2.font = [UIFont boldSystemFontOfSize:15.0];
					lblNW2.text = @"שח";
					[cell.contentView addSubview:lblNW2];
					
					UILabel *lblAddress = [[UILabel alloc] initWithFrame:CGRectMake(180, 5, 110, 60)];
					lblAddress.numberOfLines = 3;
					lblAddress.textAlignment = UITextAlignmentRight;
					lblAddress.textColor = [UIColor blackColor];
					lblAddress.backgroundColor = [UIColor clearColor];
					lblAddress.font = [UIFont systemFontOfSize:15.0];
					lblAddress.text = self.objSelectedDeal.address;
					[cell.contentView addSubview:lblAddress];
					
					cell.backgroundColor = appDelegate.clrCell;
					
					break;
				}
				default:
					break;
			}
			break;
		}
        case 1:
		{
            cell.selectionStyle = UITableViewCellSelectionStyleGray;

            cell.textLabel.text = @"הצג על מפה";
            cell.textLabel.textAlignment = UITextAlignmentCenter;
			break;
        }
		case 2:
		{
            cell.selectionStyle = UITableViewCellSelectionStyleNone;

			switch (indexPath.row) {
				case 0:
				{
					UILabel *label = nil;
					label = [[UILabel alloc] initWithFrame:CGRectZero];
					[label setTextAlignment:UITextAlignmentRight];
					[label setLineBreakMode:UILineBreakModeWordWrap];
					[label setMinimumFontSize:FONT_SIZE];
					[label setNumberOfLines:0];
					[label setFont:[UIFont systemFontOfSize:FONT_SIZE]];
					[label setTag:1];
					label.textColor = [UIColor blackColor];
					[cell.contentView addSubview:label];
					
					NSString *text = self.objSelectedDeal.description;
					
					label.text = text;
					
					CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
					CGSize size = [text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
					
					if (!label)
						label = (UILabel*)[cell viewWithTag:1];
					
					[label setText:text];
					[label setFrame:CGRectMake(CELL_CONTENT_MARGIN, CELL_CONTENT_MARGIN, CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), MAX(size.height, 44.0f))];
					break;
				}
				default:
					break;
			}
			break;
		}
		default:
			break;
	}
	
    return cell;
}


- (void)loadImage :(NSMutableArray *)arrObjects {
    
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	Deal *objDeal = [arrObjects objectAtIndex:0];
	NSURL *url = [[NSURL alloc] initWithString:objDeal.image_url];
	UIImage *image = [[UIImage alloc] initWithData:[[NSData alloc] initWithContentsOfURL:url]]; 
	objDeal.imgDeal = image;
	
	[self performSelectorOnMainThread:@selector(loadImageComplete:) withObject:arrObjects waitUntilDone:YES];
	
	[pool drain];
}

- (void)loadImageComplete:(NSMutableArray *)arrObjects{
	
	Deal *objDeal = [arrObjects objectAtIndex:0];
	UIImageView *imgView = [arrObjects objectAtIndex:1];
    //	UIImage *img = [appDelegate imageByScalingProportionallyToSize:CGSizeMake(100, 96) srcImg:objDeal.imgDeal];
	imgView.image = objDeal.imgDeal;
    UIActivityIndicatorView *act=[arrObjects objectAtIndex:2];
	[act stopAnimating];
}

#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
    if (indexPath.section == 1) {
        appDelegate.objDealMapViewController = [[DealMapViewController alloc] initWithNibName:@"DealMapViewController" bundle:nil];
        [self.navigationController pushViewController:appDelegate.objDealMapViewController animated:YES];
        [appDelegate.objDealMapViewController release];
	}
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
    [lblEnding release];
}


@end
