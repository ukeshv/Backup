//
//  DealMapViewController.h
//  DailyD
//
//  Created by Vimal Shah on 4/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"

@interface AddressAnnotation : NSObject<MKAnnotation> {
	
	CLLocationCoordinate2D coordinate;
    int index;
    NSString *title;
    NSString *subtitle;
	MKPinAnnotationColor pinColor;
	
    NSString *imageFileName;
    
}

@property int index;
@property (nonatomic,retain) NSString *title;
@property (nonatomic,retain) NSString *subtitle;
@property (nonatomic, assign) MKPinAnnotationColor pinColor;
@property (nonatomic,retain) NSString *imageFileName;

@end

@interface DealMapViewController : UIViewController <MKMapViewDelegate> {
    
    DailyDAppDelegate *appDelegate;
    
    
    IBOutlet MKMapView *mView;
	AddressAnnotation *addAnnotation;

}


@end
