//
//  DealMapViewController.m
//  DailyD
//
//  Created by Vimal Shah on 4/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DealMapViewController.h"

@implementation AddressAnnotation

@synthesize coordinate;
@synthesize index;
@synthesize title;
@synthesize subtitle;
@synthesize pinColor;
@synthesize imageFileName;


- (NSString *)subtitle{
	return subtitle;
}

- (NSString *)title{
	return title;
}

-(id)initWithCoordinate:(CLLocationCoordinate2D) c{
	coordinate=c;
    //	NSLog(@"%f,%f",c.latitude,c.longitude);
	return self;
}
@end


@implementation DealMapViewController


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.\
    
    appDelegate = (DailyDAppDelegate *)[[UIApplication sharedApplication] delegate];

    self.navigationItem.title = @"מפה";
////    [self setMapView:[[[RMMapView alloc] initWithFrame:CGRectMake(0.0, 0.0, 320, 320)] autorelease]];
//	[self setMapView:[[[RMMapView alloc]initWithFrame:CGRectMake(0.0, 0.0, 320, 320)
//										  andApiToken:@"db3c216b-6ec2-43e8-b652-151ad524ea93"]autorelease]];
//    
//    [mapView setBackgroundColor:[UIColor lightGrayColor]];
//    self.view = mapView;
    
//    MKCoordinateRegion region;
//	MKCoordinateSpan span;
//	span.latitudeDelta=0.007;
//	span.longitudeDelta=0.007;
//    CLLocationCoordinate2D userlocation;
//    userlocation.latitude = [appDelegate.lat doubleValue];
//    userlocation.longitude = [appDelegate.lon doubleValue];
//    region.span=span;
//    region.center=userlocation;
//    [mView setRegion:region animated:TRUE];

}

//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
//{
//    // Return YES for supported orientations
//    return (interfaceOrientation == UIInterfaceOrientationPortrait);
//}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


@end
