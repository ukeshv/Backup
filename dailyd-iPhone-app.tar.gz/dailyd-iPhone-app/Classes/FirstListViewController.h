//
//  FirstListViewController.h
//  DailyD
//
//  Created by Vimal Shah on 2/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface FirstListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, MBProgressHUDDelegate> {

	DailyDAppDelegate *appDelegate;
	
	IBOutlet UITableView *tblView;
	MBProgressHUD *HUD;
	int cate_count;

}

@property (nonatomic, retain)IBOutlet UITableView *tblView;

- (void)showDeals;
- (void)calculateTotalCount;


@end
