//
//  FirstListViewController.m
//  DailyD
//
//  Created by Vimal Shah on 2/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FirstListViewController.h"
#import "WebService.h"
@implementation FirstListViewController

@synthesize tblView;

int test=1;
WebService *service;
BOOL started;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    NSLog(@"service started");
    [super viewDidLoad];
	
	appDelegate = (DailyDAppDelegate *)[[UIApplication sharedApplication] delegate];
	self.navigationController.navigationBar.tintColor = appDelegate.clrNavBar;
	self.tblView.backgroundColor = [UIColor lightGrayColor];
	
	UIButton* infoButton = [UIButton buttonWithType:UIButtonTypeInfoLight];
	[infoButton addTarget:self action:@selector(infoButtonAction) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *modalButton = [[UIBarButtonItem alloc] initWithCustomView:infoButton];
	[self.navigationItem setLeftBarButtonItem:modalButton animated:YES];
	[modalButton release];
	
	UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, 67.0, 27.0)];
	[imgView setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]]];
	UIBarButtonItem *btnRight = [[UIBarButtonItem alloc] initWithCustomView:imgView];
	self.navigationItem.rightBarButtonItem = btnRight;
	[imgView release];
	
	
	cate_count =0;
	
}


-(void)calculateTotalCount
{
	for(int i=0; i<[appDelegate.arrCatDeals count]-1; i++)
	{
	    cate_count += [[[appDelegate.arrCatDeals objectAtIndex:i] objectForKey:@"deals_count"] intValue];
	}
	NSLog(@"Total Category count ==>%d",cate_count);
						
}


- (void)viewWillAppear:(BOOL)animated {
	
	self.navigationItem.title = @"קטגוריות";
	[self.tblView deselectRowAtIndexPath:[self.tblView indexPathForSelectedRow] animated:YES];

    service=[[WebService alloc] init];
    
	if (appDelegate.isFromSettings1) {
		appDelegate.isFromSettings1 = FALSE;
		[self showDeals];
	} else if ([appDelegate.arrCatDeals count] != 0) {
		[appDelegate arrDealsFromObjDictByCategories:appDelegate.arrCatDeals];
		[self.tblView reloadData];
	} else {
		[self showDeals];
	}
	
	
}

- (void)viewWillDisappear:(BOOL)animated {
	
}

- (IBAction) infoButtonAction {
	
	self.navigationItem.title = @"בחזרה";
	
	appDelegate.isFromSettings1 = TRUE;

	appDelegate.objSettingsViewController = [[SettingsViewController alloc] initWithNibName:@"SettingsViewController" bundle:nil];
	[self.navigationController pushViewController:appDelegate.objSettingsViewController animated:YES];
	[appDelegate.objSettingsViewController release];
}

- (void)showDeals {
	// The hud will dispable all input on the view (use the higest view possible in the view hierarchy)
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	
    // Add HUD to screen
    [self.navigationController.view addSubview:HUD];
	
    // Regisete for HUD callbacks so we can remove it from the window at the right time
    HUD.delegate = self;
	
    HUD.labelText = @"Loading";
	HUD.detailsLabelText = @"dailyD!";
    // Show the HUD while the provided method executes in a new thread
    [HUD showWhileExecuting:@selector(loadingStart) onTarget:self withObject:nil animated:YES];
}

- (void)loadingStart {
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	NSLog(@"loainf sada");
	NSString *jsonString = [service apiCategories:appDelegate.setAPIUrl];//[appDelegate apiDeals:[pagenumber intValue]];
	
	NSError *error;
	SBJSON *json = [[SBJSON new] autorelease];
	appDelegate.arrCatDeals = [json objectWithString:jsonString error:&error];
    
	//NSLog(@"AppDelegate arrdeals  :%@",appDelegate.arrDeals);
	[appDelegate arrDealsFromObjDictByCategories:appDelegate.arrCatDeals];
	
	[self performSelectorOnMainThread:@selector(loadingComplete) withObject:nil waitUntilDone:YES];
	
	[pool release];
}

-(void) loadingComplete {
	NSLog(@" sdaf %d",[appDelegate.arrCatDeals count]);
	[self calculateTotalCount];
	[self.tblView reloadData];
}

#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	/*if ([appDelegate.arrDeals count] == 0)
		return 0;
	else*/
		return [appDelegate.arrCatDeals count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 59.0;
}
// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	//    if (cell == nil) {
	//	cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	//    }
	cell = [[[ClearLabelsCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	cell.backgroundView = [[[GradientView alloc] init] autorelease];

	UIImageView *img = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DaliyD2.png"]];
	cell.backgroundView = img;


	// Configure the cell.
	
	if (indexPath.row == 0) 
	{ 
	// cell.textLabel.text = [NSString stringWithFormat:@"(%d) הצג הכל",[appDelegate.arrDeals count]];
		
		UILabel *lblSave1 = [[UILabel alloc] initWithFrame:CGRectMake(39, 10, 36, 26)];
		lblSave1.textAlignment = UITextAlignmentCenter;
		lblSave1.textColor = [UIColor colorWithRed:0.39 green:0.91 blue:0.38 alpha:1];
		lblSave1.backgroundColor = [UIColor clearColor];
		lblSave1.font = [UIFont boldSystemFontOfSize:18.0];
		lblSave1.text = [NSString stringWithFormat:@"%d",cate_count];
		[cell.contentView addSubview:lblSave1];
		
		UILabel *lblSave = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 230, 54)];
		lblSave.textAlignment = UITextAlignmentRight;
		lblSave.textColor = [UIColor blackColor];
		lblSave.backgroundColor = [UIColor clearColor];
		lblSave.font = [UIFont boldSystemFontOfSize:21.0];
		lblSave.text = @"כל הקטגוריות";
		[cell.contentView addSubview:lblSave];
	} else {
		UILabel *lblSave1 = [[UILabel alloc] initWithFrame:CGRectMake(39, 10, 36, 26)];
		lblSave1.textAlignment = UITextAlignmentCenter;
		lblSave1.textColor = [UIColor colorWithRed:0.39 green:0.91 blue:0.38 alpha:1];
		lblSave1.backgroundColor = [UIColor clearColor];
		lblSave1.font = [UIFont boldSystemFontOfSize:18.0];
	lblSave1.text = [NSString stringWithFormat:@"%d",[[[appDelegate.arrCatDeals objectAtIndex:indexPath.row-1] objectForKey:@"deals_count"] intValue]];
		[cell.contentView addSubview:lblSave1];
		
		UILabel *lblSave = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 230, 54)];
		lblSave.textAlignment = UITextAlignmentRight;
		lblSave.textColor = [UIColor blackColor];
		lblSave.backgroundColor = [UIColor clearColor];
		lblSave.font = [UIFont boldSystemFontOfSize:21.0];
		lblSave.text = [NSString stringWithFormat:@"%@",[[appDelegate.arrCatDeals objectAtIndex:indexPath.row-1] valueForKey:@"name"]];
		[cell.contentView addSubview:lblSave];
        
		
		
		NSMutableArray *myArray =[[NSMutableArray alloc]init];
		[myArray addObject:@"test"];
		[myArray addObject:@"test1"];
	
		
		[NSArray arrayWithArray:(NSArray *)myArray];
		
//		cell.textLabel.text = [NSString stringWithFormat:@"(%d) %@",[[[appDelegate.arrMutableDealsByCategories objectAtIndex:indexPath.row-1] objectForKey:@"value"] count], [[appDelegate.arrMutableDealsByCategories objectAtIndex:indexPath.row-1] valueForKey:@"header"]];
	}
	
//	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
*/

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 */


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */


/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
//	appDelegate.objCatDealsViewController = [[CatDealsViewController alloc] initWithNibName:@"CatDealsViewController" bundle:nil];
//	appDelegate.objCatDealsViewController.selIndex = indexPath.row;
//	[self.navigationController pushViewController:appDelegate.objCatDealsViewController animated:YES];
//	[appDelegate.objCatDealsViewController release];

    appDelegate.objFirstSubListViewController = [[FirstSubListViewController alloc] initWithNibName:@"FirstSubListViewController" bundle:nil];

   if (indexPath.row == 0) {
        appDelegate.objFirstSubListViewController.selCategoryID = 0;
        appDelegate.objFirstSubListViewController.selCategoryName = @"הצג הכל";
       
       
//        NSString *jsonString = [service apiCategoriesLocation:appDelegate.setAPIUrl catId:0];
//        NSError *error;
//        SBJSON *json = [[SBJSON new] autorelease];
       
       // appDelegate.objFirstSubListViewController.arrLocsFromCats = [json objectWithString:jsonString error:&error];
      //  appDelegate.objFirstSubListViewController.arrLocsFromCats = appDelegate.arrMutableDealsByCategoriesAllSections;
    } else {
        
       // NSMutableArray *arrLocsFromCats = [[appDelegate.arrMutableDealsByCategories objectAtIndex:indexPath.row-1] objectForKey:@"value"];
        
		//Deal *objDeal = [[[appDelegate.arrMutableDealsByCategories objectAtIndex:indexPath.row-1] objectForKey:@"value"] objectAtIndex:0];        
       // Category *aCat = [appDelegate.arrDeals objectAtIndex:0];
        appDelegate.objFirstSubListViewController.selCategoryID  = [[[appDelegate.arrCatDeals objectAtIndex:indexPath.row] valueForKey:@"id"] intValue];
        appDelegate.objFirstSubListViewController.selCategoryName = [[appDelegate.arrCatDeals objectAtIndex:indexPath.row] valueForKey:@"name"];
		appDelegate.objFirstSubListViewController.selDealsCount  = [[[appDelegate.arrCatDeals objectAtIndex:indexPath.row] valueForKey:@"deals_count"] intValue];
		
	
	
	// appDelegate.objFirstSubListViewController.arrLocsFromCats = arrLocsFromCats;
    }
   	[self.navigationController pushViewController:appDelegate.objFirstSubListViewController animated:YES];
    [appDelegate.objFirstSubListViewController release];
}
/*
#pragma UIScrollView delegate
- (void)scrollViewDidScroll:(UIScrollView *)aScrollView {
    CGPoint offset = aScrollView.contentOffset;
    CGRect bounds = aScrollView.bounds;
    CGSize size = aScrollView.contentSize;
    UIEdgeInsets inset = aScrollView.contentInset;
    float y = offset.y + bounds.size.height - inset.bottom;
    float h = size.height;
    // NSLog(@"offset: %f", offset.y);   
    // NSLog(@"content.height: %f", size.height);   
    // NSLog(@"bounds.height: %f", bounds.size.height);   
    // NSLog(@"inset.top: %f", inset.top);   
    // NSLog(@"inset.bottom: %f", inset.bottom);   
    // NSLog(@"pos: %f of %f", y, h);
    
    //float reload_distance = 10;
    if(y == h ) {
               if(!started){
        
            test++;
        started=YES;
           [self showDeals:test];
                   [self.tblView reloadData];
                 //  [self.tblView scrollsToTop];
                 //  [self.tblView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
         }
    }
}
*/

#pragma mark -
#pragma mark MBProgressHUDDelegate methods

- (void)hudWasHidden {
    // Remove HUD from screen when the HUD was hidded
    [HUD removeFromSuperview];
    started=NO;
    [HUD release];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
