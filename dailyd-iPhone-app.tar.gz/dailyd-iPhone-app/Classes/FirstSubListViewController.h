//
//  FirstSubListViewController.h
//  DailyD
//
//  Created by Vimal Shah on 4/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface FirstSubListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, MBProgressHUDDelegate> {
 
    DailyDAppDelegate *appDelegate;
	
	IBOutlet UITableView *tblView;
	MBProgressHUD *HUD;

    int selCategoryID;
    NSMutableArray *arrLocsFromCats;
    NSString *selCategoryName;
	int selDealsCount;
    int locationCount;
}

@property (nonatomic, retain)IBOutlet UITableView *tblView;
@property int selCategoryID;
@property int selDealsCount;
@property (nonatomic, retain) NSMutableArray *arrLocsFromCats;
@property (nonatomic, retain) NSString *selCategoryName;

- (void)showDeals;
-(void)calculateLocationCount;


@end
