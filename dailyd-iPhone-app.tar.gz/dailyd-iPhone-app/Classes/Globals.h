//
//  Globals.h
//  DailyD
//
//  Created by Vimal Shah on 2/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <sqlite3.h>
#import <MapKit/MapKit.h>
#import <MessageUI/MessageUI.h>
#import "../JSON/JSON.h"
#import "Reachability.h"
#import "GradientView.h"
#import "ClearLabelsCellView.h"

@class DailyDAppDelegate;
@class Deal;
@class Category;
@class Location;

@class FirstListViewController;
@class SecondListViewController;
@class ThirdListViewController;

@class FirstSubListViewController;
@class SecondSubListViewController;

@class CatDealsViewController;
@class LocDealsViewController;
@class SiteDealsViewController;

@class DealDetailViewController;
@class DealMapViewController;
@class SettingsViewController;
@class CategoriesViewController;
@class LocationsViewController;
// @class LocCategoryViewController;

@class BrowserViewController;

#import "MBProgressHUD.h"
#import "FBConnect.h"

#import "DailyDAppDelegate.h"
#import "Deal.h"
#import "Category.h"
#import "Location.h"

#import "FirstListViewController.h"
#import "SecondListViewController.h"
#import "ThirdListViewController.h"

#import "FirstSubListViewController.h"
#import "SecondSubListViewController.h"

#import "CatDealsViewController.h"
#import "LocDealsViewController.h"
#import "SiteDealsViewController.h"

#import "DealDetailViewController.h"
#import "DealMapViewController.h"
#import "SettingsViewController.h"
#import "CategoriesViewController.h"
#import "LocationsViewController.h"
// #import "LocCategoryViewController.m"

#import "BrowserViewController.h"

