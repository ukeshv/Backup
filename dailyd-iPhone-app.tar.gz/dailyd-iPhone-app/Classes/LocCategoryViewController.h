//
//  LocCategoryViewController.h
//  DailyD
//
//  Created by mac pro on 25/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface LocCategoryViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, MBProgressHUDDelegate>
{
    IBOutlet UITableView *locationTableview;
	MBProgressHUD *HUD;
	int cate_count;
    
    DailyDAppDelegate *appDelegate;
    NSMutableArray *locationCatArray;
    
    
}

@property (nonatomic, retain) UITableView *locationTableview;

- (void)showDeals;

@end
