//
//  LocCategoryViewController.m
//  DailyD
//
//  Created by mac pro on 25/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LocCategoryViewController.h"
#import "WebService.h"


@implementation LocCategoryViewController
@synthesize locationTableview;

WebService *service;
BOOL started;



// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */


- (void)viewDidLoad
{
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    service=[[WebService alloc] init];
    appDelegate = (DailyDAppDelegate *)[[UIApplication sharedApplication] delegate];
    locationCatArray = [[NSMutableArray alloc]init];
    
	self.locationTableview.backgroundColor = [UIColor lightGrayColor];
    self.navigationItem.title = @"Location Category";
    
	UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, 67.0, 27.0)];
	[imgView setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]]];
	UIBarButtonItem *btnRight = [[UIBarButtonItem alloc] initWithCustomView:imgView];
	self.navigationItem.rightBarButtonItem = btnRight;
	[imgView release];
    
  //  locationCount =0;
    
    // [appDelegate arrLocsFromCategory:self.arrLocsFromCats];
    
    [self showDeals];
}

- (void)viewWillAppear:(BOOL)animated {
	[self.locationTableview deselectRowAtIndexPath:[self.locationTableview indexPathForSelectedRow] animated:YES];
}

- (void)showDeals {
	// The hud will dispable all input on the view (use the higest view possible in the view hierarchy)
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	
    // Add HUD to screen
    [self.navigationController.view addSubview:HUD];
	
    // Regisete for HUD callbacks so we can remove it from the window at the right time
    HUD.delegate = self;
	
    HUD.labelText = @"Loading";
	HUD.detailsLabelText = @"dailyD!";
    // Show the HUD while the provided method executes in a new thread
    [HUD showWhileExecuting:@selector(loadingStart) onTarget:self withObject:nil animated:YES];
}

- (void)loadingStart {
	
	//NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
    
    NSString *jsonString;
    jsonString = [service apiLocationCategories:@"http://www.dailyd.co.il/" locId:5];
    
	
	NSError *error;
	SBJSON *json = [[SBJSON new] autorelease];
	locationCatArray = [json objectWithString:jsonString error:&error];
	
	//[appDelegate arrDealsFromObjDictByCategoriesWithSubLocations:appDelegate.arrCatSubDeals];
	
	[self performSelectorOnMainThread:@selector(loadingComplete) withObject:nil waitUntilDone:YES];
	
	
}

-(void) loadingComplete {
	NSLog(@"arrCatsubDeals : %d",[locationCatArray count] );
   // [self calculateLocationCount];
    
	[self.locationTableview reloadData];
}

/*
-(void)calculateLocationCount
{
    locationCount =0;
    
	for(int i=0; i<[appDelegate.arrCatSubDeals count]; i++)
	{
        if(selCategoryID ==0)
        {
            locationCount += [[[appDelegate.arrCatSubDeals objectAtIndex:i] objectForKey:@"deals_count"] intValue];
            NSLog(@"Deals _count ==>%d",[[[appDelegate.arrCatSubDeals objectAtIndex:i] objectForKey:@"deals_count"] intValue]); 
        }
        
        else
        {
            locationCount += [[[appDelegate.arrCatSubDeals objectAtIndex:i] objectForKey:@"count"] intValue];
            NSLog(@"Category _count ==>%d",[[[appDelegate.arrCatSubDeals objectAtIndex:i] objectForKey:@"count"] intValue]); 
            
        }
	}
	NSLog(@"Total Category count ==>%d",locationCount);
    
}

*/
 
#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 59.0;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	/*if ([appDelegate.arrCatSubDeals count] == 0)
     return 0;
     else*/
    return [locationCatArray count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	//    if (cell == nil) {
    //	cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	//    }
	cell = [[[ClearLabelsCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	cell.backgroundView = [[[GradientView alloc] init] autorelease];
    
	UIImageView *img = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DaliyD2.png"]];
	cell.backgroundView = img;
	// Configure the cell.
    
        if (indexPath.row == 0) {
        //		cell.textLabel.text = [NSString stringWithFormat:@"(%d) הצג הכל",[appDelegate.arrDeals count]];
        UILabel *lblSave1 = [[UILabel alloc] initWithFrame:CGRectMake(39, 10, 36, 26)];
        lblSave1.textAlignment = UITextAlignmentCenter;
        lblSave1.textColor = [UIColor colorWithRed:0.39 green:0.91 blue:0.38 alpha:1];
        lblSave1.backgroundColor = [UIColor clearColor];
        lblSave1.font = [UIFont boldSystemFontOfSize:18.0];
        lblSave1.text = [NSString stringWithFormat:@"%d",50];
        [cell.contentView addSubview:lblSave1];
        
        UILabel *lblSave = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 230, 54)];
        lblSave.textAlignment = UITextAlignmentRight;
        lblSave.textColor = [UIColor blackColor];
        lblSave.backgroundColor = [UIColor clearColor];
        lblSave.font = [UIFont boldSystemFontOfSize:21.0];
        lblSave.text = @"הצג הכל";
        [cell.contentView addSubview:lblSave];
    } else {
        //		cell.textLabel.text = [NSString stringWithFormat:@"(%d) %@",[[[appDelegate.arrMutableDealsByLocations objectAtIndex:indexPath.row-1] objectForKey:@"value"] count], [[appDelegate.arrMutableDealsByLocations objectAtIndex:indexPath.row-1] valueForKey:@"header"]];
        
        UILabel *lblSave1 = [[UILabel alloc] initWithFrame:CGRectMake(39, 10, 36, 26)];
        lblSave1.textAlignment = UITextAlignmentCenter;
        lblSave1.textColor = [UIColor colorWithRed:0.39 green:0.91 blue:0.38 alpha:1];
        lblSave1.backgroundColor = [UIColor clearColor];
        lblSave1.font = [UIFont boldSystemFontOfSize:18.0];
        lblSave1.text = [NSString stringWithFormat:@"%d",[[[locationCatArray objectAtIndex:indexPath.row-1] objectForKey:@"deals_count"] intValue]];
        [cell.contentView addSubview:lblSave1];
        
        UILabel *lblSave = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 230, 54)];
        lblSave.textAlignment = UITextAlignmentRight;
        lblSave.textColor = [UIColor blackColor];
        lblSave.backgroundColor = [UIColor clearColor];
        lblSave.font = [UIFont boldSystemFontOfSize:21.0];
        lblSave.text = [NSString stringWithFormat:@"%@",[[locationCatArray objectAtIndex:indexPath.row-1] valueForKey:@"name"]];
        [cell.contentView addSubview:lblSave];
    }

    
    //	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}


/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 */


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */


/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */



/*
#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    appDelegate.objLocDealsViewController = [[LocDealsViewController alloc] initWithNibName:@"LocDealsViewController" bundle:nil];
    
    
    if(self.selCategoryID == 0)
    {
        appDelegate.objLocCategoryViewController =[[LocCategoryViewController alloc]initWithNibName:@"LocCategoryViewController" bundle:nil ];
        [self.navigationController pushViewController:appDelegate.objLocCategoryViewController animated:YES];
        [appDelegate.objLocDealsViewController release];       
        
        
    }
    else
    {
        if(indexPath.row ==0)
        {
            appDelegate.objLocDealsViewController.selIndex = indexPath.row;
            appDelegate.objLocDealsViewController.selCategoryName = self.selCategoryName;
            appDelegate.objLocDealsViewController.setCatId=self.selCategoryID;
            appDelegate.objLocDealsViewController.setLocId =0;
            
        }
        else
        {
            appDelegate.objLocDealsViewController.selIndex = indexPath.row;
            appDelegate.objLocDealsViewController.selCategoryName = self.selCategoryName;
            appDelegate.objLocDealsViewController.setLocId=[[[appDelegate.arrCatSubDeals objectAtIndex:indexPath.row-1] objectForKey:@"id"] intValue];
            appDelegate.objLocDealsViewController.setCatId=self.selCategoryID;
            
            NSLog(@"Sel location ID==>%d",[[[appDelegate.arrCatSubDeals objectAtIndex:indexPath.row-1] objectForKey:@"id"] intValue]);
        }
        
        [self.navigationController pushViewController:appDelegate.objLocDealsViewController animated:YES];
        [appDelegate.objLocDealsViewController release];       
        
    }
        
}    


/*

#pragma UIScrollView delegate
/*- (void)scrollViewDidScroll:(UIScrollView *)aScrollView {
 CGPoint offset = aScrollView.contentOffset;
 CGRect bounds = aScrollView.bounds;
 CGSize size = aScrollView.contentSize;
 UIEdgeInsets inset = aScrollView.contentInset;
 float y = offset.y + bounds.size.height - inset.bottom;
 float h = size.height;
 // NSLog(@"offset: %f", offset.y);   
 // NSLog(@"content.height: %f", size.height);   
 // NSLog(@"bounds.height: %f", bounds.size.height);   
 // NSLog(@"inset.top: %f", inset.top);   
 // NSLog(@"inset.bottom: %f", inset.bottom);   
 // NSLog(@"pos: %f of %f", y, h);
 
 //float reload_distance = 10;
 if(y == h ) {
 if(!started){
 
 pages++;
 started=YES;
 [self showDeals:pages];
 }
 }
 }
 */
#pragma mark -
#pragma mark MBProgressHUDDelegate methods

- (void)hudWasHidden {
    // Remove HUD from screen when the HUD was hidded
    [HUD removeFromSuperview];
    started=NO;
    [HUD release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


- (void)dealloc
{
    [super dealloc];
}

//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
//{
//    // Return YES for supported orientations
//    return (interfaceOrientation == UIInterfaceOrientationPortrait);
//}

@end
