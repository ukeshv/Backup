//
//  LocDealsViewController.h
//  DailyD
//
//  Created by Vimal Shah on 3/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface LocDealsViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,MBProgressHUDDelegate> {

	DailyDAppDelegate *appDelegate;
	
	IBOutlet UITableView *tblView;
	MBProgressHUD *HUD;
	int selIndex;
    NSString *selCategoryName;
    int setCatId;
    int setLocId;
    NSString *dealsStatus;

}

@property (nonatomic, retain)IBOutlet UITableView *tblView;
@property int selIndex;
@property (nonatomic, retain) NSString *selCategoryName;
@property int setCatId;
@property int setLocId;
@property (nonatomic, retain) NSString *dealsStatus;




-(void)showDeals:(int)page;
- (void)loadingStart:(NSNumber*)page;

@end
