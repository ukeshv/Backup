//
//  Location.m
//  DailyD
//
//  Created by Vimal Shah on 2/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Location.h"


@implementation Location

@synthesize id;
@synthesize name;
@synthesize preferred;

- (void) dealloc {
	
	[name release];
	[super dealloc];
}

@end
