//
//  LocationCategoryViewController.h
//  DailyD
//
//  Created by mac pro on 25/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"
#import "WebService.h"

@interface LocationCategoryViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, MBProgressHUDDelegate>
{
    
    IBOutlet UITableView *locationTableView;
    int location_count;
    
    DailyDAppDelegate *appDelegate;
    WebService *service;
	MBProgressHUD *HUD;
    
    NSMutableArray *tempArray;
    int selLocId;


}

@property (nonatomic, retain) UITableView *locationTableView;
@property int selLocId;



-(void)calculateLocationCount;
- (void)showDeals;


@end
