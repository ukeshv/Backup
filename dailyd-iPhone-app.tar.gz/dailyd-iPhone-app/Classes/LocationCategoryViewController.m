//
//  LocationCategoryViewController.m
//  DailyD
//
//  Created by mac pro on 25/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LocationCategoryViewController.h"

@implementation LocationCategoryViewController
@synthesize locationTableView;
@synthesize selLocId;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    appDelegate = (DailyDAppDelegate *) [[UIApplication sharedApplication]delegate];
    service =[[WebService alloc]init];
    tempArray =[[NSMutableArray alloc]init];
    
    locationTableView.delegate =self;
    locationTableView.dataSource =self;
    location_count =0;
    
    [self showDeals];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}



- (void)showDeals {
	// The hud will dispable all input on the view (use the higest view possible in the view hierarchy)
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	
    // Add HUD to screen
    [self.navigationController.view addSubview:HUD];
	
    // Regisete for HUD callbacks so we can remove it from the window at the right time
    HUD.delegate = self;
	
    HUD.labelText = @"Loading";
	HUD.detailsLabelText = @"dailyD!";
    // Show the HUD while the provided method executes in a new thread
    [HUD showWhileExecuting:@selector(loadingStart) onTarget:self withObject:nil animated:YES];
}


-(void)calculateLocationCount
{
    location_count =0;
    
	for(int i=0; i<[appDelegate.arrLocationCategory count]; i++)
	{
        location_count += [[[appDelegate.arrLocationCategory objectAtIndex:i] objectForKey:@"count"] intValue];
        NSLog(@"Deals _count ==>%d",[[[appDelegate.arrLocationCategory objectAtIndex:i] objectForKey:@"count"] intValue]); 
       
	}
	NSLog(@"Total Category count ==>%d",location_count);
    
}





- (void)loadingStart {
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
    NSLog(@"Sel Location Id ==>%d",self.selLocId);
    
    NSString *jsonString;
    jsonString = [service apiLocationCategories:appDelegate.setAPIUrl locId:self.selLocId];
                 
	NSError *error;
	SBJSON *json = [[SBJSON new] autorelease];
	appDelegate.arrLocationCategory = [json objectWithString:jsonString error:&error];
    
	
	//[appDelegate arrDealsFromObjDictByCategoriesWithSubLocations:appDelegate.arrCatSubDeals];
	
	[self performSelectorOnMainThread:@selector(loadingComplete) withObject:nil waitUntilDone:YES];
	
	[pool release];
}

-(void) loadingComplete {
	NSLog(@"arrCatsubDeals : %d",[appDelegate.arrCatSubDeals count] );
    [self calculateLocationCount];
  //  NSLog(@"Temp Array ==>%@",appDelegate.arrLocationCategory);
    
	[self.locationTableView reloadData];
}


// UITableview delegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [appDelegate.arrLocationCategory count]+1;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 59.0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	//    if (cell == nil) {
	//	cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	//    }
	cell = [[[ClearLabelsCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	cell.backgroundView = [[[GradientView alloc] init] autorelease];
    
	UIImageView *img = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DaliyD2.png"]];
	cell.backgroundView = img;
    
    
	// Configure the cell.
	
	if (indexPath.row == 0) 
	{ 
        // cell.textLabel.text = [NSString stringWithFormat:@"(%d) הצג הכל",[appDelegate.arrDeals count]];
		
		UILabel *lblSave1 = [[UILabel alloc] initWithFrame:CGRectMake(39, 10, 36, 26)];
		lblSave1.textAlignment = UITextAlignmentCenter;
		lblSave1.textColor = [UIColor colorWithRed:0.39 green:0.91 blue:0.38 alpha:1];
		lblSave1.backgroundColor = [UIColor clearColor];
		lblSave1.font = [UIFont boldSystemFontOfSize:18.0];
		lblSave1.text = [NSString stringWithFormat:@"%d",location_count];
		[cell.contentView addSubview:lblSave1];
		
		UILabel *lblSave = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 230, 54)];
		lblSave.textAlignment = UITextAlignmentRight;
		lblSave.textColor = [UIColor blackColor];
		lblSave.backgroundColor = [UIColor clearColor];
		lblSave.font = [UIFont boldSystemFontOfSize:21.0];
		lblSave.text = @"הצג הכל";
		[cell.contentView addSubview:lblSave];
	} else {
        
		UILabel *lblSave1 = [[UILabel alloc] initWithFrame:CGRectMake(39, 10, 36, 26)];
		lblSave1.textAlignment = UITextAlignmentCenter;
		lblSave1.textColor = [UIColor colorWithRed:0.39 green:0.91 blue:0.38 alpha:1];
		lblSave1.backgroundColor = [UIColor clearColor];
		lblSave1.font = [UIFont boldSystemFontOfSize:18.0];
        lblSave1.text = [NSString stringWithFormat:@"%d", [[[appDelegate.arrLocationCategory objectAtIndex:indexPath.row-1] objectForKey:@"count"] intValue]];
        [cell.contentView addSubview:lblSave1];
		
		UILabel *lblSave = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 230, 54)];
		lblSave.textAlignment = UITextAlignmentRight;
		lblSave.textColor = [UIColor blackColor];
		lblSave.backgroundColor = [UIColor clearColor];
		lblSave.font = [UIFont boldSystemFontOfSize:21.0];
		lblSave.text = [NSString stringWithFormat:@"%@",[[appDelegate.arrLocationCategory objectAtIndex:indexPath.row-1] objectForKey:@"name"]];
		[cell.contentView addSubview:lblSave];
 
    }
	
    //	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;

}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    appDelegate.objLocDealsViewController = [[LocDealsViewController alloc] initWithNibName:@"LocDealsViewController" bundle:nil];
    
    
//    if(self.selCategoryID == 0)
//    {
//        
//        LocationCategoryViewController *locCategoryView =[[LocationCategoryViewController alloc]initWithNibName:@"LocationCategoryViewController" bundle:nil];
//        locCategoryView.selLocId = [[[appDelegate.arrCatSubDeals objectAtIndex:indexPath.row-1] objectForKey:@"id"] intValue];
//        [self.navigationController pushViewController:locCategoryView animated:YES];
//        [locCategoryView release];
//        
//    }
//    else
//    {
        if(indexPath.row ==0)
        {
            appDelegate.objLocDealsViewController.selIndex = indexPath.row;
//            appDelegate.objLocDealsViewController.selCategoryName = self.selCategoryName;
            appDelegate.objLocDealsViewController.setCatId=self.selLocId;
            appDelegate.objLocDealsViewController.setLocId =0;
            
        }
        else
        {
            appDelegate.objLocDealsViewController.selIndex = indexPath.row;
       //     appDelegate.objLocDealsViewController.selCategoryName = self.selCategoryName;
            appDelegate.objLocDealsViewController.setCatId=[[[appDelegate.arrLocationCategory objectAtIndex:indexPath.row-1] objectForKey:@"id"] intValue];
            appDelegate.objLocDealsViewController.setLocId=self.selLocId;
            
            NSLog(@"Sel location ID==>%d",[[[appDelegate.arrCatSubDeals objectAtIndex:indexPath.row-1] objectForKey:@"id"] intValue]);
        }
        
        [self.navigationController pushViewController:appDelegate.objLocDealsViewController animated:YES];
        [appDelegate.objLocDealsViewController release];       
        
    //}
}



@end
