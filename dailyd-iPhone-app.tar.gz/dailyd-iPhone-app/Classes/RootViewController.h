//
//  RootViewController.h
//  DailyD
//
//  Created by Vimal Shah on 2/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"

@interface RootViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, MBProgressHUDDelegate> {
	
	DailyDAppDelegate *appDelegate;
	
	IBOutlet UITableView *tblView;
	MBProgressHUD *HUD;

	UISegmentedControl *segControl;
	int segIndex;
}

@property (nonatomic, retain)IBOutlet UITableView *tblView;

- (void)showDeals:(int)page;

@end
