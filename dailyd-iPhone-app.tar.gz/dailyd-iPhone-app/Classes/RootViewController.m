//
//  RootViewController.m
//  DailyD
//
//  Created by Vimal Shah on 2/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "DealCellView.h"

@implementation RootViewController

@synthesize tblView;

#pragma mark -
#pragma mark View lifecycle

BOOL started;
int rootpage=1;

- (void)viewDidLoad {
    [super viewDidLoad];

	appDelegate = (DailyDAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	UIButton* infoButton = [UIButton buttonWithType:UIButtonTypeInfoLight];
	[infoButton addTarget:self action:@selector(infoButtonAction) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *modalButton = [[UIBarButtonItem alloc] initWithCustomView:infoButton];
	[self.navigationItem setLeftBarButtonItem:modalButton animated:YES];
	[modalButton release];

	UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, 67.0, 27.0)];
	[imgView setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]]];
	UIBarButtonItem *btnRight = [[UIBarButtonItem alloc] initWithCustomView:imgView];
	self.navigationItem.rightBarButtonItem = btnRight;
	[imgView release];
	
	NSArray *segmentTextContent = [NSArray arrayWithObjects: @"קטגוריות", @"מיקומים", nil];
//	NSArray *segmentTextContent = [NSArray arrayWithObjects: @"Categories", @"Locations", nil];
	segControl = [[UISegmentedControl alloc] initWithItems:segmentTextContent];
	segControl.frame = CGRectMake(0, 0, 150, 30);
	[segControl addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
	segControl.segmentedControlStyle = UISegmentedControlStyleBezeled;
	segControl.enabled = true;
	
	self.navigationItem.titleView = segControl;
	[segControl release];
	segControl.selectedSegmentIndex = 0;
	segIndex = 0;
		
}

- (void)viewWillAppear:(BOOL)animated {
	[self.tblView deselectRowAtIndexPath:[self.tblView indexPathForSelectedRow] animated:YES];

	self.navigationItem.title = nil;

//	if (appDelegate.isFromSettings) {
//		appDelegate.isFromSettings = FALSE;
//		
//		appDelegate.arrMutableDealsByCategories = nil;
//		appDelegate.arrMutableDealsByLocations = nil;
//
//		segControl.selectedSegmentIndex = 0;
//		segIndex = 0;
//		
//	}

}

- (IBAction) segmentAction :(id)sender {
	UISegmentedControl *segC = sender;
	segIndex = segC.selectedSegmentIndex;
	
	if (segIndex == 0) {
		if(![appDelegate.arrMutableDealsByCategories count] > 0) {
			[appDelegate arrDealsFromObjDictByCategories:appDelegate.arrDeals];
		}
	} else {
		if(![appDelegate.arrMutableDealsByLocations count] > 0) {
			[appDelegate arrDealsFromObjDictByLocations:appDelegate.arrDeals];
		}
	}
	[self.tblView reloadData];
}

- (IBAction) infoButtonAction {
	
	self.navigationItem.title = @"בחזרה";

	appDelegate.objSettingsViewController = [[SettingsViewController alloc] initWithNibName:@"SettingsViewController" bundle:nil];
	[self.navigationController pushViewController:appDelegate.objSettingsViewController animated:YES];
	[appDelegate.objSettingsViewController release];
}

- (void)showDeals:(int)page {
	// The hud will dispable all input on the view (use the higest view possible in the view hierarchy)
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	
    // Add HUD to screen
    [self.navigationController.view addSubview:HUD];
	
    // Regisete for HUD callbacks so we can remove it from the window at the right time
    HUD.delegate = self;
	
    HUD.labelText = @"Loading";
	HUD.detailsLabelText = @"dailyD!";
    // Show the HUD while the provided method executes in a new thread
    [HUD showWhileExecuting:@selector(loadingStart:) onTarget:self withObject:[NSNumber numberWithInt:page] animated:YES];
}

- (void)loadingStart:(NSNumber*)number {
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

	NSString *jsonString = [appDelegate apiDeals:[number intValue]];

	NSError *error;
	SBJSON *json = [[SBJSON new] autorelease];
	appDelegate.arrDeals = [json objectWithString:jsonString error:&error];
	
	[appDelegate arrDealsFromObjDictByCategories:appDelegate.arrDeals];
	
	[self performSelectorOnMainThread:@selector(loadingComplete) withObject:nil waitUntilDone:YES];
	
	[pool release];
}

-(void) loadingComplete {
	NSLog(@"%d",[appDelegate.arrDeals count]);
	[self.tblView reloadData];
}

/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

/*
 // Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations.
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
 */


#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	if (segIndex == 0)
		return [appDelegate.arrMutableDealsByCategories count];
	else
		return [appDelegate.arrMutableDealsByLocations count];
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	if (segIndex == 0)
		return [[[appDelegate.arrMutableDealsByCategories objectAtIndex:section] objectForKey:@"value"] count];
	else
		return [[[appDelegate.arrMutableDealsByLocations objectAtIndex:section] objectForKey:@"value"] count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	if (segIndex == 0)
		return ([[appDelegate.arrMutableDealsByCategories objectAtIndex:section] objectForKey:@"header"]);
	else
		return ([[appDelegate.arrMutableDealsByLocations objectAtIndex:section] objectForKey:@"header"]);
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	return 30;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	return 100;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	// create the parent view that will hold header Label
	UIView* customView = [[UIView alloc] initWithFrame:CGRectMake(10.0, 10.0, 300.0, 30.0)];
	//CGFloat rd = 56/255;
	customView.backgroundColor = appDelegate.clrCell;
	//customView.backgroundColor = [UIColor clearColor];
	// create the button object
	UILabel * headerLabel = [[UILabel alloc] initWithFrame:CGRectZero];
	headerLabel.backgroundColor = [UIColor clearColor];
	headerLabel.opaque = NO;
	headerLabel.textColor = [UIColor blackColor];
	headerLabel.shadowOffset = CGSizeMake(0.0, 1.0);
	headerLabel.highlightedTextColor = [UIColor grayColor];
	headerLabel.font = [UIFont boldSystemFontOfSize:16];
	//[headerLabel setFont:[UIFont fontWithName:appDelegate.pref_font size:12]];    
	
	headerLabel.frame = CGRectMake(10.0, 0.0, 290.0, 30.0);
	headerLabel.textAlignment = UITextAlignmentRight;
	
	// If you want to align the header text as centered
	// headerLabel.frame = CGRectMake(150.0, 0.0, 300.0, 44.0);
	
	if (segIndex == 0)
		headerLabel.text = [[appDelegate.arrMutableDealsByCategories objectAtIndex:section] objectForKey:@"header"];
	else
		headerLabel.text = [[appDelegate.arrMutableDealsByLocations objectAtIndex:section] objectForKey:@"header"];
	[customView addSubview:headerLabel];
	
	return customView;
	
}
// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
//    }
    
	// Configure the cell.

	DealCellView *objCell = [[DealCellView alloc] init];
	[cell.contentView addSubview:objCell.view];
	[objCell.view setFrame:CGRectMake(5, 0, 300, 44)];

	Deal *objDeal;
	if (segIndex == 0)
		objDeal = [[[appDelegate.arrMutableDealsByCategories objectAtIndex:indexPath.section] objectForKey:@"value"] objectAtIndex:indexPath.row];
	else
		objDeal = [[[appDelegate.arrMutableDealsByLocations objectAtIndex:indexPath.section] objectForKey:@"value"] objectAtIndex:indexPath.row];
	
	objCell.lblTitle.text = objDeal.title;
	[cell.contentView addSubview:objCell.lblTitle];
	
	[cell.contentView addSubview:objCell.imgDealImage];
	if (objDeal.imgDeal != nil) {
		UIImage *img = [appDelegate imageByScalingProportionallyToSize:CGSizeMake(100, 96) srcImg:objDeal.imgDeal];
		objCell.imgDealImage.image = img;
	} else {
		objCell.imgDealImage.image = [UIImage imageNamed:@"100X80_thumb.png"];
		if (![objDeal.image_url isEqualToString:@""]) {
			NSMutableArray *arrObjects = [[NSMutableArray alloc] init];
			[arrObjects addObject:objDeal];
			[arrObjects addObject:objCell];
			[NSThread detachNewThreadSelector:@selector(loadImage:) toTarget:self withObject:arrObjects];
		}
	}
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)loadImage :(NSMutableArray *)arrObjects {
    
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	Deal *objDeal = [arrObjects objectAtIndex:0];
	NSURL *url = [[NSURL alloc] initWithString:objDeal.image_url];
	UIImage *image = [[UIImage alloc] initWithData:[[NSData alloc] initWithContentsOfURL:url]]; 
	objDeal.imgDeal = image;
	
	[self performSelectorOnMainThread:@selector(loadImageComplete:) withObject:arrObjects waitUntilDone:YES];
	
	[pool drain];
}

- (void)loadImageComplete:(NSMutableArray *)arrObjects{
	
	Deal *objDeal = [arrObjects objectAtIndex:0];
	DealCellView *objCell = [arrObjects objectAtIndex:1];
	UIImage *img = [appDelegate imageByScalingProportionallyToSize:CGSizeMake(100, 96) srcImg:objDeal.imgDeal];
	objCell.imgDealImage.image = img; 
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
	Deal *objDeal;
	
	if (segIndex == 0)
		objDeal = [[[appDelegate.arrMutableDealsByCategories objectAtIndex:indexPath.section] objectForKey:@"value"] objectAtIndex:indexPath.row];
	else
		objDeal = [[[appDelegate.arrMutableDealsByLocations objectAtIndex:indexPath.section] objectForKey:@"value"] objectAtIndex:indexPath.row];
	
	self.navigationItem.title = @"בחזרה";

	appDelegate.objDealDetailViewController = [[DealDetailViewController alloc] initWithNibName:@"DealDetailViewController" bundle:nil];
	appDelegate.objDealDetailViewController.objSelectedDeal = objDeal;
	[self.navigationController pushViewController:appDelegate.objDealDetailViewController animated:YES];
	[appDelegate.objDealDetailViewController release];
}

#pragma UIScrollView delegate
- (void)scrollViewDidScroll:(UIScrollView *)aScrollView {
    CGPoint offset = aScrollView.contentOffset;
    CGRect bounds = aScrollView.bounds;
    CGSize size = aScrollView.contentSize;
    UIEdgeInsets inset = aScrollView.contentInset;
    float y = offset.y + bounds.size.height - inset.bottom;
    float h = size.height;
    // NSLog(@"offset: %f", offset.y);   
    // NSLog(@"content.height: %f", size.height);   
    // NSLog(@"bounds.height: %f", bounds.size.height);   
    // NSLog(@"inset.top: %f", inset.top);   
    // NSLog(@"inset.bottom: %f", inset.bottom);   
    // NSLog(@"pos: %f of %f", y, h);
    
    //float reload_distance = 10;
    if(y == h ) {
        if(!started){
            
            rootpage++;
            started=YES;
            [self showDeals:rootpage];
            [self.tblView reloadData];
            //  [self.tblView scrollsToTop];
            [self.tblView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
    }
}


#pragma mark -
#pragma mark MBProgressHUDDelegate methods

- (void)hudWasHidden {
    // Remove HUD from screen when the HUD was hidded
    [HUD removeFromSuperview];
    started=NO;
    [HUD release];
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end

