//
//  SecondSubListViewController.h
//  DailyD
//
//  Created by Vimal Shah on 4/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface SecondSubListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, MBProgressHUDDelegate> {
    
    DailyDAppDelegate *appDelegate;
	
	IBOutlet UITableView *tblView;
	MBProgressHUD *HUD;
    
    int selLocationID;
    NSMutableArray *arrCatsFromLocs;
    NSString *selLocationName;
    
}

@property (nonatomic, retain)IBOutlet UITableView *tblView;
@property int selLocationID;
@property (nonatomic, retain) NSMutableArray *arrCatsFromLocs;
@property (nonatomic, retain) NSString *selLocationName;

- (void)showDeals;

@end
