//
//  SecondSubListViewController.m
//  DailyD
//
//  Created by Vimal Shah on 4/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SecondSubListViewController.h"
#import "WebService.h"

@implementation SecondSubListViewController

@synthesize tblView;

@synthesize selLocationID;
@synthesize arrCatsFromLocs;
@synthesize selLocationName;

BOOL started;
#pragma mark - View lifecycle
WebService *service;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    service=[[WebService alloc] init];
    appDelegate = (DailyDAppDelegate *)[[UIApplication sharedApplication] delegate];
	self.tblView.backgroundColor = [UIColor lightGrayColor];
    self.navigationItem.title = self.selLocationName;
    
	UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, 67.0, 27.0)];
	[imgView setImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]]];
	UIBarButtonItem *btnRight = [[UIBarButtonItem alloc] initWithCustomView:imgView];
	self.navigationItem.rightBarButtonItem = btnRight;
	[imgView release];
    
   // [appDelegate arrCatsFromLocation:self.arrCatsFromLocs];

   [self showDeals];

}

- (void)viewWillAppear:(BOOL)animated {
	[self.tblView deselectRowAtIndexPath:[self.tblView indexPathForSelectedRow] animated:YES];
}


- (void)showDeals {
	// The hud will dispable all input on the view (use the higest view possible in the view hierarchy)
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	
    // Add HUD to screen
    [self.navigationController.view addSubview:HUD];
	
    // Regisete for HUD callbacks so we can remove it from the window at the right time
    HUD.delegate = self;
	
    HUD.labelText = @"Loading";
	HUD.detailsLabelText = @"dailyD!";
    // Show the HUD while the provided method executes in a new thread
    [HUD showWhileExecuting:@selector(loadingStart) onTarget:self withObject:nil animated:YES];
}

- (void)loadingStart {
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
    NSString *jsonString;
    if (self.selLocationID == 0) {
        jsonString = [service apiCategories:appDelegate.setAPIUrl];
	} else {
        jsonString = [service apiLocationCategories:appDelegate.setAPIUrl locId:self.selLocationID];
    }
    
	
	NSError *error;
	SBJSON *json = [[SBJSON new] autorelease];
	appDelegate.arrLocSubDeals = [json objectWithString:jsonString error:&error];
	
	[appDelegate arrDealsFromObjDictByLocationsWithSubCategories:appDelegate.arrLocSubDeals];
	
	[self performSelectorOnMainThread:@selector(loadingComplete) withObject:nil waitUntilDone:YES];
	
	[pool release];
}

-(void) loadingComplete {
	NSLog(@"%d",[appDelegate.arrDeals count]);
	[self.tblView reloadData];
}

#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 59.0;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	/*if ([appDelegate.arrLocSubDeals count] == 0)
		return 0;
	else*/
		return [appDelegate.arrLocSubDeals count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	//    if (cell == nil) {
    //	cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	//    }
	cell = [[[ClearLabelsCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	cell.backgroundView = [[[GradientView alloc] init] autorelease];
    
	UIImageView *img = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DaliyD2.png"]];
	cell.backgroundView = img;
	// Configure the cell.
	
	if (indexPath.row == 0) {
        //		cell.textLabel.text = [NSString stringWithFormat:@"(%d) הצג הכל",[appDelegate.arrDeals count]];
		UILabel *lblSave1 = [[UILabel alloc] initWithFrame:CGRectMake(39, 10, 36, 26)];
		lblSave1.textAlignment = UITextAlignmentCenter;
		lblSave1.textColor = [UIColor colorWithRed:0.39 green:0.91 blue:0.38 alpha:1];
		lblSave1.backgroundColor = [UIColor clearColor];
		lblSave1.font = [UIFont boldSystemFontOfSize:18.0];
		lblSave1.text = [NSString stringWithFormat:@"%d",[appDelegate.arrLocSubDeals count]];
		[cell.contentView addSubview:lblSave1];
		
		UILabel *lblSave = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 230, 54)];
		lblSave.textAlignment = UITextAlignmentRight;
		lblSave.textColor = [UIColor blackColor];
		lblSave.backgroundColor = [UIColor clearColor];
		lblSave.font = [UIFont boldSystemFontOfSize:21.0];
		lblSave.text = @"כל הקטגוריות";
		[cell.contentView addSubview:lblSave];
	} else {
        //		cell.textLabel.text = [NSString stringWithFormat:@"(%d) %@",[[[appDelegate.arrMutableDealsByLocations objectAtIndex:indexPath.row-1] objectForKey:@"value"] count], [[appDelegate.arrMutableDealsByLocations objectAtIndex:indexPath.row-1] valueForKey:@"header"]];
        
		UILabel *lblSave1 = [[UILabel alloc] initWithFrame:CGRectMake(39, 10, 36, 26)];
		lblSave1.textAlignment = UITextAlignmentCenter;
		lblSave1.textColor = [UIColor colorWithRed:0.39 green:0.91 blue:0.38 alpha:1];
		lblSave1.backgroundColor = [UIColor clearColor];
		lblSave1.font = [UIFont boldSystemFontOfSize:18.0];
		lblSave1.text = [NSString stringWithFormat:@"%d",[[[appDelegate.arrLocSubDeals objectAtIndex:indexPath.row] objectForKey:@"count"] intValue]];
		[cell.contentView addSubview:lblSave1];
		
		UILabel *lblSave = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 230, 54)];
		lblSave.textAlignment = UITextAlignmentRight;
		lblSave.textColor = [UIColor blackColor];
		lblSave.backgroundColor = [UIColor clearColor];
		lblSave.font = [UIFont boldSystemFontOfSize:21.0];
		lblSave.text = [NSString stringWithFormat:@"%@",[[appDelegate.arrLocSubDeals objectAtIndex:indexPath.row] valueForKey:@"name"]];
		[cell.contentView addSubview:lblSave];
	}
	
    //	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 */


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */


/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
   /* appDelegate.objCatDealsViewController = [[CatDealsViewController alloc] initWithNibName:@"CatDealsViewController" bundle:nil];
	appDelegate.objCatDealsViewController.selIndex = indexPath.row;
    appDelegate.objCatDealsViewController.selLocationName = self.selLocationName;
    [self.navigationController pushViewController:appDelegate.objCatDealsViewController animated:YES];
	[appDelegate.objCatDealsViewController release];
    */
   // if(indexPath.row!=0){
        appDelegate.objCatDealsViewController = [[CatDealsViewController alloc] initWithNibName:@"CatDealsViewController" bundle:nil];
        appDelegate.objCatDealsViewController.selIndex = indexPath.row;
        appDelegate.objCatDealsViewController.selLocationName = self.selLocationName;
       // [appDelegate.objCatDealsViewController setSelLocationName:<#(NSString *)#>]
        appDelegate.objCatDealsViewController.setLocId=self.selLocationID;
        appDelegate.objCatDealsViewController.setCatId=[[[appDelegate.arrLocSubDeals objectAtIndex:indexPath.row] objectForKey:@"id"] intValue];
        
        [self.navigationController pushViewController:appDelegate.objCatDealsViewController animated:YES];
        [appDelegate.objCatDealsViewController release];
        
        //	appDelegate.objCatDealsViewController = [[CatDealsViewController alloc] initWithNibName:@"CatDealsViewController" bundle:nil];
        //	appDelegate.objCatDealsViewController.selIndex = indexPath.row;
        //	[self.navigationController pushViewController:appDelegate.objCatDealsViewController animated:YES];
        //	[appDelegate.objCatDealsViewController release];
   // }

    //	appDelegate.objCatDealsViewController = [[CatDealsViewController alloc] initWithNibName:@"CatDealsViewController" bundle:nil];
    //	appDelegate.objCatDealsViewController.selIndex = indexPath.row;
    //	[self.navigationController pushViewController:appDelegate.objCatDealsViewController animated:YES];
    //	[appDelegate.objCatDealsViewController release];
    
}

//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
//{
//    // Return YES for supported orientations
//    return (interfaceOrientation == UIInterfaceOrientationPortrait);
//}
/*
#pragma UIScrollView delegate
- (void)scrollViewDidScroll:(UIScrollView *)aScrollView {
    CGPoint offset = aScrollView.contentOffset;
    CGRect bounds = aScrollView.bounds;
    CGSize size = aScrollView.contentSize;
    UIEdgeInsets inset = aScrollView.contentInset;
    float y = offset.y + bounds.size.height - inset.bottom;
    float h = size.height;
    // NSLog(@"offset: %f", offset.y);   
    // NSLog(@"content.height: %f", size.height);   
    // NSLog(@"bounds.height: %f", bounds.size.height);   
    // NSLog(@"inset.top: %f", inset.top);   
    // NSLog(@"inset.bottom: %f", inset.bottom);   
    // NSLog(@"pos: %f of %f", y, h);
    
    //float reload_distance = 10;
    if(y == h ) {
        if(!started){
            
            pagessl++;
            started=YES;
            [self showDeals:pagessl];
        }
    }
}

*/

#pragma mark -
#pragma mark MBProgressHUDDelegate methods

- (void)hudWasHidden {
    // Remove HUD from screen when the HUD was hidded
    started=NO;
    [HUD removeFromSuperview];
    [HUD release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


@end
