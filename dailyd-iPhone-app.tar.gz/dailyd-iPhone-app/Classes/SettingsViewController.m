//
//  SettingsViewController.m
//  DailyD
//
//  Created by Vimal Shah on 2/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SettingsViewController.h"


@implementation SettingsViewController

@synthesize tblView;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	appDelegate = (DailyDAppDelegate *)[[UIApplication sharedApplication] delegate];
	self.navigationItem.title = @"הגדרות";

	self.view.backgroundColor = appDelegate.clrTableViewBack;
	self.tblView.backgroundColor = [UIColor lightGrayColor];

//	[appDelegate updateCategoriesFile];
//	[appDelegate updateLocationsFile];
}

- (void)viewWillAppear:(BOOL)animated {
	[self.tblView deselectRowAtIndexPath:[self.tblView indexPathForSelectedRow] animated:YES];
	
//	BOOL flgHasCategory = FALSE;
//	for (int i=0; i<[appDelegate.arrPreferredCategories count]; i++) {
//		if ([[appDelegate.arrPreferredCategories objectAtIndex:i] isEqualToString:@"1"]) {
//			flgHasCategory = TRUE;
//		}
//	}
	BOOL flgHasCategory = [appDelegate isAllCategoryUnchecked];
	if (!flgHasCategory) {
		alertNoCategories = [[UIAlertView alloc] initWithTitle:appDelegate.setAppAlertTitle message:@"יש לבחור לפחות קטגוריה אחת" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
		[alertNoCategories show];
		[alertNoCategories release];
	}
	
//	BOOL flgHasLocations = FALSE;
//	for (int i=0; i<[appDelegate.arrPreferredLocations count]; i++) {
//		if ([[appDelegate.arrPreferredLocations objectAtIndex:i] isEqualToString:@"1"]) {
//			flgHasLocations = TRUE;
//		}
//	}
	BOOL flgHasLocations = [appDelegate isAllLocationUnchecked];
	if (!flgHasLocations) {
		alertNoLocations = [[UIAlertView alloc] initWithTitle:appDelegate.setAppAlertTitle message:@"יש לבחור לפחות מיקום אחד" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
		[alertNoLocations show];
		[alertNoLocations release];
	}
	
}

- (void)viewWillDisappear:(BOOL)animated {

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if (alertView == alertNoCategories) {
		appDelegate.objCategoriesViewController = [[CategoriesViewController alloc] initWithNibName:@"CategoriesViewController" bundle:nil];
		[self.navigationController pushViewController:appDelegate.objCategoriesViewController animated:YES];
		[appDelegate.objCategoriesViewController release];
		
	}
	if (alertView == alertNoLocations) {
		appDelegate.objLocationsViewController = [[LocationsViewController alloc] initWithNibName:@"LocationsViewController" bundle:nil];
		[self.navigationController pushViewController:appDelegate.objLocationsViewController animated:YES];
		[appDelegate.objLocationsViewController release];
		
	}
}
#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	//    if (cell == nil) {
	cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	//    }
//	cell = [[[ClearLabelsCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
//	cell.backgroundView = [[[GradientView alloc] init] autorelease];

	// Configure the cell.
	
	if (indexPath.section == 0) {
		cell.textLabel.text = @"בחר קטגוריות";
	} else if (indexPath.section == 1) {
		cell.textLabel.text = @"בחר מיקומים";
	}
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}


/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */


/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 */


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */


/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
	if (indexPath.section == 0) {
		appDelegate.objCategoriesViewController = [[CategoriesViewController alloc] initWithNibName:@"CategoriesViewController" bundle:nil];
		[self.navigationController pushViewController:appDelegate.objCategoriesViewController animated:YES];
		[appDelegate.objCategoriesViewController release];
	} else if (indexPath.section == 1) {
		appDelegate.objLocationsViewController = [[LocationsViewController alloc] initWithNibName:@"LocationsViewController" bundle:nil];
		[self.navigationController pushViewController:appDelegate.objLocationsViewController animated:YES];
		[appDelegate.objLocationsViewController release];
	}
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
