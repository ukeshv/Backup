//
//  ShareViewController.h
//  DailyD
//
//  Created by Ronak Shah on 16/03/11.
//  Copyright 2011 http://agileinfoways.com. All rights reserved.
//

#import "Globals.h"


@interface ShareViewController : UIViewController <UIActionSheetDelegate,MFMessageComposeViewControllerDelegate,UINavigationControllerDelegate,MFMailComposeViewControllerDelegate,FBRequestDelegate,FBSessionDelegate>{
	FBSession* _session;
	FBLoginDialog *_loginDialog;
	UIButton *_postGradesButton;
	UIButton *_logoutButton;
	NSString *_facebookName;
	BOOL _posting;
	
	DailyDAppDelegate *appDelegate;
}
@property (nonatomic, retain) FBSession *session;
@property (nonatomic, retain) IBOutlet UIButton *postGradesButton;
@property (nonatomic, retain) IBOutlet UIButton *logoutButton;
@property (nonatomic, retain) FBLoginDialog *loginDialog;
@property (nonatomic, copy) NSString *facebookName;
@property (nonatomic, assign) BOOL posting;

- (IBAction)postGradesTapped:(id)sender;
- (IBAction)logoutButtonTapped:(id)sender;
- (void)postToWall;
- (void)getFacebookName;

-(IBAction) btnEmailClicked;
-(IBAction) btnSmsClicked:(id) sender;
-(void)displayComposerSheet;
-(void)launchMailAppOnDevice;
@end
