//
//  ShareViewController.m
//  DailyD
//
//  Created by Ronak Shah on 16/03/11.
//  Copyright 2011 http://agileinfoways.com. All rights reserved.
//

#import "ShareViewController.h"


@implementation ShareViewController
@synthesize session = _session;
@synthesize postGradesButton = _postGradesButton;
@synthesize logoutButton = _logoutButton;
@synthesize loginDialog = _loginDialog;
@synthesize facebookName = _facebookName;
@synthesize posting = _posting;


#pragma mark FOR sending eamil

-(IBAction) btnEmailClicked{
	Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
	if (mailClass != nil)
	{
		// We must always check whether the current device is configured for sending emails
		if ([mailClass canSendMail])
		{
			[self displayComposerSheet];
		}
		else
		{
			[self launchMailAppOnDevice];
		}
	}
	else
	{
		[self launchMailAppOnDevice];
	}
	
}
-(void)displayComposerSheet 
{
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    picker.mailComposeDelegate = self;
    
    [picker setSubject:@"DailyD iPhone Application"];
    
	
	//    // Set up recipients
	//    NSArray *toRecipients = [NSArray arrayWithObject:@"first@example.com"]; 
	//    NSArray *ccRecipients = [NSArray arrayWithObjects:@"second@example.com", @"third@example.com", nil]; 
	//    NSArray *bccRecipients = [NSArray arrayWithObject:@"fourth@example.com"]; 
	//    
	//    [picker setToRecipients:toRecipients];
	//    [picker setCcRecipients:ccRecipients];  
	//    [picker setBccRecipients:bccRecipients];
    
    // Attach an image to the email
	//    NSString *path = [[NSBundle mainBundle] pathForResource:@"Icon" ofType:@"png"];
	//    NSData *myData = [NSData dataWithContentsOfFile:path];
	//    [picker addAttachmentData:myData mimeType:@"image/png" fileName:@"AppIcon"];
    
    // Fill out the email body text
    NSString *emailBody = @"I'm using DailyD iPhone Application and find it interesting for finding deals. You will like it too! \n http://itunes.apple.com/il/app/id424761898?mt=8\n";
    [picker setMessageBody:emailBody isHTML:NO];
    
    [self presentModalViewController:picker animated:YES];
    [picker release];
}
-(void)launchMailAppOnDevice
{
    NSString *recipients = @"mailto:?subject=DailyD iPhone Application";
    NSString *body = @"&body=I'm using DailyD iPhone Application and find it interesting for finding deals. You will like it too! \n http://itunes.apple.com/il/app/id424761898?mt=8\n";
    
    NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
    email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 
{   
	//    message.hidden = NO;
	//    // Notifies users about errors associated with the interface
	//    switch (result)
	//    {
	//        case MFMailComposeResultCancelled:
	//            message.text = @"Result: canceled";
	//            break;
	//        case MFMailComposeResultSaved:
	//            message.text = @"Result: saved";
	//            break;
	//        case MFMailComposeResultSent:
	//            message.text = @"Result: sent";
	//            break;
	//        case MFMailComposeResultFailed:
	//            message.text = @"Result: failed";
	//            break;
	//        default:
	//            message.text = @"Result: not sent";
	//            break;
	//    }
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark FOR Post on Facebook

- (IBAction)postGradesTapped:(id)sender {
    NSLog(@"postGradesTapped");
	_posting = YES;
	// If we're not logged in, log in first...
	if (![_session isConnected]) {
		self.loginDialog = nil;
		_loginDialog = [[FBLoginDialog alloc] init];	
		[_loginDialog show];	
	}
	// If we have a session and a name, post to the wall!
	else if (_facebookName != nil) {
		[self postToWall];
	}
	// Otherwise, we don't have a name yet, just wait for that to come through.
}

- (IBAction)logoutButtonTapped:(id)sender {
	[_session logout];
}


#pragma mark FBSessionDelegate methods

- (void)session:(FBSession*)session didLogin:(FBUID)uid {
	[self getFacebookName];
}

- (void)session:(FBSession*)session willLogout:(FBUID)uid {
	_facebookName = nil;
}

#pragma mark Get Facebook Name Helper

- (void)getFacebookName {
	NSString* fql = [NSString stringWithFormat:
					 @"select uid,name from user where uid == %lld", _session.uid];
	NSDictionary* params = [NSDictionary dictionaryWithObject:fql forKey:@"query"];
	[[FBRequest requestWithDelegate:self] call:@"facebook.fql.query" params:params];
}

#pragma mark FBRequestDelegate methods

- (void)request:(FBRequest*)request didLoad:(id)result {
	if ([request.method isEqualToString:@"facebook.fql.query"]) {
		NSArray* users = result;
		NSDictionary* user = [users objectAtIndex:0];
		NSString* name = [user objectForKey:@"name"];
		self.facebookName = name;		
		_logoutButton.hidden = NO;
		[_logoutButton setTitle:[NSString stringWithFormat:@"Facebook: Logout as %@", name] forState:UIControlStateNormal];
		if (_posting) {
			[self postToWall];
			_posting = NO;
		}
	}
}

#pragma mark Post to Wall Helper

- (void)postToWall {
	
	FBStreamDialog* dialog = [[[FBStreamDialog alloc] init] autorelease];
	dialog.userMessagePrompt = @"Enter your message:";
	dialog.attachment = [NSString stringWithFormat:@"{\"name\":\"DailyD\",\"href\":\"http://dailyd.co.il/\",\"description\":\"I'm using DailyD iPhone Application and find it interesting for finding deals. You will like it too!\"}"];
	dialog.actionLinks = @"[{\"text\":\"DailyD!\",\"href\":\"http://itunes.apple.com/il/app/id424761898?mt=8\"}]";

	[dialog show];
}

#pragma mark For sending SMS
-(IBAction) btnSmsClicked:(id) sender{
	float version = [[[UIDevice currentDevice] systemVersion] floatValue];
	NSLog(@"version %f",version);
	if(version < 4.0){
		NSString *stringURL = @"sms:+12345678901";
		NSURL *url = [NSURL URLWithString:stringURL];
		[[UIApplication sharedApplication] openURL:url];
	}
	else{
		MFMessageComposeViewController *controller = [[[MFMessageComposeViewController alloc] init] autorelease];
		if([MFMessageComposeViewController canSendText]){
			controller.messageComposeDelegate = self;
			[self presentModalViewController:controller animated:YES];
		}
	}
}
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
	[self dismissModalViewControllerAnimated:YES];
}
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	static NSString* kApiKey = @"133562463367597";
	static NSString* kApiSecret = @"6cdcfe15d56fa0e917bc05370b77784b";
	_session = [[FBSession sessionForApplication:kApiKey secret:kApiSecret delegate:self] retain];
	
	// Load a previous session from disk if available.  Note this will call session:didLogin if a valid session exists.
	[_session resume];
	
}
-(void)viewWillAppear:(BOOL)animated{
	UIActionSheet *shareMenu = [[UIActionSheet alloc] initWithTitle:appDelegate.setAppAlertTitle delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:@"שתף בדוא\"ל",@"שתף במסרון",@"שתף בפייסבוק",@"בטל",nil];
	[shareMenu showInView:self.view];
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
	if(buttonIndex == 0){
		Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
		if (mailClass != nil)
		{
			// We must always check whether the current device is configured for sending emails
			if ([mailClass canSendMail])
			{
				[self displayComposerSheet];
			}
			else
			{
				[self launchMailAppOnDevice];
			}
		}
		else
		{
			[self launchMailAppOnDevice];
		}
		
	}
	if(buttonIndex == 1){
		float version = [[[UIDevice currentDevice] systemVersion] floatValue];
		NSLog(@"version %f",version);
		if(version < 4.0){
			NSString *stringURL = @"sms:+12345678901";
			NSURL *url = [NSURL URLWithString:stringURL];
			[[UIApplication sharedApplication] openURL:url];
		}
		else{
			MFMessageComposeViewController *controller = [[[MFMessageComposeViewController alloc] init] autorelease];
			if([MFMessageComposeViewController canSendText]){
				controller.messageComposeDelegate = self;
				[self presentModalViewController:controller animated:YES];
			}
		}
		
	}
	if(buttonIndex == 2){
		_posting = YES;
		// If we're not logged in, log in first...
		if (![_session isConnected]) {
            appDelegate.flgFBLoginDialog = TRUE;
			self.loginDialog = nil;
			_loginDialog = [[FBLoginDialog alloc] init];	
			[_loginDialog show];	
		}
		// If we have a session and a name, post to the wall!
		else if (_facebookName != nil) {
            appDelegate.flgFBLoginDialog = FALSE;
			[self postToWall];
		}
		
	}
	if(buttonIndex == 3){
//		[appDelegate.tabBarController setSelectedIndex:2];
		self.tabBarController.selectedViewController = [self.tabBarController.viewControllers objectAtIndex:appDelegate.selectedTabIndex];	
	}
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
