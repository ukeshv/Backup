//
//  SiteDealsViewController.h
//  DailyD
//
//  Created by Vimal Shah on 3/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface SiteDealsViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,MBProgressHUDDelegate> {

	DailyDAppDelegate *appDelegate;
	MBProgressHUD *HUD;
	IBOutlet UITableView *tblView;
	
	int selIndex;
    int siteID;
}

@property (nonatomic, retain)IBOutlet UITableView *tblView;
@property int siteID;
@property int selIndex;
- (void)showDeals:(int)page;
@end
