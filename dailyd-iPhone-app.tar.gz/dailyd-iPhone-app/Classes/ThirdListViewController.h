//
//  ThirdListViewController.h
//  DailyD
//
//  Created by Vimal Shah on 3/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"


@interface ThirdListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, MBProgressHUDDelegate> {

	DailyDAppDelegate *appDelegate;
	
	IBOutlet UITableView *tblView;
	MBProgressHUD *HUD;
	
}

@property (nonatomic, retain)IBOutlet UITableView *tblView;

- (void)showDeals;

@end
