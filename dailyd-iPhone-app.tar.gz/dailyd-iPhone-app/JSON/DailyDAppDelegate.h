//
//  DailyDAppDelegate.h
//  DailyD
//
//  Created by Vimal Shah on 2/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Globals.h"

@interface DailyDAppDelegate : NSObject <UIApplicationDelegate,UITabBarDelegate,CLLocationManagerDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
	UITabBarController *tabBarController;
	
	UIImageView *imgSplash;
	NSTimer *tmSplashDelay;
	UIActivityIndicatorView *progressInd;
    
	Reachability *remoteHost;
	int remoteHostStatus;
    
	CLLocationManager *locManager;
    
	// Settings
	NSDictionary *setDictionary;
	NSString *setAppAlertTitle;
	NSString *setNavBarColor;
	UIColor *clrNavBar;
	NSString *setTableViewBackColor;
	UIColor *clrTableViewBack;
	NSString *setCellColor;
	UIColor *clrCell;
	NSString *setSourceTextColor;
	UIColor *clrSourceText;
	NSString *setSplashDelay;
	NSString *setAPIUrl;
	NSString *setCategoriesURL;
	NSString *setLocationsURL;
	
	NSMutableArray *arrPreferredCategories;
	NSMutableArray *arrPreferredLocations;
	BOOL isFirstLaunch;
	
	// DB Variables
	NSString *databaseName;
	NSString *databasePath;
	
	// Global Variables
	BOOL isFromSettings1;
	BOOL isFromSettings2;
	BOOL isFromSettings3;
	int prevCatCount;
	int prevLocCount;
	int selectedTabIndex;
	BOOL flgFBLoginDialog;
    
	NSArray *arrDeals;
    
	NSMutableArray *arrCatSubDeals;
	NSMutableArray *arrLocSubDeals;
    NSMutableArray *arrSiteSubDeals;
	NSMutableArray *arrMutableDealsByCategoriesAllSections;
	NSMutableArray *arrMutableDealsByLocationsAllSections;
	NSArray *arrCatDeals;
	NSMutableArray *arrLocDeals;
	NSMutableArray *arrSiteDeals;
	NSMutableArray *arrMutableDealsByCategories;
    NSMutableArray *arrMutableDealsByAllCategories;
	NSMutableArray *arrMutableDealsByCategoriesSubLocations;
	NSMutableArray *arrMutableDealsByLocations;
	NSMutableArray *arrMutableDealsByAllLocations;
	NSMutableArray *arrMutableDealsByLocationsSubCategories;
	NSMutableArray *arrMutableDealsBySites;
	NSMutableArray *arrMutableDealsByAllSites;
	NSArray *arrCatgories;
	NSMutableArray *arrMutableCategories;
	NSArray *arrLocations;
	NSMutableArray *arrMutableLocations;
    NSMutableArray *arrLocationCategory;
	
    FirstSubListViewController *objFirstSubListViewController;
    SecondSubListViewController *objSecondSubListViewController;
    
	CatDealsViewController *objCatDealsViewController;
	LocDealsViewController *objLocDealsViewController;
	SiteDealsViewController *objSiteDealsViewController;
	
	DealDetailViewController *objDealDetailViewController;
	DealMapViewController *objDealMapViewController;
	SettingsViewController *objSettingsViewController;
	CategoriesViewController *objCategoriesViewController;
	LocationsViewController *objLocationsViewController;
//	LocCategoryViewController *objLocCategoryViewController;
    
    
    
    
}
@property int selectedTabIndex;
@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;
@property (nonatomic, retain) IBOutlet UITabBarController *tabBarController;

@property (nonatomic, retain, readonly) UIActivityIndicatorView *progressInd;

@property (nonatomic, retain) CLLocationManager *locManager;

// Settings
@property (nonatomic, retain) NSString *setAppAlertTitle;
@property (nonatomic, retain) NSString *setNavBarColor;
@property (nonatomic, retain) UIColor *clrNavBar;
@property (nonatomic, retain) NSString *setTableViewBackColor;
@property (nonatomic, retain) UIColor *clrTableViewBack;
@property (nonatomic, retain) NSString *setCellColor;
@property (nonatomic, retain) UIColor *clrCell;
@property (nonatomic, retain) NSString *setSourceTextColor;
@property (nonatomic, retain) UIColor *clrSourceText;
@property (nonatomic, retain) NSString *setSplashDelay;
@property (nonatomic, retain) NSString *setAPIUrl;
@property (nonatomic, retain) NSString *setCategoriesURL;
@property (nonatomic, retain) NSString *setLocationsURL;

@property (nonatomic, retain) NSMutableArray *arrPreferredCategories;
@property (nonatomic, retain) NSMutableArray *arrPreferredLocations;
@property BOOL isFirstLaunch;

// DB Variables
@property (nonatomic, retain) NSString *databaseName;
@property (nonatomic, retain) NSString *databasePath;

// Global Variables
@property BOOL isFromSettings1;
@property BOOL isFromSettings2;
@property BOOL isFromSettings3;
@property int prevCatCount;
@property int prevLocCount;
@property BOOL flgFBLoginDialog;

@property (nonatomic, retain) NSArray *arrDeals;

@property (nonatomic, retain) NSMutableArray *arrCatSubDeals;
@property (nonatomic, retain) NSMutableArray *arrLocSubDeals;
@property (nonatomic, retain) NSMutableArray *arrSiteSubDeals;
@property (nonatomic, retain) NSMutableArray *arrMutableDealsByCategoriesAllSections;
@property (nonatomic, retain) NSMutableArray *arrMutableDealsByLocationsAllSections;
@property (nonatomic, retain) NSArray *arrCatDeals;
@property (nonatomic, retain) NSMutableArray *arrLocDeals;
@property (nonatomic, retain) NSMutableArray *arrSiteDeals;
@property (nonatomic, retain) NSMutableArray *arrMutableDealsByCategories;
@property (nonatomic, retain) NSMutableArray *arrMutableDealsByAllCategories;
@property (nonatomic, retain) NSMutableArray *arrMutableDealsByCategoriesSubLocations;
@property (nonatomic, retain) NSMutableArray *arrMutableDealsByLocations;
@property (nonatomic, retain) NSMutableArray *arrMutableDealsByAllLocations;
@property (nonatomic, retain) NSMutableArray *arrMutableDealsByLocationsSubCategories;
@property (nonatomic, retain) NSMutableArray *arrMutableDealsBySites;
@property (nonatomic, retain) NSMutableArray *arrMutableDealsByAllSites;
@property (nonatomic, retain) NSArray *arrCatgories;
@property (nonatomic, retain) NSMutableArray *arrMutableCategories;
@property (nonatomic, retain) NSArray *arrLocations;
@property (nonatomic, retain) NSMutableArray *arrMutableLocations;
@property (nonatomic, retain) NSMutableArray *arrLocationCategory;

@property (nonatomic, retain) CatDealsViewController *objCatDealsViewController;
@property (nonatomic, retain) LocDealsViewController *objLocDealsViewController;
@property (nonatomic, retain) SiteDealsViewController *objSiteDealsViewController;

@property (nonatomic, retain) FirstSubListViewController *objFirstSubListViewController;
@property (nonatomic, retain) SecondSubListViewController *objSecondSubListViewController;

@property (nonatomic, retain) DealDetailViewController *objDealDetailViewController;
@property (nonatomic, retain) DealMapViewController *objDealMapViewController;
@property (nonatomic, retain) SettingsViewController *objSettingsViewController;
@property (nonatomic, retain) CategoriesViewController *objCategoriesViewController;
@property (nonatomic, retain) LocationsViewController *objLocationsViewController;
// @property (nonatomic, retain) LocCategoryViewController *objLocCategoryViewController;


- (NSString *)getCategories;
- (NSString *)getLocations;

- (void) copySettingsFile;
- (void) loadPrefereces;
- (void) loadSettings;
- (void) loadCategoryFile;
- (void) loadLocationFile;
- (void) updateCategoriesFile;
- (void) updateLocationsFile;

- (UIColor *) colorForHex:(NSString *)hexColor;
- (UIImage *)imageByScalingProportionallyToSize:(CGSize)targetSize srcImg:(UIImage *)image;
- (NSDate *) parseDateString:(NSString*) dateString withGMTString:(NSString*) GMTString;

- (void)arrDealsFromObjDictByCategories :(NSArray *)arrDict;
- (void)arrDealsFromObjDictByCategoriesWithSubLocations :(NSArray *)arrDict;
- (void)arrDealsFromObjDictByLocations :(NSArray *)arrDict;
- (void)arrDealsFromObjDictByLocationsWithSubCategories :(NSArray *)arrDict;
- (void)arrDealsFromObjDictBySites :(NSArray *)arrDict;

- (void)arrAllCatDealsFromObjDict :(NSArray *)arrDict;
- (void)arrAllLocDealsFromObjDict :(NSArray *)arrDict;
- (void)arrAllSiteDealsFromObjDict :(NSArray *)arrDict;

- (void)arrCategoriesFromObjDict :(NSArray *)arrDict;
- (void)arrLocationsFromObjDict :(NSArray *)arrDict;

- (void) arrLocsFromCategory :(NSMutableArray *) arrDealCats;
- (void) arrCatsFromLocation :(NSMutableArray *) arrDealLocs;

// Database Functions
-(void) dbconnect;
-(void) checkAndCreateDatabase;
-(sqlite3_stmt*) PrepareStatement:(const char *)sql;

-(void)firstCatSave :(Category *)aCat;
-(void)firstLocSave :(Location *)aLoc;
-(void)checkCategory :(Category *)aCat c:(int)cstatus;
-(void)checkLocation :(Location *)aLoc c:(int)cstatus;
-(BOOL)isAllCategoryUnchecked;
-(BOOL)isAllLocationUnchecked;
-(void)mapCategories;
-(void)mapLocations;
-(void)flushCategories;
-(void)flushLocations;
-(int)loadCategoryPrefFromDB :(int)catID;
-(int)loadLocationPrefFromDB :(int)locID;

// API Functions
- (NSString *)apiDeals:(int)page;
- (NSString *)apiDealsForSelectedCategory :(int)selectedCategoryID pageNo:(int)page;
- (NSString *)apiDealsForSelectedLocation :(int)selectedLocationID;

@end


