//
//  DailyDAppDelegate.m
//  DailyD
//
//  Created by Vimal Shah on 2/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DailyDAppDelegate.h"
#import "RootViewController.h"


@implementation DailyDAppDelegate

@synthesize window;
@synthesize navigationController;
@synthesize tabBarController;

@synthesize locManager;

@synthesize progressInd;

@synthesize setAppAlertTitle;
@synthesize setNavBarColor;
@synthesize clrNavBar;
@synthesize setTableViewBackColor;
@synthesize clrTableViewBack;
@synthesize setCellColor;
@synthesize clrCell;
@synthesize setSourceTextColor;
@synthesize clrSourceText;
@synthesize setSplashDelay;
@synthesize setAPIUrl;
@synthesize setCategoriesURL;
@synthesize setLocationsURL;

@synthesize arrPreferredCategories;
@synthesize arrPreferredLocations;
@synthesize isFirstLaunch;

@synthesize isFromSettings1;
@synthesize isFromSettings2;
@synthesize isFromSettings3;
@synthesize prevCatCount;
@synthesize prevLocCount;
@synthesize flgFBLoginDialog;

@synthesize arrDeals;

@synthesize arrCatSubDeals;
@synthesize arrLocSubDeals;
@synthesize arrMutableDealsByCategoriesAllSections;
@synthesize arrMutableDealsByLocationsAllSections;
@synthesize arrCatDeals;
@synthesize arrLocDeals;
@synthesize arrSiteDeals;
@synthesize arrMutableDealsByCategories;
@synthesize arrMutableDealsByAllCategories;
@synthesize arrMutableDealsByCategoriesSubLocations;
@synthesize arrMutableDealsByLocations;
@synthesize arrMutableDealsByAllLocations;
@synthesize arrMutableDealsByLocationsSubCategories;
@synthesize arrMutableDealsBySites;
@synthesize arrMutableDealsByAllSites;
@synthesize arrCatgories;
@synthesize arrMutableCategories;
@synthesize arrLocations;
@synthesize arrMutableLocations;
@synthesize arrLocationCategory;

@synthesize objCatDealsViewController;
@synthesize objLocDealsViewController;
@synthesize objSiteDealsViewController;

@synthesize objFirstSubListViewController;
@synthesize objSecondSubListViewController;

@synthesize objDealDetailViewController;
@synthesize objDealMapViewController;
@synthesize objSettingsViewController;
@synthesize objCategoriesViewController;
@synthesize objLocationsViewController;
//@synthesize objLocCategoryViewController;


@synthesize arrSiteSubDeals;
@synthesize databaseName;
@synthesize databasePath;
@synthesize selectedTabIndex;

#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
    // Override point for customization after application launch.
    self.arrMutableDealsByCategories = [[NSMutableArray alloc] init];
	self.arrMutableDealsByCategoriesAllSections = [[NSMutableArray alloc] init];
    self.arrMutableDealsByCategoriesSubLocations = [[NSMutableArray alloc] init];
    self.arrMutableDealsByLocations = [[NSMutableArray alloc] init];
	self.arrMutableDealsByLocationsAllSections = [[NSMutableArray alloc] init];
    
    
    
	[imgSplash setImage:[UIImage imageNamed:@"Default.png"]];
	[self.window addSubview:imgSplash];
	[self.window addSubview:self.progressInd];
	
	[self loadSettings];
    
	[self copySettingsFile];
    //	[self updateCategoriesFile];
    //	[self updateLocationsFile];
	[self dbconnect];
    
	[self loadCategoryFile];
	[self loadLocationFile];
    
	[self loadPrefereces];
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object: nil];
	
	remoteHost = [[Reachability reachabilityWithHostName:@"www.apple.com"] retain];
	[remoteHost startNotifier];
    // Add the navigation controller's view to the window and display.
	
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)addNavController {
	[progressInd removeFromSuperview];
	[imgSplash removeFromSuperview];
    //	[self.window addSubview:navigationController.view];
    [self.window addSubview:tabBarController.view];
}

- (void)updateNetwork:(Reachability*)curReach {
	
	NetworkStatus connection = [curReach currentReachabilityStatus];
	
	if(curReach == remoteHost){
		switch (connection)
		{
			case NotReachable:
			{
				remoteHostStatus = 0;
				break;
			}
			case ReachableViaWWAN:
			{
				remoteHostStatus = 1;
				break;
			}
			case ReachableViaWiFi:
			{
				remoteHostStatus = 2;
				break;
			}
		}
		
		if(remoteHostStatus != 0) {
            
            self.locManager = [[[CLLocationManager alloc] init] autorelease];
            self.locManager.delegate = self; // send loc updates to myself
            [self.locManager startUpdatingLocation];
            
			[self performSelectorOnMainThread:@selector(updateCategoriesFile) withObject:nil waitUntilDone:YES];
			[self performSelectorOnMainThread:@selector(updateLocationsFile) withObject:nil waitUntilDone:YES];
			tmSplashDelay = [NSTimer scheduledTimerWithTimeInterval:[self.setSplashDelay intValue] target:self selector:@selector(addNavController) userInfo:nil repeats:NO];
		} else {
			[progressInd removeFromSuperview];
			UIAlertView *alert = [[UIAlertView alloc]initWithTitle:self.setAppAlertTitle message:@"Internet Connection not available currently. Please check your internet connectivity and try again after sometime." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
			[alert show];
			[alert release];
		}
		NSLog(@"Connection 1 status : %d", remoteHostStatus);
	}
}


- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation {
    
    [self.locManager stopUpdatingHeading];
    
    NSLog(@"Location: %@", [newLocation description]);
    
}

- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error {
    
}

- (void) reachabilityChanged: (NSNotification* )note {
	
	Reachability* curReach = [note object];
	[self updateNetwork:curReach];
	
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
	//    NSLog(@"Selected tabbar - %d", self.tabBarController.selectedIndex);
	self.selectedTabIndex = self.tabBarController.selectedIndex;
}

- (void)copySettingsFile {
	
	NSFileManager *myManager = [NSFileManager defaultManager];
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
	
    NSString *insCatPath = @"categories.txt";
    NSString *srcCatPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:insCatPath];
    NSString *destCatPath = [documentsDirectory stringByAppendingPathComponent:insCatPath];
    NSError *err;
	if(![myManager fileExistsAtPath:destCatPath]) {
		
		[myManager copyItemAtPath:srcCatPath 
						   toPath:destCatPath 
							error:&err];
		
	}
    
	NSString *insLocPath = @"locations.txt";
    NSString *srcLocPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:insLocPath];
    NSString *destLocPath = [documentsDirectory stringByAppendingPathComponent:insLocPath];
    NSError *err1;
	if(![myManager fileExistsAtPath:destLocPath]){
		
		[myManager copyItemAtPath:srcLocPath 
						   toPath:destLocPath 
							error:&err1];
	}
	
}

- (void)loadPrefereces {
	NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
	self.isFirstLaunch = [prefs boolForKey:@"prefFirstTime"];
	self.arrPreferredCategories = [prefs valueForKey:@"prefPreferredCategories"];
	self.arrPreferredLocations = [prefs valueForKey:@"prefPreferredLocations"];
	if (!self.isFirstLaunch) {
		self.arrPreferredCategories = [[NSMutableArray alloc] init];
		for (int i=0; i<[self.arrMutableCategories count]; i++) {
			Category *aCat = [self.arrMutableCategories objectAtIndex:i];
			[aCat setPreferred:1];
			[self firstCatSave:aCat];
			[self.arrPreferredCategories addObject:@"1"];
		}
        
		self.arrPreferredLocations = [[NSMutableArray alloc] init];
		for (int i=0; i<[self.arrMutableLocations count]; i++) {
			Location *aLoc = [self.arrMutableLocations objectAtIndex:i];
			[aLoc setPreferred:1];
			[self firstLocSave:aLoc];
			[self.arrPreferredLocations addObject:@"1"];
		}
		
		self.isFirstLaunch = TRUE;
		[prefs setBool:self.isFirstLaunch forKey:@"prefFirstTime"];
		[prefs setValue:self.arrPreferredCategories forKey:@"prefPreferredCategories"];
		[prefs setValue:self.arrPreferredLocations forKey:@"prefPreferredLocations"];
		[prefs synchronize];
	}
}

- (void)loadSettings {
	NSString *path = [[NSBundle mainBundle] bundlePath];
	NSString *finalPath = [path stringByAppendingPathComponent:@"AppSettings.plist"];
    
    NSLog(@"Final Path ==>%@",finalPath);
	setDictionary = [[NSDictionary dictionaryWithContentsOfFile:finalPath] retain];
	self.setAppAlertTitle = [setDictionary valueForKey:@"AppAlertTitle"];
	self.setNavBarColor = [setDictionary valueForKey:@"NavBarColor"];
	self.clrNavBar = [self colorForHex:self.setNavBarColor];
	self.setTableViewBackColor = [setDictionary valueForKey:@"TableViewBackColor"];
	self.clrTableViewBack = [self colorForHex:self.setTableViewBackColor];
	self.setCellColor = [setDictionary valueForKey:@"CellColor"];
	self.clrCell = [self colorForHex:self.setCellColor];
	self.setSourceTextColor = [setDictionary valueForKey:@"SourceTextColor"];
	self.clrSourceText = [self colorForHex:self.setSourceTextColor];
	self.setSplashDelay = [setDictionary valueForKey:@"SplashDelay"];
	self.setAPIUrl = [setDictionary valueForKey:@"APIUrl"];
	self.setCategoriesURL = [setDictionary valueForKey:@"CategoriesURL"];
	self.setLocationsURL = [setDictionary valueForKey:@"LocationsURL"];
}

- (void) loadCategoryFile {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
	NSString   *path = [documentsDirectory stringByAppendingPathComponent:@"categories.txt"];
	NSError    *error1 = nil;
	NSString   *jsonString = [NSString stringWithContentsOfFile: path 
													   encoding: NSUTF8StringEncoding 
														  error: &error1];
	
	NSError *error;
	SBJSON *json = [[SBJSON new] autorelease];
	self.arrCatgories = [json objectWithString:jsonString error:&error];
	
	[self arrCategoriesFromObjDict:self.arrCatgories];
	
}

- (void) loadLocationFile {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
	NSString   *path = [documentsDirectory stringByAppendingPathComponent:@"locations.txt"];
	NSError    *error1 = nil;
	NSString   *jsonString = [NSString stringWithContentsOfFile: path 
													   encoding: NSUTF8StringEncoding 
														  error: &error1];
	
	NSError *error;
	SBJSON *json = [[SBJSON new] autorelease];
	self.arrLocations = [json objectWithString:jsonString error:&error];
	
	[self arrLocationsFromObjDict:self.arrLocations];
	
}

- (void) updateCategoriesFile {
	
	NSString *catFileData = [NSString stringWithContentsOfURL:[NSURL URLWithString:self.setCategoriesURL]];
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
	
	NSString   *path = [documentsDirectory stringByAppendingPathComponent:@"categories.txt"];
	
	[catFileData writeToFile:path 
                  atomically:NO 
                    encoding:NSStringEncodingConversionAllowLossy 
                       error:nil];
	
	self.prevCatCount = [self.arrMutableCategories count];
	[self loadCategoryFile];
	
	[self mapCategories];
	[self flushCategories];
	
	self.arrPreferredCategories = [[NSMutableArray alloc] init];
	for (int i=0; i<[self.arrMutableCategories count]; i++) {
		Category *aCat = [self.arrMutableCategories objectAtIndex:i];
		[self firstCatSave:aCat];
		if (aCat.preferred == 1)
			[self.arrPreferredCategories addObject:@"1"];
		else
			[self.arrPreferredCategories addObject:@"0"];
	}
	
}

- (void) updateLocationsFile {
	
	NSString *locFileData = [NSString stringWithContentsOfURL:[NSURL URLWithString:self.setLocationsURL]];
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
	
	NSString   *path = [documentsDirectory stringByAppendingPathComponent:@"locations.txt"];
	
	[locFileData writeToFile:path 
				  atomically:NO 
					encoding:NSStringEncodingConversionAllowLossy 
					   error:nil];
    
	self.prevLocCount = [self.arrMutableLocations count];
	[self loadLocationFile];
	
	[self mapLocations];
	[self flushLocations];
	
	self.arrPreferredLocations = [[NSMutableArray alloc] init];
	for (int i=0; i<[self.arrMutableLocations count]; i++) {
		Location *aLoc = [self.arrMutableLocations objectAtIndex:i];
		[self firstLocSave:aLoc];
		if (aLoc.preferred == 1)
			[self.arrPreferredLocations addObject:@"1"];
		else
			[self.arrPreferredLocations addObject:@"0"];
	}
	
}

- (UIColor *) colorForHex:(NSString *)hexColor {
	hexColor = [[hexColor stringByTrimmingCharactersInSet:
				 [NSCharacterSet whitespaceAndNewlineCharacterSet]
				 ] uppercaseString];
	
	// String should be 6 or 7 characters if it includes '#'
	if ([hexColor length] < 6) 
		return [UIColor blackColor];
	
	// strip # if it appears  
	if ([hexColor hasPrefix:@"#"]) 
		hexColor = [hexColor substringFromIndex:1];
	
	// if the value isn't 6 characters at this point return 
	// the color black
	if ([hexColor length] != 6) 
		return [UIColor blackColor];
	
	// Separate into r, g, b substrings
	NSRange range;
	range.location = 0;
	range.length = 2; 
	
	NSString *rString = [hexColor substringWithRange:range]; 
	
	range.location = 2;
	NSString *gString = [hexColor substringWithRange:range];
	
	range.location = 4;
	NSString *bString = [hexColor substringWithRange:range];
	
	// Scan values  
	unsigned int r, g, b;
	[[NSScanner scannerWithString:rString] scanHexInt:&r];
	[[NSScanner scannerWithString:gString] scanHexInt:&g];
	[[NSScanner scannerWithString:bString] scanHexInt:&b];
	
	return [UIColor colorWithRed:((float) r / 255.0f)
						   green:((float) g / 255.0f)
							blue:((float) b / 255.0f)
						   alpha:1.0f];
	
}

- (UIImage *)imageByScalingProportionallyToSize:(CGSize)targetSize srcImg:(UIImage *)image{
	
	UIImage *sourceImage = image;
	UIImage *newImage = nil;
	
	CGSize imageSize = sourceImage.size;
	CGFloat width = imageSize.width;
	CGFloat height = imageSize.height;
	
	CGFloat targetWidth = targetSize.width;
	CGFloat targetHeight = targetSize.height;
	
	CGFloat scaleFactor = 0.0;
	CGFloat scaledWidth = targetWidth;
	CGFloat scaledHeight = targetHeight;
	
	CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
	
	if (CGSizeEqualToSize(imageSize, targetSize) == NO) {
		
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
		
        if (widthFactor < heightFactor) 
			scaleFactor = widthFactor;
        else
			scaleFactor = heightFactor;
		
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
		
        // center the image
		
        if (widthFactor < heightFactor) {
			thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5; 
        } else if (widthFactor > heightFactor) {
			thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
	}
	
	
	// this is actually the interesting part:
	
	UIGraphicsBeginImageContext(targetSize);
	
	CGRect thumbnailRect = CGRectZero;
	thumbnailRect.origin = thumbnailPoint;
	thumbnailRect.size.width  = scaledWidth;
	thumbnailRect.size.height = scaledHeight;
	
	[sourceImage drawInRect:thumbnailRect];
	
	newImage = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	if(newImage == nil) NSLog(@"could not scale image");
	
	return newImage ;
}

- (UIActivityIndicatorView *)progressInd
{
	//    if (progressInd == nil)
	//    {
	CGRect frame = CGRectMake((self.window.frame.size.width/2)-18, (self.window.frame.size.height/2)-40, 30, 30);
	progressInd = [[UIActivityIndicatorView alloc] initWithFrame:frame];
	[progressInd startAnimating];
	progressInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
	[progressInd sizeToFit];
	progressInd.autoresizingMask = (UIViewAutoresizingFlexibleLeftMargin |
									UIViewAutoresizingFlexibleRightMargin |
									UIViewAutoresizingFlexibleTopMargin |
									UIViewAutoresizingFlexibleBottomMargin);
	
	//        progressInd.tag = kViewTag; // tag this view for later so we can remove it from recycled table cells
	//    }
    return progressInd;
}

-(NSDate *) parseDateString:(NSString*) dateString withGMTString:(NSString*) GMTString {
	
    NSInteger hoursFromGMT      = [GMTString intValue]; 
    NSInteger secondsFromGMT    = (hoursFromGMT * 60 * 60);
	
    NSTimeZone *timeZone = [NSTimeZone timeZoneForSecondsFromGMT:secondsFromGMT];
	
    NSDateFormatter *dateFormatterGMTAware = [[NSDateFormatter alloc] init];
    [dateFormatterGMTAware setTimeZone:timeZone];
    [dateFormatterGMTAware setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSDate *date = [dateFormatterGMTAware dateFromString:dateString];
	[dateFormatterGMTAware release];
	
    //	NSLog(@"%@ in Local GMT\n\n", date);
	return date;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}


- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}

- (void)arrDealsFromObjDictByCategories :(NSArray *)arrDict {
	
    
	NSMutableArray *valueIndex = [[NSMutableArray alloc] init];
	NSMutableDictionary *parti;
	//NSLog(@"Arr Dict : %@",arrDict);
	for (int i=0; i<[arrDict count]; i++) {
		Deal *aDeal = [[Deal alloc] init];
		[aDeal setTitle:[[arrDict objectAtIndex:i] valueForKey:@"title"]];
		[aDeal setAddress:[[arrDict objectAtIndex:i] valueForKey:@"address"]];
		[aDeal setEnds_at:[[arrDict objectAtIndex:i] valueForKey:@"ends_at"]];
		
        //		NSLog(@"%@ in Original GMT\n\n", aDeal.ends_at);
        
		NSDate *dateInLocalGMT = [self parseDateString:[aDeal.ends_at substringToIndex:19] withGMTString:[aDeal.ends_at substringFromIndex:20]];
		[aDeal setDt_ends_at:dateInLocalGMT];
		[aDeal setPrice:[[[arrDict objectAtIndex:i] valueForKey:@"price"] intValue]];
		[aDeal setImage_url:[[arrDict objectAtIndex:i] valueForKey:@"image_url"]];
		[aDeal setValue:[[[arrDict objectAtIndex:i] valueForKey:@"value"] intValue]];
		[aDeal setSave:[[[arrDict objectAtIndex:i] valueForKey:@"save"] intValue]];
		[aDeal setDescription:[[arrDict objectAtIndex:i] valueForKey:@"description"]];
		[aDeal setDeal_url:[[arrDict objectAtIndex:i] valueForKey:@"deal_url"]];
		[aDeal setSource:[[arrDict objectAtIndex:i] valueForKey:@"source"]];
		
		NSArray *arrCat = [[arrDict objectAtIndex:i] valueForKey:@"categories"];
		Category *aCategory = [[Category alloc] init];
		aCategory.id = [[[arrCat objectAtIndex:0] valueForKey:@"id"] intValue];
		aCategory.name = [[arrCat objectAtIndex:0] valueForKey:@"name"];
		arrCat = [NSArray arrayWithObjects:aCategory, nil];
		[aDeal setCategories:arrCat];
		
		NSArray *arrLoc = [[arrDict objectAtIndex:i] valueForKey:@"locations"];
		Location *aLocation = [[Location alloc] init];
		aLocation.id = [[[arrLoc objectAtIndex:0] valueForKey:@"id"] intValue];
		aLocation.name = [[arrLoc objectAtIndex:0] valueForKey:@"name"];
		arrLoc = [NSArray arrayWithObjects:aLocation, nil];
		[aDeal setLocations:arrLoc];
		
        // ****** 0601
        if (![[[arrDict objectAtIndex:i] valueForKey:@"lat"] isEqualToString:@"0"]) {
            NSArray *arrLat = [[arrDict objectAtIndex:i] valueForKey:@"lat"];
            [aDeal setLat:arrLat];
        }
        if (![[[arrDict objectAtIndex:i] valueForKey:@"lon"] isEqualToString:@"0"]) {
            NSArray *arrLon = [[arrDict objectAtIndex:i] valueForKey:@"lon"];
            [aDeal setLon:arrLon];
        }
        //		NSLog(@"lat %@",[[arrDict objectAtIndex:i] valueForKey:@"lat"]);
        // ****** 0601
		
        
        int exsistingIndex = -1;
		for (int i=0; i<[self.arrMutableDealsByCategories count]; i++) {
			NSMutableDictionary * part = [self.arrMutableDealsByCategories objectAtIndex:i];
			NSString *header = [part valueForKey:@"header"];
			if ([header isEqualToString:aCategory.name]) {
				exsistingIndex = i;
			}
		}
		if (exsistingIndex >= 0) {
			NSMutableDictionary * part = [self.arrMutableDealsByCategories objectAtIndex:exsistingIndex];
			NSMutableArray *arrDealSection = [part valueForKey:@"value"];
			[arrDealSection addObject:aDeal];
		} else {
			parti = [[NSMutableDictionary alloc] init];
			[parti setValue:aCategory.name forKey:@"header"];
			
			valueIndex = [[NSMutableArray alloc] init];
			[parti setValue:valueIndex forKey:@"value"];
			
			[valueIndex addObject:aDeal];
			[self.arrMutableDealsByCategories addObject:parti];
		}
        
		[self.arrMutableDealsByCategoriesAllSections addObject:aDeal];
        //		[self.arrMutableDeals addObject:aDeal];
		[aDeal release];
		aDeal = nil;
	}
}

- (void)arrDealsFromObjDictByCategoriesWithSubLocations :(NSArray *)arrDict {
	
    
	NSMutableArray *valueIndex = [[NSMutableArray alloc] init];
	NSMutableDictionary *parti;
	
	for (int i=0; i<[arrDict count]; i++) {
		Deal *aDeal = [[Deal alloc] init];
		[aDeal setTitle:[[arrDict objectAtIndex:i] valueForKey:@"title"]];
		[aDeal setAddress:[[arrDict objectAtIndex:i] valueForKey:@"address"]];
		[aDeal setEnds_at:[[arrDict objectAtIndex:i] valueForKey:@"ends_at"]];
		
		//		NSLog(@"%@ in Original GMT\n\n", aDeal.ends_at);
		
		NSDate *dateInLocalGMT = [self parseDateString:[aDeal.ends_at substringToIndex:19] withGMTString:[aDeal.ends_at substringFromIndex:20]];
		[aDeal setDt_ends_at:dateInLocalGMT];
		[aDeal setPrice:[[[arrDict objectAtIndex:i] valueForKey:@"price"] intValue]];
		[aDeal setImage_url:[[arrDict objectAtIndex:i] valueForKey:@"image_url"]];
		//[aDeal setValue:[[[arrDict objectAtIndex:i] valueForKey:@"value"] intValue]];
		[aDeal setSave:[[[arrDict objectAtIndex:i] valueForKey:@"save"] intValue]];
		[aDeal setDescription:[[arrDict objectAtIndex:i] valueForKey:@"description"]];
		[aDeal setDeal_url:[[arrDict objectAtIndex:i] valueForKey:@"deal_url"]];
		[aDeal setSource:[[arrDict objectAtIndex:i] valueForKey:@"source"]];
		
		NSArray *arrCat = [[arrDict objectAtIndex:i] valueForKey:@"categories"];
		Category *aCategory = [[Category alloc] init];
		aCategory.id = [[[arrCat objectAtIndex:0] valueForKey:@"id"] intValue];
		aCategory.name = [[arrCat objectAtIndex:0] valueForKey:@"name"];
		arrCat = [NSArray arrayWithObjects:aCategory, nil];
		[aDeal setCategories:arrCat];
		
		NSArray *arrLoc = [[arrDict objectAtIndex:i] valueForKey:@"locations"];
		Location *aLocation = [[Location alloc] init];
		aLocation.id = [[[arrLoc objectAtIndex:0] valueForKey:@"id"] intValue];
		aLocation.name = [[arrLoc objectAtIndex:0] valueForKey:@"name"];
		arrLoc = [NSArray arrayWithObjects:aLocation, nil];
		[aDeal setLocations:arrLoc];
		
		//		NSLog(@"cname %@",aCategory.name);
		int exsistingIndex = -1;
		for (int i=0; i<[self.arrMutableDealsByCategoriesSubLocations count]; i++) {
			NSMutableDictionary * part = [self.arrMutableDealsByCategoriesSubLocations objectAtIndex:i];
			NSString *header = [part valueForKey:@"header"];
			if ([header isEqualToString:aLocation.name]) {
				exsistingIndex = i;
			}
		}
		if (exsistingIndex >= 0) {
			NSMutableDictionary * part = [self.arrMutableDealsByCategoriesSubLocations objectAtIndex:exsistingIndex];
			NSMutableArray *arrDealSection = [part valueForKey:@"value"];
			[arrDealSection addObject:aDeal];
		} else {
			parti = [[NSMutableDictionary alloc] init];
			[parti setValue:aLocation.name forKey:@"header"];
			
			valueIndex = [[NSMutableArray alloc] init];
			[parti setValue:valueIndex forKey:@"value"];
			
			[valueIndex addObject:aDeal];
			[self.arrMutableDealsByCategoriesSubLocations addObject:parti];
		}
		
		
		//		[self.arrMutableDeals addObject:aDeal];
		[aDeal release];
		aDeal = nil;
	}	
}

- (void)arrDealsFromObjDictByLocations :(NSArray *)arrDict {
	
	NSMutableArray *valueIndex = [[NSMutableArray alloc] init];
	NSMutableDictionary *parti;
	
	for (int i=0; i<[arrDict count]; i++) {
		Deal *aDeal = [[Deal alloc] init];
		[aDeal setTitle:[[arrDict objectAtIndex:i] valueForKey:@"title"]];
		[aDeal setAddress:[[arrDict objectAtIndex:i] valueForKey:@"address"]];
		[aDeal setEnds_at:[[arrDict objectAtIndex:i] valueForKey:@"ends_at"]];
		
		//		NSLog(@"%@ in Original GMT\n\n", aDeal.ends_at);
		
		NSDate *dateInLocalGMT = [self parseDateString:[aDeal.ends_at substringToIndex:19] withGMTString:[aDeal.ends_at substringFromIndex:20]];
		[aDeal setDt_ends_at:dateInLocalGMT];
		[aDeal setPrice:[[[arrDict objectAtIndex:i] valueForKey:@"price"] intValue]];
		[aDeal setImage_url:[[arrDict objectAtIndex:i] valueForKey:@"image_url"]];
		[aDeal setValue:[[[arrDict objectAtIndex:i] valueForKey:@"value"] intValue]];
		[aDeal setSave:[[[arrDict objectAtIndex:i] valueForKey:@"save"] intValue]];
		[aDeal setDescription:[[arrDict objectAtIndex:i] valueForKey:@"description"]];
		[aDeal setDeal_url:[[arrDict objectAtIndex:i] valueForKey:@"deal_url"]];
		[aDeal setSource:[[arrDict objectAtIndex:i] valueForKey:@"source"]];
		
		NSArray *arrCat = [[arrDict objectAtIndex:i] valueForKey:@"categories"];
		Category *aCategory = [[Category alloc] init];
		aCategory.id = [[[arrCat objectAtIndex:0] valueForKey:@"id"] intValue];
		aCategory.name = [[arrCat objectAtIndex:0] valueForKey:@"name"];
		arrCat = [NSArray arrayWithObjects:aCategory, nil];
		[aDeal setCategories:arrCat];
		
		NSArray *arrLoc = [[arrDict objectAtIndex:i] valueForKey:@"locations"];
		Location *aLocation = [[Location alloc] init];
		aLocation.id = [[[arrLoc objectAtIndex:0] valueForKey:@"id"] intValue];
		aLocation.name = [[arrLoc objectAtIndex:0] valueForKey:@"name"];
		arrLoc = [NSArray arrayWithObjects:aLocation, nil];
		[aDeal setLocations:arrLoc];
		
		//		NSLog(@"cname %@",aCategory.name);
		int exsistingIndex = -1;
		for (int i=0; i<[self.arrMutableDealsByLocations count]; i++) {
			NSMutableDictionary * part = [self.arrMutableDealsByLocations objectAtIndex:i];
			NSString *header = [part valueForKey:@"header"];
			if ([header isEqualToString:aLocation.name]) {
				exsistingIndex = i;
			}
		}
		if (exsistingIndex >= 0) {
			NSMutableDictionary * part = [self.arrMutableDealsByLocations objectAtIndex:exsistingIndex];
			NSMutableArray *arrDealSection = [part valueForKey:@"value"];
			[arrDealSection addObject:aDeal];
		} else {
			parti = [[NSMutableDictionary alloc] init];
			[parti setValue:aLocation.name forKey:@"header"];
			
			valueIndex = [[NSMutableArray alloc] init];
			[parti setValue:valueIndex forKey:@"value"];
			
			[valueIndex addObject:aDeal];
			[self.arrMutableDealsByLocations addObject:parti];
		}
		
		
        [self.arrMutableDealsByLocationsAllSections addObject:aDeal];
		//		[self.arrMutableDeals addObject:aDeal];
		[aDeal release];
		aDeal = nil;
	}	
}

- (void)arrDealsFromObjDictByLocationsWithSubCategories :(NSArray *)arrDict {
	self.arrMutableDealsByLocationsSubCategories = [[NSMutableArray alloc] init];
	
	NSMutableArray *valueIndex = [[NSMutableArray alloc] init];
	NSMutableDictionary *parti;
	
	for (int i=0; i<[arrDict count]; i++) {
		Deal *aDeal = [[Deal alloc] init];
		[aDeal setTitle:[[arrDict objectAtIndex:i] valueForKey:@"title"]];
		[aDeal setAddress:[[arrDict objectAtIndex:i] valueForKey:@"address"]];
		[aDeal setEnds_at:[[arrDict objectAtIndex:i] valueForKey:@"ends_at"]];
		
        //		NSLog(@"%@ in Original GMT\n\n", aDeal.ends_at);
        
		NSDate *dateInLocalGMT = [self parseDateString:[aDeal.ends_at substringToIndex:19] withGMTString:[aDeal.ends_at substringFromIndex:20]];
		[aDeal setDt_ends_at:dateInLocalGMT];
		[aDeal setPrice:[[[arrDict objectAtIndex:i] valueForKey:@"price"] intValue]];
		[aDeal setImage_url:[[arrDict objectAtIndex:i] valueForKey:@"image_url"]];
		[aDeal setValue:[[[arrDict objectAtIndex:i] valueForKey:@"value"] intValue]];
		[aDeal setSave:[[[arrDict objectAtIndex:i] valueForKey:@"save"] intValue]];
		[aDeal setDescription:[[arrDict objectAtIndex:i] valueForKey:@"description"]];
		[aDeal setDeal_url:[[arrDict objectAtIndex:i] valueForKey:@"deal_url"]];
		[aDeal setSource:[[arrDict objectAtIndex:i] valueForKey:@"source"]];
		
		NSArray *arrCat = [[arrDict objectAtIndex:i] valueForKey:@"categories"];
		Category *aCategory = [[Category alloc] init];
		aCategory.id = [[[arrCat objectAtIndex:0] valueForKey:@"id"] intValue];
		aCategory.name = [[arrCat objectAtIndex:0] valueForKey:@"name"];
		arrCat = [NSArray arrayWithObjects:aCategory, nil];
		[aDeal setCategories:arrCat];
		
		NSArray *arrLoc = [[arrDict objectAtIndex:i] valueForKey:@"locations"];
		Location *aLocation = [[Location alloc] init];
		aLocation.id = [[[arrLoc objectAtIndex:0] valueForKey:@"id"] intValue];
		aLocation.name = [[arrLoc objectAtIndex:0] valueForKey:@"name"];
		arrLoc = [NSArray arrayWithObjects:aLocation, nil];
		[aDeal setLocations:arrLoc];
		
        //		NSLog(@"cname %@",aCategory.name);
		int exsistingIndex = -1;
		for (int i=0; i<[self.arrMutableDealsByLocationsSubCategories count]; i++) {
			NSMutableDictionary * part = [self.arrMutableDealsByLocationsSubCategories objectAtIndex:i];
			NSString *header = [part valueForKey:@"header"];
			if ([header isEqualToString:aCategory.name]) {
				exsistingIndex = i;
			}
		}
		if (exsistingIndex >= 0) {
			NSMutableDictionary * part = [self.arrMutableDealsByLocationsSubCategories objectAtIndex:exsistingIndex];
			NSMutableArray *arrDealSection = [part valueForKey:@"value"];
			[arrDealSection addObject:aDeal];
		} else {
			parti = [[NSMutableDictionary alloc] init];
			[parti setValue:aCategory.name forKey:@"header"];
			
			valueIndex = [[NSMutableArray alloc] init];
			[parti setValue:valueIndex forKey:@"value"];
			
			[valueIndex addObject:aDeal];
			[self.arrMutableDealsByLocationsSubCategories addObject:parti];
		}
        
		
        //		[self.arrMutableDeals addObject:aDeal];
		[aDeal release];
		aDeal = nil;
	}
    
}

- (void)arrDealsFromObjDictBySites :(NSArray *)arrDict {
	self.arrMutableDealsBySites = [[NSMutableArray alloc] init];
	
	NSMutableArray *valueIndex = [[NSMutableArray alloc] init];
	NSMutableDictionary *parti;
	
	for (int i=0; i<[arrDict count]; i++) {
		Deal *aDeal = [[Deal alloc] init];
		[aDeal setTitle:[[arrDict objectAtIndex:i] valueForKey:@"title"]];
		[aDeal setAddress:[[arrDict objectAtIndex:i] valueForKey:@"address"]];
		[aDeal setEnds_at:[[arrDict objectAtIndex:i] valueForKey:@"ends_at"]];
		
		//		NSLog(@"%@ in Original GMT\n\n", aDeal.ends_at);
		
		NSDate *dateInLocalGMT = [self parseDateString:[aDeal.ends_at substringToIndex:19] withGMTString:[aDeal.ends_at substringFromIndex:20]];
		[aDeal setDt_ends_at:dateInLocalGMT];
		[aDeal setPrice:[[[arrDict objectAtIndex:i] valueForKey:@"price"] intValue]];
		[aDeal setImage_url:[[arrDict objectAtIndex:i] valueForKey:@"image_url"]];
		[aDeal setValue:[[[arrDict objectAtIndex:i] valueForKey:@"value"] intValue]];
		[aDeal setSave:[[[arrDict objectAtIndex:i] valueForKey:@"save"] intValue]];
		[aDeal setDescription:[[arrDict objectAtIndex:i] valueForKey:@"description"]];
		[aDeal setDeal_url:[[arrDict objectAtIndex:i] valueForKey:@"deal_url"]];
		[aDeal setSource:[[arrDict objectAtIndex:i] valueForKey:@"source"]];
		
		NSArray *arrCat = [[arrDict objectAtIndex:i] valueForKey:@"categories"];
		Category *aCategory = [[Category alloc] init];
		aCategory.id = [[[arrCat objectAtIndex:0] valueForKey:@"id"] intValue];
		aCategory.name = [[arrCat objectAtIndex:0] valueForKey:@"name"];
		arrCat = [NSArray arrayWithObjects:aCategory, nil];
		[aDeal setCategories:arrCat];
		
		NSArray *arrLoc = [[arrDict objectAtIndex:i] valueForKey:@"locations"];
		Location *aLocation = [[Location alloc] init];
		aLocation.id = [[[arrLoc objectAtIndex:0] valueForKey:@"id"] intValue];
		aLocation.name = [[arrLoc objectAtIndex:0] valueForKey:@"name"];
		arrLoc = [NSArray arrayWithObjects:aLocation, nil];
		[aDeal setLocations:arrLoc];
		
		//		NSLog(@"cname %@",aCategory.name);
		int exsistingIndex = -1;
		for (int i=0; i<[self.arrMutableDealsBySites count]; i++) {
			NSMutableDictionary * part = [self.arrMutableDealsBySites objectAtIndex:i];
			NSString *header = [part valueForKey:@"header"];
			if ([header isEqualToString:aDeal.source]) {
				exsistingIndex = i;
			}
		}
		if (exsistingIndex >= 0) {
			NSMutableDictionary * part = [self.arrMutableDealsBySites objectAtIndex:exsistingIndex];
			NSMutableArray *arrDealSection = [part valueForKey:@"value"];
			[arrDealSection addObject:aDeal];
		} else {
			parti = [[NSMutableDictionary alloc] init];
			[parti setValue:aDeal.source forKey:@"header"];
			
			valueIndex = [[NSMutableArray alloc] init];
			[parti setValue:valueIndex forKey:@"value"];
			
			[valueIndex addObject:aDeal];
			[self.arrMutableDealsBySites addObject:parti];
		}
		
		
		//		[self.arrMutableDeals addObject:aDeal];
		[aDeal release];
		aDeal = nil;
	}	
}

- (void)arrAllCatDealsFromObjDict :(NSArray *)arrDict {
	self.arrMutableDealsByAllCategories = [[NSMutableArray alloc] init];
	
	for (int i=0; i<[arrDict count]; i++) {
		Deal *aDeal = [[Deal alloc] init];
		[aDeal setTitle:[[arrDict objectAtIndex:i] valueForKey:@"title"]];
		[aDeal setAddress:[[arrDict objectAtIndex:i] valueForKey:@"address"]];
		[aDeal setEnds_at:[[arrDict objectAtIndex:i] valueForKey:@"ends_at"]];
		
		//		NSLog(@"%@ in Original GMT\n\n", aDeal.ends_at);
		
		NSDate *dateInLocalGMT = [self parseDateString:[aDeal.ends_at substringToIndex:19] withGMTString:[aDeal.ends_at substringFromIndex:20]];
		[aDeal setDt_ends_at:dateInLocalGMT];
		[aDeal setPrice:[[[arrDict objectAtIndex:i] valueForKey:@"price"] intValue]];
		[aDeal setImage_url:[[arrDict objectAtIndex:i] valueForKey:@"image_url"]];
		[aDeal setValue:[[[arrDict objectAtIndex:i] valueForKey:@"value"] intValue]];
		[aDeal setSave:[[[arrDict objectAtIndex:i] valueForKey:@"save"] intValue]];
		[aDeal setDescription:[[arrDict objectAtIndex:i] valueForKey:@"description"]];
		[aDeal setDeal_url:[[arrDict objectAtIndex:i] valueForKey:@"deal_url"]];
		[aDeal setSource:[[arrDict objectAtIndex:i] valueForKey:@"source"]];
		
		NSArray *arrCat = [[arrDict objectAtIndex:i] valueForKey:@"locations"];
		Category *aCategory = [[Category alloc] init];
		aCategory.id = [[[arrCat objectAtIndex:0] valueForKey:@"id"] intValue];
		aCategory.name = [[arrCat objectAtIndex:0] valueForKey:@"name"];
		arrCat = [NSArray arrayWithObjects:aCategory, nil];
		[aDeal setCategories:arrCat];
		
		NSArray *arrLoc = [[arrDict objectAtIndex:i] valueForKey:@"categories"];
		Location *aLocation = [[Location alloc] init];
		aLocation.id = [[[arrLoc objectAtIndex:0] valueForKey:@"id"] intValue];
		aLocation.name = [[arrLoc objectAtIndex:0] valueForKey:@"name"];
		arrLoc = [NSArray arrayWithObjects:aLocation, nil];
		[aDeal setLocations:arrLoc];
		
		[self.arrMutableDealsByAllCategories addObject:aDeal];
		[aDeal release];
		aDeal = nil;
	}
}

- (void)arrAllLocDealsFromObjDict :(NSArray *)arrDict {
	self.arrMutableDealsByAllLocations = [[NSMutableArray alloc] init];
	
	for (int i=0; i<[arrDict count]; i++) {
		Deal *aDeal = [[Deal alloc] init];
		[aDeal setTitle:[[arrDict objectAtIndex:i] valueForKey:@"title"]];
		[aDeal setAddress:[[arrDict objectAtIndex:i] valueForKey:@"address"]];
		[aDeal setEnds_at:[[arrDict objectAtIndex:i] valueForKey:@"ends_at"]];
		
		//		NSLog(@"%@ in Original GMT\n\n", aDeal.ends_at);
		
		NSDate *dateInLocalGMT = [self parseDateString:[aDeal.ends_at substringToIndex:19] withGMTString:[aDeal.ends_at substringFromIndex:20]];
		[aDeal setDt_ends_at:dateInLocalGMT];
		[aDeal setPrice:[[[arrDict objectAtIndex:i] valueForKey:@"price"] intValue]];
		[aDeal setImage_url:[[arrDict objectAtIndex:i] valueForKey:@"image_url"]];
		[aDeal setValue:[[[arrDict objectAtIndex:i] valueForKey:@"value"] intValue]];
		[aDeal setSave:[[[arrDict objectAtIndex:i] valueForKey:@"save"] intValue]];
		[aDeal setDescription:[[arrDict objectAtIndex:i] valueForKey:@"description"]];
		[aDeal setDeal_url:[[arrDict objectAtIndex:i] valueForKey:@"deal_url"]];
		[aDeal setSource:[[arrDict objectAtIndex:i] valueForKey:@"source"]];
		
		NSArray *arrCat = [[arrDict objectAtIndex:i] valueForKey:@"locations"];
		Category *aCategory = [[Category alloc] init];
		aCategory.id = [[[arrCat objectAtIndex:0] valueForKey:@"id"] intValue];
		aCategory.name = [[arrCat objectAtIndex:0] valueForKey:@"name"];
		arrCat = [NSArray arrayWithObjects:aCategory, nil];
		[aDeal setCategories:arrCat];
		
		NSArray *arrLoc = [[arrDict objectAtIndex:i] valueForKey:@"categories"];
		Location *aLocation = [[Location alloc] init];
		aLocation.id = [[[arrLoc objectAtIndex:0] valueForKey:@"id"] intValue];
		aLocation.name = [[arrLoc objectAtIndex:0] valueForKey:@"name"];
		arrLoc = [NSArray arrayWithObjects:aLocation, nil];
		[aDeal setLocations:arrLoc];
		
		[self.arrMutableDealsByAllLocations addObject:aDeal];
		[aDeal release];
		aDeal = nil;
	}
}

- (void)arrAllSiteDealsFromObjDict :(NSArray *)arrDict {
	self.arrMutableDealsByAllSites = [[NSMutableArray alloc] init];
	
	for (int i=0; i<[arrDict count]; i++) {
		Deal *aDeal = [[Deal alloc] init];
		[aDeal setTitle:[[arrDict objectAtIndex:i] valueForKey:@"title"]];
		[aDeal setAddress:[[arrDict objectAtIndex:i] valueForKey:@"address"]];
		[aDeal setEnds_at:[[arrDict objectAtIndex:i] valueForKey:@"ends_at"]];
		
		//		NSLog(@"%@ in Original GMT\n\n", aDeal.ends_at);
		
		NSDate *dateInLocalGMT = [self parseDateString:[aDeal.ends_at substringToIndex:19] withGMTString:[aDeal.ends_at substringFromIndex:20]];
		[aDeal setDt_ends_at:dateInLocalGMT];
		[aDeal setPrice:[[[arrDict objectAtIndex:i] valueForKey:@"price"] intValue]];
		[aDeal setImage_url:[[arrDict objectAtIndex:i] valueForKey:@"image_url"]];
		[aDeal setValue:[[[arrDict objectAtIndex:i] valueForKey:@"value"] intValue]];
		[aDeal setSave:[[[arrDict objectAtIndex:i] valueForKey:@"save"] intValue]];
		[aDeal setDescription:[[arrDict objectAtIndex:i] valueForKey:@"description"]];
		[aDeal setDeal_url:[[arrDict objectAtIndex:i] valueForKey:@"deal_url"]];
		[aDeal setSource:[[arrDict objectAtIndex:i] valueForKey:@"source"]];
		
		NSArray *arrCat = [[arrDict objectAtIndex:i] valueForKey:@"locations"];
		Category *aCategory = [[Category alloc] init];
		aCategory.id = [[[arrCat objectAtIndex:0] valueForKey:@"id"] intValue];
		aCategory.name = [[arrCat objectAtIndex:0] valueForKey:@"name"];
		arrCat = [NSArray arrayWithObjects:aCategory, nil];
		[aDeal setCategories:arrCat];
		
		NSArray *arrLoc = [[arrDict objectAtIndex:i] valueForKey:@"categories"];
		Location *aLocation = [[Location alloc] init];
		aLocation.id = [[[arrLoc objectAtIndex:0] valueForKey:@"id"] intValue];
		aLocation.name = [[arrLoc objectAtIndex:0] valueForKey:@"name"];
		arrLoc = [NSArray arrayWithObjects:aLocation, nil];
		[aDeal setLocations:arrLoc];
		
		[self.arrMutableDealsByAllSites addObject:aDeal];
		[aDeal release];
		aDeal = nil;
	}
}

- (void) arrLocsFromCategory :(NSMutableArray *) arrDealCats {
    
    self.arrMutableDealsByCategoriesSubLocations = [[NSMutableArray alloc] init];
    self.arrCatSubDeals = [[NSMutableArray alloc] init];
    
    NSMutableArray *valueIndex = [[NSMutableArray alloc] init];
	NSMutableDictionary *parti;
    
    for (int i=0; i<[arrDealCats count]; i++) {
        Deal *aDeal = [arrDealCats objectAtIndex:i];
        Location *aLocation = [aDeal.locations objectAtIndex:0];
        
        int exsistingIndex = -1;
		for (int i=0; i<[self.arrMutableDealsByCategoriesSubLocations count]; i++) {
            
            
			NSMutableDictionary * part = [self.arrMutableDealsByCategoriesSubLocations objectAtIndex:i];
			NSString *header = [part valueForKey:@"header"];
			if ([header isEqualToString:aLocation.name]) {
				exsistingIndex = i;
			}
		}
        
        if (exsistingIndex >= 0) {
			NSMutableDictionary * part = [self.arrMutableDealsByCategoriesSubLocations objectAtIndex:exsistingIndex];
			NSMutableArray *arrDealSection = [part valueForKey:@"value"];
			[arrDealSection addObject:aDeal];
		} else {
			parti = [[NSMutableDictionary alloc] init];
			[parti setValue:aLocation.name forKey:@"header"];
			
			valueIndex = [[NSMutableArray alloc] init];
			[parti setValue:valueIndex forKey:@"value"];
			
			[valueIndex addObject:aDeal];
			[self.arrMutableDealsByCategoriesSubLocations addObject:parti];
		}
        
        [self.arrCatSubDeals addObject:aDeal];
        [aDeal release];
    }
}

- (void) arrCatsFromLocation :(NSMutableArray *) arrDealLocs {
    self.arrMutableDealsByLocationsSubCategories = [[NSMutableArray alloc] init];
    self.arrLocSubDeals = [[NSMutableArray alloc] init];
    
    NSMutableArray *valueIndex = [[NSMutableArray alloc] init];
	NSMutableDictionary *parti;
    
    for (int i=0; i<[arrDealLocs count]; i++) {
        Deal *aDeal = [arrDealLocs objectAtIndex:i];
        Category *aCategory = [aDeal.categories objectAtIndex:0];
        
        int exsistingIndex = -1;
		for (int i=0; i<[self.arrMutableDealsByLocationsSubCategories count]; i++) {
            
            
			NSMutableDictionary * part = [self.arrMutableDealsByLocationsSubCategories objectAtIndex:i];
			NSString *header = [part valueForKey:@"header"];
			if ([header isEqualToString:aCategory.name]) {
				exsistingIndex = i;
			}
		}
        
        if (exsistingIndex >= 0) {
			NSMutableDictionary * part = [self.arrMutableDealsByLocationsSubCategories objectAtIndex:exsistingIndex];
			NSMutableArray *arrDealSection = [part valueForKey:@"value"];
			[arrDealSection addObject:aDeal];
		} else {
			parti = [[NSMutableDictionary alloc] init];
			[parti setValue:aCategory.name forKey:@"header"];
			
			valueIndex = [[NSMutableArray alloc] init];
			[parti setValue:valueIndex forKey:@"value"];
			
			[valueIndex addObject:aDeal];
			[self.arrMutableDealsByLocationsSubCategories addObject:parti];
		}
        
        [self.arrLocSubDeals addObject:aDeal];
        [aDeal release];
    }
    
}

- (void)arrCategoriesFromObjDict :(NSArray *)arrDict {
	self.arrMutableCategories = [[NSMutableArray alloc] init];
	
	for (int i=0; i<[arrDict count]; i++) {
		Category *aCategory = [[Category alloc] init];
		[aCategory setId:[[[arrDict objectAtIndex:i] valueForKey:@"id"] intValue]];
		[aCategory setName:[[arrDict objectAtIndex:i] valueForKey:@"name"]];
		int pref = [self loadCategoryPrefFromDB:aCategory.id];
		[aCategory setPreferred:pref];
		[self.arrMutableCategories addObject:aCategory];
		[aCategory release];
		aCategory = nil;
	}
}

- (void)arrLocationsFromObjDict :(NSArray *)arrDict {
	self.arrMutableLocations = [[NSMutableArray alloc] init];
	
	for (int i=0; i<[arrDict count]; i++) {
		Location *aLocation = [[Location alloc] init];
		[aLocation setId:[[[arrDict objectAtIndex:i] valueForKey:@"id"] intValue]];
		[aLocation setName:[[arrDict objectAtIndex:i] valueForKey:@"name"]];
		int pref = [self loadLocationPrefFromDB:aLocation.id];
		[aLocation setPreferred:pref];
		[self.arrMutableLocations addObject:aLocation];
		[aLocation release];
		aLocation = nil;
	}
}

#pragma mark -
#pragma mark Database Functions

// Database Functions
-(void) dbconnect{
	// Setup some globals
	
	self.databaseName = @"DailyD.sqlite";
	
	// Get the path to the documents directory and append the databaseName
	NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDir = [documentPaths objectAtIndex:0];
	self.databasePath = [documentsDir stringByAppendingPathComponent:self.databaseName];
	
	// Execute the "checkAndCreateDatabase" function
	
	[self checkAndCreateDatabase];
}

-(void) checkAndCreateDatabase{
	// Check if the SQL database has already been saved to the users phone, if not then copy it over
	BOOL success;
	
	// Create a FileManager object, we will use this to check the status
	// of the database and to copy it over if required
	NSFileManager *fileManager = [NSFileManager defaultManager];
	
	// Check if the database has already been created in the users filesystem
	success = [fileManager fileExistsAtPath:databasePath];
	
	// If the database already exists then return without doing anything
	if(success) {
		//[fileManager removeFileAtPath:databasePath handler:nil]; //************************************************************
		return;
	}
	// If not then proceed to copy the database from the application to the users filesystem
	
	// Get the path to the database in the application package
	NSString *databasePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:databaseName];
	
	// Copy the database from the package to the users filesystem
	[fileManager copyItemAtPath:databasePathFromApp toPath:self.databasePath error:nil];
	
	[fileManager release];
}


-(void)firstCatSave :(Category *)aCat {
	
	sqlite3 *database;
	if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
		const char* sql = "INSERT INTO category_prefs (catid,prefstatus) VALUES (?,?)";
		sqlite3_stmt *statement;
		//localpath =@"abc";
		statement = [self PrepareStatement:sql];	
		int a1  = sqlite3_bind_int(statement,1,aCat.id);
		int a2  = sqlite3_bind_int(statement,2,aCat.preferred);
		//NSLog(SQLITE_OK);
		
		if (statement)
		{
			if (a1 != SQLITE_OK || a2 != SQLITE_OK)
			{
				sqlite3_finalize(statement);
				return;
			}
			
			sqlite3_step(statement);
		}
		sqlite3_finalize(statement);
	}	
	
}

-(void)checkCategory :(Category *)aCat c:(int)cstatus {
	
	sqlite3 *database;
	if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
		const char* sql = "Update category_prefs set prefstatus = ? where catid = ?";
		sqlite3_stmt *statement;
		//localpath =@"abc";
		statement = [self PrepareStatement:sql];	
		int a1  = sqlite3_bind_int(statement,1,cstatus);
		int a2  = sqlite3_bind_int(statement,2,aCat.id);
		//NSLog(SQLITE_OK);
		
		if (statement)
		{
			if (a1 != SQLITE_OK || a2 != SQLITE_OK)
			{
				sqlite3_finalize(statement);
				return;
			}
			
			sqlite3_step(statement);
		}
		sqlite3_finalize(statement);
	}	
	
}

-(BOOL)isAllCategoryUnchecked {
    
	BOOL returnVal = FALSE;
	// Setup the database object
	sqlite3 *database;
	
	// Open the database from the users filessytem
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK) {
		// Setup the SQL Statement and compile it for faster access
		const char *sqlStatement = "select * from category_prefs where prefstatus = 1";
		sqlite3_stmt *compiledStatement;
		if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
			// Loop through the results and add them to the feeds array
			while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
				returnVal = TRUE;
			}
		}
		// Release the compiled statement from memory
	}
	sqlite3_close(database);
	return returnVal;	
	
}


-(int)loadCategoryPrefFromDB :(int)catID {
	
	int pref = 0;
	// Setup the database object
	sqlite3 *database;
	
	// Open the database from the users filessytem
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK) {
		// Setup the SQL Statement and compile it for faster access
		const char *sqlStatement = "select * from category_prefs where catid = ?";
		sqlite3_stmt *compiledStatement;
		if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
			sqlite3_bind_int(compiledStatement, 1, catID);
			// Loop through the results and add them to the feeds array
			while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
				pref = sqlite3_column_int(compiledStatement, 1);
			}
		}
		// Release the compiled statement from memory
	}
	sqlite3_close(database);
	return pref;
}

-(void)mapCategories {
	
	// Setup the database object
	sqlite3 *database;
	
	// Open the database from the users filessytem
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK) {
		
		for (int i=0; i<[self.arrMutableCategories count]; i++) {
			Category *aCat = [self.arrMutableCategories objectAtIndex:i];
            
			BOOL found = FALSE;
            
			const char *sqlStatement = "select * from category_prefs where catid = ?";
			sqlite3_stmt *compiledStatement;
			if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
				sqlite3_bind_int(compiledStatement, 1, aCat.id);
				// Loop through the results and add them to the feeds array
				while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
					[aCat setPreferred:sqlite3_column_int(compiledStatement,1)];
                    
					found = TRUE;
				}
			}
			
			if (!found) {
				[aCat setPreferred:1];
			}
			sqlite3_finalize(compiledStatement);
		}
		// Setup the SQL Statement and compile it for faster access
		// Release the compiled statement from memory
	}
	sqlite3_close(database);
	
	
}

-(void)firstLocSave :(Location *)aLoc {
	
	sqlite3 *database;
	if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
		const char* sql = "INSERT INTO location_prefs (locid,prefstatus) VALUES (?,?)";
		sqlite3_stmt *statement;
		//localpath =@"abc";
		statement = [self PrepareStatement:sql];	
		int a1  = sqlite3_bind_int(statement,1,aLoc.id);
		int a2  = sqlite3_bind_int(statement,2,aLoc.preferred);
		//NSLog(SQLITE_OK);
		
		if (statement)
		{
			if (a1 != SQLITE_OK || a2 != SQLITE_OK)
			{
				sqlite3_finalize(statement);
				return;
			}
			
			sqlite3_step(statement);
		}
		sqlite3_finalize(statement);
	}	
	
}

-(void)checkLocation :(Location *)aLoc c:(int)cstatus {
	
	sqlite3 *database;
	if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
		const char* sql = "Update location_prefs set prefstatus = ? where locid = ?";
		sqlite3_stmt *statement;
		//localpath =@"abc";
		statement = [self PrepareStatement:sql];	
		int a1  = sqlite3_bind_int(statement,1,cstatus);
		int a2  = sqlite3_bind_int(statement,2,aLoc.id);
		//NSLog(SQLITE_OK);
		
		if (statement)
		{
			if (a1 != SQLITE_OK || a2 != SQLITE_OK)
			{
				sqlite3_finalize(statement);
				return;
			}
			
			sqlite3_step(statement);
		}
		sqlite3_finalize(statement);
	}	
	
}

-(BOOL)isAllLocationUnchecked {
	
	BOOL returnVal = FALSE;
	// Setup the database object
	sqlite3 *database;
	
	// Open the database from the users filessytem
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK) {
		// Setup the SQL Statement and compile it for faster access
		const char *sqlStatement = "select * from location_prefs where prefstatus = 1";
		sqlite3_stmt *compiledStatement;
		if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
			// Loop through the results and add them to the feeds array
			while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
				returnVal = TRUE;
			}
		}
		// Release the compiled statement from memory
	}
	sqlite3_close(database);
	return returnVal;	
	
}

-(int)loadLocationPrefFromDB :(int)locID {
	
	int pref = 0;
	// Setup the database object
	sqlite3 *database;
	
	// Open the database from the users filessytem
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK) {
		// Setup the SQL Statement and compile it for faster access
		const char *sqlStatement = "select * from location_prefs where locid = ?";
		sqlite3_stmt *compiledStatement;
		if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
			sqlite3_bind_int(compiledStatement, 1, locID);
			// Loop through the results and add them to the feeds array
			while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
				pref = sqlite3_column_int(compiledStatement, 1);
			}
		}
		// Release the compiled statement from memory
	}
	sqlite3_close(database);
	return pref;
}

-(void)mapLocations {
	
	// Setup the database object
	sqlite3 *database;
	
	// Open the database from the users filessytem
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK) {
		
		for (int i=0; i<[self.arrMutableLocations count]; i++) {
			Location *aLoc = [self.arrMutableLocations objectAtIndex:i];
			
			BOOL found = FALSE;
			
			const char *sqlStatement = "select * from location_prefs where locid = ?";
			sqlite3_stmt *compiledStatement;
			if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
				sqlite3_bind_int(compiledStatement, 1, aLoc.id);
				// Loop through the results and add them to the feeds array
				while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
					[aLoc setPreferred:sqlite3_column_int(compiledStatement,1)];
					
					found = TRUE;
				}
			}
			
			if (!found) {
				[aLoc setPreferred:1];
			}
			sqlite3_finalize(compiledStatement);
		}
		// Setup the SQL Statement and compile it for faster access
		// Release the compiled statement from memory
	}
	sqlite3_close(database);
	
	
}

-(void)flushCategories {
	// Setup the database object
	sqlite3 *database;
	// Open the database from the users filessytem
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK) {
		sqlite3_stmt *deleteStmt;
		NSString * sql = @"delete from category_prefs";
		if(sqlite3_prepare_v2(database, [sql UTF8String], -1, &deleteStmt, NULL) != SQLITE_OK)
			NSAssert1(0, @"Error while creating delete statement. '%s'", sqlite3_errmsg(database));
		
		if (SQLITE_DONE != sqlite3_step(deleteStmt))
			NSAssert1(0, @"Error while deleting. '%s'", sqlite3_errmsg(database));
		
		sqlite3_reset(deleteStmt);
	}
	
}

-(void)flushLocations {
	// Setup the database object
	sqlite3 *database;
	// Open the database from the users filessytem
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK) {
		sqlite3_stmt *deleteStmt;
		NSString * sql = @"delete from location_prefs";
		if(sqlite3_prepare_v2(database, [sql UTF8String], -1, &deleteStmt, NULL) != SQLITE_OK)
			NSAssert1(0, @"Error while creating delete statement. '%s'", sqlite3_errmsg(database));
		
		if (SQLITE_DONE != sqlite3_step(deleteStmt))
			NSAssert1(0, @"Error while deleting. '%s'", sqlite3_errmsg(database));
		
		sqlite3_reset(deleteStmt);
	}	
}

-(sqlite3_stmt*) PrepareStatement:(const char *)sql
{
	// Setup the database object
	sqlite3 *database;
	// Init the animals Array
	
	// Open the database from the users filessytem
	if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
		// Setup the SQL Statement and compile it for faster access
		const char *sqlStatement = sql;
		sqlite3_stmt *compiledStatement;
		
		if(sqlite3_prepare_v2(database, sqlStatement,-1, &compiledStatement, NULL) == SQLITE_OK) {
			//NSLog(@"COMPILED STATEMENT: %@",compiledStatement);
			return compiledStatement;
			
		}
	}
	return nil;
}

#pragma mark -
#pragma mark API Functions

- (NSString *)apiDeals:(int)page {
	
	NSString *catIDs = [self getCategories];
	NSString *locIDs = [self getLocations];
	
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@?filtered=true&format=json&categories=%@&locations=%@&page=%d&per_page=15",self.setAPIUrl,catIDs,locIDs,page]];
	NSLog(@"%@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;
}

- (NSString *)apiDealsForSelectedCategory :(int)selectedCategoryID pageNo:(int)page {
	
	NSString *locIDs = [self getLocations];
	
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@?filtered=true&format=json&categories=%d&locations=%@&page=%d&per_page=10",self.setAPIUrl,selectedCategoryID,locIDs,page]];
	NSLog(@"%@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;
}

- (NSString *)apiDealsForSelectedLocation :(int)selectedLocationID {
	
	NSString *catIDs = [self getCategories];
	
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@?filtered=true&format=json&categories=%@&locations=%d",self.setAPIUrl,catIDs,selectedLocationID]];
	NSLog(@"%@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;
}

- (NSString *)getCategories {
	NSString *strCategories = @"";
	for (int i=0; i<[self.arrMutableCategories count]; i++) {
		Category *aCat = [self.arrMutableCategories objectAtIndex:i];
		if (aCat.preferred == 1) {
			strCategories = [strCategories stringByAppendingString:[NSString stringWithFormat:@"%d,",aCat.id]];
		}
	}
	if ([strCategories length] > 1)
		strCategories = [strCategories substringToIndex:[strCategories length]-1];
	return strCategories;
}

- (NSString *)getLocations {
	NSString *strLocations = @"";
	for (int i=0; i<[self.arrMutableLocations count]; i++) {
		Location *aLoc = [self.arrMutableLocations objectAtIndex:i];
		if (aLoc.preferred == 1) {
			strLocations = [strLocations stringByAppendingString:[NSString stringWithFormat:@"%d,",aLoc.id]];
		}
	}
	if ([strLocations length] > 1)
		strLocations = [strLocations substringToIndex:[strLocations length]-1];
	return strLocations;
}

#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
	[navigationController release];
	[window release];
	[super dealloc];
}

@end

