//
//  WebService.h
//  DailyD
//
//  Created by Jagadeesh on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface WebService : NSObject {
    
}

-(NSString*) apiCategories:(NSString*)home;
-(NSString*) apiCategoriesLocation:(NSString*)home catId:(int)value;
-(NSString*) apiDealsHome:(NSString *)home catId:(int)cid locId:(int)lid pageno:(int)page;
-(NSString*) apiLocation:(NSString*)home;
-(NSString*) apiLocationCategories:(NSString*)home locId:(int)value;
-(NSString*) apiSiteList:(NSString*)home;
-(NSString*) apiSiteDeals:(NSString*)home siteId:(int)value pageno:(int)page;
-(NSString*) apiLocationAllDeals:(NSString *)home; 


@end
