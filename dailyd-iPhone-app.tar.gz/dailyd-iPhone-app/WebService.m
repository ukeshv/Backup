//
//  WebService.m
//  DailyD
//
//  Created by Jagadeesh on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "WebService.h"


@implementation WebService

-(id)init{
    
    NSLog(@"initialized");
    return self;
}
-(NSString*) apiCategories:(NSString*)home{
   
	NSLog(@"loaded");
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/categories?format=json",home]];
	NSLog(@"%@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;

}

-(NSString*) apiCategoriesLocation:(NSString*)home catId:(int)value{
    
	NSLog(@"loaded");
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/category_location?category_id=%d",home,value]];
    NSLog(@"ws Categories_Location==> %@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;
    
}

-(NSString*) apiDealsHome:(NSString *)home catId:(int)cid locId:(int)lid pageno:(int)page{
    http://vrinteractive.railsfactory.com/api/category_location_deals?category_id=1&location_id=5&page=1&per_page=5
    
    NSLog(@"loaded");
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/category_location_deals?category_id=%d&location_id=%d&page=%d&per_page=20",home,cid,lid,page]];
	NSLog(@"%@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;
}
//http://vrinteractive.railsfactory.com/api/locations
-(NSString*) apiLocation:(NSString*)home{
    
	NSLog(@"loaded");
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/locations",home]];
	NSLog(@"%@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;
    
}


//http://vrinteractive.railsfactory.com/api/sites

-(NSString*) apiLocationCategories:(NSString*)home locId:(int)value{
    
	NSLog(@"loaded");
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/location_category?location_id=%d",home,value]];
	NSLog(@"%@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;
    
}

-(NSString*) apiLocationAllDeals:(NSString *)home
{
    NSLog(@"loaded");
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/all_deals",home]];
	NSLog(@"%@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;   
    
    
}


-(NSString*) apiSiteList:(NSString*)home{
    
	NSLog(@"loaded");
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/sites",home]];
	NSLog(@"%@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;
    
}
//http://vrinteractive.railsfactory.com/api/site_deals?site_id=5&page=1&per_page=5

-(NSString*) apiSiteDeals:(NSString*)home siteId:(int)value pageno:(int)page{
    
	NSLog(@"loaded");
	NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/site_deals?site_id=%d&page=%d&per_page=20",home,value,page]];
	NSLog(@"%@",[url absoluteString]);
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:url];
	[request setHTTPMethod:@"GET"];
	
	NSURLResponse *response = NULL;
	NSError *requestError = NULL;
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
	NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
	responseString = [responseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
    //	NSLog(@"responseString:\n%@",responseString);
	return responseString;
    
}

@end
