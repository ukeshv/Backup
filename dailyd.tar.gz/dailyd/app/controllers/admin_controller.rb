class AdminController < ApplicationController
  before_filter :authenticate_user!
  before_filter :reject_disabled_users
  before_filter :only_allow_admins

  def index
  end

  def users		 
	users=params[:email] ? User.where("email like ?","%"+params[:email]+"%") : User  	
  @users = users.all.paginate :page => params[:page], :per_page=>30,:order => 'lower(email) ASC'   # or @search.relation to lazy load in view
    if request.post?
      params[:user].keys.each do |user_id|
        next if current_user.id == user_id.to_i # Users cannot remove themselves

        User.transaction do
          u = User.find(user_id)
          u.update_attributes(:admin => false, :disabled => false, :test => false)
          u.update_attributes(params[:user][user_id])
        end
      end
    end

    logger.warn "Done with the loop"
    #~ @users = User.paginate :page => params[:page], :order => 'lower(email) ASC'
  end

  def update_email
    if params[:email] =~ /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/
    user = User.find_by_id(params[:id])
    @user =user
    begin
    user.update_attribute("email",params[:email])
		user.add_md5_id if user
		user.save
    rescue
    @error_already_exist = true
    end
    else
    @error = true
	end
  end

  def delete_user
  user = User.find_by_id(params[:id])
  user.destroy
  flash[:success] = "המשתמש נמחק בהצלחה"
  redirect_to "/admin/users"
  end

end
