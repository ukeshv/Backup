class ApiController < ApplicationController
		
	def categories
	 #~ render :json=> Category.all.collect(&:to_iphone_hash_new)
	 category_hash = Category.all.collect(&:to_iphone_hash_new)
	 filter_category_hash = category_hash.select{|x| x[:deals_count] !=0}
	 render :json=> filter_category_hash
  end
 
  def locations
	 #~ render :json=> Location.all.collect(&:to_iphone_hash_new)
	 location_hash = Location.all.collect(&:to_iphone_hash_new)
	 filter_location_hash = location_hash.select{|x| x[:deals_count] !=0}
	 render :json=> filter_location_hash
  end
 
	def sites
	 #~ render :json=> Site.all.collect(&:to_iphone_hash_new)
	 site_hash = Site.all.collect(&:to_iphone_hash_new)
	 filter_site_hash = site_hash.select{|x| x[:deals_count] !=0}
	 render :json=> filter_site_hash
  end
 
  def category_deals
		@deals = Deal.active.by_categories(params[:category_id])
		@deals = @deals.paginate(:page=>params[:page],:per_page=>params[:per_page])
		render :json => @deals.collect(&:to_iphone_hash)
	end

  def location_deals
		@deals = Deal.active.by_locations(params[:location_id])
		@deals = @deals.paginate(:page=>params[:page],:per_page=>params[:per_page])
		render :json => @deals.collect(&:to_iphone_hash)
	end	
	
	def category_location
	#~ @location_deals =  Deal.active.includes(:categories,:locations).where("categories.id = ?",params[:category_id]).group("locations.name").count	
	deals = Location.all.collect{|x| x.to_iphone_hash_for_location(params[:category_id])}
	location_deals = deals.each_with_index{|x,i| deals.delete(x) if(deals[i][:count] <= 0)}
	filter_location_deals = location_deals.select{|x| x[:count] !=0}
	 render :json => filter_location_deals
 end
 
 	def location_category
	#~ @location_deals =  Deal.active.includes(:categories,:locations).where("categories.id = ?",params[:category_id]).group("locations.name").count	
	deals = Category.all.collect{|x| x.to_iphone_hash_for_location(params[:location_id])}
	category_deals = deals.each_with_index{|x,i| deals.delete(x) if(deals[i][:count] <= 0)}
	filter_category_deals = category_deals.select{|x| x[:count] != 0}
	 render :json => filter_category_deals
 end

def category_location_deals
	@deals =  Deal.active.includes(:categories,:locations).where("categories.id =? and locations.id =?",params[:category_id],params[:location_id])
	@deals = @deals.paginate(:page=>params[:page],:per_page=>params[:per_page])
	render :json => @deals.collect(&:to_iphone_hash)
end

def site_deals
  @deals =  Deal.active.includes(:site).where("sites.id=?",params[:site_id])
	@deals = @deals.paginate(:page=>params[:page],:per_page=>params[:per_page])
	render :json => @deals.collect(&:to_iphone_hash)
end	

def all_deals
	category_ids = Category.select("id").all.collect(&:id)
	location_ids = Location.select("id").all.collect(&:id)
	@deals = Deal.current.includes(:categories, :locations).where(["locations.id in (?) AND categories.id in (?)", location_ids, category_ids])
	@deals = @deals.paginate(:page=>params[:page],:per_page=>params[:per_page])
	render :json => @deals.collect(&:to_iphone_hash)
end	

end
