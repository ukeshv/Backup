require 'md5'

class ApplicationController < ActionController::Base
	layout "admin"
  protect_from_forgery

  before_filter :get_locations_and_categories_and_sites#,:total_deals
  cache_sweeper :front_sweeper

  protected
  def all_location_ids
    @all_location_ids ||= @locations.collect(&:id).sort
  end
  helper_method :all_location_ids

  def all_locations_deal?(deal)
    deal.location_ids.sort == all_location_ids
  end
  helper_method :all_locations_deal?


def total_deals
  @total_deals ||= Deal.active.includes("locations","categories","site")
end

helper_method :total_deals


  def get_locations_and_categories_and_sites
    @locations = Location.all
    @categories = Category.all
    @sites = Site.not_disabled.all
  end

  def reject_disabled_users
    if current_user.disabled?
      flash[:alert] = 'Unauthorized access.'
      redirect_to :controller => :home, :action => :index
    end
  end

  def only_allow_admins
    unless current_user and current_user.admin?
      flash[:alert] = 'Unauthorized access.'
      redirect_to :controller => :home, :action => :index
    end
  end

  def get_current_deals
    @deals = Deal.current.all
  end

  def get_user_by_md5
    @user = User.find_by_md5_id(params[:id])
    if @user.nil?
      logger.warn "Redirecting; no user with MD5 '#{params[:id]}'"
      redirect_to root_url
    end
  end


  def find_user_settings
    @total_deals=Deal.active.map(&:id)
    user=User.find_by_email_and_reg(cookies[:email],true,:include=>["follows","boughts"]) if cookies[:email]
    @from=user && user.break_from ? user.break_from.strftime("%d/%m/%Y") : nil
    @to=user && user.break_to ? user.break_to.strftime("%d/%m/%Y") : nil
    follow=user.follows if user
    @terms=follow.map(&:term).compact.uniq if user && follow
    @follow_deals=follow.map(&:deal_id) if user && follow
    @bought_deals=user.boughts.map(&:deal_id) if user && user.boughts
    @follow_deals=@follow_deals-(@follow_deals-@total_deals) if @follow_deals
    @user=user
  end


end

# a silly comment
# another silly comment
