class BannersController < ApplicationController
  before_filter :authenticate_user!
  before_filter :reject_disabled_users
  before_filter :only_allow_admins
  before_filter :find_banner,:only=>[:show,:edit,:update,:destroy]

  def index
    @banners = Banner.all
  end

  def edit
  end

  def update
    @banner.update_attributes(params[:banner])
    flash[:notice] = "Banner has been updated."
    redirect_to @banner
  end

  def new
    @banner = Banner.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @banner }
    end
  end

  def create

    @banner = Banner.new(params[:banner])

    respond_to do |format|
      if @banner.save
        format.html { redirect_to(@banner, :notice => 'Banner was successfully created.') }
        format.xml  { render :xml => @site, :status => :created, :location => @banner }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @banner.errors, :status => :unprocessable_entity }
      end
    end
  end

  def destroy
    @banner.destroy
    flash[:notice] = "Banner has been deleted."
    redirect_to banners_path
  end

  def show
  end

  protected

  def find_banner
  @banner = Banner.find_by_id(params[:id])
  end

end
