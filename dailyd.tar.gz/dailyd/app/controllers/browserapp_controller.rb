class BrowserappController < ApplicationController
  before_filter :get_current_deals

  def index
    if params[:category].present?
      if params[:location].present?
        @location = Location.find(params[:location])
        @location_id = @location.id || 0
        @deals = @deals.select {|d| d.locations.include?(@location) }
      end
      @category = Category.find(params[:category])
      @category_id = @category.id || 0
      @deals = @deals.select {|d| d.categories.include?(@category) }
    elsif params[:location].present?
      @location = Location.find(params[:location])
      @location_id = @location.id || 0
      @deals = @deals.select {|d| d.locations.include?(@location) }
    end

    render :layout => 'browserapp'
  end
end
