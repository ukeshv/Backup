class ClicksController < ApplicationController
  before_filter :authenticate_user!, :only => :index
  before_filter :reject_disabled_users, :only => :index
  before_filter :only_allow_admins, :only => :index

  def index
    clicks = Click.for_site(site_ids).during(_start_date, _end_date).group("deal_id").count
    @clicks = {}
    clicks.each do |deal_id, count|
      deal = Deal.includes("site").find(deal_id)
      @clicks[deal.site] ||= {}
      @clicks[deal.site][deal] = count
    end
  end

  def new
    redirect_to root_url and return if params[:id].blank?

    @deal = Deal.find(params[:id])

    render_facebook = "true" == params[:fb]

    unless render_facebook
      click = @deal.clicks.create(:user_id => current_user.try(:id), :referrer => request.referrer,
        :browser_info => request.user_agent, :remote_ip => request.remote_ip)

      redirect_to @deal.url and return unless click.new_record?

      redirect_to root_url
    else
      render :layout => false
    end
  end

protected

  def _start_date
    (params[:start_date] && _make_date(params[:start_date]) || Time.now.to_date).to_time.beginning_of_day
  end
  helper_method :_start_date

  def _end_date
    ((params[:end_date] && _make_date(params[:end_date]) || _start_date) + 1.day).to_time.beginning_of_day
  end
  helper_method :_end_date

  def site_ids
    params[:site] == "all" ? Site.all.collect(&:id) : [params[:site].to_i]
  end

  def _make_date(v)
    "#{v[:year]}-#{v[:month]}-#{v[:day]}".to_date rescue "#{v[:year]}-#{v[:month]}-01".to_date.end_of_month
  end
end
