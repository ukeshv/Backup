class DealsController < ApplicationController
  before_filter :authenticate_user!, :except => :previous
  before_filter :reject_disabled_users, :except => :previous
  before_filter :only_allow_admins, :except => :previous
  before_filter :find_deal,:only=>[:show,:edit,:update,:destroy]

  # GET /deals
  # GET /deals.xml
  def index
    if params[:deal_search] and !params[:deal_search].blank?
      @deals=Deal.search(params[:deal_search].downcase).paginate :page => params[:page], :order => 'created_at ASC'
    else
      @deals = Deal.paginate :page => params[:page], :order => 'created_at ASC'
      respond_to do |format|
        format.html # index.html.erb
        format.xml  { render :xml => @deals }
      end
    end
  end

  # GET /deals/1
  # GET /deals/1.xml
  def show
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @deal }
    end
  end

  # GET /deals/new
  # GET /deals/new.xml
  def new
    @deal = Deal.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @deal }
    end
  end

  # GET /deals/1/edit
  def edit
  end

  # POST /deals
  # POST /deals.xml
  def create
		#~ puts params.inspect
		#~ puts params["location5"].inspect
    @deal = Deal.new(params[:deal])
		@deal.save
    respond_to do |format|
      if @deal.save
				save_location_address
        Deal.delay(:run_at => Time.current.end_of_day - 1.hour).get_lat_lng(@deal.id) unless @deal.nation_wide_deal?
        format.html { redirect_to(@deal, :notice => 'Deal was successfully created.') }
        format.xml  { render :xml => @deal, :status => :created, :location => @deal }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @deal.errors, :status => :unprocessable_entity }
      end
    end
  end
def save_location_address
  	#~ if @deal.locations.map(&:id).uniq.count==@locations.count
		#~ @deal.update_attributes(:nation_wide_deal=>1)
	#~ else
		#~ @deal.update_attributes(:nation_wide_deal=>0)
	#~ end
  address_arr=[]
  address_arr << params[:address1] << params[:address2] << params[:address3] << params[:address4] << params[:address5]
  #~ if @deal.nation_wide_deal?
  #~ @deal.addresses << Address.create(:address => address_arr.compact.first)
  #~ else
    (1..5).each do |x|
      address= params["address#{x}"]
      location=params["location#{x}"]
        unless (address.blank? || location.blank?)
        a=Address.create(:address=>address) if address
        DealAddress.create(:deal_id=>@deal.id,:address_id=>a.id)
        AddressLocation.create(:location_id=>location,:address_id=>a.id)
        end
        unless location.blank?
        DealLocation.find_or_create_by_deal_id_and_location_id(:deal_id=>@deal.id,:location_id=>location)
        end
    #~ end
	end

end
  # PUT /deals/1
  # PUT /deals/1.xml
  def update
    a=DealAddress.delete(DealAddress.find_all_by_deal_id(@deal.id).map(&:id))
    save_location_address
    respond_to do |format|
      if @deal.update_attributes(params[:deal])

        format.html { redirect_to(@deal, :notice => 'Deal was successfully updated.') }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @deal.errors, :status => :unprocessable_entity }
      end
    end
  end


  # DELETE /deals/1
  # DELETE /deals/1.xml
  def destroy
    @deal.destroy

    respond_to do |format|
      format.html { redirect_to(deals_url) }
      format.xml  { head :ok }
    end
  end

  def previous
    @date_to_view = params[:date].present? ? Date.parse(params[:date]) : Date.parse(1.day.ago.to_s)
    @deals = Deal.where(["starts_at <= ? and ends_at >= ? ", @date_to_view, @date_to_view]).all

    @next_link = @date_to_view + 1.day
    if @next_link == Date.today
      @next_link = nil
    end

    @prev_link = @date_to_view - 1.day
  end

  protected

  def find_deal
   @deal = Deal.find_by_id(params[:id])
  end


end
