class FrontController < ApplicationController
#~ defaults :resource_class => Deal, :collection_name => 'deals'
layout 'application'
skip_before_filter :get_locations_and_categories_and_sites, :if => :is_it_js?
before_filter :current_user_settings,:calculate_counts, :unless => :is_it_js? #,:load_deals, :except=>["get_deals"]
caches_action :index,:unless => :is_it_js?
#~ helper_method  :total_deals

def is_it_js?
  return (request.format.js? || request.format.json?)
end

def index
find_deals unless request.format.json?
  respond_to do |format|
    format.html
    format.xml
    format.js
    #http://dailyd.co.il/?format=json
    #http://dailyd.co.il/?format=json&md5_id=FOOBAR
    format.json { _render_filters }
  end
end

def _render_filters
    location_ids = _parse_list(params[:locations])
    location_ids = Location.select("id").all.collect(&:id) if location_ids.blank?
    category_ids = _parse_list(params[:categories])
    category_ids = Category.select("id").all.collect(&:id) if category_ids.blank?
    @deals = Deal.current.includes(:categories, :locations).where(["locations.id in (?) AND categories.id in (?)", location_ids, category_ids])
    render :json => @deals.collect(&:to_iphone_hash)
end

def _parse_list(v)
    v.to_s.split(/,/).collect(&:to_i).compact.select {|v| v > 0}
end


# newly added for home page scratch

def find_deals
  if params[:locations] && params[:search_data] && !params[:search_data].blank?
    search = "%"+params[:search_data].downcase+"%"
    condition = "locations.id in (?) and categories.id in (?) and sites.id in (?) and (title like ? or description like ?)",params[:locations],params[:categories],params[:sites],search,search
  elsif params[:locations]
    condition = "locations.id in (?) and categories.id in (?) and sites.id in (?)",params[:locations],params[:categories],params[:sites]
  else
  condition = nil
end
  deals = (condition!=nil) ? total_deals.where(condition).order("sites.sort_order ASC, deals.created_at DESC"): total_deals.order("sites.sort_order ASC, deals.created_at DESC")
  @total = deals.count
  top_deals = find_top_deals(deals)
  @deals = top_deals + (deals - top_deals)
  @indexed_deals = @deals.paginate(:page => params[:page], :per_page => 40)
  @bought_ids= Bought.where("email=?",cookies[:email]).select("deal_id").map(&:deal_id) if cookies[:email]
end

def find_top_deals(deals)
arr = []
deals.map{|x| arr << x if x.position}
return arr.sort_by{|x| x.position}
end

def load_deals
  deals_list = collection#.paginate(:page => params[:page], :per_page => 5)
  top_deals = Deal.active.where("position is NOT NULL").sort_by{|x| x.position}
  deals = (top_deals + (deals_list - top_deals))
  @indexed_deals = deals.paginate(:page => params[:page], :per_page => 40)
  @total = deals.count
end

def collection
  @deals ||= end_of_association_chain.current#.paginate(:page => params[:page], :per_page => 5)
end

def calculate_counts
  @count_by_site = Deal.active.group(:site_id).count
  @count_by_category = Deal.active.includes(:categories).group("categories.id").count
end

def get_deals
  if params[:pagination]
    respond_to do |format|
      render :template =>"front/get_deals_paginate"
    end
  else
  if params[:filter_deals]
    @filter = true
    deals = Deal.active.by_filter(params[:locations],params[:categories],params[:sites])
    top_deals = find_top_deals(deals)
    @indexed_deals = (top_deals + (deals - top_deals)).paginate(:page => params[:page], :per_page => 40)
    respond_to do |format|
      format.js
    end
  end

end
end

#newly added for home page scratch - End

def save_filters
    if params[:email] && !params[:email].blank? && ((params[:email]  =~/^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/)!=nil)
      @new_user = User.find_or_initialize_by_email(params[:email])
      @new_user.disabled = false
      new_user = @new_user.new_record?
      @new_user.save(:validate => false)
        save_cookies
        cookies[:user_preference] = {
        :value => @new_user.md5_id,
        :expires => 20.years.from_now.utc
      }

        render :text =>"success"
    else
        if cookies[:user_preference] && !params[:email]
        u_md5 = cookies[:user_preference]
        user = User.find_by_md5_id(u_md5)

        user.location_ids = (params[:location_ids] || "").split(/,/)
        user.site_ids = (params[:site_ids] || "").split(/,/)
        user.category_ids = (params[:category_ids] || "").split(/,/)
        user.save(false)

        cookies[:settings_saved] = "true"
        cookies[:filter_location_ids] = params[:location_ids]
        cookies[:filter_category_ids] = params[:category_ids]
        cookies[:filter_site_ids] = params[:site_ids]

        render :nothing => true
        else
            render :text => "error"
        end
    end
end



def save_cookies
  @new_user.location_ids = (params[:location_ids] || "").split(/,/)
  @new_user.site_ids = (params[:site_ids] || "").split(/,/)
  @new_user.category_ids = (params[:category_ids] || "").split(/,/)
  @new_user.save(false)

  cookies[:settings_saved] = "true"
  cookies[:email] = params[:email]
  cookies[:filter_location_ids] = params[:location_ids]
  cookies[:filter_category_ids] = params[:category_ids]
  cookies[:filter_site_ids] = params[:site_ids]
end

  def current_user_settings
    # take user from cookie or param
    u_md5 = params[:md5_id] || cookies[:user_preference]
    if u_md5 && u = User.find_by_md5_id(u_md5)
      cookies[:email] = u.email
      cookies[:filter_location_ids] = u.location_ids.uniq.join(",")
      cookies[:filter_category_ids] = u.category_ids.uniq.join(",")
      cookies[:filter_site_ids] = u.site_ids.uniq.join(",")
			cookies[:reg_user]=u.reg
    end
    true
  end


end
