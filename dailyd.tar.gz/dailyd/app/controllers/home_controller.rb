class HomeController < ApplicationController

  #~ layout 'internal', :except => [:index, :subscribe,:customize]
  #~ layout 'application',:only=>["customize"]
  
  layout :select_layout
  
  before_filter :get_current_deals, :except => [ :index, :recent_deals ]

  def index
    return _render_filters unless params[:filtered].blank?
    @location = Location.find_by_id(params[:location]) unless params[:location].blank?
    @location ||= Location.first
    @deals = @location.deals.current.with_not_disabled_site.all

    @category = Category.find_by_id(params[:category]) unless params[:category].blank?
    @category_id = @category.try(:id).to_i

    if params[:md5_id] && u = User.find_by_md5_id(params[:md5_id])
      @deals = @deals.select {|d| u.subscribed_to?(d)}
    elsif @category
      @deals = @deals.select {|d| d.categories.include?(@category) }
    end

    respond_to do |format|
      format.html { render :layout => 'application' }
      format.xml
      # http://dailyd.co.il/?format=json
      # http://dailyd.co.il/?format=json&md5_id=FOOBAR
      format.json { render :json => @deals.collect(&:to_iphone_hash) }
    end

  end
	
#~ def customize
	#~ user=User.find_by_email_and_reg(cookies[:email],true,:include=>["follows","boughts"]) if cookies[:email]
  #~ @from=user && user.break_from ? user.break_from.strftime("%d/%m/%Y") : nil
   #~ @to=user && user.break_to ? user.break_to.strftime("%d/%m/%Y") : nil
	 #~ follow=user.follows if user
  #~ @terms=follow.map(&:term) if user && follow
#~ find_deals_for_terms(@terms) if @terms
  #~ @follow_deals=follow.map(&:deal_id) if user && follow
	#~ @bought_deals=user.boughts.map(&:deal_id) if user && user.boughts
	#~ @user=user
#~ end


def customize
  #~ user=User.find_by_email_and_reg(cookies[:email],true) if cookies[:email]
	@deal_bought=params[:b]
	@deal_follow=params[:f]
	user=User.find_by_email(cookies[:email]) if cookies[:email]	
  @from=user && user.break_from ? user.break_from.strftime("%d/%m/%Y") : nil
  @to=user && user.break_to ? user.break_to.strftime("%d/%m/%Y") : nil
  @user = user
	if @user
		redirect_to "/settings/preferences"
	end
end


  def recent_deals
    if params[:category].present?
      @category = Category.find(params[:category])
      @recent_deals = Deal.old.for_category(@category).paginate :page => params[:page], :per_page => 20
    elsif params[:location].present?
      @location = Location.find_by_id(params[:location]) || Location.first
      @recent_deals = Deal.old.for_location(@location).paginate :page => params[:page], :per_page => 20

    elsif params[:site].present?
      @site = Site.find_by_id(params[:site]) || Site.first
      @recent_deals = Deal.old.for_site(@site).paginate :page => params[:page], :per_page => 20
    else
      @recent_deals = Deal.old.paginate :page => params[:page], :per_page => 20
    end
		@deals = Deal.current.all
    render :layout => 'application'
  end

  def subscribe
    render :layout => 'application'
  end

  def categories
    render :json => Category.all.collect(&:to_iphone_hash)
  end

  def locations
    render :json => Location.all.collect(&:to_iphone_hash)
  end

  def sites
    render :json => Site.not_disabled.collect(&:to_iphone_hash)
  end

protected

  def _render_filters
    location_ids = _parse_list(params[:locations])
    location_ids = Location.select("id").all.collect(&:id) if location_ids.blank?
    category_ids = _parse_list(params[:categories])
    category_ids = Category.select("id").all.collect(&:id) if category_ids.blank?
    @deals = Deal.current.includes(:categories, :locations).where(["locations.id in (?) AND categories.id in (?)", location_ids, category_ids])
    render :json => @deals.collect(&:to_iphone_hash)
  end

  def _parse_list(v)
    v.to_s.split(/,/).collect(&:to_i).compact.select {|v| v > 0}
  end


private

def select_layout
  if action_name == "customize"
    return "application"
  elsif action_name == "index"
    return "nothing"
  else
    return "internal"
  end
end


end
