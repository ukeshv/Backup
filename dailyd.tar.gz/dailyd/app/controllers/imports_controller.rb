class ImportsController < ApplicationController
  before_filter :authenticate_user!
  before_filter :only_allow_admins

  def index
    @imported_deals = ImportedDeal.not_imported.order("created_at DESC").all
  end

  def create
    errors = 0
    params[:imported_deals].each do |id, opts|
      d = ImportedDeal.find(id)
      case opts[:action]
      when "remove"
        d.deal_id = 0
        d.save
      when "import"
        d.address = opts[:address]
        d.title = opts[:title]
        d.description = opts[:description]
        d.starts_at=opts[:starts_at]
        d.ends_at=opts[:ends_at]
        d.url=opts[:url]
        d.discount_percentage=opts[:discount_percentage]
        d.amount_saved=opts[:amount_saved]
        d.suggested_location=opts[:suggested_location]
        d.value=opts[:value]
        begin
          ImportedDeal.transaction do
            d.import!((opts[:locations] || {}).keys, (opts[:categories] || {}).keys,(opts[:address] || {}).values,(opts[:location] || {}).values)
          end
        rescue ActiveRecord::RecordInvalid => e
          errors += 1
        end
      else
        # skip
      end
    end
    flash[:notice] = "#{params[:imported_deals].keys.size - errors} processed, #{errors} failed (no address, location or categories)"
    system('rake download_image:local RAILS_ENV=production')
    redirect_to :action => :index
  end

  def deal_map
    @deal = ImportedDeal.find(params[:id])
    @address = params[:address]
    if @address && !@address.blank?
    response = Deal.parse_response(@address)
    @lat = response[0]
    @lng = response[1]
    else
    @error = "אנא הכנס את כתובת"
    end
    render :partial=>"address_map",:locals=>{:lat=>@lat,:lng=>@lng,:error=>@error}
  end

end
