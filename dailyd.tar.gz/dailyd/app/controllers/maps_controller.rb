class MapsController < ApplicationController
  before_filter :authenticate_user!, :except => :previous
  before_filter :reject_disabled_users, :except => :previous
  before_filter :only_allow_admins, :except => :previous
  before_filter :set_deal

  def show

  end

  protected
  def set_deal

    unless params[:address]
      @deal = Deal.find(params[:deal_id])
    else
      @deal = ImportedDeal.find(params[:deal_id])
      @address = params[:address]
    end

    @deal = Deal.find(params[:deal_id])

  end

end
