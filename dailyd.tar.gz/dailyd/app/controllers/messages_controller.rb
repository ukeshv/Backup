class MessagesController < InheritedResources::Base
  defaults :resource_class => Deal,:collection_name => 'deals'
  layout 'internal', :only => [:send_feedback]
  before_filter :authenticate_user!, :except => :send_feedback
  before_filter :reject_disabled_users, :except => :send_feedback
  before_filter :only_allow_admins, :except => :send_feedback
  # GET /locations
  # GET /locations.xml
  def index
    @messages = Message.all

    respond_to do |format|
      format.html{render :layout=>"admin"} # index.html.erb
      format.xml  { render :xml => @messages }
    end
  end

  def new
    #~ @deals = Location.all.map {|l| {:location => l, :deals => l.deals.deal_sort}}
		#~ @nation_wide_deals=Deal.find(:all,:conditions=>['nation_wide_deal=?',true])
		#~ @all_locations_deals = []
    @deals_by_location = {}
    @total = 0

    collection.each do |deal|
      @total += 1
      #~ if all_locations_deal?(deal)# && all_location_exceptions(deal)
        #~ @all_locations_deals << deal
        #~ next
      #~ end
      deal.locations.each do |l|
        @deals_by_location[l.id] ||= {:location => l, :deals => []}
        @deals_by_location[l.id][:deals] << deal
      end
    end
    @indexed_deals = @locations.map do |l|
      @deals_by_location[l.id] || {:location => l, :deals => []}
    end
		 @deals_count =Deal.deal_sort.count
     render :layout=>"admin"
  end


  def collection
    @deals ||= end_of_association_chain.current.with_not_email_disable_site
  end

  # TODO: cleanup
  def create
    User.delay.send_daily_email(params)
    render :text => "Sending is queued"
  end

  def send_feedback
    subject = params[:subject]
    if (subject == "1" || subject == "4")
    to_address = "support@dailyd.co.il"
    elsif (subject == "2" || subject == "3")
    to_address = "b2b@dailyd.co.il"
   end
    if subject == "1"
    params[:subject] = "אני לקוח ואני מעוניין בשירות לקוחות"
    elsif subject == "2"
    params[:subject] = "אני ספק/בעל עסק ואני מעוניין בשיתוף פעולה"
    elsif subject == "3"
    params[:subject] = "אני מעוניין בשיתוף פעולה"
    elsif subject == "4"
    params[:subject] = "יש לי שאלה כללית, אני צריך/ה עזרה בבקשה"
    end
    UserMailer.send_feedback(params,to_address).deliver
    render :action => 'feedbackthankyou'
  end

end
