class PrefsController < ApplicationController
  before_filter :get_current_deals, :except => :recent_deals
  before_filter :get_user_by_md5

  layout 'internal'

  def edit
	@user=User.find_by_md5_id(params[:id]) if params[:id]
	if @user
   current_user_settings
	 set_cookies
   redirect_to home_customize_path
   end
  end

  def update
    @user.update_attributes!(params[:user])
    set_cookies unless (cookies[:email] || cookies[:user_preference])
    redirect_to root_url
  end

  def current_user_settings
		u=@user
    # take user from cookie or param
      cookies[:email] = u.email
      cookies[:filter_location_ids] = u.location_ids.uniq.join(",")
      cookies[:filter_category_ids] = u.category_ids.uniq.join(",")
      cookies[:filter_site_ids] = u.site_ids.uniq.join(",")
			cookies[:reg_user]=u.reg
    true
  end


  protected
  def set_cookies
    cookies[:user_preference] = {
      :value => @user.md5_id,
      :expires => 20.years.from_now.utc
    }
  end

end
