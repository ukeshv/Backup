class SettingsController < ApplicationController
before_filter :find_user,:only=>["user_details"]
before_filter :find_user_cookies,:only=>["follow","fav_add_terms","bought","add_reminder","change_password","details","preferences","add_follow","update_message_setting","send_code","message_setting","delete_reminder"]
skip_before_filter :get_locations_and_categories_and_sites
before_filter :get_current_deals,:only=>["forgot_password","reset_password"]

layout :select_layout

def is_it_js?
  return (request.format.js? || request.format.json?)
end

def update
	user = User.find_by_md5_id(params[:md5_id])
	params[:user][:break_from]=Date.strptime(params[:user][:break_from], '%d/%m/%Y') unless params[:user][:break_from].blank?
	params[:user][:break_to]= Date.strptime(params[:user][:break_to], '%d/%m/%Y') unless params[:user][:break_to].blank?
	params[:user][:site_ids]=[]  unless params[:user][:site_ids]
	params[:user][:location_ids]=[]  unless params[:user][:location_ids]
	params[:user][:category_ids]=[]  unless params[:user][:category_ids]
	user.update_attributes(params[:user])
	set_cookies unless (cookies[:email] || cookies[:user_preference])
	get_locations_and_categories_and_sites
#~ redirect_to home_customize_path
end

def change_password
	if @user.valid_password?(params[:old_password])
   @user.update_attributes(:password=>params[:user][:password], :password_confirmation=>params[:user][:password_confirmation])
	 @success= "הסיסמא שלך עודכנה בהצלחה"
	else
	 @error = "סיסמא שגויה, אנא נסה שנית"
	end
end

	def forgot_password
if params[:user] &&!params[:user][:email].blank?
	user=User.find_by_email_and_reg(params[:user][:email],true)
		if user
		 User.send_reset_instructions(user)
		 @success="הוראות איפוס סיסמא נשלחו לכתובת המייל שלך, אנא עקוב אחר ההוראות"
		 else
			 @error="כתובת המייל לא נמצאה, נסה שנית בבקשה"
			end
	end
end

def reset_password
if params[:user] && params[:user][:reset_password_token] &&!params[:user][:reset_password_token].blank?
	user=User.find_by_reset_password_token(params[:user][:reset_password_token])
	  if user
				user.update_attributes(:password=>params[:user][:password], :password_confirmation=>params[:user][:password_confirmation])
				if user.save
						user.update_attribute(:reset_password_token,nil);
					@success="הסיסמא עודכנה בהצלחה"
					redirect_to home_customize_path
				end
	 else
	   @error="בעיה באיפוס סיסמא, אנא בדוק כתובת מייל וסיסמא ונסה שנית"
	 end
	end
end

def find_user_with_cookies
	user=User.find_by_email(cookies[:email]) if cookies[:email]
  @from=user && user.break_from ? user.break_from.strftime("%d/%m/%Y") : nil
  @to=user && user.break_to ? user.break_to.strftime("%d/%m/%Y") : nil
	@user = user
	get_locations_and_categories_and_sites
end


def user_details
	@user.update_attributes(params[:user])
end

def preferences
	find_user_with_cookies
end
def add_follow
 if @user
		if @user.reg?
		@deal_id=params[:deal]
		render :partial=>"front/terms"
		else
		render :text=>"nofulluser"
   end
 else
	  render :text=>"nouser"
end
end

def follow
	deal=Deal.find_by_id(params[:id])
	if params[:term] && !params[:term].blank?
    	term= params[:term].split(",").delete_if {|x| x.blank? }
	   	term.each do |t|
		  terms = Follow.find_by_user_id_and_term(@user.id,t)
				unless terms && !terms.blank?
					fav=Follow.create(:user_id=>@user.id,:term=>t)
				end
			end
			render :nothing=>true
	end
end

def fav_add_terms
	if params[:term] && !params[:term].blank?
		term= params[:term].split(",").delete_if {|x| x.blank? }
		term.each do |t|
			  terms = Follow.find_by_user_id_and_term(@user.id,t)
				unless terms && !terms.blank?
				fav=Follow.create(:user_id=>@user.id,:term=>t)
				end
			end
		find_user_deals("follow")
	end
end

def delete_terms
fav=Follow.find_all_by_user_id_and_term(params[:user_id],params[:id])
fav.map{|x| x.delete} if fav
flash[:notice]="המונח נמחק בהצלחה"
redirect_to followed_deals_settings_path
end

def bought
 if @user
    if @user.reg?  && params[:default_action] == "add"
		bought=Bought.find_or_create_by_user_id_and_deal_id(:user_id=>@user.id,:deal_id=>params[:id],:email=>@user.email) if params[:id]
		render :nothing=>true
		elsif @user.reg? && params[:default_action] == "delete"
		bought_deal = Bought.find_by_user_id_and_deal_id(@user.id,params[:id])
		bought_deal.delete if bought_deal
		render :nothing=>true
		else
		render :text=>"nofulluser"
	  end
	else
		render :text=>"nouser"
  end
end

def add_reminder
	if params[:id]
		bought=Bought.find_by_user_id_and_deal_id(@user.id,params[:id])
		bought.update_attributes(:reminder_date=>Date.strptime(params[:date],'%d/%m/%Y'))
		#~ render :nothing=>true
		find_user_deals("bought")
	end
end

def delete_reminder
	if params[:id]
				bought=Bought.find_by_user_id_and_deal_id(@user.id,params[:id])
				bought.update_attribute("reminder_date",nil)
				find_user_deals("bought")
	end	
end

def delete_follow_deals
follow=Follow.find_all_by_user_id_and_deal_id(params[:user_id],params[:id])
follow.map{|x| x.delete} if follow
flash[:notice]="דיל נמחק בהצלחה"
redirect_to followed_deals_settings_path
end

def delete_bought_deals
bought=Bought.find_all_by_user_id_and_deal_id(params[:user_id],params[:id])
bought.map{|x| x.delete} if bought
flash[:notice]="דיל נמחק בהצלחה"
redirect_to favorites_settings_path
end

def followed_deals
@user=User.find_by_email_and_reg(cookies[:email],true,:include=>["follows"]) if cookies[:email]
total_deals=Deal.active.find(:all,:select=>'id').map(&:id)
	if @user
		follow_deals=@user.follows.map(&:deal_id) 
		@follow_deals= follow_deals - (follow_deals-total_deals) if follow_deals
		@terms = @user.follows.map(&:term).compact.uniq 
	end
end

def favorites
 if params[:md5_id]
	@user=User.find_by_md5_id(params[:md5_id])
	current_user_settings(@user)
	set_cookies
end
@bought_deal=params[:b] 
@follow_deal=params[:f]
@user=User.find_by_email_and_reg(cookies[:email],true,:include=>["boughts"]) if cookies[:email]
@bought_deals=@user.boughts.uniq.map(&:deal_id) if @user
end


def send_code
	if params[:terms]
		@mes_setting=(params[:message_option]=="SMS and Email") ? "SMS_Email" : params[:message_option]
		if params[:phone] && params[:phone]=~/^[0-9]{8}$/ 
		 @phone = "05" + params[:phone]
		 #~ user_phone = User.find_by_phone_for_sms(@phone)
		 user_phone = User.check_user_in_pool(@phone)
			 if (user_phone==1)
				@result = 1
				@message = true
			 else
				@result = User.send_request_to_micropay(@phone)
			 end
		else
		 @result = 1
	 end
	else
	@terms_error = true
	end
end

def complete_registration
	@user = User.find_by_email(cookies[:email])
  res = @user.complete_sms_registration(params[:phone],params[:code])
	if res==0
		@user.update_attribute("message_option",params[:mes_setting])
		@user.update_attribute("phone",params[:phone])
		@user.update_attribute("message_settings_enabled",true)
		flash[:success] = "ההגדרות שלך עודכנו בהצלחה"
		@error = false
	else
		@error= true
	end
end

def update_message_setting
	if params[:message_option]
		params[:message_option]=(params[:message_option]=="SMS and Email") ? "SMS_Email" : params[:message_option]
		m_o = @user.message_option
		if m_o && (m_o == "SMS" || m_o =="SMS_Email")
			@user.delete_user_from_pool
			@user.update_attribute("phone_for_sms",nil)
		end
		@user.update_attribute("message_option",params[:message_option])
		@user.update_attribute("message_settings_enabled",true)
		@message=@user.message_option=="Email" ? "nothing" : "show_phone"
		flash[:success] = "ההגדרות שלך עודכנו בהצלחה"
	end
end

def message_setting
	type=params[:type]
	 if ((type=="SMS") || (type=="setting")) 
		render :partial=>"message_phone_form",:locals=>{:type=>params[:type]}
	 elsif ((type == "SMS_Email") || (type=="SMS and Email"))
		if (type=="SMS and Email")
			type="SMS_Email"
		end
		render :partial=>"message_phone_email_form",:locals=>{:type=>type}
	elsif type=="Email" 
		render :partial=>"message_form",:locals=>{:type=>params[:type]}
	end	 
end

# To move the followed deals to bought

def mark_as_bought
	deals = Follow.find_all_by_user_id_and_deal_id(params[:user_id],params[:id])
	if deals
	 deals.map{|x| x.delete}
	 Bought.find_or_create_by_user_id_and_deal_id_and_email(:user_id=>params[:user_id],:deal_id=>params[:id],:email=>params[:email])	
 end
 flash[:success] = "הדיל התווסף לרשימת 'שוברים שרכשתי' בהצלחה"
 redirect_to "/settings/followed_deals"
end




def current_user_settings(u)
    # take user from cookie or param
      cookies[:email] = u.email
      cookies[:filter_location_ids] = u.location_ids.uniq.join(",")
      cookies[:filter_category_ids] = u.category_ids.uniq.join(",")
      cookies[:filter_site_ids] = u.site_ids.uniq.join(",")
			cookies[:reg_user]=u.reg
    true
end
	

protected

def set_cookies
	cookies[:user_preference] = {
	:value => @user.md5_id,
	:expires => 20.years.from_now.utc
	}
end

def find_user
	@user=User.find_by_id(params[:id])
end

def find_user_cookies
	@user=User.find_by_email(cookies[:email]) if cookies[:email]
end

def find_user_deals(type)
	find_user_settings
		if type=="follow"
		render:partial=>"follow",:locals=>{:follow_deals=>@follow_deals,:terms=>@terms,:user=>@user}
	elsif type=="bought"
		render :partial=>"bought",:locals=>{:bought_deals=>@bought_deals,:user=>@user}
	end
end


private

def select_layout
  if (action_name == "forgot_password" || action_name == "reset_password")
    return "application"
  else
    return "internal"
  end
end


end
