class SubscriptionsController < ApplicationController
layout "application"
before_filter :get_user_by_md5, :only => :disable
skip_before_filter :verify_authenticity_token, :only => :create
#~ layout "recentdeals",:only=>["new","create"]
before_filter :check_for_user_existence,:current_user_settings,:only=>:new


def check_for_user_existence
	email = cookies[:email]
  if email && !email.blank?
    user = User.find_by_email(email)
    if user && user.reg?
			flash[:success] = "אתה כבר משתמש רשום במערכת, להרשמת משתמש נוסף, אנא צא מהמערכת"
      redirect_to "/settings/preferences"
    else
      return true
    end
  end
end

def new
	@deal_bought=params[:b]
	@deal_follow=params[:f]
	@user=User.find_by_email_and_reg(cookies[:email],true) if cookies[:email]
end

def new_fb_user
 cookies[:facebook_user_email] = params[:email]
 create
end

def create_facebook_user
	unless params[:error]
		access_token = fb_client.authorize(:code => params[:code])
		session[:facebook_id] = fb_client.me.info['id']
		cookies[:facebook_user_email] = fb_client.me.info['email']
		session[:facebook]="facebook"
		create
	else
		flash[:error] = "Please check the app settings for facebook"
		redirect_to "/"
	end
end

def create	
	if params[:email] &&  !params[:email].blank?
		email = params[:email].strip.downcase
		reg_val = true #newly added
	elsif params[:user] && params[:user][:email] &&  !params[:user][:email].blank?
		email = params[:user][:email].strip.downcase
		reg_val = params[:user][:reg] if params[:user] && params[:user][:reg]#newly added
	elsif cookies[:facebook_user_email] && cookies[:facebook_user_email] != "null"
		email = cookies[:facebook_user_email]
		reg_val = true #newly added
	#~ session[:facebook_user_email] = nil
	end
	email.gsub!(/[\s\/\\,|<>]/, '') if email
	#TODO: add params check here to handle save settings
	if email.blank? or (email  =~/^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/)==nil
	#~ set_user
		render :action => 'illegal_address'
		return
end
	@new_user = User.find_or_initialize_by_email(email)
	@new_user.reg= reg_val if reg_val#newly added
  @new_user.fb_user=true if	cookies[:facebook_user_email]		#newly addedn for fb user
	@new_user.disabled = false
	set_selected_filters if "true" == params[:override]
	new_user = @new_user.new_record?
	@new_user.save(:validate => false)
	cookies[:email] = @new_user.email
	set_cookies
	if new_user
		@new_user.update_attributes(params[:user]) #newly added
		cookies[:settings_saved] = "true" if "true" == params[:override]
		verify_full_user_signup
		return
	else
		redirect_to root_path
	return
	end
end


def verify_full_user_signup
		if @new_user.reg? 
		save_coupons 
		else
		redirect_to successful_registration_path(@new_user)
		end	
end

#~ def login
	#~ @new_user=User.find_by_email_and_reg(params[:user][:email],true)
	#~ if (@new_user && !@new_user.valid_password?(params[:user][:password]))
		#~ flash[:error]="Incorrect password"
		#~ params[:settings] ? (redirect_to :back) : (redirect_to home_customize_path)
	#~ elsif @new_user.blank?
		#~ flash[:error]="You have not yet registered with password"
		#~ params[:settings] ? (redirect_to :back) : (redirect_to home_customize_path)
	#~ else
		#~ set_cookies
		#~ redirect_to root_path
	#~ end
#~ end
def login
@new_user=User.find_by_email_and_reg(params[:user][:email],true)
	if @new_user 
		if @new_user.fb_user?
			flash[:error]="נראה שאתה כבר רשום עם סיסמא"
			destination_url
		 elsif (!@new_user.valid_password?(params[:user][:password]))
		  flash[:error]="סיסמא שגויה"
			destination_url
			else
		 cookies[:email] = @new_user.email
		 set_cookies
		 if (params[:deal_bought] && !params[:deal_bought].blank?)
			deal = Bought.find_by_user_id_and_deal_id(@new_user.id,params[:deal_bought])
			unless deal
			Bought.create(:user_id=>@new_user.id,:deal_id=>params[:deal_bought],:email=>@new_user.email)
			end
			 #~ Bought.create(:user_id=>@new_user.id,:deal_id=>params[:deal_bought]) 
		 cookies[:bought]=params[:deal_bought]
		redirect_to root_path
		return
	 end
		if (params[:deal_follow] && !params[:deal_follow].blank?)
		 cookies[:follow]=params[:deal_follow]
		@new_user.message_settings_enabled ?  (redirect_to root_path) : (redirect_to "/settings/followed_deals")
     return
		end
 		 redirect_to :back
    end
	else
		flash[:error]="אתה עדיין לא נרשמת עם סיסמא"
		destination_url
	end
end

def fb_create


end


def destination_url
  if params[:settings]
		redirect_to :back
	else
		if params[:deal_follow] && !params[:deal_follow].blank? 
		redirect_to home_customize_path(:f=>params[:deal_follow] )
		elsif params[:deal_bought] && !params[:deal_bought].blank?
		redirect_to home_customize_path(:b=>params[:deal_bought] )
		else
		redirect_to home_customize_path
		end
 end
end


def full_registration
	@new_user = User.find_by_email_and_reg(params[:user][:email],false)
	@deal_bought=params[:deal_bought]
	@deal_follow=params[:deal_follow]
		if @new_user
		@new_user.update_attributes(params[:user])
	  set_cookies
		cookies[:email]=@new_user.email
		save_coupons  
		#~ redirect_to root_path
	else
		create
	end
end

def save_coupons
	if @deal_bought && !@deal_bought.blank?
		deal = Bought.find_by_user_id_and_deal_id(@new_user.id,@deal_bought)
		unless deal
		Bought.create(:user_id=>@new_user.id,:deal_id=>@deal_bought,:email=>@new_user.email)
		end
    flash[:success]="שלום ותודה שהצטרפת לדיילי די, הדיל נוסף לאיזור האישי שלך תחת 'שוברים שרכשתי'"
		redirect_to "/settings/favorites" 
	elsif @deal_follow && !@deal_follow.blank?
    flash[:success]="שלום ותודה שהצטרפת לדיילי די, כעת תוכל להשלים את ההרשמה לשירות 'דיל אישי'"
		redirect_to "/settings/followed_deals" 
	else 
   flash[:success]="נרשמת בהצלחה" 
	 redirect_to "/settings/preferences"
	 end		
end


def disable
	@user.update_attributes(:disabled => true)
	redirect_to home_bye_url
end

def successful_registration
	@new_user=User.find_by_id(params[:user])			
end

protected
def set_cookies
	cookies[:user_preference] = {
	:value => @new_user.md5_id,
	:expires => 20.years.from_now.utc
	}
end

def set_user(is_new = true)
	if params[:email] && !params[:email].blank?
		@new_user = User.new(params[:email])
	elsif params[:user] && params[:user][:email] &&  !params[:user][:email] .blank?			
		@new_user = User.new(params[:user].slice(:email))
	elsif cookies[:facebook_user_email]
		@new_user = User.new(cookies[:facebook_user_email])
	end
	set_selected_filters
end

def set_selected_filters
	filter_location_ids = (params[:location_ids] || "").split(/,/)
	filter_category_ids = (params[:category_ids] || "").split(/,/)
	filter_site_ids = (params[:site_ids] || "").split(/,/)

	@new_user.location_ids = filter_location_ids
	@new_user.site_ids = filter_site_ids
	@new_user.category_ids = filter_category_ids
end

def fb_client
	@client ||= FacebookOAuth::Client.new(
	:application_id => FACE_BOOK['app_id'],
	:application_secret => FACE_BOOK['secret_key'],
	:callback => format_url("subscriptions/create_facebook_user/")
	)
end

def format_url(callback_url)
	return "http://#{request.env['HTTP_HOST']}/#{callback_url}"
end

def current_user_settings#newly added
# take user from cookie or param
	u_md5 = params[:md5_id] || cookies[:user_preference]
	if u_md5 && u = User.find_by_md5_id(u_md5)
		cookies[:email] = u.email
		cookies[:filter_location_ids] = u.location_ids.uniq.join(",")
		cookies[:filter_category_ids] = u.category_ids.uniq.join(",")
		cookies[:filter_site_ids] = u.site_ids.uniq.join(",")
	end
	true
end


end
