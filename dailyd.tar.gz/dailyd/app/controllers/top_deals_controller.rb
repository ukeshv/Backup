class TopDealsController <  InheritedResources::Base
	layout "admin"
	defaults :resource_class => Deal, :collection_name => 'deals'
  actions :index
	before_filter :authenticate_user!,:reject_disabled_users,:only_allow_admins,:load_deals
  #~ caches_action :index
	#~ application_controller

	def index
    index! do |format|
      format.html
      format.xml
      #http://dailyd.co.il/?format=json
      #http://dailyd.co.il/?format=json&md5_id=FOOBAR
      #~ format.json { render :json => @deals.collect(&:to_iphone_hash) }
    end
  end

  def create
    params[:position] && params[:position].each_pair do |k,v|
			#~ unless v.blank?
				d = Deal.find_by_id(k)
        d.update_attribute('position',v)
			#~ end
    end

    redirect_to top_deals_path, :flash=>{:notice=>"עמדות מבצעים עודכנו בהצלחה"}
   end

	protected

	def load_deals
    #~ @all_locations_deals = []
    #~ @deals_by_location = {}
    #~ @total = 0

    #~ collection.each do |deal|
      #~ @total += 1
      #~ if all_locations_deal?(deal)
        #~ @all_locations_deals << deal
        #~ next
      #~ end
      #~ deal.locations.each do |l|
        #~ @deals_by_location[l.id] ||= {:location => l, :deals => []}
        #~ @deals_by_location[l.id][:deals] << deal
      #~ end
    #~ end
    #~ @indexed_deals = @locations.map do |l|
      #~ @deals_by_location[l.id] || {:location => l, :deals => []}
    #~ end
     #~ @deals =collection.sort_by{|x| x.position.blank? ? 0 : x.position}
		@top_deals =collection.select{|x|  x.position!=nil}.sort_by{|x|x.position}
		@deals =collection-@top_deals
  end

  def collection
    @deals ||= end_of_association_chain.current
  end

	  def reject_disabled_users
    if current_user.disabled?
      flash[:alert] = 'Unauthorized access.'
      redirect_to :controller => :home, :action => :index
    end
  end

  def only_allow_admins
    unless current_user and current_user.admin?
      flash[:alert] = 'Unauthorized access.'
      redirect_to :controller => :home, :action => :index
    end
  end

end
