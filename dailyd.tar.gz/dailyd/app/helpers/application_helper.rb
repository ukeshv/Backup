module ApplicationHelper

def javascript(*args)
  content_for(:head) { javascript_include_tag(*args) }
end

  def deal_click_link(deal, fb = false)
    lnk = "#{APP_CONFIG['site_url']}clicks/new?id=#{deal.id}"
    lnk << "&fb=true" if fb
    lnk
  end

  def more_text(count)
    " <span style='color:#060;font-size:18px'>#{count}</span> "
  end

  def more_deals_link(location,md5_id)
    text = if 1 == location[:more_count]
     "ישנו עוד" + more_text(location[:more_count]) + "דיל יומי"
    else
      "ישנם עוד" + more_text(location[:more_count]) + "דילים יומיים"
    end
    text << " "<< "באיזור #{location[:location].name}, #{link_to("לחצו כאן", "http://dailyd.co.il/?location=#{location[:location].id}&md5_id=#{md5_id}")} על מנת לראות את כל הדילים היומיים  באיזור זה" << "<br/><br/>"
  end

  def select_site(field_name = "site", selection = nil)
    opts = options_for_select(["all", "All"] + Site.all.map{|s| [s.name, s.id]}, selection)
    select_tag(field_name, opts)
  end

  def get_unique_clicks_count(deal)
    deal_users = deal.clicks.select('user_id').map(&:user_id).compact
    unique_clicks_hash ={}
    deal_users.map{|x| unique_clicks_hash[x]=deal_users.count(x)}
    unique_clicks_hash = unique_clicks_hash.reject{|k,v| v<=1 }
    #~ is_unique_click_present = unique_clicks_hash.values.select{|x| x>1}.length>0
    is_unique_click_present = unique_clicks_hash.length > 0
    return [is_unique_click_present,unique_clicks_hash]
  end


def find_deal_address(location,deal)
	address_arr = deal.addresses
	loc = Location.find_by_name(location)
	if deal.nation_wide_deal
	return address_arr.first.try(:address)
	else
	add_ids = address_arr.map(&:id)
	addr_id = AddressLocation.find(:all,:conditions=>["location_id = ? and address_id in (?)",loc.try(:id),add_ids],:limit=>1).first.try(:address_id)
	return Address.find_by_id(addr_id).try(:address)
	end
end

def user_settings(cooki_email)
return path
end


def find_date(deal,user)
	reminder=Bought.find_by_user_id_and_deal_id(user,deal).reminder_date
	date= reminder ? reminder.strftime("%d/%m/%Y") : nil
 return date
end

def banner_link(link)
	(link[0..6] == "http://") ? link : ("http://"+link)
end

def find_user_bought(deal_id,bought_ids)
	return bought_ids ? (bought_ids.include?(deal_id) ? "buy_link active" : "buy_link") : "buy_link"
end


def hebrew_date
  t= Date.today
  months = ["ינואר" ,"פברואר" , "מרץ" , "אפריל" , "מאי","יוני","יולי" ,"אוגוסט" ,"ספטמבר" ,"אוקטובר" ,"נובמבר" ,"דצמבר" ]  
  days = ["יום ראשון", "יום שני", "יום שלישי", "יום רביעי", "יום חמישי", "יום שישי", "יום שבת"]
  
  return "#{days[t.wday]}, #{t.day} #{months[(t.month) - 1] },#{t.year}"
end


def site_login_page(site)
 return (site && site.login_page?) ? site.login_page : site.url
end


end
