module BannersHelper
end
