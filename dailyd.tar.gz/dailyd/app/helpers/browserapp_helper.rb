module BrowserappHelper
end
