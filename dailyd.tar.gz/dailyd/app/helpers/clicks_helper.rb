module ClicksHelper
end
