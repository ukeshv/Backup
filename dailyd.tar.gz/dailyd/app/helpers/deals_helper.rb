module DealsHelper
def getlocation(addr_id)
	unless addr_id.blank?
		addr_loc=AddressLocation.find_by_address_id(addr_id)
		if addr_loc.nil?
			loc_name=nil
		else
	   loc_name=Location.find_by_id(addr_loc.location_id )#.name if loc_id
		end
		return loc_name
		end
end
end

