module FrontHelper
  def deal_filter(deal)
    filter_string = "#{deal.locations.map {|l| "location_#{l.id}"}.join(" ")} site_#{deal.site_id} #{deal.categories.map {|l| "category_#{l.id}"}.join(" ")}"
  end


def change_collection_order_old(deals,location_id,all_location_deals)
                all_loc_deal = all_location_deals.map(&:deal_locations)
    top_deals=deals.map(&:deal_locations)
                total_deals=(all_loc_deal+top_deals).flatten.select{|x| (!x.position.nil? && x.location_id==location_id)}.sort_by{|x| x.position}.map(&:deal)
    deals.reject!{|x| total_deals.map(&:id).include?(x.id)}
    deals_collection  = deals.group_by(&:site_id) if (deals&&deals.length > 0)

    if deals_collection && deals_collection.length > 0
      deals = []
      (0.. (deals_collection.values.map(&:count).max-1)).each do |y|
        deals_collection.each do |k,v|
          deals << v[y] unless total_deals.include?(v[y])
        end
      end
    end
  return (total_deals+deals).compact
end


  def change_collection_order(deals,location_id,all_location_deals)
		all_loc_deal = all_location_deals.map(&:deal_locations)
    top_deals=deals.map(&:deal_locations)
		total_deals=(all_loc_deal+top_deals).flatten.select{|x| (!x.position.nil? && x.location_id==location_id)}.sort_by{|x| x.position}.map(&:deal)
    deals.reject!{|x| total_deals.map(&:id).include?(x.id)}
		deals_id=deals.map(&:id)
		all_deals=[]
		sites= Site.find(:all).sort_by{|x|x.sort_order}.map(&:id)
		@sites_order= Site.find(:all).sort_by{|x|x.sort_order}.map(&:sort_order)
		deals_hash  = deals.group_by(&:site_id)
		sites_order_uniq=@sites_order.uniq
		sites_order_uniq.each do |o|
			if @sites_order.count(o) > 1
			@same_order_deals_hash=Hash.new()
				same_order_sites=Site.find(:all,:conditions=>['sort_order=?',o])
					same_order_sites.each do |s|
					 select_deals=[]
						select_deals=deals_hash.select{|key,values|key==s.id}.flatten
						 site_id=select_deals[0]
						 select_deals.reject!{|item|item==site_id}
						@same_order_deals_hash[site_id]=select_deals
					end
				 same_order_deals=[]
					unless @same_order_deals_hash.empty?
					(0.. (@same_order_deals_hash.values.map(&:count).max-1)).each do |y|
								@same_order_deals_hash.each do |k,v|
									same_order_deals << v[y]
								end
							end
					end
					all_deals<<same_order_deals.compact
			else
				s=Site.find_by_sort_order(o)
				site_deals=Deal.find(:all,:conditions=>["site_id=? and id in (?)",s.id,deals_id])
				all_deals<<site_deals
     	end
  end
return (total_deals+all_deals.flatten).compact
end

#~ def find_deal_address(location,deal,all_locs)
	#~ if all_locs==true
	#~ addr=deal.addresses.map(&:id)	if deal && deal.addresses
	#~ else
	#~ current_loc_addresses=Location.find_all_by_name(location).map(&:addresses).flatten.map(&:id)
		#~ unless deal.locations.map(&:id).uniq.count==1
		#~ deal_addr=deal.deal_addresses.map(&:address_id)
		#~ all_addr=deal_addr+current_loc_addresses
		#~ addr=all_addr.select{|x| all_addr.grep(x).count > 1}.uniq
		#~ else
			#~ unless deal.addresses.empty?
			#~ addr=deal.addresses.first.id.to_a
			#~ end
		#~ end
	#~ end
  #~ return addr
#~ end

def find_all_location_deal_position(deal,location)
	location_id = Location.find_by_name(location).id
	return DealLocation.where("deal_id =? and location_id = ? and position is not null",deal.id,location_id).empty? ? false : true
end

def find_nation_wide_address(deal,location_id)
addr = AddressLocation.find(:all,:conditions=>['location_id = ? and address_id in (?)',location_id,deal.deal_addresses.map(&:address_id)]).first.try(:address_id)
address = Address.find_by_id(addr).try(:address)
return address ? address : "לא זמין"
end

end
