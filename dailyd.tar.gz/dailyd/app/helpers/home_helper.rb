module HomeHelper
  def current_md5_user
    @current_user ||= User.find_by_md5_id(params[:md5_id]) || User.find_by_md5_id(cookies[:user_preference])
  end
end
