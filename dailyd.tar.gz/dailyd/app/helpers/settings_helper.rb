module SettingsHelper
def find_gender(user)
	if user.gender?
	%w{Male Female}
	else
	%w{Gender Male Female}
  end
end

def verify_user_message_setting(user)
	if user.message_settings_enabled?
		return true
	else
		return false
 end
end

end
