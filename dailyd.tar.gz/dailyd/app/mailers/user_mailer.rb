class UserMailer < ActionMailer::Base
  helper :application
  default :from => "deals@dailyd.co.il"

  def import_stats(stats)
    text = ""
    stats.each do |k, v|
      text << k.to_s << ": #{v.inspect}\n"
    end
    mail :to => "roy.zinn@gmail.com,viviergas@gmail.com,mars@railsfactory.org,mariammal.moorthi@sedin.co.in" do |format|
      format.text {render :text => text }
    end
  end

  def send_daily_email(user, locations, only_testing)
	 @user = user
    @locations = locations
    mail(:to => user.email, :subject => "המייל היומי - דיילי די")
  end

  # Method to send reminder of bought deals

  def send_reminder(user, deals)
    @user = user
    @deals = deals
    mail(:to => user.email, :subject => "מייל תזכורת מדיילי די")
  end

  # Method to send mail regarding follow terms

  def send_follow_mail(user, deals)
    @user = user
    @deals = deals
    mail(:to => user.email, :subject => "דיילי די - דיל שחיפשת")
  end

  def send_welcome(user)
    @user = user
    mail(:to => @user.email, :subject => 'ברוכים הבאים לדיילי די')
  end

  def send_feedback(form_params,to_addr)
    @form_params = form_params
    mail(:to => to_addr, :subject => 'הודעה ממשתמש')
  end

   def send_reset_instructions(user)
		@user=user
    mail(:to => user.email, :subject => 'הוראות איפוס סיסמא - דיילי די')
  end

  def sending_status(counters)
    @counter = counters
    mail :to => "roy.zinn@gmail.com,viviergas@gmail.com,mars@railsfactory.org,mariammal.moorthi@sedin.co.in" do |format|
      format.text {render :text => "Success: #{@counter['success']}, Failed: #{@counter['failure']}"}
    end
  end


end
