class Address < ActiveRecord::Base
	has_many :deal_addresses
  has_many :deals, :through => :deal_addresses
	has_many :address_locations
	has_many :locations,:through=>:address_locations

end
