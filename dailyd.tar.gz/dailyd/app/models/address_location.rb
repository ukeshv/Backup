class AddressLocation < ActiveRecord::Base
	#~ has_many :address
  #~ has_many :location
	belongs_to :address
	belongs_to :location
end
