class Banner < ActiveRecord::Base

  has_attached_file :photo,
                    :styles => { :small => "100x150>" },
                    :storage => :s3,
                    :s3_credentials => "#{RAILS_ROOT}/config/amazon_s3.yml",
                    :path => ":attachment/:id/:style.:extension",
                    :bucket => S3_CONFIG[:bucket_name]

end
