class Category < ActiveRecord::Base
  validates :name, :presence => true, :uniqueness => true

  has_many :deal_categories
  has_many :deals, :through => :deal_categories

  has_many :user_categories, :dependent => :destroy
  has_many :users, :through => :user_categories

  # After we create a category, every existing user should have this
  # category selected for their daily e-mail blast.  They can always
  # turn it off by going to the preferences page.
  after_create :all_users_get_new_category

  def all_users_get_new_category
    User.transaction do
      User.find(:all,:select=>"id").each do |user|
        #~ logger.warn "Adding '#{self.name}' to user ID '#{user.id}', e-mail address '#{user.email}'"
        user.categories << self
      end
    end
  end

  def to_iphone_hash
    {
      :name => name,
      :id => id
    }
  end
  
    
  def to_iphone_hash_new
    {
      :name => name,
      :id => id,
      :deals_count => Deal.active.includes(:categories).where("categories.id in (?)",[self.id]).count
    }
  end
		
  def to_iphone_hash_for_location(location_id)
	{
	:name =>name,	
	:id => id,
	:count => Deal.active.includes(:locations,:categories).where("categories.id = ? and locations.id = ?",self.id,location_id).count
	}
  end
  
end
