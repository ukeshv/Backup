class Click < ActiveRecord::Base
  belongs_to :deal
  belongs_to :user

  validates :deal_id, :presence => true
  scope :during, lambda {|from, to| where("clicks.created_at >= ? AND clicks.created_at < ?", from, to)}
  scope :for_site, lambda {|site_ids| where("sites.id in (?)", site_ids).includes(:deal => :site)}

  def deal_url
    deal.url
  end

end
