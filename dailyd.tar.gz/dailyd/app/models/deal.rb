# coding: utf-8
class Deal < ActiveRecord::Base
   require 'net/http'
   require 'net/https'
  require 'uri'
  require 'json'
  serialize :latitudes
  serialize :longitudes

  validates :url, :presence => true
  validates :title, :presence => true
  validates :description, :presence => true
  validates :starts_at, :presence => true
  validates :ends_at, :presence => true
  validates :suggested_location, :presence => true

  validates_format_of :url, :with => /^http/, :message => "does not look like a legal URL"

  validates_presence_of :site_id
  validates_presence_of :value
  validates_presence_of :discount_percentage
  validates_presence_of :address

  validates_numericality_of :value, :greater_than_or_equal_to => 0
  validates_numericality_of :discount_percentage, :greater_than => 0, :less_than => 100
  validates_numericality_of :amount_saved, :greater_than => 0

  belongs_to :location
  belongs_to :site

  has_many :clicks
  has_many :messages

  has_many :deal_categories
  has_many :categories, :through => :deal_categories
	has_one :bought
  has_many :deal_locations
  has_many :locations, :through => :deal_locations
  has_many :deal_addresses
  has_many :addresses, :through => :deal_addresses

  has_many :imported_deals
  has_many :favorites

  validate :check_for_at_least_one_location
  validate :check_for_at_least_one_category

  scope :deals_no_image, where('? between starts_at and ends_at and (in_local=? or in_local is NULL)',Time.now,false)

  scope :active, lambda {with_not_disabled_site.where(["starts_at <= ? and ends_at >= ? ", Time.now, Time.now])}
  scope :with_includes, includes(:site, :categories, :locations)
  scope :ordered, includes('site').order("sites.sort_order ASC, deals.created_at DESC")

  scope :current, lambda { includes(:site, :categories, :locations).order("sites.sort_order ASC, deals.created_at DESC").active }
  scope :deal_sort, lambda { includes(:site, :categories, :locations).order("deals.created_at DESC").active }
  scope :with_not_disabled_site, includes("site").where("not sites.is_disabled")

  #Added for Email Disabled Functionality

  scope :with_not_email_disable_site, includes("site").where("not sites.is_email_disabled")

  #End

  scope :old, lambda { includes('site').order("sites.sort_order ASC, deals.created_at DESC").where(["deals.ends_at <= ?", Time.now]) }
  scope :for_category, lambda {|c| includes('categories').where('categories.id = ?', c.id)}
  scope :for_site, lambda {|s| where('site_id = ?', s.id)}
  scope :for_location, lambda {|l| includes('locations').where('locations.id = ?', l.id)}

  scope :by_locations, lambda {|l_ids| includes('locations').where('locations.id in (?)', l_ids.to_s.split(","))}
  scope :by_categories, lambda {|c_ids| includes('categories').where('categories.id in (?)', c_ids.to_s.split(","))}
  scope :by_sites, lambda {|s_ids| where('deals.site_id in (?)', s_ids.to_s.split(","))}

  scope :by_filter, lambda {|l_ids,c_ids,s_ids| includes(:locations,:categories,:site).where('locations.id in (?) or categories.id in (?) or sites.id in (?)', l_ids, c_ids, s_ids)}

  scope :ordered_by_location, includes('locations').order('locations.id ASC')

  scope :search, lambda {|d| where('title LIKE (?) or description LIKE (?) or url LIKE (?)', "%#{d}%", "%#{d}%", "%#{d}%")}

  has_attached_file :photo, :path_prefix => 'public/system/property_photos'


  has_attached_file :photo, :path_prefix => 'public/system/property_photos'

  def working_picture_url
    if photo.exists?
      "http://dailyd.co.il#{photo.url}"
    else
      picture_url
    end
  end

  def amount_to_pay
    (value - amount_saved).to_i
  end

  def short_description
    description[0..800] + '...'
  end

  def image_alt
    "#{title}, #{amount_to_pay.to_i}"
  end

  def is_current?
    (starts_at <= Time.now) and (ends_at >= Time.now)
  end

  def deal_url
    deal.url
  end

  def deal_id
    deal.id
  end

  def user_email
    user.email
  end

  def user_id
    user.id
  end

  def title_with_price
    "#{title} ב-₪#{amount_to_pay.to_i}  במקום ₪#{value.to_i}"
  end

  def self.current_by_location
    Location.all.inject({}) { |h, k|  h[k.id] = k.deals.current.with_not_email_disable_site.collect(&:id); h}
  end

  def self.current_by_id
    current.includes("categories").index_by &:id
  end


 def to_iphone_hash
    if self.nation_wide_deal?
      lats,longs = -1,-1
    else
      lats,longs = self.latitudes,self.longitudes
    end
    {
      :source => site.url,
      :title => title,
      :description => description,
      :image_url => working_picture_url,
      :deal_url => "http://dailyd.co.il/clicks/new?id=#{id}&from=iphone",
      :value => value.to_i,
      :price => amount_to_pay.to_i,
      :save => discount_percentage.to_i,
      :locations => locations.collect{|x| x.to_deal_iphone_hash(self)},
      :categories => categories.collect(&:to_iphone_hash),
      :sites => site.is_disabled? ? nil : site.to_iphone_hash ,
      #~ :address => address,
      :ends_at => ends_at,
      :latitude => lats,
      :longitude => longs
    }
  end


 def self.parse_response(address)
  begin
    puts "processing address-----#{address}-----------"
    uri = URI.parse(URI.encode("http://www.waze.co.il/WAS/mozi?q=#{address}&token=b59ee5a3-290c-45fa-83af-75731e9b4c7d&lon=34.7898&lat=32.08676"))
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true if uri.scheme == "https"  # enable SSL/TLS
    request = Net::HTTP::Get.new(uri.request_uri)
    response = http.request(request)
    parsed_response =  JSON.parse(response.body)
    longitude = parsed_response[0]['location']['lon']
    latitude = parsed_response[0]['location']['lat']
    return [latitude,longitude]
  rescue =>e
    puts "error in connection--------------------------------------#{e}"
  end
 end

  def image_url
    if photo.exists?
      photo.url
    else
      in_local && image_name ? "http://#{S3_CONFIG[:bucket_name]}.s3.amazonaws.com/public/attachments/#{id}/#{image_name}" : (picture_url ? picture_url : "default.jpg")
    end
  end

  def self.get_lat_lng(deal_id)
    d = Deal.find_by_id(deal_id)
    lat_arr,lng_arr = [],[]
    d.addresses.each do |x|
      addr = x.address
      next if addr.blank?
      res  = parse_response(addr)
      puts "Fetching latitude & longitude..............."
      lat_arr << res[0]
      lng_arr << res[1]
    end
    d.latitudes = lat_arr
    d.longitudes = lng_arr
    d.save
  end

  private
  def check_for_at_least_one_category
    errors.add(:base,"You must choose at least one category.") if categories.empty?
  end


  def check_for_at_least_one_location
    errors.add(:base,"You must choose at least one location.") if locations.empty?
  end


end


