class DealAddress < ActiveRecord::Base
	belongs_to :deal
	belongs_to :address
end
