class DealCategory < ActiveRecord::Base
  belongs_to :deal
  belongs_to :category

  validates_presence_of :deal_id
  validates_presence_of :category_id

  validates_numericality_of :deal_id
  validates_numericality_of :category_id
end
