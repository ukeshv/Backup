class DealLocation < ActiveRecord::Base
  DEFAULT=20
  belongs_to :deal
  belongs_to :location

  validates_presence_of :deal_id
  validates_presence_of :location_id

  validates_numericality_of :deal_id
  validates_numericality_of :location_id

  scope :find_deals_from_location,lambda {|deal_ids,location_id| where(["deal_id IN (?) and location_id = ? ", deal_ids, location_id])}

  def position_order
    position ? position : DEFAULT
  end
end
