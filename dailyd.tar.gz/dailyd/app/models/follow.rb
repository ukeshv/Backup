require 'net/http'
require 'uri'
class Follow < ActiveRecord::Base
belongs_to :user

#~ validates :user_id, :uniqueness => {:scope => [:deal_id,:term]}

def self.mail_to_followers
	@sms_users = []
	#Fetching all users
	users = User.includes("follows")
	#Processing each user
	users.each do |user|
	#Check for users message_option
		if user.message_option == "SMS"
			#~ sms_users << user
			create_follows_for_sms_user(user)
		elsif user.message_option == "Email"
			create_follows_and_mail(user)
		elsif user.message_option == "SMS_Email"
			#~ sms_users << user
			create_follows_and_mail(user)
		end
	end
	if @sms_users.length > 0
		schedule_sms(@sms_users)
	end
end

#Method to find the deals for users and send mail

def self.create_follows_and_mail(user)
	terms = user.follows.map(&:term).compact.uniq.map{|x| "locate(\"#{x}\",title) or locate(\"#{x}\",description)"}*" or "
	unless terms.blank?
	deals = Deal.find_by_sql("select * from deals where created_at >= DATE_SUB(now(),INTERVAL 24 HOUR) and (#{terms});")
	deal_ids = deals.map(&:id)
	if deal_ids && deal_ids.length > 0
		if user.message_option == "SMS_Email"
		@sms_users << user
		end
		db_values = deal_ids.map{|x| "(#{x},#{user.id})"}*","
		ActiveRecord::Base.connection.execute("insert into follows(deal_id,user_id) values#{db_values}")
		UserMailer.send_follow_mail(user,deals).deliver
	end
 end
end

# Send SMS

def self.schedule_sms(users)
	phone_list = users.map(&:phone_for_sms).compact.join(",")
	unless phone_list.blank?
		uri = URI.parse(URI.encode("http://www.micropay.co.il/ExtApi/ScheduleSms.php?get=1&uid=2161&un=dail&msg= בוקר טוב, המוצר/בית-עסק שחיפשת עכשיו באיזור האישי שלך בדיילי-די&rb=17266&list=#{phone_list}&ne=roy@dailyd.co.il&dh=09&di=30&dy=#{Date.today.year}&dm=#{Date.today.month}&dd=#{Date.today.day}&charset=utf-8&from=4949"))
		http = Net::HTTP.new(uri.host, uri.port)
		request = Net::HTTP::Get.new(uri.request_uri)
		response = http.request(request)
	end
end


#Method to find the deals for sms users

def self.create_follows_for_sms_user(user)
	terms = user.follows.map(&:term).compact.uniq.map{|x| "locate(\"#{x}\",title) or locate(\"#{x}\",description)"}*" or "
	unless terms.blank?
	deals = Deal.find_by_sql("select id from deals where created_at >= DATE_SUB(now(),INTERVAL 24 HOUR) and (#{terms});")
	deal_ids = deals.map(&:id)
	if deal_ids && deal_ids.length > 0
		@sms_users << user
		db_values = deal_ids.map{|x| "(#{x},#{user.id})"}*","
		ActiveRecord::Base.connection.execute("insert into follows(deal_id,user_id) values#{db_values}")
	end
 end
end

end






