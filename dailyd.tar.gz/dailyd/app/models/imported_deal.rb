class ImportedDeal < ActiveRecord::Base

  scope :not_imported, :conditions => {:deal_id => nil}
  belongs_to :deal
  def generate_uuid
    self.uuid ||= title.hash.to_s + url.hash.to_s
  end

  def self.build_from_import(d, default_source)
    i = new
    i.source                   = d["source"] || default_source
    i.uuid                     = d["uid"]
    i.title                    = d["title"]
    i.url                      = d["url"]
    i.picture_url              = d["image"]
    unless i.picture_url =~ /^(http|www)/
      i.picture_url = "http://#{File.join(default_source, i.picture_url)}"
    end
    i.description              = d["description"] || d["title"]
    i.starts_at                = d["start_date"] || Time.now.beginning_of_day
    i.ends_at                  = d["end_date"] || Time.now.tomorrow.at_midnight
    i.value                    = d["full_price"]




    # bug fix for promo deals where they put all prices as zero
    if ((d["full_price"].to_f > 0) && ((d["full_price"].to_f - d["price"].to_f) / d["full_price"].to_f))
      i.discount_percentage    = d["discount_percentage"] || 100*((d["full_price"].to_f > 0) && ((d["full_price"].to_f - d["price"].to_f) / d["full_price"].to_f))
    else
      i.discount_percentage    = 0
    end
    i.amount_saved             = d["saving"] || d["full_price"].to_f - d["price"].to_f
    i.address                  = d["address"]
    i.suggested_location       = d["suggested_location"]
    i.purchased                 = d["purchased"]  || 0
    i.generate_uuid
    i
  end

  def before_create
    Site.all.each do |s|
      next unless url.downcase =~ /#{s.url}/
      self.site_id = s.id
      return
    end
    # bug fix for m-tov, the url doest include m-tov
    self.site_id = 39 if (url =~ /(masheootov)/)
    self.site_id = 22 if (url =~ /(bestours)/)
    self.site_id = 30 if (url =~ /(kvootzati)/)
    self.site_id = 56 if (url =~ /(israelcoupon)/)
    self.site_id = 37 if (url =~ /(jdeal)/)
    self.site_id = 8 if (url =~ /(gozrim)/)

    self.site_id = 9 if (url =~ /(dealhayom)/) #added as requested by Roy
    self.site_id = 38 if (url =~ /(sale365)/)
    self.site_id = 58 if (url =~ /(deal4all)/)
    self.site_id = 80 if (url =~ /www.group(e|d|k|w|l|p|m|f|v|t|c).co.il/)


  end

  def to_deal
    attributes.except("created_at","source", "updated_at", "deal_id", "id", "uuid")
  end

  def import!(location_ids, category_ids,address_values,location_id_hash)
    category_ids ||= []
    location_ids ||= []
    address_values ||= []
    location_id_hash ||= []
    @address_ids= []
    @locations = Location.find(:all)
    @d = Deal.create(to_deal)
    @d.category_ids = category_ids
    @d.location_ids = location_ids

    #~ if location_ids.uniq.count == @locations.count
    #~ @d.nation_wide_deal = 1
    @d.addresses << Address.create(:address => address_values.compact.first)
    #~ else
    #~ @d.nation_wide_deal = 0
    address_values.each_with_index do |x,ind|
      next if (x.blank? || location_id_hash[ind].blank?)
      a=Address.create(:address =>x )
      @d.addresses << a
      add_loc = AddressLocation.new(:address_id => a.id, :location_id => location_id_hash[ind])
      add_loc.save!
    end
   #~ end
    @d.save!
    self.deal_id = @d.id
    Deal.delay(:run_at => Time.current.end_of_day - 1.hour).get_lat_lng(@d.id) unless @d.nation_wide_deal?
    save!
  end

end
