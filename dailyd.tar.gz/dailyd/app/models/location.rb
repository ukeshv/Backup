class Location < ActiveRecord::Base
  validates :name, :presence => true, :uniqueness => true

  has_many :deal_locations
  has_many :deals, :through => :deal_locations

  has_many :user_locations, :dependent => :destroy
  has_many :users, :through => :user_locations
	
	has_many :address_locations
	has_many :addresses,:through=>:address_locations
	
  after_create :all_users_get_new_location

  def to_deal_iphone_hash(deal)
    {
      :name => name,
      :id => id,
      :address => AddressLocation.find(:all,:conditions=>["location_id = ? and address_id in (?)",self.id,deal.address_ids]).map(&:address).collect(&:address)
    }
  end
  
  def to_iphone_hash
    {
      :name => name,
      :id => id
    }
  end
  
  def to_iphone_hash_new
    {
      :name => name,
      :id => id,
      :deals_count => Deal.active.includes(:locations).where("locations.id in (?)",[self.id]).count
    }
  end
  
  def to_iphone_hash_for_location(category_id)
	{
	:name =>name,	
	:id => id,
	:count => Deal.active.includes(:locations,:categories).where("categories.id = ? and locations.id = ?",category_id,self.id).count
	}
end


  def all_users_get_new_location
    User.transaction do
      User.find(:all,:select=>"id").each do |user|
        #~ logger.warn "Adding '#{self.name}' to user ID '#{user.id}', e-mail address '#{user.email}'"
        user.locations << self
      end
    end
  end
	

  #test
end

# another comment

  
