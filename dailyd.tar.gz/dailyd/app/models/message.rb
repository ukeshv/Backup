class Message < ActiveRecord::Base

  belongs_to :user
  belongs_to :deal

  validates_presence_of :user_id
  validates_presence_of :deal_id

end
