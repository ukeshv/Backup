class Site < ActiveRecord::Base
  has_many :deals

  validates :url, :presence => true, :uniqueness => true
  validates :name, :presence => true, :uniqueness => true
  validates :sort_order, :presence => true, :numericality => true

  has_many :user_sites, :dependent => :destroy
  has_many :users, :through => :user_sites
  scope :not_disabled, where("not sites.is_disabled")

  # After we create a site, every existing user should have this
  # site selected for their daily e-mail blast.  They can always
  # turn it off by going to the preferences page.
  after_create :all_users_get_new_site

def all_users_get_new_site
 User.transaction do
		User.find(:all,:select=>"id").each do |user|
			#~ logger.warn "Adding '#{self.name}' to user ID '#{user.id}', e-mail address '#{user.email}'"
			user.sites << self
		end
	end
end

  def to_iphone_hash
    {
      :name => name,
      :id => id,
      :url => url
    }
  end
  
  def to_iphone_hash_new
    {
      :url => url,
      :id => id,
      :deals_count => Deal.active.where("site_id in (?)",[self.id]).count
    }
  end
  
end
