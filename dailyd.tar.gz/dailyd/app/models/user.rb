require 'md5'
require 'net/http'
require 'uri'

class User < ActiveRecord::Base

  SECRET_MD5_PHRASE = 'dailyd is really cool'

  # Include default devise modules. Others available are:
  # :token_authenticatable, :confirmable, :lockable and :timeoutable
  devise :database_authenticatable, :registerable,
  :recoverable, :rememberable, :trackable, :validatable#,:omniauthable


  # Setup accessible (or protected) attributes for your model
  attr_accessible :email, :password, :password_confirmation, :remember_me, :admin, :disabled, :test, :location_ids, :category_ids, :site_ids,:break_from,:break_to,:email_frequency,:familyname,:name,:address,:phone,:gender,:reg

  validates :email, :presence => true, :uniqueness => true

  has_many :clicks
  has_many :messages

  has_many :user_locations
  has_many :locations, :through => :user_locations

  has_many :user_categories
  has_many :categories, :through => :user_categories

  has_many :user_sites
  has_many :sites, :through => :user_sites
	#mysettings
  has_many :follows
  has_many :boughts

  after_create :register_all_locations
  after_create :register_all_categories
  after_create :register_all_sites
  after_create :send_welcome_email
  after_update :send_welcome_email_to_disabled

  #~ before_save :add_md5_id
  before_create :add_md5_id


 def self.find_for_facebook_oauth(access_token, signed_in_resource=nil)
  data = access_token['extra']['user_hash']
  if user = User.find_by_email(data["email"])
    user
  else # Create a user with a stub password.
    User.create!(:email => data["email"], :password => Devise.friendly_token[0,20])
  end
end

def self.new_with_session(params, session)
    super.tap do |user|
      if data = session["devise.facebook_data"] && session["devise.facebook_data"]["extra"]["user_hash"]
        user.email = data["email"]
      end
    end
  end

  def send_welcome_email
    UserMailer.send_welcome(self).deliver
  end


  def send_welcome_email_to_disabled
    return unless disabled_changed?
    send_welcome_email unless disabled?
  end

  # TODO: cache location.count
  def subscribed_to_all_locations?
    Location.count == locations.count
  end

  # TODO: cache category.count
  def subscribed_to_all_categories?
    Category.count == categories.count
  end

  # TODO: cache site.count
  def subscribed_to_all_sites?
    Site.count == sites.count
  end

  def register_all_locations
    self.locations = location_ids.blank? ? Location.all : Location.where(["id in (?)", location_ids]).all
  end

  def register_all_categories
    self.categories = category_ids.blank? ? Category.all : Category.where(["id in (?)", category_ids]).all
  end

  def register_all_sites
    self.sites = site_ids.blank? ? Site.all : Site.where(["id in (?)", site_ids]).all
  end

  def add_md5_id
    to_md5 = email + SECRET_MD5_PHRASE
    self.md5_id = MD5.md5(to_md5).hexdigest
  end

  def subscribed_to?(deal)
    !(deal.location_ids & location_ids).blank? & !(deal.category_ids & category_ids).blank? && site_ids.member?(deal.site_id)
  end

  def self.send_daily_email(params)
    only_testing = params[:test_only].present?
    counter = {'success' => 0, 'failure' => 0}

    deals_by_id = Deal.current_by_id
    current_deals_by_location = Deal.current_by_location
    locations = Location.all.index_by(&:id)

    User.where(:disabled => false).find_in_batches(:batch_size => 10) do |users|
      users.each do |user|
        if only_testing and !user.test?
          logger.warn "Ignoring non-test user '#{user.email}' during a test mailing"
          next
        end

        if !user.test? && user.last_email_sent_at && user.last_email_sent_at > 12.hours.ago.utc # TODO: config(?)
          logger.warn "Ignoring non-test user which already received an email less then 12 hous ago"
          next
        end
        user.update_attribute(:last_email_sent_at, Time.now.utc)

        user_current_deals = user.deal_ids_for_email(params[:locations], current_deals_by_location, deals_by_id)


        if user_current_deals.empty?
          logger.warn "If we got here, then user_current_deals is not empty"
          next
        end

        begin
          UserMailer.send_daily_email(user, User.deal_ids_to_deals(user_current_deals, deals_by_id, locations), only_testing).deliver
          counter['success'] += 1
          # Message.create(:user => user, :body => params[:message_contents])
        rescue
          logger.warn "[MessagesController#create] Error trying to send e-mail to user ID '#{user.id}', address '#{user.email}'"
          counter['failure'] += 1
        end
      end
      GC.start
    end

    UserMailer.sending_status(counter).deliver
  end

  def self.deal_ids_to_deals(dealids, deals_by_id =  Deal.current.index_by(&:id), locations = Location.all.index_by(&:id))
    dealids.map do |v|
      {
        :location => locations[v[:location_id]],
        :deals => v[:deal_ids].map {|d| deals_by_id[d]}.sort {|a, b| s = a.site.sort_order <=> b.site.sort_order; s.zero? ? (b.created_at <=> a.created_at) : s},
        :more_count => v[:more_count]
      }
    end
  end

  # preferred_deals as passed from params:
  # {"123" => {"3" => "1", "5" => 1"}, "456" => {"4" => "1", "10" => "1"}
  # 123, 456 - location_ids
  # "3", "5", "4", "10" - deal_ids
  def deal_ids_for_email(preferred_deals, current_deals_by_location = Deal.current_by_location, deals_by_id = Deal.current_by_id, default_deails_per_location = 4)
    res = []

    # filter locations
    current_location_ids = locations.collect(&:id) & current_deals_by_location.keys
    current_location_ids.each do |lid|
      if current_deals_by_location[lid]
        res << {:location_id => lid, :deal_ids => current_deals_by_location[lid].clone}
      end
    end

    # filter categories
    cids = category_ids
    res.each do |r|
      r[:deal_ids].clone.each do |did|
        r[:deal_ids].delete(did) if (deals_by_id[did].category_ids & cids).blank?
      end
    end

    # filter sites
    sids = site_ids
    res.each do |r|
      r[:deal_ids].clone.each do |did|
        r[:deal_ids].delete(did) unless sids.member?(deals_by_id[did].site_id)
      end
    end

    res.reject! {|v| v[:deal_ids].blank?}

    # use prefered deals
    unless preferred_deals.blank?
      prefered_location_ids = preferred_deals.keys.collect(&:to_i)
      res.each do |r|
        pref_dealids = (preferred_deals[r[:location_id].to_s] || {}).keys.collect(&:to_i)
        next if pref_dealids.blank?
        loc_deal_ids = r[:deal_ids].clone
        r[:deal_ids] = pref_dealids & r[:deal_ids]
        r[:deal_ids] = loc_deal_ids if r[:deal_ids].blank?
        r[:more_count] = loc_deal_ids.size - r[:deal_ids].size
        r.delete(:more_count) if r[:more_count] < 1
      end
    end

    # TODO: show other deal if deal already shown

    # compact deals, max 5 per location
    res.each do |r|
      next if r[:more_count]

      d_count = r[:deal_ids].size
      r[:deal_ids] = r[:deal_ids][0..default_deails_per_location - 1]
      d_count -= r[:deal_ids].size
      r[:more_count] = d_count if d_count > 0
    end

    # cleanup and return
    res.reject! {|v| v[:deal_ids].blank?}
    res
  end


# Added For sending Reminder on July 20

def self.send_reminder
  User.includes("boughts").where("disabled=? and boughts.reminder_date =?",false,Date.today).find_in_batches(:batch_size => 10) do |users|
    users.each do |user|
      @deals = user.boughts.where("DATE(reminder_date) = ?",Date.today).map(&:deal)
      UserMailer.send_reminder(user,@deals).deliver
    end
  end
end

def self.send_reset_instructions(user)
	 token=Digest::SHA1.hexdigest(user.email)
	 user.update_attribute("reset_password_token",token)
	 UserMailer.send_reset_instructions(user).deliver
 end
 
def self.send_request_to_micropay(phone)
  uri = URI.parse(URI.encode("http://www.micropay.co.il/ExtApi/ScheduleSms.php?get=1&uid=2161&un=dail&act=pass&list=#{phone}&from=4949&pid=17266"))
  http = Net::HTTP.new(uri.host, uri.port)
  request = Net::HTTP::Get.new(uri.request_uri)
  response = http.request(request)
  if response.body.include?("ERROR")
    return 1
  else
    return 0
  end
end

def complete_sms_registration(phone,code)
  uri = URI.parse(URI.encode("http://www.micropay.co.il/ExtApi/PoolMembers.php?get=1&uid=2161&un=dail&pid=17266&act=add&list=#{phone}&pass=#{code}&ip=199.123.1.99"))
  http = Net::HTTP.new(uri.host, uri.port)
  request = Net::HTTP::Get.new(uri.request_uri)
  response = http.request(request)
  if response.body == "OK"
    self.phone_for_sms = phone
    self.message_settings_enabled = true
    self.save
    return 0
  else
    return 1
  end
 end


def delete_user_from_pool
  uri = URI.parse(URI.encode("http://www.micropay.co.il/ExtApi/PoolMembers.php?get=1&uid=2161&un=dail&pid=17266&act=del&list=#{self.phone_for_sms}"))
  http = Net::HTTP.new(uri.host, uri.port)
  request = Net::HTTP::Get.new(uri.request_uri)
  response = http.request(request)
  if response.body == "OK"
    return 0
  else
    return 1
  end
end

def self.check_user_in_pool(phone)
  uri = URI.parse(URI.encode("http://www.micropay.co.il/ExtApi/PoolMembers.php?get=1&uid=2161&un=dail&pid=17266&act=check&list=#{phone}"))
  http = Net::HTTP.new(uri.host, uri.port)
  request = Net::HTTP::Get.new(uri.request_uri)
  response = http.request(request)
  if response.body == "NOT_REG"
    return 0
  else
    return 1
  end
end

end