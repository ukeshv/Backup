class FrontSweeper < ActionController::Caching::Sweeper
  observe Deal

  def after_save(deal)
    expire_action :controller => :front, :action => :index
    expire_fragment("deal_#{deal.id}")
  end
end
