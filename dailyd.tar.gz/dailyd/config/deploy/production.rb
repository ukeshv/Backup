set :user, "deploy"

# Servers & roles
role :app, "184.106.170.61", :primary => true
role :db, "184.106.170.61", :primary => true

# Application
set :deploy_to, "/var/www/dailyd.co.il"

# If you want to deploy some other branch means, set the branch here
#set :branch, "staging"

namespace :init do
  desc "create database.yml"
  task :database_yml do
  set :db_user, "dailyd"
  set :db_pass, "dailydpw"
database_configuration =<<-EOF
---
login: &login

production:
  adapter: postgresql
  encoding: unicode
  database: dailyd_current_production
  pool: 5
  username: #{db_user}
  password: #{db_pass}

  <<: *login

EOF
    run "mkdir -p #{shared_path}/config/database/"
    run "mkdir -p #{shared_path}/attachments/"
    put database_configuration, "#{shared_path}/config/database/database.yml"
  end
end

namespace :localize do

  desc "copy shared configurations to current"
  task :copy_shared_configurations, :roles => [:app] do
    %w[database.yml].each do |f|
      run "ln -nsf #{shared_path}/config/database/#{f} #{current_path}/config/#{f}"
    end
  end

  desc "link important static files to current"
  task :link_static_files, :roles => [:app] do
    run "ln -nfs #{shared_path}/config/settings.yml #{current_path}/config/settings.yml"
    run "ln -nfs #{shared_path}/config/newrelic.yml #{current_path}/config/newrelic.yml"
    run "ln -nfs #{shared_path}/config/amazon_s3.yml #{current_path}/config/amazon_s3.yml"
    run "ln -nfs #{shared_path}/attachments #{current_path}/public/"
  end

  desc "copy Expires header to our static content"
  task :copy_expires_header, :roles => [:app] do
    %w[header].each do |f|
        run "ln -nsf #{current_path}/public #{current_path}/public/add_expires_header"
        run "ln -nsf #{current_path}/public/attachments #{current_path}/public/attachments/add_expires_header"
    end
  end
end

# We don't user spinner to control our app servers. SMF is used to manage them, so we need to define custom
# SMF commands for start/stop/restart here. RBAC is used to allow the admin user to control these services.

namespace :rake do
  desc "Create asset packages for production"
  task :after_update_code, :roles => :app do
     run "cd #{current_path} && rake asset:packager:build_all RAILS_ENV=production"
   end
 end

namespace :deploy do
  desc "Restart Application"
    task :restart, :roles => :app do
      run "touch #{current_path}/tmp/restart.txt"
  end
end

#~ namespace :delayed_job do
  #~ task :shared_restart, :roles => :app do
    #~ run "cd #{current_path};RAILS_ENV=production script/delayed_job --pid-dir=#{shared_path}/dj_pids stop"
    #~ run "cd #{current_path};RAILS_ENV=production script/delayed_job --pid-dir=#{shared_path}/dj_pids start"
  #~ end
#~ end

# after "deploy:update_code", "deploy:migrate"
after "deploy:setup", "init:database_yml"
after "deploy:symlink", "localize:copy_shared_configurations"
after "deploy:symlink", "localize:link_static_files"
after "deploy:symlink", "localize:copy_expires_header"
after "deploy:symlink", "rake:after_update_code"
#~ after "deploy:restart", "delayed_job:shared_restart"
