Delayed::Worker.max_run_time = 12.hours
Delayed::Worker.max_attempts = 10
