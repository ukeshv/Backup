HoptoadNotifier.configure do |config|
  config.api_key = 'ca3450abdc1cbeba09b5610827c15a97'
end
