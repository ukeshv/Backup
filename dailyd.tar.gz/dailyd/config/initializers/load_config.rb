require "#{Rails.root}/lib/ruby_classes_extensions"
APP_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/settings.yml")[RAILS_ENV]
FACE_BOOK = YAML.load_file("#{RAILS_ROOT}/config/facebooker.yml")[RAILS_ENV]
S3_CONFIG = YAML.load_file("#{Rails.root}/config/amazon_s3.yml")[Rails.env].recursive_symbolize_keys!
