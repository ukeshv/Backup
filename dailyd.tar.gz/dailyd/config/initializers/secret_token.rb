# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Dailyd::Application.config.secret_token = '7a49b6177154ccd8559c75869967d68ef494a298c3cb19bc5dcba4af2e11cb24fcabebcecf7e41fb1fabc8eb845a1a4c9a73cf8b303cc2c062b5634264151369'
