Dailyd::Application.routes.draw do

devise_for :users, :controllers => { :omniauth_callbacks => "users/omniauth_callbacks",:registrations => 'devise/registrations' }

  root :to => 'front#index'


  get "admin/index"
  get "admin/users"
  post "admin/users"
  get "admin/send_daily_mail"
  get "admin/edit_user"

  post "admin/update_email"

  get "home/how_it_works"
  get "home/about_us"
  get "home/previous_deals"
  get "home/recent_deals"
  get "home/faq"
  get "home/terms_of_use"
  get "home/businesses"
  get "home/contact"
  get "home/customize"
  get "home/subscribe"
  get "home/bye"
  get "home/categories"
  get "home/locations"
  get "home/sites"
  get "home/applications_page"
  get "home/index"
  #get "home/locations"

  get "browserapp/index"
  
  #for API

 get "api/categories"
 get "api/locations"
 get "api/sites"
 get "api/category_deals"
 get "api/location_deals"
 get "api/site_deals"
 get "api/category_location"
 get "api/location_category"
 get "api/category_location_deals"
 get "api/all_deals"


  resources :banners
  resources :clicks
  resources :imports, :only => [:index, :create] do
  get "deal_map",:on=>:member
  end

  resources :categories
  resources :deals do
    get "previous", :on => :collection
    resource :map, :only => :show
  end
  resources :locations
  resources :sites
  resources :prefs
  resources :top_deals

  resources :subscriptions do
    get "disable", :on => :member
    get "error", :on => :member
    get "create_facebook_user", :on=>:collection
    get "new_fb_user", :on=>:collection
		post "full_registration", :on=>:collection
    post "login",:on=>:collection
    post "full_login",:on=>:collection
  end
  resources :messages do
    post "send_feedback", :on => :collection
  end
 resources :front ,:only => [:index] do
  get 'load_index'
  get 'get_deals',:on=>:collection
  get 'save_filters',:on=>:collection
end
resources :settings do
  post "update_message_setting",:on=>:collection
  get "message_setting",:on=>:collection
  post "send_code",:on=>:collection
  post "complete_registration",:on=>:collection
  get "details",:on=>:collection
  get "favorites",:on=>:collection
  get "followed_deals",:on=>:collection
  get "preferences",:on=>:collection
  get "add_follow",:on=>:collection
  get "find_setting_type",:on=>:collection
  get "find_favorite_type",:on=>:collection
  post "user_details",:on=>:member
  get "terms",:on=>:member
  get "fav_add_terms",:on=>:collection
  get "follow",:on=>:collection
  get "delete_terms",:on=>:member
  get "add_reminder",:on=>:member
  get "delete_reminder",:on=>:member
  get "delete_bought_deals",:on=>:member
  get "delete_follow_deals",:on=>:member
  get "mark_as_bought",:on=>:collection
  get "bought",:on=>:member
  post "change_password",:on=>:collection
	match "forgot_password",:on=>:collection
  match "reset_password",:on=>:collection
end
match "/successful_registration/:user"=>'subscriptions#successful_registration',:as=>"successful_registration"
match "/fb_create"=>'subscriptions#fb_create',:as=>"fb_create"
match "/delete_user/:id"=>'admin#delete_user',:as=>"delete_user",:via=>"get"
  # The priority is based upon order of creation:
  # first created -> highest priority.

  # Sample of regular route:
  #   match 'products/:id' => 'catalog#view'
  # Keep in mind you can assign values other than :controller and :action

  # Sample of named route:
  #   match 'products/:id/purchase' => 'catalog#purchase', :as => :purchase
  # This route can be invoked with purchase_url(:id => product.id)

  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   resources :products

  # Sample resource route with options:
  #   resources :products do
  #     member do
  #       get 'short'
  #       post 'toggle'
  #     end
  #
  #     collection do
  #       get 'sold'
  #     end
  #   end

  # Sample resource route with sub-resources:
  #   resources :products do
  #     resources :comments, :sales
  #     resource :seller
  #   end

  # Sample resource route with more complex sub-resources
  #   resources :products do
  #     resources :comments
  #     resources :sales do
  #       get 'recent', :on => :collection
  #     end
  #   end

  # Sample resource route within a namespace:
  #   namespace :admin do
  #     # Directs /admin/products/* to Admin::ProductsController
  #     # (app/controllers/admin/products_controller.rb)
  #     resources :products
  #   end

  # You can have the root of your site routed with "root"
  # just remember to delete public/index.html.
  # root :to => "welcome#index"

  # See how all your routes lay out with "rake routes"

  # This is a legacy wild controller route that's not recommended for RESTful applications.
  # Note: This route will make all actions in every controller accessible via GET requests.
  # match ':controller(/:action(/:id(.:format)))'
end
