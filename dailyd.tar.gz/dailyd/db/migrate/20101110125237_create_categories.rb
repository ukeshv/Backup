class CreateCategories < ActiveRecord::Migration
  def self.up
    create_table :categories do |t|
      t.string :name, :null => false
      t.boolean :is_disabled, :null => false, :default => false

      t.timestamps

    end
    add_index :categories, :name, :unique => true
    add_index :categories, :is_disabled
  end

  def self.down
    drop_table :categories
  end
end
