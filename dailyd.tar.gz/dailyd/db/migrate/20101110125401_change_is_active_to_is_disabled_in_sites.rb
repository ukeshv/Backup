class ChangeIsActiveToIsDisabledInSites < ActiveRecord::Migration
  def self.up
    rename_column :sites, :is_active, :is_disabled
    change_column :sites, :is_disabled, :boolean, :null => false, :default => false

    add_index :sites, :url, :unique => true
    add_index :sites, :is_disabled
  end

  def self.down
  end
end
