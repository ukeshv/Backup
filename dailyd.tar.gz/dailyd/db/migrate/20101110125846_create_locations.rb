class CreateLocations < ActiveRecord::Migration
  def self.up
    create_table :locations do |t|
      t.string :name, :null => false
      t.boolean :is_disabled, :null => false, :default => false

      t.timestamps
    end

    add_index :locations, :name, :unique => true
    add_index :locations, :is_disabled
  end

  def self.down
    drop_table :locations
  end
end
