class ModifyDeal < ActiveRecord::Migration
  def self.up
    add_column :deals, :site_id, :integer, :null => false
    add_column :deals, :location_id, :integer, :null => false
    add_column :deals, :starts_at, :timestamp, :null => false
    add_column :deals, :ends_at, :timestamp, :null => false
    add_column :deals, :picture_url, :string
    add_column :deals, :value, :decimal
    add_column :deals, :discount_percentage, :integer
    add_column :deals, :amount_saved, :decimal

    rename_column :deals, :content, :description

    add_index :deals, :site_id
    add_index :deals, :location_id
    add_index :deals, :starts_at
    add_index :deals, :ends_at
    add_index :deals, :discount_percentage
  end

  def self.down
  end
end
