class CreateDealsCategories < ActiveRecord::Migration
  def self.up
    create_table :deals_categories do |t|
      t.integer :deal_id
      t.integer :category_id

      t.timestamps
    end
  end

  def self.down
    drop_table :deals_categories
  end
end
