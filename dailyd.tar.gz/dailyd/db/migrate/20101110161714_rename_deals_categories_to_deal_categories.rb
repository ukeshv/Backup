class RenameDealsCategoriesToDealCategories < ActiveRecord::Migration
  def self.up
    rename_table :deals_categories, :deal_categories
  end

  def self.down
    rename_table :deal_categories, :deals_categories
  end
end
