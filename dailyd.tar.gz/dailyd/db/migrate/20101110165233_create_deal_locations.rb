class CreateDealLocations < ActiveRecord::Migration
  def self.up
    create_table :deal_locations do |t|
      t.integer :deal_id
      t.integer :location_id

      t.timestamps
    end

    add_index :deal_locations, :deal_id
    add_index :deal_locations, :location_id
  end

  def self.down
    drop_table :deal_locations
  end
end
