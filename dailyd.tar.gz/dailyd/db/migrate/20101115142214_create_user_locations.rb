class CreateUserLocations < ActiveRecord::Migration
  def self.up
    create_table :user_locations do |t|
      t.integer :user_id, :null => false
      t.integer :location_id, :null => false

      t.timestamps
    end

    add_index :user_locations, [:user_id, :location_id], :unique => true
    add_index :user_locations, :location_id
  end

  def self.down
    drop_table :user_locations
  end
end
