class AddTestFieldToUser < ActiveRecord::Migration
  def self.up
    add_column :users, :test, :boolean, :default => false, :null => false
    add_index :users, :test
  end

  def self.down
    remove_column :users, :test
  end
end
