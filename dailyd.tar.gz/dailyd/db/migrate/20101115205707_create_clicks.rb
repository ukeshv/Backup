class CreateClicks < ActiveRecord::Migration
  def self.up
    create_table :clicks do |t|
      t.integer :deal_id, :null => false
      t.integer :user_id, :null => true
      t.string :referrer
      t.string :browser_info
      t.string :remote_ip

      t.timestamps
    end

    add_index :clicks, :deal_id
    add_index :clicks, :user_id
    add_index :clicks, :referrer
    add_index :clicks, :browser_info
    add_index :clicks, :remote_ip
  end

  def self.down
    drop_table :clicks
  end
end
