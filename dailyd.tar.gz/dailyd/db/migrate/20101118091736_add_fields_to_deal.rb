class AddFieldsToDeal < ActiveRecord::Migration
  def self.up
    add_column :deals, :address, :string
    add_column :deals, :small_picture_url, :string
    add_column :deals, :medium_picture_url, :string
  end

  def self.down
    remove_column :deals, :address
    remove_column :deals, :small_picture_url
    remove_column :deals, :medium_picture_url
  end
end
