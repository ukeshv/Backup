class AddBodyToMessage < ActiveRecord::Migration
  def self.up
    add_column :messages, :body, :text
  end

  def self.down
    remove_column :messages, :body
  end
end
