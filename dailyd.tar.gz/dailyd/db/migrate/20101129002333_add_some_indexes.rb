class AddSomeIndexes < ActiveRecord::Migration
  def self.up
    add_index :deal_categories, :deal_id
    add_index :deal_categories, :category_id
  end

  def self.down
  end
end
