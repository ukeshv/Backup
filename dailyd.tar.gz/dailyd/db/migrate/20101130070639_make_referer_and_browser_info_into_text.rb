class MakeRefererAndBrowserInfoIntoText < ActiveRecord::Migration
  def self.up
    remove_index :clicks, :referrer
    remove_index :clicks, :browser_info
    change_column :clicks, :referrer, :text
    change_column :clicks, :browser_info, :text
  end

  def self.down
  end
end
