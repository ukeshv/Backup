class SetMd5IdAndAddUniqueIndex < ActiveRecord::Migration
  def self.up
    say_with_time "About to update users, to add MD5 code" do
      User.all.each do |u|
        STDERR.puts "Adding MD5 to user ID '#{u.id}', email address '#{u.email}'"
        u.save!
      end
    end

    change_column :users, :md5_id, :string, :null => false
    add_index :users, :md5_id, :unique => true
  end

  def self.down
  end
end
