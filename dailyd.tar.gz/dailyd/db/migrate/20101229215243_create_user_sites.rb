class CreateUserSites < ActiveRecord::Migration
  def self.up
    create_table :user_sites do |t|
      t.integer :user_id, :null => false
      t.integer :site_id, :null => false

      t.timestamps
    end

    add_index :user_sites, [:user_id, :site_id], :unique => true
    add_index :user_sites, :site_id
  end

  def self.down
    drop_table :user_sites
  end
end
