class AllUsersAllSites < ActiveRecord::Migration
  def self.up
    sites = Site.all
    User.all.each do |user|
      STDERR.puts "User id '#{user.id}', '#{user.email}'"
      sites.each do |site|
        STDERR.puts "\tSite id '#{site.id}', '#{site.name}'"
        if user.sites.member?(site)
          STDERR.puts "\t\tAlready there"
        else
          STDERR.puts "\t\tAdding association"
          user.sites << site
        end
      end
    end
  end

  def self.down
  end
end
