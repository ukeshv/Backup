class CreateImportedDeals < ActiveRecord::Migration
  def self.up
    create_table :imported_deals do |t|
      t.string :source
      t.string :uuid
      t.integer :deal_id
      t.timestamps
      t.string :title
      t.string :url
      t.string :picture_url
      t.text :description
      t.datetime :starts_at
      t.datetime :ends_at
      t.decimal  :value
      t.integer  :discount_percentage
      t.decimal  :amount_saved
      t.string :address
      t.string :suggested_location
      t.integer :site_id
    end
    add_index :imported_deals, [:source, :uuid]
    add_index :imported_deals, :deal_id
  end

  def self.down
    drop_table :imported_deals
  end
end
