class ChangeTitleLength < ActiveRecord::Migration
  def self.up
    change_column :deals, :title, :string, :limit => 2048
    change_column :imported_deals, :title, :string, :limit => 2048
  end

  def self.down
    change_column :imported_deals, :title, :string
    change_column :deals, :title, :string
  end
end
