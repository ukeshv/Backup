class AddLastSentToUsers < ActiveRecord::Migration
  def self.up
    add_column :users, :last_email_sent_at, :datetime
    ActiveRecord::Base.connection.execute "update users set last_email_sent_at = '#{1.day.ago.to_s(:db)}'"
  end

  def self.down
    remove_column :users, :last_email_sent_at
  end
end
