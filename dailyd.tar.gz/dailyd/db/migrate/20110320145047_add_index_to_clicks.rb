class AddIndexToClicks < ActiveRecord::Migration
  def self.up
    add_index :clicks, [:created_at, :deal_id]
  end

  def self.down
    remove_index :clicks, [:created_at, :deal_id]
  end
end
