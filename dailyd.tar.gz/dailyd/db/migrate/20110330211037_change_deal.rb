class ChangeDeal < ActiveRecord::Migration
  def self.up
    change_column :deals, :title, :string, :limit => 4096
    change_column :deals, :url, :string, :limit => 2048
  end

  def self.down
    change_column :deals, :url, :string, :limit => 255
    change_column :deals, :title, :string, :limit => 2048
  end
end
