class ChangeImportedDeals < ActiveRecord::Migration
  def self.up
    change_column :imported_deals, :title, :string, :limit => 4096
    change_column :imported_deals, :url, :string, :limit => 2048
  end

  def self.down
    change_column :imported_deals, :title, :string, :limit => 2048
    change_column :imported_deals, :url, :string, :limit => 255
  end
end
