class AddNationWideDealToDeal < ActiveRecord::Migration
  def self.up
    add_column :deals, :nation_wide_deal, :boolean
  end

  def self.down
    remove_column :deals, :nation_wide_deal
  end
end
