class AddAddress2ToImportedDeal < ActiveRecord::Migration
  def self.up
    add_column :imported_deals, :address2, :string
    add_column :imported_deals, :address3, :string
    add_column :imported_deals, :address4, :string
    add_column :imported_deals, :address5, :string
  end

  def self.down
    remove_column :imported_deals, :address2
    remove_column :imported_deals, :address3
    remove_column :imported_deals, :address4
    remove_column :imported_deals, :address5
  end
end
