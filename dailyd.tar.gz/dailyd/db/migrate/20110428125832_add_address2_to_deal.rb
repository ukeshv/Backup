class AddAddress2ToDeal < ActiveRecord::Migration
  def self.up
    add_column :deals, :address2, :string
    add_column :deals, :address3, :string
    add_column :deals, :address4, :string
    add_column :deals, :address5, :string
  end

  def self.down
    remove_column :deals, :address2
    remove_column :deals, :address3
    remove_column :deals, :address4
    remove_column :deals, :address5
  end
end
