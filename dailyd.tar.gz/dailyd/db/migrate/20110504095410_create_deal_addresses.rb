class CreateDealAddresses < ActiveRecord::Migration
  def self.up
    create_table :deal_addresses do |t|
      t.integer :deal_id
      t.integer :address_id
      t.timestamps
    end
  end

  def self.down
    drop_table :deal_addresses
  end
end
