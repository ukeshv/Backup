class CreateAddressLocations < ActiveRecord::Migration
  def self.up
    create_table :address_locations do |t|
      t.integer :location_id
      t.integer :address_id
      t.timestamps
    end
  end

  def self.down
    drop_table :address_locations
  end
end
