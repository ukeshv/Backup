class AddPositionToDealLocation < ActiveRecord::Migration
  def self.up
    add_column :deal_locations, :position, :integer
  end

  def self.down
    remove_column :deal_locations, :position, :integer
  end
end
