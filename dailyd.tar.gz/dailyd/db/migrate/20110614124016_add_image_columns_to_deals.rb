class AddImageColumnsToDeals < ActiveRecord::Migration
  def self.up
    add_column :deals, :in_local, :boolean, :default=>false
    add_column :deals, :image_name, :string
  end

  def self.down
    remove_column :deals, :image_name
    remove_column :deals, :in_local
  end
end
