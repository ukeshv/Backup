class AddLatLngToDeal < ActiveRecord::Migration
  def self.up
    add_column :deals, :latitudes, :text
    add_column :deals, :longitudes, :text
  end

  def self.down
    remove_column :deals,:latitudes
    remove_column :deals,:longitudes
  end
end
