class AddFieldToUsers < ActiveRecord::Migration
  def self.up
    add_column :users,:name,:string
		add_column :users,:familyname,:string
		add_column :users,:address,:string
		add_column :users,:phone,:string
		add_column :users,:gender,:string
		add_column :users,:reg,:boolean,:default=>false
		add_column :users,:email_frequency,:string	
		add_column :users,:break_from,:date
		add_column :users,:break_to,:date
  end

  def self.down
 remove_column :users,:name
 remove_column :users,:familyname
 remove_column :users,:address
 remove_column:users,:phone
 remove_column:users,:gender
 remove_column :users,:reg
  remove_column :users,:reg
	remove_column :users,:email_frequency
  remove_column :users,:break_from
  remove_column :users,:break_to
  end
end
