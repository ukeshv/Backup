class CreateBoughts < ActiveRecord::Migration
  def self.up
    create_table :boughts do |t|
		  t.integer :user_id
      t.integer :deal_id
			t.date :reminder_date
      t.timestamps
    end
  end

  def self.down
    drop_table :boughts
  end
end
