class AddPositionToDeal < ActiveRecord::Migration
  def self.up
  add_column :deals, :position, :integer
  end

  def self.down
  remove_column :deals, :position
  end
end
