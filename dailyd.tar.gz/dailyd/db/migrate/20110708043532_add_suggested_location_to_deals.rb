class AddSuggestedLocationToDeals < ActiveRecord::Migration
  def self.up
	add_column :deals, :suggested_location, :string
  end

  def self.down
	remove_column :deals, :suggested_location
  end
end
