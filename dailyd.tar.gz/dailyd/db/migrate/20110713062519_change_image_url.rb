class ChangeImageUrl < ActiveRecord::Migration
  def self.up
  change_column :deals, :picture_url, :string, :limit => 1024
  change_column :imported_deals, :picture_url, :string, :limit => 1024
  end

  def self.down
  change_column :deals, :picture_url, :string
  change_column :imported_deals, :picture_url, :string
  end
end
