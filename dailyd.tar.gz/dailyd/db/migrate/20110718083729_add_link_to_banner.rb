class AddLinkToBanner < ActiveRecord::Migration
  def self.up
    add_column :banners, :link, :string, :limit => 1024
  end

  def self.down
    remove_column :banners, :link
  end
end
