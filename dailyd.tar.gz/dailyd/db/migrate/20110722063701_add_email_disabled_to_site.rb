class AddEmailDisabledToSite < ActiveRecord::Migration
  def self.up
    add_column :sites, :is_email_disabled, :boolean,:default=>false
  end

  def self.down
    remove_column :sites, :is_email_disabled
  end
end
