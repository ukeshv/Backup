class AddExtraFieldsForSms < ActiveRecord::Migration
  def self.up
  add_column :users, :phone_for_sms, :string
  add_column :users, :message_settings_enabled, :boolean,:default=>false
  add_column :users, :message_option, :string
  end

  def self.down
  remove_column :users, :phone_for_sms
  remove_column :users, :message_settings_enabled
  remove_column :users, :message_option
  end
end
