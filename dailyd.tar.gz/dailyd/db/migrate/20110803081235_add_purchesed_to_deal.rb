class AddPurchesedToDeal < ActiveRecord::Migration
  def self.up
    add_column :deals, :purchased, :integer
  end

  def self.down
    remove_column :deals, :purchased
  end
end
