class AddPurchasedToImportedDeal < ActiveRecord::Migration
  def self.up
    add_column :imported_deals, :purchased, :integer
  end

  def self.down
    remove_column :imported_deals, :purchased
  end
end
