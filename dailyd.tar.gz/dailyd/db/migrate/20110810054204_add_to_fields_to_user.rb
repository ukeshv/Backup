class AddToFieldsToUser < ActiveRecord::Migration
  def self.up
		add_column :users,:fb_user,:boolean,:default=>false
  end

  def self.down
	remove_column :users,:fb_user
  end
end
