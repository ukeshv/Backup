# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20110803081611) do

  create_table "address_locations", :force => true do |t|
    t.integer  "location_id"
    t.integer  "address_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "addresses", :force => true do |t|
    t.string   "address",    :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "banners", :force => true do |t|
    t.string   "name"
    t.boolean  "enabled",                            :default => true
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "photo_file_name"
    t.string   "photo_content_type"
    t.integer  "photo_file_size"
    t.datetime "photo_updated_at"
    t.string   "link",               :limit => 1024
  end

  create_table "categories", :force => true do |t|
    t.string   "name",                           :null => false
    t.boolean  "is_disabled", :default => false, :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "categories", ["is_disabled"], :name => "index_categories_on_is_disabled"
  add_index "categories", ["name"], :name => "index_categories_on_name", :unique => true

  create_table "clicks", :force => true do |t|
    t.integer  "deal_id",      :null => false
    t.integer  "user_id"
    t.text     "referrer"
    t.text     "browser_info"
    t.string   "remote_ip"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "clicks", ["created_at", "deal_id"], :name => "index_clicks_on_created_at_and_deal_id"
  add_index "clicks", ["deal_id"], :name => "index_clicks_on_deal_id"
  add_index "clicks", ["remote_ip"], :name => "index_clicks_on_remote_ip"
  add_index "clicks", ["user_id"], :name => "index_clicks_on_user_id"

  create_table "deal_addresses", :force => true do |t|
    t.integer  "deal_id"
    t.integer  "address_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "deal_categories", :force => true do |t|
    t.integer  "deal_id"
    t.integer  "category_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "deal_categories", ["category_id"], :name => "index_deal_categories_on_category_id"
  add_index "deal_categories", ["deal_id"], :name => "index_deal_categories_on_deal_id"

  create_table "deal_locations", :force => true do |t|
    t.integer  "deal_id"
    t.integer  "location_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "position"
  end

  add_index "deal_locations", ["deal_id"], :name => "index_deal_locations_on_deal_id"
  add_index "deal_locations", ["location_id"], :name => "index_deal_locations_on_location_id"

  create_table "deals", :force => true do |t|
    t.string   "title",               :limit => 4096
    t.string   "url",                 :limit => 2048
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "site_id",                                                                               :null => false
    t.datetime "starts_at",                                                                             :null => false
    t.datetime "ends_at",                                                                               :null => false
    t.string   "picture_url",         :limit => 1024
    t.decimal  "value",                               :precision => 10, :scale => 0
    t.integer  "discount_percentage"
    t.decimal  "amount_saved",                        :precision => 10, :scale => 0
    t.string   "address"
    t.string   "small_picture_url"
    t.string   "medium_picture_url"
    t.string   "photo_file_name"
    t.string   "photo_content_type"
    t.integer  "photo_file_size"
    t.boolean  "nation_wide_deal"
    t.string   "address2"
    t.string   "address3"
    t.string   "address4"
    t.string   "address5"
    t.boolean  "in_local",                                                           :default => false
    t.string   "image_name"
    t.text     "latitudes"
    t.text     "longitudes"
    t.integer  "position"
    t.string   "suggested_location"
    t.integer  "purchased"
  end

  add_index "deals", ["discount_percentage"], :name => "index_deals_on_discount_percentage"
  add_index "deals", ["ends_at"], :name => "index_deals_on_ends_at"
  add_index "deals", ["site_id"], :name => "index_deals_on_site_id"
  add_index "deals", ["starts_at"], :name => "index_deals_on_starts_at"

  create_table "delayed_jobs", :force => true do |t|
    t.integer  "priority",   :default => 0
    t.integer  "attempts",   :default => 0
    t.text     "handler"
    t.text     "last_error"
    t.datetime "run_at"
    t.datetime "locked_at"
    t.datetime "failed_at"
    t.string   "locked_by"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "delayed_jobs", ["locked_by"], :name => "delayed_jobs_locked_by"
  add_index "delayed_jobs", ["priority", "run_at"], :name => "delayed_jobs_priority"

  create_table "imported_deals", :force => true do |t|
    t.string   "source"
    t.string   "uuid"
    t.integer  "deal_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "title",               :limit => 4096
    t.string   "url",                 :limit => 2048
    t.string   "picture_url",         :limit => 1024
    t.text     "description"
    t.datetime "starts_at"
    t.datetime "ends_at"
    t.decimal  "value",                               :precision => 10, :scale => 0
    t.integer  "discount_percentage"
    t.decimal  "amount_saved",                        :precision => 10, :scale => 0
    t.string   "address"
    t.string   "suggested_location"
    t.integer  "site_id"
    t.string   "address2"
    t.string   "address3"
    t.string   "address4"
    t.string   "address5"
    t.integer  "purchased"
  end

  add_index "imported_deals", ["deal_id"], :name => "index_imported_deals_on_deal_id"
  add_index "imported_deals", ["source", "uuid"], :name => "index_imported_deals_on_source_and_uuid"

  create_table "locations", :force => true do |t|
    t.string   "name",                           :null => false
    t.boolean  "is_disabled", :default => false, :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "locations", ["is_disabled"], :name => "index_locations_on_is_disabled"
  add_index "locations", ["name"], :name => "index_locations_on_name", :unique => true

  create_table "messages", :force => true do |t|
    t.integer  "deal_id"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.text     "body"
  end

  add_index "messages", ["deal_id"], :name => "index_messages_on_deal_id"
  add_index "messages", ["user_id"], :name => "index_messages_on_user_id"

  create_table "sites", :force => true do |t|
    t.string   "url"
    t.boolean  "is_disabled",       :default => false, :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "name"
    t.integer  "sort_order",        :default => 1,     :null => false
    t.boolean  "is_email_disabled", :default => false
    t.string   "login_page"
  end

  add_index "sites", ["is_disabled"], :name => "index_sites_on_is_disabled"
  add_index "sites", ["name"], :name => "index_sites_on_name"
  add_index "sites", ["url"], :name => "index_sites_on_url", :unique => true

  create_table "user_categories", :force => true do |t|
    t.integer  "user_id",     :null => false
    t.integer  "category_id", :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "user_categories", ["category_id"], :name => "index_user_categories_on_category_id"
  add_index "user_categories", ["user_id", "category_id"], :name => "index_user_categories_on_user_id_and_category_id", :unique => true

  create_table "user_locations", :force => true do |t|
    t.integer  "user_id",     :null => false
    t.integer  "location_id", :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "user_locations", ["location_id"], :name => "index_user_locations_on_location_id"
  add_index "user_locations", ["user_id", "location_id"], :name => "index_user_locations_on_user_id_and_location_id", :unique => true

  create_table "user_sites", :force => true do |t|
    t.integer  "user_id",    :null => false
    t.integer  "site_id",    :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "user_sites", ["site_id"], :name => "index_user_sites_on_site_id"
  add_index "user_sites", ["user_id", "site_id"], :name => "index_user_sites_on_user_id_and_site_id", :unique => true

  create_table "users", :force => true do |t|
    t.string   "email",                               :default => "",    :null => false
    t.string   "encrypted_password",   :limit => 128, :default => "",    :null => false
    t.string   "reset_password_token"
    t.string   "remember_token"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",                       :default => 0
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "admin",                               :default => false
    t.boolean  "disabled",                            :default => false, :null => false
    t.boolean  "test",                                :default => false, :null => false
    t.string   "md5_id",                                                 :null => false
    t.datetime "last_email_sent_at"
  end

  add_index "users", ["email"], :name => "index_users_on_email", :unique => true
  add_index "users", ["md5_id"], :name => "index_users_on_md5_id", :unique => true
  add_index "users", ["reset_password_token"], :name => "index_users_on_reset_password_token", :unique => true
  add_index "users", ["test"], :name => "index_users_on_test"

end
