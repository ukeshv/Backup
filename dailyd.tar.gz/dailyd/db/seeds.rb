# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ :name => 'Chicago' }, { :name => 'Copenhagen' }])
#   Mayor.create(:name => 'Daley', :city => cities.first)

%w(buy2 baligam yemama grouper wallashops bigdeal grouper buddies gozrim).each do |url|
  Site.create({:url => "#{url}.co.il", :name => url})
end

Category.create([{:name => "אוכל שתיה"},
                 {:name => "ספא"},
                 {:name => "בריאות ויופי"},
                 {:name => "פעילויות והרפתקאות"},
                 {:name => "נופש"},
                 {:name => "ספורט וכושר"},
                 {:name => "חוגים"},
                 {:name => "קמענואות ושירותים"}
                ])

Location.create([{:name => "תל אביב והמרכז"},
                 {:name => "חיפה"},
                 {:name => "השרון"},
                 {:name => "ירושלים"},
                 {:name => "באר שבע"}
                ])


