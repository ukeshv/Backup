Given /^I am not authenticated$/ do
  visit('/users/sign_out') # ensure that at least
end

Given /^a user with e\-mail address "([^"]*)" and password "([^"]*)"$/ do |email_address, password|
  @user = Factory.create(:user,
                         :email => email_address,
                         :password => password,
                         :password_confirmation => password)
end

Given /^an admin with e\-mail address "([^"]*)" and password "([^"]*)"$/ do |email_address, password|
  @user = Factory.create(:user,
                         :email => email_address,
                         :password => password,
                         :password_confirmation => password,
                         :admin => true)
end

When /^I log in as "([^"]*)" with password "([^"]*)"$/ do |email, password|
  Given %{I go to the login page}
  And %{I fill in "user_email" with "#{email}"}
  And %{I fill in "user_password" with "#{password}"}
  And %{I press "Sign in"}
end

Given /^standard sites$/ do 
  %w(baligam.co.il wallashops.co.il).each do |url|
    Factory.create(:site, :url => url, :name => url)
  end
end

Given /^standard locations$/ do 
  %w(Jerusalem Haifa Modiin).each do |url|
    Factory.create(:location,
                   :name => url)
  end
end

Given /^standard categories$/ do 
  %w(food spa service).each do |name|
    Factory.create(:category, :name => name)
  end
end

Given /I choose one location/ do
  all('#locations input[type=checkbox]').each {|ch| check(ch[:id]) }
end

Given /^one deal that is current$/ do
  @deal = Factory.create(:deal)
end

Given /^one deal that has already expired$/ do
  @deal = Factory.create(:deal, 
                         :ends_at => (Time.now - 10.minutes))
end

When /^I create a click for deal ID "([^\"]*)"$/ do |deal_id|
  Given %{one deal that is current}
  Then %{I go to the click page for deal ID #{@deal.id}}
  @click = Factory.create(:click, :deal => @deal)
end

Then /^(?:|I )should not be on (.+)$/ do |page_name|
  current_path = URI.parse(current_url).path
  if current_path.respond_to? :should
    current_path.should_not == path_to(page_name)
  else
    assert_not_equal path_to(page_name), current_path
  end
end

Then /^there should be (\d+) clicks? in the database$/ do |number_of_clicks|
  Click.count.should == number_of_clicks.to_i
end

Then /^there should be (\d+) messages? in the database$/ do |number_of_messages|
  Message.count.should == number_of_messages.to_i
end

Then /^the user "([^\"]*)" should be disabled$/ do |email|
  user = User.find_by_email(email)
  user.disabled.should == true
end

Then /^the user "([^\"]*)" should not be disabled$/ do |email|
  user = User.find_by_email(email)
  user.disabled.should == false
end

Then /^user "([^\"]*)" should have category "([^\"]*)" selected$/ do |email, category_name|
  user = User.find_by_email(email)
  category = Category.find_by_name(category_name)
  user.categories.should include(category)
end

Then /^user "([^\"]*)" should not have category "([^\"]*)" selected$/ do |email, category_name|
  user = User.find_by_email(email)
  category = Category.find_by_name(category_name)
  user.categories.should_not include(category)
end
