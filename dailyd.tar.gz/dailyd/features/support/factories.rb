Factory.define(:user) do |user|
  user.sequence(:email) { |n| "user#{n}@example.com"}
  user.password "password"
  user.admin false
end

Factory.define(:site) do |site|
  site.sequence(:url) {|n| "http://example#{n}.com"}
  site.sequence(:name) {|n| "example#{n}.com"}
  site.sort_order 1
end

Factory.define(:category) do |category|
  category.sequence(:name) {|n| "cat#{n}"}
  category.is_disabled false
end

Factory.define(:location) do |location|
  location.sequence(:name) {|n| "city#{n}"}
end

Factory.define(:deal) do |deal| 
  deal.sequence(:title) { |n| "title#{n}"}
  deal.sequence(:url) { |n| "http://example.com/deal#{n}"}
  deal.sequence(:picture_url) { |n| "http://example.com/dealpic#{n}.jpeg"}
  deal.sequence(:description) { |n| "description#{n}"}
  deal.sequence(:address) { |n| "address#{n}"}
  deal.value 100
  deal.discount_percentage 50
  deal.amount_saved 50

  deal.locations { Location.all }
  deal.categories { Category.all }

  deal.association :site
  
  deal.starts_at 1.day.ago
  deal.ends_at (Time.now + 1.day)
end

Factory.define(:click) do |click|
  click.association :user
  click.association :deal
end

