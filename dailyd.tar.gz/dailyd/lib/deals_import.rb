# http://www.dealzone.co.il/livefeed
# ["address", "end_time", "title", "discount_price", "image_url", "id", "description", "original_price", "quantity_sold"]
#
#
# http://www.baligam.co.il/products/rss
# ["title", "pubDate", "guid", "link", "description"] 
#
#
# https://www.yemama.co.il/rss.ashx
# ["category", "title", "pubDate", "link", "description"]
#
#
# http://www.dealhayom.co.il/deals/active.xml
# 
#
# http://imalike.co.il/dealfeed.ashx
# ["PriceAfterDiscount", "DealStartDateIL", "DealStartDateGMT", "HoursLeft", "DealEndDateIL", "DealURL", "UpdateDateGMT", "IsSoldOut", "FullPrice", "ID", "PriceSave", "MinutesLeft", "DealImage", "DealEndDateGMT", "DiscountPercentage", "DealTitle", "VouchersBought", "UpdateDateIL", "SecondsLeft"]
#
#  http://www.expressdeal.co.il/rss/rss.ashx
#  ["title", "datePosted", "link", "description"] 
#
#  http://www.wallashops.co.il/wssvc/GroupDeals.aspx
#  ["price", "categoryName", "areaIdYad2", "discount_percentage", "areaName", "addresses", "dealName", "img", "itemsTook", "dealTitle", "categoryId", "img2", "dealShortName", "link", "areaId", "original_price", "endDate", "isSoldOut"]
#
#  http://www.gargir.co.il/xmlexport
#  not parsable
#
# http://shavhe.co.il/feeds/rss.ashx
# "http://www.deal10.co.il/pub.ashx?id=dailyd" => [DealsImport::Deal10, "www.deal10.co.il"],
# "http://www.dealon.co.il/articles/rss_agg_dailyd.xml" => [DealsImport::Base, "www.dealon.co.il"],



module DealsImport
  class Base
    attr_accessor :source, :content, :imported, :skipped, :errors, :messages, :updated_dates,
      :imported_deal_ids
    include HTTParty
    format :xml
    def initialize(url, source)
      @source = source
      @imported = 0
      @skipped = 0
      @errors = 0
      @updated_dates = 0
      @messages = []
      @imported_deal_ids = []
      begin
        @content = self.class.get(url)
      rescue => e
        @deals = {}
        @errors += 1
        @messages << e.inspect + e.backtrace[0..4].join("---")
      end
    end

    def deals
      @deals ||= @content["deals"]["deal"]
    end

    def deal(index)
      deals[index]
    end

    def save_deal(d)
      same = ImportedDeal.find_by_uuid_and_source(d.uuid, d.source)
      if same
        ## updating the number of purchased coupons
        same.deal.update_attribute(:purchased, d.purchased) if same.deal
        same.update_attribute(:purchased, d.purchased)
         
        ## updating deals end time in case their end time has changed (also updating the link & image url)  
        if same.deal && same.deal.ends_at != d.ends_at && d.source != 'www.yemama.co.il' && d.source != 'www.groupon.co.il'
          same.deal.update_attribute(:ends_at, d.ends_at)
          same.update_attribute(:ends_at, d.ends_at)
          same.deal.update_attribute(:picture_url, d.picture_url)
          same.update_attribute(:picture_url, d.picture_url)
          same.deal.update_attribute(:url, d.url)
          same.update_attribute(:url, d.url)
          @updated_dates += 1
        else
          @skipped += 1
        end
        @imported_deal_ids << same.id
      else
        begin
          d.save!
          @imported_deal_ids << d.id
          @imported += 1
        rescue => e
          @errors += 1
          @messages << e.inspect + e.backtrace[0..4].join("---")
        end
      end
    end

    def process!
      begin
        if deals.is_a?(Hash)
          @deals = [deals]
        end

        0.step(deals.size - 1) do |index|
          d = ImportedDeal.build_from_import(deal(index), @source)
          save_deal(d)
        end

      rescue => e
        @errors += 1
        @messages << e.inspect + e.backtrace[0..4].join("---")
      end
    end
  end

  class IsraDates < Base
    def self.parse_date(v)
      begin
        d, t = v.split(/ /)
      rescue
        d = v
        t = "23:59:00"
      end
      day, month, year = d.split(/\//)
      begin
        h, m, s = t.split(/:/)
      rescue
        h, m, s = "23", "59", "00"
      end
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = super
      d.merge("start_date" => self.class.parse_date(d["start_date"]), "end_date" => self.class.parse_date(d["end_date"]))
    end
  end
  
  class BaBetov < Base
    def deal(index)
      d = super
      d.merge("end_date" => d["end_date"].to_datetime - 3.hours)
    end
  end
  
  class Groupli < Base
    def deal(index)
      d = super
      d.merge("purchased" => d["ordered"])
    end
  end
  
  class Couponchik < Base
    def deal(index)
      d = super
      d.merge("purchased" => d["ordered"])
    end
  end
  
  class ShefaDeal < Base
    def deal(index)
      d = super
      d.merge("purchased" => d["ordered"])
    end
  end
  
  class YomiYomi < Base
    def deal(index)
      d = super
      d.merge("purchased" => d["ordered"])
    end
  end
  
  class DealHarif < Base
    def deal(index)
      d = super
      d.merge("source" => "www.deal-harif.co.il", "purchased" => d["ordered"])
    end
  end
  
  class OneZero < Base
    def deal(index)
      d = super
      d.merge("purchased" => d["ordered"])
    end
  end
  
  class MyDeal < Base
    def deal(index)
      d = super
      d.merge("source" => "www.my-deal.co.il", "purchased" => d["ordered"])
    end
  end
  
  class GroupOrgIl < Base
    def deal(index)
      d = super
      d.merge("end_date" => d["end_date"].to_datetime - 3.hours, "address" => "")
    end
  end
  
  class DealCity < Base
    def deals
      @deals ||= @content["Deals"]["Deal"]
    end
    
    def deal(index)
      d = super
      d.merge("description" => d["description"].gsub(/<\/?[^>]*>/, ""))
    end
  end
  
  class Mtov < IsraDates
    def deal(index)
      d = super
      d.merge("url" => ("http://masheootov.go2cloud.org/aff_c?offer_id=4&aff_id=1005&source=" + d["uid"]))
    end
  end
  
  class StarDeal < IsraDates
    def deal(index)
      d = super
      d.merge("purchased" => d["ordered"])
    end
  end
  
  class DealHayom < Base
    def deals
      @deals ||= @content["coupon:deals"]["coupon:deal"]
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["coupon:title"],
        "uid" =>   d["coupon:id"],
        "url" =>   "http://dealhayomcoil.go2cloud.org/SHN?url=" + d["coupon:full_url"],
        "description" => d["coupon:description"].gsub(/<\/?[^>]*>/, "").gsub("&nbsp;", "  "),
        "price" => d["coupon:price"].to_i,
        "full_price" => d["coupon:value"].to_i,
        "end_date" => d["coupon:valid_until"],
        "image" => d["coupon:image"],
        "suggested_location" => d["coupon:city"],
        "address" => d["coupon:company_address"],
        "purchased" => d["coupon:purchases_num"]
      }
    end
  end
  
  class Kaninu < Base
    def deals
      @deals ||= @content["coupon:deals"]["coupon:deal"]
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["coupon:title"],
        "uid" =>   d["coupon:id"],
        "url" =>   d["coupon:full_url"],
        "description" => d["coupon:description"].gsub(/<\/?[^>]*>/, "").gsub("&nbsp;", "  "),
        "price" => d["coupon:price"].to_i,
        "full_price" => d["coupon:value"].to_i,
        "end_date" => d["coupon:valid_until"],
        "image" => d["coupon:image"],
        "suggested_location" => d["coupon:city"],
        "address" => d["coupon:company_address"],
        "purchased" => d["coupon:purchases_num"]
      }
    end
  end

  class Shavhe < IsraDates
    def deals
      @deals ||= @content["Deals"]["Deal"]
    end

    def deal(index)
      d = super
      d.merge("title" => d["Title"], "description" => d["Description"])
    end
  end
  
  class Groupunch < IsraDates
    def deals
      @deals ||= @content["Deals"]["Deal"]
    end

    def deal(index)
      d = super
      d.merge("title" => d["Title"], "description" => d["Description"])
    end
  end

  class Walla < Base

    def self.guess_address(a)
      r = a["addressDetails"].is_a?(Array) ? a["addressDetails"].first.values.join(", ") :  a["addressDetails"].values.join(", ")
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["dealTitle"],
        "url" => d["link"],
        "image" => d["img"],
        "description" => d["dealName"],
        "end_date" => IsraDates.parse_date(d["endDate"]),
        "price" => d["price"].to_s.gsub(/,/, "").to_i,
        "discount_percentage" => d["discount_percentage"],
        "full_price" => d["original_price"].to_s.gsub(/,/, "").to_i,
        "address" => self.class.guess_address(d["addresses"]).gsub(/\n/, ""),
        "suggested_location" => d["areaName"],
        "purchased" => d["itemsTook"]
      }
    end
  end
  
  class Buy2 < Base
    
    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => d["url"],
        "uid" => d["uid"],
        "image" => d["image"],
        "description" => d["description"],
        "end_date" => IsraDates.parse_date(d["end_date"]),
        "price" => d["price"].to_s.gsub(/,/, "").to_i,
        "discount_percentage" => d["discount-percentage"],
        "full_price" => d["full_price"].to_s.gsub(/,/, "").to_i,
        "address" => d["area"],
        "suggested_location" => d["area"],
        "purchased" => d["totalPurchased"]
      }
    end
  end
  
  class GroupIsrael < Base
    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => d["url"],
        "uid" => d["uid"],
        "image" => d["image"],
        "description" => d["description"],
        "end_date" => d["end_date"],
        "price" => d["price"].to_i,
        "discount_percentage" => d["discount-percentage"],
        "full_price" => d["full_price"].to_i,
        "purchased" => d["purchased"]
      }
    end
  end
  
  class Groupon < Base
    
    def deals
      @deals ||= @content["rss"]["channel"]["item"]
    end
    
    def get_location
      @location = @content["rss"]["channel"]["title"]
    end
  	
    def deal(index)
      d = deals[index]
      {
        "title" => d["description"].gsub(%r{</?[^>]+?>}, ''),
        "url" => d["link"].gsub(/(\?.+)/,"") + "/.hUfoU0",
        "uid" => d["link"].scan(/\d+/)[0],
        "image" => "http://dailyd.co.il/images/default_giftcard_image.jpeg", #d["description"].match(/(http).*(jpg|png|gif)/)[0],
        "end_date" => d["pubDate"].to_datetime.tomorrow.in_time_zone("Jerusalem") + 59.minutes,
        "price" => d["description"].scan(/\d+/)[-2].to_i,
        "full_price" => d["description"].scan(/\d+/)[-1].to_i,
        "address" => get_location,
        "suggested_location" => get_location
      }
    end
  end

  class Yemama < Base
    
    def deals
      @deals ||= @content["rss"]["channel"]["item"]
    end

  	def w3c_date(date) 
  	  date.utc.strftime("%Y-%m-%dT%H:%M:%S+00:00") 
  	end
  	
  	def get_image(image_link)
  	  if image_link.nil?
  	    "http://dailyd.co.il/images/default_giftcard_image.jpeg"
  	  else
  	    begin
  	      image_link.match(/(http).*(jpg|png|gif)/)[0].gsub("'","").split(";")[0]
  	    rescue
  	      "http://dailyd.co.il/images/default_giftcard_image.jpeg"
	      end
  	  end
  	end
  	    

    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => d["link"].gsub("hen","heb"),
        "uid" => d["link"].scan(/\d+/)[0],
        "image" => get_image(d["description"]),
        "end_date" => Time.now.beginning_of_day + 2.day,
        "price" => d["title"].scan(/\d+/)[-2].to_i,
        "full_price" => d["title"].scan(/\d+/)[-1].to_i,
        "suggested_location" => d["category"]
      }
    end

  end
  
  class Kvootzati < Base

    def deals
      @deals ||= @content["STORE"]["PRODUCTS"]["PRODUCT"]
    end

  	def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["name"],
        "url" => d["affUrl"].gsub("&aff_id=0","&aff_id=1004"),
        "uid" => d["id"],
        "image" => d["imgUrl"],
        "description" => d["desceription"].gsub("&nbsp;", "  ").gsub("&quot", " "),
        "end_date" => parse_date(d["endDate"]),
        "price" => d["price"].to_i,
        "full_price" => d["originalPrice"].to_i,
        "address" => " ",
        "suggested_location" => "Haifa",
        "purchased" => d["sold"]
      }
    end
  end
  
  class Sale365 < Base

    def deals
      @deals ||= @content["STORE"]["PRODUCTS"]["PRODUCT"]
    end

  	def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["name"],
        "url" => d["affUrl"].gsub("aff_id=0","aff_id=1002"),
        "uid" => d["id"],
        "image" => d["imgUrl"],
        "description" => d["desceription"].gsub("&nbsp;", "  ").gsub("&quot", " "),
        "end_date" => parse_date(d["endDate"]),
        "price" => d["price"].to_i,
        "full_price" => d["originalPrice"].to_i,
        "address" => " ",
        "suggested_location" => "Haifa",
        "purchased" => d["sold"]
      }
    end
  end
  
  class YouToo < Base
    
  	def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      if deals.is_a?(Hash)
        d = deals
      else
        d = deals[index]
      end
      {
        "title" => d["title"],
        "url" => d["deal_url"] + "&uid=1499",
        "uid" => d["id"],
        "image" => d["image_url"],
        "description" => d["description"],
        "end_date" => parse_date(d["end_time"]),
        "price" => d["price_after"],
        "full_price" => d["price_before"],
        "address" => d["address"],
        "suggested_location" => "",
        "purchased" => d["sold"]
      }
    end
  end
  
  class Coupona < Base

  	def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
        d = deals[index]
        {
        "uid" => d["urlToSite"].scan(/\d+/)[0],
        "title" => d["title"],
        "url" => d["urlToSite"] + "&sId=67",
        "image" => d["imageURL"],
        "description" => d["description"],
        "end_date" => parse_date(d["endTime"]),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "suggested_location" => d["area"],
        "purchased" => d["orderAmount"]
        }
    end
  end
  
  class ImaLike < Base

    def deal(index)
      d = deals[index]
      {
        "title" => d["title"].gsub(/<\/?[^>]*>/, ""),
        "url" => d["url"] + "&SourceAff=DailyD",
        "uid" => d["uid"],
        "image" => d["image"],
        "description" => d["title"],
        "start_date" => Time.now,
        "end_date" => d["end_date"].to_datetime,
        "price" => d["price"].to_i,
        "full_price" => d["full_price"].to_i,
        "discount_percentage" => d["discount_percentage"],
        "purchased" => d["sold"]
      }
    end
  end
  
  class Garagenik < Base

    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split('.')
      h, m = t.split(/:/)
      Time.local(year, month, day, h, m) + 3.hours
    end
  
    def deal(index)
      d = super
      d.merge("end_date" => parse_date(d["end_date"]), "suggested_location" => d["address"].gsub(%r{</?[^>]+?>}, ''))
    end
  end

  class Cheapopo < Base

    def parse_date(v)
    d, t = v.split(/ /)
    day, month, year = d.split(/\//)
    h, m, s = t.split(/:/)
    Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "uid" => d["uid"],
        "title" => d["title"],
        "url" => d["urlToSite"],
        "image" => d["imageURL"],
        "description" => d["description"],
        "end_date" => parse_date(d["endTime"]),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "suggested_location" => d["area"],
        "purchased" => d["orderAmount"]
      }
    end
  end
  
  class BuyCell < Base
    def deals
      @deals ||= @content["root"]["deal"]
    end

  	def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s) + 3.hours
    end

    def deal(index)
      d = deals[index]
      {
        "uid" => d["description"].hash.to_s,
        "title" => d["title"],
        "url" => d["urlToSite"],
        "image" => d["imageURL"],
        "description" => d["description"].gsub(%r{</?[^>]+?>}, '').gsub(/(&nbsp)/, ''),
        "end_date" => parse_date(d["endTime"]),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "suggested_location" => d["area"].gsub(/<\/?[^>]*>/, ""),
        "purchased" => d["orderAmount"]
      }
    end
  end
  
  class Gozrim < Base
    
  	def parse_gozrim_date(date) 
  	  tmp = date.split(",")
  	  (tmp[0] + "/" + tmp[1] + "/" + tmp[2] + " 12:00").to_datetime.utc.strftime("%Y-%m-%dT%H:%M:%S+00:00")
  	end

    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => "http://gozrim.go2cloud.org/aff_c?params=%26deal%3D" + d["id"] + "&offer_id=7&aff_id=1016",
        "uid" => d["id"],
        "image" => d["image_url"],
        "description" => d["description"],
        "end_date" => parse_gozrim_date(d["end_time"]),
        "price" => d["price_after"].to_i,
        "full_price" => d["price_before"].to_i,
        "address" => d["address"],
        "suggested_location" => d["address"],
        "purchased" => d["total_sold"]
      }
    end
  end
  
  class Buddies < Base

  	def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => d["deal_url"],
        "uid" => d["id"],
        "image" => d["image_url"],
        "description" => d["description"].gsub("&nbsp;", "  ").gsub("&quot", " "),
        "start_date" => Time.now,
        "end_date" => parse_date(d["end_time"]),
        "price" => d["price_after"].to_i,
        "full_price" => d["price_before"].to_i,
        "discount_percentage" => d["discount_percentage"],
        "address" => d["address"],
        "purchased" => d["sold"]
      }
    end
  end
  
  class Zing < Base
  	def parse_zing_date(date) 
  	  Time.at(date.to_i).utc.strftime("%Y-%m-%dT%H:%M:%S+00:00")
  	end

    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => d["path"],
        "uid" => d["dealid"],
        "image" => d["image"],
        "description" => d["description"].gsub(%r{</?[^>]+?>}, '').gsub(/(&nbsp)/,""),
        "start_date" => Time.now,
        "end_date" => parse_zing_date(d["time_end"]),
        "price" => d["price_after_ils"].to_i,
        "full_price" => d["price_before_ils"].to_i,
        "address" => d["area"],
        "suggested_location" => d["area"],
        "purchased" => d["current_count"]
      }
    end
  end
  
  class GreatDeal < Base
  	def parse_date(date) 
  	  Time.at(date.to_i).to_datetime
  	end

    def deal(index)
      d = deals[index]
      {
        "title" => d["name"],
        "url" => d["link"],
        "uid" => d["id"],
        "image" => d["image"],
        "description" => d["name"],
        "end_date" => parse_date(d["end"]),
        "price" => d["price"].to_i,
        "full_price" => d["orginal_price"].to_i,
        "purchased" => d["current"],
        "suggested_location" => d["business"]["address"]
      }
    end
  end
  
  class HadealHayomi < Base
  	def parse_date(date) 
  	  Time.at(date.to_i).to_datetime
  	end

    def deal(index)
      d = deals[index]
      {
        "title" => d["name"],
        "url" => 'http://' + d["link"],
        "uid" => d["id"],
        "image" => 'http://' + d["image"],
        "description" => d["name"],
        "end_date" => parse_date(d["end"]),
        "price" => d["price"].to_i,
        "full_price" => d["orginal_price"].to_i,
        "purchased" => d["current"],
        "suggested_location" => d["business"]["address"]
      }
    end
  end
  
  class Kantina < Base
    def deals
      @deals ||= @content["xml"]["node"]
    end

  	def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => "http://www.kantina.co.il/affiliate/1346" + d["UrlToPage"],
        "image" => d["imageURL"],
        "description" => d["description"].gsub(%r{</?[^>]+?>}, ''),
        "end_date" => parse_date(d["endtime"]),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "address" => d["area"],
        "suggested_location" => d["area"],
        "purchased" => d["orderAmount"]
      }
    end
  end
  
  class Bestours < Base
    def deal(index)
      d = deals[index]
      {
        "uid" => d["uid"],
        "title" => d["title"],
        "url" => d["hasoffers_affiliate_url"].gsub("aff_id=100","aff_id=1002"),
        "image" => d["image"],
        "description" => d["description"],
        "start_date" => d["start_date"],
        "end_date" => d["end_date"],
        "price" => d["price"].to_i,
        "full_price" => d["full_price"].to_i,
        "discount_percentage" => d["discount_percentage"].to_i,
        "address" => d["address"],
        "purchased" => d["num_current"]
      }
    end
  end
  
  class Jdeal < Base
    def deal(index)
      d = deals[index]
      {
        "uid" => d["uid"],
        "title" => d["title"],
        "url" => "http://jdeal.go2cloud.org/aff_c?offer_id=2&aff_id=1005&source=" + d["url"].gsub(/^.*(deals\/)/,""),
        "image" => d["image"],
        "start_date" => d["start_date"],
        "end_date" => d["end_date"],
        "price" => d["price"].scan(/\d+/)[0].to_i,
        "full_price" => d["full_price"].scan(/\d+/)[0].to_i,
        "discount_percentage" => d["discount_percentage"].to_i,
        "saving" => d["saving"].scan(/\d+/)[0].to_i,
      }
    end
  end
  
  class Bpi < Base
    def deals
      @deals ||= @content["Deals"]["Deal"]
    end

    def deal(index)
        d = deals[index]
      {
        "uid" => d["ID"],
        "title" => d["DealTitle"],
        "url" => d["DealURL"],
        "image" => d["DealImage"],
        "start_date" => d["DealStartDate"].to_datetime,
        "end_date" => d["DealEndDate"].to_datetime,
        "price" => d["PriceAfterDiscount"].to_i,
        "full_price" => d["FullPrice"].to_i,
        "discount_percentage" => d["DiscountPercentage"].to_i,
        "saving" => d["PriceSave"].to_i,
      }
    end
  end
  
  class CrazyPrice < Base
    
    def deal(index)
      d = deals[index]
      {
        "uid" => d["id"],
        "title" => d["title"],
        "description" => d["title"],
        "url" => d["urlToSite"] + "?oid=1005_3",
        "image" => d["imageUrl"],
        "end_date" => d["endTime"].to_datetime.in_time_zone("Jerusalem") - 3.hours,
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "purchased" => d["orderAmount"]
      }
    end
  end
  
  class RakHayom < Base
    def deals
      @deals ||= @content["result"]["data"]["teams"]["team"]
    end

    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "uid" => d["id"],
        "title" => d["title"],
        "url" => d["link"],
        "image" => d["small_image_url"],
        "price" => d["team_price"].to_i,
        "full_price" => d["market_price"].to_i,
        "discount_percentage" => d["rebate"].to_i,
        "start_date" => d["start_date"],
        "end_date" => d["end_date"],
        "address" => d["city"],
        "suggested_location" => d["city"],
        "purchased" => d["current_point"]
      }
    end
  end
  
  class NofeshSale < Base
    
    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "uid" => d["uid"],
        "title" => d["title"],
        "url" => d["url"] + "?affCode=0008b98af003",
        "image" => d["image"],
        "description" => d["description"],
        "price" => d["price"].to_i,
        "full_price" => d["full_price"].to_i,
        "discount_percentage" => d["discount_percentage"].to_i,
        "saving" => d["saving"].to_i,
        "end_date" => parse_date(d["end_date"]),
        "address" => d["address"],
        "suggested_location" => d["address"]
      }
    end
  end
  
  class DealZone < Base
    def deal(index)
      d = deals[index]
      {
        "uid" => d["id"],
        "title" => d["title"],
        "url" => "http://www.dealzone.co.il/partner.php?p=dailyd&d=" + d["id"],
        "image" => d["image_url"],
        "price" => d["discount_price"].to_i,
        "full_price" => d["original_price"].to_i,
        "end_date" => d["end_time"].to_datetime,
        "address" => d["address"]
      }
    end
  end
  
  
  class GroupE < Base
    
    def deals
      @deals ||= @content["result"]["data"]["deals"]["deal"]
    end
    
    def deal(index)
      d = deals[index]
      {
        "uid" => d["id"],
        "title" => d["flashtext"],
        "url" => d["link"].match(/https?:\/\/[\S]+/)[0],
        "image" => d["small_image_url"],
        "description" => d["flashtext"],
        "start_date" => d["start_date"].to_datetime.in_time_zone("Jerusalem") - 3.hours,
        "end_date" => d["end_date"].to_datetime.in_time_zone("Jerusalem") - 3.hours,
        "price" => d["price"].to_i,
        "full_price" => d["market_price"].to_i,
        "address" => d["area"],
        "suggested_location" => d["area"],
        "purchased" => d["current_point"]
      }
    end
  end
  
  class TravelDeal < Base
    
    def deals
      @deals ||= @content["Deals"]["Deal"]
    end
    
    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end
    
    def deal(index)
      d = deals[index]
      {
        "uid" => d["Title"],
        "title" => d["Description"],
        "url" => d["UrlToSite"],
        "image" => d["ImageUrl"],
        "description" => d["Description"],
        "start_date" => parse_date(d["StartTime"]),
        "end_date" => parse_date(d["EndTime"]),
        "price" => d["PriceAfterDiscount"].to_i,
        "full_price" => d["RegPrice"].to_i,
        "discount_percentage" => d["Discount"]
      }
    end
  end
  
  class DrDeal < Base
    def deal(index)
      d = deals[index]
      {
        "uid" => d["uid"],
        "title" => d["title"],
        "url" => d["url"],
        "image" => d["image"],
        "description" => d["title"],
        "start_date" => d["start_date"].to_datetime.in_time_zone("Jerusalem"),
        "end_date" => d["end_date"].to_datetime.in_time_zone("Jerusalem"),
        "price" => d["price"].to_i,
        "full_price" => d["full_price"].to_i,
        "discount_percentage" => d["discount_percentage"],
        "saving" => d["saving"],
        "address" => d["address"].truncate(255),
        "source" => d["source"]
      }
    end
  end
  
  class MyCoupon < Base
    def deal(index)
      d = deals[index]
      {
        "uid" => d["id"],
        "title" => d["name"].truncate(255),
        "url" => d["pageUrl"],
        "image" => d["imageUrl"],
        "description" => d["description"],
        "end_date" => d["endDate"],
        "price" => d["price"].to_i,
        "full_price" => d["originalPrice"].to_i,
        "address" => d["address"],
        "suggested_location" => d["address"],
        "purchased" => d["sold"]
      }
    end
  end
  
  class Dday < Base

    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "uid" => d["id"],
        "title" => d["title"],
        "url" => d["urlToSite"] + "&ref=dailyd",
        "image" => d["imageURL"],
        "description" => d["description"].gsub(%r{</?[^>]+?>}, ''),
        "end_date" => parse_date(d["endtime"]),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "suggested_location" => d["area"],
        "purchased" => d["orderAmount"]
      }
    end
  end
  
  class Amama < Base

    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => d["urlToSite"],
        "image" => d["imageURL"],
        "description" => d["description"],
        "end_date" => parse_date(d["endTime"]),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "suggested_location" => d["area"]
      }
    end
  end
  
  class GroupDeal < Base
    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => d["urlToSite"],
        "image" => d["imageURL"],
        "description" => d["description"],
        "end_date" => parse_date(d["endTime"]),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "address" => d["area"],
        "suggested_location" => d["area"],
        "purchased" => d["orderAmount"]
      }
    end
  end
  
  class Gargir < Base
    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "uid" => d["dealid"],
        "title" => d["title"],
        "url" => d["urlToSite"],
        "image" => d["imageURL"],
        "description" => d["description"].gsub(%r{</?[^>]+?>}, ''),
        "end_date" => parse_date(d["endTime"]),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "address" => d["area"],
        "suggested_location" => d["area"]
      }
    end
  end
  
  class DealMovil < Base
  	def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => d["urlToSite"],
        "image" => d["imageURL"],
        "description" => d["description"],
        "end_date" => parse_date(d["endTime"] + " 23:59:00"),
        "price" => d["priceAfterDiscount"],
        "full_price" => d["regPrice"],
        "suggested_location" => d["area"],
        "purchased" => d["orderAmount"]
      }
    end
  end
  
  class ILoveTravel < Base
    def deal(index)
      d = deals[index]
      {
        "uid" => d["uid"],
        "title" => d["title"],
        "url" => d["url"],
        "image" => d["image"],
        "description" => d["title"],
        "start_date" => d["start_date"],
        "end_date" => d["end_date"],
        "price" => d["price"].to_i,
        "full_price" => d["full_price"].to_i,
        "discount_percentage" => d["discount_percentage"],
        "saving" => d["saving"],
      }
    end
  end
  
  class Bdeal < Base
    def deal(index)
      d = deals[index]
      {
        "title" => d["description"],
        "url" => d["pageUrl"],
        "image" => d["imageUrl"],
        "description" => d["description"],
        "end_date" => d["endDate"],
        "price" => d["price"].to_i,
        "full_price" => d["originalPrice"].to_i,
        "address" => d["address"],
        "suggested_location" => d["address"]
      }
    end
  end
  
  class IsraelCoupon < Base
    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "uid" => d["id"],
        "title" => d["title"],
        "url" => "http://israelcoupon.go2cloud.org/aff_c?offer_id=1&aff_id=1004&source=" + d["id"],
        "image" => d["image_url"],
        "price" => d["price_after"].to_i,
        "full_price" => d["price_before"].to_i,
        "end_date" => parse_date(d["end_time"]),
        "suggested_location" => d["area"],
        "purchased" => d["sold"]
      }
    end
  end
  class Deal10 < Base
    def deal(index)
      d = deals[index]
      {
        "uid" => d["uid"],
        "title" => d["title"],
        "url" => d["url"],
        "image" => d["image"],
        "start_date" => d["start_date"],
        "end_date" => d["end_date"],
        "price" => d["price"].scan(/\d+/)[0].to_i,
        "full_price" => d["full_price"].scan(/\d+/)[0].to_i,
        "discount_percentage" => d["discount_percentage"].scan(/\d+/)[0],
        "saving" => d["saving"].scan(/\d+/)[0],
        "address" => d["address"]
      }
    end
  end
  
  class Baligam < Base
    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "title" => d["title"],
        "url" => d["urlToSite"],
        "image" => d["imageURL"],
        "description" => d["description"],
        "end_date" => parse_date(d["endTime"]),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "address" => d["area"],
        "suggested_location" => d["area"],
        "purchased" => d["orderAmount"]
      }
    end
  end
  
  class KenZeZol < Base
    def parse_date(v)
      d, t = v.gsub("- ","").split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
      d = deals[index]
      {
        "uid" => d["id"],
        "title" => d["name"],
        "url" => d["link"],
        "image" => d["image"],
        "end_date" => parse_date(d["end"]),
        "price" => d["price"].to_i,
        "full_price" => d["orginal_price"].to_i,
        "purchased" => d["current"]
      }
    end
  end
  
  class BuyWithYou < Base
    def deal(index)
      d = deals[index]
      {
        "uid" => d["uid"],
        "title" => d["title"],
        "url" => d["url"],
        "image" => d["image"],
        "end_date" => d["end_date"],
        "price" => d["price"].to_i,
        "full_price" => d["full_price"].to_i,
        "discount_percentage" => d["discount_percentage"],
        "saving" => d["saving"],
        "address" => d["address"],
        "purchased" => d["ordered"]
      }
    end
  end
  
  class ExpressDeal < Base
  	def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
        d = deals[index]
        {
        "title" => d["title"],
        "url" => d["urlToSite"],
        "image" => d["imageURL"],
        "description" => d["description"],
        "end_date" => parse_date(d["endTime"] + " 23:59:00"),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "address" => d["area"],
        "suggested_location" => d["area"],
        "purchased" => d["orderAmount"]
        }
    end
  end
  
  class Couponic < Base
    def deal(index)
        d = deals[index]
        {
          "uid" => d["id"],
          "title" => d["name"],
          "url" => d["link"],
          "image" => d["image"],
          "end_date" => Time.at(d["end"].to_i),
          "price" => d["price"].to_i,
          "full_price" => d["orginal_price"].to_i,
          "address" => d["business"]["address"],
          "purchased" => d["current"]
        }
    end
  end
  
  class Konimtov < Base
    def deal(index)
        d = deals[index]
        {
          "uid" => d["id"],
          "title" => d["name"],
          "url" => "http://" + d["link"],
          "image" => "http://" + d["image"],
          "end_date" => Time.at(d["end"].to_i) + 3.hours,
          "price" => d["price"].to_i,
          "full_price" => d["orginal_price"].to_i,
          "address" => d["business"]["address"],
          "discount_percentage" => d["discount_percentage"],
          "purchased" => d["current"]
        }
    end
  end
  
  class Metoraf < IsraDates
    def deal(index)
      d = super
      d.merge("url" => d["url"].gsub("sId=0","sId=3"))
    end
  end
  
  class Deal4All < Base
    def deal(index)
      d = super
      d.merge("url" => "http://deal4all.go2cloud.org/aff_c?offer_id=1&aff_id=1003&source=" + d["uid"], "description" => d["description"].gsub(/<\/?[^>]*>/, ""))
    end
  end
  
  class Dealike < Base
    def deals
      @deals ||= @content["urlset"]["deal"]
    end

    def deal(index)
        d = deals[index]
        {
          "uid" => d["uid"],
          "title" => d["title"],
          "url" => d["url"],
          "image" => d["image"],
          "description" => d["description"].gsub(/<\/?[^>]*>/, ""),
          "end_date" => d["end_date"].to_datetime.in_time_zone("Jerusalem") - 3.hours,
          "price" => d["price"].to_i,
          "full_price" => d["full_price"].to_i,
          "purchased" => d["purchased"]
        }
    end
  end
  
  class JerDeal < Base

    def deal(index)
        d = deals[index]
        {
          "uid" => d["uid"],
          "title" => d["title"],
          "url" => d["url"],
          "image" => d["image"],
          "description" => d["description"],
          "end_date" => d["end_date"],
          "price" => d["price"].to_i,
          "full_price" => d["full_price"].to_i,
          "purchased" => d["ordered"]
        }
    end
  end
  
  class Bwc < Base
  	def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end

    def deal(index)
        d = deals[index]
        {
          "uid" => d["uid"],
          "title" => d["title"],
          "url" => d["url"] + "?affCode=000402387051",
          "image" => d["image"],
          "description" => d["description"],
          "start_date" => parse_date(d["start_date"]),
          "end_date" => parse_date(d["end_date"]),
          "price" => d["price"].to_i,
          "full_price" => d["full_price"].to_i,
          "saving" => d["saving"],
          "address" => d["address"],
          "purchased" => d["ordered"]
        }
    end
  end
  
  class Passportgo < Base
    def deal(index)
        d = deals[index]
        {
          "uid" => d["uid"],
          "title" => d["title"],
          "url" => d["url"],
          "image" => d["image"],
          "description" => d["description"],
          "end_date" => d["end_date"],
          "price" => d["price"].to_i,
          "full_price" => d["full_price"].to_i,
          "saving" => d["saving"],
          "address" => d["address"],
          "purchased" => d["ordered"]
        }
    end
  end
  
  class LaylaDeal < Base
    def deal(index)
        d = deals[index]
        {
        "uid" => d["id"],
        "title" => d["name"],
        "url" => d["link"],
        "image" => d["image"],
        "end_date" => Time.at(d["end"].to_i),
        "price" => d["price"].to_i,
        "full_price" => d["orginal_price"].to_i,
        "address" => d["business"]["address"],
        }
    end
  end
  
  class Couponpon < Base
    def deal(index)
        d = deals[index]
        {
        "uid" => d["id"],
        "title" => d["name"],
        "url" => d["link"],
        "image" => d["image"],
        "end_date" => Time.at(d["end"].to_i),
        "price" => d["price"].to_i,
        "full_price" => d["orginal_price"].to_i,
        "address" => d["business"]["address"],
        "purchased" => d["current"]
        }
    end
  end
  
  class Couponeto < Base
    def deal(index)
        d = deals[index]
        {
          "uid" => d["uid"],
          "title" => d["title"],
          "url" => d["url"],
          "image" => d["image"],
          "description" => d["description"],
          "end_date" => d["end_date"],
          "price" => d["price"].to_i,
          "full_price" => d["full_price"].to_i,
          "saving" => d["saving"],
          "address" => d["address"]
        }
    end
  end
  
  class Orange < Base
    
    def deal(index)
      d = deals[index]
      {
        "uid" => d["dealid"],
        "title" => "????? ????? ?????'" + d["description"],
        "url" => d["url"],
        "image" => d["image"],
        "description" => d["highlights"],
        "start_date" => d["start_date"],
        "end_date" => d["end_date"],
        "price" => d["price"].to_i,
        "full_price" => d["full_price"].to_i,
        "purchased" => d["sold"]
      }
    end
  end
  
  class BigDeal < Base
    
    def parse_date(v)
      d, t = v.split(/ /)
      day, month, year = d.split(/\//)
      h, m, s = t.split(/:/)
      Time.local(year, month, day, h, m , s)
    end
    
    def deal(index)
      d = deals[index]
      {
        "uid" => d["urlToSite"].scan(/\d+/)[0],
        "title" => d["title"],
        "url" => d["urlToSite"],
        "image" => d["imageURL"],
        "description" => d["description"],
        "end_date" => parse_date(d["endTime"]),
        "price" => d["priceAfterDiscount"].to_i,
        "full_price" => d["regPrice"].to_i,
        "purchased" => d["orderAmount"]
      }
    end
  end
  
  
  SOURCES = {
    "http://www.coupo.co.il/?xml&aff_id=8" => [ DealsImport::Base, "www.coupo.co.il" ],
    "http://www.tendeal.co.il/xmls/dailyD.xml" => [ DealsImport::Base, "www.tendeal.co.il" ],
    "http://www.shefadeal.co.il/?xml=15" => [ DealsImport::ShefaDeal, "www.shefadeal.co.il" ],
    "http://shavhe.co.il/feeds/dailyd.aspx" => [ DealsImport::Shavhe, "shavhe.co.il" ],
    "http://www.groupunch.co.il/feeds/dailyd.aspx" => [DealsImport::Groupunch, "www.groupunch.co.il"],
    "http://www.bigdeal.co.il/xml.aspx?sid=19" => [ DealsImport::BigDeal, "www.bigdeal.co.il" ],
    "http://www.wallashops.co.il/wssvc/GroupDeals.aspx" => [ DealsImport::Walla, "www.wallashops.co.il" ],
    "http://www.dealhayom.co.il/deals/active.xml" => [DealsImport::DealHayom, "www.dealhayom.co.il"],
    "http://www.kaninu.co.il/xml.ashx" => [DealsImport::Kaninu, "www.kaninu.co.il"],
    "http://www.stardeal.co.il/dealscan/" => [DealsImport::StarDeal, "www.stardeal.co.il"],

    "http://apps.buy2.co.il/buy2wid.aspx?result=xml&source=dailyd&medium=dailyd_deals&date=#{Date.today.day}_#{Date.today.month-1}" => [DealsImport::Buy2, "www.buy2.co.il"],
    "http://babetov.co.il/rss/afflivedailyd.RSS.asp" => [DealsImport::BaBetov, "www.babetov.co.il"],
    "http://www.youtoo.co.il/Site/Compare/Deals_dailydeals.aspx" => [DealsImport::YouToo, "www.youtoo.co.il"],
    
    "http://imalike.co.il/dealfeed.ashx?key=3" => [DealsImport::ImaLike, "www.imalike.co.il"],
    "http://www.sunsell.co.il/AffiliateXml/dailyD.asp" => [DealsImport::IsraDates, "www.sunsell.co.il"],
    "http://www.1plus1.co.il/xml_d.aspx?sId=17" => [DealsImport::IsraDates, "www.1plus1.co.il"],
    "http://garagenik.co.il/deals/deal/dday" => [DealsImport::Garagenik, "www.garagenik.co.il"],
    "http://www.cheapopo.co.il/xmls/zap.php" => [DealsImport::Cheapopo, "www.cheapopo.co.il"],
    "http://www.buycell.co.il/Offers/xml" => [DealsImport::BuyCell, "www.buycell.co.il"],
    
    "http://www.gozrim.co.il/deals.xml" => [DealsImport::Gozrim, "www.gozrim.co.il"],
    "http://www.kvootzati.co.il/xml/" => [DealsImport::Kvootzati, "www.kvootzati.co.il"],
    "http://www.sale365.co.il/xml/" => [DealsImport::Sale365, "www.sale365.co.il"],
    "http://aff.group.org.il/DealsXmlDailyD.aspx" => [DealsImport::GroupOrgIl, "www.group.org.il"],
    "http://www.zing.co.il/feed.xml.php" => [DealsImport::Zing, "www.zing.co.il"],
    "http://www.buddies.co.il/Site/Compare/Deals_dailydeals.aspx" => [DealsImport::Buddies, "www.buddies.co.il"],
    "http://dealcity.co.il/export/deals/getdeals/user/dailyd/pass/dailyd2010" => [DealsImport::DealCity, "www.dealcity.co.il"],
    "http://market.orange.co.il/api/dealsController/getAffActiveDeals/?aff_username=dailyd&aff_password=d41lyd" => [DealsImport::Orange, "http://market.orange.co.il"],
    
    "http://www.kantina.co.il/dxml" => [DealsImport::Kantina, "www.kantina.co.il"],
    "http://www.groupli.co.il/?xml=6" => [DealsImport::Groupli, "www.groupli.co.il"],
    "http://www.coupona.co.il/groupdeals.xml" => [DealsImport::Coupona, "www.coupona.co.il"],
    "http://www.bestours.co.il/feed2.xml?hasoffers_affid=100" => [DealsImport::Bestours, "www.bestours.co.il"],
    "http://www.m-tov.co.il/deald.xml" => [DealsImport::Mtov, "www.m-tov.co.il"],
    "http://jdeal.co.il/deal/agg" => [DealsImport::Jdeal, "www.jdeal.co.il"],
    "http://www.crazyprice.co.il/tavo/zap.aspx" => [DealsImport::CrazyPrice, "www.crazyprice.co.il"],
    "http://www.rak-ayom.co.il/api/index.php" => [DealsImport::RakHayom, "www.rak-ayom.co.il"],
    "http://nofeshsale.co.il/dealscan/" => [DealsImport::NofeshSale, "www.nofeshsale.co.il"],
    "http://www.group-e.co.il/api/index.php?site=dailyD" => [DealsImport::GroupE, "www.group-e.co.il"],
    
    "http://www.deal-harif.co.il/?xml=3" => [DealsImport::DealHarif, "www.deal-harif.co.il"],
    "http://www.1zero.co.il/?xml=3" => [DealsImport::OneZero, "www.1zero.co.il"],
    "http://www.dday.co.il/xml.aspx" => [DealsImport::Dday, "www.dday.co.il"],
    
    "http://groupdeal.co.il/print_deal.xml?id=28" => [DealsImport::GroupDeal, "www.groupdeal.co.il"],
    "http://www.dealmovil.co.il/rss/xml.asp?siteurl=dailyd.co.il" => [DealsImport::DealMovil, "www.dealmovil.co.il"],
    "http://ilovetravel.co.il/modules/mehirot/xml2.php" => [DealsImport::ILoveTravel, "www.ilovetravel.co.il"],
    
    "http://www.couponchik.co.il/?xml=8" => [DealsImport::Couponchik, "www.couponchik.co.il"],
    "http://www.great-deal.co.il/xml.php" => [DealsImport::GreatDeal, "www.great-deal.co.il"],
    "http://hadealhayomi.co.il/index.php/site/xml" => [DealsImport::HadealHayomi, "www.hadealhayomi.co.il"],
        
    "http://www.israelcoupon.co.il/nodesxml" => [DealsImport::IsraelCoupon, "www.israelcoupon.co.il"],
    "http://deal4all.co.il/Market/Rss/DaylyDInfoStream" => [DealsImport::Deal4All, "www.deal4all.co.il"],
    "http://www.baligam.co.il/api/v2/list_open_deals.xml" => [DealsImport::Baligam, "www.baligam.co.il"],
    "http://www.kenzezol.co.il/xml.php" => [DealsImport::KenZeZol, "www.kenzezol.co.il"],
    "http://www.buywithyou.co.il/?xml=8" => [DealsImport::BuyWithYou, "www.buywithyou.co.il"],
    "http://www.expressdeal.co.il/rss/xml.asp?siteurl=dailyd.co.il" => [DealsImport::ExpressDeal, "www.expressdeal.co.il"],
    "http://www.couponic.co.il/xml.php" => [DealsImport::Couponic, "www.couponic.co.il"],
    
    "http://www.konimtov.co.il/site/xml" => [ DealsImport::Konimtov, "www.konimtov.co.il" ],
    "http://dealike.co.il/sitemap.xml" => [ DealsImport::Dealike, "www.dealike.co.il" ],
    "http://www.dealclub.co.il/index/xml/type/4/affiliate/4" => [ DealsImport::Base, "www.dealclub.co.il" ],
    "http://www.jerusalemdeal.co.il/?xml=aff_id13" => [ DealsImport::JerDeal, "www.jerusalemdeal.co.il" ],
    "http://www.bwc.co.il/dealscan/" => [ DealsImport::Bwc, "www.bwc.co.il" ],
    "http://www.passportgo.co.il/?xml=15" => [ DealsImport::Passportgo, "www.passportgo.co.il" ],
    "http://www.yomiyomi.co.il/?xml=3" => [ DealsImport::YomiYomi, "www.yomiyomi.co.il" ],
    "http://www.groupisrael.co.il/Offers/xml/1" => [ DealsImport::GroupIsrael, "www.groupisrael.co.il" ],
    "http://www.couponpon.co.il/xml.php" => [ DealsImport::Couponpon, "www.couponpon.co.il" ],
    "http://www.couponeto.co.il/index/xml/type/4/affiliate/3" => [ DealsImport::Couponeto, "www.couponeto.co.il" ],
    "https://api.groupon.de/feed/api/v1/deals/oftheday/IL/tel-aviv-iw" => [DealsImport::Groupon, "www.groupon.co.il"],
    "https://api.groupon.de/feed/api/v1/deals/oftheday/IL/sharon-iw" => [DealsImport::Groupon, "www.groupon.co.il"],
    "https://api.groupon.de/feed/api/v1/deals/oftheday/IL/shfela-iw" => [DealsImport::Groupon, "www.groupon.co.il"],
    "https://api.groupon.de/feed/api/v1/deals/oftheday/IL/jerusalem-iw" => [DealsImport::Groupon, "www.groupon.co.il"],
    "https://api.groupon.de/feed/api/v1/deals/oftheday/IL/haifa-iw" => [DealsImport::Groupon, "www.groupon.co.il"],
    "https://api.groupon.de/feed/api/v1/deals/oftheday/IL/beer-sheva-iw" => [DealsImport::Groupon, "www.groupon.co.il"],
    "http://api.groupon.de/feed/api/v1/deals/oftheday/IL/national-deal" => [DealsImport::Groupon, "www.groupon.co.il"],
    "http://api.groupon.de/feed/api/v1/deals/oftheday/IL/products-iw" => [DealsImport::Groupon, "www.groupon.co.il"]
  }
  
  def self.import!
    stats = {}
    important = 0
    imported_deal_ids = []
    SOURCES.each do |url, opts|
      k = opts.first.new(url, opts.last)
      k.process! rescue nil
      stats[opts.last] = {
        :imported => k.imported,
        :skipped => k.skipped,
        :errors => k.errors,
        :messages => k.messages,
        :updated_dates => k.updated_dates
      }
      important += k.imported + k.errors + k.updated_dates
      imported_deal_ids += k.imported_deal_ids
    end

    deals_to_be_deleted = []
    Deal.current.each do |d|
      next if d.imported_deals.blank?
      if (d.imported_deal_ids & imported_deal_ids).blank?
        deals_to_be_deleted << d
      end
    end

    unless deals_to_be_deleted.blank?
      deals_to_be_deleted.map do |x|
        if x.site_id != 27 && x.site_id != 1  ## remove deals except Groupon's & BUY2
          x.ends_at = Time.now - 2.hours
          x.save(false)
          x.imported_deals.map{|x| x.ends_at=Time.now - 2.hours; x.save(false)}
    	  end
      end

      stats[:to_be_deleted] = deals_to_be_deleted.map do |d|
    	  {:id => d.id, :title => d.title, :url => d.url}
      end
    end

    important += deals_to_be_deleted.size

    UserMailer.import_stats(stats).deliver unless important.zero?
  end
end

## "http://www.yemama.co.il/rss.ashx" => [DealsImport::Yemama, "www.yemama.co.il" ],
## "http://www.dealzone.co.il/livefeed" => [DealsImport::DealZone, "www.dealzone.co.il"],
# "http://bestpriceil.co.il/dealfeed.php" => [DealsImport::Bpi, "www.bestpriceil.co.il"],
# "http://www.amama.co.il/xml.aspx?sId=11" => [DealsImport::Amama, "www.amama.co.il"],
# "http://www.bdeal.co.il/?xml=6" => [DealsImport::Bdeal, "www.bdeal.co.il"],
# "http://www.smartcoupon.co.il/deals.xml" => [DealsImport::Base, "www.smartcoupon.co.il"],
# "http://www.layladeal.co.il/xml.php" => [ DealsImport::LaylaDeal, "www.layladeal.co.il" ],
# "http://www.dr-deals.co.il/index.php?option=com_enmasse&controller=xml&tmpl=raw&idev_id=100" => [DealsImport::DrDeal, "www.dr-deals.co.il"],
# "http://www.gargir.co.il/xml/partner:1246" => [DealsImport::Gargir, "www.gargir.co.il"],
# "http://www.traveldeal.co.il/feeds/dailyd.aspx" => [DealsImport::TravelDeal, "www.traveldeal.co.il"],
# "http://www.metoraf.co.il/xml_d.aspx" => [ DealsImport::Metoraf, "www.metoraf.co.il" ],
# "http://www.my-coupon.co.il/?xml=19" => [DealsImport::MyCoupon, "www.my-coupon.co.il"],
# "http://www.my-deal.co.il/?xml=19" => [DealsImport::MyDeal, "www.my-deal.co.il"],