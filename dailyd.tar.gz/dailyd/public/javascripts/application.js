$(document).ready(function()
		  {
		      $('#deal_picture_url').change(function() 
						    {
							$("#picture_preview").html('<iframe src="' + $("#deal_picture_url").val() + '" width="300" height="300"></iframe>');
						    });


		      $('#deal_url').change(function() {

						$("#deal_preview").html('<iframe src="' + $("#deal_url").val() + '" width="300" height="300"></iframe>');
					    });

		      $('#header-subscribe-email').click(function() {
							     if ($(this).attr('value') == 'כתובת דוא”ל שלך')
							     {
								 $(this).attr({'value': ''});
							     }
							 });

		      $("#category-select").change(function () {
						       var current_path = window.location + "";
						       var new_path = '';

						       if (current_path.indexOf("?") == -1)
							   {
							       current_path = current_path + "?";
							   }

						       if (current_path.indexOf('category=') == -1)
							   {
							       new_path = current_path + "&category=" + $(this).val();
							   }
						       else
							   {
							       new_path = current_path.replace(/category=\d*/, "category=" + $(this).val());
							   }

						       window.location = new_path;
						       }
						   );

		      $("#location-select").change(function () {
						       var current_path = window.location + "";
						       var new_path = '';

						       if (current_path.indexOf("?") == -1)
							   {
							       current_path = current_path + "?";
							   }

						       if (current_path.indexOf('location=') == -1)
							   {
							       new_path = current_path + "&location=" + $(this).val();
							   }
						       else
							   {
							       new_path = current_path.replace(/location=\d*/, "location=" + $(this).val());
							   }

						       window.location = new_path;
						       }
						   );
		  });

				
function showDefaultText(field,text){
label="label_"+field.id;
if (field.value.length==0){ele=$("#"+label).text(text);}
}

function clearDefaultText(field){
label="#label_"+field.id;
ele=$(label).text("");
}

$(".error-msg-close,.success-msg-close").live('click',function() { var ele = $(this).parent().parent(); ele.hide();return false; } )


//~ var facebookLoginWindow;
//~ var loginWindowTimer;
//~ function facebookLogin(app_id,site_url)
//~ {
    //~ var popupWidth=650;
    //~ var popupHeight=300;
    //~ var xPosition=($(window).width()-popupWidth)/2;
    //~ var yPosition=($(window).height()-popupHeight)/2;
    //~ var loginUrl="http://www.facebook.com/dialog/oauth/?"+
        //~ "scope=publish_stream&"+
        //~ "client_id="+app_id+"&"+
        //~ "redirect_uri="+site_url+"subscriptions/new_fb_user&"+
        //~ "response_type=token&"+
        //~ "display=popup";
    //~ facebookLoginWindow=window.open(loginUrl, "LoginWindow",
        //~ "location=1,scrollbars=1,"+
        //~ "width="+popupWidth+",height="+popupHeight+","+
        //~ "left="+xPosition+",top="+yPosition);
 
    //~ loginWindowTimer=setInterval(onTimerCallbackToCheckLoginWindowClosure(app_id), 1000);
//~ }
//~ function onTimerCallbackToCheckLoginWindowClosure(app_id)
//~ {
	//~ //app_id= $("#face_key").attr('value');
    //~ // If the window is closed, then reinit Facebook
    //~ if (facebookLoginWindow.closed)
    //~ {
		
        //~ clearInterval(loginWindowTimer);
        //~ FB.init({
          //~ appId  :app_id ,
          //~ status : true, // check login status
          //~ cookie : true, // enable cookies to allow the server to access the session
          //~ xfbml  : true  // parse XFBML
        //~ });
 
        //~ FB.getLoginStatus(onFacebookLoginStatus);
    //~ }
//~ }

