var currentPage = 1;

function checkScroll() {
 var pathname = window.location.pathname;
  if (nearBottomOfPage()) {
    currentPage++;
    //~ new Ajax.Request('/front.js?page=' + currentPage, {asynchronous:true, evalScripts:true, method:'get'});
  location_array= []
  category_array= [] 
  site_array= []
  
  $(".location_cb:checked").each(function(){location_array.push($(this).attr('fld_val'));});
  $(".category_cb:checked").each(function(){category_array.push($(this).attr('fld_val'));});
  $(".site_cb:checked").each(function(){site_array.push($(this).attr('fld_val'));});
 searchData =  $("#search").val();

  if (location_array.length > 0 && category_array.length >0 && site_array.length > 0)
  {
   $.ajax({
    url:'/.js',
    type:'get',
    beforeSend: function(){
    if($(".dynamic_loading").length < 1)
    $(".deal_container:last").append("<div class='dynamic_loading deal_loader'>Loading more deals..<img src='/images/ajax-loader_3.gif'></img></div>");
    },
    complete: function(){$(".dynamic_loading").remove();},
    data : {page: currentPage ,
    asynchronous: true,
    locations:location_array,
    categories:category_array,
    sites:site_array,
    search_data : searchData
            }  });
  }
  else
  {
  $("#products").html("");
  $(".nothing_checked").show();
  }
//	 complete: function(){jQuery('#spinner').hide() }
  
  } else {
    setTimeout("checkScroll()", 250);
  }
}

function nearBottomOfPage() {
  return scrollDistanceFromBottom() < 150;
}

function scrollDistanceFromBottom(argument) {
if (jQuery.browser.msie) {
  return pageHeight() - (document.documentElement.scrollTop + document.documentElement.clientHeight);
}
else
{
  return pageHeight() - (window.pageYOffset + self.innerHeight);
}
}

function pageHeight() {
  return Math.max(document.body.scrollHeight, document.body.offsetHeight);
}

jQuery(checkScroll)


