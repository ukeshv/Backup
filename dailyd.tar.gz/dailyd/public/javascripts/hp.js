$(function(){
if($.cookie("bought")){	
  $("#bought_"+$.cookie("bought")).attr("class","buy_link active")
	$.cookie("bought", null);
   jQuery.facebox("הדיל נוסף לאיזור האישי שלך תחת 'שוברים שרכשתי'");
}	
if($.cookie("follow")){	
   jQuery.facebox("<p>הכנס שם עסק ו/או שם של מוצר שאתה מעוניין 'לעקוב' אחר, הוא יתווסף לך באיזור 'דיל אישי'<br/><br/><input class='fav_term_txt' type ='text'></input><input type='button'  value='לעקוב' onclick='follow();'></p>	<span id='error' style='color:red;display:none;'>ניתן להכניס מס ערכים מופרדים בפסיקים</span>");
$.cookie("follow", null);
}	
if ($.cookie("user_preference")) {
  if ($.cookie("settings_saved")) {
    $.cookie("settings_saved", null);
    $(".settings_saved").show();
  }
}

if ($.cookie('email')) {
    $(".divhello span.name").html($.cookie('email'));
    $(".divhello").show();
    $("#new_search_fld").css({"top":"5px"});
    $(".divhello a.exit").live('click',function(){
      $.cookie("email", null);
      $.cookie("filter_location_ids", null);
      $.cookie("filter_category_ids", null);
      $.cookie("filter_site_ids", null);
      $.cookie("user_preference", null);
      $.cookie("reg_user", null);/*for mysetting Jul18*/
      $.cookie("facebook_user_email", null);/*for mysetting Aug10*/			
      $.cookie("follow", null);/*for mysetting Aug11*/			
      $.cookie("bought", null);/*for mysetting Aug11*/			
      //window.location.href = "/";
      $(".divhello").hide();
      $(".preferences").hide();
      $(".divhello2").show();
      $("#new_search_fld").css({"top":"12px"});
      $(".location_cb, .category_cb, .site_cb").attr("checked", "checked");
      on_location_clicked();
      $("#home_link").html("התחבר");
    });
    $(".preferences").show();
    $("a.preferences").click(load_user_settings);
   load_user_settings();
   $("#home_link").html("איזור אישי");
  }
  else {
    $(".divhello2").show();
    $("#new_search_fld").css({"top":"12px"});
    $("#home_link").html("התחבר");
  }
});
  
$(".login-to-load").live('click', function(){
  $("#override_settings").val("false");
  $(".email-prompt").html("כניסה למערכת באמצעות כתובת מייל:");
  $(".new_email .notice").removeClass("hidden");
  $(".save-button").val("טען הגדרות");
  jQuery.facebox({div: '#dialog'});
  return false;
});

/*changes done for home page scratch*/

  function load_user_settings(){
      $('.location_cb').removeAttr("checked");
      $.each($.cookie("filter_location_ids").split(','), function(){
        $('.location_cb[filter="location_' + this + '"]').attr("checked", "checked");
      });

      $('.site_cb').removeAttr("checked");
      $.each($.cookie("filter_site_ids").split(','), function(){
        $('.site_cb[filter="site_' + this + '"]').attr("checked", "checked");
      });

      $('.category_cb').removeAttr("checked");
      $.each($.cookie("filter_category_ids").split(','), function(){
        $('.category_cb[filter="category_' + this + '"]').attr("checked", "checked");
      });
      on_location_clicked();
  }



  // location
function on_location_clicked() {
  location_array= []
  category_array= [] 
  site_array= []
  $(".location_cb:checked").each(function(){location_array.push($(this).attr('fld_val'));});
  $(".category_cb:checked").each(function(){category_array.push($(this).attr('fld_val'));});
  $(".site_cb:checked").each(function(){site_array.push($(this).attr('fld_val'));});
  searchData =  $("#search").val();
  if (location_array.length > 0 && category_array.length >0 && site_array.length > 0)
  {
      $.ajax({
      url:'/.js',
      type:'get',
      data : {locations:location_array,categories:category_array,sites:site_array,search_data:searchData,filter_deals:true,asynchronous: true},
      beforeSend: function(){$('#spinner').css({"visibility":"visible"})},
      complete: function(){$('#spinner').css({"visibility":"hidden"});reset_filter_deals();}
    });
  }
  else
  {
  $("#products").html("");
  $(".nothing_checked").show();
  $(".shown_count").html('0');
  }
}



  $(".location_cb, .category_cb, .site_cb").live("click",on_location_clicked);

/*changes done for home page scratch*/


  $(".show-only-location").click(function(){
    $('.location_cb[filter!="' + $(this).attr("id") +  '"]').removeAttr("checked");
    $('.location_cb[filter="' + $(this).attr("id")+ '"]').attr("checked", "checked");
    on_location_clicked();
    return false;
  });
  
    $(".show-only-category").click(function(){
    $('.category_cb[filter!="' + $(this).attr("id") +  '"]').removeAttr("checked");
    $('.category_cb[filter="' + $(this).attr("id")+ '"]').attr("checked", "checked");
    on_location_clicked();
    return false;
  });
  
    $(".show-only-site").click(function(){
    $('.site_cb[filter!="' + $(this).attr("id") +  '"]').removeAttr("checked");
    $('.site_cb[filter="' + $(this).attr("id")+ '"]').attr("checked", "checked");
    on_location_clicked();
    return false;
  });
  
  
/*changes done for home page scratch*/

  $("#check_all_locations").live('click',function(){
    $(".location_cb").attr("checked", "checked")
    on_location_clicked();
    return false;
  });
  
    $("#check_all_categories").live('click',function(){

     $(".category_cb").attr("checked", "checked")
     on_location_clicked();
     return false;
  });
  
    $("#check_all_sites").live('click', function(){
      $(".site_cb").attr("checked", "checked")
      on_location_clicked();
      return false;
  });
  
/*changes done for home page scratch*/


  $("#check_no_locations").live("click", function(){
    $(".location_cb").removeAttr("checked")
     on_location_clicked();
     return false;
  });

  $("#check_no_categories").live("click",function(){
    $(".category_cb").removeAttr("checked")
    on_location_clicked();
    return false;
  });
  
    $("#check_no_sites").live("click", function(){
     $(".site_cb").removeAttr("checked")
     on_location_clicked();
     return false;
  });
  

  $("#show_all").click(function(){
    $(".location_cb").attr("checked", "checked")
    $(".category_cb").attr("checked", "checked")
    $(".site_cb").attr("checked", "checked")
    on_location_clicked();
    return false;
  });

  
 // $(".site_cb, .category_cb").click(on_other_checked);




// sort
$("a.sort").click(function(){
	var o = $(this);
	var order = 1;
	if (o.attr("order")) { order = -1; }
	$("a.sort").removeClass("active").removeClass("up").removeAttr("order");
	o.addClass("active");
	var attr = o.attr("filter");
	//~ $(".deals-container").each(function(){
	//~ var deals_container = $(this);
	var product_container = $("#products");
	//~ var deals = deals_container.find(".deal_container").detach();
	var deals = $(".deal_container").detach()
	var deals = deals.sort(function(a, b){
		return order * ($(a).attr(attr) - $(b).attr(attr));
	});
	deals.appendTo(product_container);
	//~ });
	if (order == 1) {
		o.attr("order", "desc");
		o.addClass("up");
	}
return false;
});

  // boxes
  function hide_box(name){
    $("#hide_" + name + "_div").hide();
    $("#" + name + "_box").slideUp('slow');
    $("#show_" + name + "_div").show();
  }

  function show_box(name){
    $("#show_" + name + "_div").hide();
    $("#" + name + "_box").slideDown('slow');
    $("#hide_" + name + "_div").show();
  }

  $('#hide_categories').live("click", function(){
    hide_box("categories");
    return false;
  });

  $('#show_categories').live("click", function(){
    show_box('categories');
    return false;
  });

  $('#hide_locations').live("click",function(){
    hide_box("locations");
    return false;
  });

  $('#show_locations').live("click",function(){
    show_box('locations');
    return false;
  });

  $('#hide_sites').live("click",function(){
    hide_box("sites");
    return false;
  });

  $('#show_sites').live("click",function(){
    show_box('sites');
    return false;
  });

  $('#hide_news').live("click",function(){
    hide_box("news");
    return false;
  });

  $('#show_news').live("click",function(){
    show_box('news');
    return false;
  });

  setTimeout(function(){
    var head = document.getElementsByTagName("head")[0]
    var js = document.createElement("script");
    js.setAttribute("type", "text/javascript");
    js.setAttribute("src", "http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-4e280a64609a5268");
    head.appendChild(js);
  }, 0);

//});

function missingImage(i)
{ 
  i.src = "/images/default.jpg";
  return true;
}


$('.save_settings').live("click",function(){
 //$("#header-subscribe-email").val($.cookie('email'));
  //submit_user_form();
if ($.cookie("email")) {
var locations = $.map($(".location_cb:checked"), function(n, i){return $(n).attr("filter").split("_")[1]});
var sites = $.map($(".site_cb:checked"), function(n, i){return $(n).attr("filter").split("_")[1]});
var categories = $.map($(".category_cb:checked"), function(n, i){return $(n).attr("filter").split("_")[1]});
locations = locations.join(",")
sites = sites.join(",")
categories = categories.join(",")

  $.ajax({
    url:'/front/save_filters',
    type:'get',
    data : {email: $.cookie('email') ,
            location_ids : locations,
            site_ids: sites,
            category_ids: categories
            },
  complete: function(){ 
  if ($.cookie("settings_saved")) {
    $.cookie("settings_saved", null);
  //  $(".settings_saved").show();
    jQuery.facebox("ההגדרות שלך נשמרו בהצלחה");
   }
  }
  });
}

else
{
   $("#override_settings").val("true");
   $(".email-prompt").html("לשמירת הגדרות וקבלת המייל היומי אנא הכנס כתובת מייל:");
   $(".new_email .notice").addClass("hidden");
   $(".save-button").val("שמור");
   
    var locations = $.map($(".location_cb:checked"), function(n, i){return $(n).attr("filter").split("_")[1]});
    var sites = $.map($(".site_cb:checked"), function(n, i){return $(n).attr("filter").split("_")[1]});
    var categories = $.map($(".category_cb:checked"), function(n, i){return $(n).attr("filter").split("_")[1]});
   
   html_popup = "<span class='email-prompt'>לשמירת הגדרות וקבלת המייל היומי אנא הכנס כתובת מייל:</span><br/><span id='error_email' style='display:none;color:red'>הכתובת אינה תקינה.  נסה שנית</span><br/><form id='form_new'><input type='text' name='email' class='new_email'><input type='hidden' name='location_ids' value='"+locations.join(',')+"' id='dialog_save_loc'><input type='hidden' name='category_ids' value='"+categories.join(',')+"' id='dialog_save_cat'><input type='hidden' name='site_ids' value='"+sites.join(',')+"' id='dialog_save_site'><input type='submit' class='save-button' id='save_settings_new' value='שמור'><img src='/images/ajaxSpinner.gif' id='ajax_spinner' style='display:none'></img><div class='notice rtl'>שים לב, במידה ואינך משתמש רשום, הכנסת כתובת מייל מאשרת הרשמה וקבלת מייל יומי</div></form>"
   jQuery.facebox(html_popup);

   //~ load_user_settings();
}
return false;
});

$("#save_settings_new").live('click',function(){
 $.ajax({
  url:'/front/save_filters',
  type:'get',
  data : $("#form_new").serialize(),
  beforeSend: function(){$('#ajax_spinner').show()},
  success : function(response){
  $('#ajax_spinner').hide();
  if(response == "error")
  {
  $("#error_email").show();
  }
  else
  {
  //  jQuery(document).trigger('close.facebox');
    $(".divhello span.name").html($.cookie('email'));
    $(".divhello").show();
    $("#new_search_fld").css({"top":"5px"});
    //$(".settings_saved").show();
    $(".content").html("ההגדרות שלך נשמרו בהצלחה");
    $(".divhello2").hide();
    $(".preferences").show();
   $("a.preferences").click(load_user_settings);
    load_user_settings();
  }
  }
  });

return false;
});

$(document).bind('reveal.facebox', function() { 
    $("#facebox input.new_email").focus();
    $("#facebox form.new_email").submit(function(){
      $("#header-subscribe-email").val($(this).find("input.new_email").val());
      jQuery(document).trigger('close.facebox');
      submit_user_form();
      return false;
    });
   })
   

 $(".divhello a.exit").live('click',function(){
      $.cookie("email", null);
      $.cookie("filter_location_ids", null);
      $.cookie("filter_category_ids", null);
      $.cookie("filter_site_ids", null);
      $.cookie("user_preference", null);
      //window.location.href = "/";
			$.cookie("reg_user", null);/*for mysetting Jul18*/
      $(".divhello").hide();
      $(".preferences").hide();
      $(".divhello2").show();
      $("#new_search_fld").css({"top":"12px"});
      $(".location_cb, .category_cb, .site_cb").attr("checked", "checked");
      on_location_clicked();
      $("#home_link").html("התחבר");
    });
    
//for mysettings added on JULY 15


function terms(deal) 
{ 
	 $.ajax({
  url: '/settings/add_follow?deal='+deal,
  cache: false,
  success: function(data){
		if (data=="nofulluser"){
    window.location = "/settings/favorites?f="+deal}
		else if(data=="nouser"){window.location = "/subscriptions/new?f="+deal}
		else{
		$('#term').html(data);
		$('#term').show();
    jQuery.facebox({div: '#term'});
		$('#term').css({"display":"none"})}
  }
  });	
//~ $("#deal").val(deal);
$("#deal").hide();
}

function follow()
{ 
var term=$("input[class=fav_term_txt]:visible").val();
if (term.length==0)
{
$(".popup .content #error").show()
}
else
{
  $.ajax({
  url: '/settings/follow',
  cache: false,
  contentType: "application/x-www-form-urlencoded; charset=UTF-8",
  data: "term="+encodeURIComponent(term),
  success: function(data){
$(".popup .content #error").hide()
$('.close').trigger('click')		
  }
  });
  }
  return false;
}

function bought(id,ele)
{
if ($(ele).attr("class") == "buy_link")
{
act = "add"
}
else
{
act ="delete"
}
  $.ajax({
  url: '/settings/'+id+'/bought',
  data : {default_action: act},
  cache: false,
  success: function(data){
		 if (data=="nofulluser"){window.location = "/settings/favorites?b="+id}
		else if(data=="nouser"){window.location = "/subscriptions/new?b="+id}
    else{
      if($(ele).attr('class') == 'buy_link'){
      $(ele).attr('class','buy_link active');
      jQuery.facebox("הדיל התווסף לרשימת 'שוברים שרכשתי' בהצלחה, רשימת השוברים נמצאת באיזור האישי");
      }
      else{
      $(ele).attr('class','buy_link')
      jQuery.facebox("דיל הוסר מרשימת קופונים קנה");
      };
}
  }
  });
  return false;
}
 
function show_filter_button(){
 count=$(".watch_link.filter_deal.active").length	
	if (count >=1){
  //$("#watch_deals").show()
  }
	else{
	//	$("#watch_deals").hide()
  $("#watch_deals").attr("value","סנן דילים נבחרים")
  $('.watch_deals').show();
	$("#watch_deals").attr("class","spa-link filter_inactive")
	}
}

function reset_filter_deals()
{
//  $('#watch_deals').show();
  $("#watch_deals").attr("class","spa-link filter_inactive")
  $(".watch_link.filter_deal.active").attr("class","watch_link filter_deal");
 // $("#watch_deals").hide()
}
    
function filter_deals()
{
ele=$("#watch_deals")
deals_active=$(".watch_link.filter_deal.active")
  if(deals_active.length < 1)
  {
    jQuery.facebox("על מנת לסנן דילים נבחרים, עליך לסמן אותם על-ידי לחיצה על כפתור 'מעניין אותי' אשר נמצא בכל אחד מהדילים");
    //$("#watch_deals").html(" מעניין אותי")
    $("#watch_deals").attr("class","spa-link filter_inactive")
  }
  else
  {
      if (deals_active.length==$("[class=watch_deals]:visible").length)
      {
           $('.watch_deals').show();
          //$("#watch_deals").html(" מעניין אותי")
          $("#watch_deals").attr("class","spa-link filter_inactive")
       }
        else{
          $(".watch_link.filter_deal").closest("div.watch_deals").hide();
          $(".watch_link.filter_deal.active").closest("div.watch_deals").show();
          //ele.attr("value","חזרה לתצוגה רגילה")
          //$("#watch_deals").html("חזרה לתצוגה רגילה")
          $("#watch_deals").attr("class","spa-link filter_active")
       }
   }
 return false;
}



$("#search_form").live("submit", function(){
 on_location_clicked();
 return false;
});
