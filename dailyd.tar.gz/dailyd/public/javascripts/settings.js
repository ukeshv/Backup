function favorites(type)
{
$('#list_'+type).attr('class','active');
if (type=="follow"){$('#list_bought').attr('class','');}
else if (type=="bought"){$('#list_follow').attr('class',' ');}
$.ajax({
            url: '/settings/find_favorite_type?type='+type,
						beforeSend: function(){$("#ajax_spin").show();},
						success: function(data){
						$('#deals').html(data);
						},
						complete: function(){$("#ajax_spin").hide();}
            });
		return false;
}
	
  
function fav_terms() 
{ 
    jQuery.facebox({div: '#fav_term'});
  }
	
function reminder(id,date)
{  
	jQuery.facebox({div: '#reminder'});
	$('[class=dp-choose-date]').remove();	
	$('[class=deal]:hidden').attr('value',id);
	$('.date-pick').datePicker().val(new Date().asString()).trigger('change');	
	if (date!=null){$('.popup .content input[class=date-pick dp-applied]').val(date);}
}	
	
function delete_terms(term)
{
	var answer=confirm("האם אתה בטוח שברצונך למחוק?")
	if (answer){
       $.ajax({
            url: '/settings/delete_terms?term='+term,
						success: function(data){
						$('#deals').html(data);},
						complete: function(){$("#delete_term_msg").show();}
            });
		return false;
	}
}

function add_term()
{	
term=$("input[class=fav_term_txt]:visible").val();
		if (term.length==0)
	{
	$(".popup .content #error").show()
	}
	else
	{
   $.ajax({
			url: '/settings/fav_add_terms',
			cache: false,
		  contentType: "application/x-www-form-urlencoded; charset=UTF-8",
      data: "term="+encodeURIComponent(term),
      success: function(data){
						$('#deals').html(data);						 
            $(".popup .content #error").hide()
            $('.close').trigger('click')				
						}
            });
	}
		return false;
}

function add_reminder()
{
id=	$('[class=deal]:hidden').val();
date=$('[class=date-pick dp-applied]:visible').val();
	if (date.length==0){	$(".popup .content #error").show()}
		else{
$.ajax({
            url: '/settings/'+id+'/add_reminder?date='+date,
            cache: false,
			     success: function(data){
						$('#deals').html(data);
            $('.close').trigger('click')				
						}
            });
					}
		return false;
}

 function delete_reminder(id)
  {
 $.ajax({
            url: '/settings/'+id+'/delete_reminder',
            cache: false,
			     success: function(data){
						$('#deals').html(data);
            $('.close').trigger('click')				
						}
            });
						return false;
 }

function delete_follow_deals(id)
{
		var answer=confirm("האם אתה בטוח שברצונך למחוק?")
if (answer){
   $.ajax({
            url: '/settings/delete_follow_deals?id='+id,
						success: function(data){
						$('#deals').html(data);
						},
						complete: function(){$("#delete_deal_msg").show();}
            });
		return false;}
}
function delete_bought_deals(id)
{
		var answer=confirm("האם אתה בטוח שברצונך למחוק?")
if (answer){
   $.ajax({
            url: '/settings/delete_bought_deals?id='+id,
						success: function(data){
						$('#deals').html(data);
						},
						complete: function(){$("#delete_deal_msg").show();}
            });
		return false;}
}


$("#pref-form").live('submit',function(){
	length=$("input[type=checkbox]:checked").length
	if (length>=1){return true;}
	 else{
		 $("#success_msg").hide()
		 $("#pref_error").show();
		 $('html, body').animate({ scrollTop: 0 }, 0);
		 return false;
		 }	
});
			

function removeall(type){				
		$("input[class="+type+"]").removeAttr("checked")
}
	
	
function checkall(type){
		$("input[class="+type+"]").attr("checked","checked")  			
	}
	
 //~ jQuery("#verify-full-user").live('submit',function(){
 //~ $("#reg_error").show();
 //~ return false; 
 //~ });
 
 /* for phone message settings*/




function show_phone(type,ele)
{
	$.ajax({
            url: '/settings/message_setting?type='+type,
            cache: false,
			     success: function(data){
						$('#'+ele).html(data);
						}
            });
			return false;
		}
$(".term").live('click',function(){	
	jQuery.facebox({div: '#terms_box'});
 return false;
});


$(".tag-menu li").live('click',function(){
$(".tag-menu li").attr('class','');
$(this).attr('class',"active");
var ele_id = $(this).attr('id');
	switch (ele_id) {
	case('first_tab') :
		$(".tag-list").html("<p>עלות הודעה 1 ש'ח. במהלך החודש תשלחנה לא יותר מ-31 הודעות (מקסימום הודעה 1 ביום), החיוב החודשי הנו בין 0 ש'ח ל-31 <br/>ש'ח בהתאם למספר ההודעות שנשלחו בחודש, בכפוף לתקנון</p>");
		break;
	case('second_tab') :
		$(".tag-list").html("<p>להסרה מהשירות בכל עת, שלחו הודעת SMS למספר 4949 עם הצירוף 'דילאישי הסר'</p>");
		break;
	case('third_tab') :
		$(".tag-list").html("<p>השירות ניתן ע'י חברת וי.אר אינטראקטיב (דיילי די), ניתן ליצור קשר עם שירות לקוחות בטלפון 054-3080090 בשעות 08:00 - 17:00<br/> ובמייל בכתובת support@dailyd.co.il</p>");
		break;
	case('fourth_tab') :
		$(".tag-list").html("<p>השירות מיועד למכשירים סלולאריים בכל הרשתות אשר תומכים ב-SMS</p>");
		break;
	case('fifth_tab') :
		$(".tag-list").html("<p>השירות בהתאם <a href='#' class='term'>לתקנון</a></p>");
		break;
	}
return false;
}
);

