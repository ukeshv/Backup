require 'spec_helper'

describe ApiController do

end
