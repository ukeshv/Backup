require 'spec_helper'

describe FrontController do

end
