require 'spec_helper'

describe ImportsController do

end
