require 'spec_helper'

describe MapsController do

end
