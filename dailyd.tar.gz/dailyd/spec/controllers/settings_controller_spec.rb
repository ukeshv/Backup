require 'spec_helper'

describe SettingsController do

end
