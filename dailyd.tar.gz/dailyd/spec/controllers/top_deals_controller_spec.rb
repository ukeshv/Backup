require 'spec_helper'

describe TopDealsController do

end
