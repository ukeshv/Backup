require 'spec_helper'

describe Follow do
  pending "add some examples to (or delete) #{__FILE__}"
end
