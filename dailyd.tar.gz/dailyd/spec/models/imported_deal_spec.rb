require 'spec_helper'

describe ImportedDeal do
  pending "add some examples to (or delete) #{__FILE__}"
end
