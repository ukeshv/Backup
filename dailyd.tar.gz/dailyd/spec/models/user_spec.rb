require File.dirname(__FILE__) + '/../spec_helper'

describe User do
  before :each do
    @all_locations = [mock_model(Location, :id => 1), mock_model(Location, :id => 2)]
    @current_deals = [
      mock_model(Deal, :id => 1, :site_id => 1, :locations => @all_locations, :category_ids => [1, 2, 3]),
      mock_model(Deal, :id => 2, :site_id => 1, :locations => @all_locations, :category_ids => [1, 2]),
      mock_model(Deal, :id => 3, :site_id => 2, :locations => @all_locations.first, :category_ids => [1]),
      mock_model(Deal, :id => 4, :site_id => 2, :locations => @all_locations.last, :category_ids => [2]),
    ]
    @deals_by_location = {
      1 => [1, 2, 3],
      2 => [4]
    }
    @user = User.new
  end

  it "should have all deals" do
    @user.stub!(:locations).and_return(@all_locations)
    @user.stub!(:category_ids).and_return([1, 2, 3])
    @user.stub!(:site_ids).and_return([1, 2])
    r = @user.deal_ids_for_email({}, @deals_by_location, @current_deals.index_by(&:id))
    r.should == [{:location_id=>1, :deal_ids=>[1, 2, 3]}, {:location_id=>2, :deal_ids=>[4]}]
  end

  it "should have only location #1 deals" do
    @user.stub!(:locations).and_return(@all_locations[0..0])
    @user.stub!(:category_ids).and_return([1, 2, 3])
    @user.stub!(:site_ids).and_return([1, 2])
    r = @user.deal_ids_for_email({}, @deals_by_location, @current_deals.index_by(&:id))
    r.should == [{:location_id=>1, :deal_ids=>[1, 2, 3]}]
  end

  it "should have categorized deals" do
    @user.stub!(:locations).and_return(@all_locations)
    @user.stub!(:category_ids).and_return([2])
    @user.stub!(:site_ids).and_return([1, 2])
    r = @user.deal_ids_for_email({}, @deals_by_location, @current_deals.index_by(&:id))
    r.should == [{:location_id=>1, :deal_ids=>[1, 2]}, {:location_id=>2, :deal_ids=>[4]}]
  end

  it "should not have deals - no matching category" do
    @user.stub!(:locations).and_return(@all_locations)
    @user.stub!(:category_ids).and_return([4])
    @user.stub!(:site_ids).and_return([1, 2])
    r = @user.deal_ids_for_email({}, @deals_by_location, @current_deals.index_by(&:id))
    r.should == []
  end

  it "should have deals by site" do
    @user.stub!(:locations).and_return(@all_locations)
    @user.stub!(:category_ids).and_return([1, 2, 3])
    @user.stub!(:site_ids).and_return([2])
    r = @user.deal_ids_for_email({}, @deals_by_location, @current_deals.index_by(&:id))
    r.should == [{:location_id=>1, :deal_ids=>[3]}, {:location_id=>2, :deal_ids=>[4]}]
  end

  it "should use prefered deals" do
    @user.stub!(:locations).and_return(@all_locations)
    @user.stub!(:category_ids).and_return([1, 2, 3])
    @user.stub!(:site_ids).and_return([1, 2])
    r = @user.deal_ids_for_email({"1" => {"2" => "1"}}, @deals_by_location, @current_deals.index_by(&:id))
    r.should == [{:location_id=>1, :deal_ids=>[2], :more_count => 2}, {:location_id=>2, :deal_ids=>[4]}]
  end

  it "should set 2 deals per location" do
    @user.stub!(:locations).and_return(@all_locations)
    @user.stub!(:category_ids).and_return([1, 2, 3])
    @user.stub!(:site_ids).and_return([1, 2])
    r = @user.deal_ids_for_email({}, @deals_by_location, @current_deals.index_by(&:id), 2)
    r.should == [{:location_id=>1, :deal_ids=>[1, 2], :more_count => 1}, {:location_id=>2, :deal_ids=>[4]}]
  end
end
