require 'spec_helper'

describe "messages/edit.html.erb" do
  before(:each) do
    @message = assign(:message, stub_model(Message,
      :new_record? => false,
      :deal_id => 1,
      :user_id => 1
    ))
  end

  it "renders the edit message form" do
    render

    # Run the generator again with the --webrat-matchers flag if you want to use webrat matchers
    assert_select "form", :action => message_path(@message), :method => "post" do
      assert_select "input#message_deal_id", :name => "message[deal_id]"
      assert_select "input#message_user_id", :name => "message[user_id]"
    end
  end
end
