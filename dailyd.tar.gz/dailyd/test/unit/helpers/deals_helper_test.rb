require 'test_helper'

class DealsHelperTest < ActionView::TestCase
end
