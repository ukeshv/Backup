class AdminController < ApplicationController
	include AuthenticatedSystem
  layout 'admin', :except=>[:article_version_preview]
  before_filter :check_login
  before_filter :admin_login_required
	protect_from_forgery :except=>[:display_article_version]
	def category_index
		@categories=Category.find(:all)
	end
	
  def category_list
		@categories = Category.paginate(:all,:per_page =>10,:page=>params[:page])		
	end
  
  def category_new
		@Category = Category.new
	end
	
	def category_create
		@category=Category.new(params[:category])
    if @category.save
      flash[:notice] = @category.name+' '+'Category is successfully created.'
      redirect_to :action => 'category_list'
    else
       render :action => 'category_new'
    end    
	end
  
  def category_edit
		 @category=Category.find(params[:id])
	end
		
	def category_update
		@category = Category.find(params[:id])
      if @category.update_attributes(params[:category])
        flash[:notice] = @category.name+' '+ 'is successfully updated'
        redirect_to :action => 'category_list', :id => @category
      else       
        render :action => 'category_edit'
      end
	end
	
	def category_delete
		@category = Category.find_by_id(params[:id])
		category_name=@category.name
		@category.destroy if @category
    flash[:notice] =category_name+' '+' Category is deleted'
    redirect_to :action => 'category_list'  
	end
	
  def category_flag
    if params[:id]
		@category = Category.find(params[:id])
		@category.update_attributes({:flag=>params[:flag]})
    #Category.update(params[:id],{:flag=>params[:flag]}) 
		if (@category.flag==0)
		flash[:notice] = @category.name+' '+ 'Category is successfully activated'
		else
		flash[:notice] = @category.name+' '+ 'Category is successfully deactivated'	
		end
    redirect_to :action => 'category_list'    
    end
  end
  

  
   def article_index
		@article=Article.find(:all)
	end
	
  def article_list
		@article = Article.paginate(:all,:per_page =>10,:page=>params[:page])
	end
  
	def article_new
		@article = Article.new
	end
	
	def article_create
		@article=Article.new(params[:article])
		unless (params[:article][:category_id].nil?)
			if @article.save
				flash[:notice] = 'New article Is Successfully Created'
				redirect_to :action => 'article_list'
			else
				flash[:notice]='Question or Answer Should not be blank'
				render :action => 'article_new'
			end    
		else
			flash[:notice]='Category Should not be blank'
			render :action => 'article_new'
		end
	end
	
def article_show
	@article=Article.find(params[:id])
	@article_versions = @article.versions.collect{|x| x.version}
end	


  def display_article_version
	current_article = Article.find(params[:article_id])
    @article = current_article.versions.find(:first,:conditions=>['article_id = ? and version = ?',params[:article_id],params[:version_id]])
    render :update do |page|
    page.replace_html 'show_article_content',:partial=>'version'
		page.replace_html 'show_article_conformation',:partial=>'conformation_msg', :locals=>{:version_id => params[:version_id],:article_id => params[:article_id]}
    end  
	end
	
  def article_edit
		 @article=Article.find(params[:id])
	end
		
	def article_update
		@article = Article.find(params[:id])
      if @article.update_attributes(params[:article])
        flash[:notice] = 'article Is Successfully Updated'
        redirect_to :action => 'article_list', :id => @article
      else       
        render :action => 'article_edit'
      end
	end
	
	def article_delete
		Article.delete(params[:id])
    flash[:notice] ="The article Is Deleted"
    redirect_to :action => 'article_list'  
	end
	
  def article_flag
    if params[:id]
     Article.update(params[:id],{:flag=>params[:flag]}) 
     redirect_to :action => 'article_list'    
    end
  end
	
	def comment_list
		 @comment = Comment.paginate(:all,:per_page =>10,:page=>params[:page])
	end
  
  def comment_edit
		 @comment=Comment.find(params[:id])
	end
		
	def comment_update
		@comment = Comment.find(params[:id])
      if @comment.update_attributes(params[:comment])
        flash[:notice] = 'comment is Successfully Updated'
        redirect_to :action => 'comment_list', :id => @comment
      else       
        render :action => 'comment_edit'
      end
   end
  
  def comment_delete
		Comment.delete(params[:id])
    flash[:notice] ="The Comment Is Deleted"
    redirect_to :action => 'comment_list'  
	end
  
  def approve_comment
    if params[:id]
     Comment.update(params[:id],{:admin_approval=>params[:flag]}) 
     redirect_to :action => 'comment_list'    
    end
  end

#Method to revert to specified version for an article
		def revert_article_version
			article = Article.find(params[:article_id])
			article.revert_to! params[:version_id]
			flash[:notice] = "Article reverted to version #{params[:version_id]}"
			redirect_to :controller=>'admin',:action => 'article_list'
		end  
		
		def article_version_preview
		@article=Article.find(params[:id])
		end
end
