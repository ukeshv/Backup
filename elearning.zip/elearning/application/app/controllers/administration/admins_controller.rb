class Administration::AdminsController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  include AuthenticatedSystem
  layout 'admin'
  before_filter :check_login
  before_filter :admin_login_required
  
  def dashboard
    @exams = Exam.find(:all, :order=>'exam_date DESC')
  end
	
	def dashboard_group_result
	@group_exams=GroupExam.paginate(:all ,:page => params[:page], :per_page =>10, :order=>'exam_date DESC')
	end	
	
	def dashboard_emp_result
	@employee_exams=EmployeeExam.paginate(:all, :conditions=>['assigned_to_employee=?', 1] , :page => params[:page], :per_page =>10, :order=>'exam_date DESC')	
  end	

  #~ def display_result
    #~ @exam = Exam.find(params[:id])
    #~ @result = @exam.employee_exams.find(:all, :order=>'total_correct_answer DESC')
  #~ end 
  
  def print_result
    @group = Group.find(params[:group_id])
    @exam = Exam.find(params[:id])
    @result = @exam.employee_exams.find(:all, :conditions=>['exam_date = ?', @exam.exam_date], :order=>'total_correct_answer DESC')
     render :layout=>false
  end 
	
  def new
    @admin = Admin.new
    respond_to do |format|
      format.html 
      format.xml  { render :xml => @admin }
    end
  end
 
 
  def show
    @admin = Admin.find(params[:id])
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @admin }
    end
  end
  
  def index
    @admin = Admin.find(:all)
    @length=@admin.length
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @admin }
    end
  end
  
  def edit
    @admin = Admin.find(params[:id])
  end
  
  def update
    @admin = Admin.find(params[:id])
    respond_to do |format|
      if @admin.update_attributes(params[:admin])
        flash[:notice] = 'Group was successfully updated.'
        format.html { redirect_to('/administration/admins') }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @admin.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  def create
    @admin = Admin.new(params[:admin])
    respond_to do |format|
      if @admin.save
        flash[:notice] = 'admin was successfully created.'
        format.html { redirect_to(administration_admins_path) }
        format.xml  { render :xml => @admin, :status => :created, :location => @admin }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @admin.errors, :status => :unprocessable_entity }
      end
    end
  end

  def destroy
    @admin = Admin.find(params[:id])
    @admin.destroy
    respond_to do |format|
      format.html { redirect_to(administration_admins_path) }
      format.xml  { head :ok }
    end
  end
 
  def result
    @result = []
    @temp = []
    @group_exam = GroupExam.find(params[:id])
    @exam = @group_exam.exam
    @group_exam.group.employee_ids.each do |employee_id|
      @employee_exams=EmployeeExam.find(:first, :conditions=>['exam_id=? and employee_id=? and exam_date=?', @group_exam.exam_id, employee_id, @group_exam.exam_date])
      if @employee_exams
        @temp<<@employee_exams.employee.firstname
        @temp<<@employee_exams.total_correct_answer
        @temp<<@employee_exams.employee.email
        @temp<<@employee_exams.is_completed
      end
      @result<<@temp
      @temp=[]      
    end
    #~ @group_exam = GroupExam.find(params[:id])
    #~ @exam = @group_exam.exam
    #~ @result = @exam.employee_exams.find(:all, :conditions=>['exam_date = ?', @exam.exam_date], :order=>'total_correct_answer DESC')
  end
  
  def employee_result
    
    if (params[:exam_id] and params[:employee_id] and params[:exam_date])
      date=Time.parse(params[:exam_date])
       @employee_exams=EmployeeExam.find(:first, :conditions=>['exam_id=? and employee_id=? and assigned_to_employee=? and exam_date=?', params[:exam_id],  params[:employee_id], 1 , date ])
     end
  end
  
  def activate
    logout_keeping_session!
    admin = Admin.find_by_activation_code(params[:activation_code]) unless params[:activation_code].blank?
    case
    when (!params[:activation_code].blank?) && admin && !admin.active?
      admin.activate!
      flash[:notice] = "Signup complete! Please sign in to continue."
      redirect_to '/login'
    when params[:activation_code].blank?
      flash[:error] = "The activation code was missing.  Please follow the URL from your email."
      redirect_back_or_default('/')
    else 
      flash[:error]  = "We couldn't find a admin with that activation code -- check your email? Or maybe you've already activated -- try signing in."
      redirect_back_or_default('/')
    end
  end
end
