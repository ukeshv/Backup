class Administration::EmployeesController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  include AuthenticatedSystem
  layout 'admin'
  before_filter :check_login
  before_filter :admin_login_required

  # render new.rhtml
  def new
    @employee = Employee.new
    respond_to do |format|
      format.html 
      format.xml  { render :xml => @employee }
    end
  end
 
 
  def show
    @employee = Employee.find(params[:id])
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @employee }
    end
  end
  
  def index
    @employee = Employee.paginate(:all,:per_page =>10,:page=>params[:page])	
    @length=@employee.length
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @employee }
    end
  end
  
  def edit
    @employee = Employee.find(params[:id])
  end
  
  def update
    @employee = Employee.find(params[:id])
    respond_to do |format|
      if @employee.update_attributes(params[:employee])
        flash[:notice] = 'Group was successfully updated.'
        format.html { redirect_to('/administration/employees') }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @employee.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  def create
  @employee = Employee.new(params[:employee])
    respond_to do |format|
      if @employee.save
        #~ if params[:mail] 
          #~ EmployeeMailer.deliver_support_notification(params[:employee][:login], params[:employee][:password], params[:employee][:email])
        #~ end
        flash[:notice] = 'employee was successfully created.'
        format.html { redirect_to(administration_employees_path) }
        format.xml  { render :xml => @employee, :status => :created, :location => @employee }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @employee.errors, :status => :unprocessable_entity }
      end
    end
  end

  def destroy
    @employee = Employee.find(params[:id])
    @employee.destroy

    respond_to do |format|
      format.html { redirect_to(administration_employees_path) }
      format.xml  { head :ok }
    end
  end
  
  def activate
    logout_keeping_session!
    employee = Employee.find_by_activation_code(params[:activation_code]) unless params[:activation_code].blank?
    case
    when (!params[:activation_code].blank?) && employee && !employee.active?
      employee.activate!
      flash[:notice] = "Signup complete! Please sign in to continue."
      redirect_to '/login'
    when params[:activation_code].blank?
      flash[:error] = "The activation code was missing.  Please follow the URL from your email."
      redirect_back_or_default('/')
    else 
      flash[:error]  = "We couldn't find a employee with that activation code -- check your email? Or maybe you've already activated -- try signing in."
      redirect_back_or_default('/')
    end
  end
  
  def print_employees
    @emp = Employee.find(:all, :order=>"firstname")
    render :layout => false
  end 
end
