class Administration::ExamsController < ApplicationController
  include AuthenticatedSystem
  layout 'admin'
  before_filter :check_login
  before_filter :admin_login_required
  
  # GET /exams
  # GET /exams.xml
  def index
    @exams = Exam.paginate(:all,:per_page =>10,:page=>params[:page])		
    respond_to do |format|
    format.html # index.html.erb
    format.xml  { render :xml => @exams }
    end
  end

  # GET /exams/1
  # GET /exams/1.xml
  def show
    @exam = Exam.find(params[:id])
    @questions=@exam.questions 
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @exam }
    end
  end

  # GET /exams/new
  # GET /exams/new.xml
  def new
    @exam = Exam.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @exam }
    end
  end

  # GET /exams/1/edit
  def edit
    @exam = Exam.find(params[:id])
    @questions=@exam.questions
     if((@exam.available_mins.to_i)==1800)
     @exam.available_mins=""
    else
    @exam.available_mins =((@exam.available_mins.to_i ) / 3600)
    end
  end

  # POST /exams
  # POST /exams.xml
  def create
    @exam = Exam.new(params[:exam])
    @exam.exam_date = params[:exam_date]
    if ((params[:exam][:available_mins].empty?) || (params[:exam][:available_mins].to_i ==0))
    @exam.available_mins=1800 if @exam.valid?
    else
    @exam.available_mins = ((params[:exam][:available_mins].to_i) * 3600 )
   end
    respond_to do |format|
      if @exam.save
        flash[:notice] = 'Exam was successfully created.'
        format.html { redirect_to(administration_exams_path) }
        format.xml  { render :xml => @exam, :status => :created, :location => @exam }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @exam.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /exams/1
  # PUT /exams/1.xml
  def update
    @exam = Exam.find(params[:id])
    if params[:trueorfalse]
      @trueorfalse=params[:trueorfalse]
      @trueorfalse.each do |trueorfalse|
        @question= Question.find(trueorfalse[0])
        @question.update_attributes(trueorfalse[1])
      end
    end
    if params[:fillup]
      @fillup=params[:fillup]
      @fillup.each do |fillup|
        @question= Question.find(fillup[0])
        @question.update_attributes(fillup[1])
      end
    end
    if params[:choose]
      @choose=params[:choose]
      @choose.each do |choose|
        @question= Question.find(choose[0])
        @question.update_attributes(choose[1])
      end
    end
    if params[:question_image]
      if params[:answer]
        @answer=params[:answer]
        @answer.each do |answer|
          @question= Question.find(answer[0])
          @question.update_attributes(:answer_flag => answer[1])
        end
      end      
      if params[:question_title]
          all_titles=params[:question_title]
          all_titles.each do |each_title|
              q=Question.find(each_title[0])
              update_fourth_element_on_title(q, each_title[1])
          end
      end
      all_photos = params[:question_image]
	    all_photos.each do |each_photo|
        image_id = each_photo[0].split(',').first
        image_obj = each_photo[1]        
        if !image_obj
        else
          @imageupload = Imageupload.find(image_id)
          @imageupload.update_attributes(image_obj)
          @question = @imageupload.question          
          image_url="<img src='"+@imageupload.public_filename+"'/>"
          option= each_photo[0].split(',').last
          if option.to_i == 1
            @question.update_attributes(:option1 => image_url)
          elsif option.to_i == 2
            @question.update_attributes(:option2 => image_url)
          elsif option.to_i == 3
            @question.update_attributes(:option3 => image_url)
          elsif option.to_i == 4
            @question.update_attributes(:option4 => image_url)
          else
            if option.to_i == 11
              update_question_title(@question,0,image_url)
            elsif option.to_i == 12
              update_question_title(@question,1,image_url)
            else
              update_question_title(@question,2,image_url)
            end
          end
        end
	    end 
    end
    respond_to do |format|
        if ((params[:exam][:available_mins].to_i)==0)
         available_mins=1800
        else
         available_mins = ((params[:exam][:available_mins].to_i ) * 3600)
        end
      if @exam.update_attributes(params[:exam])
        @exam.update_attributes(:available_mins=>available_mins)
        @exam.update_attributes(:exam_date=>params[:exam_date])
        flash[:notice] = 'Exam was successfully updated.'
        format.html { redirect_to(administration_exams_path) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @exam.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  def update_question_title(question_obj, num, url_of_image)
      title_arr = question_obj.title.split('&nbsp;')
      title_text = title_arr.pop      
      title_arr[num]= url_of_image
      final_title = title_arr.join('&nbsp;')+"&nbsp;"+title_text
      question_obj.update_attributes(:title => final_title)
  end
    
  def update_fourth_element_on_title(q_obj,title)
       title = " " if title=="" 
      arr = q_obj.title.split('&nbsp;')
      arr[3] = title
      new_arr=arr.join('&nbsp;')
      q_obj.update_attributes(:title => new_arr)
  end

  # DELETE /exams/1
  # DELETE /exams/1.xml
  def destroy
    @exam = Exam.find(params[:id])
    @exam.destroy
     respond_to do |format|
      format.html { redirect_to(administration_exams_path) }
      format.xml  { head :ok }
    end
  end
  
  def delete_question
    @question=Question.find(params[:question_id])
    @question.destroy
  end
      
  def assign_exam
    flash[:exam_question_nil] = " "
    @exam=Exam.find(params[:id])
    if @exam.questions.size == 0 
      flash[:exam_question_nil] = "Exam does not have any question, Create question & then assign "
      redirect_to administration_exams_path
    end
  end    
  
  def assign_exam_to
    if params[:assign]    
      if params[:assign] == "Group"
        @exam=Exam.find(params[:id])
        @groups=Group.find(:all)
        render :action =>:assign_exam_to_group
      elsif params[:assign] == "Employee"
        @exam=Exam.find(params[:id])
        @employee=Employee.find(:all)
        render :action =>:assign_exam_to_employee
      end
    else
      redirect_to :action =>:assign_exam
      flash[:error]="select employee or group to assign exam" 
    end  
  end
  
  def assign_exam_to_group
  end
  
  def assign_exam_to_employee
  end
 
  def save_assigned_exam_to_group
    #add field assigned_to_employee and set value as zero
    if params[:selected_groups_list]
      @exam=Exam.find(params[:id])
      @selected_list=params[:selected_groups_list]
      @selected_list.each do |group_id|
        @group=Group.find(group_id) 
        date=@exam.exam_date
        available_mins=@exam.available_mins 
        total_questions=@exam.questions.size
        if @group.employees
          @group.employees.each do |employee|
            EmployeeExam.find_or_create_by_employee_id_and_exam_id_and_exam_date(
              :employee_id=>employee.id,
              :exam_id=>@exam.id,
              :total_questions=> total_questions,
              :available_mins=>available_mins,
              :exam_date=>date,
              :assigned_to_employee=>0
            )
          end #employee do 
          GroupExam.find_or_create_by_group_id_and_exam_id_and_exam_date(
            :exam_id=>@exam.id,
            :group_id=>@group.id,
            :exam_date=>date,
            :total_employees_in_group=>@group.employees.size
          )  
      
          if params[:mail]
            @group.employees.each do |employee|
              exam_time =@exam.exam_date.strftime("%d-%m-%Y  - %I:%M %p")
              ExamMailer.deliver_support_notification(employee.email, @exam.title, exam_time, employee.login) 
            end #employee do      
          end
          redirect_to :action=>:index
          flash[:success]="exam has been successfully assigned to group"
        end # group employees if 
      end #group_id do 
    else
      redirect_to :action=>:index
      flash[:fail]="exam cannot be assigned assigned, as no groups selected"
    end #selected_list if
  end
  
  def save_assigned_exam_to_employee
    #add field assigned_to_employee and set value as one
    if params[:selected_employee_list]
      @exam=Exam.find(params[:id])
      @selected_list=params[:selected_employee_list]
      date=@exam.exam_date
      available_mins=@exam.available_mins 
      total_questions=@exam.questions.size
      @selected_list.each do |employee_id|
         EmployeeExam.find_or_create_by_employee_id_and_exam_id_and_exam_date(
          :employee_id=>employee_id,
          :exam_id=>@exam.id,
          :total_questions=> total_questions,
          :available_mins=>available_mins,
          :exam_date=>date,
          :assigned_to_employee=>1
         )
      end 
      if params[:mail]
          @selected_list.each do |employee_id|
            employee=Employee.find(employee_id)
            exam_time =@exam.exam_date.strftime("%d-%m-%Y  - %I:%M %p")
            ExamMailer.deliver_support_notification(employee.email, @exam.title, exam_time, employee.login) 
          end
        end
       redirect_to :action=>:index
       flash[:success]="exam has been successfully assigned"
    else
      redirect_to :action=>:index
      flash[:fail]="exam cannot be assigned assigned, as no employee selected"
    end  
  end
end