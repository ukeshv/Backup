class Administration::GroupsController < ApplicationController
  include AuthenticatedSystem
  layout 'admin'
  before_filter :check_login
  before_filter :admin_login_required
  
  # GET /groups
  # GET /groups.xml
  def index
    @groups = Group.paginate(:all,:per_page =>10,:page=>params[:page])	
    @length= @groups.length
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @groups }
    end
  end

  # GET /groups/1
  # GET /groups/1.xml
  def show
    @group = Group.find(params[:id])
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @group }
    end
  end

  # GET /groups/new
  # GET /groups/new.xml
  def new
    @employees=Employee.find(:all)
    @group = Group.new
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @group }
    end
  end

  # GET /groups/1/edit
  def edit
    @group = Group.find(params[:id])
    @employees=Employee.find(:all)
    @employees_list = @employees - @group.employees
  end

  # POST /groups
  # POST /groups.xml
  def create
    if params[:selected_list]
      employees = Employee.find(params[:selected_list])
    end
    @group = Group.new(params[:group])
    respond_to do |format|
      if @group.save
        if employees
          @group.employees=employees
        end
        flash[:notice] = 'Group was successfully created.'
        format.html { redirect_to('/administration/groups') }
        format.xml  { render :xml => @group, :status => :created, :location => @group }
      else
        @employees=Employee.find(:all)
        @selected_emp = employees
        @employees=@employees- employees
        format.html { render :action => "new" }
        format.xml  { render :xml => @group.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /groups/1
  # PUT /groups/1.xml
  def update
    @group = Group.find(params[:id])
    if params[:selected_list]
      employees = Employee.find(params[:selected_list])
      @group.employees=employees
    end
    if !params[:selected_list]
      @employee_group=EmployeeGroup.find_by_group_id(@group.id)
      @employee_group.destroy
    end
    respond_to do |format|
      if @group.update_attributes(params[:group])
        flash[:notice] = 'Group was successfully updated.'
        format.html { redirect_to('/administration/groups') }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @group.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /groups/1
  # DELETE /groups/1.xml
  def destroy
    @group = Group.find(params[:id])
    @group.destroy
    respond_to do |format|
      format.html { redirect_to(administration_groups_path) }
      format.xml  { head :ok }
    end
  end
  
  def assign_exam
     flash[:group_members_nil]  = " "
    @group = Group.find(params[:id])
    @exam=Exam.find(:all)
     if @group.employees.empty?
      flash[:group_members_nil] = 'No members in this group'
      redirect_to administration_groups_path
    end
  end
  
  def save_assigned_exams
    flash[:group_members_nil] = " "
    @group=Group.find(params[:id])
    if !@group.employees.empty?
      if params[:selected_exam_list]
        @exams=Exam.find(:all, :conditions =>['id IN (?)', params[:selected_exam_list]])
        selected_exam_list = params[:selected_exam_list]
        selected_exam_list.each do |exam_id|
          ex=Exam.find(exam_id)
          date=ex.exam_date
          total_questions=ex.questions.size
          if @group.employees
            @group.employees.each do |employee|
              EmployeeExam.find_or_create_by_employee_id_and_exam_id_and_exam_date(
              :employee_id=>employee.id,
              :exam_id=>exam_id,
              :total_questions=> total_questions,
              :exam_date=>date)
            end
          
            GroupExam.find_or_create_by_group_id_and_exam_id_and_exam_date(
              :exam_id=>exam_id,
              :group_id=>@group.id,
              :exam_date=>date,
              :total_employees_in_group=>@group.employees.size
              )
          
            #~ if params[:mail]
              #~ @exams.each do |exam|
                #~ @group.employees.each do |employee|
                  #~ exam_time =exam.exam_date.strftime("%d-%m-%Y  - %I:%M %p")
                  #~ ExamMailer.deliver_support_notification(employee.email, exam.title, exam_time, employee.login) 
                #~ end#employee do
              #~ end #exam do
            #~ end# mail if
          end #group employee if
        end #selected list do
      end #selected_list if
      respond_to do |format|
        flash[:assign_exam_notice] = 'Exam Assigned to Group'
        format.html { redirect_to administration_groups_path}
      end
    else
      flash[:group_members_nil] = 'No members in this group'
      redirect_to administration_groups_path
    end
    
  end
end