class Administration::QuestionListController < ApplicationController
  include AuthenticatedSystem
  layout 'admin'
  before_filter :check_login
  before_filter :admin_login_required

  protect_from_forgery :except=>[:create]
  # GET /questions
  # GET /questions.xml
  def index    
    @questions = Question.find_all_by_exam_id(params[:exam_id])

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @questions }
    end
  end

  # GET /questions/1
  # GET /questions/1.xml
  def show    
    @exam = Exam.find(params[:exam_id])
#    @question = Question.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @question }
    end
  end

  # GET /questions/new
  # GET /questions/new.xml
  def new    
     
    @exam = Exam.find(params[:exam_id])
    @question = Question.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @question }
    end
  end

  # GET /questions/1/edit
  def edit
    @question = Question.find(params[:id])
  end

  # POST /questions
  # POST /questions.xml
  def create
    if (params[:count]=="1")
      trueorfalse= params[:trueorfalse]
      trueorfalse.each do|values|
        @question=Question.new(values[1])
        @question.exam_id = params[:exam_id]
        @question.type_flag = 1
        @question.exam.update_attributes(:type_flag=>1)
        @question.save
      end
    elsif (params[:count]=="2")
      fillup= params[:fillup]
      fillup.each do|values|
        @question=Question.new(values[1])
        @question.exam_id = params[:exam_id]
        @question.type_flag = 2
        @question.exam.update_attributes(:type_flag=>2)
        @question.save
      end
    elsif (params[:count]=="3")
      choose= params[:choose]
      choose.each do|values|
        @question=Question.new(values[1])
        @question.exam_id = params[:exam_id]
        @question.type_flag = 3
        @question.exam.update_attributes(:type_flag=>3)
        @question.save
      end
    elsif (params[:count]=="4")
	multi= params[:multi]
	multi.each do|values|
		@question=Question.new(values[1])
		@question.exam_id = params[:exam_id]
		@question.type_flag = 4
		@question.exam.update_attributes(:type_flag=>4)
		@question.save
	end  
    elsif (params[:count]=="5")
      unless params[:question_image].empty?
        @question = Question.new()
        @question.exam_id = params[:exam_id]
        @question.type_flag = 5
        @question.answer_flag =params[:answer] 
        #@question.title =params[:title] 
        @question.imageuploads
        a=[]
        all_photos = params[:question_image]  
        all_photos.each do |each_photo|
          @imageupload = Imageupload.create(each_photo)
          @question.imageuploads << @imageupload
          a << @imageupload.public_filename
	      end  
=begin str=params[:title]
	str=str.split('*')
	if(str.size==1)
	str3=str[0];
	str2=""
	str1=""
	else
	str3=str[2]
	str2=str[1]
	str1=str[0]
	end
=end
	      @question.title ="<img src=\"#{a[0]}\" align=\"center\" />&nbsp;" + "<img src=\"#{a[1]}\" align=\"center\" />&nbsp;"+"<img src=\"#{a[2]}\" align=\"center\" />" + "&nbsp;"+params[:title]
       # @question.title ="<img src=\"#{a[0]}\" />&nbsp;" + "<img src=\"#{a[1]}\"  />&nbsp;" +"<img src=\"#{a[2]}\"  />" + "&nbsp;#{params[:title]}"
        @question.option1="<img src=\"#{a[3]}\" />"
        @question.option2="<img src=\"#{a[4]}\" />"
        @question.option3="<img src=\"#{a[5]}\" />"
        @question.option4="<img src=\"#{a[6]}\" />" 
	    end
      else
        flash[:error] = 'Select a question type'
    end
    #@question = Question.new(params[:question])
    
    respond_to do |format|
      if @question.save
        flash[:notice] = 'Question was successfully created.'        
        format.html { redirect_to(administration_exams_path) }
        format.xml  { render :xml => @question, :status => :created, :location => @question }
      else        
        format.html { render :action => "new" }
        format.xml  { render :xml => @question.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /questions/1
  # PUT /questions/1.xml
  def update
    @question = Question.find(params[:id])

    respond_to do |format|
      if @question.update_attributes(params[:question])
        flash[:notice] = 'Question was successfully updated.'
        format.html { redirect_to(administration_exam_question_list_path) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @question.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /questions/1
  # DELETE /questions/1.xml
  def destroy
    @question = Question.find(params[:id])
    @question.destroy

    respond_to do |format|
      format.html { redirect_to(administration_exam_question_list_path) }
      format.xml  { head :ok }
    end
  end
  
  def load_question
	@question_no=1
      if (params[:exam_type]=="1")
            render :update do |page|      
            page.replace_html "question_list",:partial=>'create_question_for_true_or_false'
            page.show('create_button');
            end	
      elsif (params[:exam_type]=="2")
            render :update do |page|      
            page.replace_html "question_list",:partial=>'create_question_for_fill_ups'
            page.show('create_button');
            end
      elsif (params[:exam_type]=="3")
            render :update do |page|      
            page.replace_html "question_list",:partial=>'create_question_for_choose_the_best'
            page.show('create_button');
            end
      elsif (params[:exam_type]=="4")
            render :update do |page|      
            page.replace_html "question_list",:partial=>'create_question_for_multi_select'
            page.show('create_button');
            end
      elsif (params[:exam_type]=="5")
            render :update do |page|      
            page.replace_html "question_list",:partial=>'create_question_for_image_type'
            page.show('create_button');
            end
      end
  end

  def add_questions
    
    @question_no = params[:id].to_i
    @question_no = @question_no+1
    @div_type = params[:type] 
    render(:update) { |page| 
    page.remove "remote_link"
    page.insert_html :bottom, @div_type , :partial => 'add_questions'	
    }
  end
end
