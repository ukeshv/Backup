class ApplicationController < ActionController::Base
  #include ExceptionNotifiable
  #include AuthenticatedSystem
  #include RoleRequirementSystem
  include HoptoadNotifier::Catcher
	require 'soap/wsdlDriver'
	require 'xmlsimple'
  helper :all # include all helpers, all the time
  protect_from_forgery :secret => 'b0a876313f3f9195e9bd01473bc5cd06'
  filter_parameter_logging :password, :password_confirmation
  rescue_from ActiveRecord::RecordNotFound, :with => :record_not_found
    before_filter :verify_url
  
  
	def verify_url
		@domain_api_key = "f2d07cd9cf5550cc528492e604b180be1804bc44"
		driver = SOAP::WSDLDriverFactory.new("http://opayu.railsfactory.com/services/wsdl").create_rpc_driver
		if params[:signature] || params[:access_key_id] || params[:expires_on] 
			begin
				@response = driver.AccessUrl(@domain_api_key, request.url, params[:access_key_id], params[:expires_on], params[:signature])
				@res = XmlSimple.xml_in(@response)['record'].first
				if @res["message"].to_s == "expired"	
						redirect_to @res["opayushorternurl"].to_s	
				elsif @res["message"].to_s != "success"		
						render :xml => @response
				end	
			rescue Exception => e
			  @response=[:url=> "nil", :message=>"failue", :error_message=>"#{e.message}", :error_code=>"106"].to_xml
				render :xml => @response
			end 
		else
			begin
				@res= driver.VerifyUrl(@domain_api_key, request.url) 
				@response = XmlSimple.xml_in(@res)['record'].first
				if (@response["message"].to_s == "success" && @response["opayushorternurl"])  
					redirect_to @response["opayushorternurl"].to_s	
				elsif @response["errorcode"].to_s == "101"
						render :xml => @res			
  			elsif @response["errorcode"].to_s == "107"
						render :xml => @res
				end
			rescue Exception => e
				@response=[:url=> "nil", :message=>"failue", :error_message=>"#{e.message}", :errorcode=>"106"].to_xml
				render :xml => @response
			end 
		end 	
	end 		 
  
  def check_login
    if !logged_in?
      redirect_to '/'
     end 
   end 
  
  def admin_login_required
    if current_user.class.name != 'Admin'
      redirect_to '/'
    end 
  end 
  
  def check_session
    if logged_in?
      if current_user.class.name != 'Admin'
        redirect_to dashboard_elearning_employee_path(current_user.id)
      else
        redirect_to dashboard_administration_admin_path(current_user.id)
      end
    end
  end
  
  protected
  
  # Automatically respond with 404 for ActiveRecord::RecordNotFound
  def record_not_found
    render :file => File.join(RAILS_ROOT, 'public', '404.html'), :status => 404
  end
end

