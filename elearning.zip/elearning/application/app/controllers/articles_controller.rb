class ArticlesController < ApplicationController
	
	include AuthenticatedSystem
  layout 'knowledge'
  before_filter :check_login
	protect_from_forgery :except=>[:add_rating]
	
 	def index
	@articles=Article.find(:all)		
	end
	
	def show
  @article=Article.find(params[:id])

	end
	
	def new
	@other_articles=Article.find(:all)
	@category=Category.find(:all)
	end
	
	def create
	@article=Article..new(params[:article])
	end
	
	def edit
	@article=Article.find(params[:id])
	end
	
	def update
	end
	
	def destroy

		@article=Article.find(params[:id])
	end
	
	def new_comment
		@article=Article.find(params[:id])
		render :layout=>false
	end
	
	def add_comment
		@article=Article.find(params[:id])
		@comment=Comment.new(:fullname=>params[:comments][:fullname], :email=>params[:comments][:email], :message=>params[:comments][:message])
		render :update do |page|
		if @comment.valid?
			@article.comments<<@comment
			flash[:notice]="Your comment successfully added.<br /> Your comment will come to account after getting admin approval"
			page.redirect_to :controller=>'articles', :action=>'show', :id=>@article.id
		else
			@error="Please fix the issues <br /><br />"
			@error+=@comment.errors[:fullname]+"<br />" if (@comment.errors[:fullname] && !@comment.errors[:fullname].empty?)
			@error+=@comment.errors[:email]+"<br />" if (@comment.errors[:email] && !@comment.errors[:email].empty?)
			page.replace_html "comment_form_message",  @error
		end
		end
	end
	
	def add_rating
		@rating_value=params[:id]
		article_id=params[:article_id]
		@article=Article.find(article_id)
		remote_ip=request.remote_ip
		@article.rate @rating_value,remote_ip
		#tooltip_text =  @article.user_id==@user.id ? "Can't rate your playlist" : @article.rated_by?(remote_ip) ? "Already Rated" : "Rate"
		render :update do |page|
		page.replace_html "rating_"+article_id+"_false", rating_div(@article,@article.rating_avg,true)
		page.replace_html "rating_"+article_id+"_message", "<b>Thanks for rating</b>"
		end	
	end

	def search
		if !params[:q].nil? and !params[:q].empty?
		search_text = "'%"+params[:q]+"%'"
		sql=" SELECT * FROM `articles` WHERE `question` LIKE #{search_text} ANd 'flag'=0 LIMIT 0 , 30 "
		@articles=Article.find_by_sql(sql)
		flash.now[:notice]="Search result for '#{params[:q]}'"
		end
	end
end
