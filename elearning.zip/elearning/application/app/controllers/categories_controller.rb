class CategoriesController < ApplicationController
	
	include AuthenticatedSystem
  layout 'knowledge'
  before_filter :check_login
	
	def index
		@categories=Category.find(:all, :conditions=>['flag = ?',0])
		@employee=Employee.find(current_user.id)
	end
	
  def list
	@employee=Employee.find(current_user.id)
	@categories=Category.find(:all)          
	end
  
	def show
		  @employee=Employee.find(current_user.id)
		@category=Category.find(params[:id],  :conditions=>['flag = ?',0])
		@articles=@category.articles
	end	
	
end