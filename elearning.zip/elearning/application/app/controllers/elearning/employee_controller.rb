class Elearning::EmployeeController < ApplicationController
  include AuthenticatedSystem
  layout 'employee_index'
  before_filter :check_login
  def dashboard
    @employee=Employee.find(current_user.id)
    @my_exams=@employee.employee_exams.find(:all,:conditions=>['is_completed = ?',0])
  end
  
  def edit
    @employee=Employee.find(current_user.id)
  end

  def exam_list
    @result=[]
    @exam=[]
    @employee=Employee.find(current_user.id)
    @completed_exams=@employee.employee_exams.find(:all,:conditions=>['is_completed = ?',1], :order=>'updated_at DESC')
    @completed_exams.each do |ex|
      @exam<<ex.exam_date.strftime("%d-%m-%Y, %I:%M %p") rescue nil
      @exam<<ex.exam
      @exam<<ex.total_questions
      @exam<<ex.total_correct_answer
			@result<<@exam
      @exam=[]
    end
  end	  
  
  def display_answers
    @employee=Employee.find(current_user.id)
    @exam=@employee.exams.find(params[:id])
		date=Time.parse(params[:date])
    @answers = Answer.find(:all,:conditions=>["employee_id =? and exam_id =? and exam_date = ?",@employee.id,@exam.id,date])
  end
  
  def update
	@user=User.find(params[:id])
	@user = User.authenticate(@user.login, params[:old_password])
	@employee=Employee.find(params[:id])
	if @user
		if ((!params[:employee][:password].empty?) and (!params[:employee][:password_confirmation].empty?))
		       if params[:employee][:password] == params[:employee][:password_confirmation]
				if @user.update_attributes(:password=>params[:employee][:password], :password_confirmation=>params[:employee][:password_confirmation])
				if params[:employee][:phone]	
				   @user.update_attributes(:phone=>params[:employee][:phone])
				end   
				flash[:notice] = "<font color='green'>Profile has been successfully Edited</font>"
				redirect_back_or_default('/')
			       end
		       else
				flash[:notice] = "<font color='red'>password and confirm password entries do not match</font>"
				render(:action =>'edit')
		       end
	       else
			flash[:notice] = "<font color='red'>Password and/or phone number field(s) can't be blank</font>"
			render(:action=>'edit')
		end
	else
		if params[:old_password].empty?
			flash[:notice] = "<font color='red'>Old password field can't be blank </font>"
			render(:action=>'edit')	
		else
			flash[:notice] = "<font color='red'>Your old password is wrong</font>"
			render(:action=>'edit')	
		end	
	end		
end

end