class Elearning::ExamsController < ApplicationController
   include AuthenticatedSystem
  layout 'employee_index'
  before_filter :check_login
  def success
    #~ @employee = Employee.find(current_user.id)
=begin
    @employee=Employee.find(session[:current_user].id)
    @my_exams=@employee.employee_exams.find(:all,:conditions=>['is_completed = ?',1])
=end
    cookies.delete :auth_token
    reset_session
  end
  
  def timeout  
    #~ @employee = Employee.find(current_user.id)
    #~ @correct_answers = Answer.find(:all,:conditions=>["employee_id =? and exam_id =? and is_correct_answer = ?",@employee.id,params[:id], true])
    #~ EmployeeExam.find_by_employee_id_and_exam_id_and_exam_date(@employee.id,params[:id]).update_attributes(:is_completed=>true,:total_correct_answer=>@correct_answers.size)	
    cookies.delete :auth_token
    reset_session
  end
end
