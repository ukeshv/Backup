class Elearning::QuestionListsController < ApplicationController
  include AuthenticatedSystem
  layout 'employee_index'
  before_filter :check_login
  protect_from_forgery :except=>[:create]
  def show
    session[:success_message] = ""
    @employee = Employee.find(current_user.id)
    @exam= Exam.find(params[:exam_id])
    @pending_exam = EmployeeExam.find(:first, :conditions=>["employee_id = ? and exam_id = ? and is_completed = ?",current_user.id, @exam.id, 0])
    @duration= @exam.duration
    @total_questions=@exam.questions.size
    @question=@exam.questions#.paginate(:page=>params[:page], :per_page => 2)
    @result = EmployeeExam.find(:first, :conditions=>["employee_id = ? and exam_id = ? and exam_date = ?", @employee.id, @exam.id,@exam.exam_date])
    #@result.is_completed=true
    #@result.save
    #@employee.active_status = 0
    #@employee.save
  end
      
  def create
    params[:answer].each do |x|
      @employee_id=x[1][:employee_id]
      @exam_id=x[1][:exam_id]
      #~ @answer = Answer.new(x[1])
      @exam_date = Exam.find(@exam_id).exam_date
      #~ if x[1][:answer_flag]
        #~ @answer.question.answer_flag == @answer.answer_flag ? @answer.is_correct_answer = true : nil 
      #~ elsif x[1][:answer_text]
        #~ @answer.question.answer_text == @answer.answer_text ? @answer.is_correct_answer = true : nil 
      #~ end
      @answer = Answer.find_or_create_by_employee_id_and_exam_id_and_question_id(
      :employee_id=>@employee_id, 
      :exam_id=>@exam_id,
      :question_id=>x[1][:question_id],
      :exam_date=>@exam_date,
      :answer_flag=>x[1][:answer_flag],
      :answer_text=>x[1][:answer_text]
      )
    @result = EmployeeExam.find(:first, :conditions=>["employee_id = ? and exam_id = ? and exam_date = ?", @employee_id,
@exam_id,@exam_date])
    @result.is_completed=true
    @result.save
      
      @answer.exam_date = @exam_date
      if x[1][:answer_flag]
        @answer.question.answer_flag == @answer.answer_flag ? @answer.is_correct_answer = true : nil 
      elsif x[1][:answer_text]
        @answer.question.answer_text == @answer.answer_text ? @answer.is_correct_answer = true : nil 
      end
      @answer.save!
    end
    #@last_exam_date=Answer.find(:first, :conditions=>["employee_id =? and exam_id =? ",@employee_id,@exam_id], :order =>"created_at DESC")
    @correct_answers = Answer.find(:all,:conditions=>["employee_id =? and exam_id =? and is_correct_answer = ? and exam_date = ?", @employee_id, @exam_id, true, @exam_date])
    @result = EmployeeExam.find(:first, :conditions=>["employee_id = ? and exam_id = ? and exam_date = ?", @employee_id, @exam_id, @exam_date])
    @result.update_attributes(:is_completed=>true, :total_correct_answer=>@correct_answers.size) if @result
    redirect_to success_elearning_exam_path(@exam_id)
=begin
  #get user answer and save it to DB.
  #and load next questions.\
  #if there is no question/exam over means, redirect the user to thanks page for successful completion of exams
  @total_questions=params[:total_questions]
  if params[:answer][:answer_flag].nil?
    render :update do |page|
      page.alert "Please select answer!"
      page.hide "ajax_spinner"
    end
  else
    @answer = Answer.new(params[:answer])
    @exam= @answer.exam
    @employee = @answer.employee
    @answer.question.answer_flag == @answer.answer_flag ? @answer.is_correct_answer = true : nil 
    @answer.save!
    render :update do |page|
      @answered_question_ids = Answer.find(:all, :select=>"question_id", :conditions=>["employee_id=? and exam_id=? and answer_flag is NOT NULL",@employee.id,@exam.id]).collect{|x| x.question_id}
      @question=@exam.questions.find(:first, :conditions=>['id NOT IN (?)', @answered_question_ids])
      if @question
        @question_no=params[:question_no].to_i+1
        page.replace_html :question_panel, :partial=> "new_question"
      else
        @correct_answers = Answer.find(:all,:conditions=>["employee_id =? and exam_id =? and is_correct_answer = ?",@employee.id,@exam.id, true])
        EmployeeExam.find_by_employee_id_and_exam_id(@employee.id,@exam.id).update_attributes(:is_completed=>true,:total_correct_answer=>@correct_answers.size)	
        page.redirect_to success_elearning_exam_path(@exam.id)
      end        
    end
  end
=end
  end
end
