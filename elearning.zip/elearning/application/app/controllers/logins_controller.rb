class LoginsController < ApplicationController
  layout 'login'
  include AuthenticatedSystem
  before_filter :check_session, :except => 'destroy'
  protect_from_forgery :except=>['create']
  def new
  end

  def create
    #logout_keeping_session!
    user = User.authenticate(params[:login], params[:password])
    if user
      self.current_user = user
      session[:current_user]=user
      if self.current_user.is_admin?
        redirect_to admin_dashboard_path
        flash[:notice] = "Logged in successfully"
      elsif self.current_user.is_employee?
        redirect_to dashboard_elearning_employee_path(session[:current_user].id)
        flash[:notice] = "Logged in successfully"
      else
        redirect_to "/" 
      end
    else
      note_failed_signin
      @login       = params[:login]
      @remember_me = params[:remember_me]
      render :action => 'new'
    end
  end
  
  def show
    redirect_to "/"
  end 

  def destroy
    self.current_user if logged_in? #.forget_me if logged_in?
    cookies.delete :auth_token
    reset_session
    flash[:notice] = "You have been logged out."
    redirect_back_or_default('/')
  end
  
  def forgot_password
    return unless request.post?
		unless params[:email].blank?
			if @user = User.find_by_email(params[:email])
				@user.forgot_password
				@user.save
        EmployeeMailer.deliver_forgot_password(@user)
				redirect_to :controller=>'logins', :action=>'new'
				flash[:notice] = "Password reset link has been sent to your email address" 
			else
        flash.now[:error_forgot] = "Could not find a user with that email address" 
			end
		else
			flash.now[:error_forgot]="Required field cannot be left blank"
		end
  end
  
  def reset_password
		@user = User.find_by_password_reset_code(params[:id])
		session[:reset_code]=params[:id]
		unless @user.nil?
		return unless request.post?	
			unless params[:password].blank? || params[:password_confirmation].blank?
				if params[:password] == params[:password_confirmation]
					if @user.update_attributes(:password=>params[:password], :password_confirmation=>params[:password_confirmation], :password_reset_code=> "NULL")
						flash[:notice] = "Password has been changed successfully"
						EmployeeMailer.deliver_reset_password(@user)
						redirect_to :controller=>'logins', :action=>'new'
          end
        else
					flash.now[:error] = "Mismatch in Password and Confirmation Password."
				end 
					
      else
			  flash.now[:error]="Required field cannot be left blank"	
			end	
		  else
			  redirect_to :action=>'login'
			  flash[:error]="Unable to use the Password Reset link more than ones."	
		  end
	  end

  

protected
  def note_failed_signin
    flash[:error] = " Invalid Login/Password "
    logger.warn "Failed login for '#{params[:login]}' from #{request.remote_ip} at #{Time.now.utc}"
  end
end
