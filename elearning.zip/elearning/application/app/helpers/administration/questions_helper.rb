module Administration::QuestionsHelper

	def get_all_image_url(question_object)
		arr = question_object.title.split('&nbsp;')
		arr.pop
		arr << question_object.option1
		arr << question_object.option2
		arr << question_object.option3
		arr << question_object.option4
		arr
	end
	
	def image_text(question_object)
			arr = question_object.title.split('&nbsp;')
			text = arr.pop
			text
	end

end
