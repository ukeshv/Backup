module ApplicationHelper
  
  # Sets the page title and outputs title if container is passed in.
  # eg. <%= title('Hello World', :h2) %> will return the following:
  # <h2>Hello World</h2> as well as setting the page title.
  def title(str, container = nil)
    @page_title = str
    content_tag(container, str) if container
  end
  
  # Outputs the corresponding flash message if any are set
  def flash_messages
    messages = []
    %w(notice warning error).each do |msg|
      messages << content_tag(:div, html_escape(flash[msg.to_sym]), :id => "flash-#{msg}") unless flash[msg.to_sym].blank?
    end
    messages
  end
  
   def rating_div(ins,rating,rated_condition,rating_container=nil) 
    begin    
      model = ins.class.to_s.downcase
      avg =  ins.rating_avg
      dom = "rating_#{ins.id}_#{rated_condition}"
      string =  %{
    <span id="#{dom}" class="rating_container"></span>
    <script>var #{dom} = new Control.Rating('#{dom}',{value: #{rating},rated: #{rated_condition},rating_container : '#{rating_container.to_s}',
        afterChange: function(value){
            new Ajax.Request('/articles/add_rating/'+value+'?article_id=#{ins.id}', {asynchronous:true, evalScripts:true}); return false;
            }
    });
   </script> 
      }      #updateUrl: 'http://my_ajax_handler',
      return string
    rescue nil
      ''
    end      
      
      
    end
    
  def category_article_count(articles)
  count = 0
  articles.each{|x|
    if x.flag == 0
    count = count + 1
    end
  }
  return count
  end
  
  def find_category
   categories=Category.find(:all, :conditions=>['flag = ?',0]) 
 end
 
 def time_format(time)
    time.strftime('%B %d, %Y %I:%M %p')
  end 
end
