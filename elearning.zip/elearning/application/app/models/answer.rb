class Answer < ActiveRecord::Base
  belongs_to :employee
  belongs_to :exam
  belongs_to :question
end
