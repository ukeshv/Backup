class Article < ActiveRecord::Base
	 # assumes page_versions table
    acts_as_versioned :if_changed => [:question, :answer, :category_id]  #Versioning done oly when question,answer and category_id fields are modified/updated
    acts_as_taggable
    has_many :ratings
    has_many :comments
    has_many :approved_comments, :conditions=>"admin_approval=1", :order=>"created_at", :class_name=>"Comment"
    belongs_to :category
    has_many :article_relationships,
    :foreign_key =>       'article_id',
    :class_name =>        'ArticleRelationship'
    has_many :bearticle_relationships,
    :foreign_key =>       'related_id',
    :class_name =>        'ArticleRelationship'
    has_many :related_articles,
    :through =>     :article_relationships,
    :source =>      :bearticle_related
    has_many :berelated_articles,
    :through =>     :bearticle_relationships,
    :source =>      :article_related
    
    
    validates_presence_of     :question, :message =>"question can't be blank" 
    validates_presence_of     :answer, :message =>"answer can't be blank" 
    
    def rated_count
      ratings.count
    end
    
    def rated_total
      ratings.collect{|x| x.rate_value}.sum
    end
    
    def rating_avg
    avg = rated_total/rated_count  if rated_count  > 0
    avg = 0 if avg.nil?
    ((avg)*10).round.to_f/10
    end
    
    def rate(rating_value,ipaddress)
      ratings<<Rating.create!(:rate_value=>rating_value,:ipaddress=>ipaddress)
    end
    
    def rated_by? ipaddress
      ratings.count(:conditions => ['ipaddress = ?', ipaddress]) > 0
    end
    
end
