class ArticleRelationship < ActiveRecord::Base
	belongs_to :article_related,   :foreign_key => "article_id",   :class_name => "Article"
  belongs_to :bearticle_related, :foreign_key => "related_id", :class_name => "Article"
end
