class Category < ActiveRecord::Base
  has_many :articles, :dependent => :destroy
  
  validates_presence_of  :name,  :message =>"Category name can't be blank" 
  validates_uniqueness_of  :name, :case_sensitive => true, :message =>"Category name already exist" 

end