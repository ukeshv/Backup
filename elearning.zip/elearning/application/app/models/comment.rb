class Comment < ActiveRecord::Base  
  belongs_to :article
  validates_format_of       :email, :with => /^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$/  ,:message=>"Invalid E-mail"
  validates_length_of   :fullname, :within => 5..50, :too_short=>"Fullname should be in the range of 5 to 50",  :too_long=>"Fullname should be in the range of 5 to 50"

end
