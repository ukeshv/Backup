class Employee < User
  has_many :employee_exams
  has_many :exams, :through=>:employee_exams
  has_many :answers
  has_many :completed_exams ,:through => :employee_exams, :source => :exam,:conditions=>["employee_exams.is_completed=true"]
  has_many :uncompleted_exams ,:through => :employee_exams, :source => :exam,:conditions=>["employee_exams.is_completed=false"]
  has_many :employee_groups, :dependent => :destroy
  has_many :groups, :through=>:employee_groups
  
  def self.answers(user)
    @arr=[]
    @questions=[]
    @employee=Employee.find(user.id)
    @employee.exams.each do |exam|
      employee_answers=@employee.answers.find_all_by_exam_id(exam.id)
      employee_answers.each do |answer|
        if answer.is_correct_answer==false
           @question_answered=answer
           @arr<<@question_answered
           @wrong_answer_question=Question.find(:all, :conditions=>['id=? and exam_id=?',answer.question_id,exam.id])
           @arr<<@wrong_answer_question
           @questions<<@arr
           @arr=[]
        end
      end  
    end
    return @questions
  end
end
