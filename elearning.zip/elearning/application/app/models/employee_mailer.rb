class EmployeeMailer < ActionMailer::Base
  def support_notification(login, password, email)
    setup_email(email)
    @body[:message]  = "Your Elearning Account has been activated"
    @body[:login] = "#{login}"
    @body[:password] = "#{password}"
  end
  
  def activation(employee)
    setup_email(employee)
    @subject    += 'Your account has been activated!'
    @body[:url]  = "http://YOURSITE/"
  end
  
  def forgot_password(user)
    @recipients  = "#{user.email}"
    @from        = "elearning@railsfactory.com"
    @sent_on     = Time.now
    @subject    = 'Request to Reset your password'
    @body[:user]  = user
		@body[:url]  = "#{$site_url}logins/reset_password/#{user.password_reset_code}" 
	end

  def reset_password(user)
    @recipients  = "#{user.email}"
     @from        = "elearning@railsfactory.com"
    @sent_on     = Time.now
    @subject    = 'Your password has been reset'
		@body[:user]  = user
  end
  
  
  protected
    def setup_email(email)
      @recipients  = "#{email}"
      @from        = "user_support@elearning.com"
      @subject     = "Elearning Account Created"
      @sent_on     = Time.now
    end
end
