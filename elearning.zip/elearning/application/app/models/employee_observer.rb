class EmployeeObserver < ActiveRecord::Observer
  def after_create(employee)
    EmployeeMailer.deliver_signup_notification(employee)
  end

  def after_save(employee)
  
    EmployeeMailer.deliver_activation(employee) if employee.recently_activated?
  
  end
end
