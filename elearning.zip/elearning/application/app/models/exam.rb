class Exam < ActiveRecord::Base
  has_many :employee_exams 
  has_many :employees, :through=>:employee_exams
  has_many :questions
  has_many :answers
  has_many :group_exams
  has_many :groups, :through=>:group_exams
  
  validates_presence_of     :title, :message =>"Exam Name field can't be blank" 
  validates_presence_of     :exam_date, :message =>"Exam Date field can't be blank" 
  validates_presence_of     :duration, :message =>"Duration field can't be blank" 
  
  validates_numericality_of :duration, :only_integer => true, :message =>"Duration is not a number" 
end