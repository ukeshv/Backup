class ExamMailer < ActionMailer::Base
  def support_notification(email, exam_title, exam_time, login)
    setup_email(email)
    @body[:message]  = "Your are assigned with the following Exam"
    @body[:exam_name] = "#{exam_title}"
    @body[:exam_time] = "#{exam_time}"
    @body[:employee_login]="#{login}"
  end
  
  protected
    def setup_email(email)
      @recipients  = "#{email}"
      @from        = "Exams@elearning.com"
      @subject     = "Exam has been assigned"
      @sent_on     = Time.now
    end
end
