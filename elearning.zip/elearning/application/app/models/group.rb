class Group < ActiveRecord::Base
  has_many :employee_groups, :dependent => :destroy
  has_many :employees, :through=>:employee_groups
  has_many :group_exams
  has_many :exams, :through=>:group_exams
  validates_presence_of      :name,:message=>"Group Name can't be blank"
end
