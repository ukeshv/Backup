class Imageupload < ActiveRecord::Base
	has_attachment  :storage => :file_system,:size => 0.megabyte..4.megabytes, :content_type => ['image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png'] , :path_prefix => 'public/files', :resize_to => [75,75]
	belongs_to :question
end
