class Rating < ActiveRecord::Base
  belongs_to :article
end
