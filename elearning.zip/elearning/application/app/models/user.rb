require 'digest/sha1'

class User < ActiveRecord::Base
  include Authentication
  include Authentication::ByPassword
  include Authentication::ByCookieToken
  before_create :change_active_status 
  validates_presence_of      :email,:message=>"can't be blank"
  validates_presence_of      :firstname,:message=>"can't be blank"
  validates_presence_of     :login
  validates_length_of       :login,    :within => 3..40
  validates_uniqueness_of   :login,    :case_sensitive => false
  #~ validates_format_of       :login,    :with => RE_LOGIN_OK, :message => MSG_LOGIN_BAD
  validates_length_of       :email,    :within => 6..100 #r@a.wk
  validates_uniqueness_of   :email,    :case_sensitive => false
  validates_format_of       :email,    :with => RE_EMAIL_OK, :message => MSG_EMAIL_BAD

  # HACK HACK HACK -- how to do attr_accessible from here?
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  #attr_accessible :login, :email, :password, :password_confirmation

  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  #
  # uff.  this is really an authorization, not authentication routine.  
  # We really need a Dispatch Chain here or something.
  # This will also let us return a human error message.
  #
  def self.authenticate(login, password)
    u = find :first, :conditions => ['email = ? and active_status =?', login, 1]
    u && u.authenticated?(password) ? u : nil
  end

  def change_active_status
    self.active_status =1 
  end 
  
  def is_admin?
    if self.type =="Admin"
      return true
    end
  end
  
   def is_employee?
    if self.type =="Employee"
      return true
    end
  end
  
  def forgot_password
	@forgotten_password = true
	self.make_password_reset_code
end

def reset_password
	# First update the password_reset_code before setting the 
	# reset_password flag to avoid duplicate email notifications.
	update_attributes(:password_reset_code => nil)
	@reset_password = true
	end

	def recently_reset_password?
	@reset_password
	end

	def recently_forgot_password?
	@forgotten_password
	end
  
  protected
   #Password Reset for Forgot password
	def make_password_reset_code
	self.password_reset_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
	end 
end
