HoptoadNotifier.configure do |config|
  config.api_key = '29ee719e22ca98da32b2486a7d06bb30'
end

# URL : http://elearning.hoptoadapp.com/login
# Login : elearning@railsfactory.org
#Password : elearning123