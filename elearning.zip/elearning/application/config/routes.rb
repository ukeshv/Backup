ActionController::Routing::Routes.draw do |map|

  map.resource :login
  
  map.namespace(:administration) do |administration|
    administration.resources :admins,  :member =>{:dashboard=>:get, :result=>:get, :employee_result=>:get, :dashboard_group_result=>:get, :dashboard_emp_result=>:get, :print_result=>:get}
    administration.resources :employees, :collection=>{:print_employees=>:get}
    administration.resources :groups, :member =>{:assign_exam=>:get} 
    administration.resources :exams, :member=>{:assign_exam=>:get} do |exam|
      exam.resource :question_list,:controller=>'question_list', :member =>{:load_question=>:get}
    end
  end
  
  map.namespace(:elearning) do |elearning|  
    elearning.resources :employee, :member =>{:dashboard=>:get, :exam_list=>:get }
    elearning.resources :exams, :member =>{:success=>:get, :timeout=>:get} do |exam|
      exam.resource :question_list
    end
  end      
   
  # Restful Authentication Resources

  # Home Page
  map.admin_dashboard '/administration/admin/dashboard', :controller => 'administration/admins', :action => 'dashboard'
  map.save_assigned_exams '/administration/groups/:id/save_assigned_exams', :controller => 'administration/groups', :action => 'save_assigned_exams'
  map.delete_question '/administration/exams/:id/question/:id', :controller => 'administration/exams', :action => 'delete_question'
  map.assign_exam_to '/administration/exams/:id/assign_exam_to', :controller => 'administration/exams', :action => 'assign_exam_to'
  map.save_assigned_exam_to_group '/administration/exams/:id/save_assigned_exam_to_group', :controller => 'administration/exams', :action => 'save_assigned_exam_to_group'
  map.save_assigned_exam_to_employee '/administration/exams/:id/save_assigned_exam_to_employee', :controller => 'administration/exams', :action => 'save_assigned_exam_to_employee'
  map.display_answers '/elearning/employee/:id/exam/:id/answers', :controller => 'elearning/employee', :action => 'display_answers'
  map.login '/login', :controller=>'logins', :action=>'new' , :requirements => { :method => :get }
  map.logout '/logout',:controller=>'logins', :action=>'destroy'
  map.forgot '/forgot', :controller =>'logins', :action => 'forgot_password'
  map.reset 'reset/:reset_code', :controller =>'logins', :action =>'reset_password'
  map.employee_result '/administration/admins/:exam_id/employee/:employee_id', :controller => 'administration/admins', :action => 'employee_result'
  
  map.root :controller => 'logins', :action => 'new'
  # Install the default routes as the lowest priority.
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
end
