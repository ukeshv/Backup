class CreateExams < ActiveRecord::Migration
  def self.up
    create_table :exams do |t|
      t.string :title
      t.text :instruction
      t.text :comprehension
      t.integer :duration, :default=>0
			t.datetime :exam_date       
      t.integer :type_flag, :default=>1

      t.timestamps
    end
  end

  def self.down
    drop_table :exams
  end
end
