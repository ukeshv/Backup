class CreateQuestions < ActiveRecord::Migration
  def self.up
    create_table :questions do |t|
      t.integer :exam_id
      t.text :title
      t.string :option1
      t.string :option2
      t.string :option3
      t.string :option4      
      t.string :answer_text
      t.integer :answer_flag, :default=>1
      t.integer :type_flag, :default=>1
      t.timestamps
    end
  end

  def self.down
    drop_table :questions
  end
end
