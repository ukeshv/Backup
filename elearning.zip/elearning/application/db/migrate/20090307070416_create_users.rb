class CreateUsers < ActiveRecord::Migration
  def self.up
    create_table :users do |t|
      t.string :login
      t.string :type
      t.string :crypted_password, :limit => 40
      t.string :salt, :limit => 40
      t.string :email
      t.integer :phone
      t.string :firstname
      t.string :lastname
      t.integer :active_status
      t.string :remember_token
      t.datetime :remember_token_expires_at
      t.datetime :last_loggedin_at
      t.string :last_loggedin_ip
      t.timestamps
    end
    
    Admin.create!(:login=>'admin', :password=>'elearning', :password_confirmation=>'elearning', :email=>'admin@elearning.com', :firstname=>'admin', :lastname=>'railsfactory', :active_status=>1)
    Employee.create!(:login=>'employee', :password=>'elearning', :password_confirmation=>'elearning', :email=>'employee@elearning.com', :firstname=>'employee', :lastname=>'railsfactory', :active_status=>1)
    
  end

  def self.down
    drop_table :users
  end
end
