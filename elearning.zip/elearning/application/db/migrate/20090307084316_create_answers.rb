class CreateAnswers < ActiveRecord::Migration
  def self.up
    create_table :answers do |t|
      t.integer :employee_id
      t.integer :exam_id
      t.integer :question_id
      t.string :answer_text
      t.integer :answer_flag
      t.integer :type_flag, :default=>1
      t.boolean :is_correct_answer, :default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :answers
  end
end
