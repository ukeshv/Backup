class CreateEmployeeExams < ActiveRecord::Migration
  def self.up
    create_table :employee_exams do |t|
      t.integer :employee_id
      t.integer :exam_id
      t.integer :total_correct_answer, :default=>0
      t.integer :total_questions, :default=>0
      t.integer :is_completed, :default=>0
      t.text :answers_dump, :text
      t.integer :percentage
      t.text :result
      t.timestamps
    end
  end

  def self.down
    drop_table :employee_exams
  end
end
