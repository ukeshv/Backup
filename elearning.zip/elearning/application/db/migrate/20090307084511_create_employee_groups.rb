class CreateEmployeeGroups < ActiveRecord::Migration
  def self.up
    create_table :employee_groups do |t|
      t.integer :group_id
      t.integer :employee_id      
      t.boolean :active_status, :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :employee_groups
  end
end
