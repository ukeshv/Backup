class CreateGroupExams < ActiveRecord::Migration
  def self.up
    create_table :group_exams do |t|
      t.integer :exam_id
      t.integer :group_id
      t.datetime :exam_date
      t.integer :total_employees_in_group, :default=>0
      t.integer :total_employees_attended_test, :default=>0
      t.timestamps
    end
  end

  def self.down
    drop_table :group_exams
  end
end
