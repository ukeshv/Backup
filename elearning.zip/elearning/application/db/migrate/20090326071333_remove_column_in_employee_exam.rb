class RemoveColumnInEmployeeExam < ActiveRecord::Migration
  def self.up
    remove_column :employee_exams, :text
  end

  def self.down
    add_column :employee_exams, :text, :text
  end
end
