class AddColumnExamDateInEmployeeExams < ActiveRecord::Migration
  def self.up
    add_column :employee_exams, :exam_date, :datetime
  end

  def self.down
    remove_column :employee_exams, :exam_date
  end
end
