class AddColumnExamDateInAnswers < ActiveRecord::Migration
  def self.up
    add_column :answers, :exam_date, :datetime
  end

  def self.down
    remove_column :answers, :exam_date
  end
end
