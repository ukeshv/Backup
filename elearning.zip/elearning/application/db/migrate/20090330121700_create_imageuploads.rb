class CreateImageuploads < ActiveRecord::Migration
  def self.up
    create_table :imageuploads do |t|
			t.integer "id"
			t.string   "content_type"
			t.string   "filename"
			t.integer  "size"
			t.integer  "question_id"
			t.string   "thumbnail"
			t.integer  "width"
			t.integer  "height"
			t.integer  "db_file_id"
			t.integer  "attachable_id"
			t.string   "attachable_type"
      t.timestamps
    end
  end

  def self.down
    drop_table :imageuploads
  end
end
