class AddAvailableHoursInExam < ActiveRecord::Migration
  def self.up
     add_column :exams, :avaliable_hours, :integer
  end

  def self.down
    remove_column :exams, :avaliable_hours
  end
end