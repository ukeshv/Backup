class AddAvaliableHoursToEmployeeExams < ActiveRecord::Migration
  def self.up
  add_column :employee_exams, :avaliable_hours, :int
  end

  def self.down
  remove_column :employee_exams, :avaliable_hours 
  end
end
