class CreateArticles < ActiveRecord::Migration
  def self.up
    create_table :articles do |t|
      t.integer :category_id
      t.string :question
      t.text :answer
      t.integer :flag , :default => 1
      t.timestamps
    end
  end

  def self.down
    drop_table :articles
  end
end
