class CreateArticleRelationships < ActiveRecord::Migration
  def self.up
    create_table :article_relationships do |t|
      t.integer :article_id
      t.integer :related_id
      t.timestamps
      t.timestamps
    end
  end

  def self.down
    drop_table :article_relationships
  end
end
