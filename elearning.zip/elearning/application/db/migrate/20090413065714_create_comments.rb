class CreateComments < ActiveRecord::Migration
  def self.up
    create_table :comments do |t|
      t.integer :article_id
      t.string :fullname, :email, :limit=>100      
      t.text :message
      t.integer :admin_approval, :default=>0
      t.timestamps
    end
  end

  def self.down
    drop_table :comments
  end
end
