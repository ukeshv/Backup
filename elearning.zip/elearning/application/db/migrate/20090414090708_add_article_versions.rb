class AddArticleVersions < ActiveRecord::Migration
require_dependency 'article'
  def self.up
     # create_versioned_table takes the same options hash
    # that create_table does
    Article.create_versioned_table
  end

  def self.down
     Article.drop_versioned_table
  end
end
