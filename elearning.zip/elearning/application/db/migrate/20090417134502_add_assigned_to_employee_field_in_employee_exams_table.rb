class AddAssignedToEmployeeFieldInEmployeeExamsTable < ActiveRecord::Migration
  def self.up
     add_column :employee_exams, :assigned_to_employee, :boolean , :default=>0
  end

  def self.down
     remove_column :employee_exams , :assigned_to_employee
  end
end
