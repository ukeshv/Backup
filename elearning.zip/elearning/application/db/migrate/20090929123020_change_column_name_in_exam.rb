class ChangeColumnNameInExam < ActiveRecord::Migration
  def self.up
    rename_column :exams, :avaliable_hours , :available_mins
    rename_column :employee_exams, :avaliable_hours , :available_mins
  end

  def self.down
    rename_column :exams, :available_mins, :avaliable_hours 
    rename_column :employee_exams, :available_mins, :avaliable_hours 
  end
end
