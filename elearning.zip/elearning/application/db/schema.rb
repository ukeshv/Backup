# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20090929123020) do

  create_table "answers", :force => true do |t|
    t.integer  "employee_id"
    t.integer  "exam_id"
    t.integer  "question_id"
    t.string   "answer_text"
    t.integer  "answer_flag"
    t.integer  "type_flag",         :default => 1
    t.boolean  "is_correct_answer", :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.datetime "exam_date"
  end

  create_table "article_relationships", :force => true do |t|
    t.integer  "article_id"
    t.integer  "related_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "article_versions", :force => true do |t|
    t.integer  "article_id"
    t.integer  "version"
    t.integer  "category_id"
    t.string   "question"
    t.text     "answer"
    t.integer  "flag",        :default => 1
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "article_versions", ["article_id"], :name => "index_article_versions_on_article_id"

  create_table "articles", :force => true do |t|
    t.integer  "category_id"
    t.string   "question"
    t.text     "answer"
    t.integer  "flag",        :default => 1
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "version"
  end

  create_table "categories", :force => true do |t|
    t.string   "name",       :limit => 100
    t.integer  "flag",                      :default => 1
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "comments", :force => true do |t|
    t.integer  "article_id"
    t.string   "fullname",       :limit => 100
    t.string   "email",          :limit => 100
    t.text     "message"
    t.integer  "admin_approval",                :default => 0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "employee_exams", :force => true do |t|
    t.integer  "employee_id"
    t.integer  "exam_id"
    t.integer  "total_correct_answer", :default => 0
    t.integer  "total_questions",      :default => 0
    t.integer  "is_completed",         :default => 0
    t.text     "answers_dump"
    t.integer  "percentage"
    t.text     "result"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.datetime "exam_date"
    t.integer  "available_mins"
    t.boolean  "assigned_to_employee", :default => false
  end

  create_table "employee_groups", :force => true do |t|
    t.integer  "group_id"
    t.integer  "employee_id"
    t.boolean  "active_status", :default => true
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "exams", :force => true do |t|
    t.string   "title"
    t.text     "instruction"
    t.text     "comprehension"
    t.integer  "duration",       :default => 0
    t.datetime "exam_date"
    t.integer  "type_flag",      :default => 1
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "available_mins"
  end

  create_table "group_exams", :force => true do |t|
    t.integer  "exam_id"
    t.integer  "group_id"
    t.datetime "exam_date"
    t.integer  "total_employees_in_group",      :default => 0
    t.integer  "total_employees_attended_test", :default => 0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "groups", :force => true do |t|
    t.string   "name"
    t.string   "description"
    t.boolean  "active_status", :default => true
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "imageuploads", :force => true do |t|
    t.string   "content_type"
    t.string   "filename"
    t.integer  "size"
    t.integer  "question_id"
    t.string   "thumbnail"
    t.integer  "width"
    t.integer  "height"
    t.integer  "db_file_id"
    t.integer  "attachable_id"
    t.string   "attachable_type"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "questions", :force => true do |t|
    t.integer  "exam_id"
    t.text     "title"
    t.string   "option1"
    t.string   "option2"
    t.string   "option3"
    t.string   "option4"
    t.string   "answer_text"
    t.integer  "answer_flag", :default => 1
    t.integer  "type_flag",   :default => 1
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "ratings", :force => true do |t|
    t.integer  "article_id"
    t.integer  "rate_value"
    t.string   "ipaddress"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "sessions", :force => true do |t|
    t.string   "session_id", :null => false
    t.text     "data"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "sessions", ["session_id"], :name => "index_sessions_on_session_id"
  add_index "sessions", ["updated_at"], :name => "index_sessions_on_updated_at"

  create_table "taggings", :force => true do |t|
    t.integer  "tag_id"
    t.integer  "taggable_id"
    t.string   "taggable_type"
    t.datetime "created_at"
  end

  add_index "taggings", ["tag_id"], :name => "index_taggings_on_tag_id"
  add_index "taggings", ["taggable_id", "taggable_type"], :name => "index_taggings_on_taggable_id_and_taggable_type"

  create_table "tags", :force => true do |t|
    t.string "name"
  end

  create_table "users", :force => true do |t|
    t.string   "login"
    t.string   "type"
    t.string   "crypted_password",          :limit => 40
    t.string   "salt",                      :limit => 40
    t.string   "email"
    t.integer  "phone"
    t.string   "firstname"
    t.string   "lastname"
    t.integer  "active_status"
    t.string   "remember_token"
    t.datetime "remember_token_expires_at"
    t.datetime "last_loggedin_at"
    t.string   "last_loggedin_ip"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "password_reset_code"
  end

end
