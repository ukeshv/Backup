class AdminController < ApplicationController
  before_filter :require_ssl
	before_filter :login_required
	before_filter :super_admin_login_required
	layout "admin"
	
  def index
    session[:admin_panel] = 1
    assign_sessions(1, nil, nil, nil, nil, nil)
    if params[:tour] == "Owner name"
      @tours = Tour.sort_by_owner_name.paginate(:page => params[:page], :per_page =>20)
    elsif params[:tour] == "All Tours"
      @tours = Tour.order_by_review_default.paginate(:page => params[:page], :per_page =>20)
    elsif params[:tour] == "Deleted Tours" && params[:orderby].nil?
      @tours = Tour.order_by_deleted.paginate(:page => params[:page], :per_page =>20)
      $tour_status_params_admin=[-2]
    elsif params[:tour] == "No. of stops"
      @tours = Tour.sort_by_stops.paginate(:page => params[:page], :per_page =>20)
    elsif params[:tour]=="Tour name"
      @tours = Tour.sort_by_tour.paginate(:page => params[:page], :per_page =>20)
    elsif params[:tour]=="Ratings"
      @tours = Tour.sort_by_ratings.paginate(:page => params[:page], :per_page =>20)
    elsif params[:tour]=="Live tours" && params[:orderby].nil?
      @tours = Tour.order_by_live.paginate(:page => params[:page], :per_page =>20)
      $tour_status_params_admin=[10]
    elsif params[:tour]=="Draft tours" && params[:orderby].nil?
      @tours = Tour.order_by_draft.paginate(:page => params[:page], :per_page =>20)
      $tour_status_params_admin=[0]
    elsif params[:tour]=="Review tours" && params[:orderby].nil?
      @tours = Tour.order_by_review.paginate(:page => params[:page], :per_page =>20)
      $tour_status_params_admin=[3,4]
    elsif params[:search] && !params[:search].empty?
      $tour_status_params_admin=[-2,-1,0,1,2,3,4,5,6,7,8,9,10]
      @tours = Tour.search_by_keyword(params[:search]).paginate(:page => params[:page], :per_page =>20)
      flash.now[:flash_msg] = "Search Result for #{params[:search]}"
    elsif params[:orderby]=="title" || params[:orderby]=="status" || params[:orderby]=="rating"
      @tours=Tour.paginate :page=>params[:page], :per_page=>20, :conditions=>['status in (?)',$tour_status_params_admin],:order=>"#{params[:orderby]} #{params[:by]}"
    elsif params[:orderby]=="ownername"
      @tours = Tour.sort_by_owner_name_link($tour_status_params_admin,params[:by]).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="stops"
      @tours = Tour.sort_by_stops_link($tour_status_params_admin,params[:by]).paginate(:page => params[:page], :per_page =>20)
    else
      $tour_status_params_admin=[-2,-1,0,1,2,3,4,5,6,7,8,9,10]
      flash.now[:flash_error_msg] = "Enter a keyword to search" if params[:search] && params[:search].empty?
      @tours = Tour.order_by_review_default.paginate(:page => params[:page], :per_page =>20)
    end
  end 
	
  def users
    assign_sessions(nil, 1, nil, nil, nil, nil)
    if params[:user] == "Username"
      @users = User.sort_users_by_username.paginate(:page => params[:page], :per_page =>20)
    elsif params[:user] == "Email"
      @users = User.sort_users_by_email.paginate(:page => params[:page], :per_page =>20)
    elsif params[:user]=="No. of Tours"
      @users = User.sort_users_by_no_of_tours.paginate(:page => params[:page], :per_page =>20)
    elsif params[:user_search] && !params[:user_search].empty?
      @users = User.user_search_by_keyword(params[:user_search]).paginate(:page => params[:page], :per_page =>20)
      flash.now[:flash_msg] = "Search Result for #{params[:user_search]}"
    elsif params[:orderby]=="username" || params[:orderby]=="email" || params[:orderby]=="created_at" || params[:orderby]=="status"
      @users=User.paginate :page=>params[:page], :per_page=>20, :order=>"#{params[:orderby]} #{params[:by]}"
    elsif params[:orderby]="no_of_tours"
      @users = User.sort_users_by_no_of_tours_link(params[:by]).paginate(:page => params[:page], :per_page =>20)
    else
      flash.now[:flash_error_msg] = "Enter a keyword to search" if params[:user_search] && params[:user_search].empty?
      @users = User.sort_users_by_username.paginate(:page => params[:page], :per_page =>20)
    end
  end
  
  def change_status
    if !params[:perform_action].nil? && params[:perform_action] == "change_status" && !params[:id].nil?
      @user=User.find(params[:id])
      @user.status ==1 ? @user.update_attribute(:status,0) : @user.update_attribute(:status,1)
    end
    redirect_to :action=>"users"
  end

  def delete_to_submitted_for_review
    if !params[:perform_action].nil? && params[:perform_action] == "delete_to_submitted_for_review" && !params[:id].nil?
      @tour=Tour.find(params[:id])
      @tour.update_attribute(:status,1)
    end
    flash[:flash_msg]="Tour successfully Undeleted"
    redirect_to :action=>"index"
  end

  def rejected_to_draft
    if !params[:perform_action].nil? && params[:perform_action] == "rejected_to_draft" && !params[:id].nil?
      @tour=Tour.find(params[:id])
      @tour.update_attribute(:status,0)
    end
    flash[:flash_msg]="Tour successfully Unrejected"
    redirect_to :action=>"index"
  end
  
  def change_account_status  
    if !params[:perform_action].nil? && params[:perform_action] == "change_account_status" && !params[:id].nil?
      @groups=Account.find(params[:id])
      @groups.status ==1 ? @groups.update_attribute(:status,0) : @groups.update_attribute(:status,1)
    end
    redirect_to :action=>"accounts"
  end
  
  
  
  def accounts
    assign_sessions(nil, nil, 1, nil, nil, nil)
    #~ @groups = Account.all.paginate(:page => params[:page], :per_page =>20)
    if params[:account] == "Group name"
      @groups = Account.sort_group_by_name.paginate(:page => params[:page], :per_page =>20)
    elsif params[:account] == "Description"
      @groups = Account.sort_group_by_description.paginate(:page => params[:page], :per_page =>20)
    elsif params[:account]=="No. of users"
      @groups = Account.sort_group_by_no_of_users.paginate(:page => params[:page], :per_page =>20)
    elsif params[:account_search]  && !params[:account_search].empty?
      @groups = Account.group_search_by_keyword(params[:account_search]).paginate(:page => params[:page], :per_page =>20)
      flash.now[:flash_msg] = "Search Result for #{params[:account_search]}"
    elsif params[:orderby]=="groupname"
      @groups = Account.sort_group_by_name(params[:by]).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="description"
      @groups = Account.sort_group_by_description(params[:by]).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="no_of_users"
      @groups = Account.sort_group_by_no_of_users(params[:by]).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="status"
      @groups = Account.sort_group_by_status(params[:by]).paginate(:page => params[:page], :per_page =>20)
    else
      flash.now[:flash_error_msg] = "Enter a keyword to search" if params[:account_search] && params[:account_search].empty?
      @groups = @groups = Account.all.paginate(:page => params[:page], :per_page =>20)
    end
  end
  
  def admin_list
    assign_sessions(nil, nil, nil, 1, nil, nil)
    if params[:admin] == "Username"
      @admins = User.sort_admins_by_username.paginate(:page => params[:page], :per_page =>20)
    elsif params[:admin] == "Email"
      @admins = User.sort_admins_by_email.paginate(:page => params[:page], :per_page =>20)
    elsif params[:admin]=="No. of Tours"
      @admins = User.sort_admins_by_no_of_tours.paginate(:page => params[:page], :per_page =>20)
    elsif params[:admin_search]  && !params[:admin_search].empty?
      @admins = User.admin_search_by_keyword(params[:admin_search]).paginate(:page => params[:page], :per_page =>20)
      flash.now[:flash_msg] = "Search Result for #{params[:admin_search]}"
    elsif params[:orderby]=="username"
      @admins = User.sort_admins_by_username_link(params[:by]).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="email"
      @admins = User.sort_admins_by_email_link(params[:by]).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="no_of_tours"
      @admins = User.sort_admins_by_no_of_tours_link(params[:by]).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="created_at"
      @admins = User.sort_admins_by_member_since_link(params[:by]).paginate(:page => params[:page], :per_page =>20)
    else
      flash.now[:flash_error_msg] = "Enter a keyword to search" if params[:admin_search] && params[:admin_search].empty?
      @admins = User.sort_admins_by_username.paginate(:page => params[:page], :per_page =>20)
    end
  end

  def display_users_by_alphabet
    @users = User.find_by_alphabet(params[:alpha]) 
    render :update do |page|
      page.replace_html "alphabet_a_z", :partial => "/admin/display_users_by_alphabet"
    end 
  end
  
  def create_account
  end
  
  def create_account_name
    @account=Account.new(params[:accounts])
    if @account.save
      redirect_to :action => "add_users_to_account", :account_id => @account.id
    else
      flash[:error] = "Group name can't be blank"
      redirect_to :action=> "create_account"
    end
  end
  
  def add_users_to_account
    @account_id = params[:account_id]
    @account =Account.find(params[:account_id])
    @users = User.all(:conditions=>['users.username like ?', 'A%'])
    return unless request.post?
    @user= User.find(params[:user_id])
    @user.accounts << @account
    @user_id = @user.id
    render :update do |page|
      page.replace_html "image_change_#{@user.id}", :partial => "/admin/change_button", :locals =>{:status => 'delete'}, :object => @user_id
    end 
  end 
  
  def  make_user_to_admin
    return unless request.post?
    @user_account=UserAccount.find_by_user_id_and_account_id(params[:user_id], params[:account_id ])
    @user_account.update_attribute("user_type", params[:user_type])
    @user_id = params[:user_id]
    @user=User.find(@user_id)
    @user.update_attribute(:user_type,2)
    render :update do |page|
      page.replace_html "image_change_#{@user_id }", :partial => "/admin/change_admin_button", :locals =>{:status => 'delete'}, :object => @user_id
    end
  end

  def remove_users_to_account
    @user_id = params[:user_id]
    return unless request.post?
    @user_account=UserAccount.find_by_user_id_and_account_id(params[:user_id], params[:account_id ])
    @user_account.destroy if @user_account
    render :update do |page|
      page.replace_html "image_change_#{@user_id}", :partial => "/admin/change_button", :locals =>{:status => 'add'}, :object => @user_id
    end 
  end

  def remove_admin_from_account
    @user_id = params[:user_id]
    @user=User.find(@user_id)
    @user.update_attribute(:user_type,1)
    return unless request.post?
    @user_account=UserAccount.find_by_user_id_and_account_id(params[:user_id], params[:account_id ])
    @user_account.update_attribute("user_type", params[:user_type])
    render :update do |page|
      page.replace_html "image_change_#{@user_id }", :partial => "/admin/change_admin_button", :locals =>{:status => 'add'}, :object => @user_id
    end
  end
  
  def change_owner
    @tour = Tour.find_by_id(params[:tour_id])
    return unless request.xhr?
    if params[:search] && !params[:search].empty?
      @users = User.change_owner_search_by_keyword(params[:search])
      flash.now[:flash_msg] = "Search Result for #{params[:search]}"
      render :update do |page|
        page.replace_html "search_error_display", :text => "<font color='green'> Search Result for #{params[:search]}</font>"
        page.replace_html "user_search_results", :partial => "user_search_result"
      end
    else
      render :update do |page|
        page.replace_html "search_error_display", :text => "<font color='red'> Enter a Keyword to search</font>"
      end
    end
  end

  def add_admins_to_account
    @account=Account.find(params[:account_id])
    @users = @user_accounts= @account.all_users
  end

  def change_the_owner
    tour = Tour.find(params[:tour_id])
    tour.update_attribute("user_id", params[:user_id])
    flash.now[:flash_msg] = "Tour owner changed to #{tour.user.username}"
    return unless request.xhr?
    render :update do |page|
      page.redirect_to tour_path(params[:tour_id], :tour_id => params[:tour_id])
    end
  end

  def tasks
    assign_sessions(nil, nil, nil, nil, 1, nil)
    @tasks = Task.find(:all, :conditions => ["state = ? or state = ?", 0,1]).paginate(:page => params[:page], :per_page =>20)
  end

  def receipts
    assign_sessions(nil, nil, nil, nil, nil, 1)
    @receipts = Receipt.find(:all).paginate(:page => params[:page], :per_page =>20)
  end

  def change_task_status
    if !params[:id].nil?
      task=Task.find(params[:id])
      (task && task.state == 1) ? task.update_attribute(:state, 0) : " "
    end
    redirect_to :action=>"tasks"
  end
  
  def users_created_recently
    assign_sessions(nil, nil, nil, nil, nil, nil,1)
    @user_registered_today=User.find(:all, :conditions=>['DATE(created_at)=?', Date.current-1]).paginate(:page => params[:page], :per_page =>20)
  end

  def users_activities_recently
    @users=[]
    @reports_history=History.find(:all, :conditions=>['DATE(created_at)=?', Date.current-1])
    @reports_history && @reports_history.each do |history|
      @users << history.user
    end
    @users=@users.uniq.paginate(:page => params[:page], :per_page =>20)
  end
  
  def pay_user
    assign_sessions(nil, nil, nil, nil, nil, nil,nil,1)
    @paypalreceipts=PaypalReceipt.all.collect{|y| y.receipt_id}
    if @paypalreceipts.empty?
      @receipts=Receipt.all
    else
      @receipts=Receipt.all(:conditions=>['id not in (?)',@paypalreceipts])
    end
    @tour_ids=@receipts.collect{|x| x.tour_id if x.tour.category!=9}
    @tour_ids=@tour_ids.uniq.flatten.compact
    @tours=Tour.find(@tour_ids)
    @users=[]
    @receipts.each do |rec|
     @users << rec.tour.user
    end
   @users=@users.uniq.flatten.paginate(:page => params[:page], :per_page =>20)
 end
 
 def pay_cheque
    @user=User.find(params[:user_id])
   if !params[:cheque_no].empty? && !@user.snail_address.nil? && @user.snail_address!="" && @user.i_agree==true
     @tours_receipt_ids =[]
     @tours=@user.tours
     @tours.each do |tour|
       tour.receipts.each do |rec|
          @tours_receipt_ids << rec.paypal_receipt.receipt_id if rec.paypal_receipt
        end
      end
      if !@tours_receipt_ids.empty?
        @pay_rec=Receipt.find(:all,:conditions=>['id not in (?) and tour_id in (?)',@tours_receipt_ids.uniq.flatten,@user.tour_ids])
      else
        @pay_rec=Receipt.find_all_by_tour_id(@user.tour_ids)
      end
      @pay_tran=PaypalTransaction.create(:user_id=>@user.id,:paid_to=>@user.snail_address,:transaction_id=>"cheque-"+params[:cheque_no],:amount_transferred=>params[:total],:status=>1, :payment_date=>Time.current,:paypal_token=>params, :comments=>params[:comments])
      @pay_rec.each do |rec|
      PaypalReceipt.create(:paypal_transaction_id=>@pay_tran.id, :receipt_id=>rec.id)
    end
     UserMailer.deliver_cheque_sent(@user, "Cheque sent",params[:total],"Cheque sent to your Snail Address")
     flash[:transaction_success]="$ #{params[:total]} was sent to #{@user.username} by means of cheque"
   else
     if @user.i_agree==false
      flash[:i_agree_error]="User #{@user.username} haven't agreed the User Agreement."
      redirect_to pay_user_admin_path and return
     end
      if @user.snail_address.nil? || @user.snail_address==""
        flash[:transaction_error]="User #{@user.username}'s Snail Address empty. Send Mail to notify him."
      else
        flash[:transaction_error]="Please fill Cheque number"
      end
   end
   redirect_to pay_user_admin_path
 end
 
def payment_history
  @pay_trans=PaypalTransaction.all.reverse.paginate(:page => params[:page], :per_page =>20)
end
 
def send_snail_address_mail
  @user=User.find(params[:user_id])
  @user.snail_reset_link(@user)
  flash[:transaction_success]="A mail has been sent to #{@user.username} to fill his/her Snail Address."
  redirect_to pay_user_admin_path
end


def info_mail
 @user_email=User.find(:all,:conditions=>['subscribe = true']).collect(&:email)
end
  
def send_info_mail
  if !params[:emails].nil?
  users=User.find(:all,:conditions=>['email in (?)', params[:emails]])
  user_ids=users.map(&:id).flatten.compact.uniq
  Delayed::Job.enqueue DelayedNotification.new(user_ids,params[:subject],params[:message_to_send])
    #~ users && users.each do |u|
    #~ UserMailer.deliver_whats_new_in_geotrio(u, params[:message_to_send])
  #~ end
  flash[:info_mail_delay] ="Mail list is added in Job soon all users will be delivered by mail"
  redirect_to info_mail_admin_path
else
flash[:info_mail_delay] ="Please select atleast one email to send the message"
redirect_to info_mail_admin_path
end
end
  
end

