class AdminSessionsController < ApplicationController
  before_filter :check_port
  before_filter :check_login, :except=>['destroy']
  layout "new", :only =>["new", "create"]

  def new
   
  end
  
  def create
    @user = User.authenticate(params[:username], params[:password])
    if @user && @user.user_type == 0
      if params[:remember_me] == "1"
        current_user.remember_me unless current_user.remember_token?
        cookies[:auth_token] = { :value => self.current_user.remember_token , :expires => self.current_user.remember_token_expires_at }
      end
      self.current_user = @user
      session[:admin] = 1
      flash[:notice] = "Logged in successfully"
      redirect_to admin_index_path
    else
      flash.now[:login_error] = "Invalid Admin Login/Password!"
      render :action => 'new'
    end
  end

  def destroy
    logout_killing_session!
    session[:admin] = nil
    flash[:logout_notice] = "You have been logged out."
    redirect_back_or_default(admin_login_path)
  end
end
