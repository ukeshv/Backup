# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  helper :all # include all helpers, all the time
  protect_from_forgery # See ActionController::RequestForgeryProtection for details
  require 'hyper_graph'
    

  include AuthenticatedSystem
  include ExceptionNotifiable
  include SimpleCaptcha::ControllerHelpers
  include ActiveMerchant::Billing
  ActiveMerchant::Billing::Base.gateway_mode = :test
  $secret =  "foobar"
  # Scrub sensitive parameters from your log
  # filter_parameter_logging :password
  def strip_for_values(object,parameters)
    for parameter in parameters
      object[parameter[0]] = parameter[1].strip 
    end	  
  end  

  def require_ssl
    if !request.ssl? && RAILS_ENV != "development"
      redirect_to :protocol => "https://"
    end
  end

  def change_layout 
    (session[:admin_panel] == 1)? "admin" : (session[:admin_panel] == 2)? "group_admin" : "home"
  end
  
  def change_layout_game
    (params[:action] == "game_main")? "game_tab": "game"
    p params.inspect
  end
  
  def current_user_name
    current_user.username if current_user
  end
  
  def check_login
    if current_user
      if params[:action]=="contact" || params[:action]=="contact_mail"
      else  
       redirect_to tours_index_path(current_user.username)
      end
    end
    
   
  end
  
  def super_admin_login_required
    if current_user 
      @user = User.find(current_user.id)
      if @user.user_type == 0
        return true
      else
        redirect_to_root
      end 
    else
      redirect_to_root
    end
  end  
  
  def group_admin_login_required
    if current_user 
      @user = User.find(current_user.id)
      if @user.user_type == 2
        return true
      else
        redirect_to_root
      end 
    else
      redirect_to_root
    end
  end
  
  def check_if_super_admin
    @user = User.find(current_user.id)
    if @user.user_type == 0
      redirect_to admin_index_path
    else
      return true
    end
  end

  def assign_sessions(a,b,c,d,e=nil,f=nil,g=nil,h=nil,i=nil)
    session[:tour] = a
    session[:user] = b
    session[:group] = c
    session[:admin_tab] = d
    session[:task] = e
    session[:receipt] = f
    session[:report] = g 
    session[:payuser] = h
    session[:infomail] = i
  end
  
  def add_price(tour)
    tour = tour.merge({:price => '0'}) if tour[:price].nil?
    return tour
  end

  def render_to_pdf(options = nil)
    data = render_to_string(options)
    pdf = PDF::HTMLDoc.new
    pdf.set_option :bodycolor, :white
    pdf.set_option :toc, false
    pdf.set_option :portrait, true
    pdf.set_option :links, false
    pdf.set_option :webpage, true
    pdf.set_option :left, '2cm'
    pdf.set_option :right, '2cm'
    pdf << data
    pdf.generate
  end

  def get_audio_file_duration
    command= Mp3Info.open("#{@audio.public_filename}").length.round
  end

  #~ def gateway
  #~ gateway = ActiveMerchant::Billing::PaypalGateway.new(
  #~ :login => PAYPAL_CONFIG['login'],
  #~ :password => PAYPAL_CONFIG['password'],
  #~ :signature => PAYPAL_CONFIG['signature'])
  #~ end

  def send_mp3
     if !params[:mp3].nil?
    file_name = params[:mp3].pop.split('_').first
    file = (params[:mp3]+[file_name]).join('/')
    #file = "/files/1/156/audio/0.mp3"
    send_file file, :type => 'audio/mp3', :disposition => 'inline'
    else
      redirect_to root_path
    end
  end
  
  def create_table_entries_mysql(stop_array, tours_stops_array, tour_tracks_array)
    #~ Call-back won't work for this method, since we used MySQL query..
      sql = ActiveRecord::Base.connection();
      #~ sql.execute("insert into stops(name,text,latitude,longitude,altitude,created_at,updated_at) values #{stop_array}")
      sql.execute("insert into tours_stops(tour_id,stop_id,sequence) values #{tours_stops_array}")
      sql.execute("insert into tour_tracks(tour_id,latitude,longitude,altitude,is_stop) values #{tour_tracks_array}")
    end
    
    def verify_fb_acess
     referer = request.env["HTTP_REFERER"]

     if (referer && referer.include?("apps.facebook.com")) 
        session.data.delete :game_tour_id
        session[:game_tour_id]= nil

      else
        session[:game_tour_id] = params[:tour_id]
        unless request.xhr?
        if params[:tour_id]
          redirect_to "#{FACEBOOK_CONFIG['facebook_redir_url']}#{params[:tour_id]}"
        elsif params[:next].split("=").last != ""
          redirect_to "#{FACEBOOK_CONFIG['facebook_redir_url']}#{params[:next].split("=").last}"
        else
        redirect_to "#{FACEBOOK_CONFIG['facebook_redir_url']}"
        end
        end
      end
     
    end
      



  private 
  
  def redirect_to_root
    redirect_to root_path
  end     
end

