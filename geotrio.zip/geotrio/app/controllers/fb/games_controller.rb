class Fb::GamesController < ApplicationController   

 	#~ layout :change_layout_game
  layout 'game'
  ensure_authenticated_to_facebook
  before_filter :verify_fb_acess, :only=>['play','find_audio_for_stop','game_main','canvas']

  def play
      
    @tour = Tour.find_by_id(params[:tour_id],:conditions=>['status=10 && category=10'])
    
  if @tour
		@zerothstop = @tour.stops[0]
    @firststop = @tour.stops[1]
    @stops = @tour.get_all_stops
    @tracks = @tour.tour_tracks
      
    @stopaudio=@zerothstop.audio.public_filename.split("/").last

   
    @lat0=@zerothstop.latitude
    @long0=@zerothstop.longitude
    @lat1=@firststop.latitude
    @long1=@firststop.longitude
  
    @stopcount=@stops.length
    @previous_stop_lat=@lat0
    @previous_stop_long=@long0

    @a=[]
    @b=[]
    @overall_top=PlayedTour.find(:all,:conditions=>['tour_id = ? && fb_user_id != ?', session[:game_tour_id],@fb_user_check],:order=>"total_clicks ASC",:limit=>5).collect{|x| @a<<x.fb_user_id; @b<<x.total_clicks}
  
  
    @fb_user_overall_top=FbUser.find(:all, :conditions=> ['id IN (?)',@a]).collect{|c| c.fb_user}

    fb_session = Facebooker::Session.create
    fbsession = Facebooker::Session.create(FACEBOOKER["api_key"],FACEBOOKER["secret_key"])
    @fb_user_name=[]
    @click_count=[]
   
   
   @fb_user_overall_top.each_with_index do |x,index|
   @fb_user=Facebooker::User.new(x,fbsession)
   @fb_user_name <<@fb_user.first_name<<@b[index]
   end
    
  else
   render :text=> "This is not a Live tour to play"
  end
        

  if request.xhr?
    @tour = Tour.find(params[:tour_id])
      if (@tour.stops.length != params[:stopcount].to_i)  
      @currentstop = @tour.stops[params[:stopcount].to_i]
      @lat1= @currentstop.latitude
      @long1= @currentstop.longitude
      
      @previous_stopcount=params[:stopcount].to_i-1

      @previous_stop = @tour.stops[@previous_stopcount.to_i]
      @previous_stop_lat= @previous_stop.latitude
      @previous_stop_long= @previous_stop.longitude

      @stopcount=params[:stopcount].to_i

      @fb_use=FbUser.find_by_fb_user(session[:fb_user_session])
      
    if !params[:check]
      @stops_complete_present_s=CompletedStop.find_by_tour_id_and_fb_user_id_and_stops_completed(params[:tour_id],@fb_use.id,params[:stopcount])
    else
      @stops_complete_present_s=CompletedStop.find_by_tour_id_and_fb_user_id_and_stops_completed(params[:tour_id],@fb_use.id,params[:stopcount].to_i-1)
    end
      
      #~ if params[:click_count] && @stops_complete_present_s.nil?
       #~ @stops_complete_present_s=CompletedStop.new(:tour_id=>params[:tour_id],:fb_user_id=>@fb_use.id,:stops_completed=>params[:stopcount].to_i-1,:clickcount=>params[:click_per_stop].to_i-1,:is_completed=>'1')
       #~ @stops_complete_present_s.save   
       #~ end
              #~ @stops_complete_present_a=CompletedStop.find_by_tour_id_and_fb_user_id_and_stops_completed(params[:tour_id],@fb_use.id,params[:stopcount].to_i-1)

          #~ if @stops_complete_present_s.nil? && params[:click_count].present?
            #~ p "if"
            #~ @stops_complete_present_s=CompletedStop.new(:tour_id=>params[:tour_id],:fb_user_id=>@fb_use.id,:stops_completed=>params[:stopcount].to_i,:clickcount=>params[:click_per_stop],:is_completed=>'1')
            #~ @stops_complete_present_s.save   
                     
          #~ elsif @stops_complete_present_s.nil? && !params[:click_count].present?
            #~ p "eif1"
            #~ @stops_complete_present_s=CompletedStop.new(:tour_id=>params[:tour_id],:fb_user_id=>@fb_use.id,:stops_completed=>params[:stopcount].to_i,:clickcount=>params[:click_per_stop],:is_completed=>'0')
            #~ @stops_complete_present_s.save   
            
            #~ @up_c_stop=CompletedStop.find_by_tour_id_and_fb_user_id_and_stops_completed(params[:tour_id],@fb_use.id,params[:stopcount].to_i-1)
            #~ @up_c_stop.update_attributes(:clickcount=>params[:click_count].to_i,:is_completed=>'1')
            #~ @up_c_stop.save
           
      if @stops_complete_present_s.nil? && params[:click_count]
        @stops_complete_present_s=CompletedStop.new(:tour_id=>params[:tour_id],:fb_user_id=>@fb_use.id,:stops_completed=>params[:stopcount].to_i-1,:clickcount=>params[:click_per_stop],:is_completed=>'1')
        @stops_complete_present_s.save 

      elsif @stops_complete_present_s.nil? && !params[:click_count]
        @stops_complete_present_s=CompletedStop.new(:tour_id=>params[:tour_id],:fb_user_id=>@fb_use.id,:stops_completed=>params[:stopcount].to_i,:clickcount=>params[:click_per_stop],:is_completed=>'0')
        @stops_complete_present_s.save 

      elsif !@stops_complete_present_s.nil? && !params[:click_count]
                
      #~ elsif !@stops_complete_present_s.nil? && params[:click_count]
        #~ @up_c_stop=CompletedStop.find_by_tour_id_and_fb_user_id_and_stops_completed(params[:tour_id],@fb_use.id,params[:stopcount].to_i-1)
        #~ @up_c_stop.update_attributes(:clickcount=>params[:click_count].to_i,:is_completed=>'1')
        #~ @up_c_stop.save
           
        @stops_complete_present_s.update_attributes(:clickcount=>@stops_complete_present_s.clickcount+1,:is_completed=>'0')
        @stops_complete_present_s.save 

      else 
        @stops_complete_present_s.update_attributes(:clickcount=>@stops_complete_present_s.clickcount+1,:is_completed=>'1')
        @stops_complete_present_s.save 

      end
    
      render :update do |page|
          page.call "loadNextStopValues",@lat1,@long1,@previous_stop_lat,@previous_stop_long,@stopcount
        end
          
      else

        @fb_use=FbUser.find_by_fb_user(session[:fb_user_session])
        if !params[:check]
        @stops_complete_present_i=CompletedStop.find_by_tour_id_and_fb_user_id_and_stops_completed(params[:tour_id],@fb_use.id,params[:stopcount].to_i)
        else
        @stops_complete_present_i=CompletedStop.find_by_tour_id_and_fb_user_id_and_stops_completed(params[:tour_id],@fb_use.id,params[:stopcount].to_i-1)
        end
      
        if @stops_complete_present_i.nil? && params[:click_count]
        @stops_complete_present_i=CompletedStop.new(:tour_id=>params[:tour_id],:fb_user_id=>@fb_use.id,:stops_completed=>params[:stopcount].to_i-1,:clickcount=>params[:click_per_stop],:is_completed=>'1')
        @stops_complete_present_i.save 

        elsif @stops_complete_present_i.nil? && !params[:click_count]
        @stops_complete_present_i=CompletedStop.new(:tour_id=>params[:tour_id],:fb_user_id=>@fb_use.id,:stops_completed=>params[:stopcount].to_i,:clickcount=>params[:click_per_stop],:is_completed=>'0')
        @stops_complete_present_i.save 

        elsif !@stops_complete_present_i.nil? && !params[:click_count]
        @stops_complete_present_i.update_attributes(:clickcount=>@stops_complete_present_i.clickcount+1,:is_completed=>'0')
        @stops_complete_present_i.save 

        else
        @stops_complete_present_i.update_attributes(:clickcount=>@stops_complete_present_i.clickcount+1,:is_completed=>'1')
        @stops_complete_present_i.save 

      end
        
          @fb_exists=PlayedTour.find(:all,:conditions=>['tour_id = ? and fb_user_id = ?', params[:tour_id] , @fb_use.id])
          if @fb_exists.to_a.empty?
          @played_user=PlayedTour.new(:tour_id=>params[:tour_id],:total_clicks=>params[:click_count],:fb_user_id=>@fb_use.id,:is_completed=>'1')
          @played_user.save
          end
      
          @tour_id=params[:tour_id]              
          @tour_title=@tour.title
          @totalclicks=params[:click_count]
          
          render :update do |page|
          page.call "connectFacebook",@tour_id,@tour_title,@totalclicks
          page.Alert.fnAlertfinish "Cool you finished the tour with &nbsp;<b> #{params[:click_count]}  clicks</b>"
          page.replace_html 'clue' ,"<div style='margin-top: -25px; margin-left:60px;font-size: 14px; color: green;'>Cool you finished the tour with #{params[:click_count]} clicks</div>"
          page.replace_html 'preview' ,""
          page.replace_html 's' ,""
          page.call('updateDivCss', 'overall_top')
          end
        
      end
  end
end
  
  
  def find_audio_for_stop
    
    pointlatlng = params[:pointerlatlang].gsub(/[() ]/,'').split(',')

    @tour = Tour.find(params[:tour_id])
    @stopslatlang=@tour.stops.collect{|x|[x.latitude,x.longitude,x.id]}
    
        @stopslatlang.each do |x|
        if ((x[0] == pointlatlng[0].to_f) and (x[1] == pointlatlng[1].to_f))
        @stop=Stop.find(x[2])
        end
        end
       
    @stopaudio=@stop.audio.public_filename.split("/").last

      render :update do |page|
        page.call "loadaudio",@stopaudio
      end
    
  end
  
  
  def canvas
   
   @fb_user_all=FbUser.find_by_fb_user(params[:fb_sig_user])
    
    if params[:fb_sig_user]
      session[:fb_user_session]=params[:fb_sig_user]
      if @fb_user_all.nil?
      @fb_user=FbUser.new(:user_id=>current_user ? current_user.id : nil ,:fb_user=>params[:fb_sig_user],:fb_app_id=>params[:fb_sig_app_id],:fb_sig=>params[:fb_sig],:fb_sig_country=>params[:fb_sig_country])
      @fb_user.save
      end
    end
    
   if params[:auth_token] && params[:tour_id]
     redirect_to "/fb/#{params[:tour_id]}/play"
   end  
   
   
    @fb_user_check=FbUser.find_by_fb_user(params[:fb_sig_user])
    
    if @fb_user_check
    @played_tour=PlayedTour.find(:all,:conditions=>['tour_id = ? and fb_user_id = ?',params[:tour_id],@fb_user_check.id])
    @completed_stop_present_c=CompletedStop.find(:all,:conditions=>['tour_id = ? and fb_user_id = ?',params[:tour_id],@fb_user_check.id])
    
    
      if !@played_tour.empty?
        session[:game_tour_id] = params[:tour_id]
        redirect_to "/fb/resume_tour"
      else 
        if !@completed_stop_present_c.empty?
        session[:game_tour_id] = params[:tour_id]
        redirect_to "/fb/resume_tour"
        
      else  
          
      #~ Played tour "tourid session" and "fb user session" not present
            if session[:game_tour_id] 
                 redirect_to "/fb/#{session[:game_tour_id]}/play"
            elsif params[:tour_id]
                 redirect_to "/fb/#{params[:tour_id]}/play"
            else  
                 redirect_to "/fb/game_main"            
            end
        end    
      end
    end            
  end       
  
  def game_main
    if session[:fb_user_session]
      @fb_user_already_exists=FbUser.find_by_fb_user(session[:fb_user_session])
      @already_played_tour_by_current_user =  PlayedTour.find(:all,:conditions=>['fb_user_id = ?',@fb_user_already_exists.id])
      title=[]
      @tour_title=[]
      @already_played_tour=[]
      
        if @already_played_tour_by_current_user
          #~ @already_played_tour_by_current_user.each do |already_played|
            #~ @tour_title<<Tour.find_by_id(already_played.tour_id)
            #~ @tour_title.collect {|x| title<<x.title}
            #~ @already_played_tour<<title<<already_played.total_clicks
          #~ end
        #~ end 
         @already_played_tour_by_current_user.each do |already_played|
          @tour_title<<already_played.tour_id<<already_played.total_clicks
        end
        
        @array1=[]
        @array2=[]
        @tour_title.each_with_index do |tit,index| 
        if (index%2==0)  
        @array2.push(tit) 
        else
        @array1.push(tit)
        end
        end
        
        @array_title=[]
        
       
        @array2.each do |a|
          @array_title<<Tour.find(:all,:conditions=>['id = ?',a]).map{|x| x.title}
        end
      
        end
    end
  end
  
  
  def resume_tour
    
    @fb_user_check=FbUser.find_by_fb_user(session[:fb_user_session])
    
    @completed_stop_present=CompletedStop.find(:all,:conditions=>['tour_id = ? and fb_user_id = ? and is_completed = ?',session[:game_tour_id],@fb_user_check.id,1])
    
    @completed_stop_present_dis=CompletedStop.find(:all,:conditions=>['tour_id = ? and fb_user_id = ?',session[:game_tour_id],@fb_user_check.id])
    #~ @completed_stop_present_dis_con=CompletedStop.find(:all,:conditions=>['tour_id = ? and fb_user_id = ? and is_completed=?',session[:game_tour_id],@fb_user_check.id,0])
    @tour=Tour.find_by_id(session[:game_tour_id])
    @stops=@tour.stops
    
    @completed_stops_count= @completed_stop_present.length+1

    @stopaudio=@stops[@completed_stop_present.length].audio.public_filename.split("/").last
    @stops = @tour.get_all_stops
    @comp_stop_val=@stops[0, @completed_stops_count]
    @comp_lat_lng=[]
    
    clicks=[]
    @completed_stop_present.each do |a|
    clicks<<a.clickcount
    end
    @clicks=clicks.inject(0) { |s,v| s += v }
    
    @comp_stop_val.each do |x|
    @comp_lat_lng<<x.latitude.to_s+"_"<<x.longitude.to_s+"_"
    end
  
  
    @a=[]
    @b=[]
    @overall_top=PlayedTour.find(:all,:conditions=>['tour_id = ? && fb_user_id != ?', session[:game_tour_id],@fb_user_check],:order=>"total_clicks ASC",:limit=>5).collect{|x| @a<<x.fb_user_id; @b<<x.total_clicks}

    @fb_user_overall_top=FbUser.find(:all, :conditions=> ['id IN (?)',@a]).collect{|c| c.fb_user}
  
      
    fb_session = Facebooker::Session.create
    fbsession = Facebooker::Session.create(FACEBOOKER["api_key"],FACEBOOKER["secret_key"])
    @fb_user_name=[]
    @click_count=[]
         
    @current_user_present=FbUser.find(:all,:conditions=>['fb_user = ?',session[:fb_user_session]]).collect{|c| c.id}
    
    if @current_user_present
    @current_user_total_clicks=PlayedTour.find(:all,:conditions=>['tour_id = ? and fb_user_id = ?',session[:game_tour_id],@current_user_present])
    end
     
       
    @fb_user_overall_top.each_with_index do |x,index|
    @fb_user=Facebooker::User.new(x,fbsession)
      if session[:fb_user_session] != x
      @fb_user_name <<@fb_user.first_name<<@b[index]
      end
    end
   
  
  
  
      if request.xhr?
     
      @tour = Tour.find(params[:tour_id])
       
        if (@tour.stops.length != params[:stopcount].to_i)  
        
        
          @currentstop = @tour.stops[params[:stopcount].to_i-1]
          @lat1= @currentstop.latitude
          @long1= @currentstop.longitude
              
          @next_stopcount=params[:stopcount].to_i
          @next_stop = @tour.stops[@next_stopcount.to_i]
          @next_stop_lat= @next_stop.latitude
          @next_stop_long= @next_stop.longitude
          @stopcount=params[:stopcount].to_i
          
            @fb_use_r=FbUser.find_by_fb_user(session[:fb_user_session])
        
              if !params[:check]
              @stops_complete_present_r=CompletedStop.find_by_tour_id_and_fb_user_id_and_stops_completed(params[:tour_id],@fb_use_r.id,params[:stopcount])
              else
              @stops_complete_present_r=CompletedStop.find_by_tour_id_and_fb_user_id_and_stops_completed(params[:tour_id],@fb_use_r.id,params[:stopcount].to_i-1)
              end
            
        if @stops_complete_present_r.nil? && params[:click_count]
        @stops_complete_present_r=CompletedStop.new(:tour_id=>params[:tour_id],:fb_user_id=>@fb_use_r.id,:stops_completed=>params[:stopcount].to_i-1,:clickcount=>params[:click_per_stop],:is_completed=>'1')
        @stops_complete_present_r.save 

      elsif @stops_complete_present_r.nil? && !params[:click_count]

        @stops_complete_present_r=CompletedStop.new(:tour_id=>params[:tour_id],:fb_user_id=>@fb_use_r.id,:stops_completed=>params[:stopcount].to_i,:clickcount=>params[:click_per_stop],:is_completed=>'0')
        @stops_complete_present_r.save 

      elsif !@stops_complete_present_r.nil? && !params[:click_count]
        @stops_complete_present_r.update_attributes(:clickcount=>@stops_complete_present_r.clickcount+1,:is_completed=>'0')
        @stops_complete_present_r.save 

      else 

        @stops_complete_present_r.update_attributes(:clickcount=>@stops_complete_present_r.clickcount+1,:is_completed=>'1')
        @stops_complete_present_r.save 

      end
    

          render :update do |page|
            page.call "loadnextstopvalues",@lat1,@long1,@next_stop_lat,@next_stop_long,@stopcount
          end
            
            
          
        else

          @fb_use_s=FbUser.find_by_fb_user(session[:fb_user_session])
        
        
        @stops_complete_present_ra=CompletedStop.find_by_tour_id_and_fb_user_id_and_stops_completed(params[:tour_id],@fb_use_s.id,params[:stopcount].to_i-1)
        
      
      if @stops_complete_present_ra.blank?
        @stops_complete_present_re=CompletedStop.new(:tour_id=>params[:tour_id],:fb_user_id=>@fb_use_s.id,:stops_completed=>params[:stopcount].to_i-1,:clickcount=>params[:click_per_stop],:is_completed=>'1')
        @stops_complete_present_re.save 
        @total_clicks=params[:click_count]
      end
      
      if @stops_complete_present_ra.present? && @stops_complete_present_ra.is_completed==0
          p "present & is_completed=0"
           p params.inspect
          @stops_complete_present_ra.update_attributes(:clickcount=>params[:click_per_stop],:is_completed=>'1')
           @stops_complete_present_ra.save 
           @totalclicks=params[:click_count].to_i
      end
      
      
    @completed_stop_present_final=CompletedStop.find(:all,:conditions=>['tour_id = ? and fb_user_id = ? and is_completed = ?',session[:game_tour_id],@fb_use_s.id,1])


    clicks_final=[]
    
    @completed_stop_present_final.each do |a|
    clicks_final<<a.clickcount
    end
    @clicksfinal=clicks_final.inject(0) { |s,v| s += v }
    
      

        @fb_exists=PlayedTour.find(:all,:conditions=>['tour_id = ? and fb_user_id = ?', params[:tour_id] , @fb_use_s.id])
        
          if @fb_exists.to_a.empty?
          @played_user=PlayedTour.new(:tour_id=>params[:tour_id],:total_clicks=>@clicksfinal,:fb_user_id=>@fb_use_s.id,:is_completed=>'1')
          @played_user.save
          end
          
      @tour_id=params[:tour_id]              
      @tour_title=@tour.title
      
      
         render :update do |page|
            page.call "connectFacebook",@tour_id,@tour_title,@clicksfinal
            page.Alert.fnAlertfinish "Cool you finished the tour with &nbsp;<b> #{@clicksfinal} clicks</b>"
            page.replace_html 'clue' ,"<div style='margin-top: -25px; margin-left:60px;font-size: 14px; color: green;'>Cool you finished the tour with #{@clicksfinal} clicks</div>"
            page.replace_html 'preview' ,""
            page.replace_html 's' ,""
            page.call('updateDivCss', 'overall_top')
          end
      
      end
    
    end

end
end