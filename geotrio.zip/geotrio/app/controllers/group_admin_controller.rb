class GroupAdminController < ApplicationController
	
  before_filter :require_ssl
	before_filter :login_required
	before_filter :group_admin_login_required
	layout "group_admin"
	
  def index
    @user = current_user
    @user_accounts_ids= @user.account_ids
    session[:admin_panel] = 2
    assign_sessions(1, nil, nil, nil)
    if params[:tour]=="Live tours" && params[:orderby].nil?
      @tours = Tour.group_admin_order_by_live(current_user.accounts).paginate(:page => params[:page], :per_page =>20)
      $tour_status_params=[10]
    elsif params[:tour] == "All Tours"
      @tours = Tour.group_admin_order_by_review(current_user.accounts).paginate(:page => params[:page], :per_page =>20)
    elsif params[:tour] == "Deleted Tours" && params[:orderby].nil?
      @tours = Tour.group_admin_order_by_deleted(current_user.accounts).paginate(:page => params[:page], :per_page =>20)      
      $tour_status_params=[-2]
    elsif params[:tour]=="Draft tours" && params[:orderby].nil?
      @tours = Tour.group_admin_order_by_draft(current_user.accounts).paginate(:page => params[:page], :per_page =>20)
      $tour_status_params=[0]
    elsif params[:tour]=="Review tours" && params[:orderby].nil?
      @tours = Tour.group_admin_order_by_review_state(current_user.accounts).paginate(:page => params[:page], :per_page =>20)
      $tour_status_params=[3,4]
    elsif params[:search] && !params[:search].empty?
      $tour_status_params_admin=[-2,-1,0,1,2,3,4,5,6,7,8,9,10]
      @tours = Tour.group_admin_search_by_keyword(params[:search],current_user.accounts).paginate(:page => params[:page], :per_page =>20)
      flash.now[:flash_msg] = "Search Result for #{params[:search]}"
    elsif params[:orderby]=="title"
      @tours = Tour.group_admin_sort_by_title($tour_status_params,params[:by],current_user.accounts).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="status" 
      @tours = Tour.group_admin_sort_by_status($tour_status_params,params[:by],current_user.accounts).paginate(:page => params[:page], :per_page =>20)
    elsif  params[:orderby]=="rating"
      @tours = Tour.group_admin_sort_by_rating($tour_status_params,params[:by],current_user.accounts).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="ownername"
      @tours = Tour.group_admin_sort_by_owner_name_link($tour_status_params,params[:by],current_user.accounts).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="stops"
      @tours = Tour.group_admin_sort_by_stops_link($tour_status_params,params[:by],current_user.accounts).paginate(:page => params[:page], :per_page =>20)
    else
      $tour_status_params=[-2,-1,0,1,2,3,4,5,6,7,8,9,10]
      flash.now[:flash_error_msg] = "Enter a keyword to search" if params[:search] && params[:search].empty?
      @tours = Tour.group_admin_order_by_review(current_user.accounts).paginate(:page => params[:page], :per_page =>20)
    end
  end 
	
  def users
    assign_sessions(nil, 1, nil, nil)
    @user = current_user
    @user_accounts_ids= @user.account_ids
    if params[:user] == "Username"
      @users = User.sort_users_by_username.paginate(:page => params[:page], :per_page =>20)
    elsif params[:user] == "Email"
      @users = User.sort_users_by_email.paginate(:page => params[:page], :per_page =>20)
    elsif params[:user]=="No. of Tours"
      @users = User.sort_users_by_no_of_tours.paginate(:page => params[:page], :per_page =>20)
    elsif params[:user_search] && !params[:user_search].empty?
      @users = User.group_admin_user_search_by_keyword(params[:user_search],current_user.accounts).paginate(:page => params[:page], :per_page =>20)
      flash.now[:flash_msg] = "Search Result for #{params[:user_search]}"
    elsif params[:orderby]=="username" || params[:orderby]=="email" || params[:orderby]=="created_at" || params[:orderby]=="status"
      @users=User.group_admin_sort_username(params[:by],current_user.accounts).paginate(:page=>params[:page], :per_page=>20)
    elsif params[:orderby]="no_of_tours"
      @users = User.group_admin_sort_users_by_no_of_tours_link(params[:by],current_user.accounts).paginate(:page => params[:page], :per_page =>20)
    else
      flash.now[:flash_error_msg] = "Enter a keyword to search" if params[:user_search] && params[:user_search].empty?
      @users = User.sort_users_by_username.paginate(:page => params[:page], :per_page =>20)
    end
  end
 
  def accounts
    assign_sessions(nil, nil, 1, nil)
    @user = current_user
    @user_accounts_ids=[]
    @user_accounts=@user.user_accounts.all(:conditions=>["user_type='admin'"])
    @user_accounts.collect{|x| @user_accounts_ids<<x.account_id}
    #~ @groups = Account.all.paginate(:page => params[:page], :per_page =>20)
    if params[:account_search]  && !params[:account_search].empty?
      @groups = Account.group_admin_group_search_by_keyword(params[:account_search],@user_accounts_ids).paginate(:page => params[:page], :per_page =>20)
      flash.now[:flash_msg] = "Search Result for #{params[:account_search]}"
    elsif params[:orderby]=="groupname"
      @groups = Account.group_admin_sort_group_by_name(params[:by],@user_accounts_ids).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="description"
      @groups = Account.group_admin_sort_group_by_description(params[:by],@user_accounts_ids).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="no_of_users"
      @groups = Account.group_admin_sort_group_by_no_of_users(params[:by],@user_accounts_ids).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="status"
      @groups = Account.group_admin_sort_group_by_status(params[:by],@user_accounts_ids).paginate(:page => params[:page], :per_page =>20)
    else
      flash.now[:flash_error_msg] = "Enter a keyword to search" if params[:account_search] && params[:account_search].empty?
      @groups = Account.find(@user_accounts_ids).paginate(:page => params[:page], :per_page =>20)
    end
  end

  def change_account_status
    if !params[:perform_action].nil? && params[:perform_action] == "change_account_status" && !params[:id].nil?
      @groups=Account.find(params[:id])
      @groups.status ==1 ? @groups.update_attribute(:status,0) : @groups.update_attribute(:status,1)
    end
    redirect_to :action=>"accounts"
  end

  def list_users_to_account
    @account=Account.find(params[:account_id])
    if params[:orderby] == "username"
      @users = User.sort_list_users_to_account_by_username(@account.all_users,params[:by]).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby] == "email"
      @users = User.sort_list_users_to_account_by_email(@account.all_users,params[:by]).paginate(:page => params[:page], :per_page =>20)
    elsif params[:orderby]=="no_of_tours"
      @users = User.sort_list_users_to_account_by_no_of_tours(@account.all_users,params[:by]).paginate(:page => params[:page], :per_page =>20)
    else
      @users =@account.all_users.paginate(:page => params[:page], :per_page =>20)
    end
  end 
  
  def add_users_to_account
    @account_id = params[:account_id]
    @account =Account.find(params[:account_id])
    @users = User.all(:conditions=>['users.username like ?', 'A%'])
    return unless request.post?
    @user= User.find(params[:user_id])
    @user.accounts << @account
    @user_id = @user.id
    render :update do |page|
      page.replace_html "image_change_#{@user.id}", :partial => "/admin/change_button", :locals =>{:status => 'delete'}, :object => @user_id
    end 
  end
	  
  def remove_users_to_account
    @user_id = params[:user_id]
    return unless request.post?
    @user_account=UserAccount.find_by_user_id_and_account_id(params[:user_id], params[:account_id ])
    @user_account.destroy if @user_account
    render :update do |page|
      page.replace_html "image_change_#{@user_id}", :partial => "/admin/change_button", :locals =>{:status => 'add'}, :object => @user_id
    end 
  end

  def change_status
    if !params[:perform_action].nil? && params[:perform_action] == "change_status" && !params[:id].nil?
      @user=User.find(params[:id])
      @user.status ==1 ? @user.update_attribute(:status,0) : @user.update_attribute(:status,1)
    end
    redirect_to :action=>"users"
  end

  def receipts
    @user = current_user
    assign_sessions(nil, nil, nil, nil, nil, 1)
    @tour_ids=[]
    @user_accounts_ids= @user.account_ids
    @group_users=UserAccount.find(:all, :conditions=>['account_id in (?)',@user_accounts_ids])
    @group_users.each {|x| @tour_ids << x.user.tour_ids}
    @tour_ids = @tour_ids.flatten.uniq
    @receipts = Receipt.find(:all, :conditions=>['tour_id in (?)',@tour_ids]).paginate(:page => params[:page], :per_page =>20)
  end
	
end
