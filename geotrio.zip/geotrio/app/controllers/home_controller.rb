class HomeController < ApplicationController
   protect_from_forgery :except=>["search_tour"]
 before_filter :login_required, :only => ['help']
 before_filter :require_ssl, :except =>["photo_search","search_result","overview_audio_search","stop_audio_search"]
 before_filter :check_login, :except => ['help','index','about','contact','news','jobs','search_result','photo_search','search_tour','search_tour_details','overview_audio_search','send_mail_to_friend','stop_audio_search']
 layout :change_layout

  
def change_layout
    if action_name=="help"
      "home"
    else
      "new"
    end
  end
  
	def index
    #~ @tours_ratings=Tour.find(:all,:conditions=>["status = 10"],:order=>"number_of_ratings  DESC").first(5)
    @tours_ratings=Tour.find(:all,:conditions=>["status = 10"])
     @tours_downloads=Tour.find(:all,:conditions=>["status = 10"],:order=>"number_of_downloads  DESC").first(5)
    @toursearch=TourSearch.find(:all).map{|x| [x.id,x.latitude,x.longitude]}*"_"
    end

  def contact_mail
    if simple_captcha_valid?  
      UserMailer.deliver_feedback(params[:name], params[:email], params[:subject], params[:content])
      flash[:contact_notice] ="Mail sent Successfully!"
      redirect_to contact_path
    else
      flash.now[:contact_error] ="Invalid Code! "
      render :action => "contact"
    end 
  end

  def help
    
  end
  
  def search_result
    #~ puts params.inspect
    if params[:data]
    tour_ids,distance_arr = [],[]
    tour_distance_arr=params[:data].split(",")
    tour_distance_arr && tour_distance_arr.each_with_index do |val, index|
      tour_ids << val.to_i if index.odd?
      distance_arr << val if index.even? 
    end
    @tour_dist_hash={}
    @tour_dist_hash_new = []
    tour_ids && tour_ids.each_with_index do |t_id, ind|
      distance_arr && distance_arr.each_with_index do |dist, index|
        if ind==index && dist.to_f <= 100
          @tour_dist_hash["#{t_id}"] = dist.to_f
        end
      end
    end
    @tour_dist_hash=@tour_dist_hash.sort {|a,b| a[1]<=>b[1]}
    @tour=[]
    @tour_dist_hash.flatten!
    @tour_dist_hash && @tour_dist_hash.each_with_index do |val,ind|
        @tour << Tour.find(val) if ind.even?
         @tour_dist_hash_new <<  val if  ind.odd?
       end
       
    @result=@tour
    #~ render :partial => 'new_search_result', :collection=>@result
    #~ search_result
    render :update do |page|
      page.replace_html "search_result", :partial => "/home/new_search_result"
    end 
    else
     render :nothing => true
    end 
    #~ puts tour_ids.inspect
    #~ puts tour_ids.count.inspect
    #~ puts distance_arr.inspect
    #~ puts distance_arr.count.inspect
    #~ @result1=Tour.find(:all,:conditions=>['title LIKE ? OR description LIKE ? ',"%#{params[:search_text]}%","%#{params[:search_text]}%"])
    #~ @count=@result1.size
    #~ @result=Tour.find(:all,:conditions=>['title LIKE ?',"%#{params[:search_text]}%"]).paginate(:page => params[:page], :per_page =>5)
  end
   def photo_search
     @tour = Tour.find(params[:tour_id].to_i)   if Tour.exists?(params[:tour_id].to_i)
     #~ if !@tour.nil? && (@tour.user_id==current_user.id || session[:admin_panel] ==1 || session[:admin_panel] == 2)
     if !@tour.nil? 
      if @tour.image
        file=   "#{@tour.image.public_filename(:iphone_img)}"
        send_file file, :type => 'image/jpeg', :disposition => 'inline'
      else
        redirect_to tour_show_path(current_user_name, @tour.id)
        flash[:upload_error]="No Image for this Tour"
      end
    else
      flash[:flash_error_msg]="Permission Denied!"
      redirect_to_index
    end
  end

def search_tour
   @toursearch=TourSearch.find(:all).map{|x| [x.id,x.latitude,x.longitude]}*"_"
    if TourSearch.exists?(params[:tour_id])
  @tour_search_all=TourSearch.find(params[:tour_id]) 
  @tour_search_id = @tour_search_all.id
  @tour=Tour.find(@tour_search_id ) if Tour.exists?(@tour_search_id)
end

 @lat_array=[]
    @long_array=[]
    if @tour
 			@tour_id = @tour.id
			@stops = @tour.get_all_stops
      @tracks = @tour.tour_tracks
			@rating = @tour.rating.round
      @tracks_stops=[]
      is_stop=[]
      #~ @tour.tour_tracks.collect{|x| @lat_array<<x.latitude}
      #~ @tour.tour_tracks.collect{|x| @long_array<<x.longitude}
      @tracks.each do |x|
        @tracks_stops <<x.latitude.to_s+"_"<<x.longitude.to_s+"_"<<x.is_stop.to_s+"_"
        @lat_array<<x.latitude
        @long_array<<x.longitude
        is_stop<<x.is_stop
      end
      @stop_count=is_stop.count(1)
    end
		if !@tour
      redirect_to_index 
    end

end

def search_tour_details
    @toursearch=TourSearch.find(:all).map{|x| [x.id,x.latitude,x.longitude]}*"_"
    @tour = Tour.find_by_id(params[:tour_id])
    @lat_array=[]
    @long_array=[]
    if @tour
 			@tour_id = @tour.id
			@stops = @tour.get_all_stops
      @tracks = @tour.tour_tracks
			@rating = @tour.rating.round
      @tracks_stops=[]
      is_stop=[]
      #~ @tour.tour_tracks.collect{|x| @lat_array<<x.latitude}
      #~ @tour.tour_tracks.collect{|x| @long_array<<x.longitude}
      @tracks.each do |x|
        @tracks_stops <<x.latitude.to_s+"_"<<x.longitude.to_s+"_"<<x.is_stop.to_s+"_"
        @lat_array<<x.latitude
        @long_array<<x.longitude
        is_stop<<x.is_stop
      end
      @stop_count=is_stop.count(1)
    end
		if !@tour
      redirect_to_index 
    end
  end
  
  
    def overview_audio_search
    if params[:tour_id] && Tour.exists?(params[:tour_id])
        @tour=Tour.find(params[:tour_id])
      if @tour
        @audio=@tour.audio
        if !@audio.nil?
                send_file "#{@audio.public_filename}", :type=>'audio/mpeg' ,:disposition=>'inline'
        else
          flash[:upload_error]="No Overview Audio for this Tour."
          redirect_to tour_show_path(current_user_name, @tour.id)
        end
      else
        flash[:flash_error_msg]="Permission Denied."
        redirect_to root_path
      end
    else
      flash[:flash_error_msg]="No such Tour found."
      redirect_to root_path
    end
  end
  
  
  def send_mail_to_friend
  @tour=Tour.find params[:tour_id]
  UserMailer.deliver_send_mail_to_friend(params[:email][:from],params[:email][:to], "#{params[:email][:name]} would like to share his Geotrio tour with you",params[:email][:message],params[:email][:name], @tour)
  flash[:sucess_mail_message] = "An email was sent to your friend(s)"
  redirect_to search_tour_path(:tour_id=>params[:tour_id])
  end



      def stop_audio_search

          if params[:tour_id] && params[:stop_seq] && Tour.exists?(params[:tour_id]) 
              @tour=Tour.find(params[:tour_id])
              
                if params[:stop_seq].to_i<@tour.stops.size
                  @tours_stops=@tour.tours_stops
                  
                  @tours_stops && @tours_stops.each do |tours_stop|
                    if tours_stop.sequence==params[:stop_seq].to_i
                      @stop=tours_stop.stop
                      p @stop.inspect
                    end
                  end
                   if @audio=@stop.audio
                     
                    if !@audio.nil?
                    send_file "#{@audio.public_filename}", :type=>'audio/mpeg' ,:disposition=>'inline'
                    end
                  else
                  flash[:upload_error] = "No Audio for this Stop!"
                  #~ redirect_to ('/play')
                  end
                end
          end
      end



end








