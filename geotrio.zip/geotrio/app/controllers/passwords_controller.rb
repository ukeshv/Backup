class PasswordsController < ApplicationController
  before_filter :check_login, :except => ['edit','change_password']
  layout "new"
  def create
    if params[:email] =~ /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i
			@user = User.find_by_email(params[:email])
			if @user
				@user.send_reset_link(@user)
        redirect_to login_path
				flash[:logout_notice] = "Reset link has been sent to " + params[:email] +"."
			else
				flash.now[:forget] = "This Email is not registerd!"
				render :action => 'new'
			end        
    else
      if params[:email].empty?
        flash.now[:forget] = "Email can't be blank"
      else
        flash.now[:forget] = "Invalid Email"
      end
      render :action => 'new'
    end
  end
  
  def edit
    @user = User.find_by_password_reset_code(params[:reset_code])
    if !@user
      flash.now[:login_error] = "Invalid Reset Code!"
      redirect_to login_path
    end
    if current_user
      redirect_to user_edit_path(current_user_name)
    end 
  end
  
   def update
    @user = User.find(params[:id])
    unless params[:user][:password].empty?
      if params[:user][:password] == params[:user][:password_confirmation]
          if ((params[:user][:password] == params[:user][:password_confirmation]) && 
                              !params[:user][:password_confirmation].blank?)
          @user.password_confirmation = params[:user][:password_confirmation]
          @user.password = params[:user][:password]
					@user.save false
          @user.update_attribute("password_reset_code","NULL")
          flash[:logout_notice] = "Password has been reset successfully."
          redirect_to login_path
          else
           flash.now[:reset_error] = "#{@user.errors['password']} #{@user.errors['password_confirmation']}"
          render :action=>"edit"
          end
      else
        flash.now[:reset_error] = "Password and Confirm Password does not match."
        render :action=>"edit"
         end    
    else
      flash.now[:empty_error] = "can not be blank"
      render :action=>"edit"
      end
  end
  
  
  def change_password
  if params[:user_id]
  @user = User.find(params[:user_id])
  else
  @user=current_user  
end
  if !params[:password].nil?
    if ((params[:password] == params[:password_confirmation]) && !params[:password_confirmation].blank?)
         @user.password_confirmation = params[:password_confirmation]
         @user.password = params[:password]
         if @user.save false
          flash[:notice] = "Password successfully updated"
          redirect_to user_edit_path(:user_name=>@user.username)
         else
          flash[:alert] = "Password not changed"
          render :action=>"change_password"
         end
      elsif ((params[:password].blank?) || (params[:password_confirmation].blank?))
         flash[:alert] = "New Password blank"
         render :action=>"change_password"
      else
         flash[:alert] = "New Password mismatch"
         render :action=>"change_password"
      end
   
  end
  end 
end
