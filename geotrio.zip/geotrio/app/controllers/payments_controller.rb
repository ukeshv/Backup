require 'rubygems'
require 'net/http'
require 'net/https'
require 'uri'
class PaymentsController < ApplicationController
  layout "home"

  def index
    uri = URI.parse('https://api-3t.sandbox.paypal.com/nvp')
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true
    http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    request = Net::HTTP::Post.new(uri.request_uri)
    request.set_form_data({'METHOD'=>'SetAuthFlowParam','USER'=>'udhaya_1273747227_biz_api1.railsfactory.org', 'PWD'=>'1273747234','SIGNATURE'=>'AQYxcAefY8hOktiaY0MAZu01QVx4ATaEZjRn.ESWzWRZ-Wv6MhzZVIl-','VERSION'=>'60.0','RETURNURL'=>'http://localhost:3000/payments/new','CANCELURL'=>'http://localhost:3000/payments/new','LOGOUTURL'=>'http://apipay.net/easyapi/index.php?sid=paypal&id=nvp_adpay&ac=getauthdetails','SERVICENAME1'=>'Name','SERVICEDEFREQ1'=>'Required','SERVICENAME2'=>'Email','SERVICEDEFREQ2'=>'Required'})
    response, body = http.request(request)
    redirect_to "https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_account-authenticate-login&token=#{URI.decode(body.split(/&/).first.split(/=/).last)}"
  end
  
  def new
    uri = URI.parse('https://api-3t.sandbox.paypal.com/nvp')
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true
    http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    request = Net::HTTP::Post.new(uri.request_uri)
    request.set_form_data({'METHOD'=>'GetAuthDetails','USER'=>'udhaya_1273747227_biz_api1.railsfactory.org', 'PWD'=>'1273747234','SIGNATURE'=>'AQYxcAefY8hOktiaY0MAZu01QVx4ATaEZjRn.ESWzWRZ-Wv6MhzZVIl-','VERSION'=>'60.0', 'token'=>params[:token]})
    response, body = http.request(request)
  end

end
