class SessionsController < ApplicationController
  before_filter :require_ssl
  before_filter :check_login, :except=>['destroy']
  layout "new", :only =>["new", "create"]
  
  def new
  end 
  
def create
self.current_user = User.authenticate(params[:username], params[:password])
if params[:search_value] == "true"
  redirect_to  create_tour_tours_path
else
    if logged_in?
      if params[:remember_me] == "on"
        current_user.remember_me unless current_user.remember_token?
        cookies[:auth_token] = { :value => self.current_user.remember_token , :expires => self.current_user.remember_token_expires_at }
      end
      if current_user.user_type == 0
        session[:admin] = 1
      elsif current_user.user_type == 2
        session[:admin] = 2
      end

      flash[:login_notice] = "Logged in successfully"
      redirect_to tours_index_path(:user_name=>current_user.username)
    else
      flash.now[:login_error] = "Invalid Login/Password!"
      render :action => 'new'
    end
    end
  end

  def destroy
    logout_killing_session!
    session[:admin] = nil
    session[:admin_panel] = nil
    assign_sessions(nil, nil, nil, nil, nil, nil)
    session[:notifications] = nil
    flash[:logout_notice] = "You have been logged out."
    redirect_back_or_default(login_path)
  end
end
