class StatisticsController < ApplicationController
  protect_from_forgery :except=>["paypal_transaction"]
  include PaypalGatewaySystem
  layout "home"
  before_filter :login_required
  require 'calendar_date_select'
  def index
    @user=current_user
    @tours_live=current_user.tours.all
    @total=0.0
    @total_tips=0.0
    @tours_receipt=[]
    @live_tour_ids=[]
    @unpaid_receipt_ids=[]
    @unpaid_tours=[]
    if @tours_live && !@tours_live.empty?
      @tours_live.each do |t|
        @live_tour_ids << t.id
        t.receipts.each do |rec|
          @tours_receipt << rec.paypal_receipt.receipt_id if rec.paypal_receipt
        end
      end
      if !@tours_receipt.empty?
        @unpaid_receipts=Receipt.find(:all,:conditions=>['id not in (?)',@tours_receipt.uniq.flatten])
      else
        @unpaid_receipts=Receipt.find_all_by_tour_id(@live_tour_ids)
      end
      @unpaid_receipts.each do |upr|
        @unpaid_receipt_ids << upr.id
      end
      @rec=Receipt.find(@unpaid_receipt_ids.uniq.flatten)
      @rec.collect{|rec| @unpaid_tours << rec.tour_id}
      @tours=current_user.tours.find(:all, :conditions=>['id in (?) and category!=9',@unpaid_tours.uniq.flatten])
      #~ @tours=current_user.tours.find_all_by_id_and_status(@unpaid_tours.uniq.flatten,10)
    end
    @trans_history=PaypalTransaction.find_all_by_user_id(current_user.id).reverse.paginate(:page => params[:page], :per_page =>20)
    @total_money_earned = PaypalTransaction.find_all_by_user_id(current_user.id)
  end

  def paypal_transaction
    @tours_receipt_ids=[]
    @live_tour_ids=[]
    @email_transfer = gateway.transfer params[:total].to_f * 100, current_user.paypal_email, :subject => "Geotrio Cash", :note => "You are Credited with $#{params[:total]} for your Tours downloaded by Users on #{Time.now}"
    if @email_transfer.success?
      @tours=current_user.tours.find_all_by_status(10)
      @tours.each do |t|
        @live_tour_ids << t.id
        t.receipts.each do |rec|
          @tours_receipt_ids << rec.paypal_receipt.receipt_id if rec.paypal_receipt
        end
      end
      if !@tours_receipt_ids.empty?
        @pay_rec=Receipt.find(:all,:conditions=>['id not in (?) and tour_id in (?)',@tours_receipt_ids.uniq.flatten,current_user.tour_ids])
      else
        @pay_rec=Receipt.find_all_by_tour_id(@live_tour_ids)
      end
      @pay_tran=PaypalTransaction.create(:user_id=>current_user.id,:paid_to=>current_user.paypal_email,:transaction_id=>@email_transfer.params["correlation_id"],:amount_transferred=>params[:total],:status=>1, :payment_date=>@email_transfer.params["timestamp"].to_time.localtime,:paypal_token=>@email_transfer)
      @pay_rec.each do |rec|
        PaypalReceipt.create(:paypal_transaction_id=>@pay_tran.id, :receipt_id=>rec.id)
      end
      flash[:success]="Transaction completed Successfully, Check your PayPal account"
    else
      PaypalTransaction.create(:user_id=>current_user.id,:paid_to=>current_user.paypal_email,:transaction_id=>@email_transfer.params["correlation_id"],:amount_transferred=>params[:total],:status=>0, :payment_date=>@email_transfer.params["timestamp"].to_time.localtime,:paypal_token=>@email_transfer)
      flash[:failure]="Transaction failed due to InCorrect PayPal Email Id"
    end
    redirect_to statistics_path
  end

  def show_transaction_history
    @trans_history=PaypalTransaction.find_all_by_user_id(current_user.id).reverse
  end

  def geotrio_payment_history
    @trans_history=PaypalTransaction.find_all_by_user_id(current_user.id).reverse
    respond_to do |format|
      format.pdf { send_data render_to_pdf({ :action => 'geotrio_payment_history.pdf.erb', :layout => 'pdf_report' }) }
    end
  end
  
  def tours_list
    @user=current_user
    @tours=current_user.tours.find(:all,:conditions=>"status=10",:order=>'title').paginate(:page => params[:page], :per_page =>20)
  end
  
  def tour_stats
    @tour=Tour.find(params[:tour_id])
     if @tour.category==2
    @user_campus_tours=@tour.user_campus_tours
    @campus_leads=[]
      @user_campus_tours && @user_campus_tours.each do |u_c_t|
        @campus_leads << u_c_t.campus_lead
      end
    end
    @rating = @tour.rating.round
    @receipts=@tour.receipts
    @amount=0.0
    @amount_today=0.0
    if request.xhr? && !params[:start_date].blank? && !params[:end_date].blank?
      @dated_total=0
      @start_date=params[:start_date].to_date
      @end_date=params[:end_date].to_date
      @dated_receipts=@tour.receipts.all(:conditions=>['DATE(created_at)>=? and DATE(created_at)<=? and tour_id=?',@start_date,@end_date,@tour.id])
      @dated_receipts && @dated_receipts.each do |dated_rec|
        @dated_total+=dated_rec.amount
      end
      render :update do |page|
	page.replace_html "displayTotal", "$#{@dated_total}"
	page.replace_html "date_range", "Money earned Between #{@start_date} to #{@end_date}"
        page.replace_html "dyn", :partial => 'chart'
      end
    end
    @receipts && @receipts.each do |rec|
       @amount+=rec.amount
     end
     @receipts_today=@tour.receipts.all(:conditions=>['DATE(created_at)=? and tour_id=?',Date.current,@tour.id])
     @receipts_today && @receipts_today.each do |rec_today|
        @amount_today+=rec_today.amount
      end
      @graph = open_flash_chart_object(600,400, "/statistics/show_graph_static/#{@tour.id}",true)
    end
    
    def show_graph_static
      @tour=Tour.find(params[:id])
      @receipts=@tour.receipts
       bar = BarOutline.new(50, '#9933CC', '#8010A0')
      bar.key("Profits", 10)
      #~ bar.key("Page VIEWS", 10)
      for i in 1..12 do
        tot=0.0
        @receipts&&@receipts.each do |rec|
          if rec.created_at.month==i && rec.created_at.year==Time.current.year
          tot+=rec.amount.to_f
        end
      end
      bar.add_data_tip(tot,"$ #{tot}")
      #~ bar.data << tot
    end
      g = Graph.new
      g.title("#{@tour.title} Statistics for year #{Time.current.year}", "{font-size: 15px;}")
      g.data_sets << bar
      g.set_tool_tip('#x_label# <br>#tip#')
      g.set_x_labels(%w(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec))
      g.set_x_label_style(10, '#9933CC', 0,1)
      g.set_x_axis_steps(2)
      g.set_x_legend("Months", 12, "#736AFF")
      g.set_y_max(bar.data.max+10)
      g.set_y_label_steps(10)
      g.set_y_legend("Profits", 12, "#736AFF")
      render :text => g.render
    end
    
    def show_graph_dynamic
	    @params_arr=params[:id].split("_")
	    @start_date=@params_arr[1].to_date
	    @end_date=@params_arr[2].to_date
      @tour=Tour.find(@params_arr[0])
      @receipts=@tour.receipts.all(:conditions=>['DATE(created_at)>=? and DATE(created_at)<=?',@start_date,@end_date], :order=>['created_at'])
       bar = BarOutline.new(50, '#9933CC', '#8010A0')
      bar.key("Profits", 10)
      #~ bar.key("Page VIEWS", 10)
      x_array=[]
      if !@receipts.empty?
	      @start_date.upto(@end_date) do |date|
			x_array<<date.strftime("%d %b %Y")
			@tot=0.0
			@receipts && @receipts.each_with_index do |rec,ind|
				if rec.created_at.to_date==date
					@tot+=rec.amount.to_f
				end
			end
      bar.add_data_tip(@tot,"$ #{@tot}")
			#~ bar.data<<@tot
		end
	else
		@start_date.upto(@end_date) do |date|
			x_array<<date.strftime("%d %b %Y")
      bar.add_data_tip(0,"$ 0.0")
			#~ bar.data<<0
		end
        end
      #~ if !@receipts.empty?
	#~ @tot=0      
      #~ @receipts && @receipts.each_with_index do |rec,ind|
	#~ if (ind==0&&@receipts.length>1&&@receipts[ind+1].created_at.to_date!=rec.created_at.to_date) || @receipts[ind-1].created_at.to_date!=rec.created_at.to_date || ind==@receipts.length-1	
	#~ if ind==@receipts.length-1 || @receipts.length<1 || (ind!=@receipts.length-1 && @receipts[ind+1].created_at.to_date!=rec.created_at.to_date)
	#~ x_array << rec.created_at.to_date.to_s
	#~ @tot+=rec.amount
	#~ bar.data << @tot
	#~ @tot=0
	#~ else
	#~ @tot+=rec.amount
	#~ end
      #~ end
      #~ else
	     #~ bar.data=[]
      #~ end
      g = Graph.new
      g.title("#{@tour.title} Statistics between #{@start_date.to_date.strftime("%d %b %Y")} and #{@end_date.to_date.strftime("%d %b %Y")}", "{font-size: 15px;}")
      g.data_sets << bar
      g.set_tool_tip('#x_label# <br>#tip#')
      g.set_x_labels(x_array)
      g.set_x_label_style(10, '#9933CC', 2,(x_array.length/10))
      g.set_x_axis_steps(2)
      g.set_x_legend("Months", 12, "#736AFF")
      g.set_y_max(10)
	if !bar.data.empty?
	g.set_y_max(bar.data.max+10)
	end
      g.set_y_label_steps(10)
      g.set_y_legend("Profits", 12, "#736AFF")
      render :text => g.render
    end
    
    def show_campus_for_selected_date_range
      @tour=Tour.find(params[:tour_id])
      @start_date=params[:start_date].to_date
      @end_date=params[:end_date].to_date
      @user_campus_tours=@tour.user_campus_tours.all(:conditions=>['DATE(created_at)>=? and DATE(created_at)<=?',@start_date, @end_date])
      @campus_leads=[]
      @user_campus_tours && @user_campus_tours.each do |u_c_t|
        @campus_leads << u_c_t.campus_lead
      end
      render :update do |page|
        page.replace_html "show_campus_lead", :partial=>"show_campus_lead_for_date_range"
      end
    end
    
end
