require "rubygems"
require "net/sftp"
require "mp3info"
class StopsController < ApplicationController
  protect_from_forgery :except=>["save_image","create"]
  before_filter :require_ssl
  before_filter :authenticate_image_stop, :only => ["stop_photo","stop_photo_jpg"]
	before_filter :login_required
	layout :change_layout
  include KmlGenerator

  def show
	  @tour = Tour.find_by_id(params[:tour_id])
    if @tour && (@tour.check_if_current_user_tour(current_user) || session[:admin] == 1 || session[:admin] == 2 )
      @stop = @tour.get_the_stop(params[:sequence_id]) 
      @stops_count=@tour.stops.count
      @tour_id = @tour.get_id
      @tour_stop_last=@tour.stops.last
      if @stop
      @tracks = @tour.tour_tracks
      @tracks_stops=[]
      is_stop=[]
      @tracks.each do |x|
        @tracks_stops <<x.latitude.to_s+"_"<<x.longitude.to_s+"_"<<x.is_stop.to_s+"_"
        is_stop<<x.is_stop
      end
      @stop_count=is_stop.count(1)
        if @stop.audio
          @file_name= @stop.get_file_name
          @public_filename = @stop.get_public_file_name
        end
        @stop_images= @stop.get_all_images
      else
        flash[:upload_error]= "No such stop !"
        redirect_to tour_show_path(current_user_name,@tour_id)
      end
    else
      redirect_to root_path
    end
	end
	
	def create
		@stop = Stop.find_by_id(params[:stop_id])
    @stop_images= @stop.get_all_images
    @tour_id = params[:tour_id]
    @tour = Tour.find_by_id(@tour_id)
    @file_name= @stop.get_file_name
    @public_filename = @stop.get_public_file_name
		@audio = Audio.new(params[:attachment])
		if @audio.valid?
      @audio.is_audio = 1
      @tour.status = 1
      @tour.save
      if @stop.audio
        @old_audio=@stop.audio
        @file_path_old=@stop.audio.public_filename.split('/')
        @stop_num=@file_path_old.pop
        @file_path=@file_path_old.join('/')
         File.rename("#{@stop.audio.public_filename}","#{@file_path}/old_#{@stop_num}")
      end
      @stop.audio = @audio
			if @stop.save && get_audio_file_duration<=240 || session[:admin_panel] == 1
        if !defined?(@file_path).nil?
           File.delete("#{@file_path}/old_#{@stop_num}")
         end
        session[:alert_box] = 1
        @file_name= @stop.get_file_name
        History.create_history(current_user.id, "#{@stop.name} - Stop Audio Uploaded", @tour.id)
        @tour.update_attribute('updated_at',Time.current)
        flash[:upload_msg] = "File uploaded successfully!"
        seq = @stop.stop_sequence(@tour_id)
				redirect_to stops_show_path(current_user_name, @tour_id, seq)
			else
        if get_audio_file_duration>240
          @stop.audio=nil
           if !defined?(@file_path).nil?
             #~ File.delete("#{@file_path}/overview.mp3")
             File.rename("#{@file_path}/old_#{@stop_num}","#{@file_path}/#{@stop_num}")  
            @stop.audio=@old_audio.clone
            @stop.audio.save
          end
          flash.now[:upload_error] = "Audio File duration should be less then 4 Minutes."
          else
          flash.now[:upload_error] = "Invalid File format!"
        end
        render :action => "show"
			end
		else
	    if params[:attachment].nil?
			  flash.now[:upload_error] = "Please attach a Audio file to Upload"
      else
        flash.now[:upload_error] = "Please attach a valid  audio file (mp3 file under 4 minute of length)"
      end
			render :action => "show"
		end
	end

  def save_image
   	@stop = Stop.find_by_id(params[:stop_id])
    @tour_id = params[:tour_id]
    @tour = Tour.find_by_id(@tour_id)
    @stop_images= @stop.get_all_images
    @image = Image.new(params[:image])
	  @img = 1 if @image.valid?
		if (@img == 1 && @stop_images.size<10)
      @stop.images << @image
			if @stop.save
        session[:alert_box] = 1
        @tour.status = 1
        @tour.save
        @stop_images= @stop.get_all_images
        seq = @stop.stop_sequence(@tour_id)
        @tour.update_attribute('updated_at',Time.current)
        flash[:upload_msg] = "File uploaded successfully!"
        History.create_history(current_user.id, "#{@stop.name} - Stop Image Uploaded", @tour.id)
				redirect_to stops_show_path(current_user_name, @tour_id, seq)
			else
				flash.now[:upload_error] = "Invalid File format!"
        render :action => "show"
			end
		else
	    if params[:image].nil?
			  flash.now[:upload_error] = "Please attach a Image to Upload"
     elsif  @image.errors.first[0] != "size"
    		flash.now[:upload_error] = "Invalid Image Format"
     else 
    		flash.now[:upload_error] = "Can not upload Image greater than 2MB"
      end
			flash.now[:upload_error] = "Can upload only 10 images for a stop!" if (@stop_images.size ==10 && @img == 1)
			render :action => "show"
		end
  end

  def delete_attachment
    @stop = Stop.find_by_id(params[:stop_id])
    @tour = Tour.find_by_id(params[:tour_id])
    if @stop && @tour
      if @stop.destroy_audio(current_user, @tour, session[:admin])
        History.create_history(current_user.id, "#{@stop.name} - Stop Audio Deleted", @tour.id)
        flash[:upload_msg] = "Audio deleted successfully!"
      else
        flash[:upload_error] = "Permission Denied!"
      end
    else
      flash[:upload_error] = "Permission Denied!"
    end
    seq = @stop.stop_sequence(@tour.id)
    redirect_to stops_show_path(current_user_name, params[:tour_id], seq)
  end

  def delete_image
    @stop = Stop.find_by_id(params[:stop_id])
    @tour = Tour.find_by_id(params[:tour_id])
    @image = Image.find_by_id(params[:id])
    if @stop && @tour && @image
      if @stop.destroy_image(@image, current_user, @tour, session[:admin])
        History.create_history(current_user.id, "#{@stop.name} - Stop Image Deleted", @tour.id)
        flash[:upload_msg] = "Image deleted successfully!"
      else
        flash[:upload_error] = "Permission Denied!"
      end
    else
      flash[:upload_error] = "Permission Denied!"
    end
    seq = @stop.stop_sequence(@tour.id)
    redirect_to stops_show_path(current_user_name, params[:tour_id], seq)
  end
  
    def save_recorded_stop_audio
      @tour=Tour.find(params[:tour_id].to_i) if Tour.exists?(params[:tour_id].to_i)
      @stop=Stop.find(params[:stop_id].to_i) if Stop.exists?(params[:stop_id].to_i)
      seq = @stop.stop_sequence(@tour.id)
      file_present=@tour.check_for_existence(seq)
      if file_present==false
        flash[:upload_error] = "Please Record an Audio to Save"
      else
      session[:stop_alert_box]=1
      @stop.take_recorded_audio_from_server(@tour.id,seq)
      @tour.update_attribute('updated_at',Time.current)
      @tour.update_attribute('status',1)
       History.create_history(current_user.id, "#{@stop.name} - Stop Audio Recorded", @tour.id)
      flash[:upload_msg] = "Audio Recorded successfully!"
     end
     redirect_to stops_show_path(current_user_name, @tour.id, seq)
  end

  def destroy
    @stop = Stop.find_by_id(params[:id])
    @tour = Tour.find_by_id(params[:tour_id])
     File.delete("#{RAILS_ROOT}/public/kmls/#{@tour.id}_#{@tour.stops.count}.kml") if  File.exists?("#{RAILS_ROOT}/public/kmls/#{@tour.id}_#{@tour.stops.count}.kml")
      @tour_id = @tour.get_id
    @stop.change_status_for_tour_tracks_stop
    @stop.delete_tours_stops(@tour_id)
    seq = @stop.stop_sequence(@tour_id)
    @tour.change_all_sequence(@stop.id)
    	@stops = @tour.stops
        @tracks = @tour.tour_tracks
        @points = @tour.get_all_points 
       	kml_generated = generate_kml(@tracks, @points)
				f = File.new("public/kmls/#{@tour.id}_#{@stops.count}.kml", "w")
				f.write(kml_generated)
				f.close
    History.create_history(current_user.id, "#{@stop.name} - Stop Deleted", @tour.id)
    flash[:flash_msg] = "Stop deleted successfully!"
    redirect_to tour_show_stops_path(current_user_name, @tour_id)
  end

  def stop_photo
    @stop_values=params[:sequence].split(/_/)
    @tour=Tour.find(params[:tour_id])
    @stops=@tour.stops
    if @stops && !@stops.empty?
      @stop_status=0
      @stops && @stops.each do |stop|
        if stop.tours_stops.first.sequence
          if stop.tours_stops.first.sequence==@stop_values[0].to_i
            @stop_status=1
            if stop.images
              @sending_status=0
              stop.images && stop.images.each_with_index do |stop_img,index|
                if index== @stop_values[1].to_i
                  file="#{stop_img.public_filename(:iphone_img)}"
                  if FileTest.exists?(file)
                       send_file file, :type => 'image/jpeg', :disposition => 'inline'
                    @sending_status=1
                  else
                    flash[:upload_error] = "Image doesnot exist!"
                    redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
                  end
                end
              end
              if @sending_status==0
                flash[:upload_error] = "No such image !"
                redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
              end
            else
              flash[:upload_error] = "No image for this stop !"
              redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
            end
          end
        else
          flash[:upload_error] = "No Stop found !"
          redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
        end
      end
      if  @stop_status==0
        flash[:upload_error] = "No such Stop !"
        redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
      end
    else
      flash[:upload_error] = "No Stop for this tour!"
      redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
    end
  end

  def stop_photo_jpg
    @stop_values=params[:sequence].split(/_/)
    @tour=Tour.find(params[:tour_id])
    @stops=@tour.stops
    if @stops && !@stops.empty?
      @stop_status=0
      @stops && @stops.each do |stop|
        if stop.tours_stops.first.sequence
          if stop.tours_stops.first.sequence==@stop_values[0].to_i
            @stop_status=1
            if stop.images
              @sending_status=0
              stop.images && stop.images.each_with_index do |stop_img,index|
                if index== @stop_values[1].to_i
                  file="#{stop_img.public_filename(:iphone_img)}"
                  if FileTest.exists?(file)
                    send_file file, :type => 'image/jpeg', :disposition => 'true' , :filename=>"#{params[:sequence]}.jpg"
                    @sending_status=1
                  else
                    flash[:upload_error] = "Image doesnot exist!"
                    redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
                  end
                end
              end
              if @sending_status==0
                flash[:upload_error] = "No such image !"
                redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
              end
            else
              flash[:upload_error] = "No image for this stop !"
              redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
            end
          end
        else
          flash[:upload_error] = "No Stop found !"
          redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
        end
      end
      if  @stop_status==0
        flash[:upload_error] = "No such Stop !"
        redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
      end
    else
      flash[:upload_error] = "No Stop for this tour!"
      redirect_to stops_show_path(current_user_name, @tour.id,@stop_values[0].to_i)
    end
  end
  
  def stop_audio
     if params[:tour_id] && params[:stop_seq] && Tour.exists?(params[:tour_id]) && !current_user.nil?
    @tour=Tour.find(params[:tour_id])
    if params[:stop_seq].to_i<@tour.stops.size
      @tours_stops=@tour.tours_stops
      @tours_stops && @tours_stops.each do |tours_stop|
        if tours_stop.sequence==params[:stop_seq].to_i
          @stop=tours_stop.stop
        end
      end
      if @tour.user_id==current_user.id || session[:admin_panel]==1 || session[:admin_panel]==2
          @audio=@stop.audio
          if !@audio.nil?
            send_file "#{@audio.public_filename}", :type=>'audio/mpeg' ,:disposition=>'inline'
          else
            flash[:upload_error] = "No Audio for this Stop!"
             redirect_to stops_show_path(current_user_name, @tour.id,params[:stop_seq].to_i)
           end
        else
            flash[:flash_error_msg]="Permission Denied."
            redirect_to root_path
          end
      else
          flash[:upload_error]="No such Stop for this Tour."
          redirect_to tour_show_path(current_user_name, @tour.id)
      end
    else
      flash[:flash_error_msg]="No such Tour found."
      redirect_to root_path
    end
  end
  
  def stop_image
    if params[:tour_id]  && params[:stop_seq]  && Tour.exists?(params[:tour_id])
        @seq=params[:stop_seq].split('_').first.to_i
        @ind=params[:stop_seq].split('_').last.to_i
        @tour=Tour.find(params[:tour_id])
        if @seq<@tour.stops.size
          @tours_stops=@tour.tours_stops
          @tours_stops && @tours_stops.each do |tours_stop|
            if tours_stop.sequence==@seq
              @stop=tours_stop.stop
            end
          end
          if @tour.user_id==current_user.id || session[:admin_panel]==1 || session[:admin_panel]==2
              @images=@stop.images
               if !@images.empty?
                 if @ind >=@stop.images.count
                    flash[:upload_error] = "No such Image for this Stop!"
                     redirect_to stops_show_path(current_user_name, @tour.id,@seq)
                  end
                 @images && @images.each_with_index do |img, index|
                    if index == @ind
                       send_file "#{img.public_filename(:thumb)}", :type=>'image/jpg' ,:disposition=>'inline'
                    end          
                  end
              else
                 flash[:upload_error] = "No Image for this Stop!"
                 redirect_to stops_show_path(current_user_name, @tour.id,@seq)
              end
          else
             flash[:flash_error_msg]="Permission Denied."
             redirect_to root_path
           end
        else
           flash[:upload_error]="No such Stop for this Tour."
          redirect_to tour_show_path(current_user_name, @tour.id)
        end
    else
      flash[:flash_error_msg]="No such Tour found."
      redirect_to root_path
    end
  end
  
   private
  
   def authenticate_image_stop
     if !logged_in?
      authenticate_or_request_with_http_basic do |username, password| 
          @user=User.authenticate(username,password)
        end
      end
      if current_user
        if current_user.user_type == 0
        session[:admin] = 1
      elsif current_user.user_type == 2
        session[:admin] = 2
      end
      end
   end

end