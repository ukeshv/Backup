require "rubygems"
require "mp3info"
require "net/sftp"
class ToursController < ApplicationController
  protect_from_forgery :except=>["save_image","save_audio"]
	before_filter :require_ssl, :except =>["kml","photo","photo_jpg", "embed_map"]
  before_filter :authenticate_image, :only => ["photo","photo_jpg"]
	before_filter :login_required, :except =>["kml","embed_map"]
	layout :change_layout, :except=>"embed_map"
	include KmlGenerator
	
	def index
    if params[:user_id]
      @user = User.find_by_id(params[:user_id])
      @tours = User.get_current_user_tours(@user).paginate(:page => params[:page], :per_page =>20)
    else
      session[:admin_panel] = nil
      @user = current_user
		  @tours = User.get_current_user_tours(current_user).paginate(:page => params[:page], :per_page =>20)
    end
    if !session[:notifications]
      @notifications = User.all_notifications(@user)
      session[:notifications] = @notifications
      @notifications && @notifications.each do |notification|
        notification.status = 1
        notification.save
      end
    end
    if session[:admin_panel]==1 || session[:admin_panel]==2
      #~ if params[:orderby]=="title"
        #~ @tours=Tour.sort_by_tour_link_admin_panel(params[:by],@user.id).paginate :page=>params[:page], :per_page=>20, :order=>"#{params[:orderby]} #{params[:by]}"
      #~ elsif params[:orderby]=="created_at"
        #~ @tours=Tour.sort_by_created_at_link_admin_panel(params[:by],@user.id).paginate :page=>params[:page], :per_page=>20, :order=>"#{params[:orderby]} #{params[:by]}"
      #~ else
        #~ @tours=Tour.sort_by_status_link_admin_panel(params[:by],@user.id).paginate :page=>params[:page], :per_page=>20, :order=>"#{params[:orderby]} #{params[:by]}"
      #~ end
      if params[:tour_admin] == "All Tours"
        @tours = Tour.order_by_review_default_user_admin(@user.id).paginate(:page => params[:page], :per_page =>20)
        $tour_status_params_user_admin=[-2,-1,0,1,2,3,4,5,6,7,8,9,10]
      elsif params[:tour_admin]=="Live tours" && params[:orderby].nil?
        @tours = Tour.order_by_live_user(@user.id).paginate(:page => params[:page], :per_page =>20)
        $tour_status_params_user_admin=[10]
      elsif params[:tour_admin]=="Draft tours" && params[:orderby].nil?
        @tours = Tour.order_by_draft_user(@user.id).paginate(:page => params[:page], :per_page =>20)
        $tour_status_params_user_admin=[0]
      elsif params[:tour_admin]=="Review tours" && params[:orderby].nil?
        @tours = Tour.order_by_review_user(@user.id).paginate(:page => params[:page], :per_page =>20)
        $tour_status_params_user_admin=[3,4]
     elsif params[:tour_admin]=="Deleted Tours" && params[:orderby].nil?
        @tours = Tour.order_by_deleted_user(@user.id).paginate(:page => params[:page], :per_page =>20)
        $tour_status_params_user_admin=[-2]
     elsif params[:search] && !params[:search].empty?
        $tour_status_params_user_admin=[-2,-1,0,1,2,3,4,5,6,7,8,9,10]
        @tours = Tour.search_by_keyword_user(params[:search],@user.id).paginate(:page => params[:page], :per_page =>20)
        flash.now[:search_box] = "Search Result for #{params[:search]}"    
      elsif params[:orderby]=="title" || params[:orderby]=="status" || params[:orderby]=="created_at"
        @tours=Tour.paginate :page=>params[:page], :per_page=>20, :conditions=>['status in (?) and user_id=?',$tour_status_params_user_admin,@user.id],:order=>"#{params[:orderby]} #{params[:by]}"
      else
        @tours = Tour.order_by_review_default_user_admin(@user.id).paginate(:page => params[:page], :per_page =>20)
        $tour_status_params_user_admin=[-2,-1,0,1,2,3,4,5,6,7,8,9,10]
      end
      
    else
      #~ if params[:orderby]=="title"
        #~ @tours=Tour.sort_by_tour_link(params[:by],@user.id).paginate :page=>params[:page], :per_page=>20, :order=>"#{params[:orderby]} #{params[:by]}"
      #~ elsif params[:orderby]=="created_at"
        #~ @tours=Tour.sort_by_created_at_link(params[:by],@user.id).paginate :page=>params[:page], :per_page=>20, :order=>"#{params[:orderby]} #{params[:by]}"
      #~ elsif params[:orderby]=="status"
        #~ @tours=Tour.sort_by_status_link(params[:by],@user.id).paginate :page=>params[:page], :per_page=>20, :order=>"#{params[:orderby]} #{params[:by]}"
      if params[:tour] == "All Tours"
      @tours = Tour.order_by_review_default_user(@user.id).paginate(:page => params[:page], :per_page =>20)
      $tour_status_params_user=[-1,0,1,2,3,4,5,6,7,8,9,10]
       elsif params[:tour]=="Live tours" && params[:orderby].nil?
      @tours = Tour.order_by_live_user(@user.id).paginate(:page => params[:page], :per_page =>20)
      $tour_status_params_user=[10]
    elsif params[:tour]=="Draft tours" && params[:orderby].nil?
      @tours = Tour.order_by_draft_user(@user.id).paginate(:page => params[:page], :per_page =>20)
      $tour_status_params_user=[0]
    elsif params[:tour]=="Review tours" && params[:orderby].nil?
      @tours = Tour.order_by_review_user(@user.id).paginate(:page => params[:page], :per_page =>20)
      $tour_status_params_user=[3,4]
       elsif params[:search] && !params[:search].empty?
        $tour_status_params_user=[-1,0,1,2,3,4,5,6,7,8,9,10]
        @tours = Tour.search_by_keyword_user(params[:search],@user.id).paginate(:page => params[:page], :per_page =>20)
        flash.now[:search_box] = "Search Result for #{params[:search]}"
      elsif params[:orderby]=="title" || params[:orderby]=="status" || params[:orderby]=="created_at"
      @tours=Tour.paginate :page=>params[:page], :per_page=>20, :conditions=>['status in (?) and user_id=? and status!=?',$tour_status_params_user,@user.id,-2],:order=>"#{params[:orderby]} #{params[:by]}"
      else
         @tours = Tour.order_by_review_default_user(@user.id).paginate(:page => params[:page], :per_page =>20)
         $tour_status_params_user=[-1,0,1,2,3,4,5,6,7,8,9,10]
      end
    end
	end

  def load_all_values
    @category=Category.find_by_code(@tour.category)
  end

	def show
    @user=User.find_by_username(params[:user_name]) if params[:user_name]    
    params[:tour_id] = params[:id] if params[:id]    
    @tour = Tour.find_by_id(params[:tour_id])
    if @tour           
      load_all_values
			@tour_id = @tour.id
      @tour.author="Please select Author" if @tour.author.blank?
			@stops = @tour.get_all_stops
      @tracks = @tour.tour_tracks
			@rating = @tour.rating.round
      @user = @tour.user
  @stopname=[]
 @stops.each do |s|
  if s.audio==nil
  @stopname<<"Upload or Record audio for #{s.name}.<br />"
end

end
    end
    if (@tour && @tour.user_id!=current_user.id && !(@tour.check_if_current_user_tour(current_user) || session[:admin_panel] == 1 || session[:admin_panel] == 2  )) || @tour.nil?
      if @tour.nil?
      flash[:flash_error_msg] = "No Such Tours!"
      else
      flash[:flash_error_msg] = "Permission denied!"
      end
      redirect_to_index 
    end
	end

 def photo
     @tour = Tour.find(params[:tour_id].to_i)   if Tour.exists?(params[:tour_id].to_i)
     #~ if !@tour.nil? && (@tour.user_id==current_user.id || session[:admin_panel] ==1 || session[:admin_panel] == 2)
     if !@tour.nil? 
      if @tour.image
        file=   "#{@tour.image.public_filename(:iphone_img)}"
        send_file file, :type => 'image/jpeg', :disposition => 'inline'
      else
        redirect_to tour_show_path(current_user_name, @tour.id)
        flash[:upload_error]="No Image for this Tour"
      end
    else
      flash[:flash_error_msg]="Permission Denied!"
      redirect_to_index
    end
  end
  
  def photo_jpg
    @tour = Tour.find(params[:tour_id].to_i)  if Tour.exists?(params[:tour_id].to_i)
    #~ if  !@tour.nil? && (@tour.user_id==current_user.id || session[:admin_panel] ==1 || session[:admin_panel] == 2)
    if  !@tour.nil? 
      if @tour.image
        file=   "#{@tour.image.public_filename(:iphone_img)}"
        send_file file, :type => 'image/jpeg', :disposition => 'true', :filename=> "overview.jpg"
      else
        redirect_to tour_show_path(current_user_name, @tour.id)
        flash[:upload_error]="No Image for this Tour"
      end
    else
      flash[:flash_error_msg]="Permission Denied!"
      redirect_to_index
    end
  end
	
  def stops
    #code for blink change route link or not
    if current_user
      @user=current_user
      @tour_count=@user.tours
      @length=@tour_count.length
    end
    @user=User.find_by_username(params[:user_name]) if params[:user_name]
    @tour = Tour.find_by_id(params[:tour_id])
    @lat_array=[]
    @long_array=[]
    if @tour
      load_all_values
			@tour_id = @tour.id
			@stops = @tour.get_all_stops
      @tracks = @tour.tour_tracks
			@rating = @tour.rating.round
      @tracks_stops=[]
      is_stop=[]
      #~ @tour.tour_tracks.collect{|x| @lat_array<<x.latitude}
      #~ @tour.tour_tracks.collect{|x| @long_array<<x.longitude}
      @tracks.each do |x|
        @tracks_stops <<x.latitude.to_s+"_"<<x.longitude.to_s+"_"<<x.is_stop.to_s+"_"
        @lat_array<<x.latitude
        @long_array<<x.longitude
        is_stop<<x.is_stop
      end
      @stop_count=is_stop.count(1)
    end
		if !@tour
      redirect_to_index 
    end
	end
  
  
  def embed_map
    @tour = Tour.find_by_id(params[:tour_id])
    @lat_array=[]
    @long_array=[]
    if @tour
      load_all_values
			@tour_id = @tour.id
			@stops = @tour.get_all_stops
      @tracks = @tour.tour_tracks
			@rating = @tour.rating.round
      @tracks_stops=[]
      is_stop=[]
      #~ @tour.tour_tracks.collect{|x| @lat_array<<x.latitude}
      #~ @tour.tour_tracks.collect{|x| @long_array<<x.longitude}
      @tracks.each do |x|
        @tracks_stops <<x.latitude.to_s+"_"<<x.longitude.to_s+"_"<<x.is_stop.to_s+"_"
        @lat_array<<x.latitude
        @long_array<<x.longitude
        is_stop<<x.is_stop
      end
      @stop_count=is_stop.count(1)
    end
		if !@tour
      redirect_to_index 
    end
  end
  

  def routes
    @tour = Tour.find_by_id(params[:tour_id])
    if @tour
      load_all_values
			@tour_id = @tour.id
			@stops = @tour.get_all_stops
      @tracks = @tour.tour_tracks
			@rating = @tour.rating.round
    end
		if !@tour || (!@tour.check_if_current_user_tour(current_user) && session[:admin] != 1)
      redirect_to_index
    end
	end
	
	def new 
		@tour = Tour.new
		redirect_to_index
  end 
	
  #~ def create 
  #~ @tour = Tour.new
  #~ @tour.attributes = strip_for_values(@tour, params[:tour])
  #~ @tour.assign_values(current_user)
  #~ if @tour.valid? && @tour.save
  #~ redirect_to_index
  #~ else
  #~ flash[:title_error] = "Title has been already taken!" if !@check_tour.nil?
  #~ render :action => "new"
  #~ end
  #~ end 
	
	def edit
		@categories=Category.find(:all)
		@tour = Tour.find_by_id(params[:tour_id])
		if !@tour || (!@tour.check_if_current_user_tour(current_user) && session[:admin] != 1 && session[:admin] != 2)
			redirect_to_index
		end
	end
	
	def update
    params[:tour] = add_price(params[:tour])
		@categories=Category.find(:all)
	  @tour = Tour.find_by_id(params[:id])
    @tour.attributes = strip_for_values(@tour, params[:tour])
		#~ @tour.user_id = current_user.id
		@tour.status= 1
		#~ if @tour.valid? && @tour.save && @tour.category!=0 && @tour.description!="0" && @tour.description!="-"
		if @tour.valid? && @tour.save
      session[:alert_box] = 1
      History.create_history(current_user.id, "Tour Details Updated", @tour.id)
      flash[:flash_msg] = "Tour Updated Successfully!"
		  redirect_to tour_show_path(current_user_name, @tour.id)  
		else
      #~ if @tour.category==0
        #~ flash.now[:category_error]="Please select Category"
      #~ end
      #~ if (@tour.description=="0" || @tour.description=="-")
        #~ flash.now[:description_error]="Please fill Description<br />"
      #~ end
			render :action => "edit"
		end
    load_all_values
	end

  def destroy
		@tour = Tour.find_by_id(params[:id])
		@tours = User.get_current_user_tours(current_user)
		if (@tours.include?(@tour) || session[:admin_panel] == 1) && (@tour.status==0 || @tour.status==1 || session[:admin_panel] == 1)
      @tour.update_attribute('status' , -2)
      @tour.save
      #tour_id = @tour.id
		  #@tour_search = TourSearch.find_by_id(@tour.id)
      #@tour_search.destroy if @tour_search
      #@tour.destroy
      #`rm -rf /files/#{get_batch_number(tour_id)}/#{tour_id}`
     	flash[:delete_tour] = "Tour deleted successfully."
		end
		redirect_to_index
	end

  def get_batch_number(index)
    i = (index / 10000) + 1
    return i
  end

  def save_image
   	@tour = Tour.find_by_id(params[:tour_id])
    @user = @tour.user
    load_all_values
    @tour_id = @tour.id
		@rating = @tour.rating.round
		@image = Image.new(params[:image])
		if @image.valid?
      @tour.image = @image
			@tour.update_attribute('status',1)
      #~ @tour.description = "-"  if @tour.description.blank?
      if @tour
        session[:alert_box] = 1
        History.create_history(current_user.id, "Overview Image uploaded", @tour.id)
        @tour.update_attribute('updated_at',Time.current)
        flash[:upload_msg] = "File uploaded successfully!"
				redirect_to tour_show_path(current_user_name, @tour.id)
			else
        flash.now[:upload_error] = "Invalid File format!"
        render :action => "show"
			end
		else
    if params[:image].nil?
  			flash.now[:upload_error] = "Please attach a Image to Upload"
     elsif  @image.errors.first[0] != "size"
    		flash.now[:upload_error] = "Invalid Image Format"
     else 
    		flash.now[:upload_error] = "Can not upload Image greater than 2MB"
      end
      render :action => "show"
		end
  end

  def save_audio
 		@tour = Tour.find_by_id(params[:tour_id])
    @user = @tour.user
    load_all_values
    @tour_id = @tour.id
		@rating = @tour.rating.round
		@audio = Audio.new(params[:audio])
		if @audio.valid?
      @audio.is_audio = 1
      if @tour.audio
        @old_audio=@tour.audio
        @file_path_old= @tour.audio.public_filename.split('/')
        @file_path_old.pop
        @file_path=@file_path_old.join('/')
        File.rename("#{@tour.audio.public_filename}","#{@file_path}/overview_old.mp3")
      end
      @tour.audio = @audio
			@tour.update_attribute('status',1)
      #~ @tour.description = "-"  if @tour.description.blank?
      
			if get_audio_file_duration<=240 || session[:admin_panel] == 1
         if !defined?(@file_path).nil?
           File.delete("#{@file_path}/overview_old.mp3")
         end
        session[:alert_box] = 1
				History.create_history(current_user.id, "Overview Audio uploaded", @tour.id)
        @tour.update_attribute('updated_at',Time.current)
        flash[:upload_msg] = "File uploaded successfully!"
				redirect_to tour_show_path(current_user_name, @tour.id)
			else
        if get_audio_file_duration>240
          @tour.audio=nil
           if !defined?(@file_path).nil?
             #~ File.delete("#{@file_path}/overview.mp3")
             File.rename("#{@file_path}/overview_old.mp3","#{@file_path}/overview.mp3")  
            @tour.audio=@old_audio.clone
            @tour.audio.save
          end
          flash.now[:upload_error] = "Audio File duration should be less then 4 Minutes."
        else
        flash.now[:upload_error] = "Invalid File format!"
        end
        render :action => "show"
			end
		else
	    if params[:audio].nil?
			  flash.now[:upload_error] = "Please attach a Audio to Upload"
      else
        flash.now[:upload_error] = "Invalid Audio Format"
      end
      render :action => "show"
		end
	end
  
  def save_recorded_overview_audio
      @tour=Tour.find(params[:tour_id].to_i) if Tour.exists?(params[:tour_id].to_i)
      file_present=@tour.check_for_existence
      if file_present==false
        flash[:upload_error] = "Please Record an Audio to Save"
      else
      session[:overview_alert_box]=1
      @tour.take_recorded_audio_from_server
      @tour.update_attribute('updated_at',Time.current)
      @tour.update_attribute('status',1)
      History.create_history(current_user.id, "Overview Audio Recorded Successfully", @tour.id)
        flash[:upload_msg] = "Audio Recorded successfully!"
     end
      redirect_to tour_show_path(current_user_name, @tour.id)
  end
  
  def delete_audio
    @tour = Tour.find_by_id(params[:tour_id])
    if @tour.audio
      @tour.audio=nil
      History.create_history(current_user.id, "Overview Audio Deleted", @tour.id)
    end
    flash[:upload_error] = "Overview Audio deleted Successfully"
    redirect_to tour_show_path(current_user_name, @tour.id)
  end

  def delete_image
    @tour = Tour.find_by_id(params[:tour_id])
    if @tour.image
      @tour.image=nil
      History.create_history(current_user.id, "Overview Image Deleted", @tour.id)
    end
    flash[:upload_error] = "Overview Image deleted Successfully"
    redirect_to tour_show_path(current_user_name, @tour.id)
  end
  
	def redirect_to_index
    if session[:admin_panel]==1
      redirect_to admin_index_path
    elsif session[:admin_panel]==2
      redirect_to group_admin_index_path
    else
      redirect_to tours_index_path(current_user_name)
    end
	end
	
	def kml
		@tour = Tour.find_by_id(params[:id])
		if @tour
			if !@tour.stops.empty? || !@tour.tour_tracks.empty?
				@stops = @tour.stops
        @tracks = @tour.tour_tracks
        @points = @tour.get_all_points 
       	kml_generated = generate_kml(@tracks, @points)
				f = File.new("public/kmls/#{@tour.id}_#{@stops.count}.kml", "w")
				f.write(kml_generated)
				f.close
				redirect_to "#{APP_CONFIG[:site_url]}/kmls/#{@tour.id}_#{@stops.count}.kml"
			end
    else
      redirect_to root_path
		end
	end

  def change_status_to_review
    @tour = Tour.find_by_id(params[:tour_id])
    @stops=@tour.stops
    @stopname=[]
 @stops.each do |s|
  if s.audio==nil
  @stopname<<"<br />Upload or Record audio for #{s.name}." 
end
end
    if @tour
      if @tour.title? && @tour.description? && @tour.category? && @tour.difficulty? && @tour.audio && @tour.author? && @tour.stops.size>=2 && @tour.description!="0" && @tour.description!="-" && @stopname.empty? 
        #~ if @tour.category==9
        #~ @tour.update_attribute('status', 5)
        #~ else
        @tour.update_attribute('status', 2)
        
        #~ end
        flash[:flash_msg] = "Tour will be Reviewed soon"
        flash[:flash_msg] = "Tour was Approved" if @tour.category==9
        flash[:flash_msg] = "Please review this tour" if session[:admin_panel] == 1 && @tour.category!=9
        History.create_history(current_user.id, "#{@tour.title} - Tour sent for Review", @tour.id)
        UserMailer.deliver_review_tour(@tour.user.username, @tour.user.email, "Tour '#{@tour.title}'-'#{@tour.id}' Submitted for Review","Submit Tour to Review",@tour)
        redirect_to tour_show_path(current_user_name, @tour.id)
      else
        if !@tour.title?
          flash[:upload_error1] = "Please fill Title."
        end
        if !@tour.description? || @tour.description=="0" || @tour.description=="-"
          flash[:upload_error2] = "Please fill Description."
        end
        if !@tour.category?
          flash[:upload_error3] = "Please fill Category."
        end
        if !@tour.difficulty?
          flash[:upload_error4] = "Please fill Difficulty."
        end
        if !@tour.audio
          flash[:upload_error5] = "Please Upload an Audio."
        end
        if !@tour.author?
          flash[:upload_error6] = "Please fill Author name."
        end   
        if @tour.stops.size<2
          flash[:upload_error7] = "There should be atleast 2 Stops."
        end
        if !@stopname.empty? 
            flash[:upload_error9] = "#{@stopname}"
        end
        redirect_to tour_show_path(current_user_name, @tour.id)
      end
    else
      redirect_to root_path
    end 
  end

  def change_status_to_recall
    @tour = Tour.find_by_id(params[:tour_id])
    if @tour
      if @tour.status==10
        flash[:flash_msg] = "Tour recalled successfully"
      else
        flash[:flash_msg] = "Tour status rollback successfully done"
      end
      system "s3cmd del --recursive s3://#{AMAZON_CONFIG['bucket_name']}/files/#{(@tour.id/ 10000) + 1}/#{@tour.id}"
      @tour.update_attribute('status', 1)
      TourSearch.delete(params[:tour_id]) if TourSearch.exists?(params[:tour_id])
      History.create_history(current_user.id, "#{@tour.title} - Tour Recalled", @tour.id)
      redirect_to tour_show_path(current_user_name, @tour.id)
    else
      redirect_to root_path
    end
  end
  
  def approve_tour
    @tour = Tour.find_by_id(params[:tour_id])
    if @tour
      @tour.update_attribute('status', 5)
      flash[:flash_msg] = "Tour Approved!"
      History.create_history(current_user.id, "#{@tour.title} - Tour Approved", @tour.id)
      Notification.add_notification_log(@tour.user_id, "<font color='#660099'><a href='/user/#{@tour.user.username}/tours/#{@tour.id}' class='simple_link'>#{@tour.title}</a> - Tour Approved</font>")
      #~ UserMailer.deliver_tour_approved(@tour.user, "Tour '#{@tour.title}' Approved","Your tour was Approved",@tour)
      redirect_to tour_show_path(current_user_name, @tour.id)
    else
      redirect_to root_path
    end
    
  end

  def reject_tour
    @tour = Tour.find_by_id(params[:tour_id])
    if @tour
      @tour.update_attribute('status', -1)
      @notification_message=params[:reject_notification]
      flash[:flash_msg] = "Tour Rejected!"
      @var = "<font color='red'><a href='/user/#{@tour.user.username}/tours/#{@tour.id}' class='simple_link'>#{@tour.title}</a> - Tour Rejected - </font>"
      reject_notify = (params[:reject_notification] && (!params[:reject_notification].blank? && (params[:reject_notification] != "Why Rejecting this Tour?")))? (@var + "<font color='red'>#{params[:reject_notification]}</a>") : @var
      Notification.add_notification_log(@tour.user_id, reject_notify)
      History.create_history(current_user.id, "#{@tour.title} - Tour Rejected", @tour.id)
      #~ Notification.add_notification_log(@tour.user_id, "<font color='red'><a href='/user/#{@tour.user.username}/tours/#{@tour.id}' class='simple_link'>#{@tour.title}</a> - Tour Rejected </font>")
      UserMailer.deliver_tour_rejected(@tour.user, "Tour '#{@tour.title}' Rejected","Your tour was Rejected",@tour,@notification_message)
      redirect_to tour_show_path(current_user_name, @tour.id)
    else
      redirect_to root_path
    end
  end

  def revise_tour
    @tour = Tour.find_by_id(params[:tour_id])
    if @tour
      @tour.update_attribute('status', 1)
      @notification_message=params[:revise_notification]
      flash[:flash_msg] = "Tour made to revise"
      @var = "<font color='blue'><a href='/user/#{@tour.user.username}/tours/#{@tour.id}' class='simple_link'>#{@tour.title}</a> - Revise this Tour - </font>"
      notify = (params[:revise_notification] && (!params[:revise_notification].blank? && (params[:revise_notification] != "What to Revise")))? (@var + "<font color='blue'>#{params[:revise_notification]}</a>") : @var
      Notification.add_notification_log(@tour.user_id, notify)
      History.create_history(current_user.id, "#{@tour.title} - Tour sent for Revise", @tour.id)
      UserMailer.deliver_tour_revised(@tour.user, "Tour '#{@tour.title}' has to be Revised","Your tour was sent to Revise",@tour,@notification_message)
      redirect_to tour_show_path(current_user_name, @tour.id)
    else
      redirect_to root_path
    end
  end

  def create_stop_task
    @task=Task.find(:first,:conditions=>['tour_id=? and stop_seq_num=? and (state=? or state=?)',params[:tour_id],params[:sequence_id],0,1])
    if @task.nil?
      Task.create(:task_type => 2,:tour_id => params[:tour_id],:stop_seq_num=>params[:sequence_id])
      flash[:flash_msg]="Task created !"
      redirect_to tour_show_stops_path(current_user_name,params[:tour_id])
    else
      flash[:flash_msg]="Task already In Progress !"
      redirect_to tour_show_stops_path(current_user_name,params[:tour_id])
    end
  end

  def create_tour_task
    @task=Task.find(:first,:conditions=>['tour_id=? and task_type=? and (state=? or state=?)',params[:tour_id],1,0,1])
    if @task.nil?
      Task.create(:task_type => 1,:tour_id => params[:tour_id],:stop_seq_num => 0)
      flash[:flash_msg]="Task created !"
      redirect_to tour_show_path(current_user_name,params[:tour_id])
    else
      flash[:flash_msg]="Task already In Progress !"
      redirect_to tour_show_path(current_user_name,params[:tour_id])
    end
  end

  def history
    @user=User.find_by_username(params[:user_name]) if params[:user_name]
    @tour = Tour.find_by_id(params[:tour_id])
    @histories = History.find_tour_history(@tour) 
  end

  def edit_route
    @user=User.find_by_username(params[:user_name]) if params[:user_name]
    @tour = Tour.find_by_id(params[:tour_id])
    @tour_tracks=@tour.tour_tracks
    @tracks_stops=[]
    @lat_arr=[]
    @long_arr=[]
    is_stop=[]
    @tour_tracks.each do |x|
      @tracks_stops <<x.latitude.to_s+"_"<<x.longitude.to_s+"_"<<x.is_stop.to_s+"_"
      @lat_arr<<x.latitude
      @long_arr<<x.longitude
      is_stop << x.is_stop
    end
   @stop_count=is_stop.count(1)
  end
 
 def save_edited_route
   
  @tour=Tour.find(params[:tourid]) if Tour.exists?(params[:tourid])
   @tour.length= params[:length]
  @tour.tour_tracks=[]
  @tour.save(false)
  @tour_rracks_arr=params[:tracks].split(",")   
  @tour_rracks_arr && @tour_rracks_arr.each_with_index do |track,index|
    if index==0 || index%3==0
      TourTrack.create(:tour_id=>params[:tourid].to_i, :latitude=>@tour_rracks_arr[index].to_f, :longitude=>@tour_rracks_arr[index+1].to_f, :is_stop=>@tour_rracks_arr[index+2].to_i)
    end
  end
  flash[:flash_msg] = "Route edited successfully!"
   render :update do |page|
        page.redirect_to tour_show_stops_path(current_user_name, params[:tourid].to_i)
    end
 end

  def clone_tour
    @tour=Tour.find(params[:tour_id])
    #~ if @tour && @tour.title? && @tour.description? && @tour.category? && @tour.difficulty? && @tour.audio && @tour.author? && @tour.stops.size>=2 && @tour.description!="0" && @tour.description!="-"
      
    if @tour && @tour.stops.size>=4
      @stop_ids=[]
      @clone_tour=@tour.clone
      @clone_tour.update_attribute('created_from',"Website")
      @clone_tour.save
      if @clone_tour.status==10
        @clone_tour.update_attribute('status',1)
      end
      @tour_audio= @tour.audio
      @tour_image= @tour.image
      @stops=@tour.stops
      @tours_stops=@tour.tours_stops
      @tour_tracks=@tour.tour_tracks
      @tour_att_audio_id=@tour.audio.attachment_path_id if @tour.audio
      @tour_att_audio=Attachment.find(@tour_att_audio_id) if @tour_att_audio_id
      if @tour_att_audio
        Attachment.create(:parent_id=> nil, :attachable_id=>@clone_tour.id, :attachable_type=>@tour_att_audio.attachable_type, :content_type=>@tour_att_audio.content_type,:filename=>@tour_att_audio.filename, :thumbnail=>@tour_att_audio.thumbnail, :size=>@tour_att_audio.size, :height=>@tour_att_audio.height, :width=>@tour_att_audio.width, :is_audio=>@tour_att_audio.is_audio, :created_at=>@tour_att_audio.created_at, :updated_at=>@tour_att_audio.updated_at )
      end
      @tour_att_image_id=@tour.image.attachment_path_id if @tour.image
      @tour_att_image_orig=Attachment.find(@tour_att_image_id) if @tour_att_image_id
      if @tour_att_image_orig
        @tour_att_image_orig_clone=Attachment.create(:parent_id=> nil, :attachable_id=>@clone_tour.id, :attachable_type=>@tour_att_image_orig.attachable_type, :content_type=>@tour_att_image_orig.content_type,:filename=>@tour_att_image_orig.filename, :thumbnail=>@tour_att_image_orig.thumbnail, :size=>@tour_att_image_orig.size, :height=>@tour_att_image_orig.height, :width=>@tour_att_image_orig.width, :is_audio=>@tour_att_image_orig.is_audio, :created_at=>@tour_att_image_orig.created_at, :updated_at=>@tour_att_image_orig.updated_at )
      end
      @tour_att_image_copy=Attachment.find_all_by_parent_id(@tour_att_image_id)
      @tour_att_image_copy && @tour_att_image_copy.each do |tour_att_img|
        if @tour_att_image_orig_clone
          Attachment.create(:parent_id=> @tour_att_image_orig_clone.id, :attachable_id=>nil, :attachable_type=>tour_att_img.attachable_type, :content_type=>tour_att_img.content_type,:filename=>tour_att_img.filename, :thumbnail=>tour_att_img.thumbnail, :size=>tour_att_img.size, :height=>tour_att_img.height, :width=>tour_att_img.width, :is_audio=>tour_att_img.is_audio, :created_at=>tour_att_img.created_at, :updated_at=>tour_att_img.updated_at )
        end
      end
      @stops && @stops.each do |stop|
        @clone_stop=stop.clone
        @clone_stop.save
        @stop_ids << @clone_stop.id
        @stop_audio= stop.audio
        @stop_images= stop.images
        @stop_att_audio_id=stop.audio.attachment_path_id if stop.audio
        @stop_att_audio=Attachment.find(@stop_att_audio_id) if @stop_att_audio_id
        if @stop_att_audio
          Attachment.create(:parent_id=> nil, :attachable_id=>@clone_stop.id, :attachable_type=>@stop_att_audio.attachable_type, :content_type=>@stop_att_audio.content_type,:filename=>@stop_att_audio.filename, :thumbnail=>@stop_att_audio.thumbnail, :size=>@stop_att_audio.size, :height=>@stop_att_audio.height, :width=>@stop_att_audio.width, :is_audio=>@stop_att_audio.is_audio, :created_at=>@stop_att_audio.created_at, :updated_at=>@stop_att_audio.updated_at )
        end
        @stop_att_images=stop.images
        @stop_att_images && @stop_att_images.each do |stop_att_img|
          @stop_att_image_orig=Attachment.find(stop_att_img.attachment_path_id)
          @stop_att_image_orig_clone=Attachment.create(:parent_id=> nil, :attachable_id=>@clone_stop.id, :attachable_type=>@stop_att_image_orig.attachable_type, :content_type=>@stop_att_image_orig.content_type,:filename=>@stop_att_image_orig.filename, :thumbnail=>@stop_att_image_orig.thumbnail, :size=>@stop_att_image_orig.size, :height=>@stop_att_image_orig.height, :width=>@stop_att_image_orig.width, :is_audio=>@stop_att_image_orig.is_audio, :created_at=>@stop_att_image_orig.created_at, :updated_at=>@stop_att_image_orig.updated_at )
          @stop_att_image_copy=Attachment.find_all_by_parent_id(stop_att_img.attachment_path_id)
          @stop_att_image_copy && @stop_att_image_copy.each do |stop_att_img_copy|
            Attachment.create(:parent_id=> @stop_att_image_orig_clone.id, :attachable_id=>nil, :attachable_type=>stop_att_img_copy.attachable_type, :content_type=>stop_att_img_copy.content_type,:filename=>stop_att_img_copy.filename, :thumbnail=>stop_att_img_copy.thumbnail, :size=>stop_att_img_copy.size, :height=>stop_att_img_copy.height, :width=>stop_att_img_copy.width, :is_audio=>stop_att_img_copy.is_audio, :created_at=>stop_att_img_copy.created_at, :updated_at=>stop_att_img_copy.updated_at )
          end
        end
      end
      @tours_stops && @tours_stops.each_with_index do |tours_stop, index|
        ToursStop.create(:tour_id=>@clone_tour.id, :stop_id=>@stop_ids[index], :sequence=>tours_stop.sequence)
      end
      @tour_tracks && @tour_tracks.each do |tour_track|
        TourTrack.create(:tour_id=>@clone_tour.id, :latitude=>tour_track.latitude, :longitude=>tour_track.longitude, :altitude=>tour_track.altitude, :is_stop=>tour_track.is_stop )
      end
      if @tour.audio
        @tour_dir_index = 1 + (@clone_tour.id/10000)
        filepath_old= @tour.audio.public_filename.split('/')
        filepath=filepath_old.pop(2)
        filepath_new=filepath_old.join('/')
        system("cp -r #{filepath_new}/ #{RAILS_ROOT}/files/#{@tour_dir_index}/#{@clone_tour.id}/")
      end
      flash[:flash_msg]="This is your New Cloned tour. "
      redirect_to tour_show_path(current_user_name,@clone_tour.id)
    else
      flash[:upload_error] = "To clone this tour.<br />"
      #~ if !@tour.title?
        #~ flash[:upload_error1] = "Please fill Title."
      #~ end
      #~ if !@tour.description? || @tour.description=="0" || @tour.description=="-"
        #~ flash[:upload_error2] = "Please fill Description."
      #~ end
      #~ if !@tour.category?
        #~ flash[:upload_error3] = "Please fill Category."
      #~ end
      #~ if !@tour.difficulty?
        #~ flash[:upload_error4] = "Please fill Difficulty."
      #~ end
      #~ if !@tour.audio
        #~ flash[:upload_error5] = "Please Upload an Audio."
      #~ end
      #~ if !@tour.author?
        #~ flash[:upload_error6] = "Please fill Author name."
      #~ end
      if @tour.stops.size<4
        flash[:upload_error7] = "There should be atleast 2 Stops."
      end
      redirect_to tour_show_path(current_user_name, @tour.id)
    end
  end

  def create_tour
     session[:admin_panel] = nil
    if current_user
      @user=current_user
      @tour_count=@user.tours
      @length=@tour_count.length
      @check_website_tour=@tour_count.find_all_by_created_from("Website")
      @check_iphone_tour=@tour_count.find_all_by_created_from("iPhone")
    end
  end

  def access_values
     if params[:is_stop]
     @stop_count=params[:is_stop].split(',').count("1")
     @stop_count+=1 if params[:is_stop].last=="0"
   end
 	  if !params[:data].empty? && !params[:title].empty? && !params[:is_stop].empty? && params[:title].length>=5 && params[:title].length<=30 && @stop_count>=4 && @stop_count<=22
      @latitude_array = []
      @longitude_array = []
      @stop_array=[]
      @tours_stops_array=[]
      @tour_tracks_array=[]
      @is_stop=params[:is_stop].split(',')
      @data = params[:data]
      @data = @data.gsub("(","").gsub(")","").split(",")
      @data && @data.each_with_index do |val,index|
        @latitude_array << val if index.even?
        @longitude_array << val if index.odd?
      end
      @tour=Tour.create(:title=> params[:title],:category=>0,:description=>"0", :difficulty=>0, :author=>current_user.username,:price=>0,:duration=>0,:rating=>0,:user_id=>current_user.id ,:length=>params[:distance].to_f*1000,:status=>1, :created_from=>"Website", :number_of_stops=>@stop_count)
      #~ tour_saved = (@tour.save)? true : false
      #~ @stops=@tour.stops
      @stop_last_id=Stop.last.id
      sequence_value=0
      @latitude_array && @latitude_array.each_with_index do |latitude,index_lat|
        @longitude_array && @longitude_array.each_with_index do |longitude,index_long|
          @is_stop && @is_stop.each_with_index do |is_this_stop,stop_index|
            #~ if !@stops.empty?
              #~ @stop_num=@tour.stops.last.name.gsub(/[A-Za-z]/,"").to_i+1
              #~ @stop_name="Stop#{@stop_num}"
            #~ else
              @stop_name="Stop#{sequence_value}"
            #~ end
            if index_lat == index_long && index_lat==stop_index && index_long==stop_index
              #~ if stop_index==0
                #~ sequence_value=0
              #~ elsif @is_stop[stop_index]=="1" ||  @is_stop[stop_index]==@is_stop.last
                #~ sequence_value=sequence_value+1
              #~ end
              @stop_id=@stop_last_id+1+sequence_value
              if @is_stop[stop_index].to_i==1 || (@is_stop[stop_index].to_i==0 && stop_index==(@is_stop.length-1))
                stop_str=""
                @stop=Stop.create(:name=>@stop_name, :text=>"", :latitude=>@latitude_array[index_lat].to_f, :longitude=>@longitude_array[index_long].to_f, :altitude=>0)
                stop_str="("+"'#{@stop_name}','',#{@latitude_array[index_lat].to_f},#{@longitude_array[index_long].to_f},0,'#{Time.current}','#{Time.current}'"+")"
                @stop_array<<stop_str
                tours_stops_str=""
                #~ @tour_stops=ToursStop.create(:tour_id=>@tour.id, :stop_id=>@stop.id, :sequence=>stop_index)
                tours_stops_str="("+"#{@tour.id},#{@stop.id},#{sequence_value}"+")"
                @tours_stops_array<<tours_stops_str
                sequence_value=sequence_value+1
              end
              tour_tracks_str=""
              if @is_stop[stop_index].to_i==0 && stop_index==(@is_stop.length-1)
                #~ @tour_tracks=TourTrack.create(:tour_id=>@tour.id, :latitude=>@latitude_array[index_lat].to_f, :longitude=>@longitude_array[index_long].to_f, :altitude=>0, :is_stop=>1)
                tour_tracks_str="("+"#{@tour.id},#{@latitude_array[index_lat].to_f},#{@longitude_array[index_long].to_f},0.0,1"+")"
              else
                #~ @tour_tracks=TourTrack.create(:tour_id=>@tour.id, :latitude=>@latitude_array[index_lat].to_f, :longitude=>@longitude_array[index_long].to_f, :altitude=>0, :is_stop=>@is_stop[stop_index].to_i)
                tour_tracks_str="("+"#{@tour.id},#{@latitude_array[index_lat].to_f},#{@longitude_array[index_long].to_f},0.0,#{@is_stop[stop_index].to_i}"+")"
              end
              @tour_tracks_array<<tour_tracks_str
            end
          end
        end
      end
      create_table_entries_mysql(@stop_array.join(','),@tours_stops_array.join(','),@tour_tracks_array.join(','))
      render :update do |page|
        page.redirect_to tour_details_tours_path(:tour_id=>@tour.id)
        #~ page.redirect_to tour_show_path(current_user_name, @tour.id)
      end
    else
      render :update do |page|
        if params[:data].empty? && params[:title].empty?
          page.alert("Please fill title and select stops for the Tour")
        elsif params[:data].empty?
          page.alert("No stops selected..")
        elsif @stop_count<4 
          page.alert("Sorry, a tour needs atleast 4 stops to be saved.")
        elsif params[:title].empty?
          page.alert("Please fill title")
       elsif @stop_count>22
          page.alert("Can't create more than 22 stops")
        else
          page.alert("Title should be between 5 to 30 characters")
        end
      end
    end
  end

  def tour_details
    @tour=Tour.find(params[:tour_id])
    @categories=Category.find(:all)
  end
  
  def create_tour_details
        @tour=Tour.find(params[:tour_id])
    @categories=Category.find(:all)
      file_present=@tour.check_for_existence
      if file_present==true
        @tour.take_recorded_audio_from_server
      end
    @tour.update_attributes(:title=>params[:tour][:title],:price=>params[:tour][:price], :category=>params[:tour][:category].to_f, :author=>params[:tour][:author], :description=>params[:tour][:description], :difficulty=>params[:tour][:difficulty], :status=>1)
    @tour.save
     if params[:tour][:uploaded_audio].nil?
      @audio_present=0
    else
      @audio_present=1
      audio={"uploaded_data"=>params[:tour][:uploaded_audio]}
      @audio = Audio.new(audio)
      if @audio.valid?
        @audio.is_audio = 1
        @audio_is_audio = 1
        @tour.audio = @audio
        if get_audio_file_duration<=240
          @audio_status=1
        else
          @audio_status=0
        end
      else
        @audio_is_audio = 0
      end
    end
       
    if params[:tour][:uploaded_image].nil?
      @image_present=0
    else
      image={"uploaded_data"=>params[:tour][:uploaded_image]}
      @image = Image.new(image)
      @image_present=1
      if @image.valid?
        @image_is_image=1
        @tour.image = @image 
      else
        @image_is_image=0
      end
    end
 
   #~ if  @tour && @tour.description!="-" && @tour.description!="0" &&  @tour.category!=0 && @audio_present==1 && @audio_is_audio == 1 && @image_present==1 && @image_is_image==1 && @audio_status==1   
      if  @tour && ((@audio_status==1 && @audio_is_audio == 1) || @audio_present==0) && (@image_is_image==1 || @image_present==0) && @tour.title.length >= 5  
      flash[:flash_msg] = "Tour Created Successfully!"
      redirect_to tour_show_path(current_user_name, @tour.id)
    else
      #~ if @tour.category==0
        #~ flash.now[:category_error]="Please select Category. <br />"
      #~ end
      #~ if  @tour.description=="-" || @tour.description=="0"
        #~ flash.now[:description_error]="Please fill Description.<br />"
      #~ end
      
         
      if @tour.title.length<5
        flash.now[:title_error]="Title can not be less than 5 characters<br />"
      end      
      
      if @audio_status==0
        flash.now[:audio_size_error]="Audio duration should be less than 4 Minutes.<br />"
      end
      #~ if @audio_present==0
        #~ flash.now[:audio_present]="Please Attach an Audio file.<br />"
      #~ end  
      if @audio_is_audio == 0
        flash.now[:audio_valid]="Please attach a valid  audio file (mp3 file under 1 minute of length)<br />"
      end 
      #~ if @image_present==0
        #~ flash.now[:image_present]="Please Attach an Image file.<br />"
      #~ end  
      if @image_is_image == 0
        flash.now[:image_valid]="Please Attach an Valid Image file (Less than 2MB).<br />"
      end
 			render :action => "tour_details"
		end
    load_all_values
	end
  
  def overview_audio
    if params[:tour_id] && Tour.exists?(params[:tour_id]) && !current_user.nil?
      @tour=Tour.find(params[:tour_id])
      if @tour.user_id==current_user.id || session[:admin_panel]==1 || session[:admin_panel]==2
        @audio=@tour.audio
        if !@audio.nil?
          send_file "#{@audio.public_filename}", :type=>'audio/mpeg' ,:disposition=>'inline'
        else
          flash[:upload_error]="No Overview Audio for this Tour."
          redirect_to tour_show_path(current_user_name, @tour.id)
        end
      else
        flash[:flash_error_msg]="Permission Denied."
        redirect_to root_path
      end
    else
      flash[:flash_error_msg]="No such Tour found."
      redirect_to root_path
    end
  end
  
  def overview_image
    if params[:tour_id] && Tour.exists?(params[:tour_id]) && !current_user.nil?
      @tour=Tour.find(params[:tour_id])
      if @tour.user_id==current_user.id || session[:admin_panel]==1 || session[:admin_panel]==2
        @image=@tour.image
        if !@image.nil?
          if params[:show]
            send_file "#{@image.public_filename}", :type=>'image/jpg' ,:disposition=>'inline'
          else
            send_file "#{@image.public_filename(:iphone_img)}", :type=>'image/jpg' ,:disposition=>'inline'
          end          
        else
          flash[:upload_error]="No Overview Image for this Tour."
          redirect_to tour_show_path(current_user_name, @tour.id)
        end
      else
        flash[:flash_error_msg]="Permission Denied."
        redirect_to root_path
      end
    else
      flash[:flash_error_msg]="No such Tour found."
      redirect_to root_path
    end
  end
  
  def security_alert
    redirect_to root_path
  end
  
  def change_length
    
   @tour = Tour.find(params[:tour_id].to_i)   if Tour.exists?(params[:tour_id].to_i)
  length_old= params[:length]
  if params[:length_type] == "miles"
  length=length_old.to_f* 1609.344
  @tour.length=length
  @tour.save(false)
  else
  length=length_old.to_f*0.304803706
  @tour.length=length
  @tour.save(false)
 end
 
render :update do |page|
 page.redirect_to tour_show_path(current_user_name, @tour.id)
end
  end
  

  
  private
   def authenticate_image
     if !logged_in?
      authenticate_or_request_with_http_basic do |username, password| 
          @user=User.authenticate(username,password)
        end
      end
      if current_user
        if current_user.user_type == 0
        session[:admin] = 1
      elsif current_user.user_type == 2
        session[:admin] = 2
      end
      end
    end
end
 