require 'rubygems'
require 'net/http'
require 'net/https'
require 'uri'
class UsersController < ApplicationController
  #~ ssl_required :create unless Rails.env.development?
  protect_from_forgery :except=>["create","update"]
  layout :change_layout, :only => ["edit", "update"]
  layout "new", :only =>["new", "create","edit",'update','update_snail_address']
  before_filter :require_ssl, :only=>['edit', 'update']
  before_filter :login_required, :only=>['edit', 'update']
  
  #~ def create
  #~ if request.post?
  #~ if RAILS_ENV == "development" || request.env['HTTPS'] == 'on'
  #~ if params[:api]
  #~ @user = User.new
  #~ @error = 1
  #~ @user, @error, @errors = check_user_params
  #~ if @error == 0
  #~ @user.username = params[:username]
  #~ @user.password = params[:password]
  #~ @user.password_confirmation = params[:password]
  #~ @user.email = params[:email]
  #~ end
  #~ else
  #~ @error = 0
  #~ @user = User.new(params[:user])
  #~ end
  #~ cookies.delete :auth_token
  #~ if @error == 0 && (RAILS_ENV == "development"  || params[:secret]== $secret)
  #~ if @user.save && @user.errors.empty?
  #~ redirect_to :controller => "admin", :action => "users"
  #~ flash[:flash_msg]="User #{@user.username} successfully created"
  #~ respond_to do |format|
  #~ format.xml {render :xml => get_success_message(@user)}
  #~ format.json {render :json => get_success_message(@user)}
  #~ end
  #~ else
  #~ get_user_error(@user)
  #~ render_with_error
  #~ end
  #~ else
  #~ render_with_error
  #~ end
  #~ else
  #~ collect_req_errors("Invalid Port - use a secured connection")
  #~ render_with_error
  #~ end
  #~ else
  #~ collect_req_errors("Invalid HTTP Method")
  #~ render_with_error
  #~ end
  #~ end

  def new
    
  end

  def create
    if request.post?
      @user = User.new
      @user.attributes = strip_for_values(@user, params[:user])
      @user.paypal_email=""
      if @user.valid? && @user.save
        if session[:admin_panel]==1 ||  session[:admin_panel]==2
          redirect_to :controller => "admin", :action => "users"
          flash[:flash_msg]="User #{@user.username} successfully created"
        else
          self.current_user=User.authenticate(@user.username,params[:user][:password])
          UserMailer.deliver_signup_success(@user, "Welcome to Geotrio","You had been Signed Up")
          #~ flash[:logout_notice]="Login to access your account"
          #~ redirect_to  new_session_path
           redirect_to user_edit_path(:user_name=> self.current_user.username)
        end
      else
        render :action => 'new'
      end
    else
      render :action => 'new'
    end
  end
  
  def edit
    if session[:admin_panel]==1 && session[:user]==1
      @user = User.find_by_username(params[:user_name])
    else
      @user = User.find(current_user.id)
    end
  end

  def update
    if session[:admin_panel]==1 && session[:user]==1
      @user = User.find_by_id(params[:id])
    else
      @user = User.find(current_user.id)
    end
    @user.attributes = strip_for_values(@user, params[:user])
    if @user.valid? && @user.save && params[:user].size!=3
      #~ if @user.paypal_email!=""
        #~ @user.update_attribute('paypal_verification_status', 1)
      #~ else
        #~ @user.update_attribute('paypal_verification_status', 0)
      #~ end
      flash[:update_notice] = "Profile updated successfully"
      if !params[:tour_id].nil? && !params[:tour_id].empty? && @user.i_agree==true
        redirect_to :controller=>"tours",:action=>"change_status_to_review",:tour_id=>params[:tour_id] 
      elsif session[:admin_panel] == 1 && session[:user] == 1 && @user.username != current_user_name
        redirect_to tours_path(:user_id => @user.id)
        flash[:login_notice]="#{@user.username}'s Profile succesfully Updated"       
      else
        redirect_to tours_index_path(:user_name => current_user.username)
        flash[:login_notice]="Profile Updated successfully"
      end
    elsif params[:user].size==3
      #~ From Statistics index page
      @user.snail_address=@user.snail_address.squish
      @user.save
       flash[:success]="Snail Address updated successfully"
        redirect_to statistics_path
    else
       render :action => 'edit'
     end
     
  end

  def verify_paypal
    if params[:from_profile]=="true"
      $from_profile=true
       $from_profit=false
    elsif params[:from_profit]=="true"
      $from_profit=true
      $from_profile=false
    end
    uri = URI.parse("#{PAYPAL_CONFIG['nvp_api_url']}")
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true
    http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    request = Net::HTTP::Post.new(uri.request_uri)
    request.set_form_data({'METHOD'=>'SetAuthFlowParam','USER'=>PAYPAL_CONFIG['login'], 'PWD'=>PAYPAL_CONFIG['password'],'SIGNATURE'=>PAYPAL_CONFIG['signature'],'VERSION'=>'60.0','RETURNURL'=>"#{PAYPAL_CONFIG['host_name']}/users/get_paypal_email",'CANCELURL'=>"#{PAYPAL_CONFIG['host_name']}/users/get_paypal_email",'LOGOUTURL'=>"#{PAYPAL_CONFIG['host_name']}/users/get_paypal_email",'SERVICENAME1'=>'Name','SERVICEDEFREQ1'=>'Required','SERVICENAME2'=>'Email','SERVICEDEFREQ2'=>'Required'})
    response, body = http.request(request)
    redirect_to "#{PAYPAL_CONFIG['set_auth_flow_url']}#{URI.decode(body.split(/&/).first.split(/=/).last)}"
  end

  def get_paypal_email
     @user=current_user
    uri = URI.parse("#{PAYPAL_CONFIG['nvp_api_url']}")
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true
    http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    request = Net::HTTP::Post.new(uri.request_uri)
    request.set_form_data({'METHOD'=>'GetAuthDetails','USER'=>PAYPAL_CONFIG['login'], 'PWD'=>PAYPAL_CONFIG['password'],'SIGNATURE'=>PAYPAL_CONFIG['signature'],'VERSION'=>'60.0','token'=>params[:token]})
    response, body = http.request(request)
    if body.split(/&/)[6].split(/=/).last == "Success" && body.split(/&/)[2].split(/=/).last!="Failure"
      @paypal_email=URI.decode(body.split(/&/)[3].split(/=/).last)
     @user.paypal_email=@paypal_email
     @user.paypal_verification_status=true
     @user.save
      flash[:notice]="Your PayPal Email ID was verified Successfully."
    elsif body.split(/&/)[2].split(/=/).last == "Failure"
      @paypal_email=current_user.paypal_email
    else
      #~ @paypal_email=""
      flash[:password_error]="Incorrect PayPal Email ID. "
    end
    if  $from_profile==true
      $from_profile=false
      redirect_to user_edit_path(:user_name => current_user.username)
    else
      $from_profit=false
      redirect_to statistics_path
    end
  end
  
 def suscribe_mail
@user=User.find(params[:user_id])
@user.subscribe = 1
@user.save(false)
flash[:flash_error_msg] = "You are now subscribed to Geotrio's mailing list"
redirect_to user_edit_path(:user_name=> @user.username)
end
     
  def unsuscribe_mail
@user=User.find(params[:user_id])
@user.subscribe = 0
@user.save(false)
flash[:flash_error_msg] = "You have successfully unsubscribed from Geotrio's mailing list"
  redirect_to user_edit_path(:user_name=> @user.username)
end

  def update_snail_address
    @user = User.find_by_password_reset_code(params[:reset_code])
  if request.post?
    if params[:user][:snail_address] == ""
      flash[:flash_error_msg]  = "Snail Address can not be empty"
      redirect_to update_snail_address_path
    else
    @user=User.find(params[:user][:id])
    @user.snail_address = params[:user][:snail_address]
    @user.save false
    flash[:flash_sucess_msg] = "Snail address updated sucessfully please login to check"
     redirect_to login_path
    end
    end
  end
  
  #~ def fill_snail_address
    #~ @user=User.find(params[:user][:id])
    #~ @user.snail_address = params[:user][:snail_address]
    #~ @user.save false
    
  #~ end
  
  private
  def render_with_error
    respond_to do |format|
      #~ format.html {render :action=> 'new'}
      format.xml {render :xml => @errors}
      format.json {render :json => @errors}
    end
  end
    
  def check_user_params
    if params[:username] && params[:password] &&  params[:email] && params[:secret]
      @error = 0
      @errors = nil
      collect_req_errors("Invalid secret Key") if params[:secret]!=$secret
    else
      collect_req_errors("Required parameters missing")
      @error = 1
    end
    return @user, @error, @errors
  end
  
  def collect_req_errors(err)
    @errors = [:success => 0, :error => err]
    @errors.to_xml
  end
  
  def get_success_message(user)
    @msg = [:success => 1, :user_id => user.id]
    return @msg
  end
  
  def get_user_error(user)
    error = ""
    error=  error + ((user.errors['username'].class==Array)? user.errors['username'][0].to_s : user.errors['username']) + ', ' if user.errors['username']
    error = error + ((user.errors['password'].class==Array)? user.errors['password'][0].to_s : user.errors['password']) + ', ' if user.errors['password']
    error = error + ((user.errors['email'].class==Array)? user.errors['email'][0].to_s : user.errors['email'])  + ', ' if user.errors['email']
    @errors=  [:success => 0, :error => error[0..-3]]
  end
  
  def user_agreement
  end
  

end


 