module AdminHelper
  def sort_options
    [ 'All Tours', 'Live tours', 'Draft tours', 'Review tours', 'Deleted Tours' ]
  end
  
  def admin_sort_options
    ['Username', 'Email', 'No. of Tours']
  end 
  
  def account_sort_options
    ['Group name', 'Description', 'No. of users']
 end
 
 def user_sort_options
    ['Username', 'Email', 'No. of Tours']
 end

  def user_full_name(user)
    first_name = user.first_name
    last_name = user.last_name
    fullname = ((first_name.nil?)? "" : first_name)  + " "  + ((last_name.nil?) ? "" : user.last_name)
    return ((fullname.blank?) ? "-"  : fullname)
  end
  
  def check_user_status(user_id, account_id)
    @user_account=UserAccount.find_by_user_id_and_account_id(user_id, account_id)
    @user_account.nil? ? false : true
  end 

  def check_user_type(user_id, account_id)
    @user_account=UserAccount.find_by_user_id_and_account_id(user_id, account_id, :conditions=> ['user_type ="admin"'])
    @user_account.nil? ? false : true
  end 
  
  def unpaid_receipts(tour)
    upr=[]
    pr=[]
    tour.receipts.each do |r|
      if r.paypal_receipt
        pr << r.paypal_receipt.receipt_id
      else
        upr << r.id
      end
    end
    unpaid_rec=Receipt.find_all_by_id(upr)
    return unpaid_rec
  end
  
end
