# Methods added to this helper will be available to all templates in the application.
require 'date'
require 'time'
module ApplicationHelper

	def current_user_name
		current_user.username
	end

  def change_date_format(date)
    if date
		  date.strftime("%h %d, %Y %H:%M:%S")
		else
			"-"
		end
  end

  def status_of_the_tour(x)
    case x
    when 0
      return "<font color='violet'>Draft</font>"  
    when 1
      return "<font color='orange'>Revise</font>"
    when 2
      return "<font color='indigo'>Submitted for review</font>"
    when 3,4
      return "<font color='blue'>In review</font>"
    when 5
      return "<font color='green'>Approved</font>"
    when 6,7,8,9
      return "<font color='brown'>Processing Tour</font>"
    when 10
      return "<font color='green'>Live</font>"
    when -1
      return "<font color='red'>Rejected</font>"
    when -2
      return "<font color='#800517'>Deleted</font>"
    end
  end

  def pdf_image_tag(image, options = {})
    options[:src] = File.expand_path(RAILS_ROOT) + '/public/images/' + image
    tag(:img, options)
  end
  
  def get_username(user_id)
    return User.find(user_id).username
  end
end
