module StatisticsHelper
  def paid_receipts(tour)
    pr=[]
    tour.receipts.each do |r|
      pr << r.paypal_receipt.receipt_id if r.paypal_receipt
    end
    return pr.uniq.flatten
  end

  def unpaid_receipts(tour)
    upr=[]
    pr=[]
    tour.receipts.each do |r|
      if r.paypal_receipt
        pr << r.paypal_receipt.receipt_id
      else
        upr << r.id
      end
    end
    unpaid_rec=Receipt.find_all_by_id(upr)
    return unpaid_rec
  end
end
