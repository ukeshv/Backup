module ToursHelper
  def tour_difficulty(x)
    case x
    when 0,1
      return "Easy"
    when 2
      return "Medium"
    when 3,4,5
      return "Hard"
    else
      return "-"
    end
  end
  
  def sort_options_user
    [ 'All Tours', 'Live tours', 'Draft tours', 'Review tours']
  end

  def get_difficulty(tour)
    tour.difficulty
  end
  
  def get_price(tour)
    tour.price
  end
  
  def get_category(tour)
	  cat=Category.find_by_code(tour.category)
	  cat.nil? ? "0" : cat.code
  end

  def sequence(stop, tour_id)
    stop.seq(tour_id)
  end

  def status_of_the_tour_ctrl(tour)
    (tour.status == 0)? "<font color='orange'>Draft</font>" : (tour.status == 10)? "Live" : "<font color='orange'>Review</font>"
  end

  def rem_dollar(price)
    price.gsub!("$", "")
    return price.strip.to_s
  end

  def convert_meters_to_miles(tour_length)
    ((tour_length*0.000621371192)*10).round.to_f/10
  end

  def convert_meters_to_feet(tour_length)
    ((tour_length*3.2808399)*10).round.to_f/10
  end
  
  def tour_notification_null_values(tour,stopname)
    str=""
    if tour.audio.nil?
      str=str+"Please Upload Overview Audio.<br />"
    end
    if tour.stops.size<2
      str=str+"There should be atleast 2 Stops.<br />"
    end
    if tour.description.blank? || tour.description=="No description given" || tour.description=="0" || tour.description=="-"
      str=str+"Please fill Description.<br />"
    end
    if tour.category.blank? || tour.category==0
      str=str+"Please select Category.<br />"
    end
    if tour.difficulty.blank? || tour.difficulty==0
      str=str+"Please select Difficulty.<br />"
    end
    if tour.author.blank? || tour.author=="Please select Author"
      str=str+"Please fill Author name.<br />"     
    end   
   if !stopname.nil?
      str=str+"#{stopname}"     
    end
    return str
  end
end
