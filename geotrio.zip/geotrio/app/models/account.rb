class Account < ActiveRecord::Base
	has_many :user_accounts
	has_many :users, :through => :user_accounts, :conditions => ['user_accounts.user_type = "user"']
	has_many :all_users, :class_name => 'User', :source => :user, :through => :user_accounts
	has_many :admins, :source => :user, :through => :user_accounts, :conditions => ['user_accounts.user_type = "admin"']
  validates_presence_of  :name

	
	def self.sort_group_by_name(order)
    if order=="desc"
      self.all(:order=>['name DESC'])
    else
      self.all(:order=>['name'])
    end
	end

  def self.sort_group_by_description(order)
    if order=="desc"
      self.all(:order=>['description DESC'])
    else
      self.all(:order=>['description'])
    end
	end
	
	def self.group_admin_sort_group_by_name(order, user_accounts_ids)
    if order=="desc"
		  self.all(:conditions=>["id in (?)",user_accounts_ids],:order=>['name']).reverse
    else
      self.all(:conditions=>["id in (?)",user_accounts_ids],:order=>['name'])
    end
	end	

	def self.group_admin_sort_group_by_description(order, user_accounts_ids)
    if order=="desc"
      self.all(:conditions=>["id in (?)",user_accounts_ids],:order=>['description']).reverse
    else
      self.all(:conditions=>["id in (?)",user_accounts_ids],:order=>['description'])
    end
	end

	def self.sort_group_by_status(order)
    if order=="desc"
      self.all(:order=>['status DESC'])
    else
      self.all(:order=>['status'])
    end
	end

	def self.group_admin_sort_group_by_status(order, user_accounts_ids)
    if order=="desc"
      self.all(:conditions=>["id in (?)",user_accounts_ids],:order=>['status DESC'])
    else
      self.all(:conditions=>["id in (?)",user_accounts_ids],:order=>['status'])
    end
	end

  # def self.sort_group_by_status(order)
	
	def self.sort_group_by_no_of_users(order)
    if order=="desc"
		  self.all(:include =>{:user_accounts =>:user}).sort_by { |u| -u.users.size }
    else
      self.all(:include =>{:user_accounts =>:user}).sort_by { |u| -u.users.size }.reverse
    end
	end
	
	def self.group_admin_sort_group_by_no_of_users(order,user_accounts_ids)
    if order=="desc"
      self.all(:conditions=>["id in (?)",user_accounts_ids],:include =>{:user_accounts =>:user}).sort_by { |u| -u.users.size }
    else
      self.all(:conditions=>["id in (?)",user_accounts_ids],:include =>{:user_accounts =>:user}).sort_by { |u| -u.users.size }.reverse
    end
	end
 
	def self.group_search_by_keyword(key)
		self.find(:all, :conditions=>["(name like ? or description like ?) ", "%#{key}%", "%#{key}%"])
	end
	
	def self.group_admin_group_search_by_keyword(key,user_accounts_ids)
		self.find(:all, :conditions=>["id in (?) and (name like ? or description like ?)",user_accounts_ids, "%#{key}%", "%#{key}%"])
	end
	
end
