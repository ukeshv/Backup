class Attachment < ActiveRecord::Base
  def self.create_or_update_by_tour_id(tour_id)
    @attachment = self.find(:first, :conditions => ["attachable_id = ? and attachable_type = ?", tour_id, "Tour"])
    if @attachment.nil?
      @attachment = self.new
      @attachment.attachable_id = tour_id
    end
    @attachment.attachable_type = 'Tour'
    @attachment.content_type = 'audio/mpeg'
    @attachment.filename = 'overview.mp3'
    @attachment.is_audio = 1
    if @attachment.save
      return true 
    else
      return false
    end
  end

  def self.create_or_update_by_stop(stop_id, sequence)
    @attachment = self.find(:first, :conditions => ["attachable_id = ? and attachable_type = ?", stop_id, "Stop"])
    if @attachment.nil?
      @attachment = self.new
      @attachment.attachable_id = stop_id
    end
    @attachment.attachable_type = 'Stop'
    @attachment.content_type = 'audio/mpeg'
    @attachment.filename = "#{sequence}.mp3"
    @attachment.is_audio = 1
    if @attachment.save
      return true
    else
      return false
    end
  end
end