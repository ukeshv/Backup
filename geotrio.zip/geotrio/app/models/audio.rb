class Audio < Attachment
  belongs_to :attachable, :polymorphic => true
  has_attachment :content_type =>['audio/mp3','audio/mpeg'], :storage => :file_system, :max_size => 10.megabytes, :path_prefix=>"/files/"
  validates_as_attachment

  def full_filename(thumbnail = nil) 
    attach_id = (self.attachable_id || Attachment.find_by_id(self.parent_id).attachable_id)
    if   ((self.attachable_type || Attachment.find_by_id(self.parent_id).attachable_type) == "Stop")
     @stop = Stop.find_by_id(self.attachable_id || Attachment.find_by_id(self.parent_id).attachable_id)
     file_system_path = (thumbnail ? thumbnail_class : self).attachment_options[:path_prefix]
     File.join(RAILS_ROOT, file_system_path, "#{get_batch_number(@stop.tours.first.id)}/#{@stop.tours.first.id.to_s}/audio", file_name_for("stop"))
    else
     file_system_path = (thumbnail ? thumbnail_class : self).attachment_options[:path_prefix]
     File.join(RAILS_ROOT, file_system_path, "#{get_batch_number(attach_id)}/#{attach_id}/audio", file_name_for("tour"))
    end
  end
  
	def convert_audio
    public_fname = self.public_filename
    splited_file_path_id = public_fname.rindex('.')
    splited_file_path = public_fname[0..(splited_file_path_id)]
    a = "ffmpeg -i #{self.public_filename } -r #{splited_file_path}wav"
	  output = `#{a}`
  end  
  
  def file_name_for(data)
    extension = filename.scan(/\.\w+$/) # extracts extension
    if data == "tour"
      file_name = "overview"
    else
      file_name = @stop.tours_stops.first.sequence
    end     
    return "#{file_name}.mp3" # change the filename to fit your needs
  end
  
  def public_filename_caf
    self.public_filename.gsub('mp3', 'caf')
  end  
  
  private
  
  def get_batch_number(index)
     i = (index / 10000) + 1
     return i 
  end
end
