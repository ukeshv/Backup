class CampusLead < ActiveRecord::Base
  has_many :user_campus_tours, :dependent => :destroy
end
