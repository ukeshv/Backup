class CompletedStop < ActiveRecord::Base
end
