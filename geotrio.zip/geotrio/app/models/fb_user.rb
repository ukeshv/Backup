class FbUser < ActiveRecord::Base
  belongs_to :user
  has_many :played_tours
end
