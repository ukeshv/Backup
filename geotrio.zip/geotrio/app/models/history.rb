class History < ActiveRecord::Base
belongs_to :user
belongs_to :tour
  def self.find_tour_history(tour)
    tour.histories.all(:order => "created_at DESC")
  end

  def self.create_history(user_id, action, tour_id=nil, stop_id=nil)
    self.create(:user_id => user_id, :action => action, :tour_id => tour_id, :stop_id => stop_id)
  end
end
