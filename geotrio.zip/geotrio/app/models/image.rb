class Image < Attachment
	
  has_attachment :storage => :file_system, :max_size => 2.megabytes, :content_type => ['image/jpeg', 'image/pjpeg', 'image/jpg', 'image/gif', 'image/png', 'image/x-png', 'image/bmp'], :thumbnails => { :thumb => [150,150], :iphone_img => [320, 460]}, :path_prefix=>"/files/"
  validates_as_attachment
  belongs_to :attachable, :polymorphic => true
  def full_filename(thumbnail = nil) 
    attach_id = self.attachable_id || Attachment.find_by_id(self.parent_id).attachable_id
    if  ((self.attachable_type || Attachment.find_by_id(self.parent_id).attachable_type) == "Stop")
      @stop = Stop.find_by_id(attach_id)
      file_system_path = (thumbnail ? thumbnail_class : self).attachment_options[:path_prefix]
      File.join(RAILS_ROOT, file_system_path, "#{get_batch_number(@stop.tours.first.id)}/#{@stop.tours.first.id.to_s}/images", thumbnail_name_for(thumbnail))
    else
      file_system_path = (thumbnail ? thumbnail_class : self).attachment_options[:path_prefix]
      File.join(RAILS_ROOT, file_system_path, "#{get_batch_number(attach_id)}/#{attach_id}/images", thumbnail_name_for(thumbnail))
    end
  end
  
  def after_attachment_saved
    if self.parent_id
      image_object=Image.find_by_id(self.parent_id)
      current_stop = Image.find(self.parent_id).attachable
      @image_seq=self.parent_id
    else
      image_object = Image.find(self.id)
      current_stop = image_object.attachable
      last_img=Image.find_all_by_parent_id(self.id)
      @image_seq=self.id
    end
    if image_object.attachable_type=="Tour" || current_stop.blank?
      file_path_old= self.public_filename.split('/')
      file_path_old.pop
      file_path=file_path_old.join('/')
      if self.thumbnail=="thumb"
        File.rename("#{self.public_filename}", "#{file_path}/overview_thumb_img.jpg")
        self.filename="overview_thumb_img.jpg"
      elsif self.thumbnail=="iphone_img"
        File.rename("#{self.public_filename}", "#{file_path}/overview_iphone_img.jpg")
        self.filename="overview_iphone_img.jpg"
      else
        File.rename("#{self.public_filename}", "#{file_path}/overview.jpg")
        self.filename="overview.jpg"
      end
      save
    else
	    file_path_old= self.public_filename.split('/')
      file_path_old.pop
      file_path=file_path_old.join('/')
      @stop_seq=current_stop.tours_stops.first.sequence 
      if self.thumbnail=="thumb"
        File.rename("#{self.public_filename}", "#{file_path}/#{@stop_seq.to_s}_#{ @image_seq.to_s}_thumb.jpg")
        self.filename="#{@stop_seq.to_s}_#{ @image_seq.to_s}_thumb.jpg"
      elsif self.thumbnail=="iphone_img"
        File.rename("#{self.public_filename}", "#{file_path}/#{@stop_seq.to_s}_#{ @image_seq.to_s}_iphone_img.jpg")
        self.filename="#{@stop_seq.to_s}_#{ @image_seq.to_s}_iphone_img.jpg"
      else
        File.rename("#{self.public_filename}", "#{file_path}/#{@stop_seq.to_s}_#{ @image_seq.to_s}.jpg")
        self.filename="#{@stop_seq.to_s}_#{ @image_seq.to_s}.jpg"
      end
      save
    end
  end
  
  private
  
  def get_batch_number(index)
    i = (index / 10000) + 1
    i = (index / 10000) if (index % 10000) == 0
    return i
  end
end
