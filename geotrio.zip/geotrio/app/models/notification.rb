class Notification < ActiveRecord::Base
belongs_to :user

  def self.add_notification_log(user_id, status)
    @notify = Notification.new
    @notify.user_id = user_id
    @notify.message = status
    @notify.save
  end
end
