class PaypalReceipt < ActiveRecord::Base
  belongs_to :paypal_transaction
	belongs_to :receipt
end
