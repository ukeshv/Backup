class PaypalTransaction < ActiveRecord::Base
  belongs_to :user
  has_many :receipts, :through => :paypal_receipts
end
