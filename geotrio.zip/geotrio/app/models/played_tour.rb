class PlayedTour < ActiveRecord::Base
  belongs_to :fb_user
end
