class Receipt < ActiveRecord::Base
  belongs_to :tour
  belongs_to :paypal_transaction
  has_one :paypal_receipt
end
