class Stop < ActiveRecord::Base
  has_one :audio, :class_name=> "Audio",:as=>:attachable, :conditions=>"attachments.is_audio = true", :dependent => :destroy
  has_many :images, :class_name=> "Image",:as=>:attachable, :conditions=>"attachments.is_audio = false", :dependent => :destroy
  has_many :tours_stops, :dependent => :destroy
  has_many :tours,:through => :tours_stops

  #before_destroy :change_status_for_tour_tracks_stop
  def get_file_name
    self.audio.filename if self.audio
  end

  def get_public_file_name
    self.audio.public_filename if self.audio
  end

  def destroy_audio(user, tour, admin_session)
    if user.tours.include?(tour) || admin_session==1 || admin_session==2
      if self.tours.include?(tour)
        self.audio.destroy
        return true
      else
        return false
      end
    else
      return false
    end
  end

  def get_all_images
    self.images
  end

  def destroy_image(image, user, tour, admin_session)
    if user.tours.include?(tour) || admin_session==1 || admin_session==2
      if self.tours.include?(tour)
        if self.images.include?(image)
          image.destroy
          return true
        end
      else
        return false
      end
    else
      return false
    end
  end

  def stop_sequence(tour_id)
    @tour_stops = self.tours_stops
    if @tour_stops
      @rec = @tour_stops.find_by_tour_id(tour_id)
      if @rec
        return @rec.sequence
      end
    end
  end

  def seq(tour_id)
    self.stop_sequence(tour_id)
  end

  def delete_tours_stops(tour_id)
    @tour_stops = self.tours_stops
    if @tour_stops
      @rec = @tour_stops.find_by_tour_id(tour_id)
      if @rec
        @rec.delete
      end
    end
  end

  def change_status_for_tour_tracks_stop
    tour = self.tours.first
    if tour
      tour_stop = self.tours_stops.find_by_tour_id(tour.id)
      sequence = tour_stop.sequence.to_i
      tour_tracks = TourTrack.find(:all, :conditions=>["tour_id = ? and is_stop = ?", tour.id, 1])
      logger.info "-------------start-------------------->"
      if tour_tracks && !tour_tracks.empty?
        logger.info "-------------in inside tour tracks-------------------->"
        logger.info "--------sequence - #{sequence}------------------------->"
        track = tour_tracks[sequence]
        logger.info "---------------track - #{track}------------------>"
        if track
          logger.info "---------------making stop 0------------------>"
          track.is_stop = 0
          track.save
        end
      end
      logger.info "---------------end------------------>"
    end 
  end
  
  def take_recorded_audio_from_server(tour_id,stop_seq)
    #~ 1)Remove old audio.
    #~ 2)fetch the audio from red5 .
    #~ 3)remove the tour_id from the appended part.
    #~ 4) convert the audio to mp3 using ffmpeg.
    #~ 5) save in attachments.
    #~ 6) delete the audio from the red5.
    self.audio=nil if self.audio
     audio_path="#{APP_CONFIG[:files_dir]}/#{get_batch_number(tour_id)}/#{tour_id}/audio/"
     FileUtils.mkdir_p "#{APP_CONFIG[:files_dir]}/#{get_batch_number(tour_id)}/#{tour_id}/audio/" if !File.directory?(audio_path) 
      Net::SFTP.start(RECORDER_CONFIG["host_name"], RECORDER_CONFIG["host_username"], :port =>RECORDER_CONFIG["ssh_port"], :password => RECORDER_CONFIG["host_password"]) do |sftp|
        sftp.download!("#{RECORDER_CONFIG["file_path"]}/#{tour_id}_#{stop_seq}.flv" , "#{APP_CONFIG[:files_dir]}/#{get_batch_number(tour_id)}/#{tour_id}/audio/#{stop_seq}.flv")
      end
      system("ffmpeg -i #{APP_CONFIG[:files_dir]}/#{get_batch_number(tour_id)}/#{tour_id}/audio/#{stop_seq}.flv -ar 44100 -ab 160k -ac 2 #{APP_CONFIG[:files_dir]}/#{get_batch_number(tour_id)}/#{tour_id}/audio/#{stop_seq}.mp3")
       Net::SFTP.start(RECORDER_CONFIG["host_name"], RECORDER_CONFIG["host_username"], :port =>RECORDER_CONFIG["ssh_port"], :password => RECORDER_CONFIG["host_password"]) do |sftp|     
        sftp.remove!("#{RECORDER_CONFIG["file_path"]}/#{tour_id}_#{stop_seq}.flv")
      end
       File.delete("#{APP_CONFIG[:files_dir]}/#{get_batch_number(tour_id)}/#{tour_id}/audio/#{stop_seq}.flv")
       audio_size=File.size("#{APP_CONFIG[:files_dir]}/#{get_batch_number(tour_id)}/#{tour_id}/audio/#{stop_seq}.mp3")
       att=Attachment.new(:parent_id=>nil, :attachable_id=>self.id, :attachable_type=>"Stop", :content_type=>"audio/mpeg", :filename=>"#{tour_id}_#{stop_seq}.mp3", :thumbnail=>nil, :size=>audio_size, :height=>nil, :width=>nil, :is_audio=>true)
       att.save
  end
  
    private
  
  def get_batch_number(index)
     i = (index / 10000) + 1
     return i 
  end
  
end
