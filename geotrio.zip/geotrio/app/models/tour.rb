class Tour < ActiveRecord::Base
	belongs_to :user
  has_many :tours_stops
  has_many :receipts, :dependent => :destroy
  has_many :tour_tracks, :dependent => :destroy
  has_many :stops, :through => :tours_stops, :dependent => :destroy
  has_many :histories, :dependent => :destroy
  has_many :user_campus_tours, :dependent => :destroy

  has_one :audio, :class_name=> "Audio", :as=>:attachable, :conditions=>"attachments.is_audio = true", :dependent => :destroy
	has_one :image, :class_name=> "Image", :as=>:attachable, :conditions=>"attachments.is_audio = false", :dependent => :destroy
	
	validates_presence_of :title, :message => "Title can't be blank!"
  validates_length_of :title, :minimum => 5 , :too_short => "Title should be at least 5 characters."
	#~ validates_presence_of :description, :message => "Description can't be blank!"
	#~ validates_presence_of :category, :message => "Category can't be blank!"
	#~ validates_presence_of :difficulty, :message => "Difficulty can't be blank!"
  #~ validates_presence_of :author, :message => "Author name can't be blank!"
  validates_length_of :author,    :within => 1..30 , :allow_blank => 'true', :message => "Author name should be between 1-30 characters."
  validates_format_of :author, :with => /^[A-Za-z0-9\/_.' ]+$/, :allow_blank => 'true', :message => "Author name can have letters, numbers, underscores,slash,apostrophe or dot (.)."
  #~ validates_presence_of :price, :message => "Price can't be blank!"
  #~ validates_numericality_of :price, :only_integer => false, :message => "Invalid Price!"

  before_destroy :delete_stop_attachment_records
  @@per_page = 10

  def self.find_tour(title)
	  self.find_by_title(title)
	end

  def check_if_current_user_tour(user)
    user.tours.include?(self)
  end

  def get_all_stops
    self.stops
  end

  #~ def assign_values(user)
  #~ self.user_id = user.id
  #~ self.author = user.username
  #~ self.length = 0
  #~ self.rating = 0
  #~ self.status = 0
  #~ end

  def get_the_stop(seq)
    self.stops.find(:first, :conditions => ['tours_stops.sequence =?', seq], :include=>"tours_stops")
  end

  def get_id
    self.id if self
  end
  
  def change_all_sequence(deleted_stop_id)
    self.tours_stops.each_with_index do |tour_stop, index|
      if deleted_stop_id < tour_stop.stop_id
        @stop = Stop.find_by_id(tour_stop.stop_id)
        if @stop.audio
          public_fname = @stop.audio.public_filename
          splited_file_path_id = public_fname.rindex('/')
          splited_file_path = public_fname[0..(splited_file_path_id)]
          filename = public_fname.split("/").last 
          FileUtils.mv "#{public_fname}", "#{splited_file_path}#{index}.mp3"
          #~ tour_stop.update_attribute('sequence', index)
        end  
        @stop.update_attribute('name',"Stop#{index}")
      end 
        tour_stop.update_attribute('sequence', index)
    end 
  end 
  
  def owner
    self.user.username
  end

  def get_category
    @category = Category.find_by_code(self.category)
    @category.name if @category
  end

  def self.sort_by_owner_name
    self.all(:order=>['users.username'], :include =>"user")
  end

  def self.sort_by_stops
    self.all(:include =>:stops).sort_by { |u| -u.stops.size }
  end

  def self.sort_by_stops_link(tour_status_params_admin,order)
    if order=="desc"
      self.all(:conditions=>['status in (?)',tour_status_params_admin], :include =>:stops).sort_by { |u| -u.stops.size }
    else
      self.all(:conditions=>['status in (?)',tour_status_params_admin], :include =>:stops).sort_by { |u| -u.stops.size }.reverse
    end
  end

  def self.group_admin_sort_by_stops_link(tour_status_params, order, user_accounts_ids)
    acc_users = []
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    if order=="desc"
      self.all(:include => [:user, :stops], :conditions=>['users.id in (?) and tours.status in (?)',acc_users,tour_status_params]).sort_by { |t| -t.stops.size }
    else
      self.all(:include => [:user, :stops], :conditions=>['users.id in (?) and tours.status in (?)',acc_users,tour_status_params]).sort_by { |t| -t.stops.size }.reverse
    end
  end
    
  def self.group_admin_sort_by_title(tour_status_params, order, user_accounts_ids)
    acc_users = []
    tours=[]
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    acc_users.collect{|x| tours << x.tour_ids}
    tours =tours.flatten.uniq
    if order=="desc"
      self.all(:conditions=>['id in (?) and status in (?)',tours,tour_status_params],:order=>["title"]).reverse
    else
      self.all(:conditions=>['id in (?) and status in (?)',tours,tour_status_params],:order=>["title"])
    end
  end
    
  def self.group_admin_sort_by_rating(tour_status_params, order, user_accounts_ids)
    acc_users = []
    tours=[]
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    acc_users.collect{|x| tours << x.tour_ids}
    tours =tours.flatten.uniq
    if order=="desc"
      self.all(:conditions=>['id in (?) and status in (?)',tours,tour_status_params]).sort_by { |t| -t.rating}
    else
      self.all(:conditions=>['id in (?) and status in (?)', tours,tour_status_params]).sort_by { |t| -t.rating}.reverse
    end
  end
    
  def self.group_admin_sort_by_status(tour_status_params, order, user_accounts_ids)
    acc_users = []
    tours=[]
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    acc_users.collect{|x| tours << x.tour_ids}
    tours =tours.flatten.uniq
    if order=="desc"
      self.all(:conditions=>['id in (?) and status in (?)',tours, tour_status_params]).sort_by { |t| -t.status}
    else
      self.all(:conditions=>['id in (?) and status in (?)',tours, tour_status_params]).sort_by { |t| -t.status}.reverse
    end
  end

  def self.sort_by_owner_name_link(tour_status_params_admin, order)
    if order=="desc"
      self.all(:conditions=>['tours.status in (?)',tour_status_params_admin], :order=>['users.username'], :include =>"user").reverse
    else
      self.all(:conditions=>['tours.status in (?)',tour_status_params_admin], :order=>['users.username'], :include =>"user")
    end
  end

  def self.group_admin_sort_by_owner_name_link(tour_status_params, order, user_accounts_ids)
    acc_users = []
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    if order=="desc"
      self.all(:include => [:user], :conditions=>['users.id in (?) and tours.status in (?)',acc_users,tour_status_params])
    else
      self.all(:include => [:user], :conditions=>['users.id in (?) and tours.status in (?)',acc_users,tour_status_params]).reverse
    end
  end

  def self.sort_by_tour
    self.all(:order => "title")
  end

  def self.sort_by_tour_link(order, id)
    if order=="desc"
      self.find(:all, :order=>"title", :conditions => ["status != ? and user_id=?", -2,id]).reverse
    else
      self.find(:all, :order=>"title", :conditions => ["status != ? and user_id=?", -2,id])
    end
  end

  def self.sort_by_created_at_link(order, id)
    if order=="desc"
      self.find(:all, :order=>"created_at", :conditions => ["status != ? and user_id=?", -2,id]).reverse
    else
      self.find(:all, :order=>"created_at", :conditions => ["status != ? and user_id=?", -2,id])
    end
  end

  def self.sort_by_status_link(order, id)
    if order=="desc"
      self.find(:all, :order=>"status", :conditions => ["status != ? and user_id=?", -2,id]).reverse
    else
      self.find(:all, :order=>"status", :conditions => ["status != ? and user_id=?", -2,id])
    end
  end

  def self.sort_by_tour_link_admin_panel(order, id)
    if order=="desc"
      self.find(:all, :order=>"title", :conditions => ["user_id=?",id]).reverse
    else
      self.find(:all, :order=>"title", :conditions => ["user_id=?",id])
    end
  end

  def self.sort_by_created_at_link_admin_panel(order, id)
    if order=="desc"
      self.find(:all, :order=>"created_at", :conditions => ["user_id=?",id]).reverse
    else
      self.find(:all, :order=>"created_at", :conditions => ["user_id=?",id])
    end
  end

  def self.sort_by_status_link_admin_panel(order, id)
    if order=="desc"
      self.find(:all, :order=>"status", :conditions => ["user_id=?",id]).reverse
    else
      self.find(:all, :order=>"status", :conditions => ["user_id=?",id])
    end
  end

  def self.sort_by_ratings
    self.all(:order => "rating DESC")
  end

  def self.search_by_keyword(key)
    self.find(:all, :conditions=>["title like ? or users.username like ?", "%#{key}%", "%#{key}%"], :include => "user")
  end  
  
  def self.search_by_keyword_user(key,user_id)
    self.find(:all, :conditions=>["title like ? and user_id=? and status!=?", "%#{key}%", user_id,-2], :include => "user")
  end

  def self.group_admin_search_by_keyword(key,user_accounts_ids)
    acc_users = []
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    self.find(:all,:include => [:user], :conditions=>["(users.id in (?) and (title like ? or users.username like ?))",acc_users, "%#{key}%", "%#{key}%"])
  end

  def get_all_points
    self.tour_tracks.all(:conditions=>['is_stop =?', 1])
  end

  def self.order_by_review_default
    arr = []
    arr << Tour.find_all_by_status(4)
    arr << Tour.all(:conditions=>['status != ?', 4])
    return arr.flatten
  end
  
 def self.order_by_review_default_user(user_id)
    arr = []
    arr << Tour.find_all_by_status_and_user_id(4,"#{user_id}")
    arr << Tour.all(:conditions=>['status != ? and status!=-2 and user_id=?', 4,"#{user_id}"])
    return arr.flatten
  end
  
   def self.order_by_review_default_user_admin(user_id)
    arr = []
    arr << Tour.find_all_by_status_and_user_id(4,"#{user_id}")
    arr << Tour.all(:conditions=>['status != ? and user_id=?', 4,"#{user_id}"])
    return arr.flatten
  end
  
  def self.group_admin_order_by_review(user_accounts_ids)
    acc_users = []
    tours=[]
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    acc_users.collect{|x| tours << x.tour_ids}
    tours =tours.flatten.uniq
    arr = []
    arr << Tour.find_all_by_status(4)
    arr << Tour.all(:conditions=>['id in (?) and status != ?', tours, 4])
    return arr.flatten
  end
 
  def self.order_by_draft
    Tour.all(:conditions=>['status=?',0], :order => "status DESC")
  end
  
 def self.order_by_draft_user(user_id)
    Tour.all(:conditions=>['status=? and user_id=?',0,user_id], :order => "status DESC")
  end

  def self.group_admin_order_by_live(user_accounts_ids)
    acc_users = []
    tours=[]
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    acc_users.collect{|x| tours << x.tour_ids}
    tours =tours.flatten.uniq
    arr = []
    arr << Tour.all(:conditions=>['id in (?) and status = ?', tours, 10], :order=> 'status DESC')
    return arr.flatten
  end
    
  def self.group_admin_order_by_draft(user_accounts_ids)
    acc_users = []
    tours=[]
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    acc_users.collect{|x| tours << x.tour_ids}
    tours =tours.flatten.uniq
    arr = []
    arr << Tour.all(:conditions=>['id in (?) and status = ?', tours, 0], :order=> 'status DESC')
    return arr.flatten
  end

  def self.group_admin_order_by_deleted(user_accounts_ids)
    acc_users = []
    tours=[]
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    acc_users.collect{|x| tours << x.tour_ids}
    tours =tours.flatten.uniq
    arr = []
    arr << Tour.all(:conditions=>['id in (?) and status = ?', tours, -2], :order=> 'status DESC')
    return arr.flatten
  end
    
  def self.group_admin_order_by_review_state(user_accounts_ids)
    acc_users = []
    tours=[]
    user_accounts_ids.collect{|x| acc_users << x.all_users}
    acc_users = acc_users.flatten.uniq
    acc_users.collect{|x| tours << x.tour_ids}
    tours =tours.flatten.uniq
    arr = []
    arr << Tour.all(:conditions=>['id in (?) and status = ? or status = ?', tours, 3,4], :order=> 'status')
    return arr.flatten
  end

  def self.order_by_live
    Tour.all(:conditions=>['status=?',10], :order => "status")
  end
  
  def self.order_by_live_user(user_id)
    Tour.all(:conditions=>['status=? and user_id=?',10,user_id], :order => "status")
  end

  def self.order_by_deleted
    Tour.all(:conditions=>['status=?',-2], :order => "status")
  end
  
  def self.order_by_deleted_user(user_id)
    Tour.all(:conditions=>['status=? and user_id=?',-2,user_id], :order => "status")
  end

  def self.order_by_review
    Tour.all(:conditions=>['status=? or status=?',3,4], :order => "status")
  end
  
  def self.order_by_review_user(user_id)
    Tour.all(:conditions=>['(status=? or status=?) and user_id=?',3,4,user_id], :order => "status")
  end
  
  def delete_stop_attachment_records
    self.stops && self.stops.each do |stop|
      stop.images = []
      stop.audio = nil
      stop.save
    end
    self.tours_stops.destroy
  end

  def self.before_submit_tour_for_review(tour)
    if tour.title? && tour.description? && tour.category? && tour.difficulty? && tour.audio && tour.author? && tour.stops.size>=2 && tour.description!="0"
      return true
    else
      return false
    end
  end
  
  def check_for_existence(stop_seq=nil)
    if stop_seq.nil?
      file_path="#{RECORDER_CONFIG["file_path"]}/#{self.id}_overview.flv"
    else
      file_path="#{RECORDER_CONFIG["file_path"]}/#{self.id}_#{stop_seq}.flv"
    end
    Net::SFTP.start(RECORDER_CONFIG["host_name"], RECORDER_CONFIG["host_username"],:port =>RECORDER_CONFIG["ssh_port"], :password => RECORDER_CONFIG["host_password"]) do |sftp|
       sftp.stat!(file_path) do |response|
        unless response.ok?
          return false
        end
      end
    end
     return true
  end
  
  def take_recorded_audio_from_server
    #~ 1)Remove old audio.
    #~ 2)fetch the audio from red5 .
    #~ 3)remove the tour_id from the appended part.
    #~ 4) convert the audio to mp3 using ffmpeg.
    #~ 5) save in attachments.
    #~ 6) delete the audio from the red5.
    self.audio=nil if self.audio
     audio_path="#{APP_CONFIG[:files_dir]}/#{get_batch_number(self.id)}/#{self.id}/audio/"
     FileUtils.mkdir_p "#{APP_CONFIG[:files_dir]}/#{get_batch_number(self.id)}/#{self.id}/audio/" if !File.directory?(audio_path) 
      Net::SFTP.start(RECORDER_CONFIG["host_name"], RECORDER_CONFIG["host_username"],:port =>RECORDER_CONFIG["ssh_port"], :password => RECORDER_CONFIG["host_password"]) do |sftp|
        sftp.download!("#{RECORDER_CONFIG["file_path"]}/#{self.id}_overview.flv" , "#{APP_CONFIG[:files_dir]}/#{get_batch_number(self.id)}/#{self.id}/audio/overview.flv")
      end
      system("ffmpeg -i #{APP_CONFIG[:files_dir]}/#{get_batch_number(self.id)}/#{self.id}/audio/overview.flv -ar 44100 -ab 160k -ac 2 #{APP_CONFIG[:files_dir]}/#{get_batch_number(self.id)}/#{self.id}/audio/overview.mp3")
      Net::SFTP.start(RECORDER_CONFIG["host_name"], RECORDER_CONFIG["host_username"],:port =>RECORDER_CONFIG["ssh_port"], :password => RECORDER_CONFIG["host_password"]) do |sftp|      
        sftp.remove!("#{RECORDER_CONFIG["file_path"]}/#{self.id}_overview.flv")
      end
       File.delete("#{APP_CONFIG[:files_dir]}/#{get_batch_number(self.id)}/#{self.id}/audio/overview.flv")
       audio_size=File.size("#{APP_CONFIG[:files_dir]}/#{get_batch_number(self.id)}/#{self.id}/audio/overview.mp3")
       att=Attachment.new(:parent_id=>nil, :attachable_id=>self.id, :attachable_type=>"Tour", :content_type=>"audio/mpeg", :filename=>"#{self.id}_overview.mp3", :thumbnail=>nil, :size=>audio_size, :height=>nil, :width=>nil, :is_audio=>true)
       att.save
  end
  
  private
  
  def get_batch_number(index)
     i = (index / 10000) + 1
     return i 
  end
  
end
