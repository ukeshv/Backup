class TourSearch < ActiveRecord::Base
  set_table_name "tour_search"
end
