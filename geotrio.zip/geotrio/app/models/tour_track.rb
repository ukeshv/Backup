class TourTrack < ActiveRecord::Base
  belongs_to :tour
end
