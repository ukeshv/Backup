require 'digest/sha1'
class User < ActiveRecord::Base
  # Virtual attribute for the unencrypted password
  include Authentication
  #~ include Authentication::ByPassword
  include Authentication::ByCookieToken
  attr_accessor :password

  has_many :tours
  has_many :notifications
  has_many :paypal_transactions
  has_many :histories
  has_many :user_accounts
  has_many :accounts, :through => :user_accounts
  has_one  :fb_user
  validates_presence_of     :username, :message => "Username can't be blank"  
  validates_presence_of     :email, :message => "Email can't be blank"  
  validates_presence_of     :password,                   :if => :password_required? , :message => "Password can't be blank"  
  validates_presence_of     :password_confirmation,      :if => :password_required? , :message => "Confirm Password can't be blank"  
  validates_presence_of     :email_confirmation,   :message => "Retype Email can't be blank"  
  validates_length_of       :password, :within => 4..25, :if => :password_required? , :message => "Please choose a password between 4-25 characters."  
  validates_confirmation_of :password,                   :if => :password_required? , :message => "Password & Confirm Password mismatch"
  validates_confirmation_of :email,           :if => :email_required? ,     :message => "Email & Retype Email mismatch"
  validates_length_of       :username,    :within => 3..25 , :message => "Please choose a username between 3-25 characters."  
  validates_length_of       :email,    :within => 3..100, :message => "This email is invalid. please choose another."  
  validates_format_of :email, :with => RE_EMAIL_OK, :message => "This email is invalid. please choose another."  
  validates_uniqueness_of   :username, :case_sensitive => false, :message => "Username has already been taken"  
  validates_format_of :username, :with => /[A-Za-z0-9_.]+/, :message => "Username can have letters, numbers, underscores, and one dot (.)."
  validates_format_of :first_name, :with => /^[A-Za-z ]+$/, :allow_blank => 'true', :message => "First Name can have letters only."
  validates_format_of :last_name, :with => /^[A-Za-z ]+$/, :allow_blank => 'true', :message => "Last Name can have letters only."
  validates_uniqueness_of   :email, :case_sensitive => false, :message => "Email has already been taken"  
  before_save :encrypt_password
  
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  attr_accessible :username, :email, :password, :password_confirmation,:paypal_email,:email_confirmation,:snail_address

  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  def self.authenticate(login, password)
    u=User.find(:first, :conditions=>['username=? and status=?',login,1])
    #~ u = find_by_username(login) # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  # Encrypts some data with the salt.
  def self.encrypt(password, salt)
    Digest::SHA1.hexdigest("--#{salt}--#{password}--")
  end

  # Encrypts the password with the user salt
  def encrypt(password)
    self.class.encrypt(password, salt)
  end

  def authenticated?(password)
    crypted_password == encrypt(password)
  end

  def remember_token?
    remember_token_expires_at && Time.now.utc < remember_token_expires_at 
  end

  # These create and unset the fields required for remembering users between browser closes
  def remember_me
    remember_me_for 2.weeks
  end

  def remember_me_for(time)
    remember_me_until time.from_now.utc
  end

  def remember_me_until(time)
    self.remember_token_expires_at = time
    self.remember_token            = encrypt("#{email}--#{remember_token_expires_at}")
    save(false)
  end

  def forget_me
    self.remember_token_expires_at = nil
    self.remember_token            = nil
    save(false)
  end

  # Returns true if the user has just been activated.
  def recently_activated?
    @activated
  end
  
  def send_reset_link(user)
    self.password_reset_code = Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{email}--") 
    self.save false
    UserMailer.deliver_password_reset_instructions(user)
  end 
  
  def snail_reset_link(user)
    self.password_reset_code = Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{email}--") 
    self.save false
  end
  
  def self.get_current_user_tours(user)
    user.tours.find(:all, :order=>"created_at DESC", :conditions => ["status != ?", -2])
  end

  def self.find_by_alphabet
    
  end
  
  def self.admin_search_by_keyword(key)
    self.find(:all, :conditions=>["(email like ? or username like ?) and user_type=?", "%#{key}%", "%#{key}%",2])
  end
  
  def self.sort_admins_by_username
    self.all(:order=>['username'], :conditions=>['user_type=?',2])
  end
  
  def self.sort_admins_by_email
    self.all(:order=>['email'], :conditions=>['user_type=?',2]).reverse
  end
  
  def self.sort_admins_by_no_of_tours
    self.all(:include =>:tours, :conditions=>['user_type=?',2]).sort_by { |u| -u.tours.size }
  end

  def self.sort_admins_by_username_link(order)
    if order=="desc"
      self.all(:order=>['username'], :conditions=>['user_type=?',2]).reverse
    else
      self.all(:order=>['username'], :conditions=>['user_type=?',2])
    end
  end

  def self.sort_admins_by_email_link(order)
    if order=="desc"
      self.all(:order=>['email'], :conditions=>['user_type=?',2]).reverse
    else
      self.all(:order=>['email'], :conditions=>['user_type=?',2])
    end
  end

  def self.sort_admins_by_no_of_tours_link(order)
    if order=="desc"
      self.all(:include =>:tours, :conditions=>['user_type=?',2]).sort_by { |u| -u.tours.size }
    else
      self.all(:include =>:tours, :conditions=>['user_type=?',2]).sort_by { |u| -u.tours.size }.reverse
    end
  end

  def self.sort_admins_by_member_since_link(order)
    if order=="desc"
      self.all(:order=>['created_at'], :conditions=>['user_type=?',2]).reverse
    else
      self.all(:order=>['created_at'], :conditions=>['user_type=?',2])
    end
  end
 
  def self.user_search_by_keyword(key)
    self.find(:all, :conditions=>["(email like ? or username like ?)", "%#{key}%", "%#{key}%"])
  end
 
  def self.group_admin_user_search_by_keyword(key,user_accounts_ids)
    acc_users = []
    user_accounts_ids.collect{|x| acc_users << x.user_ids}
    acc_users = acc_users.flatten.uniq
    self.find(:all, :conditions=>["(users.id in (?) and (email like ? or username like ?))",acc_users, "%#{key}%", "%#{key}%"])
  end

  def self.change_owner_search_by_keyword(key)
    self.find(:all, :conditions=>["username like ?", "%#{key}%"])
  end
   
  def self.sort_users_by_username
    self.all(:order=>['username'])
  end
  
  def self.sort_users_by_email
    self.all(:order=>['email'])
  end
  
  def self.sort_users_by_no_of_tours
    self.all(:include =>:tours).sort_by { |u| -u.tours.size }
  end

  def self.sort_users_by_no_of_tours_link(order)
    if order=="desc"
      self.all(:include =>:tours).sort_by { |u| -u.tours.size }
    else
      self.all(:include =>:tours).sort_by { |u| -u.tours.size }.reverse
    end
  end
  
  def self.group_admin_sort_users_by_no_of_tours_link(order,user_accounts_ids)
    acc_users = []
    user_accounts_ids.collect{|x| acc_users << x.user_ids}
    acc_users = acc_users.flatten.uniq
    if order=="desc"
      self.all(:conditions=>['users.id in (?)',acc_users],:include =>:tours).sort_by { |u| -u.tours.size }
    else
      self.all(:conditions=>['users.id in (?)', acc_users],:include =>:tours).sort_by { |u| -u.tours.size }.reverse
    end
  end
    
  def self.group_admin_sort_username(order,user_accounts_ids)
    acc_users = []
    user_accounts_ids.collect{|x| acc_users << x.user_ids}
    acc_users = acc_users.flatten.uniq
    if order=="desc"
      self.all(:conditions=>['users.id in (?)',acc_users],:include =>:tours).sort_by { |u| -u.tours.size }
    else
      self.all(:conditions=>['users.id in (?)', acc_users],:include =>:tours).sort_by { |u| -u.tours.size }.reverse
    end
  end

  def self.sort_list_users_to_account_by_username(account_all_users,order)
    user_ids=[]
    account_all_users.collect{|x| user_ids<< x.id}
    if order=="desc"
      self.all(:conditions=>['id in (?)',user_ids],:order=>['username']).reverse
    else
      self.all(:conditions=>['id in (?)',user_ids],:order=>['username'])
    end
  end

  def self.sort_list_users_to_account_by_email(account_all_users,order)
    user_ids=[]
    account_all_users.collect{|x| user_ids<< x.id}
    if order=="desc"
      self.all(:conditions=>['id in (?)',user_ids],:order=>['email']).reverse
    else
      self.all(:conditions=>['id in (?)',user_ids],:order=>['email'])
    end
  end

  def self.sort_list_users_to_account_by_no_of_tours(account_all_users,order)
    user_ids=[]
    account_all_users.collect{|x| user_ids<< x.id}
    if order=="desc"
      self.all(:conditions=>['id in (?)',user_ids]).sort_by{|u| u.tours.size}.reverse
    else
      self.all(:conditions=>['id in (?)',user_ids]).sort_by{|u| u.tours.size}
    end
  end

  protected
  # before filter
  def encrypt_password
    return if password.blank?
    self.salt = Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{username}--") if new_record?
    self.crypted_password = encrypt(password)
  end
    
  def password_required?
    crypted_password.blank? || !password.blank?
  end
  
  def email_required?
    !email.blank?
  end

  def self.all_notifications(user)
    user.notifications.all(:conditions => ['status = 0'])
  end
  
  def self.find_by_alphabet(text)
    self.all(:conditions=>['users.username like ?', "#{text}%"])
  end      
end
