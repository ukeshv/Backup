class UserCampusTour < ActiveRecord::Base
	  belongs_to :campus_lead
		belongs_to :tour
end
