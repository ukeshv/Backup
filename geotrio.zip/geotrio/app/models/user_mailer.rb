class UserMailer < ActionMailer::Base
	
	def password_reset_instructions(user)
    setup_email(user)
    @subject    += 'Reset your password'
    @body[:url]  = "#{APP_CONFIG[:site_url]}/reset/#{user.password_reset_code}"
  end

  def feedback(name, email, subject, content)
    @recipients = "contact@geotrio.com"
		@from        = email
		@subject     = "[Geotrio] "
		@sent_on     = Time.now
    @subject += subject
    @body[:url]  = content
  end
	
	def review_tour(name, email, subject, content,tour)
		@recipients = "contact@geotrio.com"
		@from        = email
		@subject     = "[Geotrio] "
		@sent_on     = Time.now
    @subject += subject
    @body[:url]  = content
		@tour=tour
	end
	
	def tour_submitted(user, subject, content,tour)
		setup_email(user)
		@sent_on = Time.now
    @subject += subject
    @body[:url]  = content
		@tour=tour
	end
	
	def tour_approved(user, subject, content,tour)
		setup_email(user)
		@sent_on = Time.now
    @subject += subject
    @body[:url]  = content
		@tour=tour
	end
	
	def tour_rejected(user, subject, content,tour,notification)
		setup_email(user)
		@sent_on = Time.now
    @subject += subject
    @body[:url]  = content
		@tour=tour
		@notification_reject=notification
	end
	
	def tour_revised(user, subject, content,tour,notification)
		setup_email(user)
		@sent_on = Time.now
    @subject += subject
    @body[:url]  = content
		@tour=tour
		@notification_message=notification
	end
	
	def signup_success(user, subject, content)
		@user=user
		@from="support@geotrio.com"
		@bcc = 'oded@geotrio.com'
		@recipients=user.email
		@sent_on = Time.now
    @subject = subject
    @body[:url]  = content
	end
	
	def snail_address_empty(user, subject, content)
		@user=user
		@from="support@geotrio.com"
		@recipients=user.email
		@sent_on = Time.now
		@subject     = "[Geotrio] "
    @subject += subject
    @body[:url]  = "#{APP_CONFIG[:site_url]}/update_snail_address/#{user.password_reset_code}"
	end
	
	def cheque_sent(user, subject,amount,content)
		@user=user
		@amount=amount
		@from="support@geotrio.com"
		@recipients=user.email
		@sent_on = Time.now
		@subject     = "[Geotrio] "
    @subject += subject
    @body[:url]  = content
	end
	
	def tour_live(tour)
		@content_type = "text/html"
		@recipients = "#{tour.user.email}"
		@from        = "admin@geotrio.com"
		@bcc = "oded@geotrio.com"
		@subject     = "[Geotrio] "
		@sent_on     = Time.now
		 #@subject += "[Geotrio] "
    #@body[:url]  = content
		@tour=tour
	end	
	
	def tour_draft(tour)
		@content_type = "text/html"
		@recipients = "#{tour.user.email}"
		@from        = "admin@geotrio.com"
		@bcc = "udhaya@railsfactory.org"
		@subject     = "[Geotrio] "
		@sent_on     = Time.now
		 #@subject += "[Geotrio] "
    #@body[:url]  = content
		@tour=tour
	end
	
		def whats_new_in_geotrio(user,subject,message)
    @user =user
    @sent_on = Time.now
		@from  = "geotrio@geotrio.com"
		@recipients = "#{user.email}"
		@subject   = subject
		@message = message
    #~ @body[:url]  = content
	end	
	
		def send_mail_to_friend(from,to,subject,message,name,tour)
		
		@user =name
		@tour =tour
    @sent_on = Time.now
		@from  = "Geotrio <no-reply@geotrio.com>"
		@from_store  = "#{from}"
		@recipients = "#{to}"
		@subject   = subject
		@message = message
    #~ @body[:url]  = content
	end
	
	
	protected
	def setup_email(user)
		@recipients = "#{user.email}"
		@from        = "admin@geotrio.com"
		@subject     = "[Geotrio] "
		@sent_on     = Time.now
		@body[:user] = user
	end
end
