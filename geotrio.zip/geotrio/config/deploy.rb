set :scm, :git
set :repository, "git@github.com:railsfactory/geotrio.git"
set :application, "geotrio"

set :geotrio_address, "192.160.13.123"
#set :geotrio_address, "bronze.rahul.net"

set :deploy_to, "/var/www/apps/#{application}"
set :user, "rails"
set :runner, "geotrio"
set :use_sudo, false

role :app, geotrio_address                   # Example Linode_address (or) EC2_Address
role :web, geotrio_address
role :db,  geotrio_address, :primary => true

namespace :init do
  desc "create database.yml"
  task :database_yml do
    set :db_user, "geotrio"
    set :db_pass, "g30.tr10"
    database_configuration =<<-EOF
---
login: &login
  adapter: mysql
  database: #{application}_production
  host: localhost
  username: #{db_user}
  password: #{db_pass}

development:
  <<: *login

EOF
    run "mkdir -p #{shared_path}/config"
    put database_configuration, "#{shared_path}/config/database.yml"
  end

end

namespace :localize do
  desc "copy shared configurations to current"
  task :copy_shared_configurations, :roles => [:app] do
    %w[database.yml].each do |f|
      run "ln -nsf #{shared_path}/config/#{f} #{current_path}/config/#{f}"
    end
  end
  desc "copy downloads folder to current"
  task :copy_downloads_folder, :roles => [:app] do
    #run "mkdir -p files"
    run "ln -nfs /var/www/geotrio/files /var/www/apps/geotrio/current/files"
  end 
end

namespace :deploy do
  desc "Restart Application"
  task :restart, :roles => :app do
    run "touch #{current_path}/tmp/restart.txt"
	end
end

after "deploy:setup", "init:database_yml"
after "deploy:symlink", "localize:copy_shared_configurations"
after "deploy:symlink", "localize:copy_downloads_folder"
