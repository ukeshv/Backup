APP_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/settings.yml")[RAILS_ENV].symbolize_keys
PAYPAL_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/paypal_settings.yml")[RAILS_ENV]
RECORDER_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/recorder_settings.yml")[RAILS_ENV]
AMAZON_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/amazon_s3.yml")[RAILS_ENV]
FACEBOOK_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/facebook_settings.yml")[RAILS_ENV]
