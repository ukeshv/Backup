ActionController::Routing::Routes.draw do |map|
  map.change_password '/password/change_password',:controller=>'passwords',:action=>'change_password'
   map.search_result '/home/search_result', :controller=>'home',:action=>'search_result'
   map.search_tour '/home/:tour_id/search_tour', :controller=>'home',:action=>'search_tour'
   map.search_tour_details '/home/:tour_id/search_tour_details', :controller=>'home',:action=>'search_tour_details'
  map.resources :users, :collection=>{:verify_paypal => :get, :get_paypal_email => :get, :user_agreement=>:get, :suscribe_mail => :get,:unsuscribe_mail=>:get}
  map.resources :stops, :collection=>{:delete_attachment => :get, :save_image => :post, :delete_image=>:get, :save_recorded_stop_audio=>:get}
  map.resources :tours, :collection=>{:delete_image => :get, :delete_audio => :get, :save_image => :post, :save_audio => :post, :change_status_to_review => :get, :approve_tour => :get, :reject_tour => :get, :revise_tour => :post, :change_status_to_recall => :get, :clone_tour=> :get, :create_tour => :get , :access_values=>:post, :tour_details=>:get, :create_tour_details=>:put, :save_edited_route=>:get, :save_recorded_overview_audio=>:get , :change_length=>:put}
  map.resources :statistics, :collection=>{:paypal_transaction=> :post, :show_transaction_history=> :get, :geotrio_payment_history=> :get, :tours_list=>:get, :tour_stats=>:get, :show_graph_static=>:get, :show_graph_dynamic=>:get, :show_campus_for_selected_date_range=>:get}
  map.resources :payments
  map.resource :session
  map.resource :admin_sessions
  map.resources :passwords
  map.resources :admin, :collection =>{:users => :get, :accounts => :get, :display_users_by_alphabet => :get, :create_account => :get,  :create_account_name => :get, :tasks => :get, :change_task_status => :get, :receipts => :get, :users_created_recently => :get, :users_activities_recently => :get, :pay_user => :get, :pay_cheque=>:get, :payment_history=>:get, :send_snail_address_mail=>:get,:info_mail=> :get, :send_info_mail => :put}
  map.resources :group_admin , :collection =>{:users => :get, :accounts => :get, :receipts => :get}
  map.resources :home, :collection => {:contact_mail => :post, :send_mail_to_friend=> :post}
  map.simple_captcha '/simple_captcha/:action', :controller => 'simple_captcha'
  map.tours_edit 'user/:user_name/tours/:tour_id/edit', :controller => "tours", :action => "edit"
  map.change_owner 'user/:user_name/tours/:tour_id/change_owner', :controller => 'admin', :action => 'change_owner'
  map.tour_show 'user/:user_name/tours/:tour_id', :controller => "tours", :action => "show"
  map.tour_show_stops 'user/:user_name/tours/:tour_id/stops', :controller => "tours", :action => "stops"
  map.tour_show_history 'user/:user_name/tours/:tour_id/history', :controller => "tours", :action => "history"
  map.map_route_edit 'user/:user_name/tours/:tour_id/edit_route', :controller => "tours", :action => "edit_route"
  map.embed_map 'tours/:tour_id/embed_map', :controller => "tours", :action => "embed_map"
  map.tour_show_routes 'user/:user_name/tours/:tour_id/routes', :controller => "tours", :action => "routes"
  map.tours_index 'user/:user_name/tours', :controller => "tours", :action => "index"
  map.stops_show 'user/:user_name/tours/:tour_id/stop/:sequence_id', :controller => "stops", :action => "show"
  map.create_stop_task '/tours/:tour_id/stop/:stop_id/:sequence_id', :controller => "tours", :action => "create_stop_task"
  map.create_tour_task '/tours_id/:tour_id', :controller => "tours", :action => "create_tour_task"
  map.user_edit 'user/:user_name/profile', :controller => "users", :action => "edit"
  map.login 'login', :controller => "sessions", :action => "new"
  map.logout 'logout', :controller => "sessions", :action => "destroy"
  map.connect 'api/v1/users/.:format', :controller => 'users', :action => 'create', :api => true
  #~ map.connect 'api/v1/tours/.:format', :controller => 'tours', :action => 'create', :api => true
  map.about '/about', :controller=>"home", :action=>"about"
  map.help '/help', :controller=>"home", :action=>"help"
  map.news '/news', :controller=>"home", :action=>"news"
  map.jobs '/jobs', :controller=>"home", :action=>"jobs"
  map.contact '/contact', :controller=>"home", :action=>"contact"
   map.photo_search '/home/:tour_id/overview_jpg_search', :controller=> 'home', :action=> 'photo_search'
  map.forgot '/forgot', :controller => 'passwords',:action => 'new'
  map.reset '/reset/:reset_code', :controller => 'passwords', :action => 'edit'
  map.update_snail_address '/update_snail_address/:reset_code', :controller => 'users', :action => 'update_snail_address'
  map.admin_login 'admin_login', :controller => "admin_sessions", :action => "new"
  map.admin_list 'admin_list',:controller=>"admin",:action=>"admin_list"
  map.add_users_to_account '/admin/add_users_to_account/:account_id',:controller=>"admin",:action=>"add_users_to_account"
  map.list_users_to_account '/group_admin/list_users_to_account/:account_id',:controller=>"group_admin",:action=>"list_users_to_account"
  map.add_admins_to_account '/admin/add_admins_to_account/:account_id',:controller=>"admin",:action=>"add_admins_to_account"
  map.remove_users_to_account '/admin/remove_users_to_account/:account_id',:controller=>"admin",:action=>"remove_users_to_account"
  
  map.root :controller => 'home', :action => 'index'
  map.photo '/tours/:tour_id/overview', :controller=> 'tours', :action=> 'photo'
 
  map.photo_jpg '/tours/:tour_id/overview.jpg', :controller=> 'tours', :action=> 'photo_jpg'
  map.stop_photo '/tours/:tour_id/stop/:sequence', :controller=> 'stops', :action=> 'stop_photo'
  map.stop_photo_jpg '/tours/:tour_id/stop/:sequence.jpg', :controller=> 'stops', :action=> 'stop_photo_jpg'
  map.overview_audio '/tours/:tour_id/overview.mp3', :controller=>'tours', :action=>'overview_audio'
  map.overview_audio_search '/tours/:tour_id/overview_audio_search.mp3', :controller=>'home', :action=>'overview_audio_search'
  map.stop_audio_search '/tours/:tour_id/stop_audio_search/:stop_seq.mp3', :controller=>'home', :action=>'stop_audio_search'
  map.overview_image '/tours/:tour_id/show/overview.jpg', :controller=>'tours', :action=>'overview_image'
  map.stop_image '/tours/:tour_id/stop/show/:stop_seq.jpg', :controller=>'stops', :action=>'stop_image'
  map.stop_audio '/tours/:tour_id/stop/:stop_seq.mp3', :controller=>'stops', :action=>'stop_audio'
  
  
  #~ map.match '*mp3', :controller=> 'application', :action=> 'send_mp3'
  map.security_alert '/files/:folder_index/:tour_id/:content/*mp3', :controller=>'tours', :action=>'security_alert'
  map.security_alert '/files/:folder_index/:tour_id/:content/*jpg', :controller=>'tours', :action=>'security_alert'
  map.kml '/tours/kml/:id.kml',:controller =>'tours', :action => 'kml'
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
 
  #~ match '/passwords/change_password'=>'passwords#change_password' , :as=>change_password
  map.play 'fb/:tour_id/play',:controller=>'fb/games',:action=>'play'
  map.resume_tour 'fb/:tour_id/resume_tour',:controller=>'fb/games',:action=>'resume_tour'
  map.canvas 'fb/canvas',:controller=>'fb/games',:action=>'canvas'
  
  
  map.resume_tour 'fb/resume_tour',:controller=>'fb/games',:action=>'resume_tour'
  
  map.play 'fb/played_tour/click',:controller=>'fb/games',:action=>'play'
  map.play 'fb/played_tour/click_resume',:controller=>'fb/games',:action=>'resume_tour'
  
  map.game_main 'fb/game_main',:controller=>'fb/games',:action=>'game_main'
  map.stop 'fb/stop',:controller=>'fb/games',:action=>'stop'
  
  
  map.canvas_tour 'fb/canvas/:tour_id',:controller=>'fb/games',:action=>'canvas'
  map.find_audio_for_stop 'fb/games/find_audio_for_stop',:controller=>'fb/games/',:action=>'find_audio_for_stop'
  
end