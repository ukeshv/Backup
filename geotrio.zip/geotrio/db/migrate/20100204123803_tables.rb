class Tables < ActiveRecord::Migration
  def self.up
    # #### #
    # Note : This is the latest DB schema
    # #### #
    sql=ActiveRecord::Base.connection()

    # #### #
    # Users Table
    # #### #
    sql.execute "
CREATE TABLE `users` (
  `id` int(16) NOT NULL auto_increment,
  `email` varchar(150) collate utf8_unicode_ci NOT NULL,
  `username` varchar(25) collate utf8_unicode_ci NOT NULL,
  `crypted_password` varchar(40) collate utf8_unicode_ci NOT NULL default '',
  `salt` varchar(40) collate utf8_unicode_ci NOT NULL,
  `status` int(3) NOT NULL default '1',
  `user_type` int(3) NOT NULL default '1',
  `first_name` varchar(100) collate utf8_unicode_ci default NULL,
  `last_name` varchar(100) collate utf8_unicode_ci default NULL,
  `signature` varchar(250) collate utf8_unicode_ci default NULL,
  `fb_name` varchar(100) collate utf8_unicode_ci default NULL,
  `tw_name` varchar(100) collate utf8_unicode_ci default NULL,
  `created_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  `remember_token` varchar(40) collate utf8_unicode_ci default NULL,
  `remember_token_expires_at` datetime default NULL,
  `password_reset_code` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"

    # #### #
    # Tours Table
    # #### #
    sql.execute "
CREATE TABLE `tours` (
  `id` int(16) NOT NULL auto_increment,
  `user_id` int(16) NOT NULL,
  `title` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` varchar(1000) collate utf8_unicode_ci NOT NULL,
  `status` int(3) NOT NULL,
  `author` varchar(100) collate utf8_unicode_ci NOT NULL,
  `price` varchar(100) collate utf8_unicode_ci NOT NULL default '0',
  `length` double NOT NULL,
  `duration` double NOT NULL,
  `difficulty` int(3) NOT NULL,
  `category` double NOT NULL,
  `rating` double NOT NULL,
  `number_of_ratings` int(16) NOT NULL default '0',
  `number_of_stops` int(4) NOT NULL default '0',
  `number_of_views` int(16) NOT NULL default '0',
  `number_of_downloads` int(16) NOT NULL default '0',
  `published_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `withdrawn_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tours_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"

    # #### #
    # Stops Table
    # #### #
    sql.execute "
CREATE TABLE `stops` (
  `id` int(16) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `text` varchar(1000) collate utf8_unicode_ci NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `altitude` double NOT NULL,
  `created_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"

    # #### #
    # Tours Stops Table
    # #### #
    sql.execute "
CREATE TABLE `tours_stops` (
  `id` int(11) NOT NULL auto_increment,
  `tour_id` int(16) NOT NULL,
  `stop_id` int(16) NOT NULL,
  `sequence` int(3) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `tour_id` (`tour_id`,`stop_id`),
  UNIQUE KEY `tour_id_2` (`tour_id`,`sequence`),
  KEY `stop_id` (`stop_id`),
  CONSTRAINT `tours_stops_ibfk_1` FOREIGN KEY (`tour_id`) REFERENCES `tours` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tours_stops_ibfk_2` FOREIGN KEY (`stop_id`) REFERENCES `stops` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"

    # #### #
    # Tour Tracks Table
    # #### #
    sql.execute "
CREATE TABLE `tour_tracks` (
  `id` int(16) NOT NULL auto_increment,
  `tour_id` int(16) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `altitude` double NOT NULL default '0',
  `is_stop` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `tour_id` (`tour_id`),
  CONSTRAINT `tour_tracks_ibfk_1` FOREIGN KEY (`tour_id`) REFERENCES `tours` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"

    # #### #
    # Tour Search Table
    # #### #
    sql.execute "
CREATE TABLE `tour_search` (
  `id` int(16) NOT NULL,
  `user_id` int(16) NOT NULL,
  `title` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` varchar(1000) collate utf8_unicode_ci NOT NULL,
  `author` varchar(100) collate utf8_unicode_ci NOT NULL,
  `price` varchar(100) collate utf8_unicode_ci NOT NULL,
  `length` double NOT NULL,
  `duration` double NOT NULL,
  `difficulty` int(3) NOT NULL,
  `category` double NOT NULL,
  `rating` double NOT NULL,
  `number_of_ratings` int(16) NOT NULL default '0',
  `number_of_stops` int(4) NOT NULL default '0',
  `number_of_views` int(16) NOT NULL default '0',
  `number_of_downloads` int(16) NOT NULL default '0',
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `published_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"

    # #### #
    # Registrations Table
    # #### #
    sql.execute "
CREATE TABLE `registrations` (
  `id` int(16) NOT NULL auto_increment,
  `user_id` int(16) default NULL,
  `device_id` varchar(150) collate utf8_unicode_ci NOT NULL,
  `application` int(3) NOT NULL default '0',
  `api_version` int(3) NOT NULL default '1',
  `tokens` text collate utf8_unicode_ci NOT NULL,
  `status` int(3) NOT NULL default '1',
  `created_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `registrations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"

    # #### #
    # Ratings Table
    # #### #
    sql.execute "
CREATE TABLE `ratings` (
  `id` int(16) NOT NULL auto_increment,
  `tour_id` int(16) NOT NULL,
  `user_id` int(16) NOT NULL,
  `rating` double NOT NULL,
  `created_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `tour_id` (`tour_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`tour_id`) REFERENCES `tours` (`id`),
  CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"
  end

  def self.down
    drop_table :users
    drop_table :tours
    drop_table :stops
    drop_table :tours_stops
    drop_table :tour_tracks
    drop_table :tour_search
    drop_table :registrations
    drop_table :ratings
  end
end
