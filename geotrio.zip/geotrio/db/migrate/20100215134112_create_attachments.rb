class CreateAttachments < ActiveRecord::Migration
  def self.up
    create_table :attachments do |t|
			t.integer :parent_id, :attachable_id
			t.string :attachable_type, :content_type, :filename, :thumbnail
			t.integer :size, :height, :width
      t.boolean :is_audio, :default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :attachments
  end
end