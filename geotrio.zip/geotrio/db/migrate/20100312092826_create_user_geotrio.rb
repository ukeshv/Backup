class CreateUserGeotrio < ActiveRecord::Migration
  def self.up
    User.create(:email => "geotrio@geotrio.com", :username => "geotrio", :password => "geotrio", :password_confirmation=>"geotrio")
  end

  def self.down
    @user = User.find_by_username("geotrio")
    @user.destroy
  end
end
