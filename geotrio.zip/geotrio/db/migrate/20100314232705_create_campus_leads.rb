class CreateCampusLeads < ActiveRecord::Migration
  def self.up
    create_table :campus_leads do |t|
      t.string :name
      t.string :email
      t.string :major
      t.string :gender
      t.string :language
      t.string :nationality
      t.string :ethnicity
      t.integer :year
      t.timestamps
    end
  end

  def self.down
    drop_table :campus_leads
  end
end
