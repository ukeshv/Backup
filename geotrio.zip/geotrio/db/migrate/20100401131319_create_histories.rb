class CreateHistories < ActiveRecord::Migration
  def self.up
    create_table :histories do |t|
      t.integer :user_id
      t.integer :tour_id
      t.integer :stop_id
      t.text :action
      t.timestamps
    end
    add_index :histories, [:user_id, :created_at]
  end

  def self.down
    drop_table :histories
  end
end
