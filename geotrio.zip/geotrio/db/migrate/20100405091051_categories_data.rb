class CategoriesData < ActiveRecord::Migration
  def self.up
	   Category.create(:name => "Architecture", :code=> "1")
	   Category.create(:name => "Campus Tours", :code=> "2")
	   Category.create(:name => "Dog Walking Tours", :code=> "3")
	   Category.create(:name => "Historical", :code=> "4")
	   Category.create(:name => "Nature and Parks", :code=> "5")
	   Category.create(:name => "Neighborhood Tours", :code=> "6")
	   Category.create(:name => "Shopping and Eating", :code=> "7")
	   Category.create(:name => "Social Tours", :code=> "8")
	   Category.create(:name => "Other", :code=> "9")
  end

  def self.down
    Category.destroy_all
  end
end

