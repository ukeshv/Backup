class CreateTasks < ActiveRecord::Migration
  def self.up
    create_table :tasks do |t|
      t.integer :task_type,     :null => false 
      t.integer :tour_id  ,     :null => false
      t.integer :stop_seq_num,  :null => false
      t.integer :state, :default => 0
      t.timestamps
    end
  end

  def self.down
    drop_table :tasks
  end
end
