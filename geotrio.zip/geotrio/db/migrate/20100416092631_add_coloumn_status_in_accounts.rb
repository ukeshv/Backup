class AddColoumnStatusInAccounts < ActiveRecord::Migration
  def self.up
    add_column :accounts, :status, :integer, :default => 1
  end

  def self.down
    remove_column :accounts, :status
  end
end
