class AddCasualCategoryRemoveSocialCategoryData < ActiveRecord::Migration
  def self.up
    c=Category.first(:conditions=>["name = ?", "Social Tours"])
    c.destroy
    Category.create(:name => "Casual Tours", :code=> "8")
  end

  def self.down
    c=Category.first(:conditions=>["name = ?", "Casual Tours"])
    c.destroy
    Category.create(:name => "Social Tours", :code=> "8")
  end
end
