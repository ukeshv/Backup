class CreateReceipts < ActiveRecord::Migration
  def self.up
    create_table :receipts do |t|
      t.integer :tour_id
      t.string :purchaser_itunes_username
      t.string :purchaser_device_id
      t.timestamp :purchased_at
      t.float :amount, :default=>0.0
      t.timestamps
    end
    add_index :receipts, [:tour_id]
    execute %{alter table receipts add constraint tour_fk1 foreign key (tour_id) references tours(id)}
  end

  def self.down
    drop_table :receipts
  end
end
