class AddKidsAndRecreationChangeCasualTourIdCategory < ActiveRecord::Migration
  def self.up
    cat1 = Category.first(:conditions=>["name = ?", "Casual Tours"])
    cat1.update_attributes(:name => "Kids and Recreation") if cat1
    cat2 = Category.first(:conditions=>["name = ?", "Other"])
    cat2.update_attributes(:name => "Casual Tours") if cat2
  end

  def self.down    
    cat1 = Category.first(:conditions=>["name = ?", "Kids and Recreation"])
    cat1.update_attributes(:name => "Casual Tours") if cat1
    cat2 = Category.first(:conditions=>["name = ?", "Casual Tours"])
    cat2.update_attributes(:name => "Other") if cat2
  end
end
