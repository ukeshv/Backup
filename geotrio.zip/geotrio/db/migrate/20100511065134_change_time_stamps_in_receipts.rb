class ChangeTimeStampsInReceipts < ActiveRecord::Migration
  # #### #
  # First we move purchased_at after created_at as is and then change it.
  # Or else, it fails as only one column can be default CURRENT_TIMESTAMP
  #   and it automatically puts the first column to be it.
  # #### #
  def self.up
    execute %{ alter table receipts modify column purchased_at datetime after created_at; }
    execute %{  alter table receipts modify created_at timestamp; }
    execute %{  alter table receipts modify updated_at timestamp; }
    execute %{ alter table receipts modify purchased_at timestamp; }
  end

  def self.down
    execute %{ alter table receipts modify purchased_at datetime; }
    execute %{  alter table receipts modify created_at datetime; }
    execute %{  alter table receipts modify updated_at datetime; }
  end
end
