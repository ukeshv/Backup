class AddColumnPaypalEmailAndPaypalVerificationStatusToUsers < ActiveRecord::Migration
  def self.up
    add_column :users, :paypal_email, :string, :null=>false
    add_column :users, :paypal_verification_status, :boolean, :default=>0, :null=>false
  end

  def self.down
    remove_column :users, :paypal_verification_status
    remove_column :users, :paypal_email
  end
end
