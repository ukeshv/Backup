class CreatePaypalTransactions < ActiveRecord::Migration
  def self.up
    create_table :paypal_transactions do |t|
      t.integer :user_id
      t.string :paid_to
      t.float :amount_transferred
      t.string :transaction_id
      t.integer :status, :default => 0
      t.datetime :payment_date
      t.text :paypal_token
      t.timestamps
    end
  end

  def self.down
    drop_table :paypal_transactions
  end
end
