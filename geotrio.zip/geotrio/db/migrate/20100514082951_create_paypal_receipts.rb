class CreatePaypalReceipts < ActiveRecord::Migration
  def self.up
    create_table :paypal_receipts do |t|
      t.integer :paypal_transaction_id, :default=>0
      t.integer :receipt_id
      t.timestamps
    end
    add_index :paypal_receipts, [:paypal_transaction_id, :receipt_id]
  end

  def self.down
    drop_table :paypal_receipts
  end
end
