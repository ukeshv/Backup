class AddColumnCreatedFromToTour < ActiveRecord::Migration
  def self.up
    add_column :tours, :created_from, :string, :default=>"iPhone"
  end

  def self.down
    remove_column :tours, :created_from
  end
end
