class CreateUserCampusTours < ActiveRecord::Migration
  def self.up
    create_table :user_campus_tours do |t|
      t.integer :campus_lead_id
      t.integer :tour_id
      t.timestamps
    end
  end

  def self.down
    drop_table :user_campus_tours
  end
end
