class AddColumnIAgreeToUsers < ActiveRecord::Migration
  def self.up
    add_column :users, :i_agree, :boolean, :default=>false
  end

  def self.down
    remove_column :users, :i_agree
  end
end
