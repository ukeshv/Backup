class CreateFbUsers < ActiveRecord::Migration
  def self.up
    create_table :fb_users do |t|
      t.integer     :user_id
      t.string      :fb_user
      t.string      :fb_app_id
      t.string      :fb_sig
      t.string      :fb_sig_country
      t.timestamps  :fb_sig_time
      t.timestamps  
    end
  end

  def self.down
    drop_table :fb_users
  end
end
