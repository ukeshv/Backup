class CreatePlayedTours < ActiveRecord::Migration
  def self.up
    create_table :played_tours do |t|
      t.integer   :tour_id  
      t.integer   :fb_user_id
      t.integer   :total_clicks
      t.integer   :is_completed
      t.timestamps
    end
  end

  def self.down
    drop_table :played_tours
  end
end
