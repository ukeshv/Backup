class CreateCompletedStops < ActiveRecord::Migration
  def self.up
    create_table :completed_stops do |t|
      t.integer :tour_id
      t.integer :fb_user_id
      t.integer :stops_completed
      t.integer :clickcount
      t.timestamps
    end
  end

  def self.down
    drop_table :completed_stops
  end
end
