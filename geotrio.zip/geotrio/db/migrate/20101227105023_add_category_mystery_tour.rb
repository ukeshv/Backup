class AddCategoryMysteryTour < ActiveRecord::Migration
  def self.up
    Category.create(:name => "Mystery Tours", :code=> "10")
  end

  def self.down
    c=Category.first(:conditions=>["name = ?", "Mystery Tours"])
    c.destroy
  end
end
