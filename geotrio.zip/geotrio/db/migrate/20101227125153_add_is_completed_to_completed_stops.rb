class AddIsCompletedToCompletedStops < ActiveRecord::Migration
  def self.up
    add_column :completed_stops, :is_completed, :integer
  end

  def self.down
    remove_column :completed_stops, :is_completed
  end
end
