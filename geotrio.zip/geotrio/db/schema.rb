# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20101227125153) do

  create_table "accounts", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "status",      :default => 1
  end

  create_table "attachments", :force => true do |t|
    t.integer  "parent_id"
    t.integer  "attachable_id"
    t.string   "attachable_type"
    t.string   "content_type"
    t.string   "filename"
    t.string   "thumbnail"
    t.integer  "size"
    t.integer  "height"
    t.integer  "width"
    t.boolean  "is_audio",        :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "campus_leads", :force => true do |t|
    t.string   "name"
    t.string   "email"
    t.string   "major"
    t.string   "gender"
    t.string   "language"
    t.string   "nationality"
    t.string   "ethnicity"
    t.integer  "year"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "categories", :force => true do |t|
    t.string   "name"
    t.string   "code"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "completed_stops", :force => true do |t|
    t.integer  "tour_id"
    t.integer  "fb_user_id"
    t.integer  "stops_completed"
    t.integer  "clickcount"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "is_completed"
  end

  create_table "delayed_jobs", :force => true do |t|
    t.integer  "priority",   :default => 0
    t.integer  "attempts",   :default => 0
    t.text     "handler"
    t.text     "last_error"
    t.datetime "run_at"
    t.datetime "locked_at"
    t.datetime "failed_at"
    t.string   "locked_by"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "fb_users", :force => true do |t|
    t.integer  "user_id"
    t.string   "fb_user"
    t.string   "fb_app_id"
    t.string   "fb_sig"
    t.string   "fb_sig_country"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "histories", :force => true do |t|
    t.integer  "user_id"
    t.integer  "tour_id"
    t.integer  "stop_id"
    t.text     "action"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "histories", ["user_id", "created_at"], :name => "index_histories_on_user_id_and_created_at"

  create_table "notifications", :force => true do |t|
    t.integer  "user_id"
    t.text     "message"
    t.boolean  "status",     :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "paypal_receipts", :force => true do |t|
    t.integer  "paypal_transaction_id", :default => 0
    t.integer  "receipt_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "paypal_receipts", ["paypal_transaction_id", "receipt_id"], :name => "index_paypal_receipts_on_paypal_transaction_id_and_receipt_id"

  create_table "paypal_transactions", :force => true do |t|
    t.integer  "user_id"
    t.string   "paid_to"
    t.float    "amount_transferred"
    t.string   "transaction_id"
    t.integer  "status",             :default => 0
    t.datetime "payment_date"
    t.text     "paypal_token"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.text     "comments"
  end

  create_table "played_tours", :force => true do |t|
    t.integer  "tour_id"
    t.integer  "fb_user_id"
    t.integer  "total_clicks"
    t.integer  "is_completed"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "ratings", :force => true do |t|
    t.integer   "tour_id",    :null => false
    t.integer   "user_id",    :null => false
    t.float     "rating",     :null => false
    t.timestamp "created_at", :null => false
    t.timestamp "updated_at", :null => false
  end

  add_index "ratings", ["tour_id", "user_id"], :name => "tour_id", :unique => true
  add_index "ratings", ["user_id"], :name => "user_id"

  create_table "receipts", :force => true do |t|
    t.integer   "tour_id"
    t.string    "purchaser_itunes_username"
    t.string    "purchaser_device_id"
    t.float     "amount",                    :default => 0.0
    t.timestamp "created_at",                                 :null => false
    t.timestamp "purchased_at",                               :null => false
    t.timestamp "updated_at",                                 :null => false
  end

  add_index "receipts", ["tour_id"], :name => "index_receipts_on_tour_id"

  create_table "registrations", :force => true do |t|
    t.integer   "user_id"
    t.string    "device_id",   :limit => 150,                :null => false
    t.integer   "application",                :default => 0, :null => false
    t.integer   "api_version",                :default => 1, :null => false
    t.text      "tokens",                                    :null => false
    t.integer   "status",                     :default => 1, :null => false
    t.timestamp "created_at",                                :null => false
    t.timestamp "updated_at",                                :null => false
  end

  add_index "registrations", ["user_id"], :name => "user_id"

  create_table "simple_captcha_data", :force => true do |t|
    t.string   "key",        :limit => 40
    t.string   "value",      :limit => 6
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "stops", :force => true do |t|
    t.string    "name",       :limit => 100,  :null => false
    t.string    "text",       :limit => 1000, :null => false
    t.float     "latitude",                   :null => false
    t.float     "longitude",                  :null => false
    t.float     "altitude",                   :null => false
    t.timestamp "created_at",                 :null => false
    t.timestamp "updated_at",                 :null => false
  end

  create_table "tasks", :force => true do |t|
    t.integer  "task_type",                   :null => false
    t.integer  "tour_id",                     :null => false
    t.integer  "stop_seq_num",                :null => false
    t.integer  "state",        :default => 0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tour_search", :force => true do |t|
    t.integer   "user_id",                                            :null => false
    t.string    "title",               :limit => 100,                 :null => false
    t.string    "description",         :limit => 1000,                :null => false
    t.string    "author",              :limit => 100,                 :null => false
    t.string    "price",               :limit => 100,                 :null => false
    t.float     "length",                                             :null => false
    t.float     "duration",                                           :null => false
    t.integer   "difficulty",                                         :null => false
    t.float     "category",                                           :null => false
    t.float     "rating",                                             :null => false
    t.integer   "number_of_ratings",                   :default => 0, :null => false
    t.integer   "number_of_stops",                     :default => 0, :null => false
    t.integer   "number_of_views",                     :default => 0, :null => false
    t.integer   "number_of_downloads",                 :default => 0, :null => false
    t.float     "latitude",                                           :null => false
    t.float     "longitude",                                          :null => false
    t.timestamp "published_at",                                       :null => false
  end

  create_table "tour_tracks", :force => true do |t|
    t.integer "tour_id",                    :null => false
    t.float   "latitude",                   :null => false
    t.float   "longitude",                  :null => false
    t.float   "altitude",  :default => 0.0, :null => false
    t.integer "is_stop",   :default => 0,   :null => false
  end

  add_index "tour_tracks", ["tour_id"], :name => "tour_id"

  create_table "tours", :force => true do |t|
    t.integer   "user_id",                                                   :null => false
    t.string    "title",               :limit => 100,                        :null => false
    t.string    "description",         :limit => 1000,                       :null => false
    t.integer   "status",                                                    :null => false
    t.string    "author",              :limit => 100,                        :null => false
    t.string    "price",               :limit => 100,  :default => "0",      :null => false
    t.float     "length",                                                    :null => false
    t.float     "duration",                                                  :null => false
    t.integer   "difficulty",                                                :null => false
    t.float     "category",                                                  :null => false
    t.float     "rating",                                                    :null => false
    t.integer   "number_of_ratings",                   :default => 0,        :null => false
    t.integer   "number_of_stops",                     :default => 0,        :null => false
    t.integer   "number_of_views",                     :default => 0,        :null => false
    t.integer   "number_of_downloads",                 :default => 0,        :null => false
    t.timestamp "published_at",                                              :null => false
    t.timestamp "withdrawn_at",                                              :null => false
    t.timestamp "created_at",                                                :null => false
    t.timestamp "updated_at",                                                :null => false
    t.string    "created_from",                        :default => "iPhone"
  end

  add_index "tours", ["user_id"], :name => "user_id"

  create_table "tours_stops", :force => true do |t|
    t.integer "tour_id",  :null => false
    t.integer "stop_id",  :null => false
    t.integer "sequence", :null => false
  end

  add_index "tours_stops", ["stop_id"], :name => "stop_id"
  add_index "tours_stops", ["tour_id", "sequence"], :name => "tour_id_2", :unique => true
  add_index "tours_stops", ["tour_id", "stop_id"], :name => "tour_id", :unique => true

  create_table "user_accounts", :force => true do |t|
    t.integer  "user_id"
    t.integer  "account_id"
    t.string   "user_type",  :default => "user"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "user_accounts", ["user_id", "account_id"], :name => "index_user_accounts_on_user_id_and_account_id"

  create_table "user_campus_tours", :force => true do |t|
    t.integer  "campus_lead_id"
    t.integer  "tour_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.string    "email",                      :limit => 150,                    :null => false
    t.string    "username",                   :limit => 25,                     :null => false
    t.string    "crypted_password",           :limit => 40,  :default => "",    :null => false
    t.string    "salt",                       :limit => 40,                     :null => false
    t.integer   "status",                                    :default => 1,     :null => false
    t.integer   "user_type",                                 :default => 1,     :null => false
    t.string    "first_name",                 :limit => 100
    t.string    "last_name",                  :limit => 100
    t.string    "signature",                  :limit => 250
    t.string    "fb_name",                    :limit => 100
    t.string    "tw_name",                    :limit => 100
    t.timestamp "created_at",                                                   :null => false
    t.timestamp "updated_at",                                                   :null => false
    t.string    "remember_token",             :limit => 40
    t.datetime  "remember_token_expires_at"
    t.string    "password_reset_code",                       :default => "",    :null => false
    t.string    "paypal_email",                                                 :null => false
    t.boolean   "paypal_verification_status",                :default => false, :null => false
    t.text      "snail_address"
    t.boolean   "i_agree",                                   :default => false
    t.boolean   "subscribe",                                 :default => true
  end

end
