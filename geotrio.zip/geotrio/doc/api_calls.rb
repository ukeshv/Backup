require 'rubygems'
require 'net/http'
require 'net/https'
require 'uri' 
require 'digest/md5'
require 'xmlsimple'

class RegisterClient
	def initialize
		$secret_key = "foobar"
		@f = File.open("log.txt", "a")
		response = send_user_registration 
		puts response
		@f.write(response.body)
		@f.close
	end 
	
	def post_params(method, port, params)
		http = Net::HTTP.new('geotrio.railsfactory.com',80)
		#~ http.use_ssl = true #if port == 443
		path = "/api/#{method}"
		result = http.post(path, params)
	end 	
 
	def send_user_registration
		write_log("user registration")
		method = 'users'
		params = "username=sfghri1&email=sri.jjhero3fgh1@gmail.com&password=sri123&secret=#{$secret_key}"
		post_params(method, 443, params)
	end 
	
	def login
		write_log 
		method = 'users'
		params = "username=sri&email=sri.jjhero3@gmail.com&password=sri123&secret=#{$secret_key}"
		post_params(method, 443, params)
	end
 
 	def create_tour
		secret_key = "foobar"
		http = Net::HTTP.new('apitest.geotrio.com', 80)
		#http.use_ssl = true
		path = '/api/v1/tours'
		data = "title=tour1&description=thisidd&rating=5&category=1&difficulty=no&secret=foobar&apiid=35"
		#resp, data = http.post(path, data)
		result = http.post(path, data)
		puts result.methods.sort
	 result_data = XmlSimple.xml_in(result.body)
	 puts result_data.inspect
	end 

	def send_registration_device
		secret_key = "foobar"
		http = Net::HTTP.new('apitest.geotrio.com', 443)
		http.use_ssl = true
		path = '/api/v1/register'
		data = "user_id=35&device_id=#{get_random_chars}&secret=foobar"
		resp, data = http.post(path, data)
		puts resp.methods.sort
		puts resp.inspect
		puts data.inspect
	end 
	
	def get_random_chars
		chars = ("a".."f").to_a + ("0".."9").to_a
		rand_number = ""
		1.upto(40) { |i| rand_number << chars[rand(chars.size-1)] }
		puts rand_number
		return "0bcdef0123456789abcdef0123456789abcdef3f"
	end
	
	def encode_key(secret_key)
		Digest::MD5.hexdigest("#{secret_key} + #{get_random_chars}")
	end 
	
	def write_log(text=nil)
	  @f.write("\n\n--------------------#{Time.now.strftime("%h %d,%Y %T")}----------------------------\n\n") 
	  @f.write("\n\n-------------------#{text}----------------------------\n\n") 
	end
end 
	
RegisterClient.new