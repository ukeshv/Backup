require 'rubygems'
require 'net/http'
require 'net/https'
require 'uri' 
require 'digest/md5'
require 'xmlsimple'

class CreateTour
	def initialize
		tour_details
	end 
	
 	def create_tour
		secret_key = "foobar"
		http = Net::HTTP.new('apitest.geotrio.com', 80)
		#http.use_ssl = true
		path = '/api/v1/tours'
		data = "title=tour1&description=thisidd&rating=5&category=1&difficulty=no&secret=foobar&id=528&token=8bba14d72ab5b864863ce1f9ee1bc18fb6caa04449aa174d33d9a78457d003e89fb2d1cb89e0c60526fc43ac10f572b3"
		#resp, data = http.post(path, data)
		result = http.post(path, data)
	 result_data = XmlSimple.xml_in(result.body)
	 puts result_data.inspect
 end 
 
 	def tour_details
		secret_key = "foobar"
		http = Net::HTTP.new('apitest.geotrio.com', 80)
		#http.use_ssl = true
		path = '/api/v1/tours/129'
		data = "id=528&token=4865ea0a221f210448a74ad63db9c4a22f29477b2e053427a6cf020595ee8b29435fb5b1d1bc1a705544827d30ac62f9"
		#resp, data = http.post(path, data)
		result = http.get(path, nil)
	 result_data = XmlSimple.xml_in(result.body)
	 puts result_data.inspect
	end 
end 
	
CreateTour.new