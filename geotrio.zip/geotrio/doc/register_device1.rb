require 'rubygems'
require 'net/http'
require 'net/https'
require 'uri'


http = Net::HTTP.new('apitest.geotrio.com', 443)
http.use_ssl = true
path = '/api/v1/register'

# POST request -> logging in
data = 'user_id=srikanth&device_id=test&secret=foobar'
resp, data = http.post(path, data)
#~ puts resp.inspect
puts data.inspect