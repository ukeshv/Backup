require 'rubygems'
require 'net/http'
require 'net/https'
require 'uri'


#~ res = Net::HTTP.post_form(URI.parse('https://apitest.geotrio.com/api/v1/register'), {:secret => "7c1b6c5ae26a51b45a3fd51992342162", :device_id=>"3e3e4"})
#~ puts res

 http = Net::HTTP.new("apitest.geotrio.com",443)
 http.use_ssl = true
        req = Net::HTTP::Get.new("/api/v1/tours/2")
        
        #~ req.basic_auth "srikanth", "sri.jjhero@gmail.com", "sri123"
        req.set_form_data({'username'=>'2005-01-01', 'email'=>'2005-03-31','email'=>'2005-03-31'})
        #~ resp, data = http.post(path, data)
        response = http.request(req)
        puts response.body.inspect
#~ url = 'http://apitest.geotrio.com/api/v1/tours?id=foobar'

#~ res=  Net::HTTP.get_print URI.parse(url)
#~ res = Net::HTTP.post_form(URI.parse(url),{'title'=>'India', 'description'=>'this is the Desc', 'rating'=>'5', :category=>'first', 'difficulty'=>'no'})
#~ puts res



#~ res=  Net::HTTP.get_print URI.parse(url)

#~ data = XmlSimple.xml_in(xml_data)
#~ puts res
exit


https://apitest.geotrio.com/api/v1/users