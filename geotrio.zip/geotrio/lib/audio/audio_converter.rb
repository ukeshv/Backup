#!/usr/local/bin/ruby


# ########################################################################## #
# Includes
# ########################################################################## #
# Note : require rubygems needed for optiflag
require 'rubygems'
require 'optiflag'
require 'daemons'


# ########################################################################## #
# Command-line arguments
# ########################################################################## #
module AudioConverterFlags extend OptiFlagSet
  @tours = []

  # #### #
  # Command-line parameters
  # #### #
  usage_flag "h","help","?"
  extended_help_flag "morehelp"

  optional_flag "env" do
    alternate_forms "e"
    description "Rails environment"
    long_form "environment"
    value_matches ["Invalid environment", /^(development|production)$/]
  end

  optional_flag "task" do
    alternate_forms "t"
    description "Task ID"
    long_form "task_id"
    value_matches ["Must be a valid task id", /^(\d+)$/]
  end

  optional_switch_flag "rerun" do
    alternate_forms "r"
    description "Re-run Task"
    long_form "rerun_task"
  end

  optional_flag "action" do
    alternate_forms "a"
    description "Start or Stop Daemon"
    long_form "daemon_action"
    value_matches ["Valid actions : start or stop", /^(start|stop)$/]
  end

  optional_switch_flag "daemonize" do
    alternate_forms "d"
    description "Daemonize this process"
    long_form "daemonize_process"
  end

  and_process!
end


# ########################################################################## #
# Class Definition
# ########################################################################## #
class AudioConverter
  # #### #
  # Logging method
  # #### #
  def logd(message)
    if @environment == "development"
      puts "#{message}"
    end
  end

  # #### #
  # Constructor
  # #### #
  def initialize
    @log_file = '/tmp/audio_converter.log'
    @pid_file = File.join(
       File.dirname(__FILE__), "..", "..", "sys", "audio_converter.pid"
    )
    @environment = 'development'
    @environment = AudioConverterFlags.flags.env \
      if AudioConverterFlags.flags.env
    logd "-- Environment = #{@environment}"

    # #### #
    # Includes specific to environment
    # #### #
    ENV['RAILS_ENV'] = @environment
    require File.join(
      File.dirname(__FILE__), "..", "..", "config", "environment"
    )
    require 'audio_utils'
  end

  # #### #
  # Method to run a single task
  # #### #
  def process_task(task)
    raise "Cannot process task unless state = 0" unless task.state == 0
    raise "Invalid task type '#{task.task_type}'" \
      unless task.task_type >= 1 && task.task_type <= 2
    logd "-------------------------------------------------------------------"
    logd "-- Starting task '#{task.id}'"
    task.state = 1 
    raise "Task with id #{task.id} cannot be updated to state 1" \
      unless task.save!
    s = false
    au = AudioUtils.new
    if task.task_type == 1
      s = au.convert_tour_overview_audio( task.tour_id )
    elsif task.task_type == 2
      s = au.convert_tour_stop_audio(task.tour_id, task.stop_seq_num)
    end
    if s
      logd "-- Task run success.  Moving task to completed stage."
      task.state = 2
      raise "Task with id #{task.id} cannot be updated to state 2" \
        unless task.save!
    end
    logd "-- Finished task '#{task.id}'"
    logd "-------------------------------------------------------------------"
  end

  # #### #
  # Method to run the loop until the process is killed
  # #### #
  def run_loop
    while true
      begin
        task = Task.first(:conditions => "state = 0")
        if task
          process_task(task)
        else
          #logd "-- No tasks with state 0 found"
          sleep 4
        end
      rescue Exception => e
        $stderr.puts "Task #{task.id} failed :: " + e.to_s
      end
    end
  end

  # #### #
  # First, check if a current process is running
  # #### #
  def check_daemon_running
    fh = File.open(@pid_file, 'r')
    saved_pid = fh.gets
    fh.close
    if saved_pid then
      saved_pid.chomp!
      begin
        if Process.kill(0, saved_pid.to_i) then
          puts "Previous process #{saved_pid} is running.  Kill it first."
          exit 0
        end
      rescue Errno::ESRCH
        puts "No previous process found"
      end
    end
  end

  # #### #
  # Method to daemonize
  # #### #
  def daemonize
    # #### #
    # Fork a child process and run that in the background
    # #### #
    pid = Process.fork do
      # #### #
      # Redirect stdout and stderr to a log file and start infinite run loop
      # #### #
      $stdout.reopen(@log_file, "w")
      $stdout.sync = true
      $stderr.reopen $stdout
      run_loop()
    end
    Process.detach(pid)

    # #### #
    # Write the PID to the PID file
    # #### #
    puts "PID = #{pid}"
    fh = File.open(@pid_file, File::RDWR|File::CREAT)
    raise "Cannot get write lock on PID file." unless fh.flock(File::LOCK_EX)
    fh.pos = 0
    fh.truncate 0
    fh.puts pid
    fh.close
  end

  # #### #
  # Method to process command-line options
  # #### #
  def process!
    # #### #
    # #### #
    if AudioConverterFlags.flags.task
      logd "-- Going to process given task #{AudioConverterFlags.flags.task}"
      task = Task.find(AudioConverterFlags.flags.task)
      if AudioConverterFlags.flags.rerun
        logd "-- Rerunning task #{task.id}"
        task.state = 0
        raise "Rerun of Task #{task.id} failed :  state not set to 0" \
          unless task.save!
      end
      process_task(task)
    else
      if AudioConverterFlags.flags.daemonize
        logd "-- Going to daemonize this process"
        daemonize
      else
        logd "-- Running the first task on the list"
        task = Task.first(:conditions => "state = 0")
        logd "-- No tasks with status 0 found" unless task
        process_task(task) if task
      end
    end
  end
end

# ########################################################################## #
# Main section
# ########################################################################## #
if Process.uid != 0
  $stderr.puts "Must run as root"
  exit 1
end
ac = AudioConverter.new
ac.check_daemon_running
ac.process!
