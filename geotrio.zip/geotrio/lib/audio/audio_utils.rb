# ########################################################################## #
# Class AudioUtils
# ########################################################################## #
class AudioUtils
  require 'user_mailer'
  # ######################################################################## #
  # Constructor method
  # ######################################################################## #
  def initialize
    @log_level = 1
  end

  # ######################################################################## #
  # Logging method
  # ######################################################################## #
  def logd(message)
    puts "#{message}" if @log_level > 0
  end

  # ######################################################################## #
  # Method to compute the tour directory index
  # ######################################################################## #
  def get_tour_dir_index(tour_id)
    return 1 + (tour_id/10000)
  end

  # ######################################################################## #
  # Method to compute the tour audio directory
  # ######################################################################## #
  def get_tour_audio_dir(tour_id)
    tour_dir_index = get_tour_dir_index(tour_id)
    tour_audio_dir \
      = "#{APP_CONFIG[:files_dir]}/#{tour_dir_index}/#{tour_id}/audio"
    raise "Tour audio directory #{tour_audio_dir} does not exist" \
      unless File.exists?(tour_audio_dir)
    raise "Tour audio directory path #{tour_audio_dir} is not a directory" \
      unless File.directory?(tour_audio_dir)

    return tour_audio_dir
  end

  # ######################################################################## #
  # Convert Tour Overview audio method
  # ######################################################################## #
  def convert_tour_overview_audio(tour_id)
    # #### #
    # Check tour status
    # #### #
    tour = Tour.find(tour_id)
    UserMailer.deliver_tour_draft(tour)
    raise "Tour must have either 0 or 1 status to be able to convert audio." \
      unless ( tour.status == 0 ) || ( tour.status == 1 )

    # #### #
    # Check if file exists
    # #### #
    tour_audio_dir = get_tour_audio_dir(tour_id)
    tour_overview_audio_caf = "#{tour_audio_dir}/overview.caf"
    raise "Tour overview caf audio file not found" \
      unless File.exists?(tour_overview_audio_caf)

    # #### #
    # Convert tour overview audio caf file to mp3
    # #### #
    logd "-- Tour ID = '#{tour_id}'"
    logd "-- Tour Audio Overview Caf file = '#{tour_overview_audio_caf}'"
    cmd = "pacpl --overwrite --to 'mp3' #{tour_overview_audio_caf}"
    logd "-- Command = '#{cmd}'"
    output = %x[#{cmd}]
    logd "-- Command status = '#{output}'"
    if output
      logd "-- Processing attachments"
      raise "Attachment not saved for overview of tour #{tour.id}" \
        unless Attachment.create_or_update_by_tour_id(tour.id)
    end

    return true
  end

  # ######################################################################## #
  # Convert Tour Stop audio method
  # ######################################################################## #
  def convert_tour_stop_audio( tour_id, stop_seq_num )
    # #### #
    # Check tour status and tour stop
    # #### #
    raise "Invalid tour id" unless tour_id.to_s.match(/^\d+$/)
    raise "Invalid stop sequence number" \
      unless stop_seq_num.to_s.match(/^\d+$/)
    t = Tour.find(tour_id)
    ts = ToursStop.find(
      :first,
      :conditions => "tour_id = #{tour_id} and sequence = #{stop_seq_num}"
    )
    raise "Tour stop not found" if ts.nil?

    # #### #
    # Check if file exists
    # #### #
    tour_audio_dir = get_tour_audio_dir(tour_id)
    tour_stop_audio_caf = "#{tour_audio_dir}/#{stop_seq_num}.caf"
    raise "Tour stop audio caf file not found" \
      unless File.exists?(tour_stop_audio_caf)

    # #### #
    # Convert tour stop audio caf file to mp3
    # #### #
    logd "-- Tour ID = '#{tour_id}'"
    logd "-- Tour Stop Audio Caf file = '#{tour_stop_audio_caf}'"
    cmd = "pacpl --overwrite --to 'mp3' #{tour_stop_audio_caf}"
    logd "-- Command = '#{cmd}'"
    output = %x[#{cmd}]
    logd "-- Command status = '#{output}'"
    if output
      logd "-- Processing attachments"
      raise "Attachment for tour #{tour_id} stop #{stop_seq_num} not saved" \
        unless Attachment.create_or_update_by_stop(ts.stop_id, stop_seq_num)
    end

    return true
  end
end
