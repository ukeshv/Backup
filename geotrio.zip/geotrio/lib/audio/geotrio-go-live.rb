#!/usr/local/bin/ruby


# ########################################################################## #
# Includes
# ########################################################################## #
# Note : require rubygems needed for optiflag
require 'rubygems'
require 'optiflag'
require File.join(File.dirname(__FILE__), "..", "..", "config", "boot")
require File.join(File.dirname(__FILE__), "..", "..", "config", "environment")
require 'user_mailer'
require 'tour'
#require 'tour_search'


# ########################################################################## #
# Methods
# ########################################################################## #
def logd(message)
  puts "#{message}" if ARGV.flags.verbose
end

def go_live(t)
  # #### #
  # Perform initial checks before processing tour audio
  # #### #
  raise "Tour with id #{t.id} does not have status 9. Cannot go live." \
    unless t.status == 9
  raise "Tour with id #{t.id} does not have description." \
    if t.description.blank?
  raise "Tour with less than two stops cannot go live." \
    if t.number_of_stops < 2

  # #### #
  # Copy the tour data to tour_search table
  # #### #
  logd "---------------------------------------------------------------------"
  logd "-- Making tour #{t.id} live"
  ts = TourSearch.new
  ts.id = t.id
  ts.user_id = t.user_id
  ts.title = t.title
  ts.description = t.description
  ts.author = t.author
  ts.price = t.price
  ts.length = t.length
  ts.duration = t.duration
  ts.difficulty = t.difficulty
  ts.category = t.category
  ts.rating = t.rating
  ts.number_of_ratings = t.number_of_ratings
  ts.number_of_stops = t.number_of_stops
  ts.number_of_views = t.number_of_views
  ts.number_of_downloads = t.number_of_downloads
  ts.published_at = t.published_at
  tour_stop0 = ToursStop.find(
    :first,
    :conditions => "tour_id = #{t.id} and sequence = 0"
  )
  stop0 = Stop.find( tour_stop0.stop_id )
  ts.latitude = stop0.latitude
  ts.longitude =stop0.longitude
  raise "Tour with id #{t.id} could not saved to tour_search" \
    unless ts.save!
  logd "---------------------------------------------------------------------"

  # #### #
  # Mark the status as "In-Zipping" and proceed with the Zipping
  # #### #
  t.status = 10
  system("s3cmd put --acl-private --recursive #{APP_CONFIG[:files_dir]}/#{(t.id/ 10000) + 1}/#{t.id} s3://#{AMAZON_CONFIG['bucket_name']}/files/#{(t.id/ 10000) + 1}/")
  UserMailer.deliver_tour_live(t)
  raise "Tour with id #{t.id} could not update status to 6" \
  unless t.save!
end


# ########################################################################## #
# Main section
# ########################################################################## #
module Opts extend OptiFlagSet
  @tours = []

  # #### #
  # Command-line parameters
  # #### #
  usage_flag "h","help","?"
  extended_help_flag "morehelp"

  optional_switch_flag "verbose" do
    alternate_forms "v"
    description "Tour ID "
    long_form "verbose_on"
  end

  optional_flag "tours" do
    alternate_forms "t"
    description "Tour ID "
    long_form "tour_ids"
    value_matches ["Must be a valid list of tour ids", /^(\d+)((,\d+)+)?$/]
  end

  and_process!

  # #### #
  # Make either all tours or given tours live
  # #### #
  if ARGV.flags.tours.nil?
    #logd "-- Processing all tours with status 9"
    @tours = Tour.all(:conditions => {:status => 9})
  else
    logd "-- Tours given"
    tour_ids = ARGV.flags.tours.split(',')
    tour_ids.each do |t_id|
      begin
        @tours.push( Tour.find(t_id) )
      rescue
        $stderr.puts "Tour with ID #{t_id} could not be found"
        exit -1
      end
    end
  end
  count = 0
  @tours.each do |tour|
    begin
      go_live( tour )
      count += 1
      break if count == 2
      sleep 4
    rescue Exception => e
      $stderr.puts "Error processing tour '#{tour.id}' -- #{e.to_s}"
    end
  end
end
