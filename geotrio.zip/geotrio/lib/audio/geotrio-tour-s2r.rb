#!/usr/local/bin/ruby

# ########################################################################## #
# Includes
# ########################################################################## #
# Note : require rubygems needed for optiflag
require 'rubygems'
require 'optiflag'
require File.join(File.dirname(__FILE__), "..", "..", "config", "boot")
require File.join(File.dirname(__FILE__), "..", "..", "config", "environment")
require 'tour'

def logd(message)
  puts "#{message}" if ARGV.flags.verbose
end

def tour_status_to_review(t)
  # #### #
  # Perform initial checks before processing tour audio
  # #### #
  
  raise "Tour with id #{t.id} does not have status 2. Cannot review." \
    unless t.status == 2
  t.title = "No title given" if t.title.blank?
  t.author = "None" if t.author.blank?
  t.description = "No description given" if t.description.blank? || t.description==0 || t.description =="-"
  t.category = "No Category selected" if t.category == 0
  
  # #### #
  # Mark the status as "In-Conversion"
  # #### #
  UserMailer.deliver_tour_submitted(t.user, "Tour '#{t.title}' Submitted for Review","Your tour was submitted for review",t)
  t.status = 3
  raise "Tour with id #{t.id} could not update status to 3" \
    unless t.save!
  logd "---------------------------------------------------------------------"
  logd "-- Tour ID = '#{t.id}'"
  logd "---------------------------------------------------------------------"

  # #### #
  # Mark the status as "Ready for Review"
  # #### #
  if t.category==9
    t.status = 5
  else
    t.status = 4
    if t.user.snail_address.nil? || t.user.snail_address.blank?
       t.user.snail_reset_link(t.user)
       UserMailer.deliver_snail_address_empty(t.user, "Please fill Snail Address","You need to fill your Snail Address")
    end
  end
  raise "Tour with id #{t.id} could not update status to 4" \
    unless t.save!
end


# ########################################################################## #
# Main section
# ########################################################################## #
module Opts extend OptiFlagSet
  @tours = []

  # #### #
  # Command-line parameters
  # #### #
  usage_flag "h","help","?"
  extended_help_flag "morehelp"

  optional_switch_flag "verbose" do
    alternate_forms "v"
    description "Tour ID "
    long_form "verbose_on"
  end

  optional_flag "tours" do
    alternate_forms "t"
    description "Tour ID "
    long_form "tour_ids"
    value_matches ["Must be a valid list of tour ids", /^(\d+)((,\d+)+)?$/]
  end

  and_process!

  # #### #
  # Do the audio conversion either for a single tour or a set of tours
  #   or for all tours that are ready to be converted
  # #### #
  #t = Tour.find(ARGV.flags.tour)
  if ARGV.flags.tours.nil?
    logd "-- Processing all tours with status 2"
    @tours = Tour.all(:conditions => {:status => 2})
  else
    logd "-- Tours given"
    tour_ids = ARGV.flags.tours.split(',')
    tour_ids.each do |t_id|
      begin
        @tours.push( Tour.find(t_id) )
      rescue
        $stderr.puts "Tour with ID #{t_id} could not be found"
        exit -1
      end
    end
  end
  count = 0
  @tours.each do |tour|
    begin
      tour_status_to_review( tour )
      count += 1
      break if count == 2
      sleep 4
    rescue Exception => e
      $stderr.puts "Error processing tour '#{tour.id}' -- #{e.to_s}"
    end
  end
end
