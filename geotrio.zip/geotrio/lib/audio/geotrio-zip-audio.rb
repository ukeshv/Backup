#!/usr/local/bin/ruby


# ########################################################################## #
# Includes
# ########################################################################## #
# Note : require rubygems needed for optiflag
require 'rubygems'
require 'optiflag'
require File.join(File.dirname(__FILE__), "..", "..", "config", "boot")
require File.join(File.dirname(__FILE__), "..", "..", "config", "environment")
require 'tour'


# ########################################################################## #
# Methods
# ########################################################################## #
def logd(message)
  puts "#{message}" if ARGV.flags.verbose
end

def zip_tour_audios(t)
  # #### #
  # Perform initial checks before processing tour audio
  # #### #
  raise "Tour with id #{t.id} does not have status 5. Cannot Zip audio." \
    unless t.status == 5
  raise "Tour with id #{t.id} does not have description." \
    if t.description.blank?
  tour_dir_index = 1 + (t.id/10000)
  tour_dir = "#{APP_CONFIG[:files_dir]}/#{tour_dir_index}/#{t.id}"
  tour_audio_dir = "#{tour_dir}/audio"
  raise "Tour audio directory #{tour_audio_dir} does not exist" \
    unless File.exists?(tour_audio_dir)
  raise "Tour audio directory path #{tour_audio_dir} is not a directory" \
    unless File.directory?(tour_audio_dir)

  # #### #
  # Mark the status as "In-Zipping" and proceed with the Zipping
  # #### #
  t.status = 6
  raise "Tour with id #{t.id} could not update status to 6" \
    unless t.save!
  logd "---------------------------------------------------------------------"
  logd "-- Tour zip starting"
  logd "-- Tour ID = '#{t.id}'"
  logd "-- Tour Directory Index ='#{tour_dir_index}'"
  logd "-- Tour Directory ='#{tour_dir}'"
  logd "-- Tour Audio Directory = '#{tour_audio_dir}'"
  Dir.chdir( tour_audio_dir )
  arr = []
  num_stops = 0
  index = 0
  Dir.chdir(tour_dir)
  system("rm -f download*.zip")
  Dir.entries('audio').sort.each { |file|
    next unless file.to_s.match(/^(\d+).mp3$/)
    num_stops += 1
    logd "-- File '#{file}' in array"
    arr << file
    if ( arr.size == 3 ) || ( num_stops == t.number_of_stops )
      # #### #
      # Zip files
      # #### #
      logd "-- **************************************************************"
      logd "-- ** Zipping files"
      files = ''
      arr.each { |f| files += " audio/#{f}" }
      logd "-- ** Files = '#{files}'"
      logd "-- ** Index = '#{index}'"
      system("zip download#{index}.zip #{files}")
      arr = []
      index += 1
      logd "-- **************************************************************"
    end
  }
  logd "-- Tour zip finished"
  logd "---------------------------------------------------------------------"

  # #### #
  # Mark the status as "Ready for Review"
  # #### #
  t.status = 9
  raise "Tour with id #{t.id} could not update status to 10" \
    unless t.save!
end


# ########################################################################## #
# Main section
# ########################################################################## #
module Opts extend OptiFlagSet
  @tours = []

  # #### #
  # Command-line parameters
  # #### #
  usage_flag "h","help","?"
  extended_help_flag "morehelp"

  optional_switch_flag "verbose" do
    alternate_forms "v"
    description "Tour ID "
    long_form "verbose_on"
  end

  optional_flag "tours" do
    alternate_forms "t"
    description "Tour ID "
    long_form "tour_ids"
    value_matches ["Must be a valid list of tour ids", /^(\d+)((,\d+)+)?$/]
  end

  and_process!

  # #### #
  # Do the audio conversion either for a single tour or a set of tours
  #   or for all tours that are ready to be converted
  # #### #
  #t = Tour.find(ARGV.flags.tour)
  if ARGV.flags.tours.nil?
    #logd "-- Processing all tours with status 5"
    @tours = Tour.all(:conditions => {:status => 5})
  else
    logd "-- Tours given"
    tour_ids = ARGV.flags.tours.split(',')
    tour_ids.each do |t_id|
      begin
        @tours.push( Tour.find(t_id) )
      rescue
        $stderr.puts "Tour with ID #{t_id} could not be found"
        exit -1
      end
    end
  end
  count = 0
  @tours.each do |tour|
    begin
      logd tour.id
      zip_tour_audios( tour )
      count += 1
      break if count == 5
    rescue Exception => e
      $stderr.puts "Error processing tour '#{tour.id}' -- #{e.to_s}"
    end
  end
end
