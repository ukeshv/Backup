#!/usr/bin/python
#
# Audio file splitter. This script should be invoked via command line:
#
# (chmod +x splitter.py)
# splitter.py {name-of-audiofile}
#
# Note: for this to run, we need the presence of the following modules:
#
# - Python 2.6 -- if earlier, then we may also need to separately install 
#   re, plistlib, and shutil.
# - pexpect (easy_install pexpect)
# - ffmpeg (ffmpeg.org) with codecs for the audio file formats we want to
#   support.
#
import os, sys, pexpect, re, plistlib, shutil

PATHTOSERVER="/var/www/html/cache"
FFMPEGCMD="/usr/local/bin/ffmpeg"
SECONDSPERSEGMENT=30

def timeToString(timenum):
	timesecs = timenum
	hours = int(timesecs / 3600)
	timesecs -= (hours * 3600)
	minutes = int(timesecs / 60)
	timesecs -= (minutes * 60)
	seconds = timesecs
	timestring = "%02d:%02d:%02d" % (hours, minutes, seconds)
	return timestring

if len(sys.argv) != 2:
	print "--Command line: splitter.py {name-of-audiofile}"
	sys.exit(2)
else:
	inputfile = sys.argv[1]

if not os.path.exists(inputfile):
	print "--Input file not found: " + inputfile
	sys.exit(2)

# First we get the file size so we know how many slices to create
#
line = pexpect.run(FFMPEGCMD + ' -i '+inputfile)
durationMatch = re.search(r"Duration: (\d+):(\d+):(\d+)\.(\d+)", line)
hours = int(durationMatch.group(1))
minutes = int(durationMatch.group(2))
seconds = int(durationMatch.group(3))
hundreds = int(durationMatch.group(4))
totalsecs = (hours * 3600) + (minutes * 60) + seconds
totalslices = (totalsecs / SECONDSPERSEGMENT)
# Add one more if needed for last segment
if ((totalsecs % SECONDSPERSEGMENT) > 0):
	totalslices+= 1

duration="%02d:%02d:%02d.%02d" % (hours, minutes, seconds, hundreds)
print "Total: %d slices - Duration: %s" % (totalslices, duration)

exts=os.path.splitext(inputfile)
cachesubdir = exts[0]
filebase = "%s/%s" % (PATHTOSERVER, cachesubdir)

# Now we create a subdirectory with the base name of the file (i.e. if the
# file is 'foo.mp4' we'll be creating a directory called 'foo' (if it
# doesn't already exist) and putting the slices and the config file in there
#
if os.path.exists(filebase):
	shutil.rmtree(filebase, True)

print "Creating subdirectory for config and file: " + filebase
os.makedirs(filebase)

# Now we loop through and create a number of 1 minute long segment files

print "Generating slices."

startsecs = 0
slice = 0
slices = []

durationstring = timeToString(SECONDSPERSEGMENT)

for start in range(totalslices):
	slice += 1
	startstr = timeToString(startsecs)
	print "Generating slice #%d: Start:%s - Duration:%s" % (slice, startstr, durationstring)
	# This is the actual ffmpeg command that does the audio file slicing.
	# NOTE: if we want to change the file format, all we have to do
	# is change the file suffix for the outfile
	#
	outslice= "slice-%04d.aac" % (slice)
	outfile = "%s/%s" % (filebase, outslice)
	cmd = FFMPEGCMD + " -sameq -ss %s -t %s -i %s %s" % (startstr, durationstring, inputfile, outfile)
	# print "Running: " + cmd
	pexpect.run(cmd)
	slicedata = dict(
		index=slice,
		file=outslice,
		path=outfile,
		size=os.path.getsize(outfile),
	)
	slices.append(slicedata)
	startsecs += SECONDSPERSEGMENT

# Now we write the XML file in Apple plist format 

print "Files written... generating XML config."

outputplist = dict(entry=dict(
			filename=inputfile,
			duration=duration,
			size=os.path.getsize(inputfile),
			slicecount=totalslices,
			),
		slices=slices)

configFile = "%s/%s-config.xml" % (filebase, cachesubdir)
plistlib.writePlist(outputplist, configFile)
print "Config file written: " + configFile
print "Done."

