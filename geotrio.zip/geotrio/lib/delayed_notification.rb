class DelayedNotification
  attr_accessor :user_ids,:subject,:msg_to_send
  def initialize(user_ids,subject, msg_to_send)
    self.user_ids = user_ids
		self.msg_to_send = msg_to_send
		self.subject = subject
  end

  def perform
		users=User.find(self.user_ids)
		users && users.each do |user|
			UserMailer.deliver_whats_new_in_geotrio(user,self.subject,self.msg_to_send)
		end
  end
end