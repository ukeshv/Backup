module KmlGenerator
  def generate_kml(tracks, points)
    generated_kml =<<-GENERATEBASICKML
<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>Paths</name>
    <description>Examples of paths. Note that the tessellate tag is by default
      set to 0. If you want to create tessellated lines, they must be authored
      (or edited) directly in KML.</description>
          GENERATEBASICKML
          @length=points.length
      points && points.each_with_index do |point, index| 
        
      generated_kml +=<<STYLE1
             <Style id="normalPlacemark#{index}">
      <IconStyle>
STYLE1
if index == 0
   generated_kml +=<<STYLE4
           <Icon>
            <href>/images/stops/0.png</href>
        </Icon>
STYLE4

elsif @length-1 == index
   generated_kml +=<<STYLE5
           <Icon>
            <href>/images/stops/l.png</href>
        </Icon>
STYLE5

else
 generated_kml +=<<STYLE3
        <Icon>
            <href>/images/stops/stop#{index}.png</href>
        </Icon>

STYLE3
    	end
       generated_kml +=<<STYLE7
       </IconStyle>
    </Style>
       <StyleMap id="exampleStyleMap#{index}">
      <Pair>
        <key>normal</key>
        <styleUrl>#normalPlacemark#{index}</styleUrl>
      </Pair>
    </StyleMap> 
STYLE7
  end
     generated_kml +=<<STYLE2
    <Style id="yellowLineGreenPoly">
      <LineStyle>
        <color>7fff0000</color>
        <width>4</width>
      </LineStyle>
      <PolyStyle>
        <color>7fff0000</color>
      </PolyStyle>
    </Style>
STYLE2
        points && points.each_with_index do |point,index|
        generated_kml += <<-POINTS	
        <Placemark>
	 <styleUrl>#exampleStyleMap#{index}</styleUrl>
          <Point>
            <coordinates>
              #{point.longitude},#{point.latitude}, 10
            </coordinates>
          </Point>
        </Placemark>
      	POINTS
      end
       generated_kml += <<-GENERATELINE	 
    <Placemark>
      <LineString>
        <extrude>1</extrude>
        <tessellate>1</tessellate>
        <altitudeMode>absolute</altitudeMode>
				<coordinates>
				GENERATELINE
        
				tracks && tracks.each do |track|
				generated_kml += <<-COORDINATES	
         #{track.longitude},#{track.latitude}, 10
      	COORDINATES
				end
				generated_kml +=<<-GENERATELINE2
				 </coordinates>
      </LineString>
    </Placemark>
  </Document>
</kml>
GENERATELINE2
	 return generated_kml
	 end
end	 