module PaypalGatewaySystem
	protected
	def gateway
		gateway = ActiveMerchant::Billing::PaypalGateway.new(
		:login => PAYPAL_CONFIG['login'],
		:password => PAYPAL_CONFIG['password'],
		:signature => PAYPAL_CONFIG['signature'])
	end
end
