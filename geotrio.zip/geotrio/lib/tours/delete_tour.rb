#!/usr/local/bin/ruby


# ########################################################################## #
# Includes
# ########################################################################## #
require File.join(File.dirname(__FILE__), "..", "config", "boot")
require File.join(File.dirname(__FILE__), "..", "config", "environment")
# Note : require rubygems needed for optiflag
require 'rubygems'
require 'optiflag'
require 'tour'


# ########################################################################## #
# Methods
# ########################################################################## #


# ************************************************************************** #
# Logging method
# ************************************************************************** #
def logd(message)
  #puts "#{message}"
  puts "#{message}" if ARGV.flags.verbose
end

def delete_tour_search(tour_id)
  # #### #
  # Perform initial checks
  # #### #
  tour_search = TourSearch.find_by_id(tour_id)
  # #### #
  # Check for tour search record, delete if available
  # #### #
  if tour_search
    # #### #
    # if tour search record found
    # #### #
    logd "== ----------------------------------------------------------------"
    logd "== -- Deleting Tour Search ID = '#{tour_search.id}'"
    logd "== ----------------------------------------------------------------"
    tour_search.destroy
    logd "== ----------------------------------------------------------------"
    logd "== -- Successfully Deleted Tour Search ID = '#{tour_search.id}'"
    logd "== ----------------------------------------------------------------"
  else
    # #### #
    # if tour search  record not found
    # #### #
    logd "== ----------------------------------------------------------------"
    logd "== -- Tour search record not found"
    logd "== ----------------------------------------------------------------"
  end
end

def delete_tour_with_dependencies(tour_id)
  # #### #
  # Perform initial checks
  # #### #
  t = Tour.find(tour_id)

  # #### #
  # Delete tour with dependencies :
  #   DB    :: tour_tracks, tour_stops, stops, history and attachments
  #   Files :: tour overview audio and photos, stop audio and photos
  # #### #
  if t
    logd "== ----------------------------------------------------------------"
    logd "== -- Deleting Tour '#{t.id}' dependencies"
    t.destroy
    logd "== -- Successfully Deleted Tour '#{t.id}' dependencies"
    logd "== ----------------------------------------------------------------"
  end
end

def tour_dir_index(tour_id)
  i = (tour_id.to_i / 10000) + 1
  return i
end

def delete_tour_files_folder(tour_id)
  dir = "#{APP_CONFIG[:files_dir]}/#{tour_dir_index(tour_id)}/#{tour_id}"
  if !File.exists?(dir)
    $stderr.puts "Tours directory #{dir} not found"
    return false
  end
  raise "Tours directory #{dir} not a directory" unless File.directory?(dir)

  # #### #
  # Remove tours folder
  # #### #
  logd "== ------------------------------------------------------------------"
  logd "== -- Deleting Tour '#{tour_id}' directory '#{dir}'"
  `rm -rf #{dir}`
  if File.exists?(dir)
    logd "== -- Deleting Tour '#{tour_id}' directory '#{dir}' failed"
  else
    logd "== -- Deleting Tour '#{tour_id}' directory '#{dir}' worked"
  end
  logd "== ------------------------------------------------------------------"

  return true
end

def delete_tour(tour_id)
  logd "====================================================================="
  logd "== delete_tour(#{tour_id}) starting"
  if delete_tour_files_folder(tour_id)
    delete_tour_search(tour_id)
    delete_tour_with_dependencies(tour_id)
  end
  logd "== delete_tour(#{tour_id}) finished"
  logd "====================================================================="
end


# ########################################################################## #
# Main section
# ########################################################################## #
module Opts extend OptiFlagSet
  # #### #
  # Command-line parameters
  # #### #
  usage_flag "h","help","?"
  extended_help_flag "morehelp"

  optional_switch_flag "verbose" do
    alternate_forms "v"
  end

  optional_flag "tour" do
    alternate_forms "t"
    description "Tour ID "
    long_form "tour_id"
    value_matches ["Must be a valid tour id", /^(\d+)$/]
  end

  and_process!
end

begin
  # #### #
  # Only root can delete tours
  # #### #
  raise 'Must run as root' unless Process.uid == 0

  # #### #
  #  Delete Tours with status -2 or delete a specific tour
  # #### #
  if ARGV.flags.tour
    logd "-- Deleting specific tour"
    delete_tour(ARGV.flags.tour)
  else
    logd "-- Deleting all marked tours"
    Tour.all(:conditions => "status = -2").each do |t|
      #puts t.id
      delete_tour(t.id)
    end
  end
rescue Exception => e
  $stderr.puts e.to_s
end
