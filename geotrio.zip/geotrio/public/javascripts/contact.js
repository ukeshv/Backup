function formValidator(){
    var name = $('name');
    var email = $('email');
    var subject = $('subject');
    var content = $('content');
    if(notEmpty(name, "Please enter your name")){
        if(notEmpty(email, "Please enter your email")){
            if(emailValidator(email, "Invalid Email")){
                if(notEmpty(subject, "Please enter a subject")){
                    if(notEmpty(content, "Please enter some content")){
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

function notEmpty(elem, helperMsg){
    if(elem.value.length == 0){
        alert(helperMsg);
        elem.focus();
        return false;
    }
    return true;
}

function emailValidator(elem, helperMsg){
    var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
    if(elem.value.match(emailExp)){
        return true;
    }else{
        alert(helperMsg);
        elem.focus();
        return false;
    }
}