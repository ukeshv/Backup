function check_for_empty(){
    //$('displayerror').hide();
    var username = $('username');
    var password = $('password');
    var error = 1;
    var error1 = 1;
    if(notEmpty(password, "password_error")){
        error = 0;
    $("displayerror").hide()
    }
    if(notEmpty(username, "username_error")){
    $("displayerror").hide()
        error1 = 0;
    }
    if(error == 0 && error1==0)
    {
    $("displayerror").hide()
        return true;
    }
    else{
        $("displayerror").hide()
        return false;
    }
}
function notEmpty(elem, div_id){
    if(elem.value.length == 0){
        document.getElementById(div_id).style.display="inline";
        elem.focus();
        return false;
    }
    else{
        document.getElementById(div_id).style.display="none";
    }
    return true;
}


