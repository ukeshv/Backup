require 'rubygems'
require 'net/http'
require 'net/https'
require 'uri' 
require 'digest/md5'

class RegisterDevice
	def initialize
		puts send_registration_request
	end 
	
	def send_registration_request
		secret_key = "foobar"
		http = Net::HTTP.new('apitest.geotrio.com', 443)
		http.use_ssl = true
		path = '/api/v1/register'
		data = "user_id=srikanth&device_id=#{get_random_chars}&secret=#{secret_key}"
		resp, data = http.post(path, data)
	end 
	
	def get_random_chars
		chars = ("a".."z").to_a + ("0".."9").to_a
		rand_number = ""
		1.upto(40) { |i| rand_number << chars[rand(chars.size-1)] }
		return rand_number
	end
	
	def encode_key(secret_key)
		Digest::MD5.hexdigest("#{secret_key} + #{get_random_chars}")
	end 
end 
	
RegisterDevice.new