#!/bin/bash

export RAILS_ENV=production
/var/www/apps/geotrio/current/lib/audio/geotrio-chunk-audio.rb -v
