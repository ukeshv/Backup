#!/bin/bash

export RAILS_ENV=production
/var/www/apps/geotrio/current/lib/audio/geotrio-tour-s2r.rb -v
