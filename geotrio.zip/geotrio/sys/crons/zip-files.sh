#!/bin/bash

export RAILS_ENV=production
/var/www/apps/geotrio/current/lib/audio/geotrio-zip-audio.rb -v
