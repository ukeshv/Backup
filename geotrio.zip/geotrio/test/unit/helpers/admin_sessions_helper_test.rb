require 'test_helper'

class AdminSessionsHelperTest < ActionView::TestCase
end
