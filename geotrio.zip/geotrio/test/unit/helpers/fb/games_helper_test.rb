require 'test_helper'

class Fb::GamesHelperTest < ActionView::TestCase
end
