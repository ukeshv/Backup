require 'test_helper'

class GroupAdminHelperTest < ActionView::TestCase
end
