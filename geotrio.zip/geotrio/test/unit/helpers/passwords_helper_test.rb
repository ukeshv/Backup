require 'test_helper'

class PasswordsHelperTest < ActionView::TestCase
end
