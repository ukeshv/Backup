require 'test_helper'

class StopsHelperTest < ActionView::TestCase
end
