require 'test_helper'

class ToursHelperTest < ActionView::TestCase
end
