class AccountController < ApplicationController
  layout :clear_or_account
  observer :user_observer
  before_filter :login_required,:only=>[:dashboard,:general_account]
  before_filter :setting_company_details, :only=>[:dashboard]

  require 'soap/wsdlDriver'
  def index
    if logged_in? && session[:user_id] && current_company
    redirect_to(:action => 'dashboard') and return 
    else
          log_visitor_activity if request.get?
          session[:plan] = nil
          session[:amount] = nil		
          return unless request.post?
          self.current_user = User.authenticate(params[:email], params[:password])
            if logged_in?
              log_user_login_activity
              session[:user_id] = current_user.id
            
             if current_user.owned_companies.length==1 && current_user.authorized_companies.length == 0 
              self.current_company=current_user.owned_companies.first
            elsif current_user.owned_companies.length==0 && current_user.authorized_companies.length == 1
              self.current_company=current_user.authorized_companies.first
            elsif current_user.owned_companies.length >= 1 || current_user.authorized_companies.length >= 1
              #self.current_company = current_user.owned_companies.first || current_user.authorized_companies.first  ### ???
              redirect_to :action=>'choose_company' and return false
            else 
              c = Company.new(:name=>"No Name", :email=>params[:email], :user_id=>session[:user_id] )
              c.save_with_validation(false)
              self.current_company = c
              flash[:notice] = "This is your first Company. Please Fill all details to proceed further"
            end
            
            flash[:notice] = "Logged in successfully"
            redirect_back_or_default(:controller => 'account', :action => 'dashboard') and return # Double renderer error.
          else
            if User.activated(params[:email], params[:password])
            flash[:error] = "Your Account not been activated. Activate your account using the activation mail sent by us."
            redirect_back_or_default(:controller => 'account', :action => 'login') and return
            else
            flash[:error] = "Invalid Email/Password"
            redirect_back_or_default(:controller => 'account', :action => 'login') and return 
            end
          end
     end #  redirected to dashboard     
  end
	
  def choose_company
    @owned_companies=current_user.owned_companies
    @authorized_companies=current_user.authorized_companies
  end
  
  def selected_company
    if current_user
       new_company = current_user.authorized_companies.find_by_id(params[:id]) ||  current_user.owned_companies.find_by_id(params[:id])
       if new_company 
          self.current_company=new_company  
       else  
          flash[:error] = "Illegel Atempt to View other company"
       end
    end
    redirect_back_or_default(:controller => 'account', :action => 'dashboard') and return
  end
  
  def delete_company
    company_id = current_company.id
    company_name = current_company.name
    if request.delete? and current_user.owned_companies.collect{|x| x.id}.include?(current_company.id)
      Account.delete_all("company_id = #{company_id}")
      Contact.delete_all("company_id = #{company_id}")
      Employee.delete_all("company_id = #{company_id}")
      EntryStatusLog.delete_all("company_id = #{company_id}")
      ExpenseDetail.delete_all("company_id = #{company_id}")
      InvoiceDetail.delete_all("company_id = #{company_id}")
      Journal.delete_all("company_id = #{company_id}")
      Payroll.delete_all("company_id = #{company_id}")
      RecurringTransact.delete_all("company_id = #{company_id}")
      Transact.delete_all("company_id = #{company_id}")
      UserAccess.delete_all("company_id = #{company_id}")
      CompanyDetails.delete_all("attachable_id = #{company_id}")
      Company.delete(company_id)
      user = current_user
      reset_session
      session[:user] = user
      flash[:notice] = "Company ' #{company_name} ' deleted"
    else  
      flash[:error] = "Illegel attempt to delete Company: ' #{company_name} '"
    end
    redirect_to :action=>'choose_company'
  end
  
  def dashboard
    redirect_to(:action => 'index') unless logged_in? || User.count > 0
    set_location('/account/dashboard')
    session[:invoice_sort] = nil
    session[:invoice_page] = nil
    session[:invoice_per_page] = nil
    session[:expense_sort] = nil
    session[:expense_page] = nil
    session[:expense_per_page] = nil
    all_invoice_list
    all_expense_list
    @any_amount = Group.find_by_sql(" SELECT sum( opening_balance ) as op, sum( closing_balance ) as cb FROM accounts WHERE company_id ="+current_company.id.to_s)
    render :layout=>'clear'
   end

  def all_invoice_list
		@source_type=[$INVOICE]
  	@recurring_invoice_limit=Jujube.get_recurring_invoice_number
  	(1..@recurring_invoice_limit).each do |invoice_number|  @source_type<<"#{$INVOICE_RECURRING} #{invoice_number}" end
    invoice_list($INVOICE,@source_type)
  end
  
  def all_expense_list
    @source_type=[$EXPENSE,$PAYROLL_CRON]
  	@recurring_expense_limit=Jujube.get_recurring_expense_number
  	(1..@recurring_expense_limit).each do |expense_number|  @source_type<<"#{$EXPENSE_RECURRING} #{expense_number}" end
    expense_list([$EXPENSE,$PAYROLL_EXPENSE],[$FLAG[:PAID],$FLAG[:UNPAID],$FLAG[:DRAFT]],@source_type)
  end
     
  def find_current_company
    #current_client = self.current_user.client
    #session[:client]=current_client
    current_company=current_user.companies[0]
    #if current_client.companies && current_client.companies.length>1
     # redirect_to '/account/choose_company'
    #elsif current_client.companies && current_client.companies.length==1
   #    self.current_company=current_client.companies[0]
    # end
  end
  
  def signup
    @user=User.new
    return unless request.post?
    set_location('/account/index')
    @user = User.new(params[:user])  
    @creditcard_detail = CreditcardDetail.new(params[:creditcard_detail])
    @company = Company.new(:email=>@user.email)
    #@client=Client.new(:email=>@user.email)
		session[:plan]='plan1' if session[:plan]==nil || session[:plan]==""
		session[:amount]=0 if session[:amount]==nil || session[:amount]==""
    if session[:amount] && session[:amount]!=0
			amount = session[:amount] * 100
      if @user.valid? and @creditcard_detail.valid? and @company.valid? #and @client.valid? 
      #@result = make_order(@user,@creditcard_detail,amount)  
      #@client.save   
      #@user.client_id = @client.id
      @user.save  
      @creditcard_detail.user_id = @user.id   
      @creditcard_detail.save
      @company.owner=@user
      @company.save
      @creditcard_detail.update_attributes(:status=>"successful",:user_id=>@user.id,:payment_date=>Time.now)  
      create_client_companies(@user)
      redirect_back_or_default(:controller => 'account', :action => 'index')
      UserNotifier.deliver_signup_notification(@user,request)
      flash[:notice] = "Thanks for signing up! A mail has been sent to #{@user.email} with further instructions." 
      end
   elsif session[:amount]==0
      if @user.valid? and @company.valid? #and @client.valid? 
      #@client.save   
      #@user.client_id = @client.id
      @user.save
      @company.owner=@user
      @company.save
      create_client_companies(@user)
      redirect_back_or_default(:controller => 'account', :action => 'index')
      UserNotifier.deliver_signup_notification(@user,request)
      flash[:notice] = "Thanks for signing up! A mail has been sent to #{@user.email} with further instructions."
      end
    else
      render :action => 'signup'
    end
   end
  
  def create_client_companies(user)
  #@client=Client.create!(:first_name=>user.first_name,:last_name=>user.last_name,:street1=>user.street1,:street2=>user.street2,:city=>user.city,:state=>user.state,:zip=>user.zip,:country=>user.country,:phone=>user.phone,:fax=>user.fax,:email=>user.email,:website=>user.website)
  #@company.update_attributes(:email=>user.email,:plan_name=>session[:plan])
  #session[:plan]=nil
  #session[:amount]=nil
  #UserAccess.create_company_access_for_user(user,@company)
  end

#these lines are commented because the remote url is not responding.
=begin
def make_order(user,creditcard,amount)
    #expiration=creditcard.expiration_month.to_s+creditcard.expiration_year.to_s
    #service =SOAP::WSDLDriverFactory.new("https://ws.paymentech.net/PaymentechGateway/wsdl/PaymentechGateway.wsdl").create_rpc_driver
    #@service_output  = service.NewOrder(:industryType =>"RC",:transType=>"A",:bin=>"000001",:merchantID=>"041756",:terminalID=>"001",:cardBrand=>"SW",:ccAccountNum=>creditcard.creditcard_number.to_s,:ccExp=>expiration.to_s,:ccCardVerifyPresenceInd=>"1",:orderID=>"31103142361483",:amount=>amount.to_s)
 end  
=end 
  
  def activate
     if params[:id]
      @user = User.find_by_activation_code(params[:id]) 
      if @user and @user.activate
        self.current_user = @user
        session[:user_id] = current_user.id
        #session[:client]=current_user.client
        self.current_company=current_user.owned_companies.first #in change company method set the session with what company you switch to
        UserNotifier.deliver_activation(@user,request) if @user.recently_activated?
        flash[:notice] = "<b>Your account has been activated.</b>" 
        redirect_back_or_default(:controller => '/account', :action => 'dashboard')
      else
        flash[:notice] = "Unable to activate the account.  Did you provide the correct information?" 
        redirect_back_or_default(:controller => '/account', :action => 'index')
      end
    else
      flash.clear
    end
  end   
  
  def accept_company
    if params[:id]
      @user_access = UserAccess.find_by_access_activation_code(params[:id]) 
      if @user_access and @user_access.activate_access
        self.current_user = @user_access.user
        session[:user_id] = current_user.id
        self.current_company=@user_access.company
        flash[:notice] = "<b>Your new account with #{current_company.name} has been activated.</b>" 
        redirect_back_or_default(:controller => '/account', :action => 'dashboard')
      else
        flash[:notice] = "Unable to activate the account.  Did you provide the correct information?" 
        redirect_back_or_default(:controller => '/account', :action => 'index')
      end
    else
      flash.clear
    end
  end
  
  
  def re_activate
     if params[:id]
      @user = User.find_by_new_email_activation_code(params[:id]) 
      if @user and @user.re_activate
        self.current_user = @user
        session[:user_id] = current_user.id
        #session[:client]=current_user.client
        session[:company]=current_user.owned_companies.first #in change company method set the session with what company you switch to
        UserNotifier.deliver_activation(@user,request) if @user.recently_activated?
        flash[:notice] = "<b>Your account has been re activated with new email.</b>" 
        redirect_back_or_default(:controller => '/account', :action => 'dashboard')
      else
        flash[:notice] = "Unable to activate the account.  Did you provide the correct information?" 
        redirect_back_or_default(:controller => '/account', :action => 'index')
      end
    else
      flash.clear
    end
  end   

  def forgot_password
    return unless request.post?
    if @user = User.find_by_email(params[:email])
      @user.forgot_password
      @user.save
      UserNotifier.deliver_forgot_password(@user,request) if @user.recently_forgot_password?
      redirect_back_or_default(:controller => '/account', :action => 'index')
      flash[:notice] = "A password reset link has been sent to your email address" 
    else
      flash[:error] = "Could not find a user with that email address" 
    end
  end

  def reset_password
    @user = User.find_by_password_reset_code(params[:id])
    raise if @user.nil?
    return if @user unless params[:password]
      if (params[:password] == params[:password_confirmation])
        self.current_user = @user #for the next two lines to work
        current_user.password_confirmation = params[:password_confirmation]
        current_user.password = params[:password]
        @user.reset_password
        flash[:notice] = current_user.save ? "Your Password has been reset" : "Your Password is not reset" 
        UserNotifier.deliver_reset_password(@user,request) if @user.recently_reset_password?
        redirect_back_or_default(:controller => '/account', :action => 'index') 
      else
        flash[:error] = "Password mismatch" 
      end  
  rescue
    logger.error "Invalid Reset Code entered" 
    flash[:error] = "Sorry - That is an invalid password reset code. Please check your code and try again. (Perhaps your email client inserted a carriage return?" 
    redirect_back_or_default(:controller => '/account', :action => 'index')
  end
  
	def general_account
    @groups = Group.find(:all, :conditions=>["parent_id = ?",0])   
	end
 
	def logout
    cookies.delete :auth_token
    reset_session
    redirect_back_or_default(:controller => 'account', :action => 'index')
  end
	
	def auto_logout
    cookies.delete :auth_token
    reset_session
  end  
	
  def delete_user_account
    return unless request.post?
    if params[:email]
      @user = User.find_by_email(params[:email])
			current_user=@user
			Company.current=current_user.owned_companies.first
      if @user
        UserNotifier.deliver_account_delete_notification(@user,request)
        @user.destroy
				#@user.client.destroy
				@user.owned_companies.first.destroy
        logout
      else
        flash[:notice]="User Not Find With this Email Id"
      end
    end
  end
  
  def pricing
    @plans = Plan.find(:all)
		if request.post?
			if params[:selected_plan]
				session[:plan] = params[:selected_plan]
				session[:amount] = params[:amount].to_f
				redirect_to :action=>"signup"
			end  
		else
			session[:plan] = nil
			session[:amount] = nil
		end
  end  
  
  def buzz
    if params[:page]
      session[:blog_page]=params[:page]
    elsif session[:blog_page]
      session[:blog_page]=session[:blog_page]
    else
      session[:blog_page]=1
    end
    if params[:per_page]
      session[:blog_page]=1
      session[:blog_per_page] = params[:per_page]
    else
      session[:blog_per_page] = 10
    end
    @blog_start_record=(session[:blog_page].to_i*session[:blog_per_page].to_i)-session[:blog_per_page].to_i
    @blog_end_record= @blog_start_record +  session[:blog_per_page].to_i  - 1  
    @blogs  = Blog.find(:all, :order => "created_at desc")
    @blog_records=@blogs.length
    @blog_pages= (@blogs.length.to_f/session[:blog_per_page].to_i).ceil
    @categories = Category.find(:all)
    @links = UrlLink.find(:all,:order=>"created_at desc")
    if request.xml_http_request?
      render :partial => "/account/blog_list", :layout => false
    end
  end  
  
  def show_full_blog_content    
    @blog = Blog.find(params[:id])
    unless @blog && @blog.nil?
    @blog.update_attributes(:views=>@blog.views.to_i + 1)
    render :update do |page|
      page.replace_html "show_blog_"+"#{params[:id].to_s}",@blog.content
    end  
    end  
  end
  
  def show_blog
    if params[:id]
    @blog = Blog.find(:all,:conditions=>["id = ? ",params[:id]])    
    elsif params[:category]
    @blog = Blog.find(:all,:conditions=>["category_id = ?",params[:category]])
  end
  @blogs = @blog unless @blog.nil?
  end
  
  def terms_of_service
    #render :layout=>false
  end  
  
  def privacy_policy
    #render :layout=>false
  end  
  
	def tour
		render :file=>'public/static_pages/tour.html'
	end
	
  def error_display
    current_company.update_attributes(:error_display=>1)
    render :update do |page|      
    end  
  end  
	
  def clear_or_account
  ['index', 'login', 'about','pricing','buzz','faq','auto_logout','privacy_policy','show_blog','terms_of_service', 'signup', 'forgot_password', 'reset_password'].include?(action_name)	? 'account' : 'clear'
  end
	
    def support_thank_u
      email = params[:email]
      subject = params[:subject]
      comment = params[:comment]
      UserNotifier.deliver_support_notification(email, subject, comment)
    end
end
