class AdminController < ApplicationController
	layout 'admin'
	def index
		return unless request.post?
		if params[:user]==$ADMIN[:user] && params[:password]==$ADMIN[:password]
			session[:admin]=true 
			flash[:success] = "Welcome #{$ADMIN[:user]}"
			render :action=>'report'
		else
			flash[:error] = "Invalid User/Password"
			session[:admin]=false
		end		
	end
	

 def report
		if session[:admin]
			premium_user_hits = params[:premium_user]
			  @collector_agent = {}
				@from_date = params[:from_date] ? params[:from_date].to_time.strftime('%Y-%m-%d 00:00:00') : Time.now.strftime('%Y-%m-%d 00:00:00')
				@to_date = params[:to_date] ? params[:to_date].to_time.strftime('%Y-%m-%d 23:59:59') : Time.now.strftime('%Y-%m-%d 23:59:59')
				session[:nav_log] = {}
				session[:non_user] = {}
				session[:premium_user] = {}
				user_ids=[]
				if premium_user_hits && premium_user_hits !="" 
				   premium_users=NavigationLog.find_by_sql("SELECT count(`user_token_id`) as counter, `user_id`  FROM `navigation_logs` where `visited_on` >= '#{@from_date}' and `visited_on` <= '#{@to_date}' and user_id <> 0 group by `user_token_id` HAVING counter > #{premium_user_hits}")
				   session[:premium_users] = premium_users.collect {|x| x.user_id}.uniq
				end
				(@from_date.to_date..@to_date.to_date).to_a.each do |date|
					nL = NavigationLog.find(:all, :conditions=>["visited_on = ? and user_id <> 0",date], :select=>"user_id, user_token_id")
					user_ids =  nL.collect{|x| x.user_id}.uniq
					user_token_ids =  nL.collect{|x| x.user_token_id}.uniq
					session[:non_user][date] = NavigationLog.count(:all, :conditions=>["visited_on = ? and user_id = ? and user_token_id not in (?)",date,0,user_token_ids], :select=>"user_id")
					if user_ids.length > 0
						session[:nav_log][date] = user_ids 
						session[:premium_user][date] = session[:premium_users]  ? (session[:nav_log][date] & session[:premium_users]).length : 'N/A'
					end	
				end
			        
		else
			render :action=>'index'
		end
 end


def user_details
		render :update do |page|
		date = params[:date].to_date
		user_ids_for_the_day = session[:nav_log][date]
		@days = params[:to_date].to_date - params[:from_date].to_date + 1
		@r=User.find(user_ids_for_the_day)
		arr = session[:nav_log].values.flatten
		@visit_counter = arr.inject(Hash.new(0)) { |h,v| h[v] += 1; h }
		@date = date
		page.replace_html("box",:partial=>"user_details")
		end
end

=begin
	def report
		if session[:admin]
				from_date = params[:from_date] ? params[:from_date].to_time.strftime('%Y-%m-%d 00:00:00') : Time.now.strftime('%Y-%m-%d 00:00:00')
				to_date = params[:to_date] ? params[:to_date].to_time.strftime('%Y-%m-%d 23:59:59') : Time.now.strftime('%Y-%m-%d 23:59:59')
				if from_date.to_date <= to_date.to_date
						@report = {}
						@member = {}
						
						@report[:total_visitors_queries] = NavigationLog.find(:all, :conditions=>["`on` >= ? and `on` <= ?",from_date,to_date])
						@report[:total_visitors_count] = @report[:total_visitors_queries].collect{|x| x.user_token}.uniq.length
						
						@report[:total_member_visitors_queries] = NavigationLog.find(:all, :conditions=>["`on` >= ? and `on` <= ? and user_id <> 0 ",from_date,to_date])
						members_user_tokens = @report[:total_member_visitors_queries].collect{|x| x.user_id}.uniq
						@report[:total_member_visitors_count] = members_user_tokens.length
						
						@report[:total_non_member_visitors_queries] = @report[:total_visitors_queries] - @report[:total_member_visitors_queries]
						@report[:total_non_member_visitors_queries].delete_if{|x| members_user_tokens.include?(x.user_token) }
						
						@report[:total_non_member_visitors_count] = @report[:total_non_member_visitors_queries].collect{|x| x.user_token}.uniq.length
						
						@report[:total_new_users_queries] = User.find(:all, :conditions=>["created_at >= ? and created_at <= ?",from_date,to_date])
						@report[:total_new_users_count] = @report[:total_new_users_queries].length 
						
						member_visitors_ids = NavigationLog.find(:all, :conditions=>["`user_id` <> 0 and `on` >= ? and `on` <= ?", from_date, to_date]).collect{|x| x.user_id}.uniq
						@visited_members = User.find(member_visitors_ids)
						
            @visited_members.each do |user|
						  @member[user.id] = [ user, NavigationLog.find(:all, :conditions=>["`user_id`= ? and `on` >= ? and `on` <= ?",user.id, from_date, to_date]) ]
					  end
					
				end 
		else
			render :action=>'index'
		end
	end
=end

	def logout
			session[:admin]=nil
			redirect_to '/'
	end
	
=begin
	def report_visitors_ctrl
		@report = {}
		@from_date=params[:from_date].to_date
		@to_date=params[:to_date].to_date
		u=UserToken.find(:all, :conditions=>["`created_at` >= ? and `updated_at` <= ?",@from_date,@to_date]).collect{|x| x.id}
		@report[:total_visitors_queries] = NavigationLog.find(:all, :conditions=>["user_token_id in (?)",u])
		render :update do |page|
		@r=@report[:total_visitors_queries] 
		page.show 'total_visitors'
		page.hide 'tvc_details' 
		page.replace_html("total_visitors",:partial=>"query_details",:object=>@r)
		#page.replace 'total_visitors',query_details(@report[:total_visitors_queries])
		end
	end
=end

	def report_member_visitors_ctrl
		@report = {}
		@from_date=params[:from_date].to_date
		@to_date=params[:to_date].to_date
		u=UserToken.find(:all, :conditions=>["created_at >= ? and updated_at <= ? and user_id <> 0",@from_date,@to_date,],:group=>'user_id').collect{|x| x.id}
		@report[:total_member_visitors_queries] = NavigationLog.find(:all, :conditions=>["user_token_id in (?) and user_id <> 0",u])
		render :update do |page|
		@r=@report[:total_member_visitors_queries]
		page.show 'total_members'
		page.hide 'tmv_details'
		page.replace_html("total_members",:partial=>"query_details",:object=>@r)
		#page.replace 'total_members',query_details(@report[:total_member_visitors_queries])
		end
	end
	
	def report_non_member_visitors_ctrl
		@report = {}
		@from_date=params[:from_date].to_date
		@to_date=params[:to_date].to_date
		u=UserToken.find(:all, :conditions=>["`created_at` >= ? and `updated_at` <= ? and user_id = 0 ",@from_date,@to_date]).collect{|x| x.id}
		@report[:total_non_member_visitors_count] = NavigationLog.find(:all, :conditions=>["`user_token_id` in (?)",u] )
		render :update do |page|
		@r=@report[:total_non_member_visitors_count]
		page.show 'total_non_member_visitors'
		page.hide 'tnmv_details' 
		page.replace_html("total_non_member_visitors",:partial=>"query_details",:object=>@r)
		#page.replace 'total_non_member_visitors',query_details(@report[:total_non_member_visitors_count])
		end
	end
	
	def report_new_users_ctrl
		@from_date=params[:from_date].to_date
		@to_date=params[:to_date].to_date
		@member = User.find(:all, :conditions=>["DATE(created_at) >= ? and DATE(updated_at) <= ?",@from_date,@to_date])
		render :update do |page|
		page.show 'total_users'
		page.hide 'tnu_details'
		page.replace_html("total_users",:partial=>"details",:object=>@member)
		#page.replace 'total_users',user_details(@report[:total_new_users_queries])
		end
	end
	
	def report_member_visitor_details_ctrl
		@from_date=params[:from_date].to_date
		@to_date=params[:to_date].to_date
		render :update do |page|
		@r = user_navigation_log(params[:user])
		page.show 'total_visited_users'
		page.hide "usr_details_#{params[:user]}"
		page.replace_html("total_visited_users",:partial=>"query_details",:object=>@r)
		#page.replace 'total_visited_users',query_details(user_navigation_log(@user_id))
		end
	end	
end
