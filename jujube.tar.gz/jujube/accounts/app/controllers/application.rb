# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  # Pick a unique cookie name to distinguish our session data from others'
  include ExceptionNotifiable
  include AuthenticatedSystem
  require "faster_csv"
  session :session_key => '_jujube_session_id'
  $DEBIT_GROUP=[1,5]
  $CREDIT_GROUP=[2,3,4]
  $INVOICE = "INVOICE"
  $INVOICE_RECEIVED = "INVOICE_RECEIVED"
  $INVOICE_RECURRING = "INVOICE_RECURRING"
  $EXPENSE = "EXPENSE"
  $EXPENSE_PAID = "EXPENSE_PAID"
  $CHEQUE = "CHEQUE"
  $CHEQUE_PAID = "CHEQUE_PAID"
  $PAYMENT_TYPE={"CHEQUE"=>"CHEQUE", "CASH"=>"CASH","CREDIT_CARD"=>"CREDIT_CARD"}
  $EXPENSE_RECURRING = "EXPENSE_RECURRING"
  $JOURNAL = "JOURNAL"  
  $REMITTANCE = "REMITTANCE"  
  $OVERDUE_REMITTANCE = "OVERDUE_REMITTANCE"  
  $PAYROLL_EXPENSE = "PAYROLL_EXPENSE"
  $PAYROLL_EXPENSE_PAID = "PAYROLL_EXPENSE_PAID"
  $PAYROLL_BASE= "PAYROLL_BASE"
  $INVOICE_CRON = "INVOICE_CRON"
  $EXPENSE_CRON = "EXPENSE_CRON"
  $ACCESS={"ALL"=>0,"INVOICE_AND_EXPENSE"=>1,"VIEW_ONLY"=>2}
  $ACCOUNT={:ADMIN=>0,:EMPLOYEE=>1,:ADVISOR=>2}
  $FLAG={:PAID=>0,:DRAFT=>1,:UNPAID=>2,:RECURRING=>3,:PAYROLL=>4,:REMITTANCE=>5,:DELETED=>9}
  $EXPENSE_DUE_LIMIT=30
  $FCC_CSV = RAILS_ROOT + "/public/csv/federal_claim.csv"
  $ENTRY={:INVOICE=>0,:EXPENSE=>1,:JOURNAL=>2}
  $QC_MAX = 571.29
  $PROVINCE_MAX = 711.03
  $LOG_ACTION={:CREATE => "Created", :DRAFT => "Saved as Draft", :PROCESS => "Processed", :EDIT => "Modified", :PAY => "Paid", :EMAIL => "E-mailed",:PRINT => "Printed",:DELETE => "Deleted", :REVERT=>"Payment Reverted"}

  
  $business_types = [ ['Select'], ['Bookkeeper'],['Daycare / Nursery'],['Information Technology'],['Management Consultant'],
  ['Medical'],['Musician(s)'],['Photography'],['Project Management'],['Other']]
  $ADMIN={:user=>'admin',:password=>'admin123'}

  session :session_expires_after => 900.seconds
	
#before_filter :current_company

  def setting_company_details
       if current_company and current_user
         if current_company.selected_province.to_s.strip.empty? or current_company.year_end_date.to_s.strip.empty? or current_company.net_days==nil or current_company.business_number.to_s.strip.empty? or current_company.name.to_s.strip.empty? or current_company.business_type.to_s.strip.empty? or current_company.owner.nil? or current_company.owner.first_name.to_s.strip.empty? or current_company.owner.last_name.to_s.strip.empty? or current_company.owner.title.to_s.strip.empty?
           redirect_to :controller=>'settings', :action=>'my_company'
         end  
       end
  end

  def log_user_login_activity
    user_token = get_cookie
    user_token_record = UserToken.find_by_name_and_user_id(user_token, current_user.id)
    if user_token_record.nil?
    user_token_record = UserToken.find_by_name_and_user_id(user_token, 0)
    if user_token_record
       user_token_record.update_attributes(:name=>user_token, :user_id=>current_user.id)
    else
       user_token_record=UserToken.create(:name=>user_token, :user_id=>current_user.id)
    end
    else
      user_token_record.update_attributes(:updated_at => Date.today) if user_token_record.updated_at < Date.today
    end
    if NavigationLog.find_by_visited_on_and_user_token_id_and_user_id(Date.today, user_token_record.id, current_user.id).nil?
      NavigationLog.create({:visited_on=>Date.today,:user_token_id=>user_token_record.id, :user_id=>current_user.id})
    end
  end

  def log_visitor_activity
    user_token = get_cookie
    user_token_record=UserToken.find_by_name(user_token)
    user_token_record=UserToken.create(:name=>user_token, :user_id=> 0)  if !user_token_record
    if NavigationLog.find_by_visited_on_and_user_token_id(Date.today, user_token_record.id).nil?
      NavigationLog.create({:visited_on=>Date.today,:user_token_id=>user_token_record.id, :user_id=>0})
    end  
  end

def get_cookie
  if !cookies[:user_token]
     remote_ip = request.env['REMOTE_ADDR']
     user_agent = request.env['HTTP_USER_AGENT']
     user_token = Digest::SHA1.hexdigest("#{remote_ip}-#{Time.now.to_i}-#{user_agent}")
     cookies[:user_token] = { :value => user_token, :expires => Time.now.advance({:years=>1}) }
  else  
    user_token = cookies[:user_token]
  end           
  user_token
end


  def formatted_number(number)
    length=number.to_s.length
    if length>5
      return number
    else
      padded_number='0' * (5-length)  +number.to_s  
    end
  end



  def add_new_contact(type)    
    @contact = Contact.new(params[:contact])
    @contact.contact_type = type
    if @contact.save
      common_initialize   
      if type=="client"
        @contact_list = @acc_rec_list
      else
        @contact_list = @acc_pay_list
      end 
      render :update do |page|
        page.call "RedBox.close"
        page.replace_html "contact_list", :partial=> "/partial/contact_list",  :locals => { :contact_list => @contact_list, :type=> type }
        page.call "select_option",'transact_account_id',@contact.company_name
        page.replace_html :address, :partial =>"/partial/address",  :locals => { :address => @contact }
      end
    else
      render :update do |page|
        page.replace_html "error_company_name" ,  "#{error_message_on :contact, :company_name}"
      end
    end
  end
  
  def get_contact_address
  render :update do |page|
    if params[:value]=="add_new"
      page.replace_html :address, "" 
      page.call "RedBox.showInline",'new_contact' 
    elsif params[:value]=="one_time_vendor"
      page.replace_html :address, "" 
      page.show 'one_time_vendor' 
    else
      @address = Contact.find_by_account_id(params[:value])
      page.replace_html :address, :partial =>"/partial/address",  :locals => { :address => @address }
    end
  end
  end
  
   def invoice_list(invoice_type, source_type,filter_condition="transacts.id!=0")
		session[:invoice_sort] =  params[:sort] || session[:invoice_sort] || "transacts.flag desc"
		session[:invoice_page] = params[:page] || session[:invoice_page] || 1
		session[:invoice_page]=1 if params[:per_page]
		session[:invoice_per_page] = params[:per_page] || session[:invoice_per_page] || 10
 		@invoices = Transact.paginate  :page => params[:page], :per_page =>session[:invoice_per_page] ,:conditions=>["transact_type = ? and debit_amount > 0  and source in (?) and (#{filter_condition} )",invoice_type, source_type], :include=>"account", :order => session[:invoice_sort] # for will_paginate ######## and flag != 9
    if request.xml_http_request?
      render :update do |page|
        page.replace_html 'invoice_list', :partial => "/invoice/invoice_list"
      end
    end
  end  
   
  def expense_list(expense_type,expense_flag,source_type,filter_condition="transacts.id!=0")
    session[:expense_sort] =  params[:sort] || session[:expense_sort] || "transacts.flag desc"
    session[:expense_page] = params[:page] || session[:expense_page] || 1
    session[:expense_page]=1 if params[:per_page]
    session[:expense_per_page] = params[:per_page] || session[:expense_per_page] || 10
		@expenses = Transact.paginate :page => params[:page], :per_page => params[:per_page] || 10, :conditions=>["transact_type in (?) and credit_amount > 0 and source in (?) and (#{filter_condition} )",expense_type,source_type], :include=>"account", :order => session[:expense_sort] #for will_paginate
    if request.xml_http_request?
      render :update do |page|
        page.replace_html 'expense_list', :partial => "/expense/expense_list"
      end
    end
  end
  
  def listing_payroll_result
    session[:payroll_page] = params[:page] || session[:payroll_page] || 1
    session[:payroll_page]=1 if params[:per_page]
    session[:payroll_per_page] = params[:per_page] || session[:payroll_per_page] || 10
    @payrolls = Payroll.find(:all,:conditions=>["flag!= 4 and flag!= 9"], :order=>"flag,end_date")
    @payroll_employees = Payroll.find(:all,:conditions=>["flag = 4"])
    if !@payroll_employees.empty?
      generate_drafted_payrolls
    end
    @payrolls = @payrolls.paginate(:page=>session[:payroll_page], :per_page=>session[:payroll_per_page], :order=>"flag desc")
    if request.xml_http_request?
      render :update do |page|
        page.replace_html "listing_result", :partial => "/employee/listing_payroll_result", :layout => false
      end
    end
  end   
  
  def generate_drafted_payrolls
    drafted_payrolls = []
          for payroll in @payroll_employees
        employee = Employee.find_by_id(payroll.employee_id)
        if employee.pay_period=="week"
          period = 52
          #@end_date = employee.start_date + 7
        elsif employee.pay_period=="bi-week"  
          period = 26
          #@end_date = employee.start_date + 14     
        elsif employee.pay_period=="month"
          period = 12
          #@end_date = employee.start_date.to_time.months_since(1).to_s(:db)
        elsif employee.pay_period=="semi-month"  
          period = 24
          #@end_date = employee.start_date + 14      
        end
         payroll_to_minus = Payroll.find(:all,:conditions=>["end_date between ? and ? and employee_id = ? and flag!=4 and transact_id = ? and flag!= 9",employee.start_date,employee.end_date,employee.id,payroll.transact_id],:order=>"end_date asc")
         drafted_count = payroll_to_minus.blank? ?  period : period - payroll_to_minus.length
         start_date = payroll_to_minus.blank? ?  employee.end_date + 1 : payroll_to_minus.last.end_date + 1
         if employee.pay_period=="week"
          end_date = start_date + 6
        elsif employee.pay_period=="bi-week" 
          end_date = start_date + 13
        elsif employee.pay_period=="month"
          if start_date.month==1 and start_date.day==29 and !start_date.to_date.leap?
              end_date = start_date.to_time.months_since(1).to_s(:db)     
          else
            end_date = start_date.to_time.months_since(1).yesterday.to_s(:db)     
          end          
        elsif employee.pay_period=="semi-month"  
          #end_date = start_date + 15
            counter_array = (payroll_to_minus.length+1).divmod(2)
            incrementable_months = counter_array.first
            incrementable_days = counter_array.last*15
            end_date = employee.start_date.to_time.advance(:months=>incrementable_months ,:days=>incrementable_days).to_s(:db)
            end_date = (end_date.to_date-1).to_s(:db)  if ( ( (employee.start_date.day==29 and employee.start_date.month==2) or ((employee.start_date+15).day==29 and (employee.start_date+15).month==2) ) and (end_date.to_date.month==3 and end_date.to_date.day==1))
        end
        ei_total = 0
        for i in 2..drafted_count
          drafted_payroll = payroll.clone
          drafted_payroll.flag=$FLAG[:UNPAID]
          drafted_payroll.start_date=start_date
          drafted_payroll.end_date=end_date
          ei_total = ei_total + drafted_payroll.employee_insurance
        unless current_company.selected_province == "QC"
          if ei_total > $PROVINCE_MAX
          drafted_payroll.employee_insurance= 0
          end
        else
          if ei_total > $QC_MAX
          drafted_payroll.employee_insurance= 0
          end
        end
           drafted_payrolls << drafted_payroll
          start_date = end_date.to_date + 1
          if employee.pay_period=="week"
            end_date = start_date + 6
          elsif employee.pay_period=="bi-week" 
            end_date = start_date + 13
          elsif employee.pay_period=="month"
              if start_date.month==1 and start_date.day==29 and !start_date.to_date.leap?
                  end_date = start_date.to_time.months_since(1).to_s(:db)     
              else
                end_date = start_date.to_time.months_since(1).yesterday.to_s(:db)     
              end          
          elsif employee.pay_period=="semi-month"  
            #end_date = start_date + 15
            counter_array = (payroll_to_minus.length+i).divmod(2)
            incrementable_months = counter_array.first
            incrementable_days = counter_array.last*15
            end_date = employee.start_date.to_time.advance(:months=>incrementable_months ,:days=>incrementable_days).to_s(:db)
            end_date = (end_date.to_date-1).to_s(:db)  if ( ( (employee.start_date.day==29 and employee.start_date.month==2) or ((employee.start_date+15).day==29 and (employee.start_date+15).month==2) ) and (end_date.to_date.month==3 and end_date.to_date.day==1))
          end
        end
    end
    drafted_payrolls =drafted_payrolls.sort{|x,y| x.end_date <=> y.end_date}  
    @payrolls=@payrolls+drafted_payrolls
  end
  
  def eliminate_space_in_first_name(model)
    eval("@first_name = @" + model +".first_name = params[:" + model + "][:first_name].strip.gsub('  ',' ')")
    return @first_name
  end  
  
  def eliminate_space_in_last_name(model)
    eval("@first_name = @" + model +".last_name = params[:" + model + "][:last_name].strip.gsub('  ',' ')")
    return @first_name
  end  

  def set_location(location)
    session[:return_back_to] = location
  end
  
  def clear_location
  	if session[:return_back_to]
	  session[:return_back_to]=nil
	  end
	end
  	
  def back_to
    if session[:return_back_to]
      redirect_to session[:return_back_to]
    else
      redirect_to ""
    end
    clear_location
  end
  
  def get_current_balance(type)
    if type=="all"
        cbSQL="SELECT id as account_id, closing_balance as bal FROM accounts"
        return Account.find_by_sql(cbSQL)
    end
  end
  
  def fcc_calculation(fcc_amount)    
    FasterCSV.foreach($FCC_CSV) do |line| #, :headers=> true,:header_converters => :symbol,:converters=> :numeric ) do |line|
    min = line[0].gsub(/[$,]+/, "").to_f unless line[0].nil?
    max = line[2].gsub(/[$,]+/, "").to_f unless line[2].nil?
    unless min.nil? or max.nil?
      if fcc_amount.to_f >= min and fcc_amount.to_f <= max
        @code = line[3]
      elsif fcc_amount.to_f >=min and line[2]=="Max"
        @code = "X"        
      end
    end
  end 
  return @code
  end
  
  def pcc_calculation(pcc_amount)    
    company = Company.find(session[:company].id)
    $PCC_CSV = RAILS_ROOT + "/public/csv/#{company.selected_province}_claim_codes.csv"
      FasterCSV.foreach($PCC_CSV) do |line| #, :headers=> true,:header_converters => :symbol,:converters=> :numeric ) do |line|
      min = line[0].gsub(/[$,]+/, "").to_f unless line[0].nil?
      max = line[2].gsub(/[$,]+/, "").to_f unless line[2].nil?
      unless min.nil? or max.nil?
        if pcc_amount.to_f >= min and pcc_amount.to_f <= max
          @pcode = line[3]
        elsif pcc_amount.to_f >=min and line[2]=="Max"
          @pcode = "X"        
        end
       end
     end 
   return @pcode  
  end
  
   
    def days_between_dates(first, last)
      count = 0
        for i in (last)..(first)
          count = count + 1
        end
      return count
    end

    def YMD(date)
      date.to_date.to_s.gsub("-", "").to_i
    end
  
  def fct_calculation(emp,fcc,pcc)
  company = Company.find(emp.company_id)
  
    if emp.pay_period=="week"
      file_to_read = RAILS_ROOT + "/public/csv/weekly.csv"
      file_for_province = RAILS_ROOT + "/public/csv/#{company.selected_province}_weekly.csv"
      file_for_cpp = RAILS_ROOT + "/public/csv/cpp_weekly.csv"
      period = 52
    elsif emp.pay_period=="bi-week"  
      file_to_read = RAILS_ROOT + "/public/csv/biweekly.csv"
      file_for_province = RAILS_ROOT + "/public/csv/#{company.selected_province}_bi-weekly.csv"
      file_for_cpp = RAILS_ROOT + "/public/csv/cpp_biweekly.csv"
      period = 26
    elsif emp.pay_period=="month"
      file_to_read = RAILS_ROOT + "/public/csv/monthly.csv"
      file_for_province = RAILS_ROOT + "/public/csv/#{company.selected_province}_monthly.csv"
      file_for_cpp = RAILS_ROOT + "/public/csv/cpp_monthly.csv"
      period = 12
    elsif emp.pay_period=="semi-month"  
      file_to_read = RAILS_ROOT + "/public/csv/semimonthly.csv"
      file_for_province = RAILS_ROOT + "/public/csv/#{company.selected_province}_semi-monthly.csv"
      file_for_cpp = RAILS_ROOT + "/public/csv/cpp_semimonthly.csv"
      period = 24
    end

    if emp.payment_type=="salary"
      @gross_pay = emp.payment_amount / period 
    elsif emp.payment_type=="wage"
      @gross_pay = emp.payment_amount * emp.hours_per_week unless emp.hours_per_week.nil?
     elsif emp.payment_type=="contract"       
      period_to_divide = days_between_dates(emp.to_date,emp.from_date) / period unless days_between_dates(emp.to_date,emp.from_date) < period
      @gross_pay = emp.payment_amount / period_to_divide unless period_to_divide.nil?
    end   
    unless company.selected_province.blank? or company.selected_province.nil?
    unless company.selected_province=="QC"
     FasterCSV.foreach(file_to_read) do |line|#, :headers=> true,:header_converters => :symbol,:converters=> :numeric ) do |line|
       
      min = line[0].to_f      
      max = line[2].to_f  
      line_number =  fcc.to_i + 3
      unless fcc == 0
         if @gross_pay.to_f >= min and @gross_pay.to_f <= max
          @ft = line[line_number].to_f           
         end
        else
          @ft=0
        end
      end
    else
      FasterCSV.foreach(file_for_province) do |line|#, :headers=> true,:header_converters => :symbol,:converters=> :numeric ) do |line|
      min = line[0].to_f      
      max = line[2].to_f  
      line_number =  fcc.to_i + 3
       unless fcc == 0
         if @gross_pay.to_f >= min and @gross_pay.to_f <= max
          @ft = line[line_number].to_f           
         end
        else
          @ft=0
        end
       end
     end
    end  
    unless company.selected_province == "QC" or company.selected_province.blank? or company.selected_province.nil?
     FasterCSV.foreach(file_for_province) do |line|#, :headers=> true,:header_converters => :symbol,:converters=> :numeric ) do |line|
      min = line[0].to_f      
      max = line[2].to_f  
      line_number =  pcc.to_i + 3
      unless pcc == 0
        if @gross_pay.to_f >= min and @gross_pay.to_f <= max
          @pt = line[line_number].to_f
        end
        else
          @pt=0
      end
    end
    else
    @pt=0
    end
    
    if emp.payment_type=="wage"
     FasterCSV.foreach(file_for_cpp) do |line|#, :headers=> true,:header_converters => :symbol,:converters=> :numeric ) do |line|
      min = line[0].to_f      
      max = line[2].to_f   
       unless @gross_pay.to_f == 0
         if @gross_pay.to_f >= min and @gross_pay.to_f <= max
          @cpp = line[3].to_f
         end
        else
          @cpp=0
      end
    end
    else    
      @cpp = ((emp.payment_amount.to_f - 3500) * 4.95/100)/period
    end
    @cpp = @cpp.nil? ? 0 : @cpp 
    @ft = @ft.nil? ? 0 : @ft
    @pt= @pt.nil? ? 0 : @pt
    if company.selected_province == "QC"
    @ei=(@gross_pay * 1.39)/100
    else
    @ei=(@gross_pay * 1.73)/100
  end
     @net = @gross_pay-(@ft+@pt+@cpp+@ei) unless @gross_pay.nil?
  end  
  
  def payroll_initialize
    @payroll_expense_EI_credit = Account.find :first,:conditions=>["alias='EI Payable'"]
    @payroll_expense_CPP_credit = Account.find :first,:conditions=>["alias='CPP Payable'"]
    @payroll_expense_Chequing_credit = Account.find :first,:conditions=>["alias='Chequing Bank Account'"]
    @payroll_expense_FIT_credit = Account.find :first,:conditions=>["alias='Income Tax Payable'"]
    @payroll_expense_wage_debit = Account.find :first,:conditions=>["alias='Wages & Salaries'"]
    @payroll_expense_ei_debit = Account.find :first,:conditions=>["alias='EI Expense'"]
    @payroll_expense_cpp_debit = Account.find :first,:conditions=>["alias='CPP Expense'"]
    @payroll_expense_penalty = Account.find :first,:conditions=>["alias='Penalties'"]
  end

def current_user_with_scope
  #User.current = current_user_without_scope unless session[:user].blank?
  Company.current = session[:company]  unless session[:company].blank?
  current_user_without_scope
end
unless method_defined?(:current_user_without_scope)
  alias_method :current_user_without_scope, :current_user
  alias_method :current_user, :current_user_with_scope
end

# Accesses the current company from the session.
=begin
    
    # Store the given company in the session.
    def current_company=(new_company)
    session[:company] = (new_company.nil? || new_company.is_a?(Symbol)) ? nil : new_company.id
    @current_company = new_company
    end



    
    def current_company_with_scope
      Company.current = current_company_without_scope unless session[:company].blank?
      current_company_without_scope
    end
    unless method_defined?(:current_company_without_scope)
      alias_method :current_company_without_scope, :current_company
      alias_method :current_company, :current_company_with_scope
    end
=end


def get_random_password( len )
chars = ("a".."z").to_a + ("A".."Z").to_a + ("0".."9").to_a
newpass = ""
1.upto(len) { |i| newpass << chars[rand(chars.size-1)] }
return newpass
end


def check_plan(feature_name)
  plan_name = current_company.plan_name
  #@plan = Plan.find_by_sql("Select feature,#{plan_name} from plans")
   case feature_name
   when "UAF"
   @result = Plan.find_by_sql("select #{plan_name} from plans where feature = 'EN'")
    if @result == "Yes"
      return true
    else
      return false 
    end  
   when "NOU"
    @result = Plan.find_by_sql("select #{plan_name} as output from plans where feature = 'NOU'")  
    @user = User.find(:all,:conditions=>["client_id = ?",session[:client].id])    
    if @user.length <= @result[0].output.to_i or @result[0].output=="Unlimited"
      return true
    else
      return false 
    end  
    when "NOC"
    @result = Plan.find_by_sql("select #{plan_name} as output from plans where feature = 'NOC'")  
    @employee = Employee.find(:all)
     if @employee.length < @result[0].output.to_i or @result[0].output == "Unlimited"
      return true
    else
      return false 
    end  
    when "SSL"
    @result = Plan.find_by_sql("select #{plan_name} from plans where feature = 'SSL'")  
    if @result == "Yes"
      return true
    else
      return false 
    end  
    when "UH"
    @result = Plan.find_by_sql("select #{plan_name} from plans where feature = 'UH'")  
    if @result == "Yes"
      return true
    else
      return false 
    end  
    when "RP"
    @result = Plan.find_by_sql("select #{plan_name} from plans where feature = 'RP'")  
    if @result == "Yes"
      return true
    else
      return false 
    end  
    when "AP"
    @result = Plan.find_by_sql("select #{plan_name} from plans where feature = 'AP'")  
    if @result == "Yes"
      return true
    else
      return false 
    end 
   end   
 end  
 
 def get_session_expire_period
   	controller_name=='account' && ['index','about','pricing','buzz','faq','auto_logout','privacy_policy','show_blog','terms_of_service'].include?(action_name)	? 0.seconds : 900.seconds
 end
 
 def admin_login
  if session[:admin].nil?
    flash[:notice] = "<font color='red'>Please Login</font>"
    redirect_to :controller=>"blogs",:action=>"login"        
  end    
 end 

  def make_email_reset_code(new_email)
    return Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{new_email}--")
  end

  
  protected

  def permission_denied
    flash[:notice] = "<font color='red'size='2'><b>You don't have privileges to access the requested page</b></font>"
    redirect_to :controller=>"account",:action => 'dashboard'
  end

  def permission_granted
    #flash[:notice] = "Welcome to the secure area"
  end

  
end
