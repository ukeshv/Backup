class BlogsController < ApplicationController
   before_filter :admin_login,:except=>[:login,:logout] 
  
  def login
    return unless request.post?
    if params[:admin_name]=="jujube" && params[:admin_password]=="jujube"
      session[:admin]="jujube_admin"
      redirect_to :controller=>"blogs",:action=>"list"
    else
      render :action=>"login"
    end  
  end
  
  def logout
    session[:admin]=nil
    redirect_to :controller=>"blogs",:action=>"login"
  end  
  
  def index
    list
    render :action => 'list'
  end

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  verify :method => :post, :only => [ :destroy, :create, :update ],
         :redirect_to => { :action => :list }

  def list
    @blog_pages, @blogs = paginate :blogs, :per_page => 10
  end

  def show
    @blog = Blog.find(params[:id])
  end

  def new
    @blog = Blog.new
    @categories = Category.find(:all)
  end

  def create
    @blog = Blog.new(params[:blog])
    @categories = Category.find(:all)    
    if @blog.save
      flash[:notice] = 'Blog was successfully created.'
      redirect_to :action => 'list'
    else
      render :action => 'new'
    end
  end

  def edit
    @blog = Blog.find(params[:id])
    @categories = Category.find(:all)    
  end

  def update
    @blog = Blog.find(params[:id])
    if @blog.update_attributes(params[:blog])
      flash[:notice] = 'Blog was successfully updated.'
      redirect_to :action => 'show', :id => @blog
    else
      render :action => 'edit'
    end
  end

  def destroy
    Blog.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
  
  def add_new_category
    render :update do |page|
      page.call "RedBox.showInline",'new_category' 
    end  
  end
  
  def create_category
    @category = Category.create!(params[:category])
    @categories = Category.find(:all)
     render :update do |page|
      page.call "RedBox.close"
      page.replace_html "category_list", :partial=> "/blogs/category_list",  :locals => { :categories => @categories }
      page.call "select_option",'blog_category_id',@category.name
     end
   end     
   
   def revert_version 
     @blog = Blog.find(params[:id]) 
     @blog.revert_to! params[:version] 
     redirect_to :action => 'edit', :id => @blog
   end 
 end
