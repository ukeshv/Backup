class ContactController < ApplicationController
  layout "clear"
  before_filter :login_required
  before_filter :setting_company_details, :only=>[:list,:new]
  
  access_control [:list] =>  "(#{$ACCESS["ALL"]}  | #{$ACCESS["VIEW_ONLY"]} | #{$ACCESS["INVOICE_AND_EXPENSE"]})",[:new,:edit,:update]=>"(#{$ACCESS["ALL"]} | #{$ACCESS["INVOICE_AND_EXPENSE"]})"

 
  def new
    set_location('/contact/list')
    @contact = Contact.new(params[:contact])
    return unless request.post?
    @contact.first_name=eliminate_space_in_first_name("contact") 
    @contact.last_name=eliminate_space_in_last_name("contact") 
    @contact.company_name=params[:contact][:company_name].strip.squeeze(' ')
    contact_type    
    if @contact.save
      if params[:save_and_new] == "save_and_new"
      redirect_to :controller=>"contact",:action=>"new"
      else
      redirect_to :controller=>"contact",:action=>"list"
      end
      flash[:notice] = "<span>#{@contact.company_name} successfully added </span>"
    else
      flash[:error] = "<span>Please fix the following errors.</span>"     
       render :action => 'new' 
    end
    rescue ActiveRecord::RecordInvalid
    render :action => 'new'
  end
  
  def contact_type
    if params[:contact_type][:client] == "1" and params[:contact_type][:vendor] != "1"
    @contact.contact_type = "client"
    elsif params[:contact_type][:vendor] == "1" and params[:contact_type][:client] != "1"
    @contact.contact_type = "vendor"
    elsif params[:contact_type][:vendor] == "1" and params[:contact_type][:client] == "1"
    @contact.contact_type = "cv"      
    else
    @contact.contact_type ="other"   
    end  
  end  
  
  def list
    #session[:contact_sort] = nil
    session[:contact_page] = nil
    session[:contact_per_page] = nil
    list1
  end

  def list1
    if params[:sort]
      session[:contact_sort] = params[:sort]
    elsif session[:contact_sort]
      session[:contact_sort] = session[:contact_sort]
    else
      session[:contact_sort] = "company_name asc"
    end   

    if params[:page]
      session[:contact_page]=params[:page]
    elsif session[:contact_page]
      session[:contact_page]=session[:contact_page]
    else
      session[:contact_page]=1
    end

    if params[:per_page]
      session[:contact_page]=1
      session[:contact_per_page] = params[:per_page]
    else
      session[:contact_per_page] = 10
    end

    @contact_start_record=(session[:contact_page].to_i*session[:contact_per_page].to_i)-session[:contact_per_page].to_i
    @contact_end_record= @contact_start_record +  session[:contact_per_page].to_i  - 1
    @transaction_details=Transact.find_by_sql("
    SELECT A.id as contact_id, A.account_id, A.company_name as name, Upper(substring(A.contact_type,1,2)) As legend, B.revenue, B.spent, B.owing, B.owed FROM contacts A 
    LEFT JOIN(
		select RST.account_id as account_id, sum(RST.revenue) as revenue, sum(RST.spent) as spent, sum(RST.owing)as owing, sum(RST.owed) as owed from (
		(SELECT account_id, sum( debit_amount ) AS revenue, '' AS spent, sum( balance_amount *-1) AS owing, '' AS owed
    FROM `transacts`
    WHERE expense_number = '' AND invoice_number != '' AND debit_amount >0 AND credit_amount =0 AND flag!=#{$FLAG[:DRAFT]} AND company_id=#{current_company.id}
    GROUP BY account_id )
    UNION
    (SELECT account_id, '' AS revenue, sum( credit_amount ) AS spent, '' AS owing, sum( balance_amount ) AS owed
    FROM `transacts`
    WHERE expense_number != '' AND credit_amount >0 AND debit_amount =0 AND flag!=#{$FLAG[:DRAFT]} AND company_id=#{current_company.id}
    GROUP BY account_id)) RST group by RST.account_id ) B 
    ON A.account_id=B.account_id WHERE A.company_id=#{current_company.id} order by #{session[:contact_sort]} 
    ")

    @contact_no_of_record=@transaction_details.length
    @contact_no_of_pages= (@transaction_details.length.to_f/session[:contact_per_page].to_i).ceil

    if request.xml_http_request?
       render :update do |page|
        page.replace_html 'listing_result', :partial => "/contact/listing_result"
      end
    end
  end 

  def edit
    @contact = Contact.find(params[:id]) #, :conditions=>["user_id = ?",current_user.id])
    rescue ActiveRecord::RecordNotFound
    flash[:error] = "<span>Not able to find that Client</span>"
    redirect_to :controller=>"contact",:action=>"list"
  end  

  def update
  @contact = Contact.find(params[:id])#, :conditions=>["user_id = ?",current_user.id])
  contact_type 
    if @contact.update_attributes(params[:contact])
    @contact.first_name=eliminate_space_in_first_name("contact") 
    @contact.last_name=eliminate_space_in_last_name("contact") 
    @contact.update
      if @contact.contact_type == "client" or @contact.contact_type == "cv"
      group_id = Account.find(:first,:conditions=>["name = 'Accounts Receivable'"])# and user_id = ? ",current_user.id])
      else  
      group_id = Account.find(:first,:conditions=>["name = 'Accounts Payable'"]) #and user_id = ?" ,current_user.id])
      end            
      #@account = Account.find(:first,:conditions=>["id = ? and user_id =?",@contact.account_id,current_user.id])
      @account = Account.find(@contact.account_id)
      @account.update_attributes(:name=>@contact.company_name,:group_id=>group_id.id)
      redirect_to :controller=>"contact",:action=>"list"
      flash[:notice] = "<span>#{@contact.company_name} Successfully Updated</span>"
    else
      flash[:error] = "<span>Please fix the following errors.</span>"
      render :action=>"edit"  
    end 
    rescue ActiveRecord::RecordNotFound
      flash[:error] = "<span>Not able to update that Client</span>"
      redirect_to :controller=>"contact",:action=>"list"
    end  
end