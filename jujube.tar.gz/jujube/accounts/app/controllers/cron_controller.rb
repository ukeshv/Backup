class CronController < ApplicationController
  layout "clear"
  def index
    
  end
  def run_cron 
    @recurring_transacts=RecurringTransact.find(:all, :conditions=>['recurring_date=?',params[:recurring_date].to_date])
    #Payroll.update_payroll_transacts(params[:recurring_date].to_date,"cron",1)
    for recurring_transact in @recurring_transacts
      if recurring_transact.recurring_type == $EXPENSE_RECURRING
        Company.current=Company.find(recurring_transact.company_id)
        source = recurring_transacts.recurring_type.to_s+' '+recurring_transacts.recurring_inv_exp_number.to_s
        Payroll.update_payroll_transacts(params[:recurring_date].to_date,"cron",Transact.count(:conditions=>"source='#{source}'")+1)
        recurring_transact.create_expense_entry
      end
      if recurring_transact.recurring_type == $INVOICE_RECURRING
        recurring_transact.create_invoice_entry
      end      
    end
    flash[:notice] = "Cron on :#{params[:recurring_date]} Successfully Executed. </span>"
    redirect_to '/cron/index'
  end
  
  def run_payroll_cron   # this method may not work as argument supplied as 1 should be changes as in above method
     Payroll.update_payroll_transacts(Date.today,"cron")
     render :text=>""
  end  
end
