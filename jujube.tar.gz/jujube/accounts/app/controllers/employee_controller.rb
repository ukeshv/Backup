class EmployeeController < ApplicationController
    layout "clear"    
    
    before_filter :login_required
    before_filter :setting_company_details, :only=>[:list,:new,:payroll,:remittance]

    access_control [:list,:payroll] =>  "(#{$ACCESS["ALL"]}  | #{$ACCESS["VIEW_ONLY"]})",
                         [:new,:create,:edit,:update,:process_payroll,:update_payroll] =>  "(#{$ACCESS["ALL"]})"
   
  def common_initialize
    @payroll_expense_wage_debit,@payroll_expense_ei_debit,@payroll_expense_cpp_debit,@payroll_expense_EI_credit,@payroll_expense_CPP_credit,@payroll_expense_FIT_credit,@payroll_pay = Jujube.employee_common_initialize
  end   
    
  def new
    #if check_plan("NOC")  
    common_initialize
    set_location('/employee/list')
    @emp_id = Jujube.get_employee_number
    @employee = Employee.new(params[:employee])
    @employee.provincial_claim = Province.find_by_code(@current_company.selected_province).provincial_claim
    @employee.provincial_claim_code = pcc_calculation(@employee.provincial_claim)
    @employee.federal_claim = 9600
    @employee.federal_claim_code = fcc_calculation(9600)
    return unless request.post?
    params[:employee][:end_date] = params[:employee][:start_date]
    @employee.employee_id = @emp_id
    @employee.first_name=eliminate_space_in_first_name("employee") 
    @employee.last_name=eliminate_space_in_last_name("employee") 
    @employee.end_date = @employee.start_date
    if @employee.save 
      unless @employee.federal_claim.nil? or @employee.payment_amount.nil? or @employee.provincial_claim.nil?
        @expense_number = Jujube.get_expense_number
        @payroll_expense_number = Jujube.get_payroll_expense_number  
        create    
      end
      redirect_to :controller=>"employee",:action=>"list"
      flash[:notice] = "<span>#{@employee.first_name} successfully added </span>"
    end
    #else
      #flash[:notice] = "<b>Please upgrade.</b> <br /><span>To add more employees you have to upgrade your plan.</span>"     
      #redirect_to :controller=>"settings",:action => "my_plan"
    #end
  end     

  def create
      fct_calculation(@employee,@employee.federal_claim_code,@employee.provincial_claim_code) unless @employee.federal_claim_code.nil? and @employee.provincial_claim_code.nil?
      @start_date=@employee.start_date
      @end_date=@employee.end_date  # which would be as same as start_date for base record
      
      @employee.update_attributes(:end_date=>@end_date)

      if @employee.pay_period=="week"
        @end_date = @start_date + 7
        period_to_calculate = 7
        period_for_year= 52      
      elsif @employee.pay_period=="bi-week" 
        @end_date = @start_date + 14
        period_to_calculate = 14
        period_for_year = 26
      elsif @employee.pay_period=="month"
        @end_date = @start_date.to_time.advance(:months=>1).advance(:days=>-1).to_s(:db)  #months_since(1).yesterday.to_s(:db) 
        period_to_calculate = 30
        period_for_year = 12
      elsif @employee.pay_period=="semi-month"  
        @end_date = @start_date + 15
        period_to_calculate = 15
        period_for_year = 24
      end    

       employee_entry
       if @employee.start_date <= Date.today
           inbetween_days = days_between_dates(Date.today.to_date,@employee.start_date.to_date)
           due_payroll_count = (inbetween_days.to_i / period_to_calculate).ceil 
           final_due_payroll_count = due_payroll_count == 0  ?  1 : due_payroll_count
           @due_payroll_count = final_due_payroll_count >  period_for_year  ?  period_for_year : final_due_payroll_count
           for due in 0..@due_payroll_count
               Payroll.update_payroll_transacts(@end_date,"",due) #,due_payroll_count
               employee = Employee.find(@employee.id)  # reloading
               @end_date = employee.end_date
           end    
       end    

      if @employee.end_date == Date.today
        Payroll.update_payroll_transacts(Date.today,"")
      end  
  end  


  def employee_entry
      @transacts=Transact.create!(:transact_type=>$PAYROLL_EXPENSE, :invoice_date=>@start_date, :account_id=>@employee.account_id, :credit_amount=>@net, :debit_amount=>0, :balance_amount=>@gross_pay*(-1), :invoice_number=>'', :expense_number=>@payroll_expense_number, :flag=>$FLAG[:PAYROLL],:source=>$PAYROLL_BASE)
      Transact.create!(:transact_type=>$PAYROLL_EXPENSE, :invoice_date=>@start_date, :account_id=>@payroll_pay.id, :credit_amount=>0, :debit_amount=>@net, :balance_amount=>@gross_pay, :invoice_number=>'', :expense_number=>@payroll_expense_number, :flag=>$FLAG[:PAYROLL],:source=>$PAYROLL_BASE)
      @payroll = Payroll.create!(:employee_id=>@employee.id,:transact_id=>@transacts.id,:start_date=>@start_date,:end_date=>@end_date,:employee_insurance=>@ei,:canada_pension_plan=>@cpp,:federal_tax=>@ft,:provincial_tax=>@pt,:gross_amount=>@gross_pay,:net_pay=>@net,:flag=>$FLAG[:PAYROLL],:expense_number=>@payroll_expense_number)
    end  
    
  def list
    session[:employee_sort] = nil
    session[:employee_page] = nil
    session[:employee_per_page] = nil
    employee_list
  end

  def employee_list
    if params[:sort]
      session[:employee_sort] = params[:sort]
    elsif session[:employee_sort]
      session[:employee_sort] = session[:employee_sort]
    else
      session[:employee_sort] = "id desc"
    end   

    if params[:page]
      session[:employee_page]=params[:page]
    elsif session[:employee_page]
      session[:employee_page]=session[:employee_page]
    else
      session[:employee_page]=1
    end
    if params[:per_page]
      session[:employee_page]=1
      session[:employee_per_page] = params[:per_page]
    else
      session[:employee_per_page] = 10
    end
    @emp_start_record=(session[:employee_page].to_i*session[:employee_per_page].to_i)-session[:employee_per_page].to_i
    @emp_end_record= @emp_start_record +  session[:employee_per_page].to_i  - 1
    @employees = Employee.paginate(:all,:order => session[:employee_sort], :page=>session[:employee_page], :per_page=>session[:employee_per_page])
    #@emp_no_of_pages= (@employees.length.to_f/session[:employee_per_page].to_i).ceil
    @emp_no_of_record=@employees.length
      if request.xml_http_request?
        render :update do |page|
          page.replace_html 'listing_result', :partial => "/employee/listing_result"
        end
      end
  end 

  def edit
    @employee = Employee.find(params[:id])
    @payroll = Payroll.find(:first,:conditions=>["employee_id = ? and flag=4",@employee.id])
    @recent_paycheques = Payroll.find(:all,:conditions=>["employee_id = ? and flag = 0",@employee.id],:order=>"end_date desc")
    #@transacts = Transact.find(:all,:conditions=>["transact_type =? and balance_amount=0",$PAYROLL_EXPENSE],:limit=>3,:order=>"invoice_date desc")
    rescue ActiveRecord::RecordNotFound
    redirect_to :controller=>"employee",:action=>"list"
  end

  def update
    common_initialize
    @employee = Employee.find(params[:id])
    if params[:delete]
      @employee.deleted_by=current_user.id    
      @employee.update
      redirect_to :controller=>"employee",:action=>"list"
      flash[:notice] = "<span>#{@employee.first_name} Successfully Deleted</span>"
     else
     if @employee.update_attributes(params[:employee])
        @employee.first_name=eliminate_space_in_first_name("employee") 
        @employee.last_name=eliminate_space_in_last_name("employee")  
        @employee.update
        unless @employee.federal_claim.nil? or @employee.payment_amount.nil?    
          @expense_number = Jujube.get_expense_number
          @payroll_expense_number = Jujube.get_payroll_expense_number        
          @revert_calculation_for_payrolls = Payroll.find(:all, :conditions=>["employee_id = ? and flag = ? and flag <> ?",@employee.id,$FLAG[:UNPAID], $FLAG[:PAYROLL] ])
          revert_on_update_delete_employee

          @payrolls = Payroll.destroy_all(["employee_id = ? and flag in (?)",@employee.id,[$FLAG[:PAYROLL],$FLAG[:UNPAID]] ])
          expense_numbers = @payrolls.collect{|x| x.expense_number }.uniq
          @transacts= Transact.destroy_all(["transact_type = ? and flag in (?) and expense_number in (?)",$PAYROLL_EXPENSE,[$FLAG[:PAYROLL],$FLAG[:UNPAID]],expense_numbers])
          #@expense_details = ExpenseDetail.destroy_all(["transact_id in (?)",@transacts.collect{|x| x.id}])   # i think this is not required as nothing is stored in this table related to payroll
          create
        end
        redirect_to :controller=>"employee",:action=>"list"
        flash[:notice] = "<span>#{@employee.first_name} Successfully Updated</span>"
      else
        flash[:error] = "<span>Please fix the following errors.</span>"
        render :action=>"edit" 
      end 
      end 
    end 
    
    
    def revert_on_update_delete_employee
      @payroll_expense_wage_debit,@payroll_expense_ei_debit,@payroll_expense_cpp_debit,@payroll_expense_EI_credit,@payroll_expense_CPP_credit,@payroll_expense_FIT_credit,@payroll_pay = Jujube.employee_common_initialize

      total_employee_insurance = @revert_calculation_for_payrolls.collect{|x| x.employee_insurance}.sum
      total_canada_pension_plan = @revert_calculation_for_payrolls.collect{|x| x.canada_pension_plan}.sum
      total_federal_tax = @revert_calculation_for_payrolls.collect{|x| x.federal_tax}.sum
      total_provincial_tax = @revert_calculation_for_payrolls.collect{|x| x.provincial_tax}.sum

      total_gross_amount = @revert_calculation_for_payrolls.collect{|x| x.gross_amount}.sum
      total_employee_insurance = @revert_calculation_for_payrolls.collect{|x| x.employee_insurance}.sum
      total_canada_pension_plan = @revert_calculation_for_payrolls.collect{|x| x.canada_pension_plan}.sum
      total_net_pay = @revert_calculation_for_payrolls.collect{|x| x.net_pay}.sum

      @payroll_expense_EI_credit.update_attributes(:closing_balance=> @payroll_expense_EI_credit.closing_balance - ( total_employee_insurance + (total_employee_insurance * 1.4) ) )
      @payroll_expense_CPP_credit.update_attributes(:closing_balance=> @payroll_expense_CPP_credit.closing_balance - ( total_canada_pension_plan + total_canada_pension_plan ) )
      @payroll_expense_FIT_credit.update_attributes(:closing_balance=> @payroll_expense_FIT_credit.closing_balance - ( total_federal_tax + total_provincial_tax ) )

      @payroll_expense_wage_debit.update_attributes(:closing_balance=> @payroll_expense_wage_debit.closing_balance - total_gross_amount) #
      @payroll_expense_ei_debit.update_attributes(:closing_balance=> @payroll_expense_ei_debit.closing_balance - (total_employee_insurance * 1.4)) #
      @payroll_expense_cpp_debit.update_attributes(:closing_balance=> @payroll_expense_cpp_debit.closing_balance - total_canada_pension_plan) #
      @payroll_pay.update_attributes(:closing_balance=> @payroll_pay.closing_balance - total_net_pay) #
    end
    
		def delete_employee
		common_initialize
    @employee = Employee.find(params[:id])
		@employee.deleted_by=current_user.id    
		@employee.update
		@revert_calculation_for_payrolls = Payroll.find(:all, :conditions=>["employee_id = ? and flag = ? and flag <> ?",@employee.id,$FLAG[:UNPAID], $FLAG[:PAYROLL] ])
    revert_on_update_delete_employee
		@payrolls = Payroll.destroy_all(["employee_id = ? and flag in (?)",@employee.id,[$FLAG[:PAYROLL],$FLAG[:UNPAID]] ])
		expense_numbers = @revert_calculation_for_payrolls.collect{|x| x.expense_number }.uniq
		@transacts= Transact.destroy_all(["transact_type = ? and flag in (?) and expense_number in (?)",$PAYROLL_EXPENSE,[$FLAG[:PAYROLL],$FLAG[:UNPAID]],expense_numbers])
    #@expense_details = ExpenseDetail.destroy_all(["transact_id in (?)",@transacts.collect{|x| x.id}])   # i think this is not required as nothing is stored in this table related to payroll
    flash[:notice] = "<span>#{@employee.first_name} Successfully Deleted</span>"
    redirect_to :controller=>"employee",:action=>"list"
	 end
	 
  def payroll
    set_location('/employee/payroll')
    session[:payroll_sort] = nil
    session[:payroll_page] = nil
    session[:payroll_per_page] = nil
    all_payroll_list
  end    
  
  def all_payroll_list
    listing_payroll_result
  end  

  def process_payroll
    @account_names=['Cash on Hand','Savings Bank Account','Chequing Bank Account','Petty Cash','Credit Card Payable']
    @source_accounts = Account.find(:all, :conditions=>["alias in (?)",@account_names])
    @payroll =Payroll.find(params[:id])
    @employee = Employee.find_by_id(@payroll.employee_id)
    if params[:update_element]
    render :update do |page|
      page.replace_html "update_"+params[:update_element].to_s, :partial=>'process_payroll'
    end 
   end      
 end  
 
  def find_provincial_code
  pcc_calculation(params[:value]) unless params[:value].nil?
  provincial_claim_code = @pcode
    render :update do |page|
      if params[:value].nil?
        page.call "$('employee_provincial_claim_code').value = ",0
        page.replace_html :pcc,0
      else
        page.call "$('employee_provincial_claim_code').value = ",provincial_claim_code
        page.replace_html :pcc,provincial_claim_code
      end  
    end  
  end
  
  def update_payroll
    @employee = Employee.new
    @employee.update_payroll(params)
    flash[:notice] = "<span>Payroll successfully Paid </span>"
    redirect_to :controller=>"employee",:action=>"payroll"       
  end    


  def find_federal_code
    fcc_calculation(params[:value]) unless params[:value].nil?
    federal_claim_code = @code
    render :update do |page|
      if params[:value].nil?
        page.call "$('employee_federal_claim_code').value = ",0
        page.replace_html :fcc,0
      else
        page.call "$('employee_federal_claim_code').value = ",federal_claim_code
        page.replace_html :fcc,federal_claim_code
      end  
    end  
  end
 end
