class ExpenseController < ApplicationController
  before_filter :login_required
  before_filter :setting_company_details, :only=>[:list,:new,:new_cheque,:payroll,:remittance, :remittances]
  
  access_control [:list] =>  "(#{$ACCESS["INVOICE_AND_EXPENSE"]} | #{$ACCESS["ALL"]}  | #{$ACCESS["VIEW_ONLY"]})",
                       [:new,:edit,:update,:details] =>  "(#{$ACCESS["INVOICE_AND_EXPENSE"]} | #{$ACCESS["ALL"]})"
  layout "clear"
  
  def new
    @expense_number = Jujube.get_expense_number
    new_expense
  end 
  
	def new_cheque
    @cheque_number = Jujube.get_cheque_number
    new_expense
  end 
  
  def create_cheque
   @expense= Expense.new
    if @expense.save_cheque(params,current_user.id,current_company.id)
      flash[:notice] = "<span>Cheque Successfully Added. </span>"
      redirect_to @expense.next_action
    else
      flash[:error] = "<span>Please try again later, there was a problem creating your cheque</span>"
      redirect_to :action=>'list'
    end
  end
  
  def new_recurring_expense
    @expense_number = Jujube.get_recurring_expense_number
    new_expense
    render :template=>'/expense/new'
  end
  
  def new_expense
    #set_location('/expense/list')
    common_initialize
    @ind = -1
    @contacts = Contact.find(:all,:conditions=>["contact_type in ('cv','vendor')"])
    @accounts_to_insert = Account.find(:all,:conditions=>["number is null and source_account='contact' and id in (?)",@contacts.collect{|x| x.account_id}]) unless @contacts.nil?
    @contact_list = @accounts_to_insert
    @groups_id = Group.find(5).children.collect{|x| x.id}
    #@accounts = Account.find(:all, :conditions=>["group_id in (?) and number IS NOT NULL or alias ='Expense Payable'", @groups_id]) 
    @accounts = Account.find(:all, :conditions=>["group_id in (?) and number IS NOT NULL", @groups_id]) 
    @account_names=['Cash on Hand','Savings Bank Account','Chequing Bank Account','Petty Cash','Credit Card Payable']
    @source_accounts = Account.find(:all, :conditions=>["alias in (?)",@account_names ])
		@cheque_number=Jujube.get_cheque_number
    session[:new_contact_action]="new"  
  end
  
  def create
   @expense= Expense.new
    if @expense.save(params,current_user.id,current_company.id)
      flash[:notice] = "<span> Expense Number:#{params[:id]} Successfully Added. </span>"
      redirect_to @expense.next_action
    else
      flash[:error] = "<span> Please try again later.</span>"
      redirect_to :action=>'list'
    end
  end

  def edit
    @expense_flag = $FLAG[:UNPAID]
    @expense_flag_array = [$FLAG[:UNPAID],$FLAG[:DRAFT]]
    @transact_type = [$EXPENSE,$PAYROLL_EXPENSE]
    edit_expense
    @want_to_edit_series=true if params.has_key?(:series) and @transact.source.include?('EXPENSE_RECURRING')
    @series_edit_note_message="Note: Changes You do will reflect throughout this recurring expence series" if @want_to_edit_series
  end
  
  def edit_recurring_expense
    @expense_flag = $FLAG[:RECURRING]
    @expense_flag_array = $FLAG[:RECURRING]
    @transact_type = [$EXPENSE_RECURRING]
    edit_expense
    session[:recurred_cron_exp_number]=@expense_number
    recurred_expense_list
    render :template=>'/expense/edit'
  end
    
  def edit_expense
    common_initialize
    @expense_number=params[:id]
    @transact = Transact.find(:first,:conditions=>["expense_number = ? and transact_type in (?) and debit_amount=0 and flag in (?)" ,@expense_number,@transact_type,@expense_flag_array])
    @transact_debit_all_records = Transact.find(:all,:conditions=>["expense_number = ? and transact_type in (?) and credit_amount=0 and flag in (?)" ,@expense_number,@transact_type,@expense_flag_array])
    @recurring_transact=RecurringTransact.find(:first, :conditions=>['recurring_inv_exp_number = ? and recurring_type=?',@transact.expense_number,@transact_type]) if @expense_flag == $FLAG[:RECURRING]
    @groups_id = Group.find(5).children.collect{|x| x.id}
    #@accounts = Account.find(:all, :conditions=>["group_id in (?) and number IS NOT NULL or alias ='Expense Payable'", @groups_id]) 
    @accounts = Account.find(:all, :conditions=>["group_id in (?) and number IS NOT NULL", @groups_id]) 
    @account_names=['Cash on Hand','Savings Bank Account','Chequing Bank Account','Petty Cash','Credit Card Payable']
		@cheque_number=Jujube.get_cheque_number
    @source_accounts = Account.find(:all, :conditions=>["alias in (?)",@account_names])
    @address = Contact.find_by_account_id(@transact.account_id) unless @transact.nil?
    @contact_list=@acc_pay_list
    get_expense_detail_amount
    @entry_logs=EntryStatusLog.find(:all,:conditions=>["entry_number = ? and entry_type = ?",@expense_number,$ENTRY[:EXPENSE]]) 
    session[:new_contact_action]="edit"
  end
  
  def edit_cheque
    common_initialize
    @expense_number=params[:id]
    @transact = Transact.find(:first,:conditions=>["expense_number = ? and transact_type = ? and debit_amount=0 and flag = (?)" ,@expense_number,$CHEQUE,$FLAG[:DRAFT]])
    @transact_debit_record = Transact.find(:first,:conditions=>["expense_number = ? and transact_type = ? and credit_amount=0 and flag in (?)" ,@expense_number,$CHEQUE,$FLAG[:DRAFT]])
    @groups_id = Group.find(5).children.collect{|x| x.id}
    #@accounts = Account.find(:all, :conditions=>["group_id in (?) and number IS NOT NULL or alias ='Expense Payable'", @groups_id]) 
    @accounts = Account.find(:all, :conditions=>["group_id in (?) and number IS NOT NULL", @groups_id]) 
    @address = Contact.find_by_account_id(@transact.account_id) unless @transact.nil?
    @contact_list=@acc_pay_list
    session[:new_contact_action]="edit"
  end
  
    def cheque_details
    common_initialize
    @expense_number=params[:id]
    @cheque_number=params[:id]
    @transact = Transact.find(:first,:conditions=>["expense_number = ? and transact_type = ? and debit_amount=0 and flag = (?)" ,@expense_number,$CHEQUE,$FLAG[:PAID]])
    @transact_debit_record = Transact.find(:first,:conditions=>["expense_number = ? and transact_type = ? and credit_amount=0 and flag in (?)" ,@expense_number,$CHEQUE,$FLAG[:PAID]])
    @groups_id = Group.find(5).children.collect{|x| x.id}
    #@accounts = Account.find(:all, :conditions=>["group_id in (?) and number IS NOT NULL or alias ='Expense Payable'", @groups_id]) 
    @accounts = Account.find(:all, :conditions=>["group_id in (?) and number IS NOT NULL", @groups_id]) 
    @address = Contact.find_by_account_id(@transact.account_id) unless @transact.nil?
    @contact_list=@acc_pay_list
    session[:new_contact_action]="edit"
  end


  def update
    return unless request.post?
    @expense=Expense.new
    if params[:paid] or params[:paid]==1
        @expense.pay_expense(params,current_user.id,current_company.id)
        flash[:notice] = "<span> Expense Number:#{params[:id]} Successfully Paid. </span>"
        redirect_to :action=>'list' 
    else
      if params[:want_to_process_recurring]=='yes'
           valid_to_change_in_series = Transact.find(:all, :conditions=>['source = ? and flag = ?',params[:source_type],$FLAG[:UNPAID]] ).collect{|x| x.expense_number}.uniq
           valid_to_change_in_series.each do |x|
              params[:id] = x
             @expense.update_expense(params,current_user.id,current_company.id)
           end
           flash[:notice] = "<span> Expense Number:#{valid_to_change_in_series.join(', ')} Successfully Updated. </span>"
           redirect_to @expense.next_action
      else 
          if @expense.update_expense(params,current_user.id,current_company.id)
              flash[:notice] = "<span> Expense Number:#{params[:id]} Successfully Updated. </span>"
              redirect_to @expense.next_action
         end
      end
    end
  end
  
    def update_cheque
    return unless request.post?
    @expense=Expense.new
        if @expense.update_cheque(params,current_user.id,current_company.id)
        flash[:notice] = "<span> Cheque Number:#{params[:id]} Successfully Updated. </span>"
        redirect_to @expense.next_action
        end
  end
  

  def get_expense_detail_amount
    @expense_details = ExpenseDetail.find(:all,:conditions=>["expense_number = ? and transact_id in (?)",@expense_number,@transact_debit_all_records.collect{|x|x.id}], :order=>:id)
    @total_amount=@expense_details.inject(0) { |sum, x| sum += (x.price.to_f * x.quantity.to_i)}
    @total_tax=@expense_details.inject(0) { |sum, x| sum += x.tax.to_f }
    @total = @total_amount+@total_tax    
  end
    
  def add_new_expense_fields
    @ind = params[:id]
    @groups_id = Group.find(5).children.collect{|x| x.id}
    #@accounts = Account.find(:all, :conditions=>["group_id in (?) and number IS NOT NULL or alias ='Expense Payable'", @groups_id])
    @accounts = Account.find(:all, :conditions=>["group_id in (?) and number IS NOT NULL", @groups_id])
    render :update do |page|
      page.insert_html :bottom, "add_field_body", :partial =>"add_field", :locals=>{:expense_detail=>nil,:ind=>@ind, :accounts=>@accounts}
      page.replace_html "display", :partial =>"add_link", :locals=>{:ind=>@ind}
    end
  end
  
  def find_sum    
    @sum = params[:sum].to_f
    @sum_tax = params[:sum_tax].to_f
    @total = @sum + @sum_tax
    render :update do |page|
      page.replace_html :total_amount, number_to_currency(@sum,{:unit => "$", :separator => ".", :delimiter => ","})
      page.replace_html :total_tax, number_to_currency(@sum_tax,{:unit => "$", :separator => ".", :delimiter => ","})
      page.replace_html :total, number_to_currency(@total,{:unit => "$", :separator => ".", :delimiter => ","})
    end
  end
  
  def find_address     
    get_contact_address
  end 

  def list
    set_location('/expense/list')
   	if request.post? 
  	check_filter_conditions_for_expense
  	all_expense_list(@filter_condition)
  	else
    session[:expense_sort] = nil
    session[:expense_page] = nil
    session[:expense_per_page] = nil
    session[:expense_paid_sort] = nil
    session[:expense_paid_page] = nil
    session[:expense_paid_per_page] = nil
    session[:expense_sorting_condtion]=nil 
    session[:payroll_sort] = nil
    session[:payroll_page] = nil
    session[:payroll_per_page] = nil
    all_expense_list("1=1")
    paid_list
    #all_payroll_list 
    end
  end   

  def revert_payment
    #if  Journal.find(:all, :conditions=>"journal_type='#{$EXPENSE_PAID}' and inv_exp_number='#{params[:id]}'").length > 2
    #    flash[:notice] = "<b>Payment not Cancelled</b>: As it was an direct payment "
        #######waiting for spec##########
    #else    
      Expense.revert_payment(params[:id],current_user.id,current_company.id)
      flash[:notice] = "Payment Successfully Reverted for expense No ##{params[:id]}"
    #end  
    redirect_to :action=>'list'
  end

    def check_filter_conditions_for_expense
  	#@net_days = session[:company] && session[:company].net_days &&  session[:company].net_days > 0 ? session[:company].net_days : 0
@filter_condition=[]
	if params[:draft]
		@filter_condition<<"( flag=#{$FLAG[:DRAFT]} )"
	end
	if params[:open]
		@filter_condition<<"(flag=#{$FLAG[:UNPAID]} and (CURDATE()-invoice_date)<=due_limit)"
	end
	if params[:overdue]
		@filter_condition<<"(flag=#{$FLAG[:UNPAID]} and (CURDATE()-invoice_date)>due_limit) "
	end
	if params[:paid]
		@filter_condition<<"(flag=#{$FLAG[:PAID]} )"
	end
  if params[:cheque]
    @filter_condition<<"(payment_type ='#{$PAYMENT_TYPE['CHEQUE']}')"
  end  
   if params[:cash]
    @filter_condition<<"(payment_type ='#{$PAYMENT_TYPE['CASH']}')"
  end  
  if params[:credit_card]
    @filter_condition<<"(payment_type ='#{$PAYMENT_TYPE['CREDIT_CARD']}')"
  end  
	if params[:all]
		@filter_condition<<"1=1"
	end
	@filter_condition=@filter_condition.join(" or ")
	@filter_condition="1=1" if @filter_condition.empty?
	session[:invoice_sorting_condtion]=@filter_condition
end


  def filter
  	render :template=>'/expense/list'
 	end

  
  def recurring_list
    set_location('/expense/recurring_list')
    all_recurring_expense_list
    render :template=>'/expense/list'
    end
    
  def all_recurring_expense_list
    expense_list([$EXPENSE_RECURRING],[$FLAG[:RECURRING]],[$EXPENSE_CRON])
  end
    
  def sorting_expense_list
	  #check_filter_conditions
	  @filter_condition= session[:expense_sorting_condtion] ? session[:expense_sorting_condtion] : "1=1"
  	all_expense_list(@filter_condition)
 	end
  
  def all_expense_list(filter_condition)
		@source_type=[$EXPENSE,$PAYROLL_EXPENSE,$CHEQUE]
  	@recurring_expense_limit=Jujube.get_recurring_expense_number
  	(1..@recurring_expense_limit).each do |expense_number|  @source_type<<"#{$EXPENSE_RECURRING} #{expense_number}" end
    expense_list([$EXPENSE,$PAYROLL_EXPENSE,$CHEQUE],[$FLAG[:PAID],$FLAG[:UNPAID],$FLAG[:DRAFT],$FLAG[:DELETED]],@source_type,filter_condition) ###### $FLAG[:DELETED]
  end
  
  def recurred_expense_list
		expense_list($EXPENSE, [$FLAG[:UNPAID]], ["#{$EXPENSE_RECURRING} #{session[:recurred_cron_exp_number]}"])
	end
	
  #def all_payroll_list
    #listing_payroll_result
  #end  
  def paid_list
    if params[:sort]
      session[:expense_paid_sort] = params[:sort]
    elsif session[:expense_paid_sort]
      session[:expense_paid_sort] = session[:expense_paid_sort]
    else
      session[:expense_paid_sort] = "id desc"
    end
    if params[:page]
      session[:expense_paid_page]=params[:page]
    elsif session[:expense_paid_page]
      session[:expense_paid_page]=session[:expense_paid_page]
    else
      session[:expense_paid_page]=1
    end
    if params[:per_page]
      session[:expense_paid_page]=1
      session[:expense_paid_per_page] = params[:per_page]
    else
      session[:expense_paid_per_page] = 10
    end
    @paid_start_record=(session[:expense_paid_page].to_i*session[:expense_paid_per_page].to_i)-session[:expense_paid_per_page].to_i
    @paid_end_record= @paid_start_record +  session[:expense_paid_per_page].to_i  - 1
    @paid_expenses = Transact.find(:all, :conditions=>["transact_type in (?) and credit_amount > 0 and balance_amount = 0 and flag = 0",[$EXPENSE,$PAYROLL_EXPENSE]], :order => session[:expense_paid_sort])
    @paid_records=@paid_expenses.length
    @paid_pages= (@paid_expenses.length.to_f/session[:expense_paid_per_page].to_i).ceil
    if request.xml_http_request?
      render :partial => "paid_list", :layout => false
    end
  end
  
  def details
    @expense_flag = $FLAG[:PAID]
    @expense_flag_array = [$FLAG[:UNPAID],$FLAG[:PAID],$FLAG[:DRAFT],$FLAG[:DELETED]]
    @transact_type = [$EXPENSE,$PAYROLL_EXPENSE]
    edit_expense
    @paid_or_not=Jujube.paid_or_not('expense',params[:id]) #Journal.find(:all,:conditions=>["inv_exp_number=? and journal_type in (?) and debit_amount = 0 and credit_amount > 0",params[:id], [$EXPENSE_PAID,$PAYROLL_EXPENSE_PAID]], :order=>"id")
  end 
 
  def delete
    @expense_flag_array = [$FLAG[:DRAFT],$FLAG[:UNPAID],$FLAG[:PAID],$FLAG[:RECURRING]]
    @transact_type = [$EXPENSE,$EXPENSE_RECURRING]
    edit_expense
    #Transact also have to be checked
    @paid_or_not=Jujube.paid_or_not('expense',params[:id]) #Journal.find(:all,:conditions=>["inv_exp_number=? and journal_type in (?) and debit_amount = 0 and credit_amount > 0",params[:id], [$EXPENSE_PAID,$PAYROLL_EXPENSE_PAID]], :order=>"id")
  end
  
  def delete_expense
    if request.delete?
      @expense=Expense.new
      @paid_or_not=Jujube.paid_or_not('expense',params[:id]) #Journal.find(:all,:conditions=>["inv_exp_number=? and journal_type in (?) and debit_amount = 0 and credit_amount > 0",params[:id], [$EXPENSE_PAID,$PAYROLL_EXPENSE_PAID]], :order=>"id")
      #Transact also have to be checked
      if @paid_or_not.blank?
          # Ticket #:705: Need to create a new journal entry for invoice and expense deletion
          # if Jujube.get_expense_number.to_i-1==params[:id].to_i
             # @expense.delete_expense_physically(params,current_user.id,current_company.id)
          #else
              @expense.delete_expense_by_changing_flag(params,current_user.id,current_company.id)
          #end   
        flash[:notice] = "<span> Expense Number:#{params[:id]} Successfully Deleted. "
        redirect_to :action=>'list'
      else
        flash[:notice] = "<span> Please try again later. An error occurred while Deleting Expense</span>"
        redirect_to :action=>'list'
      end
    else 
        flash[:notice] = "<b>Ill-legal try to delete an expense.: </b> <span> Issue reported to admin.</span>"
        redirect_to :action=>'list'
    end
  end

  def add_new_vendor    
    add_new_contact("vendor")
  end
  
  def remittances
    params[:page]||=1
    params[:per_page]||=10
     @remittance_reports=Payroll.paginate(:page=>params[:page], :per_page=>params[:per_page], :conditions=>["end_date <= (?) and flag != ? and flag != ?",1.month.ago.end_of_month, $FLAG[:DELETED],$FLAG[:PAYROLL]], :group=>"month(end_date),year(end_date)", :order=>"end_date DESC", :select=>"monthname(end_date) as month,year(end_date)as year, concat(monthname(DATE_ADD(end_date, INTERVAL 1 MONTH)),'15, ',YEAR(DATE_ADD(end_date, INTERVAL 1 MONTH)) ) as due_date,sum(canada_pension_plan) as cpp,sum(employee_insurance) as ei, sum(federal_tax) as fd, sum(provincial_tax) as pt")
     #@remittance_reports=Payroll.paginate(:page=>params[:page], :per_page=>params[:per_page], :conditions=>["flag=0 and remittance_paid = 0 and when_paid is NULL and end_date <= (?) ",1.month.ago.end_of_month], :group=>"month(end_date),year(end_date)", :order=>"end_date DESC", :select=>"monthname(end_date) as month,year(end_date)as year, concat(monthname(DATE_ADD(end_date, INTERVAL 1 MONTH)),'15, ',YEAR(DATE_ADD(end_date, INTERVAL 1 MONTH)) ) as due_date,sum(canada_pension_plan) as cpp,sum(employee_insurance) as ei, sum(federal_tax) as fd, sum(provincial_tax) pt")
      if request.xml_http_request?
      render :update do |page|
        page.replace_html "remittances_listing", :partial => "/expense/remittances_list", :layout => false
      end
    end

  end
  
  def remittance
    @month_start_date="01 #{params[:month]} #{params[:year]}".to_time.at_beginning_of_month.to_date
    @month_end_date="01 #{params[:month]} #{params[:year]}".to_time.at_end_of_month.to_date
    @month = @month_start_date.strftime("%B")
    @year = @month_start_date.year.to_s
    @due_date = "01 #{params[:month]} #{params[:year]}".to_time.next_month.strftime("%b 15th")
    @overdue_payroll = Payroll.find(:all,:conditions=>["end_date between ? and ? and flag=? and when_paid is NULL",@month_start_date,@month_end_date,$FLAG[:UNPAID]])
    @processed_payroll = Payroll.find(:all,:conditions=>["end_date between ? and ? and flag=? and when_paid is NULL",@month_start_date,@month_end_date,$FLAG[:PAID]])
    #unless @processed_payroll.blank?
   # @overdue_payroll = Payroll.find(:all,:conditions=>["flag=? and when_paid is NULL and id not in (?) and end_date between ? and ? ",$FLAG[:PAID],@processed_payroll.collect{|x| x.id},@month_start_date,@month_end_date]) 
   # else
    #@overdue_payroll = Payroll.find(:all,:conditions=>["flag=? and when_paid is NULL and end_date between ? and ? ",$FLAG[:PAID],@month_start_date,@month_end_date]) 
    #end
    processed_payroll_details 
    employee_ids = @processed_payroll.collect{|x| x.employee_id}
    @no_of_employees = employee_ids.uniq unless employee_ids.nil?
    overdue_payroll_details
    @remittance_paid_or_not=Journal.find(:all,:conditions=>["journal_type = ?",$REMITTANCE.to_s + "_" + @month.upcase + "_" + @year])
    payroll_accounts
   end
   
   def processed_payroll_details
    @payroll_cpp = @processed_payroll.collect{|x| x.canada_pension_plan }.inject(0) { |a, v| a += v} unless @processed_payroll.nil?
    @payroll_ei = @processed_payroll.collect{|x| x.employee_insurance }.inject(0) { |a, v| a += v} unless @processed_payroll.nil?
    @payroll_ft = @processed_payroll.collect{|x| x.federal_tax }.inject(0) { |a, v| a += v}  unless @processed_payroll.nil?
    @payroll_pt = @processed_payroll.collect{|x| x.provincial_tax }.inject(0) { |a, v| a += v} unless @processed_payroll.nil?
    @payroll_tax = @payroll_ft + @payroll_pt unless @payroll_ft.nil?
    #@processed_payroll = Payroll.find(:all,:conditions=>["end_date between ? and ? and flag=?",1.month.ago.at_beginning_of_month.to_date,1.month.ago.at_end_of_month.to_date,$FLAG[:PAID]])
    @processed_gross_amount =  @processed_payroll.collect{|x| x.gross_amount}.inject(0) { |a, v| a += v} unless @processed_payroll.nil?     
   end
  
  def overdue_payroll_details
    @overdue_cpp = @overdue_payroll.collect{|x| x.canada_pension_plan }.inject(0) { |a, v| a += v} unless @overdue_payroll.nil?
    @overdue_ei = @overdue_payroll.collect{|x| x.employee_insurance }.inject(0) { |a, v| a += v} unless @overdue_payroll.nil?
    @overdue_ft = @overdue_payroll.collect{|x| x.federal_tax }.inject(0) { |a, v| a += v}  unless @overdue_payroll.nil?
    @overdue_pt = @overdue_payroll.collect{|x| x.provincial_tax }.inject(0) { |a, v| a += v} unless @overdue_payroll.nil?
    @overdue_tax = @overdue_ft + @overdue_pt unless @overdue_ft.nil?     
  end  
  
  def payroll_accounts
    @payroll_expense_EI_credit = Account.find :first,:conditions=>["alias='EI Payable'"]
    @payroll_expense_CPP_credit = Account.find :first,:conditions=>["alias='CPP Payable'"]
    @payroll_expense_Chequing_credit = Account.find :first,:conditions=>["alias='Chequing Bank Account'"]
    @payroll_expense_FIT_credit = Account.find :first,:conditions=>["alias='Income Tax Payable'"]   
  end
  
  def common_initialize
    @acc_pay,@acc_pay_list,@expense_tax_account = Jujube.expense_common_initialize
  end
  
  def pay_options
      render :update do |page|
        page.call "RedBox.showInline",'pay_options' 
      end
  end  

  def pay_current_remittance
    @expense = Expense.new
    @expense.pay_current_remittance(params)
    flash[:notice] = "<span> Remittance Successfully Paid. "
    redirect_to :controller=>"general",:action=>"journal_list"
  end
  
  def check_cheque
      if params.include?(:cheque_number)
        if params[:cheque_number].nil? || params[:cheque_number].empty?
          render :update do |page|
          page[:cheque_error_disp].innerHTML="Please Enter the valid cheque number"
          end
        else
          cheque_result=check_uniqueness_of_cheque_number(params[:cheque_number])  
          if cheque_result[1]
            render :update do |page|
            page[params[:form_id]].submit
            end
          else
            render :update do |page|
            page[:cheque_error_disp].innerHTML="cheque number not in current sequence. You can use #{cheque_result[0]}"
            end
          end
        end
      else
        render :update do |page|
        page[params[:form_id]].submit
        end
      end
   end
  
  def check_uniqueness_of_cheque_number(cheque_number)
    @cheque_numbers=Transact.find(:all, :conditions=>["payment_type = ?", $PAYMENT_TYPE["CHEQUE"]]).collect{|x| x.cheque_number}
    if @cheque_numbers.include?(cheque_number.to_i)
      return [get_available_cheque_number(cheque_number),false]
    else
      return ["",true]
    end
  end
  
  def get_available_cheque_number(cheque_number)
    @cheque_numbers=Transact.find(:all, :conditions=>["payment_type = ?", $PAYMENT_TYPE["CHEQUE"]]).collect{|x| x.cheque_number}
    if @cheque_numbers.include?(cheque_number.to_i)
    suggest_cheq_num=cheque_number.to_i+1
    suggest_cheq_num=1 if suggest_cheq_num == 99999
    get_available_cheque_number(suggest_cheq_num)
    else
    return formatted_number(cheque_number)
    end
  end
  
  def pay_overdue_remittance
    @expense = Expense.new
    @expense.pay_overdue_remittance(params)
    flash[:notice] = "<span>Overdue Remittance Successfully Paid. "
    redirect_to :controller=>"general",:action=>"journal_list"
  end    

  
  def pay_other_remittance
    @expense = Expense.new
    @expense.pay_other_remittance(params)
    flash[:notice] = "<span>Other Remittance Successfully Paid. "
    redirect_to :controller=>"general",:action=>"journal_list"
  end  

end
