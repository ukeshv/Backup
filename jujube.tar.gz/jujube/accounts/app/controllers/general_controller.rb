class GeneralController < ApplicationController
  require "spreadsheet/excel"
  include Spreadsheet
  layout "clear"
   
  before_filter :login_required
  before_filter :setting_company_details, :only=>[:accounts,:journal_list]
  
  access_control [:accounts,:journal_list] =>  "(#{$ACCESS["ALL"]}  | #{$ACCESS["VIEW_ONLY"]})",
                       [:new_journal,:edit_journal,:update_journal,:update_opening_balance] =>  "(#{$ACCESS["ALL"]})"
  
  def accounts
    @groups = Group.find(:all, :conditions=>["parent_id = ?",0])   
  end

  def journal_list
    set_location('/general/journal_list')
    session[:sort] = nil
    journal_sorting_list
  end

  def journal_sorting_list
    if params[:sort]
      session[:sort] = params[:sort]
    elsif session[:sort]
      session[:sort] = session[:sort]
    else
      session[:sort] = "CAST(journal_number AS UNSIGNED) DESC, id"
    end   
    #@journals = Journal.find(:all, :conditions=>["flag != 9"], :order => session[:sort])      
    @journals = Journal.find(:all, :order => session[:sort])      
    
    i=0
    jno=0 
    for journal in @journals          
      jn = journal.journal_number 
      ien = journal.inv_exp_number
      if jn.blank?
        journal_number=ien
      else
        journal_number=jn
      end
      if journal_number == jno        
        @journals[i].journal_number = '' 
        @journals[i].journal_type = '' 
        @journals[i].inv_exp_number = '' 
        @journals[i].journal_date = ''  
        @journals[i].description = ''   
      end       
      jno= journal_number
      i+=1
    end    
    
    if request.xml_http_request?
      render :update do |page|
        page.replace_html 'listing_result', :partial => "/general/listing_journal_result"
      end
    end       
  end

  def new_journal
    set_location('/general/journal_list')
    @ind=0
    @accounts= Account.find(:all,:conditions=>["number is not null"], :order=>"number")
    @journal_number = Jujube.get_journal_number
    session[:selected_account]=nil
    return unless request.post?
    @journal_accounts = params[:journal_account].values
    @debit_amounts = params[:debit_amount].values
    @credit_amounts = params[:credit_amount].values
    @total_debit_amount = @debit_amounts.inject(0) { |n, value| n.to_f + value.to_f }
    @total_credit_amount = @credit_amounts.inject(0) { |n, value| n.to_f + value.to_f }
    @total_journal_items = params[:journal_account].values.length
      if @total_debit_amount == @total_credit_amount
        i=0
        while i < @total_journal_items.to_i
          @journal=Journal.new
          @journal.journal_type=$JOURNAL
          @journal.journal_number=params[:id]
          @journal.account_id=@journal_accounts[i]
          @journal.description=params[:description]
          @journal.journal_date=params[:journal_date]
          @journal.debit_amount=  @debit_amounts[i] 
          @journal.credit_amount=  @credit_amounts[i] 
          @journal.save
          @account = Account.find(@journal_accounts[i])
          @account.update_attributes(:closing_balance=>(@account.closing_balance.to_f + @debit_amounts[i].to_f - @credit_amounts[i].to_f)) if $DEBIT_GROUP.include?(@account.group.parent.id)  
          @account.update_attributes(:closing_balance=>(@account.closing_balance.to_f + @credit_amounts[i].to_f - @debit_amounts[i].to_f)) if $CREDIT_GROUP.include?(@account.group.parent.id)
          i+=1
        end
        flash[:notice] = "<span> Journal Number:#{params[:id]} Successfully Added. </span>"
        redirect_to :action=>"journal_list"
      else
        flash[:error] = "<span>Debit Amount and Credit Amount Total should be Equal.</span>"    
      end
  end

  def edit_journal
		@accounts= Account.find(:all,:conditions=>["number is not null"], :order=>"number")
		@journal_number = params[:id]
    @journals = Journal.find(:all, :conditions=>["journal_type=? and journal_number = ? ", $JOURNAL, @journal_number], :order=>"id")
    for account in @accounts
      for journal in @journals
        if journal.account_id == account.id
         #account.closing_balance=account.closing_balance.to_f+journal.credit_amount.to_f-journal.debit_amount.to_f  if $DEBIT_GROUP.include?(account.group.parent.id)
         #account.closing_balance=account.closing_balance.to_f-journal.credit_amount.to_f+journal.debit_amount.to_f if $CREDIT_GROUP.include?(account.group.parent.id)
         account.closing_balance=account.closing_balance.to_f+journal.credit_amount.to_f-journal.debit_amount.to_f  if $DEBIT_GROUP.include?(account.group.parent.id)
         account.closing_balance=account.closing_balance.to_f-journal.credit_amount.to_f+journal.debit_amount.to_f if $CREDIT_GROUP.include?(account.group.parent.id)
        end
      end
    end
  end

  def update_journal
    @journal_number = params[:id]
    @journals = Journal.destroy_all(["journal_type=? and journal_number = ? ", $JOURNAL, @journal_number])
    @journal_accounts = params[:journal_account].values
    @debit_amounts = params[:debit_amount].values
    @credit_amounts = params[:credit_amount].values
    for journal in @journals
      @account = Account.find(journal.account_id)
      @account.update_attributes(:closing_balance=>@account.closing_balance.to_f+journal.credit_amount.to_f-journal.debit_amount.to_f)  if $DEBIT_GROUP.include?(@account.group.parent.id)
      @account.update_attributes(:closing_balance=>@account.closing_balance.to_f-journal.credit_amount.to_f+journal.debit_amount.to_f) if $CREDIT_GROUP.include?(@account.group.parent.id)
    end
    i=0 
    for journal in @journal_accounts
      @journal = Journal.create!(:account_id =>@journal_accounts[i], :journal_type=>$JOURNAL,:journal_number=>@journal_number,:description=>params[:description], :journal_date=>params[:journal_date], :debit_amount=>  @debit_amounts[i] ,:credit_amount=>  @credit_amounts[i] )
      @account = Account.find(@journal_accounts[i])
      @account.update_attributes(:closing_balance=>(@account.closing_balance.to_f + @debit_amounts[i].to_f - @credit_amounts[i].to_f)) if $DEBIT_GROUP.include?(@account.group.parent.id)  
      @account.update_attributes(:closing_balance=>(@account.closing_balance.to_f + @credit_amounts[i].to_f - @debit_amounts[i].to_f)) if $CREDIT_GROUP.include?(@account.group.parent.id)
      i+=1
    end
    flash[:notice] = "<span> Journal Number:#{params[:id]} Successfully Updated. </span>"
    redirect_to :action=>'journal_list' 
  end

  def add_new_journal_fields
    @ind = params[:id]
		@accounts= Account.find(:all,:conditions=>["number is not null"], :order=>"number")
    render :update do |page|
      page.insert_html :bottom, "add_field", :partial =>"add_field", :object=>{:ind=>@ind}
     # page.call "check_diabled_status",@ind.to_i+1
      page.replace_html "display", :partial =>"add_link", :object=>{:ind=>@ind}
    end  
  end    
  
   def account_display
        @result = get_current_balance("all")
        @account = Account.find_by_id(params[:id])
        render :update do |page|
          page.replace_html "account_row"+ @account.id.to_s, :partial=>'account_row_display'
        end
   end 
      
 def update_opening_balance
        return unless request.post? 
        acc = eval("params[:account_" + "#{params[:id].to_s}" + "]")
        @account = Account.find(params[:id])
        @account_name_checking = Account.find(:first,:conditions=>["alias = ? and id != ? and company_id =?",acc[:name],params[:id],current_company.id])
        @account = Account.find_by_id(params[:id])
        if @account_name_checking.nil?
            @account.closing_balance = @account.closing_balance - @account.opening_balance + acc[:opening_balance].to_f
            @account.update_attributes(acc)
            if params[:advisor] 
            unless params[:advisor][:balance] == "" and params[:advisor][:balance].blank?
             @account.update_attributes(:closing_balance => @account.closing_balance  + params[:advisor][:balance].to_f)
            end
            end
            render :update do |page|
                page.redirect_to :controller=>"general",:action=>"accounts"
            end
        else
            render :update do |page|
                page.hide "popup"    
                page.hide "error1_"+params[:id]    
                 page.hide "error_"+params[:id]    
                page.show "popup"  
                page.show "error_"+params[:id] 
                if !(@account_name_checking.nil?) 
                    page.show "error1_"+params[:id] 
                end
            end
        end 
  end    
  
  
  def income_statement
      return unless request.post?    
      company_end_date = current_company.year_end_date.to_time
      if params[:i_s_type].downcase=='yearly'
          begin
            view_date = "#{company_end_date.day}-#{company_end_date.month}-#{params[:view_year]}".to_date 
          rescue 
            view_date = "#{company_end_date.day-1}-#{company_end_date.month}-#{params[:view_year]}".to_date
          end
          
          if params[:compare_year] !="nothing"
            begin
             compare_date = "#{company_end_date.day}-#{company_end_date.month}-#{params[:compare_year]}".to_date 
            rescue 
             compare_date =  "#{company_end_date.day-1}-#{company_end_date.month}-#{params[:compare_year]}".to_date 
            end
          end
      else  
          view_date = month_relavent_to_company_end_date(params[:view_month])
          compare_date = month_relavent_to_company_end_date(params[:compare_month],view_date) if params[:compare_month] !="nothing"
      end
      @groups = Group.find(:all,:conditions=>["name in (?)",['Revenue','Expenses']])
      @retained_earnings = Account.find(:first,:conditions=>"alias = 'Retained Earnings - Previous Year'")
      params[:year_end_date] = view_date 
      params[:compare_date] = compare_date  if (params[:i_s_type].downcase=='yearly' && params[:compare_date] != "nothing" ) || (params[:i_s_type].downcase !='yearly' && params[:compare_month] != "nothing")
      common_query
    end  



    def month_relavent_to_company_end_date(month, view_date=nil)
      company_end_year_date =   Time.now > current_company.year_end_date.to_time ? Time.now : current_company.year_end_date.to_time
      selected_month_date = "01-#{month}-#{company_end_year_date.year}".to_time.end_of_month
      if (selected_month_date > company_end_year_date) || (view_date && selected_month_date.to_date > view_date)
        selected_month_date = selected_month_date.advance(:years=>-1)
      end 
      return selected_month_date.to_date
    end
    
    def common_query
     if params[:compare_date]
       @accounts_date1 = Account.find_by_sql("SELECT accounts.id, accounts.name, accounts.closing_balance, journals.journal_date as journal_date  FROM accounts  LEFT JOIN journals ON accounts.company_id=#{current_company.id} and journals.company_id=#{current_company.id} and accounts.id=journals.account_id and journals.journal_date <="+"'"+"#{params[:compare_date].to_s.to_date}"+"'"+" WHERE accounts.company_id=#{current_company.id} and journal_date is not NULL GROUP BY accounts.id")
       payroll_date_1 = Payroll.find(:first, :conditions=>["end_date <= (?) and flag != ? and flag != ?",session[:year_end_date],$FLAG[:DELETED],$FLAG[:PAYROLL]], :select=>"sum(federal_tax) as fd, sum(provincial_tax) as pt") # its result will be only one record
       @income_tax_date1 = payroll_date_1.pt.to_f+payroll_date_1.fd.to_f
     end
   
     if params[:year_end_date]
       @accounts_date2 = Account.find_by_sql("SELECT accounts.id, accounts.name, accounts.closing_balance, journals.journal_date as journal_date  FROM accounts  LEFT JOIN journals ON accounts.company_id=#{current_company.id} and journals.company_id=#{current_company.id} and accounts.id=journals.account_id and journals.journal_date <="+"'"+"#{params[:year_end_date].to_s.to_date}"+"'"+" WHERE accounts.company_id=#{current_company.id} and journal_date is not NULL GROUP BY accounts.id")
       payroll_date_2 = Payroll.find(:first, :conditions=>["end_date <= (?) and flag != ? and flag != ?",session[:compare_date],$FLAG[:DELETED],$FLAG[:PAYROLL]], :select=>"sum(federal_tax) as fd, sum(provincial_tax) as pt") # its result will be only one record
       @income_tax_date2 = payroll_date_2.pt.to_f+payroll_date_2.fd.to_f
     end
     #@accounts_date1 = Account.find_by_sql("SELECT accounts.id, accounts.name, accounts.closing_balance,sum(journals.debit_amount)as debit, sum(journals.credit_amount)as credit FROM accounts  LEFT JOIN journals ON accounts.company_id=#{current_company.id} and journals.company_id=#{current_company.id} and accounts.id=journals.account_id and journals.journal_date <="+"'"+"#{session[:year_end_date].to_s.to_date}"+"'"+" WHERE accounts.company_id=#{current_company.id} GROUP BY accounts.id")
     #@accounts_date2 = Account.find_by_sql("SELECT accounts.id, accounts.name, accounts.closing_balance,sum(journals.debit_amount) as debit, sum(journals.credit_amount) as credit FROM accounts  LEFT JOIN journals ON accounts.company_id=#{current_company.id} and journals.company_id=#{current_company.id} and accounts.id=journals.account_id and journals.journal_date <="+"'"+"#{session[:compare_date].to_s.to_date}"+"'"+" WHERE accounts.company_id=#{current_company.id} GROUP BY accounts.id")
     # may need to check condition -> remittance_paid !!!
    end  
   
   def balance_sheet
     @groups = Group.find(:all,:conditions=>["name in (?)",['Assets','Liabilities','Equity']])
     balance_sheet_query
    return unless request.post?
    if params[:selected_date]      
      session[:selected_date] = params[:selected_date]
     elsif params[:compared_date]       
      session[:compared_date]= params[:compared_date]
    end  
     balance_sheet_query
   end  
   
   def balance_sheet_query
     #@accounts_date1 = Account.find_by_sql("SELECT accounts.id, accounts.name, accounts.closing_balance,sum(journals.debit_amount)as debit, sum(journals.credit_amount)as credit, journals.journal_date as journal_date FROM accounts  LEFT JOIN journals ON accounts.company_id=#{current_company.id} and journals.company_id=#{current_company.id} and accounts.id=journals.account_id and journals.journal_date <="+"'"+"#{session[:selected_date] ? session[:selected_date].to_s.to_date : Date.today.to_date}"+"'"+" WHERE accounts.company_id=#{current_company.id} and journal_date is not NULL GROUP BY accounts.id")
     #@accounts_date2 = Account.find_by_sql("SELECT accounts.id, accounts.name, accounts.closing_balance,sum(journals.debit_amount) as debit, sum(journals.credit_amount) as credit, journals.journal_date as journal_date FROM accounts  LEFT JOIN journals ON accounts.company_id=#{current_company.id} and journals.company_id=#{current_company.id} and accounts.id=journals.account_id and journals.journal_date <="+"'"+"#{session[:compared_date] ? session[:compared_date].to_s.to_date : Date.today.to_date}"+"'"+" WHERE accounts.company_id=#{current_company.id} and journal_date is not NULL GROUP BY accounts.id")
     @accounts_date1 = Account.find_by_sql("SELECT accounts.id, accounts.name, accounts.closing_balance,sum(journals.debit_amount)as debit, sum(journals.credit_amount)as credit FROM accounts  LEFT JOIN journals ON accounts.company_id=#{current_company.id} and journals.company_id=#{current_company.id} and accounts.id=journals.account_id and journals.journal_date <="+"'"+"#{session[:selected_date] ? session[:selected_date].to_s.to_date : Date.today.to_date}"+"'"+" WHERE accounts.company_id=#{current_company.id} GROUP BY accounts.id")
     @accounts_date2 = Account.find_by_sql("SELECT accounts.id, accounts.name, accounts.closing_balance,sum(journals.debit_amount) as debit, sum(journals.credit_amount) as credit FROM accounts  LEFT JOIN journals ON accounts.company_id=#{current_company.id} and journals.company_id=#{current_company.id} and accounts.id=journals.account_id and journals.journal_date <="+"'"+"#{session[:compared_date] ? session[:compared_date].to_s.to_date : Date.today.to_date}"+"'"+" WHERE accounts.company_id=#{current_company.id} GROUP BY accounts.id")
   end  
  
def export_reports 
  @groups = Group.find(:all, :conditions=>["parent_id = ?",0])  
  journal_list
  account_file = Date.today.strftime("%m-%d-%Y").to_s+"_JuJube_Hardcopy.xls"
  #journal_file = "journals.xls"
  workbook = Excel.new("#{RAILS_ROOT}/public/reports/#{account_file}")
  #journal_workbook = Excel.new("#{RAILS_ROOT}/public/reports/#{journal_file}")
  worksheet = workbook.add_worksheet("accounts")
  journal_worksheet = workbook.add_worksheet("journals")
  row1= 1
  for group in @groups
    for sub_group in group.children
      worksheet.write(row1,0,sub_group.number)
      worksheet.write(row1,1,sub_group.name)
      row1 = row1+ 1
      for user_account in sub_group.user_accounts(session[:user_id])
        worksheet.write(row1,0,user_account.number)
        worksheet.write(row1,1,user_account.name)
        worksheet.write(row1,4,user_account.closing_balance)
        row1 = row1 + 1  
      end
    end
  end
  @header =  %w(JE.# Date Description Account Debit Credit)
  col = 0
  @header.each do |header|
  journal_worksheet.write(0,col,header.upcase)
  col += 1
  end
  row2= 1
  for journal in  @journals
    journal_worksheet.write(row2,0,"JE.##{journal.journal_number}") unless journal.journal_number.blank?
    journal_worksheet.write(row2,1,journal.journal_date.to_time.strftime("%m/%d/%Y")) unless journal.journal_date.nil?
    description = journal.inv_exp_number.nil? ? journal.journal_type.to_s : journal.journal_type.to_s + ":" + journal.inv_exp_number.to_s + journal.description.to_s
    journal_worksheet.write(row2,2,description)
    journal_worksheet.write(row2,3,journal.account.number.to_s + "  " + journal.account.name.to_s)
    journal_worksheet.write(row2,4,journal.debit_amount)
    journal_worksheet.write(row2,5,journal.credit_amount)
    row2 = row2 + 1
  end
  workbook.close
  filepath = RAILS_ROOT + "/public/reports/" + "#{account_file}"
  send_file filepath, :disposition => 'inline' 
  #File.delete("#{RAILS_ROOT}/public/reports/#{account_file}") if File.exist?("#{RAILS_ROOT}/public/reports/#{account_file}")
end
end
