class HeartbeatController < ActionController::Base 
  #ignoring the filter mechnism used in application controller
session :off 
#since activerecord session is used, will create unwanted sessions when hearbeat is called

  def index
    Account.count  #sample db query to see if app works
    render :text => 'Alive' #'Alive' to matched by heartbeat tester, via cron
  end

end
