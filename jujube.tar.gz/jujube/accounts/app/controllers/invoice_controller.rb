class InvoiceController < ApplicationController
  before_filter :login_required #, :clear_location, :except=>'back_to'
  before_filter :setting_company_details, :only=>[:new_invoice,:list]

  access_control [:list ] =>  "(#{$ACCESS["INVOICE_AND_EXPENSE"]} | #{$ACCESS["ALL"]}  | #{$ACCESS["VIEW_ONLY"]})",
                       [:new,:create,:edit,:new_invoice,:edit_invoice,:update,:receive_invoice,:update_invoice,:details,:delete,:delete_invoice] =>  "(#{$ACCESS["INVOICE_AND_EXPENSE"]} | #{$ACCESS["ALL"]})"
  include PdfHelper
    # Sends pdf of an estimate out...
    #
		layout :clear_or_invoice_pdf
		
   def pdf
     i = 0	   
     rand_number = Time.now.to_i.to_s
    @template_name = "invoice_#{current_user.id.to_s}_#{params[:id].to_s}_#{rand_number}.html"
    @pdf_name = "invoice_#{current_user.id.to_s}_#{params[:id].to_s}_#{rand_number}.pdf"
    invoice_pdf
    generator = IO.popen("htmldoc -t pdf --webpage -f #{RAILS_ROOT}/public/#{@pdf_name}  http://#{request.env['HTTP_HOST']}/#{@template_name}", "w+")
    generator.close_write
    while i < 10 do
	 i+=1   
        sleep(1)
	if File.exists?(RAILS_ROOT+'/public/'+@pdf_name)
		i = 10
		if @control_from != "email"
			send_data(File.open(RAILS_ROOT+'/public/'+@pdf_name,'rb').read, :filename => @pdf_name, :type => "application/pdf")
			File.delete(RAILS_ROOT+'/public/'+@template_name) if File.exists?(RAILS_ROOT+'/public/'+@template_name)
			File.delete(RAILS_ROOT+'/public/'+@pdf_name) if File.exists?(RAILS_ROOT+'/public/'+@pdf_name)
		else
			
		end		
	end
   end     
  end
		
  def invoice_pdf
	details
	File.open(RAILS_ROOT+"/public/#{@template_name}","w"){|f| f.write(render(:action=> 'invoice_pdf', :layout=>false) )}
  end


  def new_invoice
    @invoice_number = Jujube.get_invoice_number
    new
		#set_location('/invoice/list')
    #render :template=>'/invoice/new'
  end  
  
  def new_recurring_invoice
    @invoice_number = Jujube.get_recurring_invoice_number
    new
    #set_location('/invoice/recurring_list')
		render :template=>'/invoice/new'
  end
  
  def new
    common_initialize
    @ind = -1
    @contact_list=@acc_rec_list
    session[:new_contact_action]="new"
    @accounts = Account.find(:all, :conditions=>["group_id in (12,13) and number IS NOT NULL"])
    render :action=>'new'
  end
  
  def create
    @invoice= Invoice.new
    if @invoice.save(params,current_user.id,current_company.id)
      flash[:notice] = "<span> Invoice Successfully Added. </span>"
      redirect_to @invoice.next_action
    else
      flash[:error] = "<span> Please try again later. An error occured while Adding Invoice</span>"
      redirect_to :action=>'list'
    end
  end
  
  def edit_invoice
      @invoice_flag_array = [$FLAG[:DRAFT],$FLAG[:UNPAID]]
      @transact_type = $INVOICE
      edit
      #set_location('/invoice/list')
      render :template=>'/invoice/edit'
  end
  
  def edit_recurring_invoice
      @invoice_flag_array = [$FLAG[:RECURRING]]
      @transact_type = $INVOICE_RECURRING
      edit
			session[:recurred_cron_inv_number]=@invoice_number
      recurred_invoice_list
		  #set_location('/invoice/recurring_list')      
      render :template=>'/invoice/edit'
  end
    
  def edit
    common_initialize
    @invoice_number=params[:id]
    @accounts = Account.find(:all, :conditions=>["group_id in (12,13) and number IS NOT NULL"]) 
    @transact = Transact.find(:first,:conditions=>["invoice_number = ? and transact_type = ? and debit_amount > 0 and flag in (?)" ,params[:id],@transact_type,@invoice_flag_array])
    @transact_credit_all_records = Transact.find(:all,:conditions=>["invoice_number = ? and transact_type = ? and debit_amount = 0 and flag in (?) " ,@invoice_number,@transact_type,@invoice_flag_array])
    @recurring_transact=RecurringTransact.find(:first, :conditions=>['recurring_inv_exp_number = ? and recurring_type=? ',@transact.invoice_number,@transact_type]) if @invoice_flag_array == [$FLAG[:RECURRING]]
    @address = Contact.find_by_account_id(@transact.account_id)
    @invoice_details = InvoiceDetail.find(:all, :conditions=>["invoice_number= ? and transact_id in (?) ",@invoice_number,@transact_credit_all_records .collect{|x|x.id}], :order=>"id")
    @total_amount=@invoice_details.inject(0) { |sum, x| sum += x.amount.to_f }
    @total_tax=@invoice_details.inject(0) { |sum, x| sum += x.tax_amount.to_f}
    @total = @total_amount+@total_tax
    @account_names=['Cash on Hand','Savings Bank Account','Chequing Bank Account','Petty Cash','Credit Card Payable']
    #@account_names=['Savings Bank Account','Chequing Bank Account']
    @source_accounts = Account.find(:all, :conditions=>["alias in (?)",@account_names ])
    @contact_list=@acc_rec_list
    @entry_logs=EntryStatusLog.find(:all,:conditions=>["entry_number = ? and entry_type = ? ",@invoice_number,$ENTRY[:INVOICE]]) 
    session[:new_contact_action]="edit"
  end

  def update
    return unless request.post?
    common_initialize
    @invoice=Invoice.new
    if params[:received]
      pay_invoice
    else
      update_invoice
    end
  end
  
  def receive_invoice
  	#set_location('/invoice/list')
		if request.post? 
		@invoice=Invoice.new
    if @invoice.pay_invoice(params[:id],params[:hidden_account_id],params[:hidden_cheque_number],params[:hidden_payment_date], params[:hidden_payment_type],current_user.id,current_company.id)
		flash[:notice] = "<span> Invoice Number:#{params[:id]} Successfully Paid. </span>"
    redirect_to :controller=>"invoice",:action=>"list"
		else
		flash[:error] = "<span> Please try again later. An error occured while Paying Invoice</span>"
		redirect_to :action=>'list' 
		end
		else
			details
			render :template=>'/invoice/details'
		end
  end
  
  def update_invoice
	  #set_location('/invoice/list')
  	return unless request.post?
    @invoice=Invoice.new
    if @invoice.update_invoice(params,current_user.id,current_company.id)
        flash[:notice] = "<span> Invoice Number:#{params[:id]} Successfully Updated. </span>"
        redirect_to @invoice.next_action
    else
        flash[:error] = "<span> Please try again later. An error occurred while Editing Invoice</span>"
        redirect_to :action=>'list'
    end
  end
  
  def revert_payment
    Invoice.revert_payment(params[:id],current_user.id,current_company.id)
    flash[:notice] = "Payment Successfully Reverted for invoice No ##{params[:id]}"
    redirect_to :action=>'list'
  end
  
  
	def details
		@invoice_flag_array = [$FLAG[:DRAFT],$FLAG[:UNPAID],$FLAG[:PAID],$FLAG[:DELETED]]
		@transact_type = $INVOICE
		edit
		@paid_or_not=Jujube.paid_or_not('invoice',params[:id]) #Journal.find(:all,:conditions=>["inv_exp_number=? and journal_type=? and debit_amount > 0 and credit_amount = 0",params[:id], $INVOICE_RECEIVED])
    #set_location('/invoice/list')
	end
  
  def list
    set_location('/invoice/list')
  	if request.post? 
  	check_filter_conditions
  	all_invoice_list(@filter_condition)
  	else
			session[:invoice_sort] = nil
			session[:invoice_page] = nil
			session[:invoice_per_page] = nil
			session[:invoice_received_sort] = nil
			session[:invoice_received_page] = nil
			session[:invoice_received_per_page] = nil
			session[:invoice_sorting_condtion]=nil
			#check_filter_conditions
			all_invoice_list("1=1")
			#received_list
    end
  end
  
    def check_filter_conditions
  	@net_days = session[:company] && session[:company].net_days &&  session[:company].net_days > 0 ? session[:company].net_days : 0
@filter_condition=[]
	if params[:draft]
		@filter_condition<<"( flag=#{$FLAG[:DRAFT]} )"
	end
	if params[:open]
		@filter_condition<<"(flag=#{$FLAG[:UNPAID]} and (CURDATE()-invoice_date)<=#{@net_days})"
	end
	if params[:overdue]
		@filter_condition<<"(flag=#{$FLAG[:UNPAID]} and (CURDATE()-invoice_date)>#{@net_days}) "
	end
	if params[:paid]
		@filter_condition<<"(flag=#{$FLAG[:PAID]} )"
	end
	if params[:all]
		@filter_condition<<"1=1"
	end
	@filter_condition=@filter_condition.join(" or ")
	@filter_condition="1=1" if @filter_condition.empty?
	session[:invoice_sorting_condtion]=@filter_condition
 end

  
  
  def filter
  	render :template=>'/invoice/list'
 	end
  def recurring_list
    set_location('/invoice/recurring_list')
    all_recurring_invoice_list
    render :template=>'/invoice/list'
  end
  
  def all_recurring_invoice_list
    invoice_list($INVOICE_RECURRING,[$INVOICE_CRON])
  end
  
  def sorting_invoice_list
	  #check_filter_conditions
	  @filter_condition= session[:invoice_sorting_condtion] ? session[:invoice_sorting_condtion] : "1=1"
  	all_invoice_list(@filter_condition)
 	end
 	
  def all_invoice_list(filter_condition)
  	@source_type=[$INVOICE]
  	@recurring_invoice_limit=Jujube.get_recurring_invoice_number
  	(1..@recurring_invoice_limit).each do |invoice_number|  @source_type<<"#{$INVOICE_RECURRING} #{invoice_number}" end
    invoice_list($INVOICE,@source_type,filter_condition)
  end
  	
	def recurred_invoice_list
		invoice_list($INVOICE, ["#{$INVOICE_RECURRING} #{session[:recurred_cron_inv_number]}"])
	end

=begin	
  def received_list
    if params[:sort]
      session[:invoice_received_sort] = params[:sort]
    elsif session[:invoice_received_sort]
      session[:invoice_received_sort] = session[:invoice_received_sort]
    else
      session[:invoice_received_sort] = "id desc"
    end   
    if params[:page]
      session[:invoice_received_page]=params[:page]
    elsif session[:invoice_received_page]
      session[:invoice_received_page]=session[:invoice_received_page]
    else
      session[:invoice_received_page]=1
    end
    if params[:per_page]
      session[:invoice_received_per_page]=1
      session[:invoice_received_per_page] = params[:per_page]
    else
      session[:invoice_received_per_page] = 10
    end
    @received_start_record=(session[:invoice_received_page].to_i*session[:invoice_received_per_page].to_i)-session[:invoice_received_per_page].to_i
    @received_end_record= @received_start_record +  session[:invoice_received_per_page].to_i  - 1
    @received_invoices = Transact.find(:all, :conditions=>["transact_type = ? and debit_amount > 0 and balance_amount = 0 and flag=0",$INVOICE], :order => session[:invoice_received_sort])
    @received_records=@received_invoices.length
    @received_pages= (@received_invoices.length.to_f/session[:invoice_received_per_page].to_i).ceil
    if request.xml_http_request?
      render :partial => "received_list", :layout => false
    end
  end  
=end

  def delete_invoice
    if request.delete?
      delete(params,params[:flag])
    else 
        flash[:error] = "<b>Ill-legal try to delete an invoice.: </b> <span> Issue reported to admin.</span>"
        redirect_to :action=>'list'
    end  
  end
  
  def delete_recurring_invoice
  	delete(params,$FLAG[:RECURRING])
  end
  
  def delete(params,flag)
  @invoice=Invoice.new
  @paid_or_not=Jujube.paid_or_not('invoice',params[:id]) #Journal.find(:all,:conditions=>["inv_exp_number=? and journal_type=? and debit_amount > 0 and credit_amount = 0",params[:id], $INVOICE_RECEIVED])
  #Transact also have to be checked
  if @paid_or_not.blank?
    # Ticket #:705: Need to create a new journal entry for invoice and expense deletion (AS)
    #if Jujube.get_invoice_number.to_i-1==params[:id].to_i
       # @invoice.delete_invioce_physically(params,flag,current_user.id,current_company.id)
    #else
        @invoice.delete_invioce_by_changing_flag(params,flag,current_user.id,current_company.id)
    #end   
    flash[:notice] = "<span> Invoice Number:#{params[:id]} Successfully Deleted. "
    redirect_to :action=>'list'
  else
    flash[:error] = "<span> Please try again later. An error occurred while Deleting Invoice</span>"
    redirect_to :action=>'list'
  end
  end
  
  def find_address
    get_contact_address
  end  
  
  def find_sum    
    @sum = params[:sum].to_f
    @sum_tax = params[:sum_tax].to_f
    @total = @sum + @sum_tax
    render :update do |page|
      page.replace_html :total_amount, number_to_currency(@sum,{:unit => "$", :separator => ".", :delimiter => ","})
      page.replace_html :total_tax, number_to_currency(@sum_tax,{:unit => "$", :separator => ".", :delimiter => ","})
      page.replace_html :total, number_to_currency(@total,{:unit => "$", :separator => ".", :delimiter => ","})
    end
  end
  
  def find_amount
    @quantity = params[:quan].to_f
    @rate = params[:rate].to_f
    @amount = @quantity * @rate
    render :update do |page|
      field_name = 'amount_'+params[:id].to_s
      page.call "$('#{field_name}').value=",@amount
    end
  end
  
  def add_new_invoice_fields
    @ind = params[:id]
    @accounts = Account.find(:all, :conditions=>["group_id in (12,13) and number IS NOT NULL"]) 
    render :update do |page|
      page.insert_html :bottom, "add_field_body", :partial =>"add_field", :locals=>{:invoice_detail=>nil, :ind=>@ind,:accounts=>@accounts}
      page.replace_html "display", :partial =>"add_link", :locals=>{:ind=>@ind}
    end  
  end      
  
  def add_new_client    
    add_new_contact("client")
  end
  
  def show_recursive_calendar
    render :update do |page|
      page.show "recursive_calendar_label"
      page.show "recursive_calendar"
      page.replace_html "recursive_calendar", :partial =>"partial/recursive_calendar", :locals=>{:calendar_name=>"transact[invoice_date1]", :selected_monthly_day=>params[:selected_monthly_day],:selected_weekly_day=>params[:selected_weekly_day]}
    end
  end
  
  def common_initialize
    @acc_rec,@acc_rec_list,@invoice_sales_account,@invoice_tax_account = Jujube.invoice_common_initialize
  end
  
  def pay_options
    @id = params[:value]
      render :update do |page|
       page.call "RedBox.showInline",'pay_options'
      end
	end
		
	def email_pdf
                @control_from = "email"
         	@transact=Transact.find(params[:id])
		params[:id] = @transact.invoice_number # params[:id] overwritten  to suppert def pdf etc.#
		pdf
		@contact=Contact.find_by_account_id(@transact.account_id)
		@error=false
		if (params[:to_address]=~ /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i) != 0
			@error=true
		end
		unless params[:cc_address].blank?
			if (params[:cc_address]=~ /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i) != 0
				@error=true
			end
		end
		params[:invoice][:pdf] = "#{RAILS_ROOT}/public/#{@pdf_name}"
		erase_render_results
		if @error==false
			if params[:default_address]
				@contact.email=params[:to_address]
				@contact.save
			end
			UserNotifier.deliver_email_invoice_pdf(current_company,@contact,params,request)
			@entry_log = EntryStatusLog.create(:user_id=>current_user.id,:company_id=>current_company.id,:date_of_change=>Time.now,:transact_id=>@transact.id,:entry_id=>@transact.id,:entry_number=>@transact.invoice_number,:entry_type=>$ENTRY[:INVOICE],:action=> $LOG_ACTION[:EMAIL])    

			flash[:notice]= "<span> Invoice ##{@transact.invoice_number} emailed successfully.</span>"
			redirect_to :action=>'details', :id=>@transact.invoice_number
			File.delete(RAILS_ROOT+'/public/'+@template_name) if File.exists?(RAILS_ROOT+'/public/'+@template_name)
			File.delete(RAILS_ROOT+'/public/'+@pdf_name) if File.exists?(RAILS_ROOT+'/public/'+@pdf_name)
		else
			flash[:error]= "<span> Please try again later. An error occurred while sending mailing pdf</span>"
			redirect_to :action=>'details', :id=>@transact.invoice_number and return
		end
		
	end
  
  
	
	def clear_or_invoice_pdf
		(action_name == 'pdf' || action_name=="invoice_pdf") ? 'invoice_pdf' : 'clear'
	end		

end
