class SettingsController < ApplicationController
  in_place_edit_for :user, :email
  before_filter :login_required, :except=>[:new_company, :create_company, :get_provincial_tax]
  access_control [:my_plan,:my_company, :tax_settings, :access_control,:new_user,:edit_user,:delete_user] =>  "(#{$ACCESS["ALL"]})"
  layout "clear"

  def my_plan
    @plans = Plan.find(:all)
    @current_plan = current_company.plan_name
  end  
  
  def upgrade_plan
    @creditcard = CreditcardDetail.find(:first,:conditions=>["user_id=?",current_user.id])
    @user = User.find(current_user.id)
     return unless request.post?
=begin     
      if params[:creditcard_detail]
      @credit_card = CreditcardDetail.new(params[:creditcard_detail]) 
      if @credit_card.valid?
        @credit_card.user_id=current_user.id
        @credit_card.save
        @credit_card.update_attributes(:status=>"successful",:payment_date=>Time.now)        
      end
      end
=end
      current_company.update_attributes(:plan_name=>params[:plan]) 
      UserNotifier.deliver_plan_upgraded_notification(@user,request)      
      flash[:notice]="<span>Plan has been upgraded. </span>"
      redirect_to :controller=>"/settings",:action=>"my_plan"      
    end  
  
  def account_details
    @user = User.find_by_id(current_user.id)
		#@company = @user.client.companies.first
		#@company = session[:company]
  end  
  
    
		def update_password_details
			@user = User.find_by_id(current_user.id)
			#@company = @user.client.companies.first
    return unless request.post?
		flash[:password_error2]=""
    if User.authenticate(current_user.email, params[:old_password])
			@old_password = params[:old_password]
			@user.email =params[:user][:email]
			@user.password =params[:user][:password]
			@user.password_confirmation =params[:user][:password_confirmation]
			@user.title =params[:user][:title]
			@user.first_name =params[:user][:first_name]
			@user.last_name =params[:user][:last_name]
      if @user.valid?
        current_user=@user.save
        UserNotifier.deliver_password_change_notification(@user,request)      
        flash[:notice] = "<span>Login details has been saved. </span>"
				session[:account_detail]="login"
				redirect_to :action=>'account_details'
      else
				flash[:password_error1]="Password mismatch"
				redirect_to :action=>'account_details', :set=>'pass'
			end
    else
				flash[:password_error2]="Wrong password"
				redirect_to :action=>'account_details'
    end
  end		


  def update_email_details
	  @user = User.find_by_id(current_user.id)
		#@company = @user.client.companies.first
    return unless request.post?
    @new_mail = params[:user][:new_email]
    if !@new_mail.match(/^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i)
      flash[:mail_error]="Please enter valid email format"
    else
        flash[:password_error]=""
        if User.authenticate(current_user.email, params[:confirm_password])
              @password = params[:confirm_password]
              @user.email =params[:user][:email]
              @user.new_email =params[:user][:new_email]
              @user.new_email_activation_code = make_email_reset_code(params[:user][:new_email])
              if User.find_by_email(params[:user][:new_email])==nil and User.find_by_new_email(params[:user][:new_email])==nil
                  if @user.valid?
                        current_user=@user.save
                        UserNotifier.deliver_email_change_notification(@user,request)      
                        flash[:notice] = "<span>Login details has been saved. </span>"
                        session[:account_detail]="login"
                  end
            else
                  flash[:mail_error]="This mail is all allready taken. choose another."
            end    
        else
            flash[:password_error]="Wrong password"
        end
    end		
		redirect_to '/settings/account_details/email'
  end		


		def update_company_details
			@user = User.find_by_id(current_user.id)
			@company = current_company
			return unless request.post?
			@user[:first_name]=params[:user][:first_name]
			@user[:last_name]=params[:user][:last_name]
			@user[:title]=params[:user][:title]
			@company[:name]=params[:company][:name]
			if @user.valid? and @company.valid? 
				@user.save
				@company.save
				current_company=@company
				current_user=@user
			flash[:notice] = "<span>Company details has been saved. </span>"
			session[:account_detail]="company"
			redirect_to :action=>'account_details'
			else
			render :action=>'account_details'
			end
		end	

=begin
  def tax_settings
  @company = Company.find(session[:company].id)
  return unless request.post?
  @company.update_attributes(:net_days=>params[:company][:net_days].to_i, :tax=>params[:company][:tax].to_f, :selected_province=>params[:company][:selected_province].to_s) 
  session[:company]=@company
  flash[:notice]="<b>Settings Updated: </b> <span>Changes have been saved. </span>"
  redirect_to(:controller=>"account",:action=>"dashboard")
  end
=end  
  
  def get_provincial_tax
    unless params[:value].nil?
      p_tax = Province.find_by_code(params[:value]).tax
      render :update do |page|
       page.call "$('company_tax').value = ",p_tax
       page.call "$('origional_tax').value = ",p_tax
      end   
    end
  end
  
 
  def new_company
     if !current_user
       flash[:error] = "Please login"
       redirect_to "/"
     else  
      @company = Company.new
      @selected_date=31
      @selected_month=12
    end
  end
    
    def create_company
    @company = Company.new
    return unless request.post?
     if !current_user
       flash[:error] = "Please login"
       redirect_to "/"
     else  
          @user = User.find_by_id(current_user.id)
          year = Date.today.year
          year +=1 if params[:end][:month].to_i < Date.today.month or (params[:end][:month].to_i == Date.today.month and  params[:end][:date].to_i < Date.today.day)
          month = params[:end][:month].to_i
          day = params[:end][:date].to_i
          begin
            date = year.to_s + "-" + month.to_s + "-" + day.to_s
            date = date.to_date
          rescue
            day=day-1
            retry
          end
          @company[:street1]=params[:company][:street1]
          @company[:street2]=params[:company][:street2]
          @company[:city]=params[:company][:city]
          @company[:state]=params[:company][:state]
          @company[:zip]=params[:company][:zip]
          @company[:country]=params[:company][:country]
          @company[:phone]=params[:company][:phone]
          @company[:fax]=params[:company][:fax]
          @company[:website]=params[:company][:website]
          @company[:year_end_date]=date
          @company[:business_number]=params[:company][:business_number]
          @company[:business_type]=params[:company][:business_type]=='Others' ? params[:company_business_other_type] : params[:company][:business_type]
          @company[:name]=params[:company][:name]
          @company.net_days=params[:company][:net_days].to_i
          @company.tax=params[:company][:tax].to_f
          @company.selected_province=params[:company][:selected_province].to_s
          @company.logo_display_flag=params[:company][:logo_display_flag]=="on" ? false : true
          @company.owner=@user
          @user[:first_name]=params[:user][:first_name]
          @user[:last_name]=params[:user][:last_name]
          @user[:title]=params[:user][:title]
          if @user.valid? and @company.valid? 
            @user.save
            @company.save
            session[:company]=@company
            current_company=@company
            current_user=@user
            if params[:company_details][:uploaded_data]!=""
              @company.create_company_details(params[:company_details])
            end
            flash[:notice]="<span>New Company created under your Account. </span>"
            redirect_to(:controller=>"account",:action=>"dashboard")
          else
            #new_company
            flash[:error]="<span>Details have not been saved. </span>"
            render :action=>'new_company'
          end
     end # if !current_user
  end
  
  def my_company
    @company = current_company
    @selected_date = @company.year_end_date.day unless @company.year_end_date.nil?
    @selected_month = @company.year_end_date.month unless @company.year_end_date.nil?
    @month_to_display = @company.year_end_date.strftime("%b") unless @company.year_end_date.nil?
    @business_type = @company.business_type
    @user = User.find_by_id(current_user.id)
    

    return unless request.post?
    year = Date.today.year
    year +=1 if params[:end][:month].to_i < Date.today.month or (params[:end][:month].to_i == Date.today.month and  params[:end][:date].to_i < Date.today.day)
    month = params[:end][:month].to_i
    day = params[:end][:date].to_i
    begin
      date = year.to_s + "-" + month.to_s + "-" + day.to_s
      date = date.to_date
    rescue
      day=day-1
      retry
    end
		@company[:street1]=params[:company][:street1]
		@company[:street2]=params[:company][:street2]
		@company[:city]=params[:company][:city]
		@company[:state]=params[:company][:state]
		@company[:zip]=params[:company][:zip]
		@company[:country]=params[:company][:country]
		@company[:phone]=params[:company][:phone]
		@company[:fax]=params[:company][:fax]
		@company[:website]=params[:company][:website]
		@company[:year_end_date]=date
		@company[:business_number]=params[:company][:business_number]
		@company[:business_type]=params[:company][:business_type]=='Others' ? params[:company_business_other_type] : params[:company][:business_type]
		@company[:name]=params[:company][:name]
    @company.net_days=params[:company][:net_days].to_i
    @company.tax=params[:company][:tax].to_f
    @company.selected_province=params[:company][:selected_province].to_s
    @company.logo_display_flag=params[:company][:logo_display_flag]=="on" ? false : true
    @user[:first_name]=params[:user][:first_name]     if params[:user] and params[:user][:first_name]
    @user[:last_name]=params[:user][:last_name]     if params[:user] and params[:user][:last_name]
		@user[:title]=params[:user][:title]    if params[:user] and params[:user][:title]

			if @user.valid? and @company.valid? 
				@user.save
				@company.save
        @company = Company.find(session[:company].id)
        session[:company]=@company
				current_company=@company
				current_user=@user
      if params[:company_details][:uploaded_data]!=""
      @company.create_company_details(params[:company_details])
    end
    flash[:notice]="<span>Changes have been saved. </span>"
    redirect_to(:controller=>"settings",:action=>"my_company")
    else
      flash[:error]="<span>Changes have not been saved. An error occurred</span>"
    end
  end
  
  def companies
    @owned_companies=current_user.owned_companies
    @authorized_companies=current_user.authorized_companies
  end
  def access_control
    @users=current_company.authorized_users
    #@users=session[:company].users.find(:all,:conditions=>["users.flag!=? and users.email != ?", $FLAG[:DELETED],session[:company].email])
    #@users=User.find(:all, :conditions=>["users.client_id=? and users.flag !=  ? and users.email != clients.email",session[:client],$FLAG[:DELETED]], :include=>[:client], :order=>'users.id')
  end 
    
  def new_user
    #if check_plan("NOU")
    set_location('/settings/access_control')
    @user=User.new
    return unless request.post?
    @user=User.find(:first, :conditions=>["email=? and email != ?", params[:user][:email], current_user.email])
    if @user
        #UserAccess.create_company_access_for_user(@user,session[:company],params[:account][:type],params[:access][:level])
        @user_access=UserAccess.new(:user_id=>@user.id,:company_id=>current_company.id, :first_name=>params[:user_access][:first_name], :last_name=>params[:user_access][:last_name],:account_type=>params[:user_access][:account_type],:access_level=>params[:user_access][:access_level], :access_activation_code=>"Jujube", :flag=>0, :access_activated_at=>Time.now)
        if @user_access.valid?
        @user_access.save
       UserNotifier.deliver_authorize_company_notification(@user,@user_access,current_company,request)
        flash[:notice] = "<span>User:#{params[:user][:first_name]} #{params[:user][:last_name]} Already a part of Jujube User with the name #{@user.name} and Added under your company. </span>"
        redirect_to :action=>'access_control'  
        end
    else
      @user=User.new
      @user.first_name=params[:user_access][:first_name]
      @user.last_name=params[:user_access][:last_name]
      @user.email=params[:user][:email]
      @user.password=@user.password_confirmation=get_random_password(5)
      @user_access=UserAccess.new(:company_id=>current_company.id,:first_name=>params[:user_access][:first_name], :last_name=>params[:user_access][:last_name], :account_type=>params[:user_access][:account_type],:access_level=>params[:user_access][:access_level], :flag=>0)
      if @user.valid? && @user_access.valid?
        @user.save
        @user_access.user_id=@user.id
        @user_access.save
        UserNotifier.deliver_signup_notification(@user,request)
#     UserAccess.create_company_access_for_user(@user,session[:company],params[:account][:type],params[:access][:level])
        flash[:notice] = "<span> New User:#{@user.name} Successfully Added. </span>"
        redirect_to :action=>'access_control'
      end
    end
  
    #else
      #flash[:notice] = "<span> To add more users you have to upgrade your plan. </span>" 
      #redirect_to :action => 'my_plan'
    #end    
  end
	
	def edit_user
		@user=User.find(:first, :conditions=>["users.id= ? and users.flag !=  ?",params[:id], $FLAG[:DELETED]])
#		@user=User.find(:first, :conditions=>["id=? and client_id=?",params[:id],session[:client].id])
		@user_access = @user.access_with_company(session[:company])
    return unless request.post?
    @user=User.find(:first, :conditions=>["id=?",params[:id]])
    @user_access = @user.access_with_company(session[:company])
    @user_access.first_name=params[:user_access][:first_name]
    @user_access.last_name=params[:user_access][:last_name]
    @user_access.account_type=params[:user_access][:account_type]
    @user_access.access_level=params[:user_access][:access_level]
    #@user.email=params[:user][:email]
    if @user_access.valid?
    @user_access.save!
    flash[:notice] = "<span> User:#{@user.name} Successfully Updated. </span>"
    redirect_to :action=>'access_control'
    else
      render :action => 'edit_user'
    end
	end
	
	def delete_user
		@user=User.find(:first, :conditions=>["id=?",params[:id]])
		@user_company_access = @user.access_with_company(session[:company])
		@user.update_attributes(:flag=>$FLAG[:DELETED])
		@user_company_access.update_attributes(:flag=>$FLAG[:DELETED])
		flash[:notice] = "<span> User:#{@user.name} Successfully Deleted. </span>"
    redirect_to :action=>'access_control'
	end
	
end
