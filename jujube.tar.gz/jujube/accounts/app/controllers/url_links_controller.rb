class UrlLinksController < ApplicationController
  before_filter :admin_login
  layout "blogs"
  def index
    list
    render :action => 'list'
  end

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  verify :method => :post, :only => [ :destroy, :create, :update ],
         :redirect_to => { :action => :list }

  def list
    @url_link_pages, @url_links = paginate :url_links, :per_page => 10
  end

  def show
    @url_link = UrlLink.find(params[:id])
  end

  def new
    @url_link = UrlLink.new
  end

  def create
    @url_link = UrlLink.new(params[:url_link])
    if @url_link.save
      flash[:notice] = 'UrlLink was successfully created.'
      redirect_to :action => 'list'
    else
      render :action => 'new'
    end
  end

  def edit
    @url_link = UrlLink.find(params[:id])
  end

  def update
    @url_link = UrlLink.find(params[:id])
    if @url_link.update_attributes(params[:url_link])
      flash[:notice] = 'UrlLink was successfully updated.'
      redirect_to :action => 'show', :id => @url_link
    else
      render :action => 'edit'
    end
  end

  def destroy
    UrlLink.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
end
