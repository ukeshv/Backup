module AdminHelper

def user_email(q)
		user = q.user_token.user 
		email = user ? user.email : 'Unknown'
		email
end
	
=begin
 def report_visitors
	@report = {}
	if @from_date.to_date <= @to_date.to_date
		@report[:total_visitors_queries] = NavigationLog.find(:all, :conditions=>["`on` >= ? and `on` <= ?",@from_date,@to_date])
		@report[:total_visitors_count] = @report[:total_visitors_queries].collect{|x| x.user_token}.uniq.length
		@collector_agent[:visitors] = @report[:total_visitors_queries].collect{|x| x.id}
	end
	@report		
 end	
 
 def report_member_visitors
		@report = {}
		if @from_date.to_date <= @to_date.to_date
			@report[:total_member_visitors_queries] = NavigationLog.find(:all, :conditions=>["`on` >= ? and `on` <= ? and user_id <> 0 ",@from_date,@to_date])
			@report[:total_member_visitors_count] = @report[:total_member_visitors_queries].collect{|x| x.user_id}.uniq.length
			
			collections = @report[:total_member_visitors_queries].collect{|x| [x.user_id, x.id, x.user_token] }
			@collector_agent[:member_visitor_user_ids], @collector_agent[:member_visitor_ids], @collector_agent[:member_visitor_tokens] = collections.collect{|x| x[0]}.uniq, collections.collect{|x| x[1]}, collections.collect{|x| x[2]}.uniq
		end
		@report
	end 
	
	def report_non_member_visitors
		@report = {}
		if @from_date.to_date <= @to_date.to_date
			ids = ( @collector_agent[:visitors] - @collector_agent[:member_visitor_ids] )
			@report[:total_non_member_visitors_queries] = NavigationLog.find(:all, :conditions=>["id IN (?) and user_token NOT IN (?) ",ids, @collector_agent[:member_visitor_tokens]] )
			@report[:total_non_member_visitors_count] = @report[:total_non_member_visitors_queries].collect{|x| x.user_token}.uniq.length
    end						
		@report
  end	
	
	def report_new_users
		@report = {}
		if @from_date.to_date <= @to_date.to_date
			@report[:total_new_users_queries] = User.find(:all, :conditions=>["created_at >= ? and created_at <= ?",@from_date,@to_date])
			@report[:total_new_users_count] = @report[:total_new_users_queries].length 
		end
		@report
 end
	
=end

 def report_visitors
	report_member_visitors
	member_visitors=@report[:total_member_visitors_count]
	report_non_member_visitors
	non_member_visitors=@report[:total_non_member_visitors_count]
	@report = {}
	#if @from_date.to_date <= @to_date.to_date
		@report[:total_visitors_count] = member_visitors+ non_member_visitors
	#end
	@report
end	

   def report_member_visitors
		@report = {}
		if @from_date.to_date <= @to_date.to_date
			#@report[:total_member_visitors_count] = UserToken.count(:conditions=>["`updated_at` >= ? and `updated_at` <= ? and user_id <> 0 ",@from_date,@to_date], :group=>"user_id").length
			@report[:total_member_visitors_count] = NavigationLog.count(:all,:conditions=>["visited_on >= ? and visited_on <= ? and user_id <> ?",@from_date,@to_date,0],:group=>'user_token_id').length
		end
		@report
	end


	def report_non_member_visitors
		@report = {}
		@collector_agent = {}
		if @from_date.to_date <= @to_date.to_date
			collection=NavigationLog.find(:all,:select=> "user_token_id", :conditions=>["user_id<>0"])
			#UserToken.find(:all,:conditions=>["user_id=?",0]).length
			#@report[:total_non_member_visitors_count] = UserToken.count(:conditions=>["`updated_at` >= ? and `updated_at` <= ? and user_id = 0 ",@from_date,@to_date])
			@report[:total_non_member_visitors_count] = NavigationLog.count(:all, :conditions=>["visited_on >= ? and visited_on <= ? and user_id = 0 and user_token_id not in (?)", @from_date.to_s, @to_date.to_s, collection])
			
    end						
		@report
  end		
	
	
	def report_new_users
		#@report = {}
		@from_date= @from_date.to_date
		@to_date= @to_date.to_date
		if @from_date <= @to_date
			@member = User.count(:conditions=>["DATE(created_at) >= ? and DATE(created_at) <= ?",@from_date,@to_date])
		end
		#@report
 end
	
 def report_all_member_details
			@member = User.find :all
	end

	def user_navigation_log(user)
		log = []
		if @from_date.to_date <= @to_date.to_date
			u=UserToken.find(:all, :conditions=>["`user_id`= ? and `updated_at` >= ? and `updated_at` <= ?",user, @from_date, @to_date]).collect{|x| x.id}
			log = NavigationLog.find_all_by_user_token_id(u)
		end	
		log
	end

  def query_details(queries)
		res = []
	  res << "<b>Log History : </b><div class='scroll'><table border='2'><tr><td>Remote-ip</td><td>Date</td><td>From-path</td><td>To-action</td><td>User-Email</td><td>User-Browser</td><td>User-cookie</td></tr>"
		 queries.each  do |q| 
			res <<  "<tr>
			 <td>#{q.remote_ip}</td>
			 <td>#{q.on}</td>
			 <td>#{q.from}</td>
			 <td>#{q.jujube_action.name}</td>
			 <td>#{user_email(q)}</td>
			 <td>#{q.user_agent}</td>
			 <td>#{q.user_token}</td>
			</tr>"
		end
		res << "</table></div>"
		res.join
  end


  def user_details(queries)
		res = []
	  res << "<b>Log History : </b><div class='scroll'><table border='2'><tr><td>Email</td><td>FirstName</td><td>LastName</td><td>Phone</td><td>WebSite</td><td>City</td><td>State</td><td>AccountActivatedOn</td></tr>"
		 queries.each  do |q| 
			res <<  "<tr>
			 <td>#{q.email}</td>
			 <td>#{q.first_name}</td>
			 <td>#{q.last_name}</td>
			 <td>#{q.phone}</td>
			 <td>#{q.website}</td>
			 <td>#{q.city}</td>
			 <td>#{q.state}</td>
			 <td>#{q.activated_at}</td>
			</tr>"
		end
		res << "</table></div>"
		res.join
  end

def user_rank(navigation_log)
		 visited_times = navigation_log.collect{|x| x.on.to_date}.uniq.length
		 from_to_days = (params[:to_date].to_date - params[:from_date].to_date).to_i
		 rank = (visited_times.to_f / from_to_days.to_f )*100
		 rank = (rank * 100).round.to_f/100
		 if rank < 40
			grade = 'Poor'
		elsif rank < 60
			grade = 'Good'							 
		elsif rank < 75
			grade = 'V.Good'
		eslif rank < 90
			grade = 'V.V.Good'
		else										
			grade = 'Excellent'
		end			
		 return "<b>(Ranked : #{rank})</b>&nbsp;ActivityLevel: <b>#{grade}</b>. Visited #{visited_times} times in #{from_to_days} days"
end

end
