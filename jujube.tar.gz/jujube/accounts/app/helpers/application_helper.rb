# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  $DEBIT_GROUP=[1,5]
  $CREDIT_GROUP=[2,4]

  
  def pagination_links_remote(paginator, options={})
    update = options.delete(:update)
    action = options.delete(:action)
    str = pagination_links(paginator, options)
    if str != nil
      str = str.gsub(/\?/, "/#{action}?") if(str !~ /#{action}/)
      str.gsub(/href="([^"]*)"/) do
        url = $1
        "href=\"#\" onclick=\"new Ajax.Updater('" + update + "', '" + url +
        "', {asynchronous:true, evalScripts:true}); return false;\"" 
      end
    end
  end 


   def sort_link_helper(text, parameter, options, html_options=nil)
 			key = parameter
			key += " DESC" if params[:sort] == parameter
 			sorting_params=options.clone
			link_to_remote text, {:url=>sorting_params.merge(:sort=>key)}, html_options
		end


  def ajax_will_paginate(collection, parameters, options) #all the ajax will_paginate options should be changed to this one.
    controller=params[:controller].clone
    action=params[:action].clone
    params[:controller]=parameters[:controller]
		params[:action]=parameters[:action]
			pagination_links = will_paginate collection, options
    params[:controller]=controller
		params[:action]=action
    return pagination_links
    
  end
  
  def page_selecter(no_of_pages,options,s_name)
    opt=options.clone
    @select_tag = "<select id='page_selecter' name='page_selecter' onchange='new Ajax.Request(\"#{url_for(options)}#{options[:params].length == 0 ? '?' : '&' }page=\"+this.value, {asynchronous:true, evalScripts:true}); return false;'>"
    page = 1
     no_of_pages.times do
     session_name = s_name.to_s + "page"
      if page.to_i ==  session[:"#{session_name}"].to_i 
        @select_tag += "<option value = #{page} selected='selected'>#{page}</option>"
      else
        @select_tag += "<option value = #{page}>#{page}</option>"
      end
    page += 1
    end
    @select_tag += "</select>"
    return @select_tag
  end

  def page_per_selecter(options,s_name)
     opt=options.clone
    @page_range = [10,25,50,75,100]
    @select_tag = "<select id='page_per_selecter' name='page_per_selecter' onchange='new Ajax.Request(\"#{url_for(options)}#{options[:params].length == 0 ? '?' : '&' }per_page=\"+this.value, {asynchronous:true, evalScripts:true}); return false;'>"
    @page_range.each do |page_range| 
       session_name = s_name.to_s + "per_page"
      if session[:"#{session_name}"].to_i == page_range  
      @select_tag += "<option value = #{page_range} selected='selected'>#{page_range}</option>"
      else  
      @select_tag += "<option value = #{page_range}>#{page_range}</option>"   
      end  
    end
    @select_tag += "</select>"
    return @select_tag
  end

  def find_account_name(id)
    acc = Account.find_by_id(id)
    return acc.name if acc 
  end  

  def find_contact(name)
    contact = Contact.find(:first,:conditions=>["company_name =?",name])
    return contact.id if contact
  end 

  
  def find_opening_balance(id,result)
    balance = []
    for r in result
       unless r.bal.nil?
         if r.account_id.to_i == id
            balance << r.bal.to_i
         end
      end  
    end  
    if balance.empty?
      return 0
    else
      return balance[0]
    end  
  end  
  
  def observe_fields(fields, options={})
    js=""
    fields.each do |field_id|
      js += observe_field(field_id, options)
    end
    js
  end  
  
  def override_class(record,invoice_due_limit=0)
    if record.flag==9
      @action="details"
       return "deleted"
    elsif record.flag==1 and record.transact_type != "PAYROLL_EXPENSE" and record.transact_type == "INVOICE"
      @action="edit_invoice"
      return "draft"
    elsif record.flag==1 and record.transact_type != "PAYROLL_EXPENSE" and record.transact_type == "EXPENSE"
      @action="edit"
      return "draft"  
    elsif record.flag==$FLAG[:DRAFT] and record.transact_type == $CHEQUE
      @action="edit_cheque"
      return "draft"
    elsif record.flag==$FLAG[:PAID] and record.transact_type == $CHEQUE
      @action="cheque_details"
      return "paid"
    elsif record.balance_amount==0 and record.flag==$FLAG[:PAID] and record.transact_type != $PAYROLL_EXPENSE
      @action="details"
      return "paid"
    elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and ((Date.today-record.invoice_date).to_i)<=record.due_limit and record.transact_type=="EXPENSE") 
    	@action="details"
      return "due"
 		elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and ((Date.today-record.invoice_date).to_i)>record.due_limit and record.transact_type == "EXPENSE") 
    	@action="details"
    	return "over_due"  
    elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and ((Date.today-record.invoice_date).to_i)<=invoice_due_limit and record.transact_type == "INVOICE")
    	@action="details"
    	return "due"  
    elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and ((Date.today-record.invoice_date).to_i)>invoice_due_limit and record.transact_type == "INVOICE")
    	@action="details"
    	return "over_due"
    elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and record.transact_type=="PAYROLL_EXPENSE" and (Date.today-record.invoice_date.to_date).to_i <= 0)
        @action="process_payroll"
        @payroll = Payroll.find(:first,:conditions=>["expense_number = ? and flag = ?",record.expense_number,$FLAG[:UNPAID]])
      return "due"
		elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and record.transact_type=="PAYROLL_EXPENSE" and (Date.today-record.invoice_date.to_date).to_i > 0)
        @action="process_payroll"
        @payroll = Payroll.find(:first,:conditions=>["expense_number = ? and flag = ?",record.expense_number,$FLAG[:UNPAID]])
      return "over_due"
    elsif record.transact_type == "PAYROLL_EXPENSE" and record.flag==$FLAG[:PAID]
        @action="process_payroll"
        @payroll = Payroll.find(:first,:conditions=>["expense_number = ? and flag = ?",record.expense_number,$FLAG[:PAID]])
      return "paid"
    else
      @action="details"
      return "edit"
    end    
end

  def find_recurring_details(exp_inv_number,transact_type)
    @recurring_transact=RecurringTransact.find(:first, :conditions=>['recurring_inv_exp_number = ? and recurring_type=?',exp_inv_number,transact_type])
  end
  
  def find_payroll_type(record)
    if (record.flag==2 and (Date.today-record.end_date.to_date).to_i == 0)
      @action="details"
    	return "due"  
    elsif (record.flag==2 and (Date.today-record.end_date.to_date).to_i > 0)
      @action="details"
    	return "over_due"
    elsif (record.flag==2 and (Date.today-record.end_date.to_date).to_i < 0)
      @action=""
    	return "due"  
    elsif (record.flag==0) # veera - check more conditions for security
      @action="details"
      return "paid"
    else
      @action=""
      return "draft"
    end        
  end
  
  def payroll_status_message(record)
    if (record.flag==2 and (Date.today-record.end_date.to_date).to_i == 0)
    	return "Due Today"  
    elsif (record.flag==2 and (Date.today-record.end_date.to_date).to_i > 0)
    	return "Due #{(Date.today - record.end_date.to_date)} days ago"
    elsif (record.flag==2 and (Date.today-record.end_date.to_date).to_i < 0)
    	return "Due in #{(record.end_date.to_date - Date.today)} days"  
    elsif (record.flag==0 and (Date.today <=> record.payment_date.to_date) == 0 )
      return "Paid Today"
    elsif (record.flag==0 and (Date.today <=> record.payment_date.to_date) == 1 )
      return "Paid #{Date.today - record.payment_date.to_date} days ago"
    elsif (record.flag==0 and (Date.today <=> record.payment_date.to_date) == -1 )
      return "Paid in #{record.payment_date.to_date - Date.today.to_date} days"
    else
      return "draft"
    end        
  end
  
  def find_expense_number(id)
    transact = Transact.find(id)
    return transact.expense_number
  end  
  
  def status_details(record,invoice_due_limit=0)
    if record.flag== $FLAG[:DELETED]
      return "<font color='red'>DELETED</font>"
    elsif record.flag== $FLAG[:DRAFT] and (record.transact_type == $INVOICE or record.transact_type == $EXPENSE or record.transact_type=$CHEQUE)
      return "Draft"
		elsif (record.flag==$FLAG[:RECURRING] && record.transact_type == "INVOICE_RECURRING")
      find_recurring_details(record.invoice_number,record.transact_type)
      return "Recursive Per #{@recurring_transact.recurring_range}"  
    elsif (record.flag==$FLAG[:RECURRING] && record.transact_type == "EXPENSE_RECURRING")
      find_recurring_details(record.expense_number,record.transact_type)
      return "Recursive Per #{@recurring_transact.recurring_range}"  
      
		elsif 	(record.flag==$FLAG[:PAID] and record.transact_type == $CHEQUE and (Date.today <=> record.invoice_date.to_date) == 0 )
      return "Paid Today"
 		elsif 	(record.flag==$FLAG[:PAID] and record.transact_type == $CHEQUE and (Date.today <=> record.invoice_date.to_date) == 1 )
      return "Paid #{Date.today - record.invoice_date.to_date} days ago"
 		elsif 	(record.flag==$FLAG[:PAID] and record.transact_type == $CHEQUE and (Date.today <=> record.invoice_date.to_date) == -1 )
      return "Paid in #{record.invoice_date.to_date - Date.today.to_date} days"
  
      
      
    elsif (record.balance_amount==0 and record.flag==$FLAG[:PAID] and (Date.today <=> record.payment_date.to_date) == 0 )
      return "Paid Today"
    elsif (record.balance_amount==0 and record.flag==$FLAG[:PAID] and (Date.today <=> record.payment_date.to_date) == 1 )
      return "Paid #{Date.today - record.payment_date.to_date} days ago"
    elsif (record.balance_amount==0 and record.flag==$FLAG[:PAID] and (Date.today <=> record.payment_date.to_date) == -1 )
      return "Paid in #{record.payment_date.to_date - Date.today.to_date} days"
			
		elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and record.transact_type=="INVOICE" and  (invoice_due_limit-(Date.today - record.invoice_date.to_date)).to_i== 0 )
			return "Due Today"
		elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and record.transact_type=="INVOICE" and ((Date.today-record.invoice_date.to_date).to_i)<=invoice_due_limit)
    	return "Due in #{invoice_due_limit-(Date.today - record.invoice_date.to_date)} days"
		elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and record.transact_type=="INVOICE" and ((Date.today-record.invoice_date.to_date).to_i)>invoice_due_limit)
    	return "Due #{(Date.today - record.invoice_date.to_date)-invoice_due_limit} days ago"  
    
    elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and record.transact_type=="EXPENSE"  and (record.due_limit-(Date.today-record.invoice_date.to_date)).to_i==0)
    	return "Due Today"    
    elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and record.transact_type=="EXPENSE"  and ((Date.today-record.invoice_date.to_date).to_i)<=record.due_limit)
			return "Due in #{record.due_limit-(Date.today - record.invoice_date.to_date)} days"
		elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and record.transact_type=="EXPENSE"  and ((Date.today-record.invoice_date.to_date).to_i) > record.due_limit)
    	return "Due #{(Date.today - record.invoice_date.to_date) - record.due_limit} days ago"
      
    elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and record.transact_type=="PAYROLL_EXPENSE" and (Date.today-record.invoice_date.to_date).to_i < 0)
    	return "Due in #{(record.invoice_date.to_date-Date.today)} days"   
		elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and record.transact_type=="PAYROLL_EXPENSE" and (Date.today-record.invoice_date.to_date).to_i > 0)
    	return "Due #{(Date.today - record.invoice_date.to_date)} days ago"  
		elsif (record.balance_amount!=0 and record.flag==$FLAG[:UNPAID] and  record.transact_type=="PAYROLL_EXPENSE" and  (Date.today - record.invoice_date.to_date).to_i == 0)
			return "Due Today"

    end    
  end
  
  def journal_type_action(journal)
    case journal.journal_type
      when "JOURNAL"
      return("/general/edit_journal/#{journal.journal_number}")
      when "INVOICE"
      return("/invoice/details/#{journal.inv_exp_number}")
      when "EXPENSE"
      return("/expense/details/#{journal.inv_exp_number}")
      when "INVOICE_RECEIVED"
      return("/invoice/details/#{journal.inv_exp_number}")
      when "INVOICE_REVERTED"
      return("/invoice/details/#{journal.inv_exp_number}")
      when "EXPENSE_PAID"
      return("/expense/details/#{journal.inv_exp_number}")
      end
    end
    
    
    def find_journal_type(journal)
       return("JE.##{journal.journal_number}" unless journal.journal_number.blank?)
    end    

   def find_expense_amount_due(number,amount)
      amount_due = amount
      @expense_details = ExpenseDetail.find(:all,:conditions=>["expense_number = ?",number])
      for item in @expense_details
      amount_due = amount_due + item.tax
      end
      return amount_due
    end  
    
    def back_to_default_page
			button_source = "<a title=\"\" href=\"#\" onclick=\"window.location='#{ request.env['HTTP_REFERER']}';return false;\" ><span>Back</span></a>" 
      return button_source
    end
    def cancel_to_default_page
    	if params[:id]
      button_source = "<a title=\"\" href=\"#\" onclick=\"needToConfirm=false; window.location='../back_to';return false;\" ><span>Cancel</span></a>" 
      else
      button_source = "<a title=\"\" href=\"#\" onclick=\"needToConfirm=false; window.location='back_to';return false;\" ><span>Cancel</span></a>" 
      end
      return button_source
    end

    def find_cash_flow
      result = Journal.find_by_sql("SELECT MONTH(journal_date), SUM(debit_amount), SUM(credit_amount),SUM(debit_amount+credit_amount)FROM `journals` WHERE company_id=#{current_company.id} AND account_id=(SELECT id FROM accounts WHERE company_id=#{current_company.id} and alias ='Cash on Hand')AND journal_date>=DATE_ADD(LAST_DAY(DATE_ADD(NOW(), INTERVAL -4 MONTH)), INTERVAL 1 DAY) AND journal_date<=LAST_DAY(DATE_ADD(NOW(),INTERVAL 3 MONTH))GROUP BY journal_date ORDER BY journal_date")
      return result
    end  
    def show_date(input)
      date= input.to_time unless input.nil?
      if date>Time.now
        date=Time.now.strftime("%m/%d/%Y")
        else
          date=date.strftime("%m/%d/%Y")
        end
    end  

    def find_gross_pay(data)
      payroll = Payroll.find(:first,:conditions=>["transact_id = ?",data])
      return payroll unless payroll.nil?      
    end
    
    def find_net_pay(data,id)
       amount = []
       if data.transact_type.scan(/\d+/)==id
         amount << data.expense_detail.price
         return amount.first
         
       else  
         result = ExpenseDetail.find(:first,:conditions=>["expense_number = ? and transact_id = ? ",data.expense_number,data.id])
         return result.price
         
       end
     end  
     
     def find_employee_name(id)
       employee = Employee.find(id)
       return employee.name
     end  
     
  def find_logo(id)
  logo=CompanyDetails.find(:first,:conditions=>["attachable_type ='Company' and attachable_id = ?",id])
  return logo
end  
def display_logo(id)
    if current_company.logo_display_flag==false and ( controller != "settings" and controller.action_name != "my_company")
      return nil
   else
      file = CompanyDetails.find(:first,:conditions=>["attachable_type ='Company' and attachable_id = ?",id])
      if file 
         return "<img src=\"/images/company_logo/#{file.id}/#{file.filename}\" border=\"0\" >"  
      else
        return "<img src=\"/images/logo_beta.gif\">"
      end  
    end   
end

def find_cash_in(month)
 from_date = Date.today.year.to_s + "-" + month.to_s + "-" + "1"
 to_date = from_date.to_time.months_since(1).yesterday.to_s(:db)
 journals = Journal.find(:all,:conditions=>["journal_date between ? and ? and flag != 9 and journal_type='INVOICE_RECEIVED'",from_date,to_date])
 total = journals.inject(0) { |a, v| a += v.debit_amount.to_f } 
 return total
end
def find_cash_out(month)
 from_date = Date.today.year.to_s + "-" + month.to_s + "-"+"1"
 to_date = from_date.to_time.months_since(1).yesterday.to_s(:db)
 journals = Journal.find(:all,:conditions=>["journal_date between ? and ? and flag != 9 and journal_type in (?)",from_date,to_date,["PAYROLL_EXPENSE_PAID","EXPENSE_PAID"]])
 total = journals.inject(0) { |a, v| a += v.credit_amount.to_f } 
 return total

end

def find_access_level
  result = UserAccess.find(:first,:conditions=>["company_id = ? and user_id =?",current_company.id,current_user.id])
  return result.access_level unless result.nil?
end  

def find_access_type
  result = UserAccess.find(:first,:conditions=>["company_id = ? and user_id =?",current_company.id,current_user.id])
  return result.account_type unless result.nil?
end  


def find_total_amount(id,type)
  total = 0
   if type==$EXPENSE or type==$INVOICE
    expense_details = ExpenseDetail.find(:all,:conditions=>["company_id = ? and expense_number = ?",current_company.id,id])
    for expense_detail in expense_details
      if expense_detail.transact and ( expense_detail.transact.transact_type == "EXPENSE" or expense_detail.transact.transact_type=="INVOICE" )
        total = total + (expense_detail.price * expense_detail.quantity) + expense_detail.tax  
      end
    end
    return total unless total.nil?
  elsif type==$CHEQUE
    transact = Transact.find(:first,:conditions=>["expense_number = ? and debit_amount=0 and transact_type=?",id,$CHEQUE])  
    return transact.credit_amount unless transact.nil?
  elsif type=="PAYROLL_EXPENSE"
    transact = Transact.find(:first,:conditions=>["expense_number = ? and debit_amount=0 and transact_type=?",id,"PAYROLL_EXPENSE"])
    return transact.credit_amount unless transact.nil?
  else
    return 0
end
    
end  

def find_user_name(id)
  user = User.find_by_id(id)
  if current_user==user
    return user.name
  else
    user_access=user.access_with_company(session[:company])
    return user_access.first_name.to_s + " " +user_access.last_name.to_s    # from usr_access table or user table
  end  
end

def find_income_statement_balance(account_id,date)
  journals = Journal.find(:all,:conditions=>["account_id =? and journal_date <= ?",account_id,date])
  account = Account.find(account_id)
  debit_total = 0
  credit_total = 0
  closing_balance = 0
  for journal in journals
   if journal.debit_amount == 0
     credit_total = credit_total + journal.credit_amount
   elsif journal.credit_amount == 0
     debit_total = debit_total + journal.debit_amount
   end 
 end 
 unless journals.length == 0
 closing_balance = account.closing_balance + debit_total - credit_total
  end
 return closing_balance
end

  def find_contact_legend(legend)
		case legend
			when "CL"
				return "<IMG SRC=\"/images/icon-client.gif\">"
			when "VE"
				return "<IMG SRC=\"/images/icon-vendor.gif\">"
			when "CV"
				return "<IMG SRC=\"/images/icon-client.gif\"><IMG SRC=\"/images/icon-vendor.gif\">"
			else
				return "<IMG SRC=\"/images/icon-contacts2.gif\">"
		end
	end
  
    def formatted_number(number)
    length=number.to_s.length
    if length>5
      return number
    else
      padded_number='0' * (5-length)  +number.to_s  
    end
  end
  
  def get_total_remittance_payment(cpp,ei,fd,pt)
    total_cpp = cpp.to_f+cpp.to_f
    total_ei = ei.to_f+(ei.to_f * 1.4)
    total_tax = pt.to_f+fd.to_f
    total_amount=total_cpp.to_f+total_ei.to_f+total_tax.to_f
  end
  
  def i_s_year_list
      start_year = current_company.year_end_date.to_time.advance(:years=>-1, :days=>1).year
      end_year = Time.now.year
      result = []
      return result if start_year > end_year
      (start_year..end_year).each{|x|
          result << [x,x]
      }
      @default_year = end_year
      result
  end
  
  def i_s_month_list
      result = []
      months_since_start = current_company.year_end_date.to_time.advance(:years=>-1, :days=>1) < Time.now
      return result if months_since_start==false
      result = [["January",1], ["February",2], ["March",3], ["April",4], ["May",5], ["June",6], ["July",7], ["August",8], ["September",9], ["October",10], ["November",11], ["December",12]]
      @default_month = Time.now.month
      result
  end


end
