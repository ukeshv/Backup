module GeneralHelper
end
