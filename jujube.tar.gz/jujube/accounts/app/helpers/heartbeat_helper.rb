module HeartbeatHelper
end
