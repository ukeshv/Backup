module SettingsHelper

def marking
	return "<font color='red'> *</font>"
end

end
