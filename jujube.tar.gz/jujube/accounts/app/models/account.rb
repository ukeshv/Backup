class Account < ActiveRecord::Base
  has_many :journals
  belongs_to :group
  has_many :transacts
  #belongs_to :user
  acts_as_scoped :company,:find_with_nil_scope=>true
  
  def self.update_counters(id, counters)
  updates = counters.inject([]) { |list, (counter_name, increment)|
    sign = increment < 0 ? "-" : "+"
    list << "#{connection.quote_column_name(counter_name)} = #{connection.quote_column_name(counter_name)} #{sign} #{increment.abs}"
  }.join(", ")
  update_all(updates, "#{connection.quote_column_name(primary_key)} = #{quote_value(id)}")
end

end
