class Blog < ActiveRecord::Base
  has_one :category
  acts_as_versioned
  validates_presence_of :title,:message=>"Please enter the Title"
  validates_presence_of :content,:message=>"Please enter the content"
  #Blog.create_versioned_table
end
