class Category < ActiveRecord::Base
  belongs_to :blog
  validates_presence_of :name,:message=>"Please enter the category name"
end
