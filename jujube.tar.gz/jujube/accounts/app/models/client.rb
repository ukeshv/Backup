class Client < ActiveRecord::Base
  has_many :users
  has_many :companies
  validates_length_of       :email,    :within => 3..100
  validates_uniqueness_of :email, :case_sensitive => false
end
