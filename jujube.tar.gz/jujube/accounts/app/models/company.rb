class Company < ActiveRecord::Base
  cattr_accessor :current # for acts as scoped
#  belongs_to :client, :dependent => :destroy
  #validates_presence_of :name,:message=>" - Please Enter the Company Name"

  has_many :accounts, :dependent => :destroy
  has_many :contacts, :dependent => :destroy
  has_many :employees, :dependent => :destroy
  has_many :expense_details, :dependent => :destroy
  has_many :invoice_details, :dependent => :destroy
  has_many :transacts, :dependent => :destroy
  has_many :journals, :dependent => :destroy
  has_many :payrolls, :dependent => :destroy
  belongs_to :owner, :class_name=>'User', :foreign_key=>'user_id'

  #has_many users through association.
  has_many :user_accesses, :foreign_key=>:company_id, :dependent => :destroy
  has_many :authorized_users, :through=>:user_accesses, :source=>'user', :class_name=>'User', :foreign_key=>:company_id, :dependent => :destroy
  #has_many :owners, :through=>:user_accesses, :source=>:user, :conditions=>["user_accesses.is_owner=true"] #this is some what duplicate association not used in application.

  belongs_to :attachable, :polymorphic => true
  has_one :company_details, :as=>:attachable, :dependent => :destroy

  after_create :load_root_account

	validates_uniqueness_of   :name, :scope => [:user_id], :message=>"This company name is already used. Please use a different name for your new company."

  # It will load required default accounts for a company.
  def load_root_account
    Company.current=self
    @root_account = RootAccount.find(:all)
    for root_account in @root_account
      @user_account = Account.create!(:group_id=> root_account.group_id,:number=>root_account.number, :name=>root_account.name,:alias=>root_account.name,:description=>root_account.description, :editable=> root_account.editable)
    end
  end

  def escaped_name
    self.name.to_s.gsub("'","&rsquo;")
  end

  #def owner
   # self.owners.first
  #end

end
