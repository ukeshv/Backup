class CompanyDetails < ActiveRecord::Base
  #acts_as_attachment
  acts_as_attachment :storage => :file_system, :content_type => ['image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png'],:file_system_path => 'public/images/company_logo'
  belongs_to :attachable, :polymorphic => true
  validates_as_attachment
end
