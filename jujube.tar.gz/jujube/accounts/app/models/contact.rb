class Contact < ActiveRecord::Base
  #validates_presence_of     :email ,:message=>"Please Enter the valid Email Id"
  #validates_presence_of     :first_name,:message=>"Please Enter Your First Name"
  validates_presence_of  :company_name,:message=>"You must enter a company name"
  #validates_uniqueness_of  :email, :scope => [:company_id], :message=>"has already taken"
  #validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i , :message=>"Invalid Email format"  
  validates_uniqueness_of  :company_name,  :scope => [:company_id], :message=>"has already taken"
  #belongs_to :user
  acts_as_scoped :company,:find_with_nil_scope=>true
  after_create :store_ledger_id
  
def store_ledger_id
  if contact_type == "client" or contact_type == "cv"
    account_group = Account.find(:first,:conditions=>["alias = 'Accounts Receivable'"])
  else  
    account_group = Account.find(:first,:conditions=>["alias = 'Accounts Payable'"])
  end    
    @account = Account.create(:group_id=>account_group.id,:number=>"",:name=>company_name,:alias=>"",:opening_balance=>0,:description=>"",:editable=>1,:source_account=>"contact")
    update_attributes(:account_id=>@account.id)
end  
  
end
