class Country < ActiveRecord::Base
	has_many :province
end
