class CreditcardDetail < ActiveRecord::Base
  belongs_to :user
  validates_presence_of :creditcard_number, :message => " - Please Enter Card number"
  validates_presence_of :creditcard_name, :message => " - Please Select Card"
  validates_presence_of :expiration_month,  :message => " - Please select the Month"
  validates_presence_of :expiration_year, :message => " - Please Select the Year"
  validates_presence_of :verification_number,  :message => " - Please Enter Verification number"
  #before_save :encrypt_credit
  #after_validation_on_create :encrypt_credit

  def encrypt_credit
    self.creditcard_number  = ez_key.encrypt(creditcard_number.to_s)
  end
  
  def ez_key
    @ez_key ||= EzCrypto::Key.with_password "password", "jujube"
  end
  
  def decrypt_credit(val)
    return ez_key.decrypt(val)
  end

end
