class Employee < ActiveRecord::Base
  #validates_presence_of     :email ,:message=>"Please Enter the valid Email Id"
  #attr_accessor :name
  validates_presence_of     :employee_id 
  validates_presence_of     :first_name,:message=>"You must enter the Employee's First Name"
  validates_presence_of     :last_name,:message=>"You must enter the Employee's Last Name"
  validates_uniqueness_of  :first_name, :scope => [:last_name],:message=>"This Name has already been taken"
  #validates_uniqueness_of  :first_name :last_name,  :scope => [:user_id]
  #validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i , :message=>"Invalid Email format"  
  after_create :store_ledger_id
  #belongs_to :user
  acts_as_scoped :company,:find_with_nil_scope=>true
  
def store_ledger_id
    group_id = Account.find(:first,:conditions=>["company_id = ? and name = 'Accounts Payable'",company_id])
    @account = Account.create(:group_id=>group_id.id,:company_id=>company_id,:number=>"",:name=>first_name + " " + last_name,:opening_balance=>0,:description=>"",:editable=>1,:source_account=>"employee")
    update_attributes(:account_id=>@account.id)
end  

def name
"#{first_name} #{last_name}"
end

  def date
    return created_at.strftime("%m/%d/%Y") unless created_at.nil?
  end
  
  def update_payroll(options=nil)
    payroll_initialize(options[:hidden_account_id])
    @payroll = Payroll.find(:first,:conditions=>["id = ? and flag=?",options[:id],$FLAG[:UNPAID]])
    @payroll_transact = Transact.find(:first,:conditions=>["expense_number = ? and transact_type = ? and debit_amount = 0 and flag=?",@payroll.expense_number,$PAYROLL_EXPENSE,$FLAG[:UNPAID]])
    @expense_number = @payroll_transact.expense_number
    @journal_number = Jujube.get_journal_number
    payroll_journal_entry(options)
 
  end
  
  def payroll_initialize(paid_account_id) 
    @payroll_expense_EI_credit = Account.find :first,:conditions=>["alias='EI Payable'"]                   #cr
    @payroll_expense_CPP_credit = Account.find :first,:conditions=>["alias='CPP Payable'"]              #cr
    #@payroll_expense_Chequing_credit = Account.find :first,:conditions=>["alias='Chequing Bank Account'"]
    @payroll_expense_paid_credit = Account.find :first,:conditions=>["id=?",paid_account_id]
    @payroll_expense_FIT_credit = Account.find :first,:conditions=>["alias='Income Tax Payable'"]    #cr 
    @payroll_expense_wage_debit = Account.find :first,:conditions=>["alias='Wages & Salaries'"]      #dr
    @payroll_expense_ei_debit = Account.find :first,:conditions=>["alias='EI Expense'"]                      #dr
    @payroll_expense_cpp_debit = Account.find :first,:conditions=>["alias='CPP Expense'"]                 #dr
    @payroll_expense_penalty = Account.find :first,:conditions=>["alias='Penalties'"]
    @acc_pay = Account.find :first, :conditions=>["alias='Accounts Payable'"]
    @payroll_pay = Account.find :first, :conditions=>["alias='Payroll Payable'"]                              #cr
  end
  
  def payroll_journal_entry(options)
    cheque_number=options[:hidden_cheque_number]
    payment_date=options[:hidden_payment_date]
    payment_type= options[:hidden_payment_type]
    @payroll_expense_paid_credit.update_attributes(:closing_balance=> @payroll_expense_paid_credit.closing_balance - @payroll.net_pay)
    @payroll_pay.update_attributes(:closing_balance=> @payroll_pay.closing_balance - @payroll.net_pay)
     Journal.create!( :inv_exp_number=>@expense_number, :journal_type=>$PAYROLL_EXPENSE_PAID, :journal_number=>@journal_number,:account_id=>@payroll_pay.id,:debit_amount=>@payroll.net_pay, :credit_amount=>0,:cheque_number=>cheque_number,:journal_date=>payment_date,:flag=>$FLAG[:PAID])        
     Journal.create!( :inv_exp_number=>@expense_number, :journal_type=>$PAYROLL_EXPENSE_PAID, :journal_number=>@journal_number,:account_id=>@payroll_expense_paid_credit.id,:debit_amount=>0, :credit_amount=>@payroll.net_pay,:cheque_number=>cheque_number,:journal_date=>payment_date,:flag=>$FLAG[:PAID])
    @payroll_transact.update_attributes(:balance_amount=>0,:flag=>$FLAG[:PAID], :payment_date=>payment_date, :cheque_number=>cheque_number,:payment_type=>payment_type)
    @payroll.update_attributes(:flag=>$FLAG[:PAID], :payment_date=>payment_date, :cheque_number=>cheque_number,:payment_type=>payment_type)
  end       

  def status
    @status = self.deleted_by.nil? ? false : true
  end
  
    
end
