class EntryStatusLog < ActiveRecord::Base
	acts_as_scoped :company,:find_with_nil_scope=>false
end
