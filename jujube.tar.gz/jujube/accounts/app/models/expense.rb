class Expense < ActiveRecord::Base
  attr_reader :user, :options
  attr_accessor :next_action 
  
  def common_initialize
    @acc_pay,@acc_pay_list,@expense_tax_account = Jujube.expense_common_initialize
    @creditcard_payable_account=Account.find :first, :conditions=>["alias='Credit Card Payable'"]
  end
  
    def self.check_gst_expense
    Company.current = nil
    @companies = Company.find(:all)
    for company in @companies
    Company.current = company
    accounts = Account.find(:first,:conditions=>["name like ?","%GST (HST) expense%"])
    if accounts.blank? 
       @user_account = Account.create!(:group_id=>15 ,:number=>5430, :name=>"GST (HST) expense",:alias=>"GST (HST) expense",:description=>'', :editable=> 1)
    end
    end
  end  

  def initialize
      # this for later usage.
  end
  
  def get_params_details(options)
    @quantities = options[:quantity].values
    @units = options[:unit].values
    @descriptions = options[:description].values
    @taxes = options[:tax].values
    @amounts = options[:amount].values
    @products = options[:product].values
    @expense_item_account_ids = options[:account_number].values
    @total_expense_items = options[:amount].values.length
    @invoice_number = options[:invoice][:number]
    @invoice_date = options[:transact][:invoice_date]
    @due_limit=options[:transact][:due_limit].to_i
    @purchase_account_id = options[:transact][:account_id]
    @total_amount = @products.inject(0) { |a, v| a += v.to_f }   
    @total_tax = @taxes.inject(0) { |a, v| a += v.to_f }   
    @total = @total_amount.to_f+@total_tax.to_f
    @flag = options[:flag] ? options[:flag].to_i : $FLAG[:PAID] # 0 - direct paid expense, 1 - unpaid expense ( saved expense ), 3 - Recurring expesne
    @purchase_account_balance=@flag== $FLAG[:PAID] ? 0 : @total*(-1)
    @expense_number = @flag==$FLAG[:RECURRING] ? Jujube.get_recurring_expense_number : Jujube.get_expense_number
    @journal_number = Jujube.get_journal_number
    @expense_flag_array = @flag == $FLAG[:RECURRING] ? [$FLAG[:RECURRING]] : [$FLAG[:UNPAID],$FLAG[:DRAFT]] #1-drafted invoice, 2-ordinary invoice(Saved invoice), 3-Recurring Invoice.
    @flag==$FLAG[:RECURRING] ? (@transact_type =$EXPENSE_RECURRING;@source_type=$EXPENSE_CRON) : (@transact_type=$EXPENSE;@source_type=$EXPENSE)
    if @flag==$FLAG[:RECURRING] and options[:recurring]
      @recurring_params = {}
      @recurring_params[:patern]=options[:recurring][:patern]
      @recurring_params[:weekly_day]=options[:recurring][:weekly_day]
      @recurring_params[:monthly_day]=options[:recurring][:monthly_day]
      @recurring_params[:yearly_day]=options[:recurring][:yearly_day]
      @recurring_params[:yearly_month]=options[:recurring][:yearly_month]
      @recurring_params[:start_date]=options[:recurring][:start_date]
      @recurring_params[:end_date]=options[:recurring][:end_date]
      @recurring_params[:no_of_occurences]=options[:recurring][:no_of_occurences]
      @recurring_params[:end_option]=options[:recurring][:end_option]
    end
  end
  
  def save(options=nil,user_id=nil,company_id=nil)
    common_initialize
    get_params_details(options)
    create_expense(options,user_id,company_id)
  end
  
  def save_cheque(options=nil,user_id=nil,company_id=nil)
    common_initialize
    get_cheque_details(options)
    create_cheque(options,user_id,company_id)
  end
  
    def get_cheque_details(options)
    @account_number = options[:cheque][:account_number]
    @cheque_number = options[:cheque][:number]
    @invoice_date = options[:cheque][:date]
    @comment = options[:cheque][:comment]
    @amount = options[:cheque][:amount]
    @flag = options[:flag]
    @purchase_account_id = options[:transact][:account_id]
    @journal_number = Jujube.get_journal_number
    @expense_number= Jujube.get_expense_number
  end


  def create_expense(options,user_id,company_id)
    if options[:flag].to_i == $FLAG[:PAID]   # forcing to act as unpaid first, when one click paid exp should be created. Then this exp will be automatically paid (see following lines)
      @forcing_direct_pay_as_2_steps = true 
      @purchase_account_balance= @total*(-1)   # applied force to tally calculations when one click exp create/paid
      options[:flag] = @flag = $FLAG[:UNPAID]  
    end  
    expense_transact_entry(user_id,company_id)
   @next_action="/expense/list" 
  #@expense_number = @flag==3 ? Jujube.get_recurring_expense_number : Jujube.get_expense_number
  if @flag==$FLAG[:RECURRING] #recurring    
    recurring_transacts_entry(company_id)
    @next_action="/expense/list"
  elsif @flag==$FLAG[:PAID] or @forcing_direct_pay_as_2_steps #paid_exp  
    #Here all are hidden field values are passed to get the redbox value in redbox.
    #directly_paid_expense_journal_entry(options[:hidden_account_id],options[:hidden_cheque_number],options[:hidden_payment_date], options[:hidden_payment_type])
    expense_journal_entry
    pay_expense(options,user_id,company_id)
    @next_action="/expense/list"
  elsif @flag==$FLAG[:UNPAID] #unpaid_exp     
    expense_journal_entry
    @next_action="/expense/list"
  end
  return true
  end

  def create_cheque(options,user_id,company_id)
    cheque_transact_entry(user_id,company_id)
    if @flag==$FLAG[:PAID]    
      directly_paid_cheque_journal_entry(@account_number,@cheque_number)
    elsif @flag==$FLAG[:UNPAID]      
      cheque_journal_entry
    end
    @next_action="/expense/list"
    return true   
  end

  def update_expense(options,user_id,company_id)
    common_initialize
    get_params_details(options)
    @expense_number=options[:id]
    @source_type=options[:source_type]
    delete_previous_expense(options)
    create_expense(options,user_id,company_id)
  end
  
  def update_cheque(options,user_id,company_id)
    common_initialize
    get_cheque_details(options)
    #@cheque_number=options[:id]
    @expense_number=options[:id]
    delete_previous_cheque(options)
    create_cheque(options,user_id,company_id)
  end

  def pay_expense(options,user_id,company_id)
  common_initialize
  @expense_number = options[:id]
  @next_action="/invoice/list"
  paid_expense_journal_entry(options[:hidden_account_id],options[:hidden_cheque_number],options[:hidden_payment_date], options[:hidden_payment_type])
  @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:transact_id=>@transact_credit.id,:entry_id=>@transact_credit.id,:entry_number=>@expense_number,:entry_type=>$ENTRY[:EXPENSE],:action=> $LOG_ACTION[:PAY])    
  end
  
  # transact entry for all.
    def expense_transact_entry(user_id,company_id)
    if @flag == $FLAG[:DRAFT]
      action=  $LOG_ACTION[:DRAFT]
    elsif @flag == $FLAG[:UNPAID]
      action =  $LOG_ACTION[:PROCESS]
    elsif @flag == $FLAG[:PAID]
      action =  $LOG_ACTION[:PAY]
    else
      action= $LOG_ACTION[:CREATE]
    end      
    @transact=Transact.create!(:transact_type=>@transact_type, :invoice_date=>@deleted_date || @invoice_date, :due_limit=>@due_limit, :account_id=>@purchase_account_id, :debit_amount=>0, :credit_amount=>@total, :balance_amount=>@purchase_account_balance, :invoice_number=>@invoice_number, :expense_number=>@expense_number, :flag=>@flag,:source=>@source_type)
    @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:transact_id=>@transact.id,:entry_id=>@transact.id,:entry_number=>@expense_number,:entry_type=>$ENTRY[:EXPENSE],:action=>action)      
    if @flag !=$FLAG[:RECURRING] 
    @account=Account.find(@purchase_account_id)
    @account.update_attributes(:closing_balance => @account.closing_balance+@total)
    end
    i=0
    while i < @total_expense_items.to_i
      tax_amount = @taxes[i]=="" ? 0  : @taxes[i]
      total_amount=tax_amount.to_f+@products[i].to_f
      #@account=Account.find(@expense_item_account_ids[i])
      @transact=Transact.create!(:transact_type=>@transact_type, :invoice_date=>@invoice_date, :due_limit=>@due_limit, :account_id=>@expense_item_account_ids[i], :debit_amount=>total_amount, :credit_amount=>0, :balance_amount=>@total, :invoice_number=>@invoice_number, :expense_number=>@expense_number, :flag=>@flag,:source=>@source_type)
      @expense_details=ExpenseDetail.create!(:transact_id=>@transact.id, :item_number=>i+1, :expense_number=>@expense_number, :quantity=> @quantities[i], :unit=>@units[i], :description=>@descriptions[i], :price=>@amounts[i], :tax=>tax_amount)
      i+=1
    end
    end
    
  def cheque_transact_entry(user_id,company_id)
    @transact=Transact.create!(:transact_type=>$CHEQUE, :invoice_date=>@invoice_date, :account_id=>@purchase_account_id, :debit_amount=>0, :credit_amount=>@amount, :balance_amount=>@amount, :invoice_number=>'', :expense_number=>@expense_number, :flag=>@flag,:source=>$PAYMENT_TYPE["CHEQUE"],:comment=>@comment,:payment_type=>$PAYMENT_TYPE["CHEQUE"],:cheque_number=>@cheque_number)
    @transact=Transact.create!(:transact_type=>$CHEQUE, :invoice_date=>@invoice_date, :account_id=>@account_number, :debit_amount=>@amount, :credit_amount=>0, :balance_amount=>@amount, :invoice_number=>'', :expense_number=>@expense_number, :flag=>@flag,:source=>$PAYMENT_TYPE["CHEQUE"],:comment=>@comment,:payment_type=>$PAYMENT_TYPE["CHEQUE"],:cheque_number=>@cheque_number)
    @account=Account.find(@purchase_account_id)
    @account.update_attributes(:closing_balance => @account.closing_balance+@amount.to_f)
  end

    def recurring_transacts_entry(company_id)
      store_recurring_requirement
     @recurring_intial_date=@recurring_transact.recurring_date
      case  @recurring_params[:end_option]
      when 'no_end'
          financial_end = Company.find(company_id).year_end_date.to_date
          @recurring_transact.create_expense_entry while ((@recurring_transact.recurring_date <=> financial_end) ==  -1)
      when 'countable_recurrence'
         (1..@recurring_params[:no_of_occurences].to_i).each{@recurring_transact.create_expense_entry}
      when 'end_by_date'
          @recurring_transact.create_expense_entry  while ((@recurring_transact.recurring_date <=> @recurring_params[:end_date].to_date) ==  -1)
      end             
  end
  
    
    def store_recurring_requirement
      case @recurring_params[:patern] 
            when 'daily'
                 @day = 0
                  next_recurrence=@recurring_params[:start_date].to_date
            when 'weekly'
                 @day = @recurring_params[:weekly_day]
                  next_recurrence=@recurring_params[:start_date].to_time.monday.to_date+@recurring_params[:weekly_day].to_i
                  next_recurrence+=7  while next_recurrence < @recurring_params[:start_date].to_date
            when 'monthly'
                 @day = @recurring_params[:monthly_day]
                 day=@recurring_params[:monthly_day].to_i
                 begin
                    next_recurrence="#{day}-#{@recurring_params[:start_date].to_date.month}-#{@recurring_params[:start_date].to_date.year}".to_date
                    if next_recurrence < @recurring_params[:start_date].to_date
                         next_recurrence=next_recurrence.to_time.advance({:months=>1}).to_date 
                         count=0
                      begin
                         next_recurrence = "#{day-count}-#{next_recurrence.month}-#{next_recurrence.year}".to_date
                      rescue
                        count+=1
                      end
                    end  
                 rescue
                    day=day.to_i-1
                    retry
                end
            when 'yearly'
                  day = @recurring_params[:yearly_day].to_i
                  month = Date::MONTHNAMES.index(@recurring_params[:yearly_month])
                 @day = "#{convert_recurrence_year_to_day( month ,day )}"
                 if month==2 and [29,30,31].include?(day)
                      next_recurrence = "01-03-#{@recurring_params[:start_date].to_date.year}".to_date - 1
                      next_recurrence = "01-03-#{@recurring_params[:start_date].to_date.year+1}".to_date - 1 if next_recurrence < @recurring_params[:start_date].to_date
                 else  
                      next_recurrence = "#{day}-#{month}-#{@recurring_params[:start_date].to_date.year}".to_date
                      next_recurrence=next_recurrence.to_time.advance({:years=>1}).to_date if next_recurrence < @recurring_params[:start_date].to_date
                end                 
      end
      case  @recurring_params[:end_option]
             when 'no_end'
                 @recurring_params[:no_of_occurences]=nil
                 @recurring_params[:end_date]=nil
             when 'countable_recurrence'
                 @recurring_params[:end_date]=nil
             when 'end_by_date'
                 @recurring_params[:no_of_occurences]=nil
      end             
       @recurring_transact=RecurringTransact.create!(:recurring_inv_exp_number=>@expense_number,:recurring_type=>@transact_type, :recurring_date=>next_recurrence, :recurring_start_date=>@recurring_params[:start_date],:recurring_range=>@recurring_params[:patern],:recurring_day=>@day, :recurring_end_date=>@recurring_params[:end_date], :recurring_count=>@recurring_params[:no_of_occurences])
   end
  
  
  # days stored in table is calculated as if the user's inputs belongs to year 2000. 1.e leap year. This is just to simplyfy calculation. restoring is done in recurring_transaction.rb
   def convert_recurrence_year_to_day(month,day)
     day=29 if month==2 and [29,30,31].include?(day)
     ("#{day.to_s}-#{month.to_s}-2000".to_date - "01-01-2000".to_date).to_i
   end
   
  
    # Journal Entry for expenses & Account Updation.
    def expense_journal_entry
      @journal=Journal.create!( :inv_exp_number=>@expense_number, :journal_type=>@transact_type, :journal_number=>@journal_number,:account_id=>@acc_pay.id,:debit_amount=>0, :credit_amount=>@total,:journal_date=>@invoice_date, :flag=>@flag)
    @acc_pay.update_attributes(:closing_balance=>@acc_pay.closing_balance+@total)
    i=0
    while i < @total_expense_items.to_i
      tax_amount = @taxes[i]=="" ? 0  : @taxes[i]
      total_amount=tax_amount.to_f+@products[i].to_f
      @account=Account.find(@expense_item_account_ids[i])
      @journal=Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>@transact_type, :journal_number=>@journal_number,:account_id=>@expense_item_account_ids[i],:debit_amount=>@products[i], :credit_amount=>0,:journal_date=>@invoice_date, :flag=>@flag)
      @account.update_attributes(:closing_balance=>@account.closing_balance.to_f+@products[i].to_f)
      i+=1
    end
      @journal=Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>@transact_type, :journal_number=>@journal_number,:account_id=>@expense_tax_account.id,:debit_amount=>@total_tax, :credit_amount=>0,:journal_date=>@invoice_date, :flag=>@flag)
      @expense_tax_account.update_attributes(:closing_balance=>(@expense_tax_account.closing_balance-@total_tax))
    end
    
    def cheque_journal_entry
      @journal=Journal.create!( :inv_exp_number=>@expense_number, :journal_type=>$CHEQUE, :journal_number=>@journal_number,:account_id=>@acc_pay.id,:debit_amount=>0, :credit_amount=>@amount,:journal_date=>@invoice_date, :flag=>@flag,:cheque_number=>@cheque_number)
      @journal=Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>$CHEQUE, :journal_number=>@journal_number,:account_id=>@account_number,:debit_amount=>@amount, :credit_amount=>0,:journal_date=>@invoice_date, :flag=>@flag,:cheque_number=>@cheque_number)
      @acc_pay.update_attributes(:closing_balance=>@acc_pay.closing_balance+@amount)
      @account=Account.find(@account_number)
      @account.update_attributes(:closing_balance=>@account.closing_balance.to_f+@amount.to_f)
    end

    
    def paid_expense_journal_entry(paid_to_account,cheque_number,payment_date,payment_type)
    @transact_debit = Transact.find(:all,:conditions=>["expense_number = ? and transact_type = ? and credit_amount = 0 and flag = ?" ,@expense_number,$EXPENSE, $FLAG[:UNPAID]])
    @transact_credit = Transact.find(:first,:conditions=>["expense_number = ? and transact_type = ? and debit_amount = 0 and flag = ?" ,@expense_number,$EXPENSE,$FLAG[:UNPAID]])
    @journal_number = Jujube.get_journal_number
    @paid_by_account=Account.find(paid_to_account)
    #@expensedetails=ExpenseDetail.find(:all,:conditions=>["transact_id in (?)",@transact_debit.collect{|x| x.id}])
    #@total_amount = @expensedetails.inject(0) { |a, v| a += v.price.to_f * v.quantity.to_f }
    @journal=Journal.create!(:journal_type=>$EXPENSE_PAID,:inv_exp_number=>@transact_credit.expense_number,:journal_number=>@journal_number,:account_id=>@paid_by_account.id,:credit_amount=>@transact_credit.credit_amount,:debit_amount=>0,:cheque_number=>cheque_number,:journal_date=>payment_date,:flag=>$FLAG[:PAID])
    @journal=Journal.create!(:journal_type=>$EXPENSE_PAID,:inv_exp_number=>@transact_credit.expense_number,:journal_number=>@journal_number,:account_id=>@acc_pay.id,:credit_amount=>0,:debit_amount=>@transact_credit.credit_amount,:cheque_number=>cheque_number,:journal_date=>payment_date,:flag=>$FLAG[:PAID])
    if $DEBIT_GROUP.include?(@paid_by_account.group.parent.id)
      @paid_by_account.update_attributes(:closing_balance=>@paid_by_account.closing_balance-@transact_credit.credit_amount)
    else  
      @paid_by_account.update_attributes(:closing_balance=>@paid_by_account.closing_balance+@transact_credit.credit_amount)
    end
    @acc_pay.update_attributes(:closing_balance=>@acc_pay.closing_balance-@transact_credit.credit_amount)
    @transact_credit.update_attributes(:balance_amount=>@transact_credit.balance_amount+@transact_credit.credit_amount,:flag=>$FLAG[:PAID], :payment_date=>payment_date, :cheque_number=>cheque_number,:payment_type=>payment_type)
    Transact.update_all("flag=#{$FLAG[:PAID]},payment_date='#{payment_date.to_date}', cheque_number='#{cheque_number}', payment_type='#{payment_type}'","expense_number = #{@expense_number} and transact_type = '#{$EXPENSE}' and flag=#{$FLAG[:UNPAID]}")
  end
  
  
  def directly_paid_expense_journal_entry(paid_to_account,cheque_number,payment_date,payment_type)
#directly paid expense
    @paid_by_account=Account.find(paid_to_account)
    @journal=Journal.create!(:journal_type=>$EXPENSE_PAID,:inv_exp_number=>@expense_number,:journal_number=>@journal_number,:account_id=>@paid_by_account.id,:credit_amount=>@total,:debit_amount=>0,:cheque_number=>cheque_number,:journal_date=>payment_date,:flag=>$FLAG[:PAID])
    #shiv test?
    if $DEBIT_GROUP.include?(@paid_by_account.group.parent.id)
      @paid_by_account.update_attributes(:closing_balance=>@paid_by_account.closing_balance-@total)
   else
      @paid_by_account.update_attributes(:closing_balance=>@paid_by_account.closing_balance+@total)
   end
   
    i=0
    while i < @total_expense_items.to_i
      tax_amount = @taxes[i]=="" ? 0  : @taxes[i]
      total_amount=tax_amount.to_f+@products[i].to_f
      @account=Account.find(@expense_item_account_ids[i])
      @journal=Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>$EXPENSE_PAID, :journal_number=>@journal_number,:account_id=>@expense_item_account_ids[i],:debit_amount=>@products[i], :credit_amount=>0,:journal_date=>payment_date, :flag=>@flag)
      @account.update_attributes(:closing_balance=>@account.closing_balance.to_f+@products[i].to_f)
      i+=1
    end
      @journal=Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>$EXPENSE_PAID, :journal_number=>@journal_number,:account_id=>@expense_tax_account.id,:debit_amount=>@total_tax, :credit_amount=>0,:journal_date=>payment_date, :flag=>@flag)
      @expense_tax_account.update_attributes(:closing_balance=>(@expense_tax_account.closing_balance-@total_tax))
      Transact.update_all("payment_date='#{payment_date.to_date}', cheque_number='#{cheque_number}', payment_type='#{payment_type}'","expense_number = #{@expense_number} and transact_type = '#{$EXPENSE}' and flag=#{$FLAG[:PAID]}")
end
  
  def directly_paid_cheque_journal_entry(paid_to_account,cheque_number)
    @paid_by_account=Account.find(paid_to_account)
    @journal=Journal.create!(:journal_type=>$CHEQUE_PAID,:inv_exp_number=>@expense_number,:journal_number=>@journal_number,:account_id=>@paid_by_account.id,:credit_amount=>@amount,:debit_amount=>0,:cheque_number=>@cheque_number,:journal_date=>Time.today,:flag=>$FLAG[:PAID])
    @paid_by_account.update_attributes(:closing_balance=>@paid_by_account.closing_balance-@total)

    @account=Account.find(@account_number)
    @journal=Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>$CHEQUE_PAID, :journal_number=>@journal_number,:account_id=>@account_number,:debit_amount=>@amount, :credit_amount=>0,:journal_date=>@invoice_date, :flag=>@flag)
    @account.update_attributes(:closing_balance=>@account.closing_balance.to_f+@amount.to_f)        
  end


  def delete_previous_expense(options)
    @transacts = Transact.find(:all,:conditions=>["transacts.expense_number = ? and transacts.transact_type = ? and transacts.flag in (?)" ,@expense_number,  @transact_type,@expense_flag_array], :include=>[:expense_detail]).each { |object| object.destroy }
    @deleted_date = @transacts[0].invoice_date if options[:want_to_process_recurring] == 'yes'
    @expense_details = ExpenseDetail.destroy_all(["expense_number = ? and transact_id in (?)",@expense_number, @transacts.collect{|x|x.id}])
    
    @total_to_deduct = @expense_details.inject(0){ |a, val| a += val.price.to_f }
    @tax_to_deduct = @expense_details.inject(0){ |b, v| b += v.tax.to_f }
    if (@flag == $FLAG[:UNPAID] && @transacts[0].flag==$FLAG[:UNPAID])
     @acc_pay.update_attributes(:closing_balance=>(@acc_pay.closing_balance-(@total_to_deduct+@tax_to_deduct)))
     @expense_tax_account.update_attributes(:closing_balance=>(@expense_tax_account.closing_balance+@tax_to_deduct))
     @journals=Journal.destroy_all(["inv_exp_number=? and journal_type =? ",@expense_number,@transact_type])
     @journal_number = @journals[0].journal_number unless @journals[0].nil?
    end 

    if @flag !=$FLAG[:PAID] and @flag!=$FLAG[:RECURRING]
      for trans in @transacts
        if trans.credit_amount.to_f == 0 and trans.flag == $FLAG[:UNPAID]
          @account=Account.find(trans.account_id)
          @account.closing_balance-=trans.expense_detail.price#expense_detail will avail after deleting the expense_details cos :incluce in Transact.find 
          @account.save
        elsif trans.debit_amount == 0 and trans.flag == $FLAG[:UNPAID]
          @account = Account.find(trans.account_id) 
          @account.closing_balance-=trans.credit_amount
          @account.save
        end
      end
    elsif @flag==$FLAG[:RECURRING]
      @recurring_transact=RecurringTransact.find(:first, :conditions=>['recurring_inv_exp_number= ? and recurring_type =? ',@expense_number,@transact_type])
      @recurring_transact.destroy if @recurring_transact
    end
  end
  
    def delete_previous_cheque(options)
    @transacts = Transact.find(:all,:conditions=>["transacts.expense_number = ? and transacts.transact_type = ? and transacts.flag in (?)" ,@expense_number,$CHEQUE,[$FLAG[:UNPAID],$FLAG[:DRAFT]]]).each { |object| object.destroy }
    if @flag !=$FLAG[:PAID] 
      for trans in @transacts
        if trans.credit_amount.to_f == 0
          @account=Account.find(trans.account_id)
          @account.closing_balance-=trans.debit_amount#expense_detail will avail after deleting the expense_details cos :incluce in Transact.find 
          @account.save
        else
          @account = Account.find(trans.account_id) 
          @account.closing_balance-=trans.credit_amount
          @account.save
        end
      end
      @acc_pay.update_attributes(:closing_balance=>(@acc_pay.closing_balance-(@amount.to_f)))
      @journals=Journal.destroy_all(["cheque_number=? and journal_type =? ",@cheque_number,$CHEQUE])
    end
  end

	def delete_expense_physically(options,user_id,company_id)
    common_initialize
    @expense_number=options[:id]
    @flag=options[:flag].to_i
    @transact_type= @flag== $FLAG[:RECURRING] ? $EXPENSE_RECURRING : $EXPENSE
    @transacts = Transact.find(:all,:conditions=>["transacts.expense_number = ? and transacts.transact_type = ? and transacts.flag = (?)" ,@expense_number,@transact_type,@flag], :include=>[:expense_detail])
    @expense_details = ExpenseDetail.find(:all, :conditions=>["expense_number = ? and transact_id in (?)",@expense_number, @transacts.collect{|x|x.id}])    
    if @flag !=$FLAG[:PAID]
        if @flag!= $FLAG[:RECURRING]
          for trans in @transacts
            if trans.credit_amount.to_f == 0
              @account=Account.find(trans.account_id)
              t=trans.expense_detail
              @account.closing_balance-=(t.price*t.quantity)#expense_detail will avail after deleting the expense_details cos :incluce in Transact.find 
              @account.save
            else
              @account = Account.find(trans.account_id) 
              @account.closing_balance-=trans.credit_amount
              @account.save
            end
          end
          @total_to_deduct = @expense_details.inject(0){ |a, val| a += (val.price.to_f * val.quantity.to_f) }
          @tax_to_deduct = @expense_details.inject(0){ |b, v| b += v.tax.to_f }
          @acc_pay.update_attributes(:closing_balance=>(@acc_pay.closing_balance-(@total_to_deduct+@tax_to_deduct)))
          @expense_tax_account.update_attributes(:closing_balance=>(@expense_tax_account.closing_balance+@tax_to_deduct))
          #@journals = Journal.delete_all(["flag=#{$FLAG[:DELETED]}","inv_exp_number = #{@expense_number} and journal_type = '#{@transact_type}'"]) # update_all
        elsif @flag==$FLAG[:RECURRING]
          @recurring_transact=RecurringTransact.find(:first, :conditions=>['recurring_inv_exp_number= ? and recurring_type =? ',@expense_number,@transact_type])
          @recurring_transact.flag=$FLAG[:DELETED]
          @recurring_transact.save      	
        end
      @transacts.each { |object| object.destroy } #update_attributes(:flag=>$FLAG[:DELETED])
      @expense_details.each { |object| object.destroy } #update_attributes(:flag=>$FLAG[:DELETED])
		end
  end


=begin
  def self.revert_payment(expense_number,user_id,company_id)
      @acc_pay,@acc_pay_list,@expense_tax_account = Jujube.expense_common_initialize
      
      #Journal.update_all("flag='#{$FLAG[:DELETED]}',journal_type='EXPENSE_REVERTED'","journal_type='#{$EXPENSE_PAID}' and inv_exp_number='#{expense_number}'")
      #if requested_journals.length==2 #lines
       #   Journal.delete_all("journal_type='#{$EXPENSE_PAID}' and inv_exp_number='#{expense_number}'")
      #else    
      #  Journal.update_all("flag='#{$FLAG[:UNPAID]}',journal_type='EXPENSE'","journal_type='#{$EXPENSE_PAID}' and inv_exp_number='#{expense_number}'")
      #end
      
      @pay_types = Jujube.pay_expense_type_accounts
            
        # NOTE : only last journal on this expense needs to be reverted #
        pay_journal = Journal.find(:first, :conditions=>["journal_type= ? and inv_exp_number= ? and account_id in (?)",$EXPENSE_PAID,expense_number,@pay_types.collect{|x| x.id}],:order=>"CAST(journal_number AS UNSIGNED) DESC")

        requested_journals = Journal.find(:all, :conditions=>"journal_type='#{$EXPENSE_PAID}' and inv_exp_number='#{expense_number}'")
        # NOTE : only last journal on this invoice needs to be reverted #
        last_journals_of_expense = requested_journals.collect{|x| x.journal_number.to_i}.max
      

      new_journal_number = Jujube.get_journal_number
      
      #reverse entry
        new_journal_1 = pay_journal.clone
        new_journal_2 = pay_journal.clone
        
        new_journal_1.credit_amount = 0
        new_journal_1.debit_amount = pay_journal.credit_amount
        new_journal_1.journal_number = new_journal_number
        new_journal_1.journal_date = Time.now.to_s(:db)
        new_journal_1.journal_type = 'EXPENSE_REVERTED'
        new_journal_1.flag = $FLAG[:DELETED]    # at present journal flag is used nowhere. but it should be other than PAID status to avoid error in 'requested_journals' below
        new_journal_1.save
        
        new_journal_2.credit_amount = pay_journal.credit_amount
        new_journal_2.debit_amount = 0
        new_journal_2.journal_number = new_journal_number
        new_journal_2.account_id = @acc_pay.id
        new_journal_2.journal_date = Time.now.to_s(:db)
        new_journal_2.journal_type = 'EXPENSE_REVERTED'
        new_journal_2.flag = $FLAG[:DELETED]   # at present journal flag is used nowhere. but it should be other than PAID status to avoid error in 'requested_journals' below
        new_journal_2.save
      #reverse entry
      
        requested_journals.each{|x| 
                                 if x.journal_number.to_i == last_journals_of_expense
                                    acc = x.account
                                    if acc.group.name=='Current Assets'
                                        Account.update_counters acc.id, :closing_balance=> -(x.debit_amount-x.credit_amount) 
                                        Account.update_counters @acc_pay.id, :closing_balance=> (x.credit_amount-x.debit_amount)
                                        #current_asset_ids = Group.find_by_name('Current Assets').account_ids
                                        #Transact.find(:first, :conditions=>["expense_number = ? and id in (?)",expense_number,current_asset_ids])
                                    elsif  acc.id == Jujube.credit_card_payable.id                                      
                                        Account.update_counters acc.id, :closing_balance=> (x.debit_amount-x.credit_amount) 
                                        Account.update_counters @acc_pay.id, :closing_balance=> (x.credit_amount-x.debit_amount)
                                    end    
                                    x.update_attribute("flag",$FLAG[:UNPAID]) 
                                end    
        }

      Transact.update_all("flag='#{$FLAG[:UNPAID]}',payment_type=NULL,cheque_number=NULL,balance_amount=debit_amount-credit_amount", "expense_number=#{expense_number}")
      transact_id = Transact.find_by_expense_number(expense_number).id
      @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:transact_id=>transact_id,:entry_id=>transact_id,:entry_number=>expense_number,:entry_type=>$ENTRY[:EXPENSE],:action=> $LOG_ACTION[:REVERT])    
  end
=end

  def self.revert_payment(expense_number,user_id,company_id)
      requested_journals = Journal.find(:all, :conditions=>"journal_type='#{$EXPENSE_PAID}' and inv_exp_number='#{expense_number}'")
      # NOTE : only last journal of this expense needs to be reverted #
      last_journals_of_expense = requested_journals.collect{|x| x.journal_number.to_i}.max
      
      new_journal_number = Jujube.get_journal_number
      requested_journals.each{|x|
                                 if x.journal_number.to_i == last_journals_of_expense  # exp can be paid then reverted then paid then reverted.... so last paid journal should only be reverted.      
                                    y = x.clone
                                    old_dbt = x.debit_amount
                                    old_crt = x.credit_amount
                                    y.debit_amount = old_crt
                                    y.credit_amount = old_dbt
                                    y.journal_type='EXPENSE_REVERTED'
                                    y.journal_number= new_journal_number
                                    y.journal_date = Time.now.to_s(:db)
                                    y.flag=$FLAG[:DELETED]   # at present journal flag is used nowhere. but it should be other than PAID status to avoid error in 'requested_journals'
                                    y.save
                                    
                                    acc = x.account
                                    acc.update_attributes(:closing_balance=>acc.closing_balance+(x.credit_amount+x.debit_amount))
                                    x.update_attributes( :flag=>$FLAG[:UNPAID] )
                                 end   
                                }
      
      Transact.update_all("flag='#{$FLAG[:UNPAID]}',payment_type=NULL,cheque_number=NULL,balance_amount=debit_amount-credit_amount", "expense_number=#{expense_number}")
      transact_id = Transact.find_by_expense_number(expense_number).id
      @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:transact_id=>transact_id,:entry_id=>transact_id,:entry_number=>expense_number,:entry_type=>$ENTRY[:EXPENSE],:action=> $LOG_ACTION[:REVERT])    
  end


	def delete_expense_by_changing_flag(options,user_id,company_id)
    common_initialize
    @expense_number=options[:id]
    @flag=options[:flag].to_i
    @transact_type= @flag== $FLAG[:RECURRING] ? $EXPENSE_RECURRING : $EXPENSE
    @transacts = Transact.find(:all,:conditions=>["transacts.expense_number = ? and transacts.transact_type = ? and transacts.flag = (?)" ,@expense_number,@transact_type,@flag], :include=>[:expense_detail])
    @expense_details = ExpenseDetail.find(:all, :conditions=>["expense_number = ? and transact_id in (?)",@expense_number, @transacts.collect{|x|x.id}])
    @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:transact_id=>@transacts.first.id,:entry_id=>@transacts.first.id,:entry_number=>@expense_number,:entry_type=>$ENTRY[:EXPENSE],:action=>$LOG_ACTION[:DELETE])    
    if @flag !=$FLAG[:PAID]
        if @flag!= $FLAG[:RECURRING]
          for trans in @transacts
            if trans.credit_amount.to_f == 0
              @account=Account.find(trans.account_id)
              t=trans.expense_detail
              @account.closing_balance-=(t.price*t.quantity)#expense_detail will avail after deleting the expense_details cos :incluce in Transact.find 
              @account.save
            else
              @account = Account.find(trans.account_id) 
              @account.closing_balance-=trans.credit_amount
              @account.save
            end
          end
          @total_to_deduct = @expense_details.inject(0){ |a, val| a += (val.price.to_f * val.quantity.to_f) }
          @tax_to_deduct = @expense_details.inject(0){ |b, v| b += v.tax.to_f }
          @acc_pay.update_attributes(:closing_balance=>(@acc_pay.closing_balance-(@total_to_deduct+@tax_to_deduct)))
          @expense_tax_account.update_attributes(:closing_balance=>(@expense_tax_account.closing_balance+@tax_to_deduct))
          #@journals = Journal.update_all("flag=#{$FLAG[:DELETED]},journal_type='EXPENSE_DELETED'","inv_exp_number = #{@expense_number} and journal_type = '#{@transact_type}'") # update_all
          @journals = Journal.find(:all, :conditions=>["inv_exp_number = '#{@expense_number}' and journal_type = '#{@transact_type}'"])
          new_journal_number = Jujube.get_journal_number
          @journals.each{|x| 
                                      y = x.clone
                                      old_dbt = x.debit_amount
                                      old_crt = x.credit_amount
                                      y.debit_amount = old_crt
                                      y.credit_amount = old_dbt
                                      y.journal_type='EXPENSE_DELETED'
                                      y.journal_number= new_journal_number
                                      y.journal_date = Time.now.to_s(:db)
                                      #y.flag=$FLAG[:DELETED]   # at present journal flag is used nowhere.
                                      y.save
                                    }
          
        elsif @flag==$FLAG[:RECURRING]
          @recurring_transact=RecurringTransact.find(:first, :conditions=>['recurring_inv_exp_number= ? and recurring_type =? ',@expense_number,@transact_type])
          @recurring_transact.flag=$FLAG[:DELETED]
          @recurring_transact.save      	
        end
      @transacts.each { |object| object.update_attribute(:flag,$FLAG[:DELETED])  } #update_attributes(:flag=>$FLAG[:DELETED])
      @expense_details.each { |object| object.update_attribute(:flag,$FLAG[:DELETED])  } #update_attributes(:flag=>$FLAG[:DELETED])
		end
  end

  def pay_current_remittance(options=nil)
    @cpp = options[:total_cpp] ?  options[:total_cpp].to_f : 0
    @ei = options[:total_ei] ? options[:total_ei].to_f : 0
    @tax = options[:total_tax] ? options[:total_tax].to_f : 0
    @net = @cpp + @ei + @tax
    payroll_initialize
    @journal_number = Jujube.get_journal_number
    @month_start_date="01 #{options[:month]} #{options[:year]}".to_time.at_beginning_of_month.to_date
    @month_end_date="01 #{params[:month]} #{params[:year]}".to_time.at_end_of_month.to_date
    @month = @month_start_date.strftime("%B")
    @year = @month_start_date.year.to_s
    journal_type = $REMITTANCE.to_s + "_" + @month.upcase + "_" + @year
    @transact_chequing=Transact.create!(:transact_type=>$REMITTANCE, :invoice_date=>'',:account_id=>@payroll_expense_Chequing_credit, :credit_amount=>@net, :debit_amount=>0, :balance_amount=>@net*(-1), :invoice_number=>'', :expense_number=>'', :flag=>$FLAG[:REMITTANCE],:source=>$REMITTANCE)
    @transact_ei=Transact.create!(:transact_type=>$REMITTANCE, :invoice_date=>'', :account_id=>@payroll_expense_EI_credit.id, :credit_amount=>0, :debit_amount=>@ei, :balance_amount=>@ei, :invoice_number=>'', :expense_number=>'', :flag=>$FLAG[:REMITTANCE],:source=>$REMITTANCE)
    @transact_cpp=Transact.create!( :transact_type=>$REMITTANCE, :invoice_date=>'', :account_id=>@payroll_expense_CPP_credit.id, :credit_amount=>0, :debit_amount=>@cpp, :balance_amount=>@cpp, :invoice_number=>'', :expense_number=>'', :flag=>$FLAG[:REMITTANCE],:source=>$REMITTANCE)
    @transact_it=Transact.create!(:transact_type=>$REMITTANCE, :invoice_date=>'', :account_id=>@payroll_expense_FIT_credit.id, :credit_amount=>0, :debit_amount=>@tax, :balance_amount=>@tax, :invoice_number=>'', :expense_number=>'', :flag=>$FLAG[:REMITTANCE],:source=>$REMITTANCE)      
    
    @journal_debit_fit = Journal.create!( :inv_exp_number=>'', :journal_type=>journal_type, :journal_number=>@journal_number,:account_id=>@payroll_expense_FIT_credit.id,:debit_amount=>@tax, :credit_amount=>0,:journal_date=>Time.now,:description=>journal_type)          
    @journal_debit_ei = Journal.create!(:inv_exp_number=>'', :journal_type=>journal_type, :journal_number=>@journal_number,:account_id=>@payroll_expense_EI_credit.id,:debit_amount=>@ei, :credit_amount=>0,:journal_date=>Time.now,:description=>journal_type)          
    @journal_debit_cpp = Journal.create!( :inv_exp_number=>'', :journal_type=>journal_type, :journal_number=>@journal_number,:account_id=>@payroll_expense_CPP_credit.id,:debit_amount=>@cpp, :credit_amount=>0,:journal_date=>Time.now,:description=>journal_type)          
    @journal_credit_chequing = Journal.create!(:inv_exp_number=>'', :journal_type=>journal_type, :journal_number=>@journal_number,:account_id=>@payroll_expense_Chequing_credit.id,:debit_amount=>0, :credit_amount=>@net,:journal_date=>Time.now,:description=>journal_type)          

    @payroll_expense_Chequing_credit.update_attributes(:closing_balance=> @payroll_expense_Chequing_credit.closing_balance + @net)
    @payroll_expense_EI_credit.update_attributes(:closing_balance=> @payroll_expense_EI_credit.closing_balance - @ei)
    @payroll_expense_CPP_credit.update_attributes(:closing_balance=> @payroll_expense_CPP_credit.closing_balance - @cpp)
    @payroll_expense_FIT_credit.update_attributes(:closing_balance=> @payroll_expense_FIT_credit.closing_balance - @tax)
    
    @payrolls = Payroll.find(:all,:conditions=>["id in (?)",options[:payroll_ids].split(",")])
    @payrolls.each{|object| object.update_attributes(:remittance_paid=>1,:when_paid=>Time.now)}

  end  
  
  def payroll_initialize
    @payroll_expense_EI_credit = Account.find :first,:conditions=>["alias='EI Payable'"]
    @payroll_expense_CPP_credit = Account.find :first,:conditions=>["alias='CPP Payable'"]
    @payroll_expense_Chequing_credit = Account.find :first,:conditions=>["alias='Chequing Bank Account'"]
    @payroll_expense_FIT_credit = Account.find :first,:conditions=>["alias='Income Tax Payable'"]
    @payroll_expense_wage_debit = Account.find :first,:conditions=>["alias='Wages & Salaries'"]
    @payroll_expense_ei_debit = Account.find :first,:conditions=>["alias='EI Expense'"]
    @payroll_expense_cpp_debit = Account.find :first,:conditions=>["alias='CPP Expense'"]
    @payroll_expense_penalty = Account.find :first,:conditions=>["alias='Penalties'"]
  end
  
  def pay_overdue_remittance(options=nil)
    @overdue_cpp = options[:overdue_cpp] ?  options[:overdue_cpp].to_f : 0
    @overdue_ei = options[:overdue_ei] ? options[:overdue_ei].to_f : 0
    @overdue_tax = options[:overdue_tax] ? options[:overdue_tax].to_f : 0
    @penalty = options[:penalty] ? options[:penalty].to_f : 0
    @overdue_total = @overdue_cpp + @overdue_ei + @overdue_tax + @penalty
    payroll_initialize
    @journal_number = Jujube.get_journal_number
    remittance_entry
    @payrolls = Payroll.find(:all,:conditions=>["id in (?)",options[:overdue_payroll_ids].split(",")])
    @payrolls.each{|object| object.update_attributes(:remittance_paid=>1,:when_paid=>Time.now)}
  end    
  
  def remittance_entry
    @transact_chequing=Transact.create!(:transact_type=>$OVERDUE_REMITTANCE, :invoice_date=>'',:account_id=>@payroll_expense_Chequing_credit, :credit_amount=>@overdue_total, :debit_amount=>0, :balance_amount=>@overdue_total*(-1), :invoice_number=>'', :expense_number=>'', :flag=>$FLAG[:REMITTANCE],:source=>$REMITTANCE)
    @transact_ei=Transact.create!(:transact_type=>$OVERDUE_REMITTANCE, :invoice_date=>'', :account_id=>@payroll_expense_EI_credit.id, :credit_amount=>0, :debit_amount=>@overdue_ei, :balance_amount=>@overdue_ei ,:invoice_number=>'', :expense_number=>'', :flag=>$FLAG[:REMITTANCE],:source=>$REMITTANCE)
    @transact_cpp=Transact.create!( :transact_type=>$OVERDUE_REMITTANCE, :invoice_date=>'', :account_id=>@payroll_expense_CPP_credit.id, :credit_amount=>0, :debit_amount=>@overdue_cpp, :balance_amount=>@overdue_cpp, :invoice_number=>'', :expense_number=>'', :flag=>$FLAG[:REMITTANCE],:source=>$REMITTANCE)
    @transact_it=Transact.create!(:transact_type=>$OVERDUE_REMITTANCE, :invoice_date=>'', :account_id=>@payroll_expense_FIT_credit.id, :credit_amount=>0, :debit_amount=>@overdue_tax, :balance_amount=>@overdue_tax, :invoice_number=>'', :expense_number=>'', :flag=>$FLAG[:REMITTANCE],:source=>$REMITTANCE)      
    @transact_penalty=Transact.create!(:transact_type=>$OVERDUE_REMITTANCE, :invoice_date=>'', :account_id=>@payroll_expense_penalty.id, :credit_amount=>0, :debit_amount=>@penalty, :balance_amount=>@penalty, :invoice_number=>'', :expense_number=>'', :flag=>$FLAG[:REMITTANCE],:source=>$REMITTANCE)      
    
    @journal_debit_penalty = Journal.create!( :inv_exp_number=>'', :journal_type=>$OVERDUE_REMITTANCE, :journal_number=>@journal_number,:account_id=>@payroll_expense_penalty.id,:debit_amount=>@penalty, :credit_amount=>0,:journal_date=>Time.now,:description=>$OVERDUE_REMITTANCE)          
    @journal_debit_fit = Journal.create!( :inv_exp_number=>'', :journal_type=>$OVERDUE_REMITTANCE, :journal_number=>@journal_number,:account_id=>@payroll_expense_FIT_credit.id,:debit_amount=>@overdue_tax, :credit_amount=>0,:journal_date=>Time.now,:description=>$OVERDUE_REMITTANCE)          
    @journal_debit_ei = Journal.create!(:inv_exp_number=>'', :journal_type=>$OVERDUE_REMITTANCE, :journal_number=>@journal_number,:account_id=>@payroll_expense_EI_credit.id,:debit_amount=>@overdue_ei, :credit_amount=>0,:journal_date=>Time.now,:description=>$OVERDUE_REMITTANCE)          
    @journal_debit_cpp = Journal.create!( :inv_exp_number=>'', :journal_type=>$OVERDUE_REMITTANCE, :journal_number=>@journal_number,:account_id=>@payroll_expense_CPP_credit.id,:debit_amount=>@overdue_cpp, :credit_amount=>0,:journal_date=>Time.now,:description=>$OVERDUE_REMITTANCE)          
    @journal_credit_chequing = Journal.create!(:inv_exp_number=>'', :journal_type=>$OVERDUE_REMITTANCE, :journal_number=>@journal_number,:account_id=>@payroll_expense_Chequing_credit.id,:debit_amount=>0, :credit_amount=>@overdue_total,:journal_date=>Time.now,:description=>$OVERDUE_REMITTANCE)          

    @payroll_expense_Chequing_credit.update_attributes(:closing_balance=> @payroll_expense_Chequing_credit.closing_balance + @overdue_total)
    @payroll_expense_EI_credit.update_attributes(:closing_balance=> @payroll_expense_EI_credit.closing_balance - @overdue_ei)
    @payroll_expense_CPP_credit.update_attributes(:closing_balance=> @payroll_expense_CPP_credit.closing_balance - @overdue_cpp)
    @payroll_expense_FIT_credit.update_attributes(:closing_balance=> @payroll_expense_FIT_credit.closing_balance - @overdue_tax)
    @payroll_expense_penalty.update_attributes(:closing_balance=> @payroll_expense_penalty.closing_balance - @penalty)
  end  

  def pay_other_remittance(options=nil)
    @overdue_cpp = options[:overdue_cpp] ?  options[:overdue_cpp].to_f : 0
    @overdue_ei = options[:overdue_ei] ? options[:overdue_ei].to_f : 0
    @overdue_tax = options[:overdue_tax] ? options[:overdue_tax].to_f : 0
    @penalty = options[:penalty] ? options[:penalty].to_f : 0
    @overdue_total = options[:total]=="" ? @overdue_cpp + @overdue_ei + @overdue_tax + @penalty : options[:total].to_f
    payroll_initialize
    @journal_number = Jujube.get_journal_number
    remittance_entry
  end    

   
end
