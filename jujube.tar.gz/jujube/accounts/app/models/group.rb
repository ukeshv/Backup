class Group < ActiveRecord::Base
  acts_as_tree
  has_many :root_accounts
  has_many :accounts
  #belongs_to :user
  #acts_as_scoped :user
  
  def user_accounts(user_id)
     @user_accounts = Account.find(:all, :conditions=>["group_id = ? and number IS NOT NULL" ,id],:order=>"number asc")
  end 
end
