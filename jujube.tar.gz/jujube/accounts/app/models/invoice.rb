class Invoice

  attr_reader :user, :options
  attr_accessor :next_action 
  
  def common_initialize
    @acc_rec,@acc_rec_list,@invoice_sales_account,@invoice_tax_account = Jujube.invoice_common_initialize
  end
  
  def initialize
   # this is for later usage.
  end
  
  def save(options=nil,user_id=nil,company_id=nil)
    common_initialize
    get_params_details(options)
    create_invoice(options,user_id,company_id)
  end

  def create_invoice(options,user_id,company_id)
      invoice_transact_entry(user_id,company_id) # Transact Entry for all invoices (ordinary,draft,recurring)
      @next_action="/invoice/list" # default redirect to action to invoice-list
      if @flag==$FLAG[:UNPAID]
        unpaid_invoice_journal_entry # Journal entries for ordianry invoice ( Saved invoice)
        @next_action="/invoice/list"
      elsif @flag==$FLAG[:RECURRING]
        recurring_transacts_entry # RecurringTransact Model entry for cron job.
        @next_action="/invoice/recurring_list"
      end
      return true
  end
  
  def invoice_transact_entry(user_id,company_id)
    @transact=Transact.new(:transact_type=>@transact_type, :account_id=>@account_id,:debit_amount=>@total,:credit_amount=>0,:balance_amount=>@total* (-1),:invoice_number=>@invoice_number, :expense_number=>"",:invoice_date=>@invoice_date, :flag=>@flag,:note=>@note,:comment=>@comment,:source=>@source_type,:custom_invoice_number=>@custom_invoice_number)
    if @transact.save
    @account=Account.find(@account_id)
    @account.closing_balance+= @total
    @account.save
    @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:entry_number=>@invoice_number,:entry_type=>$ENTRY[:INVOICE],:action=>$LOG_ACTION[:PROCESS])  if @flag ==$FLAG[:UNPAID]
    @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:entry_number=>@invoice_number,:entry_type=>$ENTRY[:INVOICE],:action=>$LOG_ACTION[:DRAFT]) if @flag ==$FLAG[:DRAFT]
    end
    i=0
    while i < @amounts.length     
      tax_amount = @taxes[i]=="" ? 0  : @taxes[i]
      total_amount = tax_amount.to_f+@amounts[i].to_f
      @transact=Transact.new(:transact_type=>@transact_type, :account_id=>@invoice_item_account_ids[i],:debit_amount=>0,:credit_amount=>total_amount,:balance_amount=>@total ,:invoice_number=>@invoice_number, :expense_number=>"",:invoice_date=>@invoice_date, :flag=>@flag,:note=>@note,:comment=>@comment,:source=>@source_type)
      if @transact.save
        @invoice_details=InvoiceDetail.create!(:transact_id=>@transact.id, :invoice_number=>@invoice_number, :quantity=> @quantities[i], :description=>@descriptions[i], :tax_amount=>tax_amount,:amount=>@amounts[i],:units=>@units[i],:rt_amount =>@rates[i])
        i+=1
      end
    end
  end
  
  def unpaid_invoice_journal_entry
    #@journal_number = Jujube.get_journal_number
    @journal=Journal.create!(:inv_exp_number=>@invoice_number,:journal_type=>$INVOICE,:journal_number=>@journal_number,:account_id=>@acc_rec.id,:debit_amount=>@total,:credit_amount=>0,:journal_date=>@invoice_date,:flag=>@flag)
    @acc_rec.update_attributes(:closing_balance=>(@acc_rec.closing_balance+@total))
    j=0
    while j < @amounts.length        
    @journal=Journal.create!(:inv_exp_number=>@invoice_number,:journal_type=>$INVOICE,:journal_number=>@journal_number,:account_id=>@invoice_item_account_ids[j],:credit_amount=>@amounts[j],:debit_amount=>0,:journal_date=>@invoice_date,:flag=>@flag)
    @account = Account.find(@invoice_item_account_ids[j])
    @account.closing_balance+=@amounts[j].to_f
    @account.save
    j+=1      
    end
    #@invoice_sales_account.update_attributes(:closing_balance=>(@invoice_sales_account.closing_balance+@total_amount))
    @journal=Journal.create!(:inv_exp_number=>@invoice_number,:journal_type=>$INVOICE,:journal_number=>@journal_number,:account_id=>@invoice_tax_account.id,:credit_amount=>@total_tax,:debit_amount=>0,:journal_date=>@invoice_date, :flag=>@flag)
    @invoice_tax_account.update_attributes(:closing_balance=>(@invoice_tax_account.closing_balance+@total_tax))
end

#invoice_payment
def pay_invoice(invoice_number,paid_to_account,cheque_number,payment_date,payment_type,user_id,company_id)
  common_initialize
  get_invoice_detail_amount(invoice_number)
  if @transact_debit.flag == $FLAG[:DRAFT]
    @account = Account.find(@transact_debit.account_id)
    @account.closing_balance+=@transact_debit.debit_amount
    @account.save
    drafted_invoice_journal_entry(paid_to_account,cheque_number)
  else
  paid_invoice_journal_entry(paid_to_account,cheque_number,payment_date)
  end
  @transact_debit.update_attributes(:balance_amount=>@transact_debit.balance_amount + @transact_debit.debit_amount, :flag=>$FLAG[:PAID], :payment_date=>payment_date, :cheque_number=>cheque_number, :payment_type=>payment_type)
  Transact.update_all("flag=#{$FLAG[:PAID]},payment_date='#{payment_date.to_date}', cheque_number='#{cheque_number}', payment_type='#{payment_type}'","invoice_number = #{invoice_number} and transact_type = '#{$INVOICE}' and flag in (#{$FLAG[:DRAFT]},#{$FLAG[:UNPAID]})")
  @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:transact_id=>@transact_debit.id,:entry_id=>@transact_debit.id,:entry_number=>invoice_number,:entry_type=>$ENTRY[:INVOICE],:action=>$LOG_ACTION[:PAY])    
  @next_action="/invoice/list"
end

def update_invoice(options,user_id,company_id)
  common_initialize
  get_params_details(options)
  @invoice_number=options[:id] #@invoice_number already available from get_params_details, but while updating an invoice the invoice_number should be same. get_params_details value will match only for new invoices.
  @source_type=options[:source_type]
  delete_previous_invoice
  create_invoice(options,user_id,company_id)
end

 
def drafted_invoice_journal_entry(paid_to_account,cheque_number,payment_date) # Creating Journal entries for the missed Entires in Journal while this Invoice is saved as Draft.
    @journal_number = Jujube.get_journal_number
    @paid_to_account = Account.find(paid_to_account)
    @journal=Journal.create!(:inv_exp_number=>@transact_debit.invoice_number,:journal_type=>$INVOICE_RECEIVED,:journal_number=>@journal_number,:account_id=>@paid_to_account.id,:credit_amount=>0,:debit_amount=>@total,:cheque_number=>cheque_number,:journal_date=>payment_date, :flag=>$FLAG[:PAID])
    @paid_to_account.closing_balance+=@total
    @paid_to_account.save
    for invoice in @invoice_details                     
      @journal=Journal.create!(:inv_exp_number=>@transact_debit.invoice_number,:journal_type=>$INVOICE,:journal_number=>@journal_number,:account_id=>invoice.transact.account_id,:credit_amount=>invoice.amount,:debit_amount=>0,:journal_date=>@invoice_date, :flag=>$FLAG[:UNPAID])
      @account = Account.find(invoice.transact.account_id)
      @account.closing_balance+=invoice.amount.to_f
      @account.save                      
    end
    @journal=Journal.create!(:inv_exp_number=>@transact_debit.invoice_number,:journal_type=>$INVOICE,:journal_number=>@journal_number,:account_id=>@invoice_tax_account.id,:credit_amount=>@total_tax,:debit_amount=>0,:journal_date=>@invoice_date, :flag=>$FLAG[:UNPAID])
    @invoice_tax_account.update_attributes(:closing_balance=>(@invoice_tax_account.closing_balance+@total_tax))
end
    
def paid_invoice_journal_entry(paid_to_account,cheque_number,payment_date)
    @journal_number = Jujube.get_journal_number
    @paid_to_account = Account.find(paid_to_account)
    @journal=Journal.create!(:inv_exp_number=>@transact_debit.invoice_number,:journal_type=>$INVOICE_RECEIVED,:journal_number=>@journal_number,:account_id=>@paid_to_account.id,:credit_amount=>0,:debit_amount=>@total,:cheque_number=>cheque_number,:journal_date=>payment_date, :flag=>$FLAG[:PAID])
    @paid_to_account.closing_balance+=@total
    @paid_to_account.save
    @journal=Journal.create!(:inv_exp_number=>@transact_debit.invoice_number,:journal_type=>$INVOICE_RECEIVED,:journal_number=>@journal_number,:account_id=>@acc_rec.id,:debit_amount=>0,:credit_amount=>@total,:cheque_number=>cheque_number,:journal_date=>payment_date, :flag=>$FLAG[:PAID])
    @acc_rec.update_attributes(:closing_balance=>(@acc_rec.closing_balance-@total))
end

def delete_previous_invoice
  # destroy previous invioce entry
  @transacts = Transact.find(:all,:conditions=>["transacts.invoice_number = ? and transacts.transact_type = ? and transacts.flag in (?) " ,@invoice_number,@transact_type,@invoice_flag_array], :include=>[:invoice_detail]).each { |object| object.destroy }
  @invoice_details = InvoiceDetail.find(:all,:conditions=>["invoice_number= ? and transact_id in (?) ",@invoice_number, @transacts .collect{|x|x.id}], :order=>"id").each { |object| object.destroy }
  @total_to_deduct = @invoice_details.inject(0){ |a, val| a += val.amount.to_f }
  @tax_to_deduct = @invoice_details.inject(0){ |b, v| b += v.tax_amount.to_f }
  if (@flag == $FLAG[:UNPAID] && @transacts[0].flag==$FLAG[:UNPAID])
    @journals = Journal.destroy_all(["inv_exp_number = ? and journal_type = ?",@invoice_number,@transact_type])
    @journal_number = @journals[0].journal_number
    @acc_rec.update_attributes(:closing_balance=>(@acc_rec.closing_balance-(@total_to_deduct+@tax_to_deduct)))
    @invoice_tax_account.update_attributes(:closing_balance=>(@invoice_tax_account.closing_balance-@tax_to_deduct))
  end
  for trans in @transacts
    if trans.debit_amount == 0 and trans.flag == $FLAG[:UNPAID]
      @account = Account.find(trans.account_id)
      @account.closing_balance-=trans.invoice_detail.amount
      @account.save
    elsif trans.credit_amount == 0 and trans.flag == $FLAG[:UNPAID]
      @account=Account.find(trans.account_id)
      @account.closing_balance-= trans.debit_amount
      @account.save
    end   
  end
  if @flag == $FLAG[:RECURRING]
  @recurring_transact=RecurringTransact.find(:first, :conditions=>['recurring_inv_exp_number= ? and recurring_type =?',@invoice_number,@transact_type])
  @recurring_transact.destroy
  end
end


def get_params_details(options)
    @quantities = options[:quantity].values
    @descriptions = options[:description].values
    @amounts = options[:amount].values
    @invoice_item_account_ids = options[:account_number].values
    @taxes = options[:tax].values
    @units = options[:units].values
    @rates = options[:rate].values 
    @flag = options[:invoice_flag] ? options[:invoice_flag].to_i : 2
    @account_id = options[:transact][:account_id]
    @invoice_date = options[:transact][:invoice_date]
    @custom_invoice_number = options[:custom_invoice_number].gsub(/\D/,"")
    @total_amount = @amounts.inject(0) { |a, v| a += v.to_f }   
    @total_tax = @taxes.inject(0) { |a, v| a += v.to_f }   
    @total = @total_amount+@total_tax
    @flag==$FLAG[:RECURRING] ? (@transact_type =$INVOICE_RECURRING;@source_type=$INVOICE_CRON) : (@transact_type=$INVOICE;@source_type=$INVOICE)
    @invoice_number = @flag==$FLAG[:RECURRING] ? Jujube.get_recurring_invoice_number :  Jujube.get_invoice_number # invoice_number can be avilable from (options) params. But for Safety caution we are recalculating the invoice_number here.
    @journal_number = Jujube.get_journal_number
    @invoice_flag_array = @flag == $FLAG[:RECURRING] ? [$FLAG[:RECURRING]] : [$FLAG[:UNPAID],$FLAG[:DRAFT]] #1-drafted invoice, 2-ordinary invoice(Saved invoice), 3-Recurring Invoice.
    @note=options[:note]
    @comment=options[:comment]
    if @flag==$FLAG[:RECURRING]
      @recursive_range=options[:recursive][:repeating_range]
      @recursive_day= options[:recursive][:repeating_monthday] ? options[:recursive][:repeating_monthday] : options[:recursive][:repeating_weekday] 
    end
end

def get_invoice_detail_amount(invoice_number)
  @transact_debit  = Transact.find(:first,:conditions=>["invoice_number = ? and transact_type = ? and credit_amount = 0 and flag !=#{$FLAG[:RECURRING]}" ,invoice_number,$INVOICE])
  @transact_credit_all_records = Transact.find(:all,:conditions=>["transacts.invoice_number = ? and transacts.transact_type = ? and transacts.debit_amount = 0 and transacts.flag != #{$FLAG[:RECURRING]}" ,invoice_number,$INVOICE], :include=>[:invoice_detail])
  @invoice_date=@transact_debit.invoice_date
  @invoice_details = InvoiceDetail.find(:all, :conditions=>["invoice_number= ? and transact_id in (?) ",invoice_number,@transact_credit_all_records .collect{|x|x.id}], :order=>"id")
  @total_amount=@invoice_details.inject(0) { |sum, x| sum += x.amount.to_f }
  @total_tax=@invoice_details.inject(0) { |sum, x| sum += x.tax_amount.to_f }
  @total = @total_amount+@total_tax
end
      
  def recurring_transacts_entry
      @recurring_transact=RecurringTransact.create!(:recurring_inv_exp_number=>@invoice_number,:recurring_type=>@transact_type,:recurring_date=>@invoice_date,:recurring_range=>@recursive_range,:recurring_day=>@recursive_day)
      if @recurring_transact.recurring_date.to_date==Date.today
        @recurring_transact.create_invoice_entry
    end
  end
  
  def delete_invioce_physically(options,flag,user_id,company_id) # Deleting an Invoice means Just changing the flag to delete status.
    common_initialize
    @invoice_number=options[:id]
    @flag=flag
    @transact_type= @flag== $FLAG[:RECURRING] ? $INVOICE_RECURRING : $INVOICE
    @transacts = Transact.find(:all,:conditions=>["transacts.invoice_number = ? and transacts.transact_type = ? and transacts.flag = ?" ,@invoice_number,@transact_type,@flag], :include=>[:invoice_detail])
    @invoice_details = InvoiceDetail.find(:all, :conditions=>["invoice_number= ? and transact_id in (?) ",@invoice_number,@transacts .collect{|x|x.id}], :order=>"id")
    @total_amount=@invoice_details.inject(0) { |sum, x| sum += x.amount.to_f }  # in invoive_details amount=price*qty.
    @total_tax=@invoice_details.inject(0) { |sum, x| sum += x.tax_amount.to_f }
    @total = @total_amount+@total_tax
    @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:transact_id=>@transacts.first.id,:entry_id=>@transacts.first.id,:entry_number=>@invoice_number,:entry_type=>$ENTRY[:INVOICE],:action=>$LOG_ACTION[:DELETE])    
	if @flag.to_i==$FLAG[:UNPAID]
		@journals = Journal.delete_all("flag='#{$FLAG[:UNPAID]}' and inv_exp_number = '#{@invoice_number}' and journal_type = '#{$INVOICE}'")
		@invoice_tax_account.update_attributes(:closing_balance=>(@invoice_tax_account.closing_balance-@total_tax)) 
		for trans in @transacts
			if trans.debit_amount == 0 and trans.flag == $FLAG[:UNPAID]
			@account = Account.find(trans.account_id)
			@account.closing_balance-=trans.invoice_detail.amount
			@account.save
			elsif trans.credit_amount == 0 and trans.flag == $FLAG[:UNPAID]
			@account=Account.find(trans.account_id)
			@account.closing_balance-= @total 
			@account.save
			end   
		end
		@acc_rec.update_attributes(:closing_balance=>(@acc_rec.closing_balance-@total ))
	elsif @flag.to_i==$FLAG[:RECURRING]
	@recurring_transact=RecurringTransact.find(:first, :conditions=>['recurring_inv_exp_number= ? and recurring_type =?',@invoice_number,@transact_type])
	@recurring_transact.flag=$FLAG[:DELETED]
	@recurring_transact.save
	end
  @transacts.each { |object| object.destroy }
	@invoice_details.each { |object| object.destroy }
  end


  def self.revert_payment(invoice_number,user_id,company_id)
      requested_journals = Journal.find(:all, :conditions=>"journal_type='#{$INVOICE_RECEIVED}' and inv_exp_number='#{invoice_number}'")
      # NOTE : only last journal of this invoice needs to be reverted #
      last_journals_of_invoice = requested_journals.collect{|x| x.journal_number.to_i}.max
      
      new_journal_number = Jujube.get_journal_number
      requested_journals.each{|x|
                                 if x.journal_number.to_i == last_journals_of_invoice  # inv can be paid then reverted then paid then reverted.... so last paid journal should only be reverted.      
                                    y = x.clone
                                    old_dbt = x.debit_amount
                                    old_crt = x.credit_amount
                                    y.debit_amount = old_crt
                                    y.credit_amount = old_dbt
                                    y.journal_type='INVOICE_REVERTED'
                                    y.journal_number= new_journal_number
                                    y.journal_date = Time.now.to_s(:db)
                                    y.flag=$FLAG[:DELETED]   # at present journal flag is used nowhere. but it should be other than PAID status to avoid error in 'requested_journals'
                                    y.save
                                    
                                    acc = x.account
                                    acc.update_attributes(:closing_balance=>acc.closing_balance+(x.credit_amount+(-1*x.debit_amount)))
                                    x.update_attributes( :flag=>$FLAG[:UNPAID] )
                                 end   
                                }
      
      Transact.update_all("flag='#{$FLAG[:UNPAID]}',payment_type=NULL,cheque_number=NULL,balance_amount=credit_amount-debit_amount", "invoice_number=#{invoice_number}")
      transact_id = Transact.find_by_invoice_number(invoice_number).id
      @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:transact_id=>transact_id,:entry_id=>transact_id,:entry_number=>invoice_number,:entry_type=>$ENTRY[:INVOICE],:action=>$LOG_ACTION[:REVERT])    
  end



  def delete_invioce_by_changing_flag(options,flag,user_id,company_id) # Deleting an Invoice means Just changing the flag to delete status.
    common_initialize
    @invoice_number=options[:id]
    @flag=flag
    @transact_type= @flag== $FLAG[:RECURRING] ? $INVOICE_RECURRING : $INVOICE
    @transacts = Transact.find(:all,:conditions=>["transacts.invoice_number = ? and transacts.transact_type = ? and transacts.flag = ?" ,@invoice_number,@transact_type,@flag], :include=>[:invoice_detail])
    @invoice_details = InvoiceDetail.find(:all, :conditions=>["invoice_number= ? and transact_id in (?) ",@invoice_number,@transacts .collect{|x|x.id}], :order=>"id")
    @total_amount=@invoice_details.inject(0) { |sum, x| sum += x.amount.to_f }  # in invoive_details amount=price*qty.
    @total_tax=@invoice_details.inject(0) { |sum, x| sum += x.tax_amount.to_f }
    @total = @total_amount+@total_tax
    @entry_log = EntryStatusLog.create(:user_id=>user_id,:company_id=>company_id,:date_of_change=>Time.now,:transact_id=>@transacts.first.id,:entry_id=>@transacts.first.id,:entry_number=>@invoice_number,:entry_type=>$ENTRY[:INVOICE],:action=>$LOG_ACTION[:DELETE])    
	if @flag.to_i==$FLAG[:UNPAID]
		#@journals = Journal.update_all("flag='#{$FLAG[:DELETED]}',journal_type='INVOICE_DELETED'", "inv_exp_number = '#{@invoice_number}' and journal_type = '#{$INVOICE}'")
    @journals = Journal.find(:all, :conditions=>["inv_exp_number = '#{@invoice_number}' and journal_type = '#{$INVOICE}'"])
    new_journal_number = Jujube.get_journal_number
    @journals.each{|x| 
                                y = x.clone
                                old_dbt = x.debit_amount
                                old_crt = x.credit_amount
                                y.debit_amount = old_crt
                                y.credit_amount = old_dbt
                                y.journal_type='INVOICE_DELETED'
                                y.journal_number= new_journal_number
                                y.journal_date = Time.now.to_s(:db)
                                #y.flag=$FLAG[:DELETED]   # at present journal flag is used nowhere.
                                y.save
                              }
		@invoice_tax_account.update_attributes(:closing_balance=>(@invoice_tax_account.closing_balance-@total_tax)) 
		for trans in @transacts
			if trans.debit_amount == 0 and trans.flag == $FLAG[:UNPAID]
			@account = Account.find(trans.account_id)
			@account.closing_balance-=trans.invoice_detail.amount
			@account.save
			elsif trans.credit_amount == 0 and trans.flag == $FLAG[:UNPAID]
			@account=Account.find(trans.account_id)
			@account.closing_balance-= @total 
			@account.save
			end   
		end
		@acc_rec.update_attributes(:closing_balance=>(@acc_rec.closing_balance-@total ))
	elsif @flag.to_i==$FLAG[:RECURRING]
	@recurring_transact=RecurringTransact.find(:first, :conditions=>['recurring_inv_exp_number= ? and recurring_type =?',@invoice_number,@transact_type])
	@recurring_transact.flag=$FLAG[:DELETED]
	@recurring_transact.save
	end
  @transacts.each { |object| object.update_attribute(:flag,$FLAG[:DELETED]) }
	@invoice_details.each { |object| object.update_attribute(:flag,$FLAG[:DELETED]) }
  end

=begin
  def graph?
    @options[:type] == "graph" 
  end

  def total_price
    @total_price ||= expenses.sum(&:price)
  end

  def expenses
    @expenses ||= user.expenses.find(:all,
      :conditions => conditions,
      :order => "created_at ASC")
  end

  def from
    @from ||= date_from_options(:from)
  end

  def to
    @to ||= date_from_options(:to)
  end

  private

    def date_from_options(which)
      part = Proc.new { |n| options["#{which}(#{n}i)"] }
      if part[1]
        Date.new(part[1].to_i, part[2].to_i, part[3].to_i)
      else
        Date.today
      end
    end

    def conditions
      conditions = ["created_at between ? AND ?"]
      parameters = [from.to_time, to.to_time.end_of_day]

      if options[:category] != "all" 
        conditions << "category_id = ?" 
        parameters << options[:category]
      end

      [conditions.join(" AND "), *parameters]
    end
=end    
end
