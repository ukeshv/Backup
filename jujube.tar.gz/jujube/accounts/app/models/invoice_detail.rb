class InvoiceDetail < ActiveRecord::Base
  belongs_to :transact
  #belongs_to :user
  acts_as_scoped :company,:find_with_nil_scope=>true
end
