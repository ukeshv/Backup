class Journal < ActiveRecord::Base
  belongs_to :account
  #belongs_to :user
  acts_as_scoped :company,:find_with_nil_scope=>true
  
  def before_save
    if self.debit_amount
      self.debit_amount=(self.debit_amount * 100).round.to_f/100
    end
     if self.credit_amount
      self.credit_amount=(self.credit_amount * 100).round.to_f/100
    end
  end    
  
  def date
    return journal_date.strftime("%m/%d/%Y")
  end
end
