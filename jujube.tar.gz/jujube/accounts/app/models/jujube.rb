class Jujube  # this Model is used for common initialize functionlities.

  def common_initialize
    @success_flag = false
    @acc_rec = Account.find :first, :conditions=>["alias='Accounts Receivable'"]
    @acc_rec_list = Account.find :all, :conditions=>["number is null and source_account='contact' and group_id=?",@acc_rec.id]
    @acc_pay = Account.find :first, :conditions=>["alias='Accounts Payable'"]
    @acc_pay_list = Account.find :all, :conditions=>["number is null and source_account='contact' and group_id=?",@acc_pay.id]
    @invoice_sales_account = Account.find :first, :conditions=>["alias='Sales'"]
    @expense_tax_account = Account.find :first, :conditions=>["alias='GST (or HST) Paid on Purchases'"]
    @invoice_tax_account = Account.find :first, :conditions=>["alias='GST (or HST) Charged on Sales'"]
    @payroll_expense_wage_debit = Account.find :first,:conditions=>["alias='Wages & Salaries'"]
    @payroll_expense_ei_debit = Account.find :first,:conditions=>["alias='EI Expense'"]
    @payroll_expense_cpp_debit = Account.find :first,:conditions=>["alias='CPP Expense'"]
   end
  
  def self.invoice_common_initialize
    @acc_rec = Account.find :first, :conditions=>["alias='Accounts Receivable'"]
    @acc_rec_list = Account.find :all, :conditions=>["number is null and source_account='contact' and group_id=?",@acc_rec.id]
    @invoice_sales_account = Account.find :first, :conditions=>["alias='Sales'"]
    @invoice_tax_account = Account.find :first, :conditions=>["alias='GST (or HST) Charged on Sales'"]
    return @acc_rec,@acc_rec_list,@invoice_sales_account,@invoice_tax_account
  end
  
  def self.expense_common_initialize
    @acc_pay = Account.find :first, :conditions=>["alias='Accounts Payable'"]
    @acc_pay_list = Account.find :all, :conditions=>["number is null and source_account='contact' and group_id=?",@acc_pay.id]
    @expense_tax_account = Account.find :first, :conditions=>["alias='GST (or HST) Paid on Purchases'"]
    return @acc_pay,@acc_pay_list,@expense_tax_account
  end
  
  def self.employee_common_initialize
    @payroll_expense_wage_debit = Account.find :first,:conditions=>["alias='Wages & Salaries'"]    #dr
    @payroll_expense_ei_debit = Account.find :first,:conditions=>["alias='EI Expense'"]                    #dr 
    @payroll_expense_cpp_debit = Account.find :first,:conditions=>["alias='CPP Expense'"]               #dr
    
    @payroll_expense_EI_credit = Account.find :first,:conditions=>["alias='EI Payable'"]                   #cr
    @payroll_expense_CPP_credit = Account.find :first,:conditions=>["alias='CPP Payable'"]              #cr
    @payroll_expense_FIT_credit = Account.find :first,:conditions=>["alias='Income Tax Payable'"]   #cr 
    @payroll_pay = Account.find :first, :conditions=>["alias='Payroll Payable'"]                               #cr

    return @payroll_expense_wage_debit,@payroll_expense_ei_debit,@payroll_expense_cpp_debit,@payroll_expense_EI_credit,@payroll_expense_CPP_credit,@payroll_expense_FIT_credit,@payroll_pay
  end

  def self.get_expense_number
    get_first_record=Transact.find :first, :conditions=>["transact_type in (?) and flag in (?)",[$EXPENSE,$PAYROLL_EXPENSE, $CHEQUE], [$FLAG[:PAID],$FLAG[:UNPAID],$FLAG[:DELETED],$FLAG[:DRAFT]] ], :order=>"CAST(expense_number AS UNSIGNED) DESC"
    eval("@get_number= (get_first_record) ? get_first_record.expense_number.to_i+1 : 1")
    return @get_number
  end
  
  def self.get_cheque_number
    Transact.maximum("cheque_number", :conditions=>["payment_type=? and 	transact_type != ?", $PAYMENT_TYPE["CHEQUE"],$INVOICE]).to_i+1
  end

  def self.get_invoice_number
    get_first_record=Transact.find :first, :conditions=>["transact_type = ? and flag in (?)",$INVOICE, [$FLAG[:DRAFT],$FLAG[:UNPAID],$FLAG[:PAID],$FLAG[:DELETED]] ], :order=>"CAST(invoice_number AS UNSIGNED) DESC"
    eval("@get_number= (get_first_record) ? get_first_record.invoice_number.to_i+1 : 1")
    return @get_number
  end
  
  def self.get_recurring_expense_number
    get_first_record=Transact.find :first, :conditions=>["transact_type=? and flag in (?)",$EXPENSE_RECURRING,[$FLAG[:RECURRING],$FLAG[:DELETED]]], :order=>"CAST(expense_number AS UNSIGNED) DESC"
    eval("@get_number= (get_first_record) ? get_first_record.expense_number.to_i+1 : 1")
    return @get_number
  end

  def self.get_payroll_expense_number
    get_first_record=Transact.find :first, :conditions=>["transact_type=? and flag in (?)",$PAYROLL_EXPENSE,[$FLAG[:PAYROLL],$FLAG[:DELETED]]], :order=>"CAST(expense_number AS UNSIGNED) DESC"
    eval("@get_number= (get_first_record) ? get_first_record.expense_number.to_i+1 : 1")
    return @get_number
  end

  def self.get_recurring_invoice_number
    get_first_record=Transact.find :first, :conditions=>["transact_type=? and flag in (?)",$INVOICE_RECURRING,[$FLAG[:RECURRING],$FLAG[:DELETED]]], :order=>"CAST(invoice_number AS UNSIGNED) DESC"
    eval("@get_number= (get_first_record) ? get_first_record.invoice_number.to_i+1 : 1")
    return @get_number
  end
  
  def get_highest_number(type)
    get_first_record=Transact.find :first, :conditions=>["transact_type in (?)",[type.capitalize,$PAYROLL_EXPENSE]], :order=>"CAST("+type+"_number AS UNSIGNED) DESC"
    eval("@get_number= (get_first_record) ? get_first_record."+type.downcase+"_number.to_i+1 : 1")
    return @get_number
  end 
  def self.get_employee_number
    get_first_record=Employee.find :first, :order=>"CAST(employee_id AS UNSIGNED) DESC"
    eval("@get_number= (get_first_record) ? get_first_record.employee_id.to_i+1 : 1")
    return @get_number
  end 

  def self.get_journal_number
    get_first_record=Journal.find :first, :order=>"CAST(journal_number AS UNSIGNED) DESC"
    eval("@get_number= (get_first_record) ? get_first_record.journal_number.to_i+1 : 1")
    return @get_number
  end

  def self.pay_expense_type_accounts
    pay_account_names=['Cash on Hand','Savings Bank Account','Chequing Bank Account','Petty Cash','Credit Card Payable']
    return Account.find(:all, :conditions=>["alias in (?)",pay_account_names])
  end

  def self.credit_card_payable
    return Account.find(:first, :conditions=>["alias = ?",'Credit Card Payable'])
  end

  def self.paid_or_not(pay_type,id)
     if pay_type.downcase=='expense'
       return Journal.find(:all,:conditions=>["inv_exp_number=? and journal_type in (?) and debit_amount = 0 and credit_amount > 0 and flag = ?",id, [$EXPENSE_PAID,$PAYROLL_EXPENSE_PAID],$FLAG[:PAID]], :order=>"id")
    else  # invoice
      return Journal.find(:all,:conditions=>["inv_exp_number=? and journal_type=? and debit_amount > 0 and credit_amount = 0 and flag = ?",id, $INVOICE_RECEIVED,$FLAG[:PAID]])
    end  
  end
  
  
end