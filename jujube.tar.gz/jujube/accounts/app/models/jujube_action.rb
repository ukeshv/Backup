class JujubeAction < ActiveRecord::Base
	has_many :navigation_logs,  :class_name=>'NavigationLog', :foreign_key=>'to'
end
