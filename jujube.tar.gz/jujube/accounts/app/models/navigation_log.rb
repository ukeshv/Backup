class NavigationLog < ActiveRecord::Base
	belongs_to :user_token
	belongs_to :jujube_action,  :class_name=>'JujubeAction', :foreign_key=>'to'
end
