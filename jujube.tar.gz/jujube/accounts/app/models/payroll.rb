class Payroll < ActiveRecord::Base
  #belongs_to :user, :dependent=>:destroy
  acts_as_scoped :company,:find_with_nil_scope=>true
  
  $PAYROLL_EXPENSE = "PAYROLL_EXPENSE"
  $EXPENSE = "EXPENSE"
  $PAYROLL_CRON = "PAYROLL_EXPENSE"
  
  def before_save
    if self.employee_insurance
      self.employee_insurance=(self.employee_insurance * 100).round.to_f/100
    end
     if self.canada_pension_plan
      self.canada_pension_plan=(self.canada_pension_plan * 100).round.to_f/100
    end
     if self.federal_tax
      self.federal_tax=(self.federal_tax * 100).round.to_f/100
    end
     if self.provincial_tax
      self.provincial_tax=(self.provincial_tax * 100).round.to_f/100
    end
     if self.gross_amount
      self.gross_amount=(self.gross_amount * 100).round.to_f/100
    end
    if self.net_pay
      self.net_pay=(self.net_pay * 100).round.to_f/100
    end
  end    
    
  def self.checking_ei_max(emp_id)
    @ei_payroll =Payroll.find(:all,:conditions=>["employee_id= ? and flag!=? and flag!=?" ,emp_id,$FLAG[:PAYROLL],$FLAG[:DELETED]])
    @ei_total = @ei_payroll.inject(0) { |sum, x| sum += x.employee_insurance.to_f }  
  end  


  def self.update_payroll_transacts(date,text,payroll_loop_counter=0)
    Company.current = nil if text == "cron"
    @employees = Employee.find(:all,:conditions=>["end_date =? and deleted_by IS NULL",date]) 
    
    for employee in @employees
        if text == "cron"
          Company.current = Company.find(employee.company_id)
          payroll_loop_counter = find(:all,:conditions=>["employee_id = ? and flag <> ? and created_at >= ? and created_at <= ?",employee.id, $FLAG[:PAYROLL], employee.start_date, date], :select=>'id').length
        else  
          payroll_loop_counter = payroll_loop_counter - 1
        end
        
        @payroll = find(:all,:conditions=>["employee_id = ? and flag = ?",employee.id,$FLAG[:PAYROLL]])
        @transacts = Transact.find(:all,:conditions=>["transact_type=? and flag=? and expense_number in (?)",$PAYROLL_EXPENSE,$FLAG[:PAYROLL],@payroll.collect{|x| x.expense_number}])
        @acc_pay = Account.find :first, :conditions=>["alias='Accounts Payable'"]# and user_id=?",self.user_id]
        @payroll_pay = Account.find :first, :conditions=>["alias='Payroll Payable'"]
        @expense_number = Jujube.get_expense_number
        company = Company.find(employee.company_id)   # this could be company = current_company
        
            for payroll in @payroll
                  @each_payroll = payroll
                  @payroll_expense_wage_debit,@payroll_expense_ei_debit,@payroll_expense_cpp_debit,@payroll_expense_EI_credit,@payroll_expense_CPP_credit,@payroll_expense_FIT_credit,@payroll_pay = Jujube.employee_common_initialize

                  Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>$PAYROLL_EXPENSE, :journal_number=>@journal_number,:account_id=>@payroll_expense_wage_debit.id,:debit_amount=>@each_payroll.gross_amount, :credit_amount=>0)          
                  Journal.create!( :inv_exp_number=>@expense_number, :journal_type=>$PAYROLL_EXPENSE, :journal_number=>@journal_number,:account_id=>@payroll_expense_ei_debit.id,:debit_amount=>@each_payroll.employee_insurance * 1.4, :credit_amount=>0)          
                  Journal.create!( :inv_exp_number=>@expense_number, :journal_type=>$PAYROLL_EXPENSE, :journal_number=>@journal_number,:account_id=>@payroll_expense_cpp_debit.id,:debit_amount=>@each_payroll.canada_pension_plan, :credit_amount=>0)

                  Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>$PAYROLL_EXPENSE, :journal_number=>@journal_number,:account_id=>@payroll_expense_EI_credit.id,:debit_amount=>0, :credit_amount=>@each_payroll.employee_insurance+@each_payroll.employee_insurance * 1.4)          
                  Journal.create!( :inv_exp_number=>@expense_number, :journal_type=>$PAYROLL_EXPENSE, :journal_number=>@journal_number,:account_id=>@payroll_expense_CPP_credit.id,:debit_amount=>0, :credit_amount=>@each_payroll.canada_pension_plan + @each_payroll.canada_pension_plan)          
                  Journal.create!( :inv_exp_number=>@expense_number, :journal_type=>$PAYROLL_EXPENSE, :journal_number=>@journal_number,:account_id=>@payroll_expense_FIT_credit.id,:debit_amount=>0, :credit_amount=>@each_payroll.federal_tax+@each_payroll.provincial_tax)          
                  
                  Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>$PAYROLL_EXPENSE, :journal_number=>@journal_number,:account_id=>@payroll_pay.id,:debit_amount=>0, :credit_amount=>@each_payroll.net_pay)          
                @payroll_expense_EI_credit.update_attributes(:closing_balance=> @payroll_expense_EI_credit.closing_balance + @each_payroll.employee_insurance + (@each_payroll.employee_insurance * 1.4))
                @payroll_expense_CPP_credit.update_attributes(:closing_balance=> @payroll_expense_CPP_credit.closing_balance + @each_payroll.canada_pension_plan + @each_payroll.canada_pension_plan)
                @payroll_expense_FIT_credit.update_attributes(:closing_balance=> @payroll_expense_FIT_credit.closing_balance + @each_payroll.federal_tax + @each_payroll.provincial_tax)

                @payroll_expense_wage_debit.update_attributes(:closing_balance=> @payroll_expense_wage_debit.closing_balance + @each_payroll.gross_amount) #
                @payroll_expense_ei_debit.update_attributes(:closing_balance=> @payroll_expense_ei_debit.closing_balance + (@each_payroll.employee_insurance * 1.4)) #
                @payroll_expense_cpp_debit.update_attributes(:closing_balance=> @payroll_expense_cpp_debit.closing_balance + @each_payroll.canada_pension_plan) #
                @payroll_pay.update_attributes(:closing_balance=> @payroll_pay.closing_balance + @each_payroll.net_pay) #

                new_payroll = payroll.clone
                new_payroll.flag= $FLAG[:UNPAID] 
                @end_date = employee.end_date
                if employee.pay_period=="week"
                 @start_date = employee.start_date.to_time.advance(:days=>((payroll_loop_counter)*7)+1 ).to_date  #@end_date + 1
                 @end_date = @start_date + 6
                elsif employee.pay_period=="bi-week" 
                 @start_date = employee.start_date.to_time.advance(:days=>((payroll_loop_counter)*14)+1 ).to_date  #@end_date + 1
                 @end_date = @start_date + 13
                elsif employee.pay_period=="month"
                 @start_date = employee.start_date.to_time.advance(:months=>payroll_loop_counter).to_s(:db)
                 @end_date = @start_date.to_time.advance(:months=>1).to_s(:db)
                elsif employee.pay_period=="semi-month"  
                  counter_array = (payroll_loop_counter).divmod(2)
                  incrementable_months = counter_array.first
                  incrementable_days = counter_array.last*15
                 @start_date = employee.start_date.to_time.advance(:months=>incrementable_months ,:days=>incrementable_days).to_s(:db)
                 @end_date = @start_date.to_time.advance(:days=>incrementable_days).to_s(:db)
                end
               
                new_payroll.start_date = @start_date
                new_payroll.end_date = @end_date
                new_payroll.expense_number = @expense_number
                self.checking_ei_max(employee.id)
                unless company.selected_province == "QC"
                  new_payroll.employee_insurance = @ei_total > $PROVINCE_MAX ? 0 : new_payroll.employee_insurance
                else
                  new_payroll.employee_insurance = @ei_total > $QC_MAX ? 0 : new_payroll.employee_insurance 
                end
                new_payroll.save
            end   # for payroll end     
              
            employee.end_date = @end_date
            employee.update     
              
            @journal_number = Jujube.get_journal_number
            for transact in @transacts
              @new_transact = transact.clone
              @new_transact.invoice_date = employee.end_date
              @new_transact.flag = $FLAG[:UNPAID]
              @new_transact.expense_number = @expense_number   
              @new_transact.transact_type = $PAYROLL_EXPENSE   
              @new_transact.source = $PAYROLL_CRON   
              @new_transact.save
              #@expense_detail = Expense   ???
            end
        end    # for employee end     
  end   # def end
  
end

