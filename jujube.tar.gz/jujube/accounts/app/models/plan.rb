class Plan < ActiveRecord::Base
end
