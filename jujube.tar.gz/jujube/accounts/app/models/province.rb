class Province < ActiveRecord::Base
	belongs_to :country
end
