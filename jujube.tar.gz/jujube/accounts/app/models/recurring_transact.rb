class RecurringTransact <  ActiveRecord::Base
   #belongs_to :user
  acts_as_scoped :company,:find_with_nil_scope=>true
  def self.find_recurring_transacts(recurring_date=Date.today)
    Company.current=nil
     @recurring_transacts=find(:all, :conditions=>['recurring_date=?',recurring_date.to_date])
    for recurring_transact in @recurring_transacts
      Company.current=Company.find(recurring_transact.company_id)
      if recurring_transact.recurring_type == $EXPENSE_RECURRING
        recurring_transact.create_expense_entry
      end
      if recurring_transact.recurring_type == $INVOICE_RECURRING
        recurring_transact.create_invoice_entry
      end      
    end
  end
  
  def update_recurring_date
    case self.recurring_range
        when "daily"
          result= (self.recurring_date.to_date+1).to_s
        when "weekly"
          result= (self.recurring_date.to_date+7).to_s
        when "monthly"
          result= justify(self.recurring_date.to_time.advance({:months=>1}).to_date,recurring_day)
        when "yearly"
           day,month = convert_day_to_recurrence_year(self.recurring_day)
           if [29,30,31].include?(day) and month==2
                result = "01-03-#{self.recurring_date.year+1}".to_date - 1
           else  
              result = self.recurring_date.to_time.advance({:years=>1}).to_date
           end   
      end
      self.recurring_date=result
      self.save    
  end
  
  def justify(date,day)
    begin
      new_date = "#{day}-#{date.month}-#{date.year}".to_date
      return new_date
    rescue
      day=day-1
      retry
    end
  end
  
  
   def convert_day_to_recurrence_year(day)
     date_in_2000 = "01-01-2000".to_date.to_time.advance({:days=>day}).to_date
     return date_in_2000.day.to_i, date_in_2000.month.to_i
   end


  def create_expense_entry
      @transacts = Transact.find(:all, :conditions=>['transacts.transact_type = ? and transacts.expense_number = ?  and transacts.flag= ?',self.recurring_type,self.recurring_inv_exp_number,$FLAG[:RECURRING]], :include=>[:expense_detail])
      @journal_number = Jujube.get_journal_number
      @expense_number = Jujube.get_expense_number
      @acc_pay = Account.find :first, :conditions=>["alias='Accounts Payable'"]
      @expense_tax_account = Account.find :first, :conditions=>["alias='GST (HST) expense'"]
      @total_tax=0
    for transact in @transacts
      @new_transact=transact.clone
      @new_transact.flag=$FLAG[:UNPAID]
      @new_transact.created_at=Time.now
      @new_transact.transact_type=$EXPENSE
      @new_transact.source= "#{$EXPENSE_RECURRING} #{self.recurring_inv_exp_number}"
      @new_transact.expense_number=@expense_number
      @new_transact.invoice_date=self.recurring_date
      @new_transact.save
      if transact.debit_amount == 0
        @account=Account.find(transact.account_id)
        @account.closing_balance+=transact.credit_amount
        @account.save
        @journal=Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>$EXPENSE, :journal_number=>@journal_number,:account_id=>@acc_pay.id,:debit_amount=>0, :credit_amount=>transact.credit_amount,:journal_date=>self.recurring_date, :flag=>$FLAG[:UNPAID])
        @acc_pay.update_attributes(:closing_balance=>@acc_pay.closing_balance+transact.credit_amount)
      else
        @new_expense_detail=transact.expense_detail.clone
        @total_tax+=@new_expense_detail.tax.to_f
        @new_expense_detail.transact_id=@new_transact.id
        @new_expense_detail.expense_number=@new_transact.expense_number
        @new_expense_detail.created_at=Time.now
        @new_expense_detail.save
        t_details = transact.expense_detail
        @journal=Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>$EXPENSE, :journal_number=>@journal_number,:account_id=>transact.account_id,:debit_amount=>t_details.price*t_details.quantity, :credit_amount=>0,:journal_date=>self.recurring_date, :flag=>$FLAG[:UNPAID])
        @account=Account.find(transact.account_id)
        @account.closing_balance+=t_details.price*t_details.quantity
        @account.save
      end
    end
    @journal=Journal.create!(:inv_exp_number=>@expense_number, :journal_type=>$EXPENSE, :journal_number=>@journal_number,:account_id=>@expense_tax_account.id,:debit_amount=>@total_tax, :credit_amount=>0,:journal_date=>self.recurring_date, :flag=>$FLAG[:UNPAID])
    @expense_tax_account.update_attributes(:closing_balance=>@expense_tax_account.closing_balance+@total_tax)
    update_recurring_date
    end
      
    def create_invoice_entry  
      @transacts = Transact.find(:all, :conditions=>['transacts.transact_type = ? and transacts.invoice_number = ? and transacts.flag= ?',self.recurring_type,self.recurring_inv_exp_number,$FLAG[:RECURRING]], :include=>[:invoice_detail])
      @invoice_number=Jujube.get_invoice_number
      for transact in @transacts
        @new_transact=transact.clone
        @new_transact.flag=$FLAG[:DRAFT]
        @new_transact.created_at=Time.now
        @new_transact.transact_type=$INVOICE
        @new_transact.source="#{$INVOICE_RECURRING} #{self.recurring_inv_exp_number}"
        @new_transact.invoice_number=@invoice_number
        @new_transact.invoice_date=self.recurring_date
        @new_transact.save
        if transact.debit_amount == 0
		      @new_invoice_detail=transact.invoice_detail.clone
		      @new_invoice_detail.transact_id=@new_transact.id
		      @new_invoice_detail.invoice_number=@new_transact.invoice_number
		      @new_invoice_detail.created_at=Time.now
		      @new_invoice_detail.save
        end
      end
      update_recurring_date
    end  
end
