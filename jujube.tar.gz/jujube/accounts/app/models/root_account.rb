class RootAccount < ActiveRecord::Base
  belongs_to :group
end
