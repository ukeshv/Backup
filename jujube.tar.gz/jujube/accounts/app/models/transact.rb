class Transact < ActiveRecord::Base
  has_one :expense_detail
  has_one :invoice_detail
  belongs_to :account
  acts_as_scoped :company,:find_with_nil_scope=>false
  
  def before_save
    if self.debit_amount
      self.debit_amount=(self.debit_amount * 100).round.to_f/100
    end
     if self.credit_amount
      self.credit_amount=(self.credit_amount * 100).round.to_f/100
    end
     if self.balance_amount
      self.balance_amount=(self.balance_amount * 100).round.to_f/100
    end
  end  
  
  def date
    return invoice_date.strftime("%m/%d/%Y") unless invoice_date.nil?
  end
  
  def formatted_invoice_number
    length=invoice_number.to_s.length
    if length>5
      return invoice_number
    else
      padded_number='0' * (5-length)  +invoice_number.to_s  
    end
  end



end
