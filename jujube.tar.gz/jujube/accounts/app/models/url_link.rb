class UrlLink < ActiveRecord::Base
end
