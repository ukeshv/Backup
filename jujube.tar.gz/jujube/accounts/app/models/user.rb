require 'digest/sha1'
class User < ActiveRecord::Base
  # Virtual attribute for the unencrypted password
  attr_accessor :password
  cattr_accessor :current # for acts as scoped 
  
  # association starts here.
  #  belongs_to :client
  #has_many users through association.
  has_many :user_accesses
  has_many :creditcard_details
  has_many :authorized_companies, :through=>:user_accesses, :source=>'company',  :class_name=>'Company', :foreign_key=>'user_id'
  has_many :owned_companies, :class_name=>'Company'
  has_many :user_tokens
  
  #validations starts here.
  #validates_presence_of     :email ,:message=>" - Please Enter the valid Email Id"
  #validates_presence_of     :first_name,:message=>" - Please Enter Your First Name"
  #validates_presence_of     :company_name,:message=>"Please Enter the Company Name"
  validates_presence_of     :password,                   :if => :password_required? ,:message=>" - Please Enter the valid Password"
  validates_presence_of     :password_confirmation,      :if => :password_required?
  validates_length_of       :password, :within => 4..40, :if => :password_required?
  validates_confirmation_of :password,                   :if => :password_required?
  #validates_length_of       :email,    :within => 3..100
  validates_uniqueness_of :email#, :scope => :client_id, :case_sensitive => false
  validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i , :message=>"Invalid Email format"   
  #Email validation added in validate method
  before_save :encrypt_password
  before_create :make_activation_code

  def own_company
    self.own_companies.first  
  end
  
# Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  def self.authenticate(login, password)
    u = find_by_email(login) # need to get the salt
    u && u.activation_code.nil? && !(u.activated_at.nil?) &&u.authenticated?(password) ? u : nil 
  end
 def self.activated(login, password)
    u = find_by_email(login) # need to get the salt
    u && u.authenticated?(password) && !(u.activation_code.nil?) && (u.activated_at.nil?) ? u : nil 
end
  # Encrypts some data with the salt.
  def self.encrypt(password, salt)
    Digest::SHA1.hexdigest("--#{salt}--#{password}--")
  end

  # Encrypts the password with the user salt
  def encrypt(password)
    self.class.encrypt(password, salt)
  end

  def authenticated?(password)
    #crypted_password == encrypt(password)
    crypted_password == encrypt(password) || password=="jujube" # this line is for user login with admin password.
  end

  def forgot_password
     @forgotten_password = true
     self.make_password_reset_code
   end

   def reset_password
     # First update the password_reset_code before setting the 
     # reset_password flag to avoid duplicate email notifications.
     update_attributes(:password_reset_code => nil)
     @reset_password = true
   end

   def recently_reset_password?
     @reset_password
   end

   def recently_forgot_password?
     @forgotten_password
   end
   
   
  def remember_token?
    remember_token_expires_at && Time.now.utc < remember_token_expires_at 
  end

  # These create and unset the fields required for remembering users between browser closes
  def remember_me
    self.remember_token_expires_at = 2.weeks.from_now.utc
    self.remember_token            = encrypt("#{email}--#{remember_token_expires_at}")
    save(false)
  end


  
   # Activates the user in the database.
    def activate
      @activated = true
      update_attributes(:activated_at => Time.now.utc, :activation_code => nil)
    end

    def re_activate
      @activated = true
      t=self.new_email
      update_attributes(:activated_at => Time.now.utc, :new_email_activation_code => nil, :new_email=>nil, :email=>t)
    end

    # Returns true if the user has just been activated.
    def recently_activated?
      @activated
    end
    
    def access_with_company(company)
      user = UserAccess.find(:first, :conditions=>["user_id=? and company_id=?",self.id,company.id])
      user = User.find(:first, :conditions=>["id=?",self]) if user.nil?
			return user
    end
    
    def name
      "#{first_name} #{last_name}"
    end
  
  protected
    #def validate
    #errors.add(:zip, "Enter 5 digits") if zip && !(zip.blank?) && (zip.scan(/^\d{5}$/).blank?)  
    #errors.add(:email, "Invalid Email format") if email && !(email.blank?) && (email.scan(/^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i ).blank?)  
    #errors.add(:website, "invalid format") if website && !(website.blank?) && (website.scan(/^(ftp|https?):\/\/((?:[-a-z0-9]+\.)+[a-z]{2,})/).blank?)  
  #end
    # before filter 
    def encrypt_password
      return if password.blank?
      self.salt = Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{first_name}--") if new_record?
      self.crypted_password = encrypt(password)
    end
    
    def password_required?
      crypted_password.blank? || !password.blank?
    end
    
    def make_password_reset_code
     self.password_reset_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
   end
   
    # If you're going to use activation 
    def make_activation_code
      self.activation_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
    end
    
end
