class UserAccess < ActiveRecord::Base
  #associations
  belongs_to :company
  belongs_to :user
  #validation
  validates_uniqueness_of :user_id, :scope => :company_id, :message=>'This user already added in your company' # one user cannot repeat within the company itself.
  validates_presence_of     :first_name
  validates_presence_of     :last_name
  validates_presence_of     :account_type
  validates_presence_of     :access_level
  before_create :make_access_activation_code
    
  # Method to create the access permission and relatioship between an user and company.
  def self.create_company_access_for_user(user,company,account_type=0,access_level=0)
    @user_access=UserAccess.new(:user_id=>user.id,:company_id=>company.id,:account_type=>account_type,:access_level=>access_level, :access_activation_code=>"Jujube", :flag=>0, :access_activated_at=>Time.now)
    @user_access.save!
    rescue ActiveRecord::RecordInvalid
  end
  
  def make_access_activation_code
    self.access_activation_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
  end
  
  def activate_access
    @activated = true
    update_attributes(:access_activated_at => Time.now.utc, :access_activation_code => nil)
  end
  
end
