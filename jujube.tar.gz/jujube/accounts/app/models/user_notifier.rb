class UserNotifier < ActionMailer::Base
  def signup_notification(user,request)
    setup_email(user)
    site_url = request.env['HTTP_HOST']
    @subject    += 'Please activate your new account'
    @body[:url]  = "http://#{site_url.to_s}/account/activate/#{user.activation_code}"
   end

  def authorize_company_notification(user,user_access,company,request)
    setup_email(user)
    site_url = request.env['HTTP_HOST']
    @subject    += 'New company added you as authorized user'
    @body[:url]  = "http://#{site_url.to_s}/account/accept_company/#{user_access.access_activation_code}"
    @body[:company]=company
  end

   def activation(user,request)
    setup_email(user)
    site_url = request.env['HTTP_HOST']
    @subject    += 'Your account has been activated!'
    @body[:url]  = "http://#{site_url.to_s}/"
  end

    def forgot_password(user,request)
    setup_email(user)
    site_url = request.env['HTTP_HOST']
    @subject    += 'Request to change your password'
    @body[:url]  = "http://#{site_url.to_s}/account/reset_password/#{user.password_reset_code}"
  end

  def reset_password(user,request)
    setup_email(user)
    site_url = request.env['HTTP_HOST']
    @subject    += 'Your password has been reset'
  end

  def account_delete_notification(user,request)
    setup_email(user)
    site_url=request.env['HTTP_HOST']
    @subject='Your account has been Deleted'
    #@body[:url]="http://#{site_url.to_s}/account/activate/#{user.activation_code}"
   end

  def plan_upgraded_notification(user,request)
    setup_email(user)
    site_url=request.env['HTTP_HOST']
    @subject='Your plan has been Upgraded'
    @body[:url]="http://#{site_url.to_s}/settings/my_plan"
  end

  def email_invoice_pdf(company,receiver,options,request)
	@recipients  = "#{options[:to_address]}"
	@cc  = "#{options[:cc_address]}"
	@from        = "#{company.email}"
	@subject     = "#{options[:subject]}"
	@sent_on     = Time.now
	@body[:receiver] = receiver
	site_url=request.env['HTTP_HOST']
	@body[:url]="http://#{site_url.to_s}"
	@body[:company]=company
	@body[:email_body]=options[:email_body]
	unless options[:invoice][:pdf].blank?
		@invoice_pdf=File.open(options[:invoice][:pdf])
		attachment :body => @invoice_pdf.read, :content_type => "application/pdf",:filename =>options[:invoice][:pdf].split('/').last
	end
   end

  def password_change_notification(user,request)
    setup_email(user)
    site_url=request.env['HTTP_HOST']
    @subject='Password has been changed.'
    @body[:url]  = "http://#{site_url.to_s}/"
  end

  def email_change_notification(user,request)
    setup_email(user)
    @recipients  = "#{user.new_email}" # over writing...
    site_url=request.env['HTTP_HOST']
    @subject    += 'Please activate your new login'
    @body[:url]  = "http://#{site_url.to_s}/account/re_activate/#{user.new_email_activation_code}"
  end

  def support_notification(email, subject, comment)
    @recipients  ="info@railsfactory.com"
    @from        = "accounts@railsfactory.com"
    @subject     = "RailsFactory Accounts - "
    @body[:email]=email
    @body[:subject]=subject
    @body[:comment]=comment
    @sent_on= Time.now
  end

  protected
  def setup_email(user)
    @recipients  = "#{user.email}"
    @from        = "accounts@railsfactory.com"
    @subject     = "RailsFactory Accounts - "
    @sent_on     = Time.now
    @body[:user] = user
  end
end