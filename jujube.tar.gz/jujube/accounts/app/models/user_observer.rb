class UserObserver < ActiveRecord::Observer
  def after_create(user)
    #UserNotifier.deliver_signup_notification(user,request)
  end

  def after_save(user)
   # UserNotifier.deliver_activation(user,request) if user.recently_activated?
   #UserNotifier.deliver_forgot_password(user) if user.recently_forgot_password?
   #UserNotifier.deliver_reset_password(user,request) if user.recently_reset_password?
  end
   
end