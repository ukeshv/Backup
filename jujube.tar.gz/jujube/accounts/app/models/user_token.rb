class UserToken < ActiveRecord::Base
	belongs_to :user
	has_many :navigation_logs
end
