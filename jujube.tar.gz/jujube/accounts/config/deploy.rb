set :repository, "http://svn.railsfactory.com/jujube/ --username mars --password mars123"
set :application, "jujube"

set :linode_address, "70.85.16.159"

set :deploy_to, "/var/www/apps/#{application}"
set :user, "deployment"
set :runner, "deployment"

role :app, linode_address
role :web, linode_address
role :db,  linode_address, :primary => true

namespace :init do
  desc "create database.yml"
  task :database_yml do
    set :db_user, Capistrano::CLI.ui.ask("database user: ")
    set :db_pass, Capistrano::CLI.password_prompt("database password: ")
    database_configuration =<<-EOF
---
login: &login
  adapter: mysql
  database: #{application}
  host: localhost
  username: #{db_user}
  password: #{db_pass}

production:
  <<: *login

EOF

    run "mkdir -p #{shared_path}/config"
    put database_configuration, "#{shared_path}/config/database.yml"
  end

  desc "create mongrel_cluster.yml"
  task :mongrel_cluster_yml do
    mongrel_cluster_configuration = <<-EOF
--- 
user: deployment
cwd: /var/www/apps/#{application}/current/
log_file: /var/www/apps/#{application}/current/log/mongrel.log
port: "8000"
environment: production
group: deployment
address: 127.0.0.1
pid_file: /var/www/apps/#{application}/current/tmp/pids/mongrel.pid
servers: 3  
EOF

    run "mkdir -p #{shared_path}/config"
    put mongrel_cluster_configuration, "#{shared_path}/config/mongrel_cluster.yml"
  end
end

namespace :localize do
  desc "copy shared configurations to current"
  task :copy_shared_configurations, :roles => [:app] do
    %w[mongrel_cluster.yml database.yml].each do |f|
      run "ln -nsf #{shared_path}/config/#{f} #{current_path}/config/#{f}"
    end
  end
end

namespace :deploy do
  desc "stop mongrel cluster"
  task :stop do
    run "cd #{current_path};mongrel_rails cluster::stop"
  end
  
  desc "restart mongrel cluster"
  task :restart do
    run "cd #{current_path};mongrel_rails cluster::restart"
    run "ln -nfs /var/www/apps/jujube/data/company_logo /var/www/apps/jujube/current/public/images/company_logo"
  end
  
end

after "deploy:setup", "init:database_yml"
after "deploy:setup", "init:mongrel_cluster_yml"
after "deploy:symlink", "localize:copy_shared_configurations"
