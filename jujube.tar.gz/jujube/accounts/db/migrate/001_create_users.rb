class CreateUsers < ActiveRecord::Migration
  def self.up
    create_table "users", :force => true do |t|
      t.column :email,                     :string
      t.column :crypted_password,          :string, :limit => 40
      t.column :salt,:string, :limit => 40
      t.column :company_name,:string 
      t.column :first_name,:string,:limit => 40 
      t.column :last_name,:string,:limit => 40 
      t.column :title,:string,:limit => 40 
      t.column :street1,:string 
      t.column :street2,:string 
      t.column :city,:string 
      t.column :state,:string 
      t.column :zip,:string,:limit => 10 
      t.column :country,:string 
      t.column :phone,:string,:limit => 20 
      t.column :fax,:string 
      #t.column :email,:string 
      t.column :website,:string 
      t.column :activation_code, :string, :limit => 40
      t.column :activated_at, :datetime
      t.column :password_reset_code, :string, :limit => 40
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
  end

  def self.down
    drop_table "users"
  end
end
