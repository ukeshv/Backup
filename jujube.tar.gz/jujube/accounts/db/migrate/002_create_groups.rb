class CreateGroups < ActiveRecord::Migration
  def self.up
    create_table :groups do |t|
      t.column :parent_id, :integer, :default => 0 
      t.column :number,:integer 
      t.column :name,:string,:limit => 50 
      t.column :description,:text 
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
    
   
Group.create!(:parent_id=>0 , :number=>'' , :name =>'Assets' , :description=>'')
Group.create!(:parent_id=>0 , :number=>'' , :name =>'Liabilities' , :description=>'')
Group.create!(:parent_id=>0 , :number=>'', :name =>'Equity' , :description=>'')
Group.create!(:parent_id=>0 , :number=>'' , :name =>'Revenue' , :description=>'')
Group.create!(:parent_id=>0 , :number=>'' , :name =>'Expenses' , :description=>'')




Group.create!(:parent_id=>1 , :number=> '1000' , :name =>'Current Assets' , :description=>'')
Group.create!(:parent_id=>1 , :number=> '1200' , :name =>'Capital Assets' , :description=>'')
Group.create!(:parent_id=>1 , :number=> '1400' , :name =>'Other Non-Current Assets' , :description=>'')


Group.create!(:parent_id=>2 , :number=>'2000' , :name =>'Current Liabilities' , :description=>'')
Group.create!(:parent_id=>2 , :number=>'2200' , :name =>'Long Term Liabilities' , :description=>'')


Group.create!(:parent_id=>3 , :number=>'3000' , :name =>'Owners Equity' , :description=>'')



Group.create!(:parent_id=>4 , :number=>'4000' , :name =>'Sales Revenue' , :description=>'')
Group.create!(:parent_id=>4 , :number=>'4200' , :name =>'Other Revenue' , :description=>'')

Group.create!(:parent_id=>5 , :number=>'5000' , :name =>'Payroll Expenses' , :description=>'')
Group.create!(:parent_id=>5 , :number=>'5200' , :name =>'General and Administrative Expenses' , :description=>'')
    
    
    
  end

  def self.down
    drop_table :groups
  end
end
