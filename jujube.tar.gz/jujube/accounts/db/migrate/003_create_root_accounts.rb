class CreateRootAccounts < ActiveRecord::Migration
  def self.up
    create_table :root_accounts do |t|
      t.column :group_id,:integer 
      t.column :number,:integer 
      t.column :name,:string
      t.column :opening_balance,:float,:default=>0
      t.column :description,:text 
      t.column :editable,:boolean,:null => false,:default=>1 # default 1 means editable. 
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
    
RootAccount.create!(:group_id=>6 , :number=>1002 , :name =>'Cash on Hand' , :description=>'')
RootAccount.create!(:group_id=>6 , :number=>1004 , :name =>'Savings Bank Account' , :description=>'')
RootAccount.create!(:group_id=>6 , :number=>1006 , :name =>'Chequing Bank Account' , :description=>'')
RootAccount.create!(:group_id=>6 , :number=>1008 , :name =>'Petty Cash' , :description=>'')
#RootAccount.create!(:group_id=>6 , :number=>1010 , :name =>'Total Cash' , :description=>'')
RootAccount.create!(:group_id=>6 , :number=>1020 , :name =>'Notes Receivable' , :description=>'')
RootAccount.create!(:group_id=>6 , :number=>1030 , :name =>'Accounts Receivable' , :description=>'')
RootAccount.create!(:group_id=>6 , :number=>1040 , :name =>'Credit Card Receivable' , :description=>'')
RootAccount.create!(:group_id=>6 , :number=>1050 , :name =>'Prepaid Expenses' , :description=>'')


RootAccount.create!(:group_id=>7 , :number=>1210 , :name =>'Land' , :description=>'')
RootAccount.create!(:group_id=>7 , :number=>1212 , :name =>'Building' , :description=>'')
RootAccount.create!(:group_id=>7 , :number=>1214 , :name =>'Accumulated Amortization (Building)' , :description=>'')
RootAccount.create!(:group_id=>7 , :number=>1220 , :name =>'Building (Net)' , :description=>'')
RootAccount.create!(:group_id=>7 , :number=>1222 , :name =>'Office Furniture and Equipment' , :description=>'')
RootAccount.create!(:group_id=>7 , :number=>1224 , :name =>'Accumulated Amortization (Furniture and Equipment)' , :description=>'')
RootAccount.create!(:group_id=>7 , :number=>1230 , :name =>'Office Furniture and Equipment (Net)' , :description=>'')
RootAccount.create!(:group_id=>7 , :number=>1232 , :name =>'Vehicle' , :description=>'')
RootAccount.create!(:group_id=>7 , :number=>1234 , :name =>'Accumulated Amortization (Vehicle)' , :description=>'')
RootAccount.create!(:group_id=>7 , :number=>1240 , :name =>'Vehicle (Net)' , :description=>'')

RootAccount.create!(:group_id=>8 , :number=>1410, :name =>'Computer Software' , :description=>'')
RootAccount.create!(:group_id=>8 , :number=>1420, :name =>'Goodwill' , :description=>'')
RootAccount.create!(:group_id=>8 , :number=>1430, :name =>'Incorporation Cost' , :description=>'')

   
RootAccount.create!(:group_id=>9 , :number=>2010, :name =>'Accounts Payable' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2020, :name =>'Credit Card Payable' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2025, :name =>'Expense Payable' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2030, :name =>'Current Portion of Bank Loan' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2040, :name =>'Corporate Taxes Payable' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2050, :name =>'Vacation Payable' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2052, :name =>'EI Payable' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2054, :name =>'CPP Payable' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2056, :name =>'Income Tax Payable' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2060, :name =>'Total Receiver General' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2070, :name =>'WCB Payable' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2072, :name =>'GST (or HST) Charged on Sales' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2074, :name =>'GST (or HST) Paid on Purchases' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2076, :name =>'GST (or HST) Payroll Deductions' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2078, :name =>'GST (or HST) Adjustments' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2080, :name =>'GST (or HST) Owing (Refund)' , :description=>'')
RootAccount.create!(:group_id=>9 , :number=>2090, :name =>'Payroll Payable' , :description=>'')

  
RootAccount.create!(:group_id=>10 , :number=>2210, :name =>'Bank Loans' , :description=>'')
RootAccount.create!(:group_id=>10 , :number=>2220, :name =>'Mortgage Payable' , :description=>'')
RootAccount.create!(:group_id=>10 , :number=>2230, :name =>'Loans From Owners' , :description=>'')


RootAccount.create!(:group_id=>11 , :number=>3010, :name =>'Owners Contribution' , :description=>'')
RootAccount.create!(:group_id=>11 , :number=>3020, :name =>'Owners Withdrawals' , :description=>'')
RootAccount.create!(:group_id=>11 , :number=>3030, :name =>'Retained Earnings - Previous Year' , :description=>'')
RootAccount.create!(:group_id=>11 , :number=>3040, :name =>'Current Earnings' , :description=>'')


RootAccount.create!(:group_id=>12 , :number=>4010, :name =>'Sales' , :description=>'')
RootAccount.create!(:group_id=>12 , :number=>4020, :name =>'Expense Reimbursement' , :description=>'')
RootAccount.create!(:group_id=>12 , :number=>4030, :name =>'Early Payment Sales Discounts' , :description=>'')

 
RootAccount.create!(:group_id=>13 , :number=>4210, :name =>'Interest Revenue' , :description=>'')
RootAccount.create!(:group_id=>13 , :number=>4220, :name =>'Miscellaneous Revenue' , :description=>'')

RootAccount.create!(:group_id=>14 , :number=>5010, :name =>'Wages & Salaries' , :description=>'')
RootAccount.create!(:group_id=>14 , :number=>5020, :name =>'EI Expense' , :description=>'')
RootAccount.create!(:group_id=>14 , :number=>5030, :name =>'CPP Expense' , :description=>'')
RootAccount.create!(:group_id=>14 , :number=>5040, :name =>'WCB Expense' , :description=>'')
RootAccount.create!(:group_id=>14 , :number=>5050, :name =>'Employee benefits' , :description=>'')


RootAccount.create!(:group_id=>15 , :number=>5210, :name =>'Accounting and Legal' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5220, :name =>'Advertising and Promotions' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5230, :name =>'Amortization Expense' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5240, :name =>'Bad Debts' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5250, :name =>'Business Fees and Licenses' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5260, :name =>'Courier and Postage' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5270, :name =>'Credit Card Charges' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5280, :name =>'Income Taxes' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5290, :name =>'Insurance' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5310, :name =>'Interest and Bank Charges' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5320, :name =>'Office Supplies' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5330, :name =>'Property Taxes' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5340, :name =>'Motor Vehicle Expenses' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5350, :name =>'Miscellaneous Expenses' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5360, :name =>'Rent' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5370, :name =>'Repair and Maintenance' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5380, :name =>'Telephone' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5390, :name =>'Travel and Entertainment' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5410, :name =>'Utilities' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5420, :name =>'Credit Card Commissions' , :description=>'')
RootAccount.create!(:group_id=>15 , :number=>5430, :name =>'GST (HST) expense' , :description=>'')
end

  def self.down
    drop_table :root_accounts
  end
end
