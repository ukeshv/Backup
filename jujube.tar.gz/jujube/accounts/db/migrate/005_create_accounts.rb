class CreateAccounts < ActiveRecord::Migration
  def self.up
    create_table :accounts do |t|
      t.column :group_id,:integer 
      t.column :user_id, :integer
      t.column :number,:integer 
      t.column :name,:string
      t.column :opening_balance,:float,:default=>0
      t.column :description,:text 
      t.column :editable,:boolean,:null => false,:default=>1 # default 1 means editable. 
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
  end

  def self.down
    drop_table :accounts
  end
end
