class CreateEmployees < ActiveRecord::Migration
  def self.up
    create_table :employees do |t|
      t.column :user_id,:integer 
      t.column :employee_id,:integer 
      t.column :ledger_id,:integer 
      t.column :first_name,:string,:limit => 40 
      t.column :last_name,:string,:limit => 40 
      t.column :title,:string
      t.column :street1,:string 
      t.column :street2,:string 
      t.column :city,:string 
      t.column :state,:string 
      t.column :zip,:string,:limit => 10 
      t.column :country,:string 
      t.column :phone,:string,:limit => 20 
      t.column :email,:string     
      t.column :fax,:string
      t.column :website,:string
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
  end

  def self.down
    drop_table :employees
  end
end
