class AddColumnAccount < ActiveRecord::Migration
  def self.up
    add_column  :accounts,:source_account, :string
    add_column  :accounts,:deleted_status, :string
    add_column  :contacts,:ledger_id, :integer
    change_column :employees, :employee_id, :string

  end

  def self.down
    remove_column  :accounts,:source_account
    remove_column  :accounts,:deleted_status
    remove_column  :contacts,:ledger_id
    change_column :employees, :employee_id, :integer
  end
end
