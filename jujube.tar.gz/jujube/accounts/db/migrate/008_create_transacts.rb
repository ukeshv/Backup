class CreateTransacts < ActiveRecord::Migration
  def self.up
    create_table :transacts do |t|
      t.column :user_id,:integer 
      t.column :transact_type,:string 
      t.column :transact_number,:string 
      t.column :account_id,:integer
      t.column :debit_amount,:double
      t.column :credit_amount,:double
      t.column :balance_amount,:double
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
  end

  def self.down
    drop_table :transacts
  end
end
