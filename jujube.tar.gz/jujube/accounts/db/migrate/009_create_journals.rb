class CreateJournals < ActiveRecord::Migration
  def self.up
    create_table :journals do |t|
      t.column :user_id,:integer 
      t.column :transact_id,:integer
      t.column :journal_type,:string 
      t.column :journal_number,:string 
      t.column :account_id,:integer
      t.column :debit_amount,:double
      t.column :credit_amount,:double
      t.column :cheque_number,:string
      t.column :description,:text
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
  end

  def self.down
    drop_table :journals
  end
end
