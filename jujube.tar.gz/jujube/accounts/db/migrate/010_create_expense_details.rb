class CreateExpenseDetails < ActiveRecord::Migration
  def self.up
    create_table :expense_details do |t|
      t.column :user_id,:integer 
      t.column :transact_id,:integer
      t.column :expense_number,:string
      t.column :item_number,:integer
      t.column :quantity,:integer
      t.column :unit,:integer
      t.column :description,:text
      t.column :price,:double
      t.column :tax,:double
      t.column :hst,:double
      t.column :amount,:double
      t.column :allo,:double
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
  end

  def self.down
    drop_table :expense_details
  end
end
