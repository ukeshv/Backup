class CreateInvoiceDetails < ActiveRecord::Migration
  def self.up
    create_table :invoice_details do |t|
      t.column :user_id,:integer 
      t.column :transact_id,:integer
      t.column :invoice_number,:integer
      t.column :quantity,:integer
      t.column :description,:text
      t.column :amount,:double
      t.column :tax,:double
      t.column :tax_amount,:double
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
  end

  def self.down
    drop_table :invoice_details
  end
end
