class AddColumnTransact < ActiveRecord::Migration
  def self.up
   rename_column :contacts, :ledger_id, :account_id
   rename_column :employees, :ledger_id, :account_id
   remove_column  :transacts,:transact_number
   add_column  :transacts,:invoice_number, :string
   add_column  :transacts,:expense_number, :string

  end

  def self.down
   rename_column :contacts, :account_id, :ledger_id
   rename_column :employees, :account_id, :ledger_id
   add_column :transacts,:transact_number, :string
   remove_column  :transacts,:invoice_number
   remove_column  :transacts,:expense_number

  end
end
