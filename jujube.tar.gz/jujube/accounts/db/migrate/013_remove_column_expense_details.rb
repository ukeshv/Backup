class RemoveColumnExpenseDetails < ActiveRecord::Migration
  def self.up
    remove_column :expense_details,:allo
  end

  def self.down
    add_column :expense_details,:allo, :integer
  end
end
