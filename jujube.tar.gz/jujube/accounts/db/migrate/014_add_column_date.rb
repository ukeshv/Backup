class AddColumnDate < ActiveRecord::Migration
  def self.up    
    add_column :transacts,:invoice_date,:date
    add_column :accounts,:alias,:string
  end

  def self.down
    remove_column :transacts,:invoice_date    
    remove_column :accounts,:alias    
  end
end
