class JournalsRenameColumnTransactId < ActiveRecord::Migration
  def self.up
    rename_column :journals, :transact_id, :inv_exp_number
  end

  def self.down
    rename_column :journals, :inv_exp_number, :transact_id
  end
end
