class TransactsAddColumnDraft < ActiveRecord::Migration
  def self.up
    add_column :transacts, :draft, :boolean
  end

  def self.down
    remove_column :transacts, :draft
  end
end
