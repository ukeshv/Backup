class JournalsAddColumnJournalDate < ActiveRecord::Migration
  def self.up
     add_column :journals, :journal_date, :date
  end

  def self.down
     remove_column :journals, :journal_date
  end
end
