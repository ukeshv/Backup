class AddColumnInvoiceDetail < ActiveRecord::Migration
  def self.up
    add_column :invoice_details, :units, :string
    add_column :invoice_details, :rt_amount, :integer
  end

  def self.down
    remove_column :invoice_details, :units
    remove_column :invoice_details, :rt_amount
  end
end
