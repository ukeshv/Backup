class TransactAddColumn < ActiveRecord::Migration
  def self.up
    add_column :transacts, :note, :text
    add_column :transacts, :comment, :text
  end

  def self.down
    remove_column :transacts, :note
    remove_column :transacts, :comment
  end
end
