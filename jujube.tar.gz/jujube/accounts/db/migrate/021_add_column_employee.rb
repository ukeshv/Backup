class AddColumnEmployee < ActiveRecord::Migration
  def self.up
    add_column :employees, :social_insurance, :string
    add_column :employees, :payment_type, :string
    add_column :employees, :payment_amount, :float
    add_column :employees, :pay_period, :string
    add_column :employees, :start_date, :date
    add_column :employees, :provincial_claim, :integer
    add_column :employees, :federal_claim, :integer
    add_column :employees, :employee_insurance, :float
    add_column :employees, :canada_pension_plan, :float
  end

  def self.down
    remove_column :employees, :social_insurance
    remove_column :employees, :payment_type
    remove_column :employees, :payment_amount
    remove_column :employees, :pay_period
    remove_column :employees, :start_date
    remove_column :employees, :provincial_claim
    remove_column :employees, :federal_claim
    remove_column :employees, :employee_insurance
    remove_column :employees, :canada_pension_plan
  end
end
