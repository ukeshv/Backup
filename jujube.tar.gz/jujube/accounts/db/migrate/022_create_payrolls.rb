class CreatePayrolls < ActiveRecord::Migration
  def self.up
    create_table :payrolls do |t|
      t.column :user_id,:integer 
      t.column :inv_exp_number,:integer
      t.column :payroll_type,:string 
      t.column :payroll_number,:string 
      t.column :account_id,:integer
      t.column :debit_amount,:double
      t.column :credit_amount,:double
      t.column :cheque_number,:string
      t.column :description,:text
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
      t.column :payroll_date,:date 
    end
  end

  def self.down
    drop_table :payrolls
  end
end
