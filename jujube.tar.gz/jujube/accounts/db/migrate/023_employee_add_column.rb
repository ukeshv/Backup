class EmployeeAddColumn < ActiveRecord::Migration
  def self.up
   add_column :employees, :vacation, :float
   add_column :employees, :deleted_by, :integer
  end

  def self.down
    remove_column :employees, :vacation    
    remove_column :employees, :deleted_by    
  end
end
