class AddColumnToEmployee < ActiveRecord::Migration
  def self.up
   add_column :employees, :hours_per_week, :float
   add_column :employees, :from_date, :date
   add_column :employees, :to_date, :date
  end

  def self.down
    remove_column :employees, :hours_per_week 
    remove_column :employees, :from_date 
    remove_column :employees, :to_date 
  end
end
