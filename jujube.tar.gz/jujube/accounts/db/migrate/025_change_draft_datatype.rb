class ChangeDraftDatatype < ActiveRecord::Migration
  def self.up
      change_column :transacts, :draft, :integer, :default=>0
  end

  def self.down
    change_column :transacts, :draft, :boolean, :default=> nil
  end
end
