class CreateRecurringTransacts < ActiveRecord::Migration
  def self.up
    create_table :recurring_transacts do |t|
      t.column :user_id, :integer
      t.column :recurring_inv_exp_number, :integer
      t.column :recurring_type, :string
      t.column :recurring_date, :date
      t.column :recurring_range, :string
      t.column :recurring_day, :integer
    end
  end

  def self.down
    drop_table :recurring_transacts
  end
end
