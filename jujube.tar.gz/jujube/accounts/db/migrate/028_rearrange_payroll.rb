class RearrangePayroll < ActiveRecord::Migration
  def self.up
    remove_column :payrolls,:inv_exp_number
    remove_column :payrolls,:payroll_type
    remove_column :payrolls,:payroll_number
    remove_column :payrolls,:account_id
    remove_column :payrolls,:debit_amount
    remove_column :payrolls,:credit_amount
    remove_column :payrolls,:cheque_number
    remove_column :payrolls,:description
    remove_column :payrolls,:payroll_date
    
    add_column :payrolls,:employee_id,:integer
    add_column :payrolls,:transact_id,:integer
    add_column :payrolls,:start_date,:date
    add_column :payrolls,:end_date,:date
    add_column :payrolls,:employee_insurance,:float
    add_column :payrolls,:canada_pension_plan,:float
    add_column :payrolls,:federal_tax,:float
    add_column :payrolls,:provincial_tax,:float
    add_column :payrolls,:gross_amount,:float
    add_column :payrolls,:net_pay,:float
    add_column :employees,:federal_claim_code,:integer
  end

  def self.down
    add_column :payrolls,:inv_exp_number,:integer
    add_column :payrolls,:payroll_type,:string
    add_column :payrolls,:payroll_number,:string
    add_column :payrolls,:account_id,:integer
    add_column :payrolls,:debit_amount,:float
    add_column :payrolls,:credit_amount,:float
    add_column :payrolls,:cheque_number,:string
    add_column :payrolls,:description,:text
    add_column :payrolls,:payroll_date,:date
    
    remove_column :payrolls,:employee_id
    remove_column :payrolls,:transact_id
    remove_column :payrolls,:start_date
    remove_column :payrolls,:end_date
    remove_column :payrolls,:employee_insurance
    remove_column :payrolls,:canada_pension_plan
    remove_column :payrolls,:federal_tax
    remove_column :payrolls,:provincial_tax
    remove_column :payrolls,:gross_amount
    remove_column :payrolls,:net_pay
    remove_column :employees,:federal_claim_code
  end
end
