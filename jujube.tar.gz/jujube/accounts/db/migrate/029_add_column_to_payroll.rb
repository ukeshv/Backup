class AddColumnToPayroll < ActiveRecord::Migration
  def self.up
    add_column :payrolls,:draft,:integer
  end

  def self.down
    remove_column :payrolls,:draft
  end
end
