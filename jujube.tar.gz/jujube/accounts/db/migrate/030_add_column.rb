class AddColumn < ActiveRecord::Migration
  def self.up
    add_column :employees,:end_date,:date
    add_column :payrolls,:expense_number,:integer
    add_column :transacts,:source,:string
    change_column :payrolls,:draft,:integer,:default=>0
  end

  def self.down
    remove_column :employees,:end_date
    remove_column :payrolls,:expense_number
    remove_column :transacts,:source
    change_column :payrolls,:draft,:integer,:default=>nil    
  end
end
