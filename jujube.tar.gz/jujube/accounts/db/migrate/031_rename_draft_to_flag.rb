class RenameDraftToFlag < ActiveRecord::Migration
  def self.up
    rename_column :transacts, :draft, :flag 
    rename_column :payrolls, :draft, :flag 
    add_column :journals, :flag, :integer, :default=>0
    change_column :payrolls,:flag,:integer,:default=>0
    change_column :transacts,:flag,:integer,:default=>0
    change_column :employees,:federal_claim,:float,:default=>0
    change_column :employees,:provincial_claim,:float,:default=>0
  end

  def self.down
    rename_column :transacts, :flag, :draft 
    rename_column :payrolls, :flag, :draft 
    remove_column :journals, :flag
    change_column :payrolls,:draft,:integer,:default=>nil
    change_column :transacts,:draft,:integer,:default=>nil
    change_column :employees,:federal_claim,:integer
    change_column :employees,:provincial_claim,:integer
  end
end
