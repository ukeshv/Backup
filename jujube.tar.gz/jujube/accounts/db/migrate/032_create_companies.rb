class CreateCompanies < ActiveRecord::Migration
  def self.up
    create_table :companies do |t|
      t.column :client_id,:integer
      t.column :name,:string 
      t.column :street1,:string 
      t.column :street2,:string 
      t.column :city,:string 
      t.column :state,:string 
      t.column :zip,:string,:limit => 10 
      t.column :country,:string 
      t.column :phone,:string,:limit => 20, :default=>"709"
      t.column :fax,:string 
      t.column :email,:string 
      t.column :website,:string 
      t.column :flag,:integer, :default =>0
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
  end

  def self.down
    drop_table :companies
  end
end
