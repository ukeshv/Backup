class CreateClients < ActiveRecord::Migration
  def self.up
    create_table :clients do |t|
      t.column :first_name,:string 
      t.column :last_name,:string 
      t.column :street1,:string 
      t.column :street2,:string 
      t.column :city,:string 
      t.column :state,:string 
      t.column :zip,:string,:limit => 10 
      t.column :country,:string 
      t.column :phone,:string,:limit => 20 
      t.column :fax,:string 
      t.column :email,:string 
      t.column :website,:string 
      t.column :flag,:integer, :default =>0
      t.column :created_at,:datetime 
      t.column :updated_at,:datetime 
    end
  end

  def self.down
    drop_table :clients
  end
end
