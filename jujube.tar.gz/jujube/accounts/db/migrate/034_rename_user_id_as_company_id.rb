class RenameUserIdAsCompanyId < ActiveRecord::Migration
  def self.up
    rename_column :accounts, :user_id, :company_id
    rename_column :contacts, :user_id, :company_id
    rename_column :employees, :user_id, :company_id
    rename_column :expense_details, :user_id, :company_id
    rename_column :invoice_details, :user_id, :company_id
    rename_column :journals, :user_id, :company_id
    rename_column :payrolls, :user_id, :company_id
    rename_column :recurring_transacts, :user_id, :company_id
    rename_column :transacts, :user_id, :company_id
    add_column :users, :client_id, :integer
  end

  def self.down
    rename_column :accounts, :company_id, :user_id
    rename_column :contacts, :company_id, :user_id
    rename_column :employees, :company_id, :user_id
    rename_column :expense_details, :company_id, :user_id
    rename_column :invoice_details, :company_id, :user_id
    rename_column :journals, :company_id, :user_id
    rename_column :payrolls, :company_id, :user_id
    rename_column :recurring_transacts, :company_id, :user_id
    rename_column :transacts, :company_id, :user_id
    remove_column :users, :client_id
  end
end