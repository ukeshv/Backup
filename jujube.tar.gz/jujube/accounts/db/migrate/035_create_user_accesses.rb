class CreateUserAccesses < ActiveRecord::Migration
  def self.up
    create_table :user_accesses do |t|
      t.column :user_id, :integer
      t.column :company_id, :integer
      t.column :flag, :integer, :default=>0
    end
    remove_column :users, :company_name
  end

  def self.down
    drop_table :user_accesses
    add_column :users, :company_name, :string
  end
end
