class AddFieldFlag < ActiveRecord::Migration
  def self.up
    add_column :users, :flag, :integer, :default=>0
    add_column :accounts, :flag, :integer, :default=>0
    add_column :contacts, :flag, :integer, :default=>0
    add_column :employees, :flag, :integer, :default=>0
    add_column :expense_details, :flag, :integer, :default=>0
    add_column :invoice_details, :flag, :integer, :default=>0
    add_column :recurring_transacts, :flag, :integer, :default=>0
    add_column :groups, :flag, :integer, :default=>0
    add_column :root_accounts, :flag, :integer, :default=>0
  end

  def self.down
    remove_column :users, :flag
    remove_column :accounts, :flag
    remove_column :contacts, :flag
    remove_column :employees, :flag
    remove_column :expense_details, :flag
    remove_column :invoice_details, :flag
    remove_column :recurring_transacts, :flag
    remove_column :groups, :flag
    remove_column :root_accounts, :flag
  end
end
