class AddExtraFields < ActiveRecord::Migration
  def self.up
    add_column :employees, :provincial_claim_code, :integer
    add_column :companies, :business_number, :integer
    add_column :companies, :year_end_date, :date
    add_column :companies, :net_days, :integer
    add_column :companies, :selected_province, :string
    add_column :companies, :tax, :string
  end

  def self.down
    remove_column :employees, :provincial_claim_code
    remove_column :companies, :business_number
    remove_column :companies, :year_end_date
    remove_column :companies, :net_days
    remove_column :companies, :selected_province
    remove_column :companies, :tax
  end
end
