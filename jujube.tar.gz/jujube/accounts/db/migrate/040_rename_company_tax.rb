class RenameCompanyTax < ActiveRecord::Migration
  def self.up
    change_column :companies,:tax,:integer,:default=>0
  end

  def self.down
    change_column :companies,:tax,:string,:default=>nil   
  end
end
