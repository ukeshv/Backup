class CompanyChangeColumn < ActiveRecord::Migration
  def self.up
    change_column :companies,:net_days,:integer,:default=>30
    change_column :companies,:business_number,:string
  end

  def self.down
    change_column :companies,:net_days,:integer,:default=>nil   
    change_column :companies,:business_number,:integer   
  end
end
