class CreatePlans < ActiveRecord::Migration
  def self.up
    create_table :plans do |t|
      t.column :feature,:string
      t.column :feature_alais,:string
      t.column :html_input,:text
      t.column :plan1,:string
      t.column :plan2,:string
      t.column :plan3,:string
      t.column :plan4,:string
      t.column :plan5,:string
    end
  end

  def self.down
    drop_table :plans
  end
end
