class CreateCreditcardDetails < ActiveRecord::Migration
  def self.up
    create_table :creditcard_details do |t|
      t.column :user_id, :integer 
      t.column :creditcard_number, :string, :null => false
      t.column :creditcard_name, :string, :null => false
      t.column :expiration_month, :integer, :null => false
      t.column :expiration_year, :integer, :null => false
      t.column :verification_number, :integer, :null => false
      t.column :status, :string
      t.column :payment_date, :datetime
    end
  end

  def self.down
    drop_table :creditcard_details
  end
end
