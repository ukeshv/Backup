class CreateEntryStatusLogs < ActiveRecord::Migration
  def self.up
    create_table :entry_status_logs do |t|
      t.column :user_id,:integer
      t.column :company_id,:integer
      t.column :date_of_change,:datetime
      t.column :transact_id,:integer
      t.column :entry_id,:integer
      t.column :entry_number,:integer
      t.column :entry_type,:integer
      t.column :action,:text
    end
  end

  def self.down
    drop_table :entry_status_logs
  end
end
