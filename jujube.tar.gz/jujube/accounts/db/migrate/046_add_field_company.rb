class AddFieldCompany < ActiveRecord::Migration
  def self.up
    add_column :companies,:error_display,:integer,:default=>0
  end

  def self.down
    remove_column :companies,:error_display
  end
end
