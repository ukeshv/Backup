class ChangeTypeTaxCompanies < ActiveRecord::Migration
  def self.up
		change_column :companies, :tax, :float, :default=>0
  end

  def self.down
		change_column :companies, :tax, :integer, :default=>0
  end
end
