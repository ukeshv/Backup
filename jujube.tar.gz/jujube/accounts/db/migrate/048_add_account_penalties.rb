class AddAccountPenalties < ActiveRecord::Migration
  def self.up
		RootAccount.create!(:group_id=>15,:number=>5325,:name=>"Penalties") if !RootAccount.exists?(:number=>5325,:name=>"Penalties")
		@companies=Company.find(:all)
		for company in @companies
			Company.current=company
			Account.create!(:group_id=>15,:number=>5325,:name=>"Penalties",:company_id=>company.id) if !Account.exists?(:number=>5325,:name=>"Penalties")
		end
  end

  def self.down
		Company.current=nil
		RootAccount.destroy_all("number=5325")
		@companies=Company.find(:all)
		for company in @companies
			Company.current=company
			Account.destroy_all("number=5325")
			#Account.create!(:group_id=>15,:number=>5325,:name=>"Penalties",:company_id=>company.id) if !Account.exists?(:number=>5325,:name=>"Penalties")
		end
  end
end


