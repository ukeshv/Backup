class AddColumntoPayroll < ActiveRecord::Migration
  def self.up
    add_column :payrolls,:remittance_paid,:integer,:default=>0
    add_column :payrolls,:when_paid,:date
  end

  def self.down
    remove_column :payrolls,:remittance_paid
    remove_column :payrolls,:when_paid
  end
end
