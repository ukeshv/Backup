class AddColumnToTransact < ActiveRecord::Migration
  def self.up
    add_column :transacts,:payment_type,:string
    add_column :transacts,:cheque_number,:integer
  end

  def self.down
    remove_column :transacts,:payment_type
    remove_column :transacts,:cheque_number
  end
end
