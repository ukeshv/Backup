class AddColumnPaymentDetailsTransacts < ActiveRecord::Migration
  def self.up
    add_column :transacts,:payment_date,:date, :default=>Time.now
    add_column :transacts,:due_limit,:integer, :default=>0
  end

  def self.down
    remove_column :transacts, :payment_date
    remove_column :transacts, :due_limit
  end
end
