class AddInRecurringTransact < ActiveRecord::Migration
  def self.up
        add_column :recurring_transacts,:recurring_start_date,:date
        add_column :recurring_transacts,:recurring_end_date,:date
        add_column :recurring_transacts,:recurring_count,:integer
  end

  def self.down
        remove_column :recurring_transacts,:recurring_start_date
        remove_column :recurring_transacts,:recurring_end_date
        remove_column :recurring_transacts,:recurring_count
  end
end
