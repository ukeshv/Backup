class CreateCountries < ActiveRecord::Migration
  def self.up
    create_table :countries do |t|
      t.column :name, :string
      t.column :code, :string, :limit=>5
    end
    Country.create(:name=>'Canada',:code=>'CA')
  end

  def self.down
    drop_table :countries
  end
end
