class CreateProvinces < ActiveRecord::Migration
  def self.up
    create_table :provinces do |t|
      t.column :country_id, :integer
      t.column :name, :string
      t.column :code, :string, :limit=>5
      t.column :provincial_claim, :integer
      t.column :tax, :float
    end
    canada_id = Country.find_by_name('Canada').id
    Province.create(:country_id=>canada_id,:name=>'Newfoundland and Labrador',:code=>'NL',:tax=>'13.0',:provincial_claim=>7566)
    Province.create(:country_id=>canada_id,:name=>'Prince Edward Island',:code=>'PE',:tax=>'15.0',:provincial_claim=>7708)
    Province.create(:country_id=>canada_id,:name=>'Nova Scotia',:code=>'NS',:tax=>'13.0',:provincial_claim=>7731)
    Province.create(:country_id=>canada_id,:name=>'New Brunswick',:code=>'NB',:tax=>'13.0',:provincial_claim=>8395)
    Province.create(:country_id=>canada_id,:name=>'Quebec',:code=>'QC',:tax=>'12.5',:provincial_claim=>0)
    Province.create(:country_id=>canada_id,:name=>'Ontario',:code=>'ON',:tax=>'13.0',:provincial_claim=>8681)
    Province.create(:country_id=>canada_id,:name=>'Manitoba',:code=>'MB',:tax=>'12.0',:provincial_claim=>8034)
    Province.create(:country_id=>canada_id,:name=>'Saskatchewan',:code=>'SK',:tax=>'12.0',:provincial_claim=>8945)
    Province.create(:country_id=>canada_id,:name=>'Alberta',:code=>'AB',:tax=>'5.0',:provincial_claim=>16161)
    Province.create(:country_id=>canada_id,:name=>'British Columbia',:code=>'BC',:tax=>'12.0',:provincial_claim=>9189)
    Province.create(:country_id=>canada_id,:name=>'Yukon',:code=>'YT',:tax=>'0',:provincial_claim=>0)
    Province.create(:country_id=>canada_id,:name=>'Northwest Territories',:code=>'NT',:tax=>'0',:provincial_claim=>0)
    Province.create(:country_id=>canada_id,:name=>'Nunavut',:code=>'NU',:tax=>'0',:provincial_claim=>0)
  end




  def self.down
    drop_table :provinces
  end
end
