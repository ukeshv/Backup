class AddFieldsCompany < ActiveRecord::Migration
  def self.up
    add_column :companies, :business_type, :string
  end

  def self.down
    remove_column :companies, :business_type
  end
end
