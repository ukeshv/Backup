class AddColumnChequeNumberPayroll < ActiveRecord::Migration
  def self.up
    add_column :payrolls, :cheque_number, :integer
    add_column :payrolls, :payment_date, :date
    add_column :payrolls, :payment_type, :string
   end

  def self.down
    remove_column :payrolls, :cheque_number
    remove_column :payrolls, :payment_date
    remove_column :payrolls, :payment_type
   end
end
