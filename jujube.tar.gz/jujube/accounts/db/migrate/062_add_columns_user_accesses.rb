class AddColumnsUserAccesses < ActiveRecord::Migration
  def self.up
    add_column "user_accesses", "first_name",                :string,   :limit => 40
    add_column "user_accesses", "last_name",                 :string,   :limit => 40
    add_column "user_accesses", "title",                     :string,   :limit => 40
    add_column "user_accesses", "is_owner", :boolean, :default=>false
    add_column "user_accesses", "access_activation_code",                     :string,   :limit => 40
    add_column "user_accesses", "access_activated_at", :datetime
    add_column "companies", "user_id", :integer
  end

  def self.down
    remove_column "user_accesses", "first_name"
    remove_column "user_accesses", "last_name"
    remove_column "user_accesses", "title"
    remove_column "user_accesses", "is_owner"
    remove_column "user_accesses", "access_activation_code"
    remove_column "user_accesses", "access_activated_at"
    remove_column "companies", "user_id"
  end
end
