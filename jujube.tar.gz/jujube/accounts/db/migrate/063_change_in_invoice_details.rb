class ChangeInInvoiceDetails < ActiveRecord::Migration
  def self.up
    change_column :invoice_details, :rt_amount, :float
  end

  def self.down
    change_column :invoice_details, :rt_amount, :integer
  end
end
