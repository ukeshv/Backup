class CreateJujubeActions < ActiveRecord::Migration
  def self.up
    create_table :jujube_actions do |t|
       t.column :name, :string
    end
  end

  def self.down
    drop_table :jujube_actions
  end
end
