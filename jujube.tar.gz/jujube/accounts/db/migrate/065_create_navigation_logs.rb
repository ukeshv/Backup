class CreateNavigationLogs < ActiveRecord::Migration
  def self.up
    create_table :navigation_logs do |t|
      t.column :user_id, :integer
      t.column :from, :string
      t.column :to, :integer
      t.column :on, :datetime
    end
  end

  def self.down
    drop_table :navigation_logs
  end
end
