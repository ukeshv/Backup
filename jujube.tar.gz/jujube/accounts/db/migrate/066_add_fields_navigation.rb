class AddFieldsNavigation < ActiveRecord::Migration
  def self.up
    add_column :navigation_logs, :remote_ip, :string
    add_column :navigation_logs, :user_agent, :string
    add_column :navigation_logs, :user_token, :string
  end

  def self.down
    remove_column :navigation_logs, :remote_ip
    remove_column :navigation_logs, :user_agent
    remove_column :navigation_logs, :user_token
  end
end
