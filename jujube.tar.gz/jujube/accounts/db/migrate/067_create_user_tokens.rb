class CreateUserTokens < ActiveRecord::Migration
  def self.up
    create_table :user_tokens do |t|
      t.column :name, :string
      t.column :user_id, :integer
      t.column :created_at, :date
      t.column :updated_at, :date
    end
    remove_column :navigation_logs, :user_token
    remove_column :navigation_logs, :user_id
    add_column :navigation_logs, :user_token_id, :integer
    add_index :navigation_logs, :user_token_id
    add_index :navigation_logs, :on
  end

  def self.down
    drop_table :user_tokens
    add_column :navigation_logs, :user_token, :string
    add_column :navigation_logs, :user_id, :integer
    remove_column :navigation_logs, :user_token_id
    remove_index :navigation_logs, :on
  end


end
