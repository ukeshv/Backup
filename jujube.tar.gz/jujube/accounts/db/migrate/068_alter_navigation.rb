class AlterNavigation < ActiveRecord::Migration
  def self.up
    remove_column :navigation_logs, :from
    remove_column :navigation_logs, :to
    remove_column :navigation_logs, :remote_ip
    remove_column :navigation_logs, :user_agent
    remove_column :navigation_logs, :on
    add_column :navigation_logs, :visited_on, :date
    add_column :navigation_logs, :user_id, :integer
  end

  def self.down
    add_column :navigation_logs, :from, :datetime
    add_column :navigation_logs, :to, :datetime
    add_column :navigation_logs, :remote_ip, :string
    add_column :navigation_logs, :user_agent, :string
    add_column :navigation_logs, :on, :datetime
    remove_column :navigation_logs, :visited_on
    remove_column :navigation_logs, :user_id
  end
end
