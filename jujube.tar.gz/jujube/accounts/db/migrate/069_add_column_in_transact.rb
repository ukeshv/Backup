class AddColumnInTransact < ActiveRecord::Migration
  def self.up
    add_column :transacts, :custom_invoice_number, :integer
    ActiveRecord::Base.connection.update("UPDATE transacts SET custom_invoice_number = invoice_number")
  end

  def self.down
    remove_column :transacts, :custom_invoice_number
  end
end
