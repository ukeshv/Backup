function check_amounts(form) {
    var debit_amount=0.00; 
    var credit_amount=0.00;
    error_flag1=false;
    error_flag2=false;
    error_flag3=false;
    error_flag4=false;
    error_flag5=false;
    $('popup').hide();
    $('error1').hide();
    $('error2').hide();
    $('error3').hide();
    $('error4').hide();
  for (i=0; i< document.getElementsByClassName('debit').length; i++) {
    debit_field = document.getElementsByClassName('debit')[i]
    credit_field = document.getElementsByClassName('credit')[i]
    account_field = document.getElementsByClassName('account_select')[i]
  if (parseFloat(debit_field.value) >= 0)
    debit_amount += parseFloat(debit_field.value);
  if (parseFloat(credit_field.value) >= 0)
    credit_amount += parseFloat(credit_field.value);
  if (account_field.value == "") {
    error_flag1=true;
    $('popup').show();
    $('error1').show();
  }
  if (debit_field.value == "" && credit_field.value == "") {
    error_flag3=true;
    $('popup').show();
    $('error3').show();
  }
  if (debit_field.value != "" && credit_field.value !="") {
    error_flag4=true;
    $('popup').show();
    $('error4').show();
  }
  }
  if (debit_amount!=credit_amount) {
    error_flag2=true;
    $('popup').show();
    $('error2').show();
    }
  if (error_flag1==false && error_flag2==false && error_flag3==false && error_flag4==false) {
    form.submit();
  }
  }
 
function disable_fields(disable_class,enable_class) {
    document.getElementsByClassName(enable_class)[0].readOnly=true;
    document.getElementsByClassName(enable_class)[0].value="";
    document.getElementsByClassName(disable_class)[0].readOnly=false;
     for (i=1; i< document.getElementsByClassName(enable_class).length; i++) {
    disable_field = document.getElementsByClassName(disable_class)[i]
    enable_field = document.getElementsByClassName(enable_class)[i]
    disable_field.value=""
    disable_field.readOnly=true;
    enable_field.readOnly=false;
     }
         document.getElementsByClassName(disable_class)[0].focus();
   }
   
   
  function disable_field(enable_field,disable_field,account,index)
  {
    if(enable_field.value.strip() != ''){disable_field.value=""}
    //disable_field.readOnly=true;
    //enable_field.readOnly=false;
    //find_account_balance(account,index);
   }
  function check_diabled_status(index,action) {
   if (document.getElementsByClassName("credit")[0].readOnly==true)
    {
     disable_fields('debit','credit');
    }
   if (document.getElementsByClassName("debit")[0].readOnly==true)
  {
     disable_fields('credit','debit');
  }
    var selected_option = $('journal_account_0').value;
    if (action="edit")
    i=0
    else
    i=1
    if (selected_option != 0)
    for (i;i<account.length;i++)
  {
    if ($('journal_account_'+index).options[i].value == selected_option)
    $('journal_account_'+index).options[i].disabled=true;
  }
    
  }
  
  function find_account_balance(account, ind){
   var total_amount = 0 
   var debit = 0
   var credit = 0
   var balance_amount = 0 
  if ($('debit_amount_'+ind).value > 0)
  var debit = parseFloat($('debit_amount_'+ind).value)
  if ($('credit_amount_'+ind).value > 0)
  var credit = parseFloat($('credit_amount_'+ind).value)
  if (!isNaN(parseFloat(balance[account])))
  balance_amount = parseFloat(balance[account])
  if (account != 0 )
  {
  if (account_type[account] == "plus")
  total_amount = balance_amount +debit - credit
  else
  total_amount = balance_amount  -debit + credit
  $('total_amount_'+ind).innerHTML =  "<b>" + "$" + new NumberFormat(total_amount).toFormatted(); + "</b>"
   }
  else
  {
  $('total_amount_'+ind).innerHTML =  "<b>" + "$" + new NumberFormat(0).toFormatted(); + "</b>"
  }
  find_total_debit_credit_amounts();
  }
  
function find_total_debit_credit_amounts()
{
var debit_input_fields = document.getElementsByClassName("debit")
  var credit_input_fields = document.getElementsByClassName("credit")
  var total_debit_amount = 0;
  var total_credit_amount = 0;
  for(i=0;i<debit_input_fields.length;i++)
  {
  if (!isNaN(parseFloat(debit_input_fields[i].value)))
  total_debit_amount += parseFloat(debit_input_fields[i].value)
  if (!isNaN(parseFloat(credit_input_fields[i].value)))
  total_credit_amount += parseFloat(credit_input_fields[i].value)
  }
  $('total_debit_amount').innerHTML="<b>" + "$" + new NumberFormat(total_debit_amount).toFormatted(); + "</b>"
  $('total_credit_amount').innerHTML="<b>" + "$" + new NumberFormat(total_credit_amount).toFormatted(); + "</b>"
}

 function update_account_selection(select_value, index) {
 var options_length=$('journal_account_0').options.length
 var select_element = document.getElementsByClassName("account_select")  
 for(j=1;j<select_element.length;j++)
 {
  var other_select_length = select_element[j].options.length
  selected_element = select_element[j].value
  for (i=0;i<other_select_length;i++)
   select_element[j].options[0]=null;
  select_element[j].options[0]=new Option("Select Account","");
  for (i=1;i<=account.length;i++)
      {
        select_element[j].options[i]=new Option(account[i-1][1],account[i-1][0]);
        if (select_element[j].options[i].value == select_value)
        select_element[j].options[i].disabled=true;
      }
  if (select_value!=selected_element)
    select_element[j].value= selected_element
  else
     $('total_amount_'+j).innerHTML =  "<b>" + "$" + new NumberFormat(0).toFormatted(); + "</b>"
  }  
  find_account_balance(select_value,index)
 } 