function tryNumberFormat(obj)
{
	obj.value = new NumberFormat(obj.value).toFormatted();
}

function check_expense_errors(submit_form,entry_type)
   {
     var error_flag1=false;
     var error_flag4=false;
     var total_amount = 0;
     var quantity_input_boxes=document.getElementsByClassName('quantity');
     var amount_input_boxes=document.getElementsByClassName('amount');
     var account_selection_boxes=document.getElementsByClassName('account');
     var quantity_error_flag='';
     var amount_error_flag='';
     var account_error_flag='';
    $('popup').hide();
    $('error1').hide();
    $('error2').hide();
    $('error3').hide();
    $('error4').hide();
    $('error5').hide();
    for (i=0; i< amount_input_boxes.length; i++) {
        if (isNaN(parseFloat(amount_input_boxes[i].value)))
        {
         amount_error_flag += i+1+', ';
        }
        if (isNaN(parseFloat(quantity_input_boxes[i].value)))
        {
         quantity_error_flag += i+1+', ';
        }
        if (account_selection_boxes[i].value=="")
        {
          account_error_flag += i+1+', ';
        }
        
      }
    account_field = $('transact_account_id');
    calendar_field = $('transact[invoice_date]');
    var find_sum_result= find_sum('product','taxes')[0];
    total_amount  = find_sum_result[0];
    error_flag3 = find_sum_result[2];
   if ((account_field.value=="") || (account_field.value=="add_new")) 
  {
    error_flag1=true;
    $('popup').show();
    $('error1').show();
    window.scrollTo(0, 0);
  }
    if (quantity_error_flag!='')
  {
    $('popup').show();
    $('error2').show();
    window.scrollTo(0, 0);
  }
  if (amount_error_flag!='') 
  {
    $('popup').show();
    $('error3').show();
    window.scrollTo(0, 0);
  }
    if (account_error_flag!='') 
  {
    $('popup').show();
    $('error5').show();
    window.scrollTo(0, 0);
  }
  if (calendar_field.value=="") 
  {
    error_flag4=true;
    $('popup').show();
    $('error4').show();
    window.scrollTo(0, 0);
  }
  if (error_flag1==false && amount_error_flag=='' && quantity_error_flag=='' && account_error_flag=='' && error_flag4==false) 
  {
	if (entry_type=="recurring")
	{
		RedBox.showInline('recurring_options'); 
		return false;
	}
  window.onbeforeunload = "";
   submit_form.submit();

  } 
  }

function check_invoice_errors(submit_form,entry_type)
{
    $('popup').hide();
    $('error1').hide();
    $('error2').hide();
    $('error3').hide();
    $('error4').hide();
    $('error5').hide();
    $('error6').hide();
    $('error7').hide();
    var error_flag1=false;
    var error_flag2=false;
    var error_flag3=false;
    var error_flag4=false;
    var error_flag5=false;
    var error_flag6=false;
    var error_flag7=false;
    var total_amount = 0;
    var unit_selection_boxes=document.getElementsByClassName('units');
    var quantity_input_boxes=document.getElementsByClassName('quantity');
    var rate_input_boxes=document.getElementsByClassName('rate');
    var amount_input_boxes=document.getElementsByClassName('amount');
    var account_selection_boxes=document.getElementsByClassName('account');
    var unit_error_flag='';
    var quantity_error_flag='';
    var rate_error_flag='';
    var amount_error_flag='';
    var account_error_flag='';
    for (i=0; i< unit_selection_boxes.length; i++) {
        if (unit_selection_boxes[i].value=="")
        {
         unit_error_flag += i+1+', ';
        }
        if (unit_selection_boxes[i].value=="Service" && isNaN(parseFloat(amount_input_boxes[i].value)))
        {
         amount_error_flag += i+1+', ';
        }
        if (unit_selection_boxes[i].value!="Service" && unit_selection_boxes[i].value!="" && isNaN(parseFloat(quantity_input_boxes[i].value)))
        {
         quantity_error_flag += i+1+', ';
        }
        if (unit_selection_boxes[i].value!="Service" && unit_selection_boxes[i].value!="" && isNaN(parseFloat(rate_input_boxes[i].value)))
        {
         rate_error_flag += i+1+', ';
        }
        if (account_selection_boxes[i].value=="")
        {
          account_error_flag += i+1+', ';
        }
      }
    account_field = $('transact_account_id');
    calendar_field = $('transact[invoice_date]');
    var find_sum_result= find_sum('amount','taxes')[0];
    total_amount  = find_sum_result[0];
    error_flag3 = find_sum_result[2];
   if (account_field.value=="" || account_field.value=="add_new") 
  {
    error_flag1=true;
    $('popup').show();
    $('error1').show();
    window.scrollTo(0, 0);
  }
    if (unit_error_flag!='')
  {
    $('popup').show();
    $('error2').show();
    window.scrollTo(0, 0);
  }
  if (amount_error_flag!='') 
  {
    $('popup').show();
    $('error3').show();
    window.scrollTo(0, 0);
  }
  if (quantity_error_flag!='') 
  {
    $('popup').show();
    $('error4').show();
    window.scrollTo(0, 0);
  }
  if (rate_error_flag!='') 
  {
    $('popup').show();
    $('error5').show();
    window.scrollTo(0, 0);
  }
  
 if (calendar_field.value=="") 
  {
    error_flag6=true;
    $('popup').show();
    $('error6').show();
    window.scrollTo(0, 0);
  }
   if (account_error_flag!="") 
  {
    error_flag7=true;
    $('popup').show();
    $('error7').show();
    window.scrollTo(0, 0);
  }
  
  if (error_flag1==false && unit_error_flag=='' && amount_error_flag=='' && quantity_error_flag=='' && rate_error_flag=='' && account_error_flag=="" && error_flag6==false) 
  {
  if (entry_type=="invoice")
  {
    document.getElementById('comment').value = document.getElementById('comment_hidden').value
  }
  window.onbeforeunload = "";
   submit_form.submit();
  } 
}

function find_sum(class_name1,class_name2) {
  var sum=0.00;
  var tax=0.00;
  var amount_nil_flag='';
  var class_elements1=document.getElementsByClassName(class_name1)
  var class_elements2=document.getElementsByClassName(class_name2)
  for (i=0; i< class_elements1.length; i++) {
    if (!isNaN(parseFloat(class_elements1[i].value)))
    {
    sum += parseFloat(class_elements1[i].value);
    }
    else
    {
    amount_nil_flag=true;
    }
    if (!isNaN(parseFloat(class_elements2[i].value)))
    {
    tax += parseFloat(class_elements2[i].value);
    }
  }
  $('total_tax').innerHTML = "$" + new NumberFormat(tax).toFormatted();
  $('total_amount').innerHTML = "$" + new NumberFormat(sum).toFormatted();
  $('total').innerHTML = "$" + new NumberFormat(sum+tax).toFormatted();
  return [sum,tax,amount_nil_flag];
}

function show_rate(val,field_id) {
   if (val == 'Service'){
    $('rate_'+field_id).readOnly=true;
    $('rate_'+field_id).style.background="inactiveborder"
    $('rate_'+field_id).style.borderStyle = 'inset';
    $('rate_'+field_id).value="";
    
    $('quantity_'+field_id).readOnly=true;
    $('quantity_'+field_id).style.background="inactiveborder";
    $('quantity_'+field_id).style.borderStyle = 'inset';
    
    $('quantity_'+field_id).value="";
    $('amount_'+field_id).readOnly=false;
    $('amount_'+field_id).style.background="white"
    $('amount_'+field_id).style.borderStyle = 'inset';
    }
  else{
    $('rate_'+field_id).readOnly=false;
    $('rate_'+field_id).style.background="white"
    $('rate_'+field_id).style.borderStyle = 'inset';
    
    $('quantity_'+field_id).readOnly=false;
    $('quantity_'+field_id).style.background="white"
    $('quantity_'+field_id).style.borderStyle = 'inset';
    
   $('amount_'+field_id).readOnly=true;
   $('amount_'+field_id).style.background="inactiveborder"
   $('amount_'+field_id).style.borderStyle = 'inset';
   //$('amount_'+field_id).value="";
   }
}

function check_num(e) {
  var key;
  if(window.event)
    key = window.event.keyCode;     //IE
  else
    key = e.which;     //firefox
  if ((key > 47 && key <58 ) || (key ==8) || (key ==46) || (key ==0)  ) {
    return true;
  } else {
    return false;
  }
}

function check_cheque_num(e) {
  var key;
  if(window.event)
    key = window.event.keyCode;     //IE
  else
    key = e.which;     //firefox
  if ((key > 47 && key <58 ) || (key ==8) || (key ==0)  ) {
    return true;
  } 
  else {
    return false;
  }
}

function show_address(val, field_id, action) {
 //alert(val);
  var x= val
  new Ajax.Updater(field_id, action+'?value=' + x, {asynchronous:true, evalScripts:true}); return false;
}

function checkbox_alert() {
  var c = 0; 
  var formControls = document.check.elements;
  for (var i = 0; i < formControls.length; i++)
  if (formControls[i].type.toLowerCase() == 'checkbox' && formControls[i].checked)
    c++;
  if(c > 1) {
    Element.hide('option');
    Element.hide('option1');
    Element.hide('option2');
    Element.hide('option3');
  } else {
    Element.show('option');
    Element.show('option1');
    Element.show('option2');
    Element.show('option3');
    //document.getElementById('invoice_no') = val;
  }
}
function select_option(selectbox,value)
{
var select_tag = $(selectbox) 
for (var i=0; i<select_tag.options.length; i++)
{
		 if (select_tag.options[i].text ==value)
          var select_index = select_tag.options[i].index
}
select_tag.selectedIndex=select_index
}

  function find_invoice_amount(ind,province,tax_value){

   var amount = 0
   var subtotal = 0 
   var taxtotal = 0 
   var grandtotal = 0 
   var amount_element = document.getElementsByClassName('amount')
   var quantity_element = document.getElementsByClassName('quantity')
   var rate_element = document.getElementsByClassName('rate')
   var tax_element = document.getElementsByClassName('taxes')
   var tax_selection = document.getElementsByClassName('tax_selection')
   for (i=0; i< document.getElementsByClassName('amount').length; i++) {
   var quantity = 0 
   var rate = 0
   var tax = 0
   if (quantity_element[i].value > 0)
  var quantity = parseFloat(quantity_element[i].value)
  if (rate_element[i].value > 0)  
  var rate = parseFloat(rate_element[i].value)
  
   if (rate_element[i].readOnly==false)
   {
   amount = (quantity * rate)
     if (amount >= 0 )
     amount_element[i].value= new NumberFormat(round_to(amount,2)).toFormatted().gsub(',','');
    }
   else
   {
   amount=parseFloat(amount_element[i].value);
   }
   if (amount>0 && tax_selection[i].checked==true)
	 {
		if (province=="PE" || province=="QC")
		{
			partial_tax1=parseFloat(amount*(0.05))
			partial_tax2=parseFloat((partial_tax1+amount)*((tax_value-5)/100));
			tax_element[i].value=round_to(partial_tax1+partial_tax2,2)
		}
		else
		{
   	tax_element[i].value = round_to((amount * (tax_value/100)),2);
		}
		}
		else
		{
		tax_element[i].value = "";
		}
   if (tax_element[i].value > 0)
	var tax = parseFloat(tax_element[i].value)
	
   subtotal += amount
   taxtotal +=tax
  }
  grandtotal = taxtotal + subtotal
  
  $('total_amount').innerHTML = "$" + new NumberFormat(subtotal).toFormatted();
  $('total_tax').innerHTML = "$" + new NumberFormat(taxtotal).toFormatted();
  $('total').innerHTML = "$" + new NumberFormat(grandtotal).toFormatted();
  
  }
  
  function check_other()
  {
  if ($('contact_type_other').checked)
  {
  $('contact_type_client').disabled=true;
  $('contact_type_vendor').disabled=true;
  }
  else
  {
  $('contact_type_client').disabled=false;
  $('contact_type_vendor').disabled=false;
  }
  }
 function amount_onfocus(id)
  {
  if (id.value==0)
    id.value = '';
   }
  function show_recursive_options(selected_option)
  {
     if (selected_option =="Select")
    {
        $('week_day1').hide();
        $('month_day1').hide();
        $('transact[invoice_date1]').value="";
        $('recursive_calendar').hide();
        $('recursive_calendar_label').hide();
				if ($('transact[invoice_date1]'))
				$('transact[invoice_date1]').value="";
   }
    else 
    {
    if(selected_option =="Week" || selected_option =="Two Weeks")
    {
      $('week_day1').show();
      $('recursive_repeating_weekday1').disabled=false;
      $('month_day1').hide();
      $('recursive_repeating_monthday1').disabled=true;
      $('recursive_repeating_weekday1').selectedIndex=0;
      $('recursive_calendar').hide();
      $('recursive_calendar_label').hide();
			if ($('transact[invoice_date1]'))
			$('transact[invoice_date1]').value="";
    }
    else
    {
    $('week_day1').hide();
    $('recursive_repeating_weekday1').disabled=true;
    $('month_day1').show();
    $('recursive_repeating_monthday1').disabled=false;
    $('recursive_repeating_monthday1').selectedIndex=0;
    $('recursive_calendar').hide();
    $('recursive_calendar_label').hide();
		if ($('transact[invoice_date1]'))
		$('transact[invoice_date1]').value="";
    }
    }
  }
  function show_recursive_calendar(selected_weekly_day,selected_monthly_day)
  {
     if(selected_weekly_day=='Select Day' || selected_monthly_day=='Select Day')
     {
      $('transact[invoice_date1]').value="";
      $('recursive_calendar').hide();
      $('recursive_calendar_label').hide();
      }
      else
      {
      new Ajax.Request('/invoice/show_recursive_calendar?selected_monthly_day=' + selected_monthly_day+'&selected_weekly_day='+selected_weekly_day, {asynchronous:true, evalScripts:true}); return false;
      }
  }
  
  function find_expense_amount(ind,province,tax_value){ 
  var amount = 0
  var quantity = 0
   var subtotal = 0 
   var taxtotal = 0 
   var grandtotal = 0 
   var amount_element = document.getElementsByClassName('amount')
   var product_element = document.getElementsByClassName('product')
   var quantity_element = document.getElementsByClassName('quantity')
   var tax_element = document.getElementsByClassName('taxes')
   var tax_selection  = document.getElementsByClassName('tax_selection')
   for (i=0; i< document.getElementsByClassName('amount').length; i++) {
   var tax = 0
   var amount = 0
   if (amount_element[i].value > 0 && quantity_element[i].value > 0) 
  amount=parseFloat(amount_element[i].value) * parseFloat(quantity_element[i].value);
  if (amount > 0 )
  product_element[i].value= round_to(amount,2);
	if (amount>0 && tax_selection[i].checked==true)
	{
	if (province=="PE" || province=="QC")
		{
			partial_tax1=parseFloat(amount*(0.05))
			partial_tax2=parseFloat((partial_tax1+amount)*((tax_value-5)/100));
			tax_element[i].value=round_to(partial_tax1+partial_tax2,2)
		}
		else
		{
   	tax_element[i].value = round_to((amount * (tax_value/100)),2);
		}
	}
	else
	{
	tax_element[i].value="";
	}
	if (tax_element[i].value > 0)
	var tax = parseFloat(tax_element[i].value)
	subtotal += amount
	taxtotal +=tax
  }
  grandtotal = taxtotal + subtotal
  $('total_amount').innerHTML = "$" + new NumberFormat(subtotal).toFormatted();
  $('total_tax').innerHTML = "$" + new NumberFormat(taxtotal).toFormatted();
  $('total').innerHTML = "$" + new NumberFormat(grandtotal).toFormatted();

}

function change_select_tag_options(account_type)
    {
    var select_options = $('journal_account_id');
    var accounts = group_accounts[account_type];
    var select_length = select_options.options.length
    for(i=0;i<select_length;i++)
    {
     select_options.options[0]=null;
    } 
    for(i=0;i<accounts.length;i++)
    {
      select_options.options[i]=new Option(accounts[i][0],accounts[i][1]);
     }
    }
    
   function check_payroll(check_value,payroll,action)
   {
   if(action=='')
   {
   $('selected_payroll').value= ''
   alert("This payroll is not added to the Expense Yet.Please Select a Valid Payroll to Process");
   return false;
   }
   else
   {
   //$('selected_payroll').value= check_value
   //var split_string=payroll.split("_")
   //$('payroll_data').value= payroll
   //$('action').value= action
   window.location='/employee/process_payroll/'+check_value 
   return true;
   }
  }

function get_line_item_numbers()
{
var line_items = document.getElementsByClassName('item_number');
 for(i=0;i<line_items.length;i++)
{
  line_items[i].innerHTML=i+1
}
}
  
String.prototype.trim = function() { return this.replace(/^\s+|\s+$/, ''); };

function check_contact_validation()
{
$('error1').hide();
$('error2').hide();
error_flag_name= false;
error_flag_type= false;
if ($('contact_company_name').value.trim() == "")
{
error_flag_name = true;
Element.show('error1')
}
 if ($('contact_type_client').checked == false &&  $('contact_type_vendor').checked == false && $('contact_type_other').checked == false)
{
error_flag_type=true;
Element.show('error2')
}
if(error_flag_name == false && error_flag_type==false)
{
window.onbeforeunload = "";
document.user.submit();
}
}

function ajax_expense_errors(submit_form,entry_type)
   {
     var error_flag1=false;
     var error_flag4=false;
     var total_amount = 0;
     var quantity_input_boxes=document.getElementsByClassName('quantity');
     var amount_input_boxes=document.getElementsByClassName('amount');
     var account_selection_boxes=document.getElementsByClassName('account');
     var quantity_error_flag='';
     var amount_error_flag='';
     var account_error_flag='';
    $('popup').hide();
    $('error1').hide();
    $('error2').hide();
    $('error3').hide();
    $('error4').hide();
    $('error5').hide();
    for (i=0; i< amount_input_boxes.length; i++) {
        if (isNaN(parseFloat(amount_input_boxes[i].value)))
        {
         amount_error_flag += i+1+', ';
        }
        if (isNaN(parseFloat(quantity_input_boxes[i].value)))
        {
         quantity_error_flag += i+1+', ';
        }
        if (account_selection_boxes[i].value=="")
        {
          account_error_flag += i+1+', ';
        }
      }
    account_field = $('transact_account_id');
    calendar_field = $('transact[invoice_date]');
    var find_sum_result= find_sum('product','taxes')[0];
    total_amount  = find_sum_result[0];
    error_flag3 = find_sum_result[2];
   if ((account_field.value=="") || (account_field.value=="add_new")) 
  {
    error_flag1=true;
    $('popup').show();
    $('error1').show();
    window.scrollTo(0, 0);
  }
    if (quantity_error_flag!='')
  {
    $('popup').show();
    $('error2').show();
    //$('error2').innerHTML="You must select a quantity for line item(s) - "+quantity_error_flag+"<br />";
    $('error2').innerHTML="You must specify a quantity for each line item <br />";
    window.scrollTo(0, 0);
  }
  if (amount_error_flag!='') 
  {
    $('popup').show();
    $('error3').show();
    //$('error3').innerHTML="You must specify a price for line item(s) - "+amount_error_flag+"<br />";
    $('error3').innerHTML="You must specify a price for each line item <br />";
    window.scrollTo(0, 0);
  }
  if (calendar_field.value=="") 
  {
    error_flag4=true;
    $('popup').show();
    $('error4').show();
    window.scrollTo(0, 0);
  }
  if (account_error_flag!='') 
  {
    $('popup').show();
    $('error5').show();
    window.scrollTo(0, 0);
  }

  if (error_flag1==false && amount_error_flag=='' && quantity_error_flag=='' && account_error_flag=='' && error_flag4==false) 
  {
new Ajax.Request('/expense/pay_options', {asynchronous:true, evalScripts:true}); return false;  } 
  }

String.prototype.trim = function() { return this.replace(/^\s+|\s+$/, ''); };

function emp_info_validation(submit_form){
 if ($('employee_payment_type').value=='wage')
{
	 if ($('employee_hours_per_week').value.trim() =='')
	{
		alert('please enter hours per week');return false;
	}
}
window.onbeforeunload = "";
submit_form.submit();
}

function validation()
{
 if ($('employee_payment_type').value=='wage')
{
 if ($('employee_hours_per_week').value.trim() =='')
{
 alert('please enter hours per week');return false;
}
else
{
return true;
}}
}

 String.prototype.trim = function() { return this.replace(/^\s+|\s+$/, ''); };

 function checking_account_balance(cpp_value,ei_value,tax_value,total_value)
 {
 
     var error_flag1=false;
     var error_flag2=false;
     var error_flag3=false;
     var error_flag4=false;

    $('errors').hide();
    $('error_cpp').hide();
    $('error_ei').hide();
    $('error_tax').hide();
    $('error_total').hide();

 if (cpp_value < $('other_cpp').value && $('other_cpp').value.trim() != "")
 {
 error_flag1=true;
 Element.show('process'); Element.hide('processing'); 
 $('errors').show();
 $('error_cpp').show();
 }
  if (ei_value < $('other_ei').value && $('other_ei').value.trim() != "" )
 {
 error_flag2=true;
 Element.show('process'); Element.hide('processing'); 
 $('errors').show();
 $('error_ei').show();
  }

 if (tax_value < $('other_tax').value && $('other_tax').value.trim() != "")
 {
 error_flag3=true;
 Element.show('process'); Element.hide('processing'); 
 $('errors').show(); 
 $('error_tax').show();
 }

  if (total_value < $('total').value && $('total').value.trim() != "") 
 {
 error_flag4=true;
 Element.show('process'); Element.hide('processing'); 
 $('errors').show(); 
 $('error_total').show();
  }
  if (error_flag1==false && error_flag2==false && error_flag3==false && error_flag4==false) 
  return true;
  else
  return false;
 }
 
    function check_error_display()
   {
   if ($('error_checkbox').checked==true)
   {
   new Ajax.Request('/account/error_display', {asynchronous:true, evalScripts:true}); return false;
   }
   }
   
   function check_add_new(value)
{
 if(value == "add_new")
 {
 new Ajax.Request('/blogs/add_new_category', {asynchronous:true, evalScripts:true});
 return false;
 }
 }

function round_to(number, precision)
{
return Math.round(number*(Math.pow(10,precision)))/(Math.pow(10,precision))
}

  function doNotConfirm(){
  // this method id used only in partial => recurring_options
  }

  function confirmExit()
  {
     if (needToConfirm)
    {
 		 var alert_message=false;
     var quantity_input_boxes=document.getElementsByClassName('quantity');
     var description_input_boxes=document.getElementsByClassName('description');
     var invoice_number_input_boxes=document.getElementsByClassName('invoice_number');
     var amount_input_boxes=document.getElementsByClassName('rate');
     var unit_input_boxes=document.getElementsByClassName('units');
     var contact_company_name=$('contact_company_name');
     var contact_last_name=$('contact_last_name');
     var contact_first_name=$('contact_first_name');
     var contact_title=$('contact_title');
     var contact_street1=$('contact_street1');
     var contact_street2=$('contact_street2');
     var contact_phone=$('contact_phone');
     var contact_fax=$('contact_fax');
     var contact_city=$('contact_city');
     var contact_email=$('contact_email');
     var contact_state=$('contact_state');
     var contact_website=$('contact_website');
     var contact_country=$('contact_country');
     var contact_zip=$('contact_zip');
     
     
    elements_array=[] 
		 elements=elements_array.concat(quantity_input_boxes, amount_input_boxes,description_input_boxes,unit_input_boxes,invoice_number_input_boxes,contact_company_name,contact_last_name,contact_first_name,contact_title,contact_street1,contact_street2,contact_phone,contact_fax,contact_city,contact_email,contact_state,contact_website,contact_country,contact_zip)
     

      for (i = 0; i < elements.length; i++)
      {
				elem=elements[i]
        if(elem){
          if ((elem.type == 'checkbox' || elem.type == 'radio') && elem.checked)
						alert_message=true;
          else if ((elem.type == 'text') && elem.value != '')
            alert_message=true;
          else if ((elem.type == 'select') && elem.selected != '')
            alert_message=true;
          }
      }
			if (alert_message)
        return "You have attempted to leave this page.  If you have made any changes to the fields without clicking the Save button, your changes will be lost.  Are you sure you want to exit this page?";
   }
  }
  

 function togle_other_business_type(){
   if( $('company_business_type').value=="Other" )$('div_business_other_type').show()
   else $('div_business_other_type').hide()
 }
  

function validate_user_name()
{
  nameExp = new RegExp(/(^[-A-Za-z\' ]+$)/)
  if($('user_first_name').value.match(nameExp)==null || $('user_last_name').value.match(nameExp)==null  ){
      alert('Fill valid User Name');
      return false
  }else
    {
       if($('user_title').value.match(nameExp)==null){
           alert('Please Enter Title');
           return false
        }else
          {
            return true
            }
 }
}


function check_province()
{
  comonyNameExp = new RegExp(/(^[-_A-Za-z\d\'\.!& ]+$)/)
  nameExp = new RegExp(/(^[-A-Za-z\' ]+$)/)
  zipExp = new RegExp(/^[ABCEGHJKLMNPRSTVXY]\d[A-Z] *\d[A-Z]\d$/)
  if($('company_business_number').value.strip()==""){alert('Enter Business number');return false; }
  else{
  if(($('company_name').value).match(comonyNameExp)==null){alert('Please enter valid company name');return false}
  else{
  if( ($('user_first_name') && $('user_first_name').value.match(nameExp)==null ) || ( $('user_last_name') && $('user_last_name').value.match(nameExp)==null  ) ){alert('Fill valid User Name');return false}
  else{
  if($('user_title') && $('user_title').value.match(nameExp)==null){alert('Please Enter Title');return false}
  else{
  if($('company_business_type').value=="Select" || ($('company_business_type').value=="Others" && $('company_business_other_type').value.strip()=="" ) ){alert('Please Select Business type');return false}
  else{
  if($('end_date').value=="" || $('end_month').value==""){alert('Select Financial year end');return false}
  else{
  if($('company_selected_province').value==""){alert('Please Select Province in tax setting');return false}
  else{
  if($('company_street1').value.strip()==""){alert('Please enter street1');return false}
  else{
  if($('company_city').value.strip()==""){alert('Enter your city name');return false}
  else{
  if($('company_state').value==""){alert('Please Select Province in mailing address');return false}
  //else{
  //if($('company_zip').value.match(zipExp)==null){alert('Enter valid Postal/Zip code (use capital letters)');return false}
  else{
	if( parseInt($('company_net_days').value) > 200){alert("Invoice Due Setting: \n\tNot allowed to be more than 200 Net days");return false}
	//else{
 	//if($('company_tax').value==$('origional_tax').value){return true;}
	//else{
	//if(confirm('You really want to change tax value ?')){return true;}
	//else{return false}
	// };
	 //};
   }; }; }; }; }; }; };}; }; };
 }
 
 function send_focus(focus_element,element_length,allowed,e){
    if(element_length>=allowed && check_num(e)){
          $(focus_element).value="";
          $(focus_element).focus();
          $('company_phone').value=($('short_phone1').value)+($('short_phone2').value)+($('short_phone3').value);
        return true;
        }
      else
        {
          return false
        }
 }

 function check_num(e) {
  var key;
  if(window.event)
    key = window.event.keyCode;     //IE
  else
    key = e.which;     //firefox
  if ((key > 47 && key <58 ) || (key ==8) || (key ==46) || (key ==0)  ) {
  return true;
  } else {
    return false;
  }
  }
 
function show_rec_options(opt){
		["daily", "weekly", "monthly", "yearly"].each(function(all_opt){$(all_opt).hide();});
		$(opt).show()
		$('recurring_patern').value=opt
	}							

function show_rec_end_options(choice){
$('recurring_end_option').value=choice
}

/*used in _recurring_options.rhtml*/
function validate_process(){
var flag = false;
		 $('patern').getElementsByClassName('rec_options').each( function(opt){
				if(opt.checked){ 
															 if(opt.value=='daily'){ flag = validate_daily() }
															 if(opt.value=='weekly'){ flag = validate_weekly() }
															 if(opt.value=='monthly'){ flag = validate_monthly() }
															 if(opt.value=='yearly'){ flag = validate_yearly() }
                               
															 if( parseInt( (new Date($('occurences_start_date').value ) ).getYear() ) <  parseInt(new Date().getYear())-1  ){
														 	      alert('Warning : START DATE can be within a year from now')
																	  flag=false;
																	}

                                if( new Date($('occurences_start_date').value) > new Date($('occurences_end_date').value) ){
															        alert('Warning : END DATE can not be smaller than START DATE')
																			flag=false;
															   }
																 
																if( parseInt( (new Date($('occurences_end_date').value ) ).getYear() ) >  parseInt(new Date().getYear())+5  ){
														 	      alert('Warning : END DATE can not be More than 5 years from now')
																	flag=false;
																	}
															 
															  if(flag==true){
																         window.onbeforeunload = doNotConfirm;
																				$('new_expense').submit()
																			}else{
																				return false
																			}
															}
			})
}

function validate_daily(){
var validate_daily_flag = false;
		if( ( ($('daily_interval').value).strip()=="" || parseInt($('daily_interval').value) > 0 )  ) {
			validate_daily_flag = true
		}else{
			alert('Daily Interval should be 1 or more than 1 day');
			validate_daily_flag = false;
		}
return validate_daily_flag		
} 

function validate_weekly(){
var validate_weekly_flag = false;
		if( ( ($('weekly_interval').value).strip()=="" || parseInt($('weekly_interval').value) > 0 )   &&    (checkWeeklyCheckbox() )  ) {
			validate_weekly_flag = true;
		}else{
			alert('checkbox Must be selected. if Interval required input positive number.');
			validate_weekly_flag = false;
		}
return validate_weekly_flag		
}

function checkWeeklyCheckbox(){
var check_flag = false;
var dayArray=["monday", "tuesday", "wednesday", "thursday", "friday", "saturday","sunday"]
dayArray.each(function(week_day){
							if($('weekly_'+week_day).checked == true){$('recurring_weekly_day').value=(dayArray.indexOf(week_day));check_flag = true }
					}
		)
return check_flag		
}

function validate_monthly(){
		var validate_monthly_flag = false;
		if(  ( ($('monthly_interval').value).strip()=="" || parseInt($('monthly_interval').value) > 0 )  &&  ( $('monthly_day').value != 'Select Day' )   ){$('recurring_monthly_day').value=$('monthly_day').value; validate_monthly_flag = true}else{alert("Day Must be selected from dropDown list. if Interval required input positive number")}
    return validate_monthly_flag
}

function validate_yearly(){
		var validate_yearly_flag = false;
		if( ( ($('yearly_interval').value).strip()=="" || parseInt($('yearly_interval').value) > 0) &&(  ( $('yearly_month').value != 'Select Month' ) && ( $('yearly_day').value != 'Select Day' ) ) ){$('recurring_yearly_day').value=$('yearly_day').value;$('recurring_yearly_month').value=$('yearly_month').value;validate_yearly_flag = true}else{alert("Month and Year Must be selected from dropDown list. if Interval required input positive number")}
		return validate_yearly_flag
}
/*used in _recurring_options.rhtml*/

 function change_select_options(){
 var cmp_state = $('company_state').value
  $('company_selected_province').value = cmp_state;
  get_provincial_tax(cmp_state)
  }
  
  function get_provincial_tax(v)
  {
  new Ajax.Request('/settings/get_provincial_tax?value='+v, {asynchronous:true, evalScripts:true}); return false;
  }