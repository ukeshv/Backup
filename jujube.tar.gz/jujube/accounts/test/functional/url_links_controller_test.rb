require File.dirname(__FILE__) + '/../test_helper'
require 'url_links_controller'

# Re-raise errors caught by the controller.
class UrlLinksController; def rescue_action(e) raise e end; end

class UrlLinksControllerTest < Test::Unit::TestCase
  fixtures :url_links

  def setup
    @controller = UrlLinksController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new

    @first_id = url_links(:first).id
  end

  def test_index
    get :index
    assert_response :success
    assert_template 'list'
  end

  def test_list
    get :list

    assert_response :success
    assert_template 'list'

    assert_not_nil assigns(:url_links)
  end

  def test_show
    get :show, :id => @first_id

    assert_response :success
    assert_template 'show'

    assert_not_nil assigns(:url_link)
    assert assigns(:url_link).valid?
  end

  def test_new
    get :new

    assert_response :success
    assert_template 'new'

    assert_not_nil assigns(:url_link)
  end

  def test_create
    num_url_links = UrlLink.count

    post :create, :url_link => {}

    assert_response :redirect
    assert_redirected_to :action => 'list'

    assert_equal num_url_links + 1, UrlLink.count
  end

  def test_edit
    get :edit, :id => @first_id

    assert_response :success
    assert_template 'edit'

    assert_not_nil assigns(:url_link)
    assert assigns(:url_link).valid?
  end

  def test_update
    post :update, :id => @first_id
    assert_response :redirect
    assert_redirected_to :action => 'show', :id => @first_id
  end

  def test_destroy
    assert_nothing_raised {
      UrlLink.find(@first_id)
    }

    post :destroy, :id => @first_id
    assert_response :redirect
    assert_redirected_to :action => 'list'

    assert_raise(ActiveRecord::RecordNotFound) {
      UrlLink.find(@first_id)
    }
  end
end
