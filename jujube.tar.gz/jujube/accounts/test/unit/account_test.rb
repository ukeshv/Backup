require File.dirname(__FILE__) + '/../test_helper'

class AccountTest < Test::Unit::TestCase
  fixtures :accounts

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
