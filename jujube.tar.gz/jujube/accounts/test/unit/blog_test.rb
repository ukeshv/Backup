require File.dirname(__FILE__) + '/../test_helper'

class BlogTest < Test::Unit::TestCase
  fixtures :blogs

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
