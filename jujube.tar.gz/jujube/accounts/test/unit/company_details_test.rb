require File.dirname(__FILE__) + '/../test_helper'

class CompanyDetailsTest < Test::Unit::TestCase
  fixtures :company_details

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
