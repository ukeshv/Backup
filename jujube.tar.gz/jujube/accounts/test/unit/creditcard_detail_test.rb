require File.dirname(__FILE__) + '/../test_helper'

class CreditcardDetailTest < Test::Unit::TestCase
  fixtures :creditcard_details

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
