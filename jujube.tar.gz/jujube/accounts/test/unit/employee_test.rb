require File.dirname(__FILE__) + '/../test_helper'

class EmployeeTest < Test::Unit::TestCase
  fixtures :employees

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
