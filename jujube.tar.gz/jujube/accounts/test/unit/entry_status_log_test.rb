require File.dirname(__FILE__) + '/../test_helper'

class EntryStatusLogTest < Test::Unit::TestCase
  fixtures :entry_status_logs

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
