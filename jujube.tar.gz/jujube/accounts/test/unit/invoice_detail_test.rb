require File.dirname(__FILE__) + '/../test_helper'

class InvoiceDetailTest < Test::Unit::TestCase
  fixtures :invoice_details

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
