require File.dirname(__FILE__) + '/../test_helper'

class NavigationLogTest < Test::Unit::TestCase
  fixtures :navigation_logs

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
