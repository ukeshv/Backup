require File.dirname(__FILE__) + '/../test_helper'

class PlanTest < Test::Unit::TestCase
  fixtures :plans

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
