require File.dirname(__FILE__) + '/../test_helper'

class RecurringTransactTest < Test::Unit::TestCase
  fixtures :recurring_transacts

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
