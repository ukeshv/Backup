require File.dirname(__FILE__) + '/../test_helper'

class UrlLinkTest < Test::Unit::TestCase
  fixtures :url_links

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
