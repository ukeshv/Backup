
require "csv"
class AdminController < ApplicationController
		before_filter :login_required ,:except => [:login]
		layout'index'
		protect_from_forgery :except => [:leave_list,:select_user]
		 
		def index
			@users = User.find(:all)
			@comp=CompOff.find(:all)
		
			if !params[:perform_action].nil? && params[:perform_action] == "change_status" && !params[:id].nil?
			@user=User.find(params[:id])
			@user.active_status == true ? @user.update_attribute(:active_status,0) : @user.update_attribute(:active_status,1)
			end
		
			@status= params[:active_status]
			params[:orderby] = "username" if params[:orderby].nil?
			params[:by]="asc"  if params[:by].nil? 
			@users=User.paginate :page=>params[:page], :per_page=>25, :order=>"#{params[:orderby]} #{params[:by]}"
		end
		
		def admin_list
			params[:orderby] = "username" if params[:orderby].nil?
			params[:by]="asc"  if params[:by].nil? 
			@admins=Admin.paginate :page=>params[:page], :per_page=>10, :order=>"#{params[:orderby]} #{params[:by]}"
		end
		
		def login
			return unless request.post?
			if !params[:username].blank? or !params[:password].blank?
					a=Admin.find(:first,:conditions=>['username = (?)',params[:username]])
				 if	a and a.username==params[:username] && a.password==params[:password]
					 session[:admin_id] = a.id 
					redirect_to :action=>"dashboard"
					flash.now[:notice]="Logged in successfully"
				 else
					 flash.now[:error]="Your Login and Password is not Correct"
					render :action=>'login'
				 end
			else
				flash.now[:error]="Please enter Login and Password"
				render :action=>'login'
				
			end
		end
		
		def new_admin
			@admin = Admin.new(params[:admin])
			return unless request.post?
			@admin.save!
			#AdminNotifier.deliver_signup_notification(@user)
			redirect_to(:controller => '/admin', :action => 'admin_list')
			flash[:notice] = "New Admin successfully created."
			rescue ActiveRecord::RecordInvalid
			  render :action => 'new_admin'
		 end
		
		def edit_admin
			@admin = Admin.find(params[:id])
			return unless request.post?
			@admin.username = params[:admin][:username]
			@admin.password = params[:admin][:password]
			@admin.email = params[:admin][:email]
			@admin.firstname = params[:admin][:firstname]
			@admin.lastname = params[:admin][:lastname]
			@admin.mobile_number = params[:admin][:mobile_number]
			@admin.save!
			redirect_to(:controller => '/admin', :action => 'admin_list')
			flash[:notice] = "Admin #{@admin.username} successfully updated."
			rescue ActiveRecord::RecordInvalid
			render :action => 'edit_admin'
		end
		
		def delete_admin
			@admin = Admin.find(params[:id]).destroy
			redirect_to(:controller => '/admin', :action => 'admin_list')
			flash[:notice] = "Admin #{@admin.username} successfully deleted."
		end
		
		
		
		def add_user
			@departments = Department.find(:all)
			@user = User.new(params[:user])
			return unless request.post?
			@user.date_of_birth = params[:date_of_birth]
			@user.date_of_joining = params[:date_of_joining]
			@user.step =  1
			@user.save!
				if @photo = Photo.find_by_user_id(@user.id)
					@photo.update_attributes(params[:photo])
				else
				photo = Photo.new(params[:photo])
				photo.user_id = @user.id
				photo.save        
				end
			AdminNotifier.deliver_signup_notification(@user)
			redirect_to(:controller => '/admin', :action => 'index')
			flash[:notice] = "New user successfully created."
			rescue ActiveRecord::RecordInvalid
			render :action => 'add_user'
		 end

		 
		 def edit_user
			@departments = Department.find(:all)
			@user = User.find(params[:id])
		        return unless request.post?
		        @user.username = params[:user][:username]
		        @user.email = params[:user][:email]
		        @user.firstname = params[:user][:firstname]
		        @user.lastname = params[:user][:lastname]
		        @user.password = params[:user][:password]
		        @user.password_confirmation = params[:user][:password_confirmation] 
			@user.emp_code=params[:user][:emp_code]
		        @user.mobile_number = params[:user][:mobile_number]
		        @user.phone_number = params[:user][:phone_number]
			@user.department_id = params[:user][:department_id]
		        @user.active_status = params[:user][:active_status] ? params[:user][:active_status] : 1
						@user.date_of_birth = params[:date_of_birth]
						@user.date_of_joining = params[:date_of_joining]
						@user.permanent_address = params[:user][:permanent_address]
						@user.present_address = params[:user][:present_address]
						@user.blood_group = params[:user][:blood_group]
						@user.emergency_contact = params[:user][:emergency_contact]
						@user.education = params[:user][:education]
						@user.designation_history = params[:user][:designation_history]
						@user.achievements = params[:user][:achievements]
						@user.participation = params[:user][:participation]
						@user.training_underground = params[:user][:training_underground]
						@user.available_days = params[:user][:available_days]
						#@user.comp_off_days = params[:user][:comp_off_days]
						@user.leave_carry_forward = params[:user][:leave_carry_forward]
						@user.step =  1
		        @user.save!
						if @photo = Photo.find_by_user_id(@user.id)
							@photo.update_attributes(params[:photo])
						else
							photo = Photo.new(params[:photo])
							photo.user_id = @user.id
							photo.save        
						end
		        #redirect_to(:controller => '/admin', :action => 'index',:page=>params[:page])
						redirect_to(:controller => '/admin', :action => 'edit_user',:id=>@user)
		        flash[:notice] = "User #{@user.username} successfully updated."
		        rescue ActiveRecord::RecordInvalid
		        render :action => 'edit_user'
		end
		
		 def remove
				photo = Photo.find(params[:id])
				@user = User.find_by_id(photo.user_id)
				photo.destroy
				redirect_to :action=>'edit_user',:id=>@user.id
		end
		
		def delete_user
			@user=User.find(params[:id]).destroy
			redirect_to(:controller => '/admin', :action => 'index', :page=>params[:page])
                        flash[:notice] = "User #{@user.username} successfully deleted."
		end
		       
		  def leave_list
                        @users=User.find(:all,:conditions=>['active_status = ?',1],:order=>'firstname')
                        @leaverequest=Leaverequest.find(:all)
                        params[:orderby] = "leave_from" if params[:orderby].nil?
                        params[:by] = "desc" if params[:by].nil?
                        if !params[:q].blank? || !params[:sel_user].blank?
                                if params[:q].nil?
                                        if !params[:sel_user].empty? && params[:sel_user][:id].blank?
                                        @user_leaverequests= Leaverequest.paginate :page=>params[:page], :per_page=>10,:order=>'user_id'
                                        else
                                        @user_leaverequests= Leaverequest.paginate :page=>params[:page], :per_page=>10, :conditions=>['user_id = (?)',params[:sel_user][:id]],:order=>'created_at desc'
                                        end
                                elsif params[:sel_user].nil?
                                        @user_leaverequests= Leaverequest.paginate :page=>params[:page], :per_page=>10,:conditions=>["(users.username like ? or users.firstname like ? or users.lastname like ? or users.email like ?)","%"+params[:q]+"%","%"+params[:q]+"%","%"+params[:q]+"%","%"+params[:q]+"%"],:include=>[:user],:order=>"#{params[:orderby]} #{params[:by]}"
                                end
                        else
                                #@user_leaverequests= Leaverequest.paginate :page=>params[:page], :per_page=>10,:order=>'created_at desc' 
                               unless params[:id].nil?
                                        if params[:id] == "dec" or params[:id] == "asc" or !params[:id]
                                        @add = "dec" if !params[:id] 
                                        params[:by] = "leave_from" if !params[:id]         
                                        @user_leaverequests = Leaverequest.paginate(:all,:order =>"#{params[:by]}",:per_page =>10,:page=>params[:page],:include=>'user')
                                        @add ="asc" if params[:id] == "asc" ;  @add = "dec"if params[:id] == "dec"
                                        end
                                 else
                                         @user_leaverequests= Leaverequest.paginate :page=>params[:page], :per_page=>10,:order=>'user_id' 
                                end        

                        end
                        session[:menu]="leave"
                 end
		
		def select_user
			if params[:name] != ""	
				@user_leaverequests= Leaverequest.paginate :page=>params[:page], :per_page=>10, :conditions=>['user_id = (?)',params[:name]]
			else
				@user_leaverequests= Leaverequest.paginate :page=>params[:page], :per_page=>10
			end
			render :update do |page|			
			page.replace_html 'user',:partial=>'user_list',:collection=>{:user_leaverequests=>@user_leaverequests}
			end
		end

		
		def logout
			@admin=Admin.find(1)
			session[:admin_id]=nil
			reset_session
			flash[:notice]="You have been logged out."
			redirect_to :action=>'login'
		end	
		
		
		def approve
			@leaverequest=Leaverequest.find(params[:id])			
			@user=User.find(@leaverequest.user_id)
			@leave = Leave.new
			@leave.user_id = @user.id
			@leave.leave_taken = Leaverequest.leave_taken(@user.id)
			@leave.available_days = $total_sanctioned_leaves - (Leaverequest.leave_taken(@user.id)).to_f
			@leave.save	
			@leaverequest.update_attribute(:approval_status,1) 
			AdminNotifier.deliver_approval_notification(@user,@leaverequest)
			if !session[:menu].nil? and session[:menu]=="dash"
				redirect_to :action=>'dashboard',:page=>params[:page]#,:sel_user=>params[:sel_user],:q=>params[:q]
			elsif !session[:menu].nil? and session[:menu]=="leave"
				redirect_to :action=>'leave_list',:page=>params[:page],:sel_user=>params[:sel_user],:q=>params[:q]
			elsif !session[:menu].nil? and session[:menu]=="report"
				redirect_to :action=>'report'
			else
				redirect_to :action=>'leave_list',:page=>params[:page],:sel_user=>params[:sel_user],:q=>params[:q]
			end			
			flash[:notice] = "Approved Leave"			
		end	
		
		
		def reject
			@leaverequest=Leaverequest.find(params[:id])
			@user=User.find(@leaverequest.user_id)
			@leaverequest.update_attribute(:approval_status,2) 
			AdminNotifier.deliver_rejected_notification(@user,@leaverequest)
			if !session[:menu].nil? and session[:menu]=="dash"
				redirect_to :action=>'dashboard',:page=>params[:page]#,:sel_user=>params[:sel_user],:q=>params[:q]
			elsif !session[:menu].nil? and session[:menu]=="leave"
				redirect_to :action=>'leave_list',:page=>params[:page],:sel_user=>params[:sel_user],:q=>params[:q]
			elsif !session[:menu].nil? and session[:menu]=="report"
				redirect_to :action=>'report'
			else
				redirect_to :action=>'leave_list',:page=>params[:page],:sel_user=>params[:sel_user],:q=>params[:q]
			end	
			flash[:notice] = "LOP Leave"
		end
		
		def show
			@leaverequest=Leaverequest.find(params[:id])
		end	
		
		def edit
			@users=User.find(:all,:conditions=>['active_status = ?',1],:order=>'firstname')
			@leaverequest=Leaverequest.find(params[:id])
			@user=User.find(:first,:conditions=>['id=?',@leaverequest.user_id])
			@rem=@template.remaining_leave(@user)
		end	
		
		def delete
			@user_leaverequests=Leaverequest.find(params[:id])
			@user_leaverequests.destroy
			flash[:notice]="Successfully deleted"
			if !session[:menu].nil? and session[:menu]=="dash"
				redirect_to :action=>'dashboard',:page=>params[:page]#,:sel_user=>params[:sel_user],:q=>params[:q]
			elsif !session[:menu].nil? and session[:menu]=="leave"
				redirect_to :action=>'leave_list',:page=>params[:page],:sel_user=>params[:sel_user],:q=>params[:q]
			elsif !session[:menu].nil? and session[:menu]=="report"
				redirect_to :action=>'report'#,:page=>params[:page],:sel_user=>params[:sel_user],:q=>params[:q]
			else
				redirect_to :action=>'leave_list',:page=>params[:page],:sel_user=>params[:sel_user],:q=>params[:q]
			end	
		end
		
		def update
			@users=User.find(:all,:conditions=>['active_status = ?',1],:order=>'firstname')
			@leaverequest = Leaverequest.find(params[:id])
			if @leaverequest.update_attributes(params[:leaverequest])
					@leaverequest.leave_from = params[:start_date]
					if @leaverequest.leave_type == "Half Day" || @leaverequest.leave_type == "Permission"
						@leaverequest.leave_to = params[:start_date]
					else
						@leaverequest.leave_to = params[:end_date]
					end
					paid=params[:leaverequest][:paid_leave]
					lop=params[:leaverequest][:lop]
					p=(paid.to_s).split('.')
					l=(lop.to_s).split('.')
					if (p[1]=='5'|| p[1]=='0' || p[1].nil?) && (l[1]=='5'|| l[1]=='0' || l[1].nil?)
					@sum=lop.to_f+ paid.to_f
					if @leaverequest.number_of_days==@sum
						@leaverequest.save
						flash[:notice] = 'Successfully Updated'						
					else
						@leaverequest.paid_leave=0
						@leaverequest.lop=0
						@leaverequest.save
						if @leaverequest.leave_type == "Permission"
						flash[:notice] = 'Successfully Updated'	
						else
						flash[:notice]="No of days not equal to sum of LOP and Paid leave"
						end
					end
					else
						@leaverequest.paid_leave=0
						@leaverequest.lop=0
						@leaverequest.save	
						flash[:notice]="Paid and LOP should end with '.0' or '.5'"
					end
				
					if params[:commit] == "Approve"
						approve
					elsif params[:commit] == "LOP"
						reject
					else
						update_leave			
					end	
			else
				render :action => 'edit'
			end
		end
		
		def update_leave
			if !session[:menu].nil? and session[:menu]=="dash"
				redirect_to :action=>'dashboard',:page=>params[:page]#,:sel_user=>params[:sel_user],:q=>params[:q]
			elsif !session[:menu].nil? and session[:menu]=="leave"
				redirect_to :action=>'leave_list',:page=>params[:page],:sel_user=>params[:sel_user],:q=>params[:q]
			elsif !session[:menu].nil? and session[:menu]=="report"
				redirect_to :action=>'report'
			else
				redirect_to :action=>'leave_list',:page=>params[:page],:sel_user=>params[:sel_user],:q=>params[:q]
			end	
		end
		
		def display_user		
			users=User.find(:all)
			if params[:sel_user] and !params[:sel_user][:id].nil? and !params[:sel_user][:id].empty?
				session[:sel_userid] = params[:sel_user][:id].to_i
			end
			params[:orderby] = "leave_from" if params[:orderby].nil?
			params[:by] = "desc" if params[:by].nil?
			if (params[:sel_user] and params[:sel_user][:id] != "") or (params[:from] and  params[:from] != 'collection')
				@single_element = true
				user = User.find( params[:sel_user] ? params[:sel_user][:id] : params[:from])
				user_leaverequests = user.leaverequests
				@user_leaverequests = user_leaverequests.paginate  :page => params[:page],  :per_page => 5 if user_leaverequests
				@user_name=user.username+" List"
				@from=params[:sel_user] ? params[:sel_user][:id] : params[:from]
			else			
				users = User.find(:all)
				@single_element = false
				user_leaverequests = users.collect{|user| [user.leaverequests] }.flatten
				@user_leaverequests = user_leaverequests.paginate  :page => params[:page],  :per_page => 5 if user_leaverequests
				@user_name="All user List"
				@from='collection'
			end
			
		end		
		
		def dashboard
			date=Date.new
			x=Date.today
			y= Date.today+15
		        @user_leaverequests=Leaverequest.paginate :page=>params[:page], :per_page=>10,:conditions=>['leave_from > ? and leave_from < ?', x,y],:order=>'leave_from'
			session[:menu]="dash"
			if @user_leaverequests.empty?
			redirect_to :action=>'leave_list'
			end	
		end	

		def change_password
			@user = User.find(params[:id])
			return unless request.post?
				if (!(params[:password]) || !params[:password_confirmation].blank?)
					@user.password_confirmation = params[:password_confirmation]
					@user.password = params[:password]        
					if @user.save
						AdminNotifier.deliver_chg_password_notification(@user)
						flash[:notice] = "Password successfully updated."
						redirect_to :controller=>'admin',:action=>'change_password'
					else
						flash.now[:error] = "An error occured, your password was not changed."
						render :action => 'change_password'
					end
				else
					flash.now[:error] = "Enter New Password and Confirm Password."
					render :action => 'change_password'      
				end
	        end
		
		def leave_request
			@users=User.find(:all,:conditions=>['active_status = ?',1],:order=>'firstname')
			@leaverequest = Leaverequest.new(params[:leaverequest])
			return unless request.post?
			@leaverequest.user_id = params[:leaverequest][:user_id]
			@leaverequest.leave_from = params[:start_date]
			@leaverequest.leave_to = params[:end_date]
			@leaverequest.approval_status = params[:leaverequest][:approval_status]
			@leaverequest.save!
                @user = User.find(@leaverequest.user_id)			
		UserNotifier.deliver_request_create_by_admin(@leaverequest,@user)
		if @leaverequest.number_of_days == 0.5
		subject= "Leave Request: half day on #{@leaverequest.leave_from.strftime('%d,%B %Y')}"
		elsif @leaverequest.number_of_days > 1
		subject= "Leave Request: #{@leaverequest.number_of_days.to_i} days from #{@leaverequest.leave_from.strftime('%d,%B %Y')}"
		elsif @leaverequest.number_of_days == 0
		subject= "Permission Request: #{@leaverequest.permission_hours} on #{@leaverequest.leave_from.strftime('%d,%B %Y')}"
		else
		subject= "Leave Request: 1 day on #{@leaverequest.leave_from.strftime('%d,%B %Y')}"
		end
                for x in params[:start_date].to_date..params[:end_date].to_date		
			Event.create(:user_id=>@user,:created_on=>x)
		end		
		LeaveNotifier.deliver_request_notification_create_by_admin(@leaverequest,@user,subject)			
			flash[:notice]= "Leave request created for #{@user.username}"			
			redirect_to :action => 'leave_list'
			rescue ActiveRecord::RecordInvalid
			render :action=>"leave_request"
		end
		 
           def comp_off
                @comp_off=CompOff.new(params[:comp_off])
		@users=User.find(:all,:conditions=>['active_status = ?',1],:order=>'firstname')				
		return unless request.post?	
                @comp_off.user_id=params[:comp_off][:user_id]
                @comp_off.date=params[:start_date]
		@comp_off.save!	
		@user=User.find(:first, :conditions=>['username=?',@comp_off.user.username])
		flash[:notice] = "CompOff Created for #{@user.username}"
		AdminNotifier.deliver_compoff_notification(@user,@comp_off)
		redirect_to :action => 'comp_off_list'
		rescue ActiveRecord::RecordInvalid
		render :action=>"comp_off"
	end
	
	def comp_off_list
		@compoff=CompOff.find(:all)
		@users=User.find(:all)
		#~ @user = User.find(params[:id])
		params[:orderby] = "user_id" if params[:orderby].nil?
		params[:by]="asc"  if params[:by].nil? 
		@compoff=CompOff.paginate :page=>params[:page], :per_page=>10, :order=>"#{params[:orderby]} #{params[:by]}"
		return unless request.post?
		redirect_to :action => 'comp_off_list'
		rescue ActiveRecord::RecordInvalid
	        render :action=>"comp_off_list"
	end	
	 
	 def edit_compoff		
		 @compoff=CompOff.find(params[:id])
	         @users=User.find(:all,:conditions=>['active_status = ?',1],:order=>'firstname')
		 @user = User.find(:first,:conditions => ['id = ?', @compoff.user_id])
		 return unless request.put?
		 @compoff.update_attributes(params[:compoff])
		 @compoff.date=params[:date]
		 @compoff.save
		 redirect_to(:controller => '/admin', :action => 'comp_off_list')
		        flash[:notice] = "User #{@user.username} successfully updated."
		        rescue ActiveRecord::RecordInvalid
		        render :action => 'comp_off_list'
	 end

         def display_compoff
		@compoff=CompOff.find(params[:id])
		@users=User.find(:all,:conditions=>['active_status = ?',1],:order=>'firstname')
		@given=User.find(:first, :conditions=>['id=?',@compoff.given_by])
	        return unless request.post? 
		redirect_to :action => 'comp_off_list'
		 rescue ActiveRecord::RecordInvalid
	         render :action=>"comp_off"
	 end
  
         def delete_compoff
		@compoff=CompOff.find(params[:id]).destroy
		redirect_to(:controller => '/admin', :action => 'comp_off_list', :page=>params[:page])
                flash[:notice] = "User #{@compoff.user_id} successfully deleted." 
         end
	 
		 
	
	def report
		@days_list = [ ]
		@monthnames=["","January","February","March","April","May","June","July","August","September","October","November","December"]
		if request.post?       
		@month = params[:date][:month]
		@year = params[:date][:year]       
		days=(Date.new(@year.to_i,12,31).to_date<<(12-@month.to_i)).day
		@monthname=@monthnames[@month.to_i]
		else   
		days = Date.today.day
		@month = Date.today.month
		@year = Date.today.year
		@monthname=@monthnames[@month.to_i]
		end
		@current_month_days = days
		@user_leaverequests=[]
			for i in 1 .. days.to_i 
			Leaverequest.find(:all,:conditions=>['DATE_FORMAT(created_at,"%Y-%c-%e") = ? ',"#{@year}-#{@month}-#{i}"]).collect{|x|  @user_leaverequests << x}
		        end
		session[:menu]="report"
	end
		
		def advance_search
			@users=User.find(:all,:conditions=>['active_status = ?',1],:order=>'firstname')
			return unless request.post? 
			@leave_type=params[:leave_type]
			@search_user=params[:sel_user][:id]
			@start_date=params[:start_date].to_date
			@end_date=params[:end_date].to_date
			if @leave_type == "Leave"
				type = "Day"
			else
				type = "Permission"
                        end 				
			if @search_user.blank?
				if @leave_type == "Both"
					@user_leaverequests=Leaverequest.find(:all,:conditions=>['leave_from >= ? and leave_from <= ?',@start_date,@end_date],:order=>'user_id')
				else
					@user_leaverequests=Leaverequest.find(:all,:conditions=>['leave_from >= ? and leave_from <= ? and leave_type like ?',@start_date,@end_date,"%"+type+"%"],:order=>'user_id')
				end	
			else
				if @leave_type == "Both"
					@user_leaverequests=Leaverequest.find(:all,:conditions=>['leave_from >= ? and leave_from <= ? and user_id = ?',@start_date,@end_date,@search_user],:order=>'user_id')
				else
					@user_leaverequests=Leaverequest.find(:all,:conditions=>['leave_from >= ? and leave_from <= ? and user_id = ? and leave_type like ?',@start_date,@end_date,@search_user,"%"+type+"%"],:order=>'user_id')
				end	
				end
		end
		
		def monthly_report
			@users = User.find(:all)
			if !params[:perform_action].nil? && params[:perform_action] == "change_status" && !params[:id].nil?
			@user=User.find(params[:id])
			@user.active_status == true ? @user.update_attribute(:active_status,0) : @user.update_attribute(:active_status,1)
			end
			params[:orderby] = "username" if params[:orderby].nil?
			params[:by]="asc"  if params[:by].nil? 
			@users=User.paginate :page=>params[:page], :per_page=>25, :order=>"#{params[:orderby]} #{params[:by]}"
			@days_list = [ ]
		@monthnames=["","January","February","March","April","May","June","July","August","September","October","November","December"]
		if request.post?       
		@month = params[:date][:month]
		@year = params[:date][:year]       
		days=(Date.new(@year.to_i,12,31).to_date<<(12-@month.to_i)).day
		@monthname=@monthnames[@month.to_i]
		else   
		@month = Date.today.month
		@year = Date.today.year
		@monthname=@monthnames[@month.to_i]
		end
		session[:menu]="report"
		
		end
				
		def export_monthly_leave
			@users = User.find(:all)
			if request.post?       
			@month = params[:date][:month]
			@year = params[:date][:year]       
			days=(Date.new(@year.to_i,12,31).to_date<<(12-@month.to_i)).day
			@monthname=@monthnames[@month.to_i]
			else   
			@month = Date.today.month
			@year = Date.today.year
			end
			report = StringIO.new
			CSV::Writer.generate(report, ',') do |csv|
			csv << %w(EmpID
					UserName
					FirstName
					LastName
					Tot.Avl.Leave
					LeaveTaken
					PaidLeave
					LOP
					Rem.Leave
			)
			for user in @users 
			csv << [user.id,
			user.username,
			user.firstname,
			user.lastname,
			@template.month_availleave(user,@month,@year),
			@template.month_leavetaken(user,@month,@year),
			@template.month_paidleave(user,@month,@year),
			@template.month_lopleave(user,@month,@year),
			@template.month_remleave(user,@month,@year),
			]
			end
			end
			report.rewind
			send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'leave.csv')
		end
		
		 def export_leave
			 @leave_type=params[:leave_type]
			 @start_date=params[:start_date]
			 @end_date=params[:end_date]
			 @search_user=params[:id]
				if @leave_type == "Leave"
				type = "Day"
			      else
				type = "Permission"
                             end 				
			if @search_user.blank?
				if @leave_type == "Both"
					@user_leaverequests=Leaverequest.find(:all,:conditions=>['leave_from >= ? and leave_from <= ?',@start_date,@end_date],:order=>'user_id')
				else
					@user_leaverequests=Leaverequest.find(:all,:conditions=>['leave_from >= ? and leave_from <= ? and leave_type like ?',@start_date,@end_date,"%"+type+"%"],:order=>'user_id')
				end	
			else
				if @leave_type == "Both"
					@user_leaverequests=Leaverequest.find(:all,:conditions=>['leave_from >= ? and leave_from <= ? and user_id = ?',@start_date,@end_date,@search_user],:order=>'user_id')
				else
					@user_leaverequests=Leaverequest.find(:all,:conditions=>['leave_from >= ? and leave_from <= ? and user_id = ? and leave_type like ?',@start_date,@end_date,@search_user,"%"+type+"%"],:order=>'user_id')
				end	
				end
			report = StringIO.new
			CSV::Writer.generate(report, ',') do |csv|
			csv << %w(Fullname
			Leavefrom
			Leaverto
			Days/Hours
			Reason
			CurrentProject
			AlternateTeamMember
			AppliedOn
			Status
			LeaveType
			)
			@user_leaverequests.each do |leave_request|
			if leave_request.leave_type ==	 "Permission"
				type = leave_request.permission_hours
			else
				days = (leave_request.number_of_days.to_s).split('.')
					if days[1].to_i == 0
						no_days = days[0]
					else
						no_days = leave_request.number_of_days
					end 
				type = no_days
			end	
			if leave_request.approval_status == 0
				status = "Pending"
			elsif leave_request.approval_status == 1
				status = "Approved"
			else
				status = "LOP"
			end	
			if leave_request.alternate_user
				alternate_user = leave_request.alternate_user.full_name
			else
				alternate_user = ""
                        end 				
			csv << [leave_request.user.full_name,
			leave_request.leave_from,
			leave_request.leave_to,
			type,
			leave_request.reason,
			leave_request.currently_working_project,
			alternate_user,
			leave_request.created_at.strftime("%d-%m-%y "),
			leave_request.created_at.strftime("%d-%m-%y "),
			status
			]
			end
			end
			report.rewind
			send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'leave.csv')
		end
		
		def export_manage_user
			@users = User.find(:all)
			report = StringIO.new
			CSV::Writer.generate(report, ',') do |csv|
			csv << %w(EmpID
					UserName
					FirstName
					LastName
					Department
					Avl.leave
					Comp-off
					LeaveTaken
					Carryfwd
					Tot.Avl.Leave
					Pending
					LOP
					Rem.Leave)
			for user in @users 
			csv << [user.id,
			user.username,
			user.firstname,
			user.lastname,
			user.department.name,
			user.available_days,
			@template.compoff_leave(user),
			user.leave_carry_forward,
			@template.total_leave(user),
			@template.leave_taken(user),
			@template.pending_leave(user),
			@template.lop_leave(user),
			@template.remaining_leave(user)
			]
			end
			end

			report.rewind
			send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'leave.csv')
		end
		
def remaining_count
	@user = User.find_by_id(params[:user_id])
	@rem=@template.remaining_leave(@user) if !@user.nil?
	if !@user.nil?
		render :update do |page|
			page[:rem_hidden_value].value = @rem
			page[:rem_val_show].innerHTML = "<font color = 'green'>(Remaining Leave: #{@rem} days)</font>"
		end	
	else
		render :update do |page|
			page[:rem_hidden_value].value = ""
			page[:rem_val_show].innerHTML = ""
		end	
	end	
end	

end
