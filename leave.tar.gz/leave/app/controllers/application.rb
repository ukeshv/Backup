# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.
require 'date'
class ApplicationController < ActionController::Base   
  include ExceptionNotifiable   
  local_addresses.clear  
  helper :all # include all helpers, all the time


  # See ActionController::RequestForgeryProtection for details
  # Uncomment the :secret if you're not using the cookie session store
 # protect_from_forgery # :secret => 'aab3c77fe8bf94d39ab924a09b20ca04'
  include AuthenticatedSystem
  before_filter :login_from_cookie
  	

def login_required
	if  session[:admin_id].nil?
		redirect_to :controller=>'/admin',:action=>'login'
	end
end

def user_login
	if session[:user_id].nil?
		redirect_to :controller =>'/user',:action=>'login'
	end
end

 def find_previous_next
    if params[:year] != nil and params[:year] != "" and params[:month] != "" and params[:month] != nil
      yr = params[:year]
      mth = params[:month]
      if params[:day] != nil and params[:day] != ""
        dy = params[:day]
      else
        dy = 1
      end
      if params[:hour] != nil and params[:hour] != ""
        hour = params[:hour]
      else
        hour = 0
      end
      if params[:minute] != nil and params[:minute] != ""
        min = params[:minute]
      else
        min = 0
      end
      now = DateTime.new(yr.to_i, mth.to_i, dy.to_i, hour.to_i, min.to_i, 0)     
      @view = params[:view]
    else
      now = DateTime.now      
    end   
    @now = now
    @year = now.year
    @month = now.month
    @day = now.day              
    @pvday = now - 1
    @nxtday = now + 1
    @begin_week = now.beginning_of_week - 1
    @end_week = now.beginning_of_week + 5 
    @pvweek =  now-6
    @nxtweek = now+6
    @pvmonth = DateTime.new(now.year, now.month, 1) << (1)
    @nxtmonth = DateTime.new(now.year, now.month, 1) >> (1)
    @pvyear = DateTime.new(now.year, now.month, 1) << (12)
    @nxtyear = DateTime.new(now.year, now.month, 1) >> (12)
  end

end
