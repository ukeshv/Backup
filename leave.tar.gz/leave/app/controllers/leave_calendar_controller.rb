class LeaveCalendarController < ApplicationController
	
 def index    
    find_previous_next     
  end
	
	def change    
    find_previous_next
    render :action => 'index', :view=>@view
  end
	
	def showyear
    begin
      find_previous_next
    rescue Exception => e
      #puts e
    end  
  end
  
  def showweek
    begin        
      find_previous_next
      wk = Date.civil(@year, @month, @day)      
      tdy = wk.strftime("%w")
      case tdy
      when '0'
        @first = wk
        @last = wk+6
      when '1'            
        @first = wk-1      
        @last = wk+5      
      when '2'
        @first = wk-2
        @last = wk+4
      when '3'
        @first = wk-3
        @last = wk+3
      when '4'
        @first = wk-4
        @last = wk+2
      when '5'
        @first = wk-5
        @last = wk+1
      when '6'
        @first = wk-6
        @last = wk
      end
      @pvweek =  @now-6
      @nxtweek = @now+6
      frm_dt = @begin_week.strftime("%Y-%m-%d")      
      to_dt = @end_week.strftime("%Y-%m-%d")   
      @events = Event.find(:all, :conditions=>"created_on between '"+frm_dt.to_s+"' and '" + to_dt.to_s + "'")      
    rescue Exception => e
      #puts e
    end  
  end 
  
  def showday
    begin        
      find_previous_next      
      wk = Date.civil(@year, @month, @day)            
      @first=wk
      @last=wk                 
      sday = wk.strftime("%Y-%m-%d")       
      @events = Event.find(:all, :conditions=>"created_on like '"+sday.to_s+"%%'")       
    rescue Exception => e
      #puts e
    end  
  end
	
end
