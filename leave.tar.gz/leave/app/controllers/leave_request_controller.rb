class LeaveRequestController < ApplicationController
        before_filter :user_login
	layout'user_index'
	
	def new_leaverequest
		@users=User.find(:all,:conditions=>['active_status = ? and id != ?',1,current_user.id],:order=>'firstname')
		@leaverequest = Leaverequest.new(params[:leaverequest])
		#~ @leave=params[:paid-leave]
		return unless request.post?		
		@leaverequest.paid_leave =  @leaverequest.number_of_days
		@leaverequest.user_id = current_user.id
		@leaverequest.leave_from = params[:start_date]
		@leaverequest.leave_to = params[:end_date]
		@leaverequest.approval_status=0
		#@leaverequest.step = (!params[:leaverequest][:permission_hours].nil? || !params[:leaverequest][:permission_hours].empty?) ? 2 : 1
		@leaverequest.save!	
		@start_date=params[:start_date]
		@end_date=params[:end_date]
		@template.monthcal(@start_date,@end_date)
		UserNotifier.deliver_request_sent(@leaverequest,current_user)
		if @leaverequest.number_of_days == 0.5
		subject= "Leave Request: half day on #{@leaverequest.leave_from.strftime('%d,%B %Y')}"
		elsif @leaverequest.number_of_days > 1
		subject= "Leave Request: #{@leaverequest.number_of_days.to_i} days from #{@leaverequest.leave_from.strftime('%d,%B %Y')}"
		elsif @leaverequest.number_of_days == 0
		subject= "Permission Request: #{@leaverequest.permission_hours} on #{@leaverequest.leave_from.strftime('%d,%B %Y')}"
		else
		subject= "Leave Request: 1 day on #{@leaverequest.leave_from.strftime('%d,%B %Y')}"
		end
		for x in params[:start_date].to_date..params[:end_date].to_date		
		Event.create(:user_id=>current_user.id,:created_on=>x)
		end
		LeaveNotifier.deliver_request_notification(@leaverequest,current_user,subject)
		redirect_to :action => 'send_request'
		rescue ActiveRecord::RecordInvalid
		render :action=>"new_leaverequest"
	 end	
	 
	 def leave_history
		 unless params[:orderby].nil? || params[:by].nil?
		 params[:orderby] = "leave_from" if params[:orderby].nil?
		 params[:by] = "desc" if params[:by].nil?
			@user_leaverequests= Leaverequest.paginate :page=>params[:page], :per_page=>10, :conditions=> ['user_id = ?', session[:user_id]] ,:order=>"#{params[:orderby]} #{params[:by]}"
		 else
			 @user_leaverequests= Leaverequest.paginate :page=>params[:page], :per_page=>10, :conditions=> ['user_id = ?', session[:user_id]] ,:order=>"created_at desc"
		end
	end
	
	
	def new_comp_offrequest
		@users=User.find(:all,:conditions=>['active_status = ? and id != ?',1,current_user.id],:order=>'firstname')
	end
		
end
