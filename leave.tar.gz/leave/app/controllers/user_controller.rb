class UserController < ApplicationController
	before_filter :user_login ,:except => [:login,:forgot_password,:reset_password]
	  layout'user_index'
		def index
			redirect_to(:action=>'login')
		end

		def login
		
			if session[:user_id]
				redirect_back_or_default(:controller => 'user', :action => 'view_profile')
			else	
			return unless request.post?
			unless params[:username].blank? || params[:password].blank?
				self.current_user = User.authenticate(params[:username], params[:password]) 
				
				if current_user and logged_in?
					if current_user.active_status == true
						session[:user_id] = current_user.id
						redirect_back_or_default(:controller => 'user', :action => 'view_profile')
						flash.now[:notice] = "Logged in successfully"
					else
						flash.now[:error] = "Your Account is not Activated"
					end
				else
					flash.now[:error] = "Please enter valid Username and Password !"	
					
				end	
			else
				flash.now[:error] = "Enter Username and Password"
			end
			end
		end


		def logout
			self.current_user if logged_in?
			@user=User.find(session[:user_id])
			@user.update_attribute(:last_loggedin,Time.now.asctime)
			session[:user_id] = nil
			cookies.delete :auth_token
			reset_session
			flash[:notice] = "You have been logged out."
			redirect_back_or_default(:controller => 'user', :action => 'login')
		end


		def view_profile
			@user = User.find(session[:user_id]) 
			@photo = Photo.find_by_user_id(session[:user_id])
		end
		

		def edit_profile
			unless session[:user_id].nil?
				@user = User.find(session[:user_id])
				return unless request.post?	
				@user.date_of_birth = params[:date_of_birth]
			        @user.date_of_joining = params[:date_of_joining]
				@user.save
				@user.step =0
					if @user.update_attributes(params[:user])
								if @photo = Photo.find_by_user_id(session[:user_id])
										@photo.update_attributes(params[:photo])
								else
										photo = Photo.new(params[:photo])
										photo.user_id = session[:user_id]
										photo.save        
								end
							flash.now[:notice]="Successfully updated"
					else
							render :action=>'edit_profile'
					end
			else
					redirect_to :action=>'login'
			end
		end	
		
		def remove
			Photo.find(params[:id]).destroy
			#if params[:act_name] == "edit"
			redirect_to :action=>'edit_profile'
			#else
				#redirect_to :action=>'view_profile'
				#end
			end

		def change_password
			return unless request.post?
			if User.authenticate(current_user.username, params[:old_password])
				if (!(params[:old_password]) || !params[:password_confirmation].blank?)
					current_user.password_confirmation = params[:password_confirmation]
					current_user.password = params[:password]        
					if current_user.save
						flash[:notice] = "Password successfully updated."
						redirect_to :controller=>'user',:action=>'change_password'
					else
						flash.now[:error] = "An error occured, your password was not changed."
						render :action => 'change_password'
					end
				else
					flash.now[:error] = "Enter New Password and Confirm Password."
					render :action => 'change_password'      
				end
			else
				flash.now[:error] = "Your current password is incorrect."
				render :action => 'change_password'
			end 
		end    


		def dashboard
			@user=User.find(session[:user_id])
		end
		
		
		def forgot_password
			
		return unless request.post?
		unless params[:email].blank?
			if @user = User.find_by_email(params[:email])
				@user.forgot_password
				@user.save
				UserNotifier.deliver_forgot_password(@user)
				redirect_to :controller => 'user', :action => 'login'
				flash[:notice] = "Password reset link has been sent to your email address" 
			else
				flash.now[:notice] = "Could not find a user with that email address" 
			end
		else
			flash.now[:error]="Required field cannot be left blank"
		end
	end
	
	
	def reset_password
		@user = User.find_by_password_reset_code(params[:id])
		session[:reset_code]=params[:id]
		unless @user.nil?
		return unless request.post?	
			unless params[:password].blank? || params[:password_confirmation].blank?
				if params[:password] == params[:password_confirmation]
					if @user.update_attributes(:password=>params[:password], :password_confirmation=>params[:password_confirmation], :password_reset_code=> "NULL")
						flash[:notice] = "Password is successfully reset"
						UserNotifier.deliver_reset_password(@user)
						redirect_to :action=>'login'
						end
					else
						flash.now[:error] = "Mismatch in Password and Confirmation Password."
					end 
					
			else
				flash.now[:error]="Required field cannot be left blank"	
			end	
		else
			redirect_to :action=>'login'
			flash[:error]="Unable to use the Password Reset link more than ones."	
		end
	end
	
	def view_details
		
		@compoffs = CompOff.find(:all, :conditions=>["user_id=?",params[:id]])
		@user = User.find_by_id(params[:id])
		
	end
	
	

end
