# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper

def display_days(n_days)
	days = (n_days.to_s).split('.')
	if days[1].to_i == 0
		no_days = days[0]
	else
		no_days = n_days
	end
return no_days
end

def remaining_leave(user)
	total = user.available_days + compoff_leave(user) + user.leave_carry_forward
	leave_taken = Leaverequest.find(:all,:select=>"SUM(number_of_days) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and user_id = ?", $fy_start_from, user.id])[0].nod.to_f
	remaining = total - leave_taken + lop_leave(user).to_f
	days = (remaining.to_s).split('.')
	if days[1].to_i == 0
		no_days = days[0]
	else
		no_days = remaining
	end
return no_days
end

def total_leave(user)
	total = user.available_days + compoff_leave(user) + user.leave_carry_forward
  days = (total.to_s).split('.')
	if days[1].to_i == 0
		no_days = days[0]
	else
		no_days = total
	end
return no_days
end

def leave_taken(user)
	leave_taken = Leaverequest.find(:all,:select=>"SUM(number_of_days) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and user_id = ?", $fy_start_from, user.id])[0].nod.to_f
	days = (leave_taken.to_s).split('.')
	if days[1].to_i == 0
		no_days = days[0]
	else
		no_days = leave_taken
	end
return no_days
end

def pending_leave(user)
	leave_taken = Leaverequest.find(:all,:select=>"SUM(number_of_days) as nod",:conditions=>["approval_status = '0' and leave_from >= ? and user_id = ?", $fy_start_from, user.id])[0].nod.to_f
	days = (leave_taken.to_s).split('.')
	if days[1].to_i == 0
		no_days = days[0]
	else
		no_days = leave_taken
	end
return no_days
end

def lop_leave(user) 
	leave_taken = Leaverequest.find(:all,:select=>"SUM(lop) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and user_id = ?",$fy_start_from, user.id])[0].nod.to_f
	days = (leave_taken.to_s).split('.')
	if days[1].to_i == 0
		no_days = days[0]
	else
		no_days = leave_taken
	end
	return no_days
end

def compoff_leave(user)
	return user.comp_offs.sum("no_of_days")  	  
end 	

def paid_leave(user)
	leave_taken = Leaverequest.find(:all,:select=>"SUM(paid_leave) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and user_id = ?",$fy_start_from, user.id])[0].nod.to_f
	days = (leave_taken.to_s).split('.')
	if days[1].to_i == 0
		no_days = days[0]
	else
		no_days = leave_taken
	end
	return no_days
end

#~ def  month_leavetaken(user,month,year)
	#~ month1=month.to_i+1
	#~ month1="#{year}-#{month1}-01"
	#~ month = "#{year}-#{month}-01"
	#~ leave_taken = Leaverequest.find(:all,:select=>"SUM(number_of_days) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and leave_from < ? and user_id = ?",month,month1,user.id])[0].nod.to_f
	#~ return leave_taken
#~ end

def  month_paidleave(user,month,year)
	month1=month.to_i+1
	month1="#{year}-#{month1}-01"
	month = "#{year}-#{month}-01"
	paidleave = Leaverequest.find(:all,:select=>"SUM(paid_leave) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and leave_from < ? and user_id = ?",month,month1,user.id])[0].nod.to_f
	return paidleave
end

def  month_lopleave(user,month,year)
	month1=month.to_i+1
	month1="#{year}-#{month1}-01"
	month = "#{year}-#{month}-01"
	lopleave= Leaverequest.find(:all,:select=>"SUM(lop) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and leave_from < ? and user_id = ?",month,month1,user.id])[0].nod.to_f
	return lopleave
end

def month_availleave(user,month,year,monthname)
                allmonth=month
                month="#{year}-#{month}-01"
                monthadd1=allmonth.to_i + 1
                monthadd1="#{year}-#{monthadd1}-01"
                monthsub1=allmonth.to_i-1
                monthsub1="#{year}-#{monthsub1}-01"
                monthsub2=allmonth.to_i - 2
                monthsub2="#{year}-#{monthsub2}-01"
                months=[["April","May","June"],["July","August","September"],["October","November","December"],["January","February","March"]]
        if monthname==months[0][0] || monthname==months[1][0] || monthname==months[2][0] || monthname==months[3][0] 
                leave_taken = Leaverequest.find(:all,:select=>"SUM(paid_leave) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and leave_from < ? and user_id = ?",month,monthadd1,user.id])[0].nod.to_f
                comp=CompOff.find(:all,:select=>"SUM(no_of_days) as nod",:conditions=>['user_id=? and date >= ? and date < ?',user.id,month,monthadd1])[0].nod.to_f
                return ((user.available_days+comp+user.leave_carry_forward)-leave_taken)
        elsif monthname==months[0][1] || monthname==months[1][1] || monthname==months[2][1] || monthname==months[3][1]
                leave_taken = Leaverequest.find(:all,:select=>"SUM(paid_leave) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and leave_from < ? and user_id = ?",monthsub1,monthadd1,user.id])[0].nod.to_f
                comp=CompOff.find(:all,:select=>"SUM(no_of_days) as nod",:conditions=>['user_id=? and date >= ? and date < ?',user.id,monthsub1,monthadd1])[0].nod.to_f
                 return ((user.available_days+comp+user.leave_carry_forward)-leave_taken)
        elsif monthname==months[0][2] || monthname==months[1][2] || monthname==months[2][2] || monthname==months[3][2]
                leave_taken = Leaverequest.find(:all,:select=>"SUM(paid_leave) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and leave_from < ? and user_id = ?",monthsub2,monthadd1,user.id])[0].nod.to_f
                comp=CompOff.find(:all,:select=>"SUM(no_of_days) as nod",:conditions=>['user_id=? and date >= ? and date < ?',user.id,monthsub2,monthadd1])[0].nod.to_f
                return ((user.available_days+comp+user.leave_carry_forward)-leave_taken)
        end       
end

 def month_remleave(user,month,year,monthname)
	rem=month_availleave(user,month,year,monthname)-month_leavetaken(user,month,year)
	return rem
end

def month_leavetaken(user,month,year)
	totdays=(Date.new(year.to_i,12,31).to_date<<(12-month.to_i)).day
	allmonth=month
	next_month=month.to_i+1
	next_month="#{year}-#{next_month}-01"
	prev_month=month.to_i - 1
	prev_month="#{year}-#{prev_month}-01"
	month = "#{year}-#{month}-01"
	leave_taken = Leaverequest.find(:all,:select=>"SUM(number_of_days) as nod",:conditions=>["approval_status = '1' and leave_from >= ? and leave_from < ? and user_id = ?",month,next_month,user.id])[0].nod.to_f
	leave_days= Leaverequest.find(:all, :conditions=>["approval_status = '1' and leave_from >= ? and leave_from < ? and user_id = ?",prev_month,next_month,user.id])
	leave_days.each do|l|		
		l_from=l.leave_from
		l_par1=l_from.to_s.split(/-/)
		l_to=l.leave_to
		l_par2=l_to.to_s.split(/-/)
		if l_par1[1]==l_par2[1]
			leave_taken-=0
		else
			if allmonth.to_i==l_par1[1].to_i
				leave_taken-=l_par2[2].to_i	
			else
				leave_taken+=(totdays - l_par1[2].to_i)
			end
		end		
	end
	return leave_taken
end


end
