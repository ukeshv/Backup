require 'date'
require 'date'

module LeaveCalendarHelper

 def monthtab(options = {}, &block)
    raise(ArgumentError, "No year given")  unless options.has_key?(:year)
    raise(ArgumentError, "No month given") unless options.has_key?(:month)

    block                        ||= Proc.new {|d| nil}

    defaults = {
      :table_class => 'calendar1',
      :month_name_class => 'monthName1',
      :other_month_class => 'otherMonth1',
      :day_name_class => 'dayName1',
      :day_class => 'day1',
      :abbrev => (0..-1),
      :first_day_of_week => 0,
      :accessible => false,
      :show_today => true,
      :previous_month_text => '<',
      :next_month_text => '>',
      :previous_year_text => '<<',
      :next_year_text => '>>'
    }
    options = defaults.merge options

    first = Date.civil(options[:year], options[:month], 1)
    last = Date.civil(options[:year], options[:month], -1)

    first_weekday = first_day_of_week(options[:first_day_of_week])
    last_weekday = last_day_of_week(options[:first_day_of_week])
    
    day_names = Date::DAYNAMES.dup
    first_weekday.times do
      day_names.push(day_names.shift)
    end

    # TODO Use some kind of builder instead of straight HTML
    cal = %(<table class="#{options[:table_class]}" border="0" cellspacing="15" cellpadding="15" width="100%" height="100%">)

=begin    
    cal << %(<thead><tr>)
    if options[:previous_month_text] or options[:next_month_text]
      #cal << %(<th colspan="2"><a href=/leave_calendar/change/?year=#{@pvyear}&month=#{@month}&opt=prev_year>#{options[:previous_year_text]}</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href=/leave_calendar/change/?year=#{@year}&month=#{@pvmonth}&opt=prev_month>#{options[:previous_month_text]}</a></th>)
      cal << %(<th colspan="2">)+(link_to options[:previous_year_text], {:controller=>'calendar', :action=>@pvyear, :id=>@month})+%(&nbsp;&nbsp;&nbsp;&nbsp;)+(link_to options[:previous_month_text], {:controller=>'calendar', :action=>@year, :id=>@pvmonth})+%(</th>)
      colspan=3
    else
      colspan=7
    end
    cal << %(<th colspan="#{colspan}" class="#{options[:month_name_class]}">#{Date::MONTHNAMES[options[:month]]}</th>)
    #cal << %(<th colspan="2"><a href=/leave_calendar/change/?year=#{@year}&month=#{@nxtmonth}&opt=nxt_month>#{options[:next_month_text]}</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href=/leave_calendar/change/?year=#{@nxtyear}&month=#{@month}&opt=nxt_year>#{options[:next_year_text]}</a></th>) if options[:next_month_text]
    cal << %(<th colspan="2">)+(link_to options[:next_month_text], {:controller=>'calendar', :action=>@year, :id=>@nxtmonth})+%(&nbsp;&nbsp;&nbsp;&nbsp;)+(link_to options[:next_year_text], {:controller=>'calendar', :action=>@nxtyear, :id=>@month})+%(</th>) if options[:next_month_text]
    cal << %(</tr><tr class="#{options[:day_name_class]}">)
=end    
    cal << %(<tr class="#{options[:day_name_class]}">)
    day_names.each do |d|
      unless d[options[:abbrev]].eql? d
        cal << "<th scope='col'><abbr title='#{d}'>#{d[options[:abbrev]]}</abbr></th>"
      else
        cal << "<th scope='col'>#{d[options[:abbrev]]}</th>"
      end
    end
    cal << "</tr></thead><tbody><tr>"
    beginning_of_week(first, first_weekday).upto(first - 1) do |d|
      cal << %(<td class="#{options[:other_month_class]})
      cal << " weekendDay" if weekend?(d)
      if options[:accessible]
        cal << %(">#{d.day}<span class="hidden"> #{Date::MONTHNAMES[d.month]}</span></td>)
      else
        cal << %(">#{d.day}</td>)
      end
    end unless first.wday == first_weekday
    
    first.upto(last) do |cur|      
      day_events = Event.find(:all, :conditions=>"created_on like '"+cur.to_s+ "%%'" )
      lnk = []
      all_day_events = []
      all_day_events_id = []
      for de in day_events
        all_day_events << de.user.firstname
        all_day_events_id << de.id        
      end                      
      cell_text, cell_attrs = block.call(cur)
      cell_text  ||= cur.mday
      cell_attrs ||= {:class => options[:day_class]}
      cell_attrs[:class] += " weekendDay" if [0, 6].include?(cur.wday) 
      cell_attrs[:class] += " today" if (cur == Date.today) and options[:show_today]  
      cell_attrs = cell_attrs.map {|k, v| %(#{k}="#{v}") }.join(" ")     
      all_day_events.each_index {|y| 
        lnk << "#{all_day_events[y]}</br>"}
      cal << "<td #{cell_attrs}>#{cell_text} 
              </br>
            #{lnk}</td>"
      cal << "</tr><tr>" if cur.wday == last_weekday        
    end
    (last + 1).upto(beginning_of_week(last + 7, first_weekday) - 1)  do |d|
      cal << %(<td class="#{options[:other_month_class]})
      cal << " weekendDay" if weekend?(d)
      if options[:accessible]
        cal << %(">#{d.day}<span class='hidden'> #{Date::MONTHNAMES[d.mon]}</span></td>)
      else
        cal << %(">#{d.day}</td>)        
      end
    end unless last.wday == last_weekday
    cal << "</tr></tbody></table>"
  end
  
  def yeartab(options = {}, &block)
    raise(ArgumentError, "No year given")  unless options.has_key?(:year)
    raise(ArgumentError, "No month given") unless options.has_key?(:month)

    block                        ||= Proc.new {|d| nil}

    defaults = {
      :table_class => 'calendar1',
      :month_name_class => 'monthName1',
      :other_month_class => 'otherMonth1',
      :day_name_class => 'dayName1',
      :day_class => 'day1',
      :abbrev => (0..2),
      :first_day_of_week => 0,
      :accessible => false,
      :show_today => true,
      :previous_month_text => '<',
      :next_month_text => '>',
      :previous_year_text => '<<',
      :next_year_text => '>>'
    }
    options = defaults.merge options

    first = Date.civil(options[:year], options[:month], 1)
    last = Date.civil(options[:year], options[:month], -1)

    first_weekday = first_day_of_week(options[:first_day_of_week])
    last_weekday = last_day_of_week(options[:first_day_of_week])
    
    day_names = Date::DAYNAMES.dup
    first_weekday.times do
      day_names.push(day_names.shift)
    end

    # TODO Use some kind of builder instead of straight HTML
    cal = %(<table class="#{options[:table_class]}" border="0" cellspacing="0" cellpadding="0">)
    cal << %(<thead><tr>)
=begin   
    if options[:previous_month_text] or options[:next_month_text]
      #cal << %(<th colspan="2"><a href=/leave_calendar/change/?year=#{@pvyear}&month=#{@month}&opt=prev_year>#{options[:previous_year_text]}</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href=/leave_calendar/change/?year=#{@year}&month=#{@pvmonth}&opt=prev_month>#{options[:previous_month_text]}</a></th>)
      cal << %(<th colspan="2">)+(link_to options[:previous_year_text], {:controller=>'calendar', :action=>@pvyear, :id=>@month})+%(&nbsp;&nbsp;&nbsp;&nbsp;)+(link_to options[:previous_month_text], {:controller=>'calendar', :action=>@year, :id=>@pvmonth})+%(</th>)
      colspan=3
    else
      colspan=7
    end
=end        
    cal << %(<th colspan="#{7}" class="#{options[:month_name_class]}">#{Date::MONTHNAMES[options[:month]]}</th>)
    #cal << %(<th colspan="2"><a href=/leave_calendar/change/?year=#{@year}&month=#{@nxtmonth}&opt=nxt_month>#{options[:next_month_text]}</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href=/leave_calendar/change/?year=#{@nxtyear}&month=#{@month}&opt=nxt_year>#{options[:next_year_text]}</a></th>) if options[:next_month_text]
    #    cal << %(<th colspan="2">)+(link_to options[:next_month_text], {:controller=>'calendar', :action=>@year, :id=>@nxtmonth})+%(&nbsp;&nbsp;&nbsp;&nbsp;)+(link_to options[:next_year_text], {:controller=>'calendar', :action=>@nxtyear, :id=>@month})+%(</th>) if options[:next_month_text]
    cal << %(<tr class="#{options[:day_name_class]}">)
    day_names.each do |d|
      unless d[options[:abbrev]].eql? d
        cal << "<th scope='col'><abbr title='#{d}'>#{d[options[:abbrev]]}</abbr></th>"
      else
        cal << "<th scope='col'>#{d[options[:abbrev]]}</th>"
      end
    end
    cal << "</tr></thead><tbody><tr>"
    beginning_of_week(first, first_weekday).upto(first - 1) do |d|
      cal << %(<td class="#{options[:other_month_class]})
      cal << " weekendDay" if weekend?(d)
      if options[:accessible]
        cal << %(">#{d.day}<span class="hidden"> #{Date::MONTHNAMES[d.month]}</span></td>)
      else
        cal << %(">#{d.day}</td>)
      end
    end unless first.wday == first_weekday
    
    first.upto(last) do |cur|      
      day_events = Event.find(:all, :conditions=>"created_on like '"+cur.to_s+ "%%'" )
      lnk = []
      all_day_events = []
      all_day_events_id = []
      for de in day_events
        all_day_events << de.name        
        all_day_events_id << de.id        
      end                      
      cell_text, cell_attrs = block.call(cur)
      cell_text  ||= cur.mday
      cell_attrs ||= {:class => options[:day_class]}
      cell_attrs[:class] += " weekendDay" if [0, 6].include?(cur.wday) 
      cell_attrs[:class] += " today" if (cur == Date.today) and options[:show_today]  
      cell_attrs = cell_attrs.map {|k, v| %(#{k}="#{v}") }.join(" ")     
      all_day_events.each_index {|y| 
        lnk << "<a href=/leave_calendar/createevent/#{all_day_events_id[y]}?day=#{cell_text}&month=#{@month}&year=#{@year}&view=#{@view}>#{all_day_events[y]}</br></a>"}
      cal << "<td #{cell_attrs}>#{cell_text} 
              <a href=/leave_calendar/createevent/?day=#{cell_text}&month=#{@month}&year=#{@year}&view=#{@view}>+</a></br>
            #{lnk}</td>"
      cal << "</tr><tr>" if cur.wday == last_weekday        
    end
    (last + 1).upto(beginning_of_week(last + 7, first_weekday) - 1)  do |d|
      cal << %(<td class="#{options[:other_month_class]})
      cal << " weekendDay" if weekend?(d)
      if options[:accessible]
        cal << %(">#{d.day}<span class='hidden'> #{Date::MONTHNAMES[d.mon]}</span></td>)
      else
        cal << %(">#{d.day}</td>)        
      end
    end unless last.wday == last_weekday
    cal << "</tr></tbody></table>"
  end
  
  def yearcalendar(options = {}, &block)
    raise(ArgumentError, "No year given")  unless options.has_key?(:year)
    raise(ArgumentError, "No month given") unless options.has_key?(:month)

    block                        ||= Proc.new {|d| nil}

    defaults = {
      :table_class => 'calendar',
      :month_name_class => 'monthName',
      :other_month_class => 'otherMonth',
      :day_name_class => 'dayName',
      :day_class => 'day',
      :abbrev => (0..2),
      :first_day_of_week => 0,
      :accessible => false,
      :show_today => true,
      :previous_month_text => '<',
      :next_month_text => '>',
      :previous_year_text => '<<',
      :next_year_text => '>>'
    }
    options = defaults.merge options

    first = Date.civil(options[:year], options[:month], 1)
    last = Date.civil(options[:year], options[:month], -1)
    
    first_weekday = first_day_of_week(options[:first_day_of_week])
    last_weekday = last_day_of_week(options[:first_day_of_week])
    
    day_names = Date::DAYNAMES.dup
    first_weekday.times do
      day_names.push(day_names.shift)
    end

    # TODO Use some kind of builder instead of straight HTML
    cal = %(<table class="#{options[:table_class]}" border="0" cellspacing="0" cellpadding="0">)
    cal << %(<thead><tr>)
=begin   
    if options[:previous_month_text] or options[:next_month_text]
      #cal << %(<th colspan="2"><a href=/leave_calendar/change/?year=#{@pvyear}&month=#{@month}&opt=prev_year>#{options[:previous_year_text]}</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href=/leave_calendar/change/?year=#{@year}&month=#{@pvmonth}&opt=prev_month>#{options[:previous_month_text]}</a></th>)
      cal << %(<th colspan="2">)+(link_to options[:previous_year_text], {:controller=>'calendar', :action=>@pvyear, :id=>@month})+%(&nbsp;&nbsp;&nbsp;&nbsp;)+(link_to options[:previous_month_text], {:controller=>'calendar', :action=>@year, :id=>@pvmonth})+%(</th>)
      colspan=3
    else
      colspan=7
    end
=end        
    cal << %(<th colspan="#{7}" class="#{options[:month_name_class]}">#{Date::MONTHNAMES[options[:month]]}&nbsp;#{@year}</th>)
    #cal << %(<th colspan="2"><a href=/leave_calendar/change/?year=#{@year}&month=#{@nxtmonth}&opt=nxt_month>#{options[:next_month_text]}</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href=/leave_calendar/change/?year=#{@nxtyear}&month=#{@month}&opt=nxt_year>#{options[:next_year_text]}</a></th>) if options[:next_month_text]
    #    cal << %(<th colspan="2">)+(link_to options[:next_month_text], {:controller=>'calendar', :action=>@year, :id=>@nxtmonth})+%(&nbsp;&nbsp;&nbsp;&nbsp;)+(link_to options[:next_year_text], {:controller=>'calendar', :action=>@nxtyear, :id=>@month})+%(</th>) if options[:next_month_text]
    cal << %(<tr class="#{options[:day_name_class]}">)
    day_names.each do |d|
      unless d[options[:abbrev]].eql? d
        cal << "<th scope='col'><abbr title='#{d}'>#{d[options[:abbrev]]}</abbr></th>"
      else
        cal << "<th scope='col'>#{d[options[:abbrev]]}</th>"
      end
    end
    cal << "</tr></thead><tbody><tr>"
    beginning_of_week(first, first_weekday).upto(first - 1) do |d|      
      cal << %(<td class="#{options[:other_month_class]})
      cal << " weekendDay" if weekend?(d)
      if options[:accessible]
        cal << %(">#{d.day}<span class="hidden"> #{Date::MONTHNAMES[d.month]}</span></td>)
      else
        cal << %(">#{d.day}</td>)
      end
    end unless first.wday == first_weekday
    
    first.upto(last) do |cur|      
      day_events = Event.find(:all, :conditions=>"created_on like '"+cur.to_s+ "%%'" )
      lnk = []
      evt_avail = []
      all_day_events = []
      all_day_events_id = []
      for de in day_events
        all_day_events << de.name        
        all_day_events_id << de.id        
      end                      
      cell_text, cell_attrs = block.call(cur)
      cell_text  ||= cur.mday
      all_day_events.each_index {|y| 
        lnk << "<a href=/leave_calendar/createevent/#{all_day_events_id[y]}?day=#{cell_text}&month=#{@month}&year=#{@year}&view=#{@view}>#{all_day_events[y]}</br></a>"}
      if (lnk != nil and lnk.size > 0) 
        evt_avail << "(#{lnk.size})"
      end
      cell_attrs ||= {:class => options[:day_class]}
      cell_attrs[:class] += " weekendDay" if [0, 6].include?(cur.wday)        
      cell_attrs[:class] += " today" if (lnk != nil and lnk.size > 0) and options[:show_today]  #if (cur == Date.today) and options[:show_today]  
      cell_attrs = cell_attrs.map {|k, v| %(#{k}="#{v}") }.join(" ")     
      cal << "<td #{cell_attrs}> 
              <a href=/leave_calendar/createevent/?day=#{cell_text}&month=#{@month}&year=#{@year}&view=#{@view}>#{cell_text}  
            #{evt_avail if evt_avail.size > 0 }</a></td>"
      cal << "</tr><tr>" if cur.wday == last_weekday        
    end
    (last + 1).upto(beginning_of_week(last + 7, first_weekday) - 1)  do |d|
      cal << %(<td class="#{options[:other_month_class]})
      cal << " weekendDay" if weekend?(d)
      if options[:accessible]
        cal << %(">#{d.day}<span class='hidden'> #{Date::MONTHNAMES[d.mon]}</span></td>)
      else
        cal << %(">#{d.day}</td>)        
      end
    end unless last.wday == last_weekday
    cal << "</tr></tbody></table>"
  end
  
  
  # Returns an HTML week-view calendar. In its simplest form, this method generates a plain
  # calendar (which can then be customized using CSS) for a given span of days.
  # However, this may be customized in a variety of ways -- changing the default CSS
  # classes, generating the individual day entries yourself, and so on.
  # 
  # The following options are required:
  #  :start_date
  #  :end_date
  # 
  # The following are optional, available for customizing the default behaviour:
  #   :table_class       => "week-view"        # The class for the <table> tag.
  #   :day_name_class    => "dayName"         # The class is for the names of the days, at the top.
  #   :day_class         => "day"             # The class for the individual day number cells.
  #                                             This may or may not be used if you specify a block (see below).
  #   :show_today        => true              # Highlights today on the calendar using the CSS class 'today'. 
  #                                           # Defaults to true.
  #   :previous_span_text   => nil            # Displayed left if set
  #   :next_span_text   => nil                # Displayed right if set
  #
  # For more customization, you can pass a code block to this method, that will get two argument, both DateTime objects,
  # and return a values for the individual table cells. The block can return an array, [cell_text, cell_attrs],
  # cell_text being the text that is displayed and cell_attrs a hash containing the attributes for the <td> tag
  # (this can be used to change the <td>'s class for customization with CSS).
  # This block can also return the cell_text only, in which case the <td>'s class defaults to the value given in
  # +:day_class+. If the block returns nil, the default options are used.
  # 
  # Example usage:
  #   week_view(:start_date => (Date.today - 5), :end_date => Date.today) # This generates the simplest possible week-view.
  #   week_view(:start_date => (Date.today - 5), :end_date => Date.today, :table_class => "calendar_helper"}) # This generates a week-view, as
  #                                                                             # before, but the <table>'s class
  #                                                                             # is set to "calendar_helper".
  #   week_view(:start_date => (Date.today - 5), :end_date => Date.today) do |s| # This generates a simple week-view, but gives special spans
  #     if listOfSpecialSpans.include?(s)          # (spans that are in the array listOfSpecialSpans) one CSS class,
  #       ["", {:class => "specialSpan"}]      # "specialSpan", and gives the rest of the spans another CSS class,
  #     else                                      # "normalSpan". You can also use this to highlight the current time differently
  #       ["", {:class => "normalSpan"}]       # from the rest of the days, etc.
  #     end
  #   end
  #
  # For consistency with the themes provided in the calendar_styles generator, use "specialSpan" as the CSS class for marked days.
  # 
  def week_view(options = {}, &block)
    raise(ArgumentError, "No start date given")  unless options.has_key?(:start_date)
    raise(ArgumentError, "No end date given") unless options.has_key?(:end_date)
    span = (options[:end_date] - options[:start_date]).to_i # Get the number of days represented by the span given
    dates = (options[:start_date]..options[:end_date])
    start_time = 0
    end_time   = 23
    time_range = (start_time..end_time).to_a        
    duration = 15

    block                        ||= Proc.new {|d| nil}
    defaults = {
      :table_class => 'week-view',
      :day_name_class => 'dayName',
      :day_class => 'day',
      :show_today => true,
      :previous_span_text => nil,
      :next_span_text => nil
    }
    options = defaults.merge options    
   
    if options[:url]
      next_start_date = options[:end_date] + 1
      next_end_date   = next_start_date + 5
      next_link = link_to('>>', url_for(options[:url].merge(:start_date => next_start_date, :end_date => next_end_date)) + options[:url_append])
      prev_start_date = options[:start_date] - span
      prev_end_date = options[:start_date] - 1
      prev_link = link_to('<<', url_for(options[:url].merge(:start_date => prev_start_date, :end_date => prev_end_date)) + options[:url_append])
    end

    # TODO Use some kind of builder instead of straight HTML
    cal = %(<table class="#{options[:table_class]}">\n)
    cal << %(\t<thead>\n\t\t<tr>\n)
    cal << %(\t\t\t<th>#{dates.first.strftime("%Y")}</th>\n)    
    dates.each do |d|      
      cal << "\t\t\t<th #{Date.today == d ? " class='today'" : ""}>#{d.strftime("%A")}<br />#{d.strftime("%b-%d")}</th>\n"
    end
    cal << "\t\t</tr>\n\t</thead>\n\t<tbody>\n"    
    time_range.each do |hour|      
      minutes = 0
      print_hour = hour.to_s.rjust(2, '0')
      srt_min = minutes.to_s.ljust(2, '0')
      tm = %(T#{print_hour}:#{srt_min}:00+05:30)          
      tm1 = DateTime.parse(tm).to_datetime
      display_time = tm1.strftime("%I:%M %p")
      4.times do |i|
        print_minutes = minutes.to_s.rjust(2, '0')                
        cal << %(\t\t<tr class='m#{print_minutes} d#{duration}'>\n)                       
        cal << %(\t\t\t<th rowspan="4"><h3>#{display_time}</h3></th>\n) if i==0         
        options[:start_date].upto(options[:end_date]) do |d|
          the_minutes = minutes
          print_start_minutes = the_minutes.to_s.ljust(2, '0')
          start_datetime_string = %(#{d.to_s(:db)}T#{print_hour}:#{print_start_minutes}:00+05:30)          
          start_datetime = DateTime.parse(start_datetime_string).to_datetime
          end_datetime = (start_datetime + duration.minutes).to_datetime
          range = (start_datetime...end_datetime)
          h =  start_datetime.strftime("%H")
          m =  start_datetime.strftime("%M")          
          day = start_datetime.strftime("%d")
          month = start_datetime.strftime("%m")
          # cell_attrs should return a hash.
          cell_text, cell_attrs = block.call(range)
          cell_text ||= ""
          cell_attrs ||= {}
          cell_attrs[:class] = cell_attrs[:class].to_s + "today" if Date.today == d
          cell_attrs = cell_attrs.map {|k, v| %(#{k}="#{v}")}.join(" ")          
          cal << "\t\t\t<td #{cell_attrs}>\n#{cell_text}&nbsp;<a href=/leave_calendar/createevent/?day=#{day}&month=#{month}&year=#{@year}&view=#{@view}&hour=#{h}&minute=#{m}>+</a>\t\t\t</td>\n"
        end
        minutes += duration
        cal << %(\t\t</tr>)
      end
    end
    cal << "\n\t</tbody>\n</table>"
  end
  
  
  
  def day_view(options = {}, &block)
    raise(ArgumentError, "No start date given")  unless options.has_key?(:start_date)
    raise(ArgumentError, "No end date given") unless options.has_key?(:end_date)
    span = (options[:end_date] - options[:start_date]).to_i # Get the number of days represented by the span given
    dates = (options[:start_date]..options[:end_date])
    start_time = 0
    end_time   = 23
    time_range = (start_time..end_time).to_a        
    duration = 15

    block                        ||= Proc.new {|d| nil}
    defaults = {
      :table_class => 'week-view',
      :day_name_class => 'dayName',
      :day_class => 'day',
      :show_today => true,
      :previous_span_text => nil,
      :next_span_text => nil
    }
    options = defaults.merge options    
   
    if options[:url]
      next_start_date = options[:end_date] + 1
      next_end_date   = next_start_date + 5
      next_link = link_to('>>', url_for(options[:url].merge(:start_date => next_start_date, :end_date => next_end_date)) + options[:url_append])
      prev_start_date = options[:start_date] - span
      prev_end_date = options[:start_date] - 1
      prev_link = link_to('<<', url_for(options[:url].merge(:start_date => prev_start_date, :end_date => prev_end_date)) + options[:url_append])
    end

    # TODO Use some kind of builder instead of straight HTML
    cal = %(<table class="#{options[:table_class]}">\n)
    cal << %(\t<thead>\n\t\t<tr>\n)
     
    dates.each do |d|      
      cal << "\t\t\t<th colspan=2 #{"class='today'"}>#{d.strftime("%d-%b-%Y %A")}</th>\n"
    end
    cal << "\t\t</tr>\n\t</thead>\n\t<tbody>\n"    
    time_range.each do |hour|      
      minutes = 0
      print_hour = hour.to_s.rjust(2, '0')
      srt_min = minutes.to_s.ljust(2, '0')
      tm = %(T#{print_hour}:#{srt_min}:00+05:30)          
      tm1 = DateTime.parse(tm).to_datetime
      display_time = tm1.strftime("%I:%M %p")
      4.times do |i|
        print_minutes = minutes.to_s.rjust(2, '0')                
        cal << %(\t\t<tr class='m#{print_minutes} d#{duration}'>\n)                       
        cal << %(\t\t\t<th rowspan="4" class='day'><h3>#{display_time}</h3></th>\n) if i==0         
        options[:start_date].upto(options[:end_date]) do |d|
          the_minutes = minutes
          print_start_minutes = the_minutes.to_s.ljust(2, '0')
          start_datetime_string = %(#{d.to_s(:db)}T#{print_hour}:#{print_start_minutes}:00+05:30)          
          start_datetime = DateTime.parse(start_datetime_string).to_datetime
          end_datetime = (start_datetime + duration.minutes).to_datetime
          range = (start_datetime...end_datetime)
          h =  start_datetime.strftime("%H")
          m =  start_datetime.strftime("%M")          
          day = start_datetime.strftime("%d")
          month = start_datetime.strftime("%m")
          # cell_attrs should return a hash.
          cell_text, cell_attrs = block.call(range)
          cell_text ||= ""
          cell_attrs ||= {}                   
          cell_attrs[:class] = cell_attrs[:class].to_s + "day"           
          cell_attrs = cell_attrs.map {|k, v| %(#{k}="#{v}")}.join(" ")          
          cal << "\t\t\t<td #{cell_attrs}>\n#{cell_text}&nbsp;<a href=/leave_calendar/createevent/?day=#{day}&month=#{month}&year=#{@year}&view=#{@view}&hour=#{h}&minute=#{m}>+</a>\t\t\t</td>\n"
        end
        minutes += duration
        cal << %(\t\t</tr>)
      end
    end
    cal << "\n\t</tbody>\n</table>"
  end
  
  private
  
  def first_day_of_week(day)
    day
  end
  
  def last_day_of_week(day)
    if day > 0
      day - 1
    else
      6
    end
  end
  
  def days_between(first, second)
    if first > second
      second + (7 - first)
    else
      second - first
    end
  end
  
  def beginning_of_week(date, start = 1)
    days_to_beg = days_between(start, date.wday)
    date - days_to_beg
  end
  
  def weekend?(date)
    [0, 6].include?(date.wday)
  end
  

end
