module UserHelper

def compoff_given_by(user)
User.find_by_id(user.to_i).username 
end

end
