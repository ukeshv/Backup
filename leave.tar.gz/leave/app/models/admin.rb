class Admin < ActiveRecord::Base
	
   validates_presence_of      :username, :message=>"Username can't be blank"
   validates_uniqueness_of  :username, :case_sensitive => false

   validates_presence_of   :password, :message=>"Password can't be blank"
   validates_length_of        :password, :within => 4..40
 
 validates_presence_of      :email,:message=>"Email can't be blank"
 validates_length_of       :email,    :within => 3..100
 validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i ,:message=>"Please provide a valid Email Address"  
 validates_uniqueness_of    :email, :case_sensitive => false
  
 validates_presence_of  :firstname ,:message=>"Firstname can't be blank"
 validates_length_of :firstname, :within => 2..40, :too_short => 'First Name must be at least 2 characters long.  Please provide a longer Name', :too_long=> 'First Name can be no longer than 40 characters. Please provide a shorter Name'
 validates_presence_of :reason,:message => "Hello"
   # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  def self.authenticate(username, password)
    u = find_by_username(username) # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end
  
    def authenticated?(password)
    password
  end
  
end
