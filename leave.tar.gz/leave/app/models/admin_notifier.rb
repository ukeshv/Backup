class AdminNotifier < ActionMailer::Base
	
	def signup_notification(user)
	     setup_email(user)
             @subject    += 'Sedin Leave Sheet Account'
						 @content_type = "text/html"
     end
     
     def approval_notification(user,leaverequest)
	     setup_email(user)
             @subject    += 'Leave Approved'
	     @body[:leaverequest] = leaverequest
			 @content_type = "text/html"
	end
	
	def rejected_notification(user,leaverequest)
	     setup_email(user)
             @subject    += 'Leave Rejected'
	     @body[:leaverequest] = leaverequest
			 @content_type = "text/html"
     end
     
     def chg_password_notification(user)
	     setup_email(user)
	     @subject +='Change Password'
	     @body[:user] = user
			 @content_type = "text/html"
		 end
		 
		 def compoff_notification(user,comp_off)
	     setup_email(user)
             @subject   += 'CompOff'
	     @body[:comp_off] = comp_off
		 @content_type = "text/html"
	 end
	 
  protected
  def setup_email(user)      
    @from  =  "mailer@railsfactory.com"
    @recipients  = "#{user.email}"
    @subject     = "Sedin:"
    @sent_on     = Time.now
    @body[:user] = user
  end
end
