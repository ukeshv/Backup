class CompOff < ActiveRecord::Base
	validates_presence_of :reason, :message => "Reason can't be blank"
	validates_presence_of :no_of_days, :message => "No of Days can't be blank"
	validates_presence_of :date, :message=>"Date can't be empty"
	validates_presence_of :current_working_project, :message => "Current_working Project can't be blank"
	validates_presence_of :user_id, :message => "Please select User Name"
	validates_presence_of :given_by, :message=>"Please select Given By"
        belongs_to :user
end
