class Leave < ActiveRecord::Base
		belongs_to :user

end
