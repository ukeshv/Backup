class LeaveNotifier < ActionMailer::Base
	
	def request_notification(leaverequest,user,subject)			
		setup_email(leaverequest,user)
			 @subject    = subject	    
	     @body[:name] = user.full_name
	     @content_type = "text/html"
	end
		 
	def request_notification_create_by_admin(leaverequest,user,subject)			
		setup_email(leaverequest,user)
			 @subject    = subject	    
	     @body[:name] = user.full_name
	     @content_type = "text/html"
	end
	
	def leave_taken(requests,subject)
		#@recipients = "ukesh@railsfactory.org"
		@from = "#{$from_email}"
		@recipients  =  "#{$to_email}"
		@sent_on     = Time.now
		@subject = subject
		@body[:requests]=requests
		@content_type="text/html"
	end
	
	def weekly_leave_taken(requests,subject)
         	#@recipients = "ukesh@railsfactory.org"
		@from = "#{$from_email}"
		@recipients  =  "mars@railsfactory.org"
		@sent_on     = Time.now
		@subject = subject
		@body[:requests]=requests
		@content_type="text/html"
	end
	
	
	
	
 protected

	  def setup_email(leaverequest,user)    	     
	    @recipients  =  "#{$to_email}"
	    @from        = "#{user.email}"
	    @subject     = ""
	    @sent_on     = Time.now
	    @body[:leaverequest] = leaverequest
	    @content_type = "text/html"
	   
	  end
end
