class Leaverequest < ActiveRecord::Base
	
	validates_presence_of :leave_type,:message=>"LeaveType can't be blank"
	validates_presence_of :leave_from,:message=>"LeaveFrom can't be blank"
	validates_presence_of :leave_to,:message=>"LeaveTo can't be blank"
	validates_presence_of :number_of_days,:message=>"Number of Days can't be blank"
	validates_presence_of :reason,:message=>"Reason can't be blank"
	validates_presence_of :currently_working_project,:message=>"Currently Working Project can't be blank"
	validates_presence_of :alternate_user_id,:message=>"Please select alternate team member"
	validates_presence_of :user_id,:message=>"Please select user"
	validates_presence_of :paid_leave,:message=>"Paid leave can't be blank"
	validates_presence_of :lop,:message=>"LOP can't be blank"
	validates_presence_of :got_approval_from,:message=>"I Got Approval From-can't be blank"

	belongs_to :user
	belongs_to :alternate_user, :class_name=>'User', :foreign_key=>'alternate_user_id'
	
def self.leave_taken(userid)
	approved_leave_req = Leaverequest.find(:all,:conditions=>['user_id = ? and approval_status = ?',userid,1],:select=>"sum(number_of_days) as sum_leave_taken")
	leave_taken =  approved_leave_req[0].sum_leave_taken
	return leave_taken
end

def self.weekly_leave_summary(no_of_days)
		date=Date.new
		x=Date.today
		y= Date.today+no_of_days
		@requests=Leaverequest.find :all,:conditions=>['leave_from >= ? and leave_from <= ?', x,y],:order=>'leave_from'
		subject=(@requests.length > 0) ? "Leave Summary for next one week" : "Hurray No one applied for leave in the next one week EOM"
		LeaveNotifier.deliver_leave_taken(@requests,subject)
end
	
def self.daily_leave_summary
    @requests=Leaverequest.find(:all,:conditions=>['? between leave_from and leave_to',Date.today+1])
		subject=(@requests.length > 0) ? "Leave Summary for today" : "Hurray No one applied leave for today - EOM"
		LeaveNotifier.deliver_leave_taken(@requests,subject) 
end	
	
def self.weekly_leave_list(no_of_days)
		date=Date.new
		x=Date.today
		y= Date.today+no_of_days
		@requests=Leaverequest.find :all,:conditions=>['leave_from >= ? and leave_from <= ?', x,y],:order=>'leave_from'
		subject=(@requests.length > 0) ? "Leave Summary for next one week" : "Hurray No one applied for leave in the next one week EOM"
		LeaveNotifier.deliver_weekly_leave_taken(@requests,subject)
end	
	
	
#def self.alternate_user_name(user_id)	
#	User.find_by_id(user_id).full_name
#end


	
end
