require 'digest/sha1'
class User < ActiveRecord::Base
attr_accessor :password,:step
  validates_presence_of      :username,:message=>"Username can't be blank"
  validates_presence_of      :email,:message=>"Email can't be blank"
  validates_presence_of      :password,                   :if => :password_required?,:message=>"Password can't be blank"
  validates_presence_of     :password_confirmation,      :if => :password_required?,:message=>'Please retype your password'
  validates_length_of       :password, :within => 4..40, :if => :password_required?
  validates_confirmation_of :password,                   :if => :password_required?

  validates_length_of       :email,    :within => 3..100
  validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i ,:message=>"Please provide a valid Email Address"  
  validates_uniqueness_of    :email, :case_sensitive => false
  
  validates_presence_of  :firstname ,:message=>"Firstname can't be blank"
  validates_presence_of  :mobile_number ,:message=>"Mobile Number can't be blank"
  validates_presence_of  :department_id ,:message=>"Select the department name"
  #~ validates_presence_of  :permanent_address ,:if => Proc.new { |user| user.step == 1 },:message=>"Permanent Address can't be blank"
  #~ validates_presence_of  :present_address ,:if => Proc.new { |user| user.step == 1 },:message=>"Present Address can't be blank"
  #~ validates_presence_of  :blood_group ,:if => Proc.new { |user| user.step == 1 },:message=>"Blood Group can't be blank"
  #~ validates_presence_of  :emergency_contact ,:if => Proc.new { |user| user.step == 1 },:message=>"Emergency Contact can't be blank"
  #~ validates_presence_of  :education ,:if => Proc.new { |user| user.step == 1 },:message=>"Education can't be blank"
  #~ validates_presence_of  :designation_history ,:if => Proc.new { |user| user.step == 1 },:message=>"Designation History can't be blank"
  #~ validates_presence_of  :achievements ,:if => Proc.new { |user| user.step == 1 },:message=>"Achievements can't be blank"
  #~ validates_presence_of  :participation ,:if => Proc.new { |user| user.step == 1 },:message=>"Participation can't be blank"
  #~ validates_presence_of  :training_underground ,:if => Proc.new { |user| user.step == 1 },:message=>"Training Underground can't be blank"
  validates_length_of :firstname, :within => 2..40, :too_short => 'First Name must be at least 2 characters long.  Please provide a longer Name', :too_long=> 'First Name can be no longer than 40 characters. Please provide a shorter Name'
  before_save :encrypt_password
  belongs_to :department
  has_one :photo
	has_many :leaves
	has_many :events
	has_many :leaverequests
  has_many :comp_offs
has_one :leaverequest, :foreign_key=>'alternate_user_id'
  
  



  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  def self.authenticate(username, password)
    u = find_by_username(username) # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  # Encrypts some data with the salt.
  def self.encrypt(password, salt)
    Digest::SHA1.hexdigest("--#{salt}--#{password}--")
  end

  # Encrypts the password with the user salt
  def encrypt(password)
    self.class.encrypt(password, salt)
  end

  def authenticated?(password)
    crypted_password == encrypt(password)
  end

 #Password Reset for Forgot password
	def forgot_password
	@forgotten_password = true
	self.make_password_reset_code
	end

	def reset_password
	# First update the password_reset_code before setting the 
	# reset_password flag to avoid duplicate email notifications.
	update_attributes(:password_reset_code => nil)
	@reset_password = true
	end

	def recently_reset_password?
	@reset_password
	end

	def recently_forgot_password?
	@forgotten_password
  end

  def full_name
      "#{firstname.capitalize} #{lastname.capitalize}"
  end
  
  def self.birthday_alert
    d=Date.today+1
    @users=User.find(:all,:conditions=>['DAYOFMONTH(date_of_birth)= ?  and MONTH(date_of_birth)= ?',d.strftime('%d'),d.strftime('%m')])
    if (!@users.nil? && !@users.empty?)
    for @user in @users
    User.message
    subject= "Happy Birthday #{@user.firstname}"     
    UserNotifier.deliver_birthday_msg(@user,subject,@birthday_msg)
    end
    end
  end	
  
  def self.birthday_list_for_employees
         day1 = Date.today+1
         d1 = day1.strftime("%m.%d")
         day2 = day1 + 31
         d2 = day2.strftime("%m.%d")
        @users=User.find_by_sql("SELECT concat_ws('.',LPAD(MONTH(date_of_birth),2,0),LPAD(DAYOFMONTH(date_of_birth),2,0)) as dob, firstname, lastname, date_of_birth  FROM `users` HAVING dob >= #{d1} and dob <= #{d2}")
         subject=(@users.length > 0) ? "Birthday list for next 30 days" : "There is no birthday list for next 30 days"
         UserNotifier.deliver_birthday_list_for_emp(@users,subject)
  end
  
  def self.message
     @msg=["Hope all that you do
Turns out happy for you
And all that you wish
Comes your way,
So each hour will bring
Every wonderful thing
You could ask of a wonderful day

HAPPY BIRTHDAY !","A greeting on your birthday
For a very happy day
And then a year
That brings the best
Of everything your way

Enjoy your special day!

HAPPY BIRTHDAY !","You're always very special
And you should know today
That you are wished the nicest things
That life can bring your way

Like warm and loving wishes
And happiness and cheer
And everything you need to start
Another happy year


HAPPY BIRTHDAY !","This brings a wish for all
The best a day and year
Can bring, for someone
Who should always have
The best of everything!

Have a Happy Birthday
And a wonderful year!","From morning till night
May your birthday be bright
And nicer than ever before!!
And as years come and go
May your happiness grow
And your dreams be fulfilled
Even more

Happy Birthday to you!"]
@birthday_msg=@msg.rand()
    end

  protected
    # before filter 
    def encrypt_password
      return if password.blank?
      self.salt = Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{username}--") if new_record?
      self.crypted_password = encrypt(password)
    end
    
    def password_required?
      crypted_password.blank? || !password.blank?
    end
    
     #Password Reset for Forgot password
	def make_password_reset_code
	self.password_reset_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
end

  def self.image(id)
    image_id=Photo.find_by_user_id(id)
    !image_id.nil? ? image_id.public_filename : "/images/mugshot-M.gif"
  end
    
  end
