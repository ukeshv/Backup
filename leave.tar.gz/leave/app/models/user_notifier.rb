class UserNotifier < ActionMailer::Base
	
  def forgot_password(user)
    setup_email(user)
    @subject    += 'Request to Reset your password'
    @body[:url]  = $site_url+ "user/reset_password/#{user.password_reset_code}" 
    @content_type = "text/html"
  end

  def reset_password(user)
    setup_email(user)
    @subject    += 'Your password has been reset'
    @content_type = "text/html"
  end
  
  def request_sent(leaverequest,user)			
       @from        = "mailer@railsfactory.com"
	@subject    = 'Leave Request sent to Admin'
       @sent_on     = Time.now
       @recipients = "#{user.email}"
       @body[:name] = user.full_name
	     @body[:leaverequest] = leaverequest
	     @content_type = "text/html"
   end
   
   def request_create_by_admin(leaverequest,user)			
       @from        = "leave@railsfactory.org"
      @subject    = 'Leave Request create by Admin'
       @sent_on     = Time.now
       @recipients = "#{user.email}"
       #@recipients = "ukesh@railsfactory.org"
       @body[:name] = user.full_name
	     @body[:leaverequest] = leaverequest
	     @content_type = "text/html"
	end
  
  def birthday_msg(user,subject,b_msg)
      @from = "mailer@railsfactory.com"
      @recipients = "internal@railsfactory.org"
      #@recipients = "ukesh@railsfactory.org"
      @subject = subject
      @body[:user] = user
      @body[:b_msg] = b_msg
      @sent_on     = Time.now
      @content_type = "text/html"
  end
    
    
  def birthday_list_for_emp(users,subject)
      @from = "mailer@railsfactory.com"
      @recipients = "#{$to_email}"
      #@recipients = "ukesh@railsfactory.org"
      @subject = subject
      @body[:users] = users
      @sent_on     = Time.now
      @content_type = "text/html"
  end
  
  
  protected
  def setup_email(user)
    @recipients  = "#{user.email}"
    @from        = "#{$from_email}"
    @subject     = ""
    @sent_on     = Time.now
    @body[:user] = user
  end
  
  
end
