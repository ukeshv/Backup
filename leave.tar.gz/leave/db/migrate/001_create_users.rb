class CreateUsers < ActiveRecord::Migration
  def self.up
    create_table :users do |t|
      t.column :username,                     :string
      t.column :email,                     :string, :limit => 40
      t.column :crypted_password,          :string, :limit => 40
      t.column :salt,                      :string, :limit => 40
      t.column :password_reset_code, :string
      t.column :firstname, :string
      t.column :lastname, :string
      t.column :mobile_number, :string
      t.column :phone_number, :string
      t.column :last_loggedin  ,:datetime
      t.column :active_status,    :boolean,:default=>0
      t.column :created_at,                :datetime
      t.column :updated_at,                :datetime
      t.column :activation_code, :string, :limit => 40
      t.column :activated_at,    :datetime
    end
  end

  def self.down
    drop_table :users
  end
end
