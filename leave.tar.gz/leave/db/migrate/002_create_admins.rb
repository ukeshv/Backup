class CreateAdmins < ActiveRecord::Migration
  def self.up
    create_table :admins do |t|
      t.column :username, :string
       t.column :password,          :string, :limit => 40
       t.column :email,          :string, :limit => 40
       t.column :firstname,          :string, :limit => 100
       t.column :lastname,          :string, :limit => 100
       t.column :mobile_number,          :string, :limit => 20
       t.column :created_at,          :datetime
       t.column :updated_at,          :datetime
        
    end
    Admin.create!(:username=>'railsfactory',:password=>'rails',:email=>'ukesh@railsfactory.org',:firstname=>'Ukesh')
  end

  def self.down
    drop_table :admins
  end
end
