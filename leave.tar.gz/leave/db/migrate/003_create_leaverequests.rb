class CreateLeaverequests < ActiveRecord::Migration
  def self.up
    create_table :leaverequests do |t|

      t.column :user_id, :integer
      t.column :leave_type, :string #Half Day/Full Day
      t.column :leave_from, :date
      t.column :leave_to, :date
      t.column :number_of_days, :float
      t.column :reason, :text
      t.column :approval_status, :integer,:default=>0   #Pending/Approved/Rejected
      t.column :created_at , :datetime
      t.column :updated_at, :datetime
      t.column :admin_note, :text
    end
  end

  def self.down
    drop_table :leaverequests
  end
end
