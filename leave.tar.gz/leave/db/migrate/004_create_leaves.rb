class CreateLeaves < ActiveRecord::Migration
  def self.up
    create_table :leaves do |t|

      t.column :user_id, :integer
      t.column :available_days, :float
      t.column :leave_taken, :float
      t.column :created_at , :datetime
      t.column :updated_at, :datetime
    end
  end

  def self.down
    drop_table :leaves
  end
end
