class AddEmpCode < ActiveRecord::Migration
  def self.up
	  add_column :users,:emp_code,:string
  end

  def self.down
	  remove_column :users,:emp_code
  end
end
