class CreateDepartments < ActiveRecord::Migration
  def self.up
    create_table :departments do |t|
      t.string :name
      t.timestamps
    end
    Department.create([{:name => "Rails"},
    {:name => "PHP"},
    {:name => "System admin"},
    {:name => "Testing"},
    {:name => "Designer"},
    {:name => "HR department"}])
    add_column :users, :department_id, :integer, :default=>0
    add_column :leaverequests, :currently_working_project, :string
    add_column :leaverequests, :alternate_team_members, :string
  end

  def self.down
    drop_table :departments
    remove_column :users, :department_id
    remove_column :leaverequests, :currently_working_project
    remove_column :leaverequests, :alternate_team_members
  end
end
