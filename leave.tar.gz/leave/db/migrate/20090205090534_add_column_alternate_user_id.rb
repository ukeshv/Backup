class AddColumnAlternateUserId < ActiveRecord::Migration
  def self.up
     remove_column :leaverequests, :alternate_team_members
     add_column :leaverequests, :alternate_user_id, :integer
  end

  def self.down
    add_column :leaverequests, :alternate_team_members, :string
    remove_column :leaverequests, :alternate_user_id
  end
end
