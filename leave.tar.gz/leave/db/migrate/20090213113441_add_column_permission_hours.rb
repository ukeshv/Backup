class AddColumnPermissionHours < ActiveRecord::Migration
  def self.up
    add_column :leaverequests, :permission_hours, :string
  end

  def self.down
    remove_column :leaverequests, :permission_hours
  end
end
