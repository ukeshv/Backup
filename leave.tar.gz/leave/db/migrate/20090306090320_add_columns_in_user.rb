class AddColumnsInUser < ActiveRecord::Migration
  def self.up
    add_column :users, :date_of_birth, :date
    add_column :users, :date_of_joining, :date
    add_column :users, :permanent_address, :text
    add_column :users, :present_address, :text
    add_column :users, :blood_group, :string
    add_column :users, :emergency_contact, :integer
    add_column :users, :education, :string
    add_column :users, :designation_history, :text
    add_column :users, :achievements, :text
    add_column :users, :participation, :text
    add_column :users, :training_underground, :string
  end

  def self.down
    remove_column :users, :date_of_birth
    remove_column :users, :date_of_joining
    remove_column :users, :permanent_address
    remove_column :users, :present_address
    remove_column :users, :blood_group
    remove_column :users, :emergency_contact
    remove_column :users, :education
    remove_column :users, :designation_history
    remove_column :users, :achievements
    remove_column :users, :participation
    remove_column :users, :training_underground
  end
end
