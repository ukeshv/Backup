class AddColumnLeaveCarryFwdInUser < ActiveRecord::Migration
  def self.up
    add_column :users, :leave_carry_forward, :float, :default=>0
  end

  def self.down
    remove_column :users, :leave_carry_forward
  end
end
