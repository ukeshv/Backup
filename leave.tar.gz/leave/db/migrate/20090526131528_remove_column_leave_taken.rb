class RemoveColumnLeaveTaken < ActiveRecord::Migration
  def self.up
    remove_column :users,:leave_taken
  end

  def self.down
    add_column :users,:leave_taken, :float, :default=>0
  end
end
