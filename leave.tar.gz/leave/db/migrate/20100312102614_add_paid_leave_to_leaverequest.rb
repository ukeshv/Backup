class AddPaidLeaveToLeaverequest < ActiveRecord::Migration
  def self.up
    add_column :leaverequests, :paid_leave, :float, :default => 0.0
  end

  def self.down
    remove_column :leaverequests, :paid_leave
  end
end
