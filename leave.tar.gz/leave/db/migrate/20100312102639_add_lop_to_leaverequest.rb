class AddLopToLeaverequest < ActiveRecord::Migration
  def self.up
    add_column :leaverequests, :lop, :float, :default => 0.0
  end

  def self.down
    remove_column :leaverequests, :lop
  end
end
