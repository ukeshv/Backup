class CreateCompOffs < ActiveRecord::Migration
  def self.up
    create_table :comp_offs do |t|
      t.integer :user_id
      t.date :date
      t.float :no_of_days
      t.string :reason
      t.string :current_working_project
      t.integer :given_by

      t.timestamps
    end
  end

  def self.down
    drop_table :comp_offs
  end
end
