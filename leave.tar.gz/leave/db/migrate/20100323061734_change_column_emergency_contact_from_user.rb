class ChangeColumnEmergencyContactFromUser < ActiveRecord::Migration
  def self.up
	  change_column :users, :emergency_contact, :string
  end

  def self.down
  end
end
