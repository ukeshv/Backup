class AddColumnGotApprovalFromToLeaverequests < ActiveRecord::Migration
  def self.up
    add_column :leaverequests, :got_approval_from, :string
  end

  def self.down
    remove_column :leaverequests, :got_approval_from
  end
end
