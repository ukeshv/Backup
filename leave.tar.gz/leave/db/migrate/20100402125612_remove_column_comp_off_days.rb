class RemoveColumnCompOffDays < ActiveRecord::Migration
  def self.up
	remove_column :users, :comp_off_days
  end

  def self.down
	add_column :users, :comp_off_days
  end
end
