class Admin::BodyHairtypesController < ApplicationController
	layout "admin"
	include AdminAuthenticatedSystem
	before_filter :admin_login_required
	@@entries_per_page = 10
	
	def index
		conditions = "(name like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"
    options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
   
    if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @body_hair_types = BodyHairtype.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @body_hair_types = BodyHairtype.paginate(options)
      @search_body_hair_type=1
      @search_value=params[:search]
    else
      @body_hair_types = BodyHairtype.paginate(options)
    end
	end
	

	def create
		@body_hair_type = BodyHairtype.new(params[:body_hairtype])
		if @body_hair_type.save
			@body_hair_types = BodyHairtype.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
			render :update do |page|
				page.hide "name_bodytype"
				page.show "flashnotice"
				page.replace_html "list", :partial=>"listing_body_hairtypes"
				page.replace_html "flashnotice", :text=>"Body hair type created successfully!"
				page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
				page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
			end
		else
			 show_hide_error_messages(@body_hair_type,'bodytype')	    
		end
	end
	
	def edit
		@body_hair_type = BodyHairtype.find(params[:id])
    render :layout =>false
	end
	
 def update
	 @body_hair_type = BodyHairtype.find(params[:id])
      if @body_hair_type.update_attributes(params[:body_hairtype])
        @body_hair_types = BodyHairtype.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
        render :update do |page|
          page.hide "edit_#{@body_hair_type.id}"
          page.hide "name_bodytype"
          page.replace_html "editname_#{@body_hair_type.id}", :partial=>"updated_body_hairtype"
          page.replace_html "flashnotice", :text=>"Body hair type Updated successfully!"
          page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
          page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
        end
      else
         show_hide_error_messages1(@body_hair_type,'bodytype')	    
      end
 end
 
 def destroy
	  @body_hair_type = BodyHairtype.find(params[:id])
		 if @body_hair_type.profiles.empty?
    @body_hair_type.destroy
    flash[:success] =  "Body hair type deleted successfully!"
		else
			flash[:success] =  "You cannot delete this body hair type as it has related profiles created by users"
		end		
    respond_to do |format|
      format.html { redirect_to(admin_body_hairtypes_url) }
      format.xml  { head :ok }
    end
 end
 
  def show_hide_error_messages(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id
               page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
             end
              page.hide "flashnotice"
              page.hide "search_text"
             	page.hide "name_bodytype"  if  obj.errors["name"].nil?
           end
         end
  end
	def show_hide_error_messages1(obj,replacing_id)
		 render :update do |page|
			 for h in obj.errors.entries
				 if !obj.errors["#{h[0]}"].nil?
					 page.show "#{h[0]}_" +  replacing_id + "1"
					 page.replace_html "#{h[0]}_" + replacing_id+"1", "#{h[1]}"
				 end
					page.hide "flashnotice"
					page.hide "name_bodytype"
					page.hide "name_bodytype1"  if  obj.errors["name"].nil?
			 end
		 end
	end
	
	def cancel
  @body_hair_type = BodyHairtype.find(params[:id]) 
		render :update do |page|
    page.replace_html "edit_#{@body_hair_type.id}", :partial=>"edit_icon"
		end
  end
	
end
