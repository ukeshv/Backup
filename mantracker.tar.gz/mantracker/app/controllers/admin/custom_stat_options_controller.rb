class Admin::CustomStatOptionsController < ApplicationController
end
