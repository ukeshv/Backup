class Admin::CustomStatsController < ApplicationController
	layout "admin"
	include AdminAuthenticatedSystem
	before_filter :admin_login_required
	@@entries_per_page = 10
	
	def  index
		@custom_stats=CustomStat.find(:all)
	end
	
	def new
		@custom_stat=CustomStat.new()
	end
	
	def create
		@custom_stat = CustomStat.new(params[:custom_stat])
		if @custom_stat.valid? 
				(params[:custom_stat][:field_type]=="textbox") || (params[:custom_stat][:field_type]=="textarea") ? custom_stat_option_no_need	 :	custom_stat_options_need
		else
			render :action => "new"
		end
	end
	
	def custom_stat_option_no_need
		@custom_stat.save
		flash[:sucess]="Custom stat created successfully ."
		@custom_stat_options=CustomStatOption.create(:custom_stat_id=> @custom_stat.id,:option_value=>@custom_stat.field_type )
		 redirect_to :action => "index"
	end
	
	def custom_stat_options_need
		options=params[:custom_stat_options].split("\r\n")
		if options.length >0
			@custom_stat.save
			flash[:success]="Custom stat created successfully."
			options.each do |option|	
				@custom_stat_option=CustomStatOption.create(:custom_stat_id=> @custom_stat.id,:option_value=>option)
			end
			redirect_to :action => "index"
		else
			flash[:notice]="Provide custom stats options"
			render :action => "new"
		end
		
	end
	
	def edit
		@custom_stat=CustomStat.find(params[:id])
		@custom_stats_options=CustomStatOption.find(:all,:conditions=>['custom_stat_id = ?',@custom_stat.id])
		custom_stats_option_value=[]
		@custom_stats_options.each do |custom_stat_option|
				if (custom_stat_option.option_value!="textbox") && (custom_stat_option.option_value!="textarea")
					custom_stats_option_value<<custom_stat_option.option_value
				end
		end
	@custom_stats_option_value=custom_stats_option_value.join("\r\n") 
	end
	
	def update
		@custom_stat = CustomStat.find_by_id(params[:custom_stat][:id])
		if @custom_stat
				field_type=params[:custom_stat][:field_type]	
			  if field_type=="textbox" || field_type=="textarea"
					textarea_or_textbox_field_type_update
				elsif field_type=="radio" || field_type=="checkbox" ||  field_type=="dropdown"
					custom_options_field_type_update
				else
					@custom_stat.errors.add(:field_type, "Please select field type")
					render :action => "edit"
				end	
		end
	end
	
	def textarea_or_textbox_field_type_update
			@custom_stats_option_value=params[:custom_stat_options]
		  @custom_stat.title=params[:custom_stat][:title]
		  @custom_stat.field_type=params[:custom_stat][:field_type]
			if @custom_stat.valid?
				@custom_stat.save		
				flash[:success]="Custom stat updated successfully."
				redirect_to :action => "index"
			else
				render :action => "edit"
			end
			
	end
	
	def custom_options_field_type_update
		@custom_stat.title=params[:custom_stat][:title]
		@custom_stat.field_type=params[:custom_stat][:field_type]
		@custom_stats_option_value=params[:custom_stat_options]
		options=params[:custom_stat_options].split("\r\n")
		if @custom_stat.valid?
			if options.length >0
				@custom_stat.save
				delete_existing_options
				options.each do |option|	
					@custom_stat_option=CustomStatOption.create(:custom_stat_id=> @custom_stat.id,:option_value=>option)
				end
				flash[:success]="Custom stat updated successfully."
				redirect_to :action => "index"
			else
				flash[:notice]="Provide custom stats options"
				render :action => "edit"
			end
		else
			render :action => "edit"
		end
		
	end
	
	def delete_existing_options #existing
		@custom_stat_options=@custom_stat.custom_stat_option_ids
		@custom_stat_options.each do |customstat|
			custom=CustomStatOption.find_by_id(customstat)
			custom.delete	
		end
	end
	
	def destroy
		@custom_stat = CustomStat.find_by_id(params[:id])
		if @custom_stat
				@custom_stat.destroy
				flash[:success] =  "Custom stat deleted successfully!"
		end	
		redirect_to(admin_custom_stats_url)
	end

end
