class Admin::EmailNotificationsController < ApplicationController
	layout "admin"
	include AdminAuthenticatedSystem
	before_filter :admin_login_required
	@@entries_per_page = 10
	
	def index
		@users = User.find(:all,:conditions=>['activated_at is NOT NULL'])
	end
	
	def create
		if params[:user_notification] 
			params[:user_notification].include?("0") ? email_notification_to_all_users : email_notification_to_particular_users
		end
		redirect_to admin_bodytypes_path
	end
	
	def email_notification_to_all_users
		@users = User.find(:all,:conditions=>['activated_at is NOT NULL'])
		str = params[:email_notification][:message]
		@users && @users.each { |user|
			msg=params[:select_option]=="[name]" ? str.gsub('[name]',user.name) : str.gsub('[email]',user.email) if user
			email_notification=EmailNotification.create(:email=>user.email,:subject=>params[:email_notification][:subject],:message=>msg) if user
		}
		flash[:success]="Email notification succesfully saved to all users."
	end
	
	def email_notification_to_particular_users
		str = params[:email_notification][:message]
		params[:user_notification] && params[:user_notification].each { |user_id|
		user=User.find_by_id(user_id)
		msg=params[:select_option]=="[name]" ? str.gsub('[name]',user.name) : str.gsub('[email]',user.email) if user
		email_notification=EmailNotification.create(:email=>user.email,:subject=>params[:email_notification][:subject],:message=>msg) if user
		}
		flash[:success]="Email notification succesfully saved to particular user(s)."
	end
	end