class Admin::EnquiriesController < ApplicationController
	layout "admin"
  include AdminAuthenticatedSystem
	before_filter :admin_login_required
  @@entries_per_page = 10
	
	def index
			@enquiries = Enquiry.find(:all)
	end
	
	def show
			@enquiry = Enquiry.find(params[:id])
	end
	
	def destroy
	@enquiry = Enquiry.find_by_id(params[:id])
		if @enquiry
				@enquiry.destroy
				flash[:success] =  "Enquiry deleted successfully!"
		end	
		redirect_to(admin_enquiries_url)
	end

end
