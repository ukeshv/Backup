class Admin::EthnicitiesController < ApplicationController
	layout "admin"
	include AdminAuthenticatedSystem
	before_filter :admin_login_required
  @@entries_per_page = 10
	
	def index
		conditions = "(name like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"
    options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
   
    if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @ethnicities = Ethnicity.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @ethnicities = Ethnicity.paginate(options)
      @search_ethnicity=1
      @search_value=params[:search]
    else
      @ethnicities = Ethnicity.paginate(options)
    end
	end
	
	def create
	@ethnicity = Ethnicity.new(params[:ethnicity])
		if @ethnicity.save
			@ethnicities = Ethnicity.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
			render :update do |page|
				page.hide "name_ethnicity"
				page.show "flashnotice"
				page.replace_html "list", :partial=>"listing_ethnicities"
				page.replace_html "flashnotice", :text=>"Ethnicity created successfully!"
				page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
				page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
			end
		else
			 show_hide_error_messages(@ethnicity,'ethnicity')	    
		end
	end
	
	def edit
		@ethnicity = Ethnicity.find(params[:id])
    render :layout =>false
	end	
	
	def update
		@ethnicity = Ethnicity.find(params[:id])
      if @ethnicity.update_attributes(params[:ethnicity])
        @ethnicities = Ethnicity.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
        render :update do |page|
          page.hide "edit_#{@ethnicity.id}"
          page.hide "name_ethnicity"
          page.replace_html "editname_#{@ethnicity.id}", :partial=>"updated_ethnicity"
          page.replace_html "flashnotice", :text=>"Ethnicity Updated successfully!"
          page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
          page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
        end
      else
         show_hide_error_messages1(@ethnicity,'ethnicity')	    
		end
	end
	
	def destroy
	  @ethnicity = Ethnicity.find(params[:id])
		if @ethnicity.profiles.empty?
			@ethnicity.destroy
			flash[:success] =  "Ethnicity deleted successfully!"
		else
			flash[:success] =  "You cannot delete this ethnicity as it has related profiles created by users"
		end	
    respond_to do |format|
      format.html { redirect_to(admin_ethnicities_url) }
      format.xml  { head :ok }
    end
	end
	
	 def show_hide_error_messages(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id
               page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
             end
              page.hide "flashnotice"
							page.hide "search_text"
             	page.hide "name_ethnicity"  if  obj.errors["name"].nil?
           end
         end
		end
			 
	def show_hide_error_messages1(obj,replacing_id)
		 render :update do |page|
			 for h in obj.errors.entries
				 if !obj.errors["#{h[0]}"].nil?
					 page.show "#{h[0]}_" +  replacing_id + "1"
					 page.replace_html "#{h[0]}_" + replacing_id+"1", "#{h[1]}"
				 end
					page.hide "flashnotice"
					page.hide "name_ethnicity"
					page.hide "name_ethnicity1"  if  obj.errors["name"].nil?
			 end
		 end
	end
	
	def cancel
  @ethnicity = Ethnicity.find(params[:id]) 
		render :update do |page|
    page.replace_html "edit_#{@ethnicity.id}", :partial=>"edit_icon"
		end
  end
	
end
