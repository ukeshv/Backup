class Admin::FaqsController < ApplicationController
  layout "admin"
  include AdminAuthenticatedSystem
	before_filter :admin_login_required
  @@entries_per_page = 10
  
  def  index
		@faqs=Faq.find(:all)
	end

	def new
		@faq=Faq.new()
	end
  
  def create
		@faq = Faq.new(params[:faq])
		if @faq.valid? 
      @faq.save
      flash[:success] =  "Faq added successfully!"
      redirect_to :action => "index"
		else
			render :action => "new"
		end
	end
  
  def edit
		@faq=Faq.find(params[:id])
	end
  
  def update
		@faq = Faq.find_by_id(params[:faq][:id])
    @faq.update_attributes(:title=>params[:faq][:title],:description=>params[:faq][:description])
		#~ if @faq
		#~ end
		flash[:success]="Faq updated successfully."
		redirect_to :action => "index"
	end
  
  def destroy
		@faq = Faq.find_by_id(params[:id])
		if @faq
				@faq.destroy
				flash[:success] =  "Faq deleted successfully!"
		end	
		redirect_to(admin_faqs_url)
	end





end
