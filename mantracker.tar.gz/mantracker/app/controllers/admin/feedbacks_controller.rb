class Admin::FeedbacksController < ApplicationController
	layout "admin"
  include AdminAuthenticatedSystem
	before_filter :admin_login_required
  @@entries_per_page = 10
	
	def index
			@feedbacks = Feedback.find(:all)
	end
	
	def show
			@feedback = Feedback.find(params[:id])
	end
	
	def destroy
	@feedback = Feedback.find_by_id(params[:id])
		if @feedback
				@feedback.destroy
				flash[:success] =  "Feedback deleted successfully!"
		end	
		redirect_to(admin_feedbacks_url)

	end

end
