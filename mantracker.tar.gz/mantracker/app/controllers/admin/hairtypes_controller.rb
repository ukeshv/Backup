class Admin::HairtypesController < ApplicationController
	layout "admin"
	include AdminAuthenticatedSystem
	before_filter :admin_login_required
	@@entries_per_page = 10
	
	def index
		conditions = "(name like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"
    options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
   
    if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @hairtypes = Hairtype.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @hairtypes = Hairtype.paginate(options)
      @search_hairtype=1
      @search_value=params[:search]
    else
      @hairtypes = Hairtype.paginate(options)
    end
	end
	

	def create
		@hairtype = Hairtype.new(params[:hairtype])
		if @hairtype.save
			@hairtypes = Hairtype.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
			render :update do |page|
				page.hide "name_bodytype"
				page.show "flashnotice"
				page.replace_html "list", :partial=>"listing_hairtypes"
				page.replace_html "flashnotice", :text=>"Bodytype created successfully!"
				page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
				page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
			end
		else
			 show_hide_error_messages(@hairtype,'bodytype')	    
		end
	end
	
	def edit
		@hairtype = Hairtype.find(params[:id])
    render :layout =>false
	end
	
 def update
	 @hairtype = Hairtype.find(params[:id])
      if @hairtype.update_attributes(params[:hairtype])
        @hairtypes = Hairtype.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
        render :update do |page|
          page.hide "edit_#{@hairtype.id}"
          page.hide "name_bodytype"
          page.replace_html "editname_#{@hairtype.id}", :partial=>"updated_hairtype"
          page.replace_html "flashnotice", :text=>"Category Updated successfully!"
          page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
          page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
        end
      else
         show_hide_error_messages1(@hairtype,'bodytype')	    
      end
 end
 
 def destroy
	  @hairtype = Hairtype.find(params[:id])
		if @hairtype.profiles.empty?
			@hairtype.destroy
			flash[:success] =  "Hair type deleted successfully!"
		else
			flash[:success] =  "You cannot delete this hair type as it has related profiles created by users"
		end	
    respond_to do |format|
      format.html { redirect_to(admin_hairtypes_url) }
      format.xml  { head :ok }
    end
 end
 
  def show_hide_error_messages(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id
               page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
             end
              page.hide "flashnotice"
              page.hide "search_text"
             	page.hide "name_bodytype"  if  obj.errors["name"].nil?
           end
         end
  end
	def show_hide_error_messages1(obj,replacing_id)
		 render :update do |page|
			 for h in obj.errors.entries
				 if !obj.errors["#{h[0]}"].nil?
					 page.show "#{h[0]}_" +  replacing_id + "1"
					 page.replace_html "#{h[0]}_" + replacing_id+"1", "#{h[1]}"
				 end
					page.hide "flashnotice"
					page.hide "name_bodytype"
					page.hide "name_bodytype1"  if  obj.errors["name"].nil?
			 end
		 end
	end
	
	def cancel
  @hairtype = Hairtype.find(params[:id]) 
		render :update do |page|
    page.replace_html "edit_#{@hairtype.id}", :partial=>"edit_icon"
		end
  end
	
end
