class Admin::HeightsController < ApplicationController
	layout "admin"
	include AdminAuthenticatedSystem
	before_filter :admin_login_required
	@@entries_per_page = 10
	
	def index
		conditions = "(name like '%#{params[:search]}%')" if params[:search] #if only search text is entered    
    params[:order] ||= "created_at" #assigning default ordering field    
    params[:by] ||= "desc" #assigning default order
    order = "#{params[:order]} #{params[:by]}"
    options = {:per_page => @@entries_per_page,:page => params[:page],:order => order,:conditions => conditions} #forming options hash initially
   
    if params[:order] && params[:by] && !params[:search] #if there is no search field 
      @heights = Height.paginate(options)
    elsif params[:search] &&  !params[:search].empty? && !params[:search].blank? #if search field is provided    
      @heights = Height.paginate(options)
      @search_height=1
      @search_value=params[:search]
    else
      @heights = Height.paginate(options)
    end
	end
	

	def create
		@height = Height.new(params[:height])
		h = params[:height][:name]
		h1 = h.gsub('inches','')
		h2 = h1.scan('"')
		if !h2.empty?
				h3 = h1.gsub('"','.')
				@height.h_value = h3
				else
				@height.h_value = h1
		end
		@height.h_value 
		if @height.save
			@heights = Height.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
			render :update do |page|
				page.hide "name_bodytype"
				page.show "flashnotice"
				page.replace_html "list", :partial=>"listing_heighttypes"
				page.replace_html "flashnotice", :text=>"Height created successfully!"
				page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
				page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
			end
		else
			 show_hide_error_messages(@height,'bodytype')	    
		end
	end
	
	def edit
		@height = Height.find(params[:id])
    render :layout =>false
	end
	
 def update
	 @height = Height.find(params[:id])
      if @height.update_attributes(params[:height])
        @heights = Height.paginate(:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
        render :update do |page|
          page.hide "edit_#{@height.id}"
          page.hide "name_bodytype"
          page.replace_html "editname_#{@height.id}", :partial=>"updated_heighttypes"
          page.replace_html "flashnotice", :text=>"Height Updated successfully!"
          page.visual_effect(:appear, 'flashnotice',  :duration => 1.5)
          page.visual_effect(:fade, 'flashnotice',  :duration => 2.5)
        end
      else
         show_hide_error_messages1(@height,'bodytype')	    
      end
 end
 
 def destroy
	  @height = Height.find(params[:id])
		if @height.profiles.empty?
			@height.destroy
			flash[:success] =  "Height deleted successfully!"
		else
			flash[:success] =  "You cannot delete this height as it has related profiles created by users"
		end	
    respond_to do |format|
      format.html { redirect_to(admin_heights_url) }
      format.xml  { head :ok }
    end
 end
 
  def show_hide_error_messages(obj,replacing_id)
         render :update do |page|
           for h in obj.errors.entries
             if !obj.errors["#{h[0]}"].nil?
               page.show "#{h[0]}_" +  replacing_id
               page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
             end
              page.hide "flashnotice"
              page.hide "search_text"
             	page.hide "name_bodytype"  if  obj.errors["name"].nil?
           end
         end
  end
	def show_hide_error_messages1(obj,replacing_id)
		 render :update do |page|
			 for h in obj.errors.entries
				 if !obj.errors["#{h[0]}"].nil?
					 page.show "#{h[0]}_" +  replacing_id + "1"
					 page.replace_html "#{h[0]}_" + replacing_id+"1", "#{h[1]}"
				 end
					page.hide "flashnotice"
					page.hide "name_bodytype"
					page.hide "name_bodytype1"  if  obj.errors["name"].nil?
			 end
		 end
	end
	
	def cancel
  @height = Height.find(params[:id]) 
		render :update do |page|
    page.replace_html "edit_#{@height.id}", :partial=>"edit_icon"
		end
  end
end
