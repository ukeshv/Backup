class Admin::HomepageSettingsController < ApplicationController
	layout "admin"
	include AdminAuthenticatedSystem
	before_filter :admin_login_required
	before_filter :check_new_flash, :only => [:dynamic_area2]
	
	def index
				@dynamics = HomepageSetting.find(:all,:conditions=>['is_primary = true'])
	end
	
	def check_new_flash
		#homepage_count = 	HomepageSetting.count :conditions=>["flash_uploads.is_primary = false"],:include=>[:flash_uploads]
		homepage_count = 	HomepageSetting.count :conditions=>["is_primary = false"]
		if homepage_count >= 6
				redirect_to admin_flash_list2_path
		end		
	end		
	
	def new_flash
				@new_flash = HomepageSetting.new(params[:flash_upload])		
				flash_upload = FlashUpload.new(params[:flash])
				@new_flash.is_primary = true
        @new_flash.step = 0				
				if  @new_flash.valid? && flash_upload.valid?
						@new_flash.flash_uploads << flash_upload
						@new_flash.save
						redirect_to :action=>'list_dynamic1_flash'
				else
						redirect_to :action=>'failed'
				end		
		end
		
	def new_flash2
				@flash_upload2 = HomepageSetting.new(params[:flash_upload2])		
				flash_upload1 = FlashUpload.new(params[:flash])
				flash_upload2 = FlashUpload.new(params[:Image])
				@flash_upload2.is_primary = false
				@flash_upload2.step = 1
				if  @flash_upload2.valid? && flash_upload1.valid? && flash_upload2.valid?
						@flash_upload2.flash_uploads << flash_upload1
						@flash_upload2.flash_uploads << flash_upload2
						@flash_upload2.save
						redirect_to :action=>'list_dynamic2_flash'
				else
						render :action=>'dynamic_area2'
				end		
		end
		
		def failed
				
		end
		
		def dynamic_area1
	
		end	
		def dynamic_area2
	   @flash_upload2 = HomepageSetting.new()
		end	

		def list_dynamic2_flash
				@dynamics2 = HomepageSetting.find(:all,:conditions=>['is_primary = false'])
		end	
		
		def list_dynamic1_flash
				@dynamics = HomepageSetting.find(:all,:conditions=>['is_primary = true'])
		end

		def flash_del2
				if  HomepageSetting.find(params[:id]).destroy
				  redirect_to :action=>'list_dynamic2_flash'
				end
		end
		
		def flash_del
				if  HomepageSetting.find(params[:id]).destroy
				  redirect_to :action=>'list_dynamic1_flash'
				end
		end
		
		def flash_edit2
				@flash_upload = HomepageSetting.find(params[:id])
				session[:place_holder] = @flash_upload.place_holder
				return unless request.post?
				@flash_upload.title = params[:flash_upload][:title]
				@flash_upload.place_holder = params[:flash_upload][:place_holder]
				@flash_upload.step = 1
				if @flash_upload.save
				@data = HomepageSetting.find_by_place_holder(params[:flash_upload][:place_holder])
				@data.update_attribute(:place_holder,session[:place_holder])
						if params[:flash]
								@flash_upload.flash_uploads.find(:first,:conditions=>["content_type = ?",'application/x-shockwave-flash']).destroy if !@flash_upload.flash_uploads.find(:first,:conditions=>["content_type = ?",'application/x-shockwave-flash']).nil?
								flash_upload = FlashUpload.new(params[:flash])
								@flash_upload.flash_uploads << flash_upload
								@flash_upload.save
						end		
						if params[:Image]
								@flash_upload.flash_uploads.find(:first,:conditions=>["content_type != ?",'application/x-shockwave-flash']).destroy if !@flash_upload.flash_uploads.find(:first,:conditions=>["content_type != ?",'application/x-shockwave-flash']).nil?
								flash_upload = FlashUpload.new(params[:Image])
								@flash_upload.flash_uploads << flash_upload
								@flash_upload.save
						 end	
						session[:place_holder] = nil
					 redirect_to :action=>'list_dynamic2_flash'
				else
						render :action => 'flash_edit2'
				end		
		end	
		
		def flash_edit
				@flash_upload = HomepageSetting.find(params[:id])
				return unless request.post?
				@flash_upload.update_attributes(params[:flash_upload])
				if params[:flash]
						@flash_upload.flash_uploads.each{|x| x.destroy}
						flash_upload = FlashUpload.new(params[:flash])
						@flash_upload.flash_uploads << flash_upload
						@flash_upload.save
				end		
       redirect_to :action=>'list_dynamic1_flash'
	 end		
	 
	 def footer_links
			 @footer_links = FooterLink.find(:all)
	 end
	 
	 def edit_footer_links
			 @footer_link = FooterLink.find(params[:id])
			 return unless request.post?
			 if @footer_link.update_attributes(params[:footer_link])
					 redirect_to :action=>'footer_links'
				else
						render :action => 'edit_footer_links'
				end
	 end

		
		
end
