class Admin::UsersController < ApplicationController
	layout "admin"
	include AdminAuthenticatedSystem
	before_filter :admin_login_required
	protect_from_forgery :except=>[:index]
	@@entries_per_page = 10
	
	def index
    if (params[:search] && !params[:search].empty? && !params[:search].blank?) 
			search = params[:search]
			params[:order] ||= "created_at" #assigning default ordering field    
			params[:by] ||= "desc" #assigning default order
			order = "users.#{params[:order]} #{params[:by]}"
			@users = User.paginate(:all,:conditions=>["(users.name like '%%"+search+"%%') or (email like '%%"+search+"%%') or (email like '%%"+search+"%%') or (profiles.address like '%%"+search+"%%')"],:include=>[:profile],:order=>order,:page=>params[:page], :per_page=>@@entries_per_page)
			@search_users=1
      @search_value=params[:search]
		elsif params[:order] || params[:by]
			@users = User.paginate(:all,:order => "#{params[:order]} #{params[:by]}",:page=>params[:page], :per_page=>@@entries_per_page)
    else
			@users = User.paginate(:all,:order=>"created_at DESC",:page=>params[:page], :per_page=>@@entries_per_page)
    end
	end		
	
		def edit
			@user = User.find_by_id(params[:id])
			load_profile_values
		end

		def update
			load_profile_values
			if params[:type] && params[:type]=="user_details"
				user_details_update
			elsif params[:type] && params[:type]=="user_profile_details"
				user_profile_update
			elsif params[:type] && params[:type]=="user_change_password" 
				change_password
			elsif params[:type] && params[:type]=="custom_details" 
					custom_profile_update_details
			end
		end
		
		def custom_profile_update_details
			if (params[:profiletype] && (params[:profiletype]=="textarea" || params[:profiletype]=="textbox"))
					params[:message] ? create_or_update_custom_stat_value(params[:message].strip)  : ""
			elsif (params[:profiletype] && (params[:profiletype]=="dropdown"))
				params[:option] && params[:option] !="-Select-" ? create_or_update_custom_stat_value(params[:option]) : ""
			elsif (params[:profiletype] && (params[:profiletype]=="checkbox"))
				custom_profile_checkbox_update
			end
		end
		
		def create_or_update_custom_stat_value(value)
			@customstats_value=CustomStatsValue.find(:first,:conditions=>['custom_stat_id = ? && user_id = ?',params[:custom_stat_id],params[:id]])
			if @customstats_value.nil?
				@custom_stats_value=CustomStatsValue.create(:user_id=>params[:id],:custom_stat_id=>params[:custom_stat_id],:field_value=>value)
			else
				customstats_value=@customstats_value.update_attribute("field_value",value)
			end
				custom_profile_updated_successfully #user profile partials called here
		end
			
		def custom_profile_updated_successfully
			flash[:success] = "Custom Profile updated successfully."
			redirect_to admin_users_path
		end
		
		def custom_profile_checkbox_update
			if params[:option] 
				selected_value=params[:option].join(",") 
				create_or_update_custom_stat_value(selected_value)
			else
				#custom_profile_error_msg
			end
		end
	
		def user_profile_update
			@user = User.find(params[:id])
			
			@user.profile.height_id=params[:height_id]
			@user.profile.ethnicity_id=params[:ethnicity_id]
			@user.profile.hairtype_id=params[:hairtype_id]
			@user.profile.bodytype_id=params[:bodytype_id]
			@user.profile.body_hairtype_id=params[:body_hairtype_id]
			
			@user.profile.is_age_required = true 
			@user.profile.is_weight_required = true 
			#@user.profile.is_height_required=true
			
			verify_address #here address validated
			
			if @verify_address && @user.profile.update_attributes(params[:profile])
				flash[:success] = "User profile details Updated Successfully!"
				redirect_to admin_users_path
			else
				render :action=>"edit"
			end
		end
		
		
	def user_details_update
		@user = User.find(params[:id])
		#@user.status= params[:user][:status] &&  params[:user][:status]=="1" ? true : false
			if @user.update_attributes(params[:user])
				flash[:success] = "User Updated Successfully!"
				redirect_to admin_users_path
			else
				render :action=>"edit"
			end
	end
	
	def verify_address
		@verify_address=false
		@location = GeoKit::Geocoders::GoogleGeocoder.geocode(params[:profile][:address])
   if @location.success? && !(params[:profile][:address].blank?)
		  @user.profile.latitude=@location.lat
		  @user.profile.longitude=@location.lng
			@verify_address=true
	 else
		@user.profile.errors.add(:address, "Please provide valid address")
   end  
 end 
 
	def change_password
	@user = User.find_by_id(params[:id])
	return unless request.post?
	is_render=true
		unless params[:password].blank? || params[:password_confirmation].blank?
			if params[:password].length > 5
					if params[:password] == params[:password_confirmation]
						if @user.update_attributes(:password=>params[:password], :password_confirmation=>params[:password_confirmation])
							flash[:success] = "Password is successfully changed"
							redirect_to admin_users_path
							 is_render=false
						end
					else
						flash.now[:passsword_error] = "Mismatch in Password and Confirmation Password."
					end 
				else
					flash.now[:passsword_error] = "Password Must have at least 6 characters."
			end	
		else
			flash.now[:passsword_error]="Required field cannot be left blank"	
		end	
	 render :action => 'change_password' if  is_render
 end	
	 
	def load_profile_values
		@custom_stats=CustomStat.find(:all)
		@bodytypes = Bodytype.find(:all)
		@hairtypes = Hairtype.find(:all)
		@bodyhairtypes = BodyHairtype.find(:all)		
		@heights = Height.find(:all)	
		@ethnicities = Ethnicity.find(:all)	
	end	
	
	def destroy
		@user = User.find_by_id(params[:id])
		user_name=@user.name
		if @user
			@user.destroy
			flash[:success] =  "User #{user_name} deleted successfully!"
		end	
    redirect_to admin_users_path
	end
	
end
