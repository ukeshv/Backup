class ApplicationController < ActionController::Base

  helper :all

  protect_from_forgery

  include ExceptionNotifiable
	
  include AuthenticatedSystem
	include RespondsToParent
	
	def collect_buddies_squirt(buddies_list)
		squirt_collection = []		
		buddies_list.each do |each_buddy|
			squirt_collection << each_buddy.squirt
		end
		return squirt_collection.flatten.uniq
	end
	
	def collect_squirts(page_type)
		if page_type == 'fresh'
			return Squirt.find(:all, :order => ['updated_at DESC'])
		else # buddies list			
			return collect_buddies_squirt(current_user.friends_by_me)
		end
  end


	def user_profile_sidebar_images
		location_address=current_user.profile.address
		location = GeoKit::Geocoders::GoogleGeocoder.geocode(location_address )
			profiles=[]
			if location.success? 
			profiles=Profile.find(:all, :origin =>location_address,:within=>5,:order=>'distance asc',:units =>"Miles")
			@profile_ids=profiles.collect { |x| x.user_id}
		end
   end

	def browse_user_profile_sidebar_images(location_address,distance,unit,online_stat)
		  location = GeoKit::Geocoders::GoogleGeocoder.geocode(location_address)
			profiles=[]
			if location.success? 
					
		  if !online_stat.nil?
		  (online_stat == "true") ? side_bar_online_user_list(location_address,distance,unit) : side_bar_user_list(location_address,distance,unit)
		  else
		  side_bar_user_list(location_address,distance,unit)
			end
		end
	end

  def side_bar_online_user_list(location_address,distance,unit)
		@online_users = [ ]
	  @online_users = User.find(:all,:conditions=>['online_status = ? and online_at >= ?',true,Time.now.utc]).collect{|x| x.id} 
		profiles=Profile.find(:all,:conditions=>['user_id IN (?)',@online_users], :origin =>location_address,:within=>distance,:order=>'distance asc',:units =>unit)
		@profile_ids=profiles.collect { |x| x.user_id}
  end
	
	def side_bar_user_list(location_address,distance,unit)
		profiles=Profile.find(:all, :origin =>location_address,:within=>distance,:order=>'distance asc',:units =>unit)
		@profile_ids=profiles.collect { |x| x.user_id}
	end

		def user_profile_images(id)
		@profile_userpublic_images = Image.find(:all,:conditions =>["is_private = ? and attachable_id = ? and attachable_type = ?",false,id,'User'],:order=>'position')
		#@user_private_images = Image.find(:all,:conditions => ["is_private = ? and attachable_id = ? and attachable_type = ?",true,params[:id],'User'],:order=>'position')
		private_photo_permission(id)
		end	

	def private_photo_permission(user_id)
			user = User.find_by_id(user_id)
			#if user.is_private_photos_locked.nil?
				@user_private_images = [ ]
		  #elsif user.is_private_photos_locked
			#	@user_private_images = [ ]
			#elsif !user.is_private_photos_locked
						@buddies_list = user.friends_by_me_ids
						#@view_list = PrivatePhotoView.find(:all, :conditions => ['viewer_id in (?)', @buddies_list])
						#@view_list = PrivatePhotoView.find(:all, :conditions => ["user_id = ? or	viewer_id in (?)",user,@buddies_list])
						@u_view =  PrivatePhotoView.find_by_user_id_and_viewer_id(user.id,current_user)
						if !@u_view.nil?
								@user_private_images = Image.find(:all,:conditions => ["is_private = ? and attachable_id = ? and attachable_type = ?",true,user_id,'User'],:order=>'position')
						end
						@photo_tab = "pub"
				#   if @buddies_list.include?(current_user.id)
				#			@u_view =  PrivatePhotoView.find_by_user_id_and_viewer_id(user.id,current_user)
				#			@u_view.is_locked ? @user_private_images = [ ] : @user_private_images = Image.find(:all,:conditions => ["is_private = ? and attachable_id = ? and attachable_type = ?",true,user_id,'User'],:order=>'position')
				#		else
				#		@user_private_images = Image.find(:all,:conditions => ["is_private = ? and attachable_id = ? and attachable_type = ?",true,user_id,'User'],:order=>'position')
				#	 end
		#end
	end

def load_footer_links
		@footer_links = FooterLink.find(:all)
end		


	def home_page_flash
		@dynamic_flash = HomepageSetting.find(:all,:conditions=>['is_primary = true'],:order => 'RAND()', :limit =>1)
		@dynamic_flash2 = HomepageSetting.find(:all,:conditions=>['is_primary = false'], :order => "place_holder", :limit => 3)
		@dynamic_flash3 = HomepageSetting.find(:all,:conditions=>['is_primary = false'], :order => "place_holder desc", :limit => 3).reverse
		@flash_image = HomepageSetting.find(:first,:conditions=>['is_primary = false'])
end

		def  setting_min_max_age
				@age = Profile.find(:all).collect {|x| x.age}
				@age_min = @age.min
				@age_max = @age.max
				return @age_min, @age_max
		end
		
		
		def  setting_min_max_weight
				@weight = Profile.find(:all, :conditions => ["weight != 'NULL'"]).collect {|x| x.weight}
				@weight_min = @weight.min
				@weight_max = @weight.max
				return @weight_min, @weight_max
		end


def fading_flash_message(text, seconds)
  text +
    <<-EOJS
      <script type='text/javascript'>
        Event.observe(window, 'load',function() { 
          setTimeout(function() {
            message_id = 'photouploadmsg';
						$(message_id).innerHTML = ""
            //new Effect.Fade(message_id);
          }, #{seconds*1000});
        }, false);
      </script>
    EOJS
end


end
