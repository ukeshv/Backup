class BrowseUsersController < ApplicationController
		before_filter :login_required
		before_filter :load_footer_links
		layout 'users',:except=>['view_large_image']
		
		def index
		session[:messages_tab] = "inbox"
    session[:current_tab]="profile"
		session[:distance_type] = (session[:distance_type] && session[:distance_type]=="Kms")  ?  "Kms" : "Miles"
		@unit = session[:distance_type]
		@total_messages = current_user.inbox_messages
		@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
					@all_msg_id = []
			 @messages.collect {|x| @all_msg_id << x.id}
		session[:browse_location] = @location_field = (params[:browse_location] && !params[:browse_location].empty?) ? params[:browse_location] : current_user.profile.address
		location = GeoKit::Geocoders::GoogleGeocoder.geocode(@location_field)
		@profile = current_user.profile
		@lat =  location.success? ? location.lat : "0.0"
		@long =  location.success? ? location.lng :  "0.0"
		session[:distance] = @distance=params[:browse_distance] && !params[:browse_distance].empty? ? params[:browse_distance] : "5"
		@start_distance = params[:start_distance] ? params[:start_distance] : '0' 
		#@view_type = current_user.browse_view_type
		

		# default slider values
		@slider_min = 0 
		@slider_max = 100
		@slider_step = 1
		@slider_default = 5
		if location.success? 
				params[:online_user_status] ? online_user_list(params[:online_user_status]) : user_list
		end
		  list_profiles 
    end
		
		def user_list
			@profiles_count =Profile.find(:all,:conditions=>["distance >= #{@start_distance.to_i} && distance <= #{@distance.to_i}"], :origin =>[@lat, @long],:order=>'distance asc',:units =>@unit)
				@profiles =Profile.paginate :all,:conditions=>["distance >= #{@start_distance.to_i} && distance <= #{@distance.to_i}"], :origin =>[@lat, @long],:order=>'distance asc',:units =>@unit,:page => params[:page],:per_page => 21
			session[:profile_ids] = @profiles_count.collect{|x| x.id} if !@profiles_count.empty?
		end
		
		def online_user_list(online_stat)
			  if (params[:online_user_status]=='true') #online_stat == "true"
						@online_users = [ ]
						@online_users = User.find(:all,:conditions=>['online_status = ? and online_at >= ?',true,Time.now.utc - 10]).collect{|x| x.id} 
						@profiles_count =Profile.find(:all,:conditions=>['user_id IN (?) && distance >= ? && distance <= ?',@online_users,"#{@start_distance.to_i}","#{@distance.to_i}"], :origin =>@location_field ,:within=>@distance.to_i,:order=>'distance asc',:units =>@unit)
						@profiles =Profile.paginate :all ,:conditions=>['user_id IN (?) && distance >= ? && distance <= ?',@online_users,"#{@start_distance.to_i}","#{@distance.to_i}"], :origin =>@location_field ,:within=>@distance.to_i,:order=>'distance asc',:units =>@unit,:page => params[:page],:per_page => 10
						session[:profile_ids] = @profiles_count.collect{|x| x.id} if !@profiles_count.empty?
				else
						@profiles_count =Profile.find(:all,:conditions=>["distance >= #{@start_distance.to_i} && distance <= #{@distance.to_i}"], :origin =>[@lat, @long],:order=>'distance asc',:units =>@unit)
				@profiles =Profile.paginate :all,:conditions=>["distance >= #{@start_distance.to_i} && distance <= #{@distance.to_i}"], :origin =>[@lat, @long],:order=>'distance asc',:units =>@unit,:page => params[:page],:per_page => 21
			session[:profile_ids] = @profiles_count.collect{|x| x.id} if !@profiles_count.empty?
				end
		end

		def browse
		end
		
		def list_profiles
		if params[:id]
		id = params[:id]
		@user=User.find(id)
		session[:profile_ids].empty? ? 	id='' :  id = @user.id
		else
	 session[:profile_ids] && session[:profile_ids].empty? ? 	id='' :  id = session[:profile_ids].first
	 profile = Profile.find(id)
	 @user= User.find(profile.user_id)
   end
		@user_profile=@user.profile
		unit = session[:distance_type]
		params[:online_user_status] ? browse_user_profile_sidebar_images(session[:browse_location],session[:distance],session[:distance_type],params[:online_user_status]) : browse_user_profile_sidebar_images(session[:browse_location],session[:distance],session[:distance_type],nil)
		user_profile_images(@user.id)
		viewed = @user.trackers.collect{|x| x.viewed_user_id}
		if ((@user.id != current_user.id) && !viewed.include?(current_user.id))
			 tracker = Tracker.create(:user_id=>params[:id],:viewed_user_id=>current_user.id)
		elsif viewed.include?(current_user.id)
			 @user_tracker = Tracker.find_by_user_id_and_viewed_user_id(@user.id,current_user.id)
			 @user_tracker.update_attributes(:updated_at=>Time.now)
		else
		end
		if params[:browse_distance] != nil
		if params[:browse_distance].to_i <= 1
		@slider_min = 0 
		@slider_max = 1
		@slider_step = 0.1
		@slider_default = 0.2
		elsif 	params[:browse_distance].to_i <= 20
		@slider_min = 0 
		@slider_max = 20
		@slider_step = 2
		@slider_default = 2
    elsif params[:browse_distance].to_i <= 100				
		@slider_min = 0 
		@slider_max = 100
		@slider_step = 1
		@slider_default = 5
		end
		end 
		
						if request.xhr?
								if params[:page] || (params[:browse_distance]  && params[:browse_location])
										render :update do |page|
												#page.show 'squirts_list'
												#page.replace_html 'squirts_list', :partial=>"browse_middle"
												page.replace_html 'results_count' ,:partial=>"browse_right"
												page[:sliderValue21h].value = session[:distance]
												page[:start_point].innerHTML = @start_distance
												page[:end_point].innerHTML = @slider_max
												#page[:end_point].innerHTML = session[:distance]
												#page.hide 'list_view'
												page.replace_html 'list_view', :partial=>"quick_view"
												page.replace_html 'online_check',:text=>'<input name="" type="checkbox" id="user_online_state" class="latest_chk" onclick="online_users_in_browse();" 
												checked />' if (params[:online_user_status] && (params[:online_user_status]=='true') && !@profiles_count.empty?)
												page.replace_html 'online_check',:text=>'<input name="" type="checkbox" id="user_online_state" class="latest_chk" 
												onclick="online_users_in_browse();" />' if (params[:online_user_status] &&  !(params[:online_user_status] == 'true') && !@profiles_count.empty?)
										end
								else
										render :update do |page|
												page.show 'squirts_list'
												if @profiles_count.empty?
												page.hide 'squirts_list'	
												else
												page.replace_html 'squirts_list', :partial=>"browse_middle"
												end
												page.replace_html 'results_count' ,:partial=>"browse_right"
												page.replace_html 'distance_type' ,:partial=>"browse_distance_type"
												page.replace_html 'browse_range_content' ,:partial=>"browse_range_display", :locals => {:browse_distance => params[:distance].to_i, :distance_type => params[:type]}
												page[:sliderValue21h].value = session[:distance]
												page[:start_point].innerHTML = @start_distance
												#page[:end_point].innerHTML = session[:distance]
												page[:end_point].innerHTML = @slider_max
												page.hide 'list_view'
												
								#page.replace_html 'online_check',:text=>"<input name='' type='checkbox' id='user_online_state' class='latest_chk' onclick='online_users_in_browse();' checked />" if (params[:online_user_status] && (params[:online_user_status]=="true") && !@profiles_count.empty?)
								page.replace_html 'online_check',:text=>"<input name='' type='checkbox' id='user_online_state' class='latest_chk' onclick='online_users_in_browse();' checked />" if (params[:online_user_status] && params[:online_user_status]=="true")
												#~ page.replace_html 'online_check',:text=>'<input name="" type="checkbox" id="user_online_state" class="latest_chk" onclick="online_users_in_browse();" />' if (params[:online_user_status] &&  !(params[:online_user_status] == 'true') && !@profiles_count.empty?)
										end
								end 
				else
				end
		end
		
	#~ def distance_search_type
		#~ params[:type] && params[:type]=="Miles" ?  type="Miles" : type="Kms"
		#~ session[:distance_type]=type
		#~ render :update do |page|
				#~ page.redirect_to browse_users_path
		#~ end
  #~ end
		def distance_search_type
		params[:type]=="Miles" ?  type="Miles" : type="Kms"
		session[:distance_type]=type
		unless params[:my_buddies]=="true" 
		 index
		end
	end

		
		def quick_list_profile_view
				if params[:view_type]=="quick_view"
				render :update do |page|
						current_user.update_attribute("browse_view_type",false)
						page.hide 'squirts_list'
						page.show 'list_view'
				end
		end
		if params[:view_type]=="list_view"
				current_user.update_attribute("browse_view_type",true)
				render :update do |page|
						page.show 'squirts_list'
						page.hide 'list_view'
				end
		end
  end

  def view_large_image
			 @user=User.find(params[:id])
			 @user_image=Image.find(@user.image_id)
  end

		
end

