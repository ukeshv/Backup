class PasswordsController < ApplicationController
		layout 'register'
		 before_filter :home_page_flash, :only=>[:reset,:update,:update_after_forgetting1,:update_after_forgetting]
	def new
				@password = Password.new
		end
		
	def new1
			render :update do |page|
					page.hide 'login_detail'
					page.show 'email_infomation'
				@password = Password.new
		end
end

  def create
    @password = Password.new(params[:password])
    @password.user = User.find_by_email(@password.email)
    if !params[:password][:email].empty?
      if !@password.user.nil?
        if @password.user && @password.user.activation_code.nil?    
          if @password.save
            PasswordMailer.deliver_forgot_password(@password)
            flash[:notice] = "A link to change your password has been sent to #{@password.email}."
            redirect_to :action => :new
          else
            render :action => :new
          end
        else
          flash.now[:error] = "Your Account is not activated. Please activate your account."
          render :action => :new
        end
      else
				flash.now[:error] = "Couldn't find user with this email address"
				render :action => :new
      end
    else
				flash.now[:error] = "Provide Email Address"
				render :action => :new
    end
  end


  def create1
    @password = Password.new(params[:password])
    @password.user = User.find_by_email(@password.email)
    if !params[:password][:email].empty?
      if !@password.user.nil?
        if @password.user && @password.user.activation_code.nil?    
          if @password.save
            PasswordMailer.deliver_forgot_password(@password)
            #flash[:notice] = "A link to change your password has been sent to #{@password.email}."
						 render :update do |page|
							  page.hide 'email_infomation'
								page.show 'login_detail'
							 	page['sent_msg'].innerHTML = "<font style='font-size:9px;color:green;'>Your login info has been sent</font>"
							#	page.show 'pwd_success_msg'
							#	page.show 'login_detail'
							#	page.hide 'pwd_error_msg'
							#	page.hide 'pwd_error_msg1'
							#	page.hide 'pwd_error_msg2'
							#	page.hide 'pwd_error_msg3'
							#	page.hide 'email_infomation'
            # redirect_to :action => :new
						end
          else
						render :update do |page|
								page.show 'pwd_error_msg'
								page.hide 'pwd_success_msg'
								page.hide 'pwd_error_msg1'
								#page.hide 'pwd_error_msg2'
								page.hide 'pwd_error_msg3'
            #render :action => :new
						end
          end
        else
				render :update do |page|
						page.show 'pwd_error_msg1'
						page.hide 'pwd_error_msg'
						page.hide 'pwd_success_msg'
						#page.hide 'pwd_error_msg2'
						page.hide 'pwd_error_msg3'
          #flash.now[:error] = "Your Account is not activated. Please activate your account."
         # render :action => :new
				end
        end
      else
				render :update do |page|
						#page.show 'pwd_error_msg2'
						page['fgt_err'].innerHTML = "<font style='font-size:9px;color:red;'>Could not find user with this email address.</font>"
						page.hide 'pwd_error_msg1'
						page.hide 'pwd_error_msg3'
						page.hide 'pwd_error_msg'
						page.hide 'pwd_success_msg'
					#flash.now[:error] = "Couldn't find user with this email address"
				#	render :action => :new
				end
      end
    else
				render :update do |page|
						page.show 'pwd_error_msg3'
						#page.hide 'pwd_error_msg2'
						page.hide 'pwd_error_msg1'
						page.hide 'pwd_error_msg'
						page.hide 'pwd_success_msg'
					#	flash.now[:error] = "Provide Email Address"
					#	render :action => :new
				end
    end
  end

  def reset
    begin
      @user = Password.find(:first, :conditions => ['reset_code = ? and expiration_date > ?', params[:reset_code], Time.now]).user
    rescue
      flash[:notice] = 'The change password URL you visited is either invalid or expired.'
      redirect_to root_path
    end    
  end

  def update_after_forgetting
     if params[:user][:password].blank?
       flash[:error] = "Password field cannot be blank."
       redirect_to :action => :reset, :reset_code => params[:reset_code]
       return
     end
    @user = Password.find_by_reset_code(params[:reset_code]).user
    
    if @user.update_attributes(params[:user])
      PasswordMailer.deliver_reset_password(@user)
      flash[:notice] = 'Password was successfully updated.'
      redirect_to login_path
    else
      flash[:error] = 'Password mismatch.'
      redirect_to :action => :reset, :reset_code => params[:reset_code]
    end
end

  def update_after_forgetting1
    @user = Password.find_by_reset_code(params[:reset_code]).user if !params[:reset_code].nil? && !params[:reset_code].empty?
    if !params[:user][:password].empty? && !params[:user][:password_confirmation].empty? && (params[:user][:password] ==params[:user][:password_confirmation])
				if (params[:user][:password].length < 4 || params[:user][:password].length > 20)
							render :update do |page|
									page.show 'change_pwd_error_msg1'
									page.hide 'change_pwd_error_msg'
							end
				else
						if @user.update_attributes(params[:user])
							PasswordMailer.deliver_reset_password(@user)
							flash[:notice] = 'Password was successfully updated.'
							render :update do |page|
									page.redirect_to root_path
							end
						else
							render :update do |page|
									page.show 'change_pwd_error_msg'
									page.hide 'change_pwd_error_msg1'
							end
					end
				end
		else
					render :update do |page|
							page.show 'change_pwd_error_msg'
							page.hide 'change_pwd_error_msg1'
					end
		end
  end
  
  def update
    @password = Password.find(params[:id])

    if @password.update_attributes(params[:password])
      flash[:notice] = 'Password was successfully updated.'
      redirect_to(@password)
    else
      render :action => :edit
    end
  end
end
