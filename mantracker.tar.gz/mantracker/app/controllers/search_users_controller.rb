class SearchUsersController < ApplicationController
		before_filter :login_required
		before_filter :load_footer_links
		layout 'users'
		
		def index
		session[:messages_tab] = "inbox"
    session[:current_tab]="profile"
		session[:distance_type] = (session[:distance_type] && session[:distance_type]=="Kms")  ?  "Kms" : "Miles"
		find_users	
		@total_messages = current_user.inbox_messages
		@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
		@all_msg_id = []
		@messages.collect {|x| @all_msg_id << x.id}
		@body_types = Bodytype.find(:all)
		@body_hair_types = BodyHairtype.find(:all)
		@hair_types = Hairtype.find(:all)
		@ethnicities = Ethnicity.find(:all)
		if request.xhr?
				if params[:page]
						render :update do |page|
								page.replace_html 'profile_page',:partial=>'view_user_profiles'
								page.replace_html 'profile_results_count',:partial=>'view_results_right'						
						end
				else
						render :update do |page|
							page.replace_html 'results_count',:partial=>'search_right'
							page.replace_html 'distance_type',:partial=>'search_distance_type'
						end
				end
		end
		end
		
		def find_users
			@total_messages = current_user.inbox_messages
			@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
			@all_msg_id = []
			@messages.collect {|x| @all_msg_id << x.id}
		unit = session[:distance_type]=="Kms" ? ":Kms" :  ":Miles"
		@profile = current_user.profile
		@location_field = (params[:squirts_search] && !params[:squirts_search].empty?) ? params[:squirts_search] : @profile.address
		@distance=params[:distance] && !params[:distance].empty? ? params[:distance] : "5"
		location = GeoKit::Geocoders::GoogleGeocoder.geocode(@location_field)
		if location.success? 
				@profiles_count =Profile.find(:all, :origin =>[@lat, @long] ,:within=>@distance.to_i,:order=>'distance asc',:units =>unit)
				@profiles =Profile.paginate :all, :origin =>[@lat, @long],:within=>@distance.to_i,:order=>'distance asc',:units =>unit,:page => params[:page],:per_page => 9
		end
		session[:profile_ids] = @profiles_count.collect{|x| x.id} if !@profiles_count.nil?
		end
			
		def search		
		@search_string = [ ]
		unit = session[:distance_type]=="Kms" ? ":Kms" :  ":Miles"
		session[:distance_type] = (session[:distance_type] && session[:distance_type]=="Kms")  ?  "Kms" : "Miles"
		@location_field = (params[:squirts_search] && !params[:squirts_search].empty?) ? params[:squirts_search] : @profile.address
		@distance=params[:distance] && !params[:distance].empty? ? params[:distance] : "5"
		condition_string
		location = GeoKit::Geocoders::GoogleGeocoder.geocode(@location_field)
		@lat = location.lat
		@long = location.lng
		if location.success? 
				@profiles_count=Profile.find(:all, :conditions=> ["#{@search_query}"], :origin =>[@lat, @long],:within=>@distance.to_i,:order=>'distance asc',:units =>unit)
				@profiles=Profile.paginate :all,:conditions=>"#{@search_query}", :origin =>[@lat, @long],:within=>@distance.to_i,:order=>'distance asc',:units =>unit,:page => params[:page],:per_page => 9
		end
				session[:profile_ids] = @profiles_count.collect{|x| x.id} if !@profiles_count.nil?
				render :update do |page|
						#if params[:modify_search]
								page.replace_html 'profile_page',:partial=>'view_user_profiles'
								page.replace_html 'profile_results_count',:partial=>'view_results_right'
					#	else
								page.replace_html 'results_count',:partial=>'search_right'
								page.replace_html 'profile_results_count',:partial=>'view_results_right'
								page.replace_html 'profile_page',:partial=>'view_user_profiles'
								page.replace_html 'online_check',:text=>'<input name="" type="checkbox" id="user_online_state" class="latest_chk" onclick="get_val();" checked />' if (params[:online_user_status]=='true')
								page.replace_html 'online_check',:text=>'<input name="" type="checkbox" id="user_online_state" class="latest_chk" onclick="get_val();" />' if !(params[:online_user_status] == 'true')
								
						#end
				end
		end
		
	def condition_string
	  get_from_param
		user_height_range(params[:height]) if !params[:height].blank?
		get_online_user_ids  if (params[:online_user_status]=='true')
		setting_min_max_age
		setting_min_max_weight
		@search_string << "profiles.user_id IN (#{@online_users})" if (params[:online_user_status]=='true')
		@search_string << "(profiles.title like '%%#{params[:profile_keyword]}%%' or profiles.name like '%%#{params[:profile_keyword]}%%')" if !params[:profile_keyword].blank?
	  @search_string << "profiles.age >= #{@age_from} and profiles.age <= #{@age_to}" if !(@age_from.to_i == @age_min && @age_to.to_i == @age_max)
		@search_string << "profiles.height_id IN (#{@height_range.join(",")})" if !@height_range.empty?
		@search_string << "profiles.weight >= #{@weight_from} and profiles.weight <= #{@weight_to}" if !(@weight_from.to_i == @weight_min && @weight_to.to_i == @weight_max)		
	  @search_string << "profiles.body_hairtype_id IN (#{@body_hair_type})" if !params[:body_hair_types].blank?
	  @search_string << "profiles.bodytype_id IN (#{@body_type})" if !params[:body_types].blank?
		@search_string << "profiles.ethnicity_id = #{params[:ethnicities]}" if !params[:ethnicities].blank?
	  @search_string << "profiles.hairtype_id IN (#{@hair_type})" if !params[:hair_types].blank?
	  @search_string << "profiles.user_id IN (#{@get_tat_profile_ids})" if !params[:tatoos].blank?
	  @search_string << "profiles.user_id IN (#{@get_interest_profile_ids})" if !params[:interests].blank?
	  @search_query = @search_string.join(" AND ")
  end

  def get_online_user_ids
			@online_users = [ ]
			@online_users = User.find(:all,:conditions=>["online_status = ? and online_at >= ?",true,Time.now.utc - 10]).collect{|x| x.id} 
			#@online_users = User.find(:all,:conditions=>['online_status = ? and online_at >= ?',true,Time.now.utc]).collect{|x| x.id} 
	end

	  def user_height_range(height_name)
		 height = height_name.split('-')
		 hfrom = height[0].to_i
     height_to = height[1].to_i

				if hfrom == 5 && height_to == 5.5
						a = ["5","5.1","5.2","5.3","5.4","5.5"]
				elsif hfrom == 5 && height_to == 6
						a = ["5","5.1","5.2","5.3","5.4","5.5","5.6","5.7","5.8","5.9","5.10","5.11","5.12","6"]
				elsif hfrom == 5 && height_to == 6.5
						a = ["5","5.1","5.2","5.3","5.4","5.5","5.6","5.7","5.8","5.9","5.10","5.11","5.12","6","6.1","6.2","6.3","6.4","6.5"]
				elsif hfrom == 5 && height_to == 7
						#a = ["5","5.1","5.2","5.3","5.4","5.5","5.6","5.7","5.8","5.9","5.10","5.11","5.12","6","6.1","6.2","6.3","6.4","6.5","6.6","6.7","6.8","6.9","6.10","6.11","6.12","7"]
						a = []
						
				elsif hfrom == 5.5 && height_to == 6
						a = ["5.5","5.6","5.7","5.8","5.9","5.10","5.11","5.12","6"]
				elsif hfrom == 5.5 && height_to == 6.5
						a = ["5.5","5.6","5.7","5.8","5.9","5.10","5.11","5.12","6","6.1","6.2","6.3","6.4","6.5"]
				elsif hfrom == 5.5 && height_to == 7
						a = ["5.5","5.6","5.7","5.8","5.9","5.10","5.11","5.12","6","6.1","6.2","6.3","6.4","6.5","6.6","6.7","6.8","6.9","6.10","6.11","6.12","7"]
						
				elsif hfrom == 6 && height_to == 6.5
						a = ["6","6.1","6.2","6.3","6.4","6.5"]
				elsif hfrom == 6 && height_to == 7
						a = ["6","6.1","6.2","6.3","6.4","6.5","6.6","6.7","6.8","6.9","6.10","6.11","6.12","7"]

				elsif hfrom == 6.5 && height_to == 7
						a = ["6.5","6.6","6.7","6.8","6.9","6.10","6.11","6.12","7"]
				end

			@height_range = Height.find(:all,:conditions=>["h_value in (?)",a]).collect{|x| x.id}
  	end

    	
	def get_from_param
		@get_tat_profile_ids = [ ]
		@get_interest_profile_ids = [ ]
		@body_type = [ ]
		@body_hair_type = [ ]
		@hair_type = [ ]
		
		age = params[:age].split('-')
		@age_from = age[0]
		@age_to= age[1]
		
		weight = params[:weight].split('-')
		@weight_from = weight[0]
		@weight_to = weight[1]
		
		@body_type << params[:body_types]
		@body_hair_type << params[:body_hair_types]
		@hair_type << params[:hair_types]
		@tatoos = params[:tatoos].split(",")
				if !params[:tatoos].blank?
				@tatoos.each do |tatoo|
				@get_tat_profile_ids = Profile.find(:all,:conditions=>["tattoos IS NOT NULL or tattoos LIKE '%%#{tatoo}%%'"]).collect{|x| x.user_id}
				#@get_tat_profile_ids = Profile.find(:all,:conditions=>["tattoos = ?","#{tatoo}"]).collect{|x| x.user_id}
				end
				end
		@interests = params[:interests].split(",")
				if !params[:interests].blank?
				@interests.each do |interest|
				@get_interest_profile_ids = Profile.find(:all,:conditions=>["interests  IS NOT NULL or interests LIKE '%%#{interest}%%'"]).collect{|x| x.user_id}
				end
		end
	end
	
		def show_results
				if params[:search_val] !=''
						@saved_searches = SavedSearch.create(:name=>params[:search_val],:user_id=>current_user.id,:address=>params[:squirts_search],:miles_kms=>params[:distance],:profile_keyword=>params[:profile_keyword],:age_from=>'0',:age_to=>params[:age],:height_from=>'0',:height_to=>params[:height],:weight_from=>'0',:weight_to=>params[:weight],:bodytype_id=>params[:body_types],:body_hairtype_id=>params[:body_hair_types],:hairtype_id=>params[:hair_types],:ethnicity_id=>params[:ethnicities],:tattoos=>params[:tatoos],:interests=>params[:interests])
						if @saved_searches.errors.empty?
								@profiles_count = Profile.find(:all,:conditions=>['id IN (?)',session[:profile_ids]])
								session[:profile_ids] = @profiles_count.collect{|x| x.id}
									@profiles = Profile.paginate :all,:conditions=>['id IN (?)',session[:profile_ids]] ,:page => params[:page], :order => 'updated_at DESC',:per_page => 10
										render :update do |page|
										page.hide 'slider1'
										page.show 'slider2'
										end
						else
								@profiles_count = Profile.find(:all,:conditions=>['id IN (?)',session[:profile_ids]])
								session[:profile_ids] = @profiles_count.collect{|x| x.id}
									@profiles = Profile.paginate :all,:conditions=>['id IN (?)',session[:profile_ids]] ,:page => params[:page], :order => 'updated_at DESC',:per_page => 21
								render :update do |page|
								page.replace_html "profile_page",:partial=>'view_user_profiles'
								page.visual_effect(:appear, 'search_error',  :duration => 1.5)
								end				
						end
				else
					@profiles_count = Profile.find(:all,:conditions=>['id IN (?)',session[:profile_ids]])
					session[:profile_ids] = @profiles_count.collect{|x| x.id}
					@profiles = Profile.paginate :all,:conditions=>['id IN (?)',session[:profile_ids]] ,:page => params[:page], :order => 'updated_at DESC',:per_page => 21
						render :update do |page|
								if params[:back_to_Search]
										page.hide 'squirts_list'
										page.show 'profile_page'
										page.replace_html 'profile_page',:partial=>'view_user_profiles'
								else
										page.hide 'slider1'
										page.show 'slider2'
								end
								end
				end
		end
		
		def results_page
		   @profiles_count = Profile.find(:all,:conditions=>['id IN (?)',session[:profile_ids]])
			 session[:profile_ids] = @profiles_count.collect{|x| x.id}
			@profiles = Profile.paginate :all,:conditions=>['id IN (?)',session[:profile_ids]] ,:page => params[:page], :order => 'updated_at DESC', :per_page => 10
				render :update do |page|
  					page.replace_html 'profile_page',:partial=>'view_user_profiles'
						page.replace_html 'profile_results_count',:partial=>'view_results_right'
				end
		end
		
		def modify_search
				@profiles = Profile.paginate :all,:conditions=>['id IN (?)',session[:profile_ids]] ,:page => params[:page], :order => 'updated_at DESC',:per_page => 10
				render :update do |page|
						#page['search_to_save'].value=''
						page.hide 'search_error'
						page.show 'slider1'
  					page.hide'slider2'
						page.hide 'squirts_list'
						page.show 'profile_page'
						page.replace_html 'profile_page',:partial=>'view_user_profiles'
				end

		end
		
	#~ def distance_search_type
		#~ params[:type] && params[:type]=="Miles" ?  type="Miles" : type="Kms"
		#~ session[:distance_type]=type
		#~ render :update do |page|
				#~ page.redirect_to 'index'
		#~ end
  #~ end
	
	def distance_search_type
		params[:type]=="Miles" ?  type="Miles" : type="Kms"
		session[:distance_type]=type
		unless params[:my_buddies]=="true" 
		 index
		end
	end

		def display_result_count
		unit = session[:distance_type]=="Kms" ? ":Kms" :  ":Miles"
		session[:distance_type] = (session[:distance_type] && session[:distance_type]=="Kms")  ?  "Kms" : "Miles"
		find_users	
				render :update do |page|
						page.replace_html 'results_count',:partial=>'search_right'
  					page.replace_html 'profile_page',:partial=>'view_user_profiles'
						page.replace_html 'profile_results_count',:partial=>'view_results_right'
				end
		end
		
		
end
