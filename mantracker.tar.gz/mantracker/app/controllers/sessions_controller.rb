# This controller handles the login/logout function of the site.  
class SessionsController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  include AuthenticatedSystem
		layout :change_layout
		
  # render new.rhtml
	def index
			home_page_flash #flash related objects called here
			if current_user
						redirect_to :controller=>'users' , :action=>'dashboard'
		  end
	end
	
  def new
		 redirect_to root_path
  end
	
	  def create
    logout_keeping_session!
				user = User.authenticate(params[:email], params[:password])
				if user
					# Protects against session fixation attacks, causes request forgery
					# protection if user resubmits an earlier form using back
					# button. Uncomment if you understand the tradeoffs.
					# reset_session
					user.online_status = true
					user.save
					self.current_user = user
					new_cookie_flag = (params[:remember_me] == "1")
					handle_remember_cookie! new_cookie_flag
				  flash.now[:notice] = "Logged in successfully!"
						redirect_to(dashboard_path)
				else
					user.online_status = false
					user.save
						note_failed_signin
					@login       = params[:email]
					@remember_me = params[:remember_me]
					render :action => 'new'
		 	end
  end


  def create1
    logout_keeping_session!
				user = User.authenticate(params[:email], params[:password])
				if user
					# Protects against session fixation attacks, causes request forgery
					# protection if user resubmits an earlier form using back
					# button. Uncomment if you understand the tradeoffs.
					# reset_session
							user.online_status = true
							user.save
							self.current_user = user
							new_cookie_flag = (params[:remember_me] == "1")
							handle_remember_cookie! new_cookie_flag
							user.update_attributes(:last_loggedin=>Date.today)
							session[:freeze_account] = ''
							render :update do |page|
								  page['err_msg'].innerHTML = "" 
									#page.hide "error_message"
								#	page.show "success_message"
						if	user.is_freezed?
								session[:freeze_account] = true
						else
								session[:freeze_account] = ''
						end
								flash.now[:notice] = "Logged in successfully"
								page.redirect_to :controller=>'browse_users',:action=>'index'
				  end

				else
					@login       = params[:login]
					@remember_me = params[:remember_me]
					#render :action => 'new'
						render :update do |page|
						#page.hide "flash_notice"
						#page.hide "success_message"
						page['err_msg'].innerHTML = "Incorrect Email/Password, please try again" 
						page['sent_msg'].innerHTML = "" 
						
						#page.show "error_message"
						end
		 	end
  end
	

  def destroy
		if current_user
					current_user.online_status = false
					current_user.save
		end
    logout_killing_session!
    flash[:notice] = "You have been logged out."
    redirect_back_or_default('/')
		end


  def change_layout
			(action_name=="index") ? "register" : "demo"
  end


  def change_flash_image
			@flash_image = HomepageSetting.find(params[:id])
			render :update do |page|
					page.replace_html 'flash_dyn', :partial=>'/partials/flash_part'
					page.replace_html 'image_dyn', :partial=>'/partials/image_part'
			end		
	end		

		def assign_profile_names
				users = User.find(:all)		
				users.each do |u|
						if !u.profile.nil? && u.id == u.profile.user_id
								u.profile.update_attributes(:name=>u.name.humanize)
						end
				end		
		end		

protected
  # Track failed login attempts
  def note_failed_signin
    flash.now[:error] = "Couldn't log you in as '#{params[:email]}'"
    logger.warn "Failed login for '#{params[:login]}' from #{request.remote_ip} at #{Time.now.utc}"
  end
end
