class SettingsController < ApplicationController
		before_filter :login_required
		
	def my_settings
		@total_messages = current_user.inbox_messages
		@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
		@all_msg_id = []
		@messages.collect {|x| @all_msg_id << x.id}
		@total_friends = current_user.friends_by_me.find(:all)
		@blocked_user_ids = current_user.blocked_users.collect{|x| x.blocker_id}
		@blocked_user_lists = User.find(:all,:conditions=>['id IN (?)',@blocked_user_ids])
		@current_tab = params[:current_tab]
				return rightclick_redirect unless request.post?
	end
			
	def my_setting_partial
		@total_messages = current_user.inbox_messages
		@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
		@all_msg_id = []
		@messages.collect {|x| @all_msg_id << x.id}
		@total_friends = current_user.friends_by_me.find(:all)
		@blocked_user_ids = current_user.blocked_users.collect{|x| x.blocker_id}
		@blocked_user_lists = User.find(:all,:conditions=>['id IN (?)',@blocked_user_ids])
		@current_tab = params[:current_tab]
		render :update do |page|
			page.replace_html 'menu', :partial=>"/settings/header_menu"
			page.replace_html 'tab_setting', :partial=>"/settings/my_setting_partial"
		end	
	end	
      
    def faq
      @faqs = Faq.find(:all,:limit=>10,:order=>'updated_at desc')
			@current_tab = params[:current_tab]
			return rightclick_redirect unless request.post?
		end
				
    def faq_partial
			@faqs = Faq.find(:all,:limit=>10,:order=>'updated_at desc')
			@current_tab = params[:current_tab]
			render :update do |page|
				page.replace_html 'menu', :partial=>"/settings/header_menu"
				page.replace_html 'tab_setting', :partial=>"/settings/faq_partial"
			end	
		end	
		
    def feedback
			@current_tab = params[:current_tab]
			return rightclick_redirect unless request.post?
		end
		
	def feedback_partial
		@current_tab = params[:current_tab]
		render :update do |page|
			page.replace_html 'menu', :partial=>"/settings/header_menu"
			page.replace_html 'tab_setting', :partial=>"/settings/feedback_partial"
		end
	end	
    
    def contact_us
			@current_tab = params[:current_tab]
			return rightclick_redirect unless request.post?
	  end
				
		def contact_us_partial
			@current_tab = params[:current_tab]
			render :update do |page|
				page.replace_html 'menu', :partial=>"/settings/header_menu"
				page.replace_html 'tab_setting', :partial=>"/settings/contact_us_partial"
			end	
		end
		
		def sort_username
				@blocked_user_ids = current_user.blocked_users.collect{|x| x.blocker_id}
				blocked_user_lists = User.find(:all,:conditions=>['id IN (?) and name LIKE ?',@blocked_user_ids,"#{params[:letter]}%"])
			  blocked_user_lists1 = User.find(:all,:conditions=>['id IN (?) and name NOT LIKE ?',@blocked_user_ids,"#{params[:letter]}%"])
				@blocked_user_lists = blocked_user_lists + blocked_user_lists1
				render :update do |page|
						page.replace_html "change_blocked_users" ,:partial=>'block_list_users'
				end
		end
		
		def unblock_users
				user_ids = params[:user_ids].split(',')
				@unblock_users = BlockedUser.find(:all,:conditions=>['user_id = ? and blocker_id IN (?)',current_user.id,user_ids]).collect{|x| x.id}
				BlockedUser.destroy(@unblock_users)
				@blocked_user_ids = current_user.blocked_users.collect{|x| x.blocker_id}
				@blocked_user_lists = User.find(:all,:conditions=>['id IN (?)',@blocked_user_ids])
				render :update do |page|
						page.replace_html "change_blocked_users" ,:partial=>'block_list_users'
						page['unblock_message'].innerHTML = "<font color='green'>Unblocked selected user. </font>"
				end

		end
		
		def change_password
				@user = current_user
				if !params[:password].blank? && !params[:new_password].blank?
						if params[:new_password].length > 3
										user = User.authenticate(@user.email,params[:password])
										if user
														if user.update_attributes(:password=>params[:new_password], :password_confirmation=>params[:new_password])
																render :update do |page|
																page.show 'old_pwd_tick'
																page.show 'new_pwd_tick'
																page.replace_html 'flash_message',:text=>'<font color="green">Activation code has been sent to activate your new password. </font>'
																end
														else
														msg = "<font color='red'>password not updated</font>"		
														id1	= 'old_pwd_tick'
														id2 = 'new_pwd_tick'
														id3 = 'flash_message'
														show_flash_message(msg,id1,id2,id3)
														end
										else
										msg = "<font color='red'>Provide valid password </font>"	
										id1	= 'old_pwd_tick'
										id2 = 'new_pwd_tick'
										id3 = 'flash_message'
										show_flash_message(msg,id1,id2,id3)
								end
						else
						msg = "<font color='red'>New password length is too short</font>"
						id1	= 'old_pwd_tick'
						id2 = 'new_pwd_tick'
						id3 = 'flash_message'
						show_flash_message(msg,id1,id2,id3)
						end
		  else
				msg = "<font color='red'>Old Password and New password can't be blank</font>"
				id1	= 'old_pwd_tick'
				id2 = 'new_pwd_tick'
				id3 = 'flash_message'
				show_flash_message(msg,id1,id2,id3)
		  end
		 
		end
 
		def show_flash_message(msg,id1,id2,id3)
				render :update do |page|
				page.hide id1
				page.hide id2
				page.replace_html id3,:text=>msg
				page.visual_effect(:appear, id3,  :duration => 1.5)
				page.visual_effect(:fade, id3,  :duration => 2.5)
				end
		end
		
		def change_email
				@user = current_user
				 @user.step = 11
				 existing_email = current_user.email
				 @user.email = params[:new_email]
				 if @user.valid?
						new_email_activation_code(@user,params[:new_email],existing_email)
						#~ @user.update_attributes(:email=>params[:new_email])
						render :update do |page|
						page.show 'old_email_tick'
						page.show 'new_email_tick'
						page.replace_html 'flash_message1',:text=>"<font color='green'>Activation code has been sent to your new email address.</font>"
						end
				 else
						render :update do |page|
						page.hide 'old_email_tick'
						page.hide 'new_email_tick'
						page.replace_html 'flash_message1',:text=>"<font color='red'>#{@user.errors.on(:email)}</font>"
						end
				 end
				
		end
		
		def new_email_activation_code(user,email,existing_email)
				user.make_new_activation_code
				user.email = existing_email
				user.save
				session[:new_email] = email
				UserMailer.deliver_new_email_notification(user,email)
		end
		
		def activate_new_email
				logout_keeping_session!
				user = User.find_by_activation_code(params[:activation_code]) unless params[:activation_code].blank?
				case
				when (!params[:activation_code].blank?) && user && !user.active?
				user.email = session[:new_email]
				user.save
				user.activate!
				
					flash[:notice] = "New Email has been activated! Please login in to continue."
					redirect_to '/'
				when params[:activation_code].blank?
					flash[:error] = "The activation code was missing.  Please follow the URL from your email."
					redirect_back_or_default('/')
				else 
					flash[:error]  = "We couldn't find a user with that activation code -- check your email? Or maybe you've already activated -- try signing in."
					redirect_back_or_default('/')
				end
		end
		
		def cancel_account
		 user = current_user
		 user.destroy
			logout_keeping_session!	
			flash[:notice]  = "Your account has been deleted from the site."
			render :update do |page|
			page.redirect_to '/'
			end
	end
	
	def freeze_account
	end
	
	def unfreeze_account
		user = User.find_by_id(current_user.id)
		user.update_attribute("is_freezed",0)
		session[:freeze_account] = ''
		flash[:notice]  = "Your account has been activated."
		redirect_to '/'
  end

	def freeze_user_account
		user = User.find_by_id(current_user.id)
		user.update_attribute("is_freezed",1)
		logout_keeping_session!
		flash[:notice]  = "Your account has been frozen."
		redirect_to '/'
  end

  def send_contact_email
			message = params[:message]		
			if !message.blank?
			@enquiry = Enquiry.create(:name=>current_user.name,:user_email=>current_user.email,:message =>message)
			UserMailer.deliver_contact_us_mail(current_user,message)
			render :update do |page|
					page.replace_html 'success_contact_us' ,:text=>"<font color='green'>Email sent successfully </font>"
			end
			else
					render :update do |page|
						page.replace_html 'success_contact_us',:text=>"<font color='red'> Enter some message </font>"
						end
			end
			
	end
	
  def send_feedback
			message = params[:feedback_msg]		
			if !message.blank?
			@enquiry = Feedback.create(:user_id=>current_user.id,:description=>message,:name=>current_user.name,:user_email=>current_user.email)
			UserMailer.deliver_feedback_mail(current_user,message)
			render :update do |page|
					page.replace_html 'success_feedback' ,:text=>"<font color='green'>Feedback sent successfully </font>"
			end
			else
				render :update do |page|
					 page.replace_html 'success_feedback',:text=>"<font color='red'> Enter some message </font>"
				end
			end
			
	end
		
		def lock_photos
		if params[:photos] == "lock_all_members"
			current_user.update_attribute("is_private_photos_locked",true)
			PrivatePhotoView.delete_all("user_id = #{current_user.id}")
			render :update do |page|
				page.replace_html 'success_photo',:text=>"<font color='green'> Settings updated </font>"
			end
		end
		
		if params[:photos] == "except_buddies"
				@total_friends = current_user.friends_by_me.find(:all)
				@total_friends.each do |i|  
						@friend = PrivatePhotoView.new
						@friend.user_id = current_user.id
						@friend.viewer_id = i.id  
				    @friend.is_locked = false
						@friend.save
				end 
				current_user.update_attribute("is_private_photos_locked",false)
			render :update do |page|
				page.replace_html 'success_photo',:text=>"<font color='green'> Settings updated </font>"
			end
		end
		
		if params[:photos] == "none"
				render :update do |page|
						page.replace_html 'success_photo',:text=>"<font color='red'> choose a option </font>"
				end
		end

		end
		
		def rightclick_redirect
			flash[:error] ="Right click not allowed"
			redirect_to dashboard_path
			end
end
