class SquirtsController < ApplicationController
	#~ protect_from_forgery :except => ['create']
	layout 'users'
	before_filter :login_required
	before_filter :load_footer_links
	
	def index # display all squirts
		session[:messages_tab] = "inbox"
		session[:current_tab]="profile"
		session[:distance_type] = (session[:distance_type] && session[:distance_type]=="Kms")  ?  "Kms" : "Miles"
		fresh_squirts	
		fresh_squirts_update
		#@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.inbox_messages if session[:messages_tab]=="inbox"
		#@messages = current_user.sent_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.sent_messages if session[:messages_tab]=="sent"
		#@messages = current_user.sent_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.saved_messages if session[:messages_tab]=="saved"
		#@messages = current_user.deleted_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.deleted_messages if session[:messages_tab]=="trash"
		@all_msg_id = []
		@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
		@messages.collect {|x| @all_msg_id << x.id}
		@tracker_ids = current_user.trackers.find(:all,:conditions=>['updated_at > ?',Date.today-12]).collect{|x| x.viewed_user_id} if session[:messages_tab] == "trackers_tab"
		@users = User.find(:all,:conditions=>['id IN (?)',@tracker_ids]).paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 12 if session[:messages_tab] == "trackers_tab"
		@online_users = User.find(:all,:conditions=>['online_status = ? and online_at >= ? and id IN (?)',true,Time.now.utc,@tracker_ids])
		@t_time = Tracker.find(:all,:conditions=>['user_id = ? and viewed_user_id IN (?)',current_user.id,@tracker_ids])
		@t1 = {}
		@t_time.each do |t|
		@t1["#{t.viewed_user_id}"] = t.updated_at.strftime("%A %B %d") + " at " +t.updated_at.strftime("%H.%M%p")
		end

	end
	
	def fresh_squirts
		@cur_squirt_page = 'fresh_squirts'
		unit = session[:distance_type]=="Kms" ? ":Kms" :  ":Miles"
		@profile = current_user.profile
		my_squirt
		@location_field = (params[:squirts_search] && !params[:squirts_search].empty?) ? params[:squirts_search] : @profile.address
		@distance=params[:distance] && !params[:distance].empty? ? params[:distance] : "5"
		location = GeoKit::Geocoders::GoogleGeocoder.geocode(@location_field )
		squirts=[]
		if location.success? 
			profiles=Profile.find(:all, :origin =>@location_field ,:within=>@distance.to_i,:order=>'distance asc',:units =>unit)
			id_arr=profiles.collect { |x| x.user_id}
			squirts=Squirt.find(:all,:conditions=>['user_id IN (?)', id_arr],:order => 'updated_at DESC')
		end
		@squirts = squirts.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 10
		@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.inbox_messages
		@all_msg_id = []
		@messages.collect {|x| @all_msg_id << x.id}
	end
	
	def fresh_squirts_update
		if request.xhr?
			render :update do |page|
				page.show "squirts_bg" 			
				page.replace_html 'total_squirts_msg', :partial => 'squirts/squirts_msg_count'
				page.replace_html 'squirts_list', :partial => 'squirts/fresh_squirts_list'				
				page.replace_html 'pagination_links_for_squirts', :partial => 'squirts/pagination_links'
				page.replace_html 'distance_type', :partial => '/squirts/squirts_distance_type'
				page.replace_html 'squirts_bg', :partial => '/squirts/form_update'
				page[:squirts_type].value = @cur_squirt_page
				page.visual_effect(:highlight,'tester', :duration => 2.5) if !flash[:notice].blank?
				@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.inbox_messages
				@all_msg_id = []
				@messages.collect {|x| @all_msg_id << x.id}				
			end
		end
	end
	
	def change_cur_squirt
			flash[:notice]=""
		if(params[:cur_squirt_page] == "fresh_squirts")
			fresh_squirts
			fresh_squirts_update
		elsif(params[:cur_squirt_page] == "my_buddies_squirts")
			my_buddies
		elsif(params[:cur_squirt_page] == "my_latest_squirts")
			if (params[:squirts_search] && !params[:squirts_search].empty?)  ||  (params[:distance] && !params[:distance].empty?)
			 		fresh_squirts	
					fresh_squirts_update
			else
				@cur_squirt_page  = 'my_latest_squirts'
				@squirt=[]
				@squirt = current_user.squirt
				@squirts=current_user.squirt
				my_squirts_update
			end
		end
			
	end
		
	def my_squirts_update
		render :update do |page|
			page.show "squirts_bg"
			page.replace_html 'distance_type', :partial => '/squirts/squirts_distance_type'
			page.replace_html 'squirts_bg', :partial => '/squirts/last_squirt_form_update'
			page.replace_html 'squirts_list', :partial => 'squirts/my_squirt_list'
			unless @cur_squirt_page  == 'my_latest_squirts'
				page.replace_html 'pagination_links_for_squirts', :partial => 'squirts/pagination_links' 
				page.replace_html 'total_squirts_msg', "#{!current_user.squirt.nil? ?  1 : 0} <span class='result'>results</span>"
			end
			page[:squirts_type].value = @cur_squirt_page
		end
  end
	
		def my_buddies
		@cur_squirt_page  = 'my_buddies_squirts'
		my_buddies = []
		my_squirt
		@my_buddies="true"
		@profile=current_user.profile
		if params[:squirts_search] || params[:distance]
			squirts=[]
			@squirts=squirts.paginate 
			unit=session[:distance_type]=="Kms" ? ":Kms" :  ":Miles"
			@location_field=params[:squirts_search] && !params[:squirts_search].empty? ? params[:squirts_search] : @profile.address
			location = GeoKit::Geocoders::GoogleGeocoder.geocode(@location_field)
			if location.success? 
				friends_ids=[]
				friends_ids<< current_user.friends_by_me_ids
				friends_ids<< current_user.friends_for_me_ids
				friends_ids = friends_ids.flatten
				profiles=Profile.find(:all,:conditions=>['user_id IN (?)', friends_ids], :origin =>@location_field ,:within=>params[:distance].to_i,:order=>'distance asc',:units =>unit)
				id_arr=profiles.collect { |x| x.user_id}
				squirts=Squirt.find(:all,:conditions=>['user_id IN (?)', id_arr],:order => 'updated_at DESC')
				@squirts = squirts.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 10
				@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.inbox_messages
				@all_msg_id = []
				@messages.collect {|x| @all_msg_id << x.id}
			end

		else
			my_buddies << current_user.friends_by_me
			my_buddies << current_user.friends_for_me
			my_buddies = my_buddies.flatten
			squirts = collect_buddies_squirt(my_buddies)
			@squirts = squirts.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 10
			@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.inbox_messages
			@all_msg_id = []
			@messages.collect {|x| @all_msg_id << x.id}
		end
		my_buddies_squirts_update
	end
	
	def my_buddies_squirts_update
		
		if request.xhr?
			render :update do |page|
				page.show "squirts_bg"
				#page.replace_html 'search_left', :partial => 'squirts/buddies_search'
				page.replace_html 'total_squirts_msg', :partial => 'squirts/squirts_msg_count'
				page.replace_html 'squirts_list', :partial => 'squirts/my_buddies_squirts_list'				
				page.replace_html 'pagination_links_for_squirts', :partial => 'squirts/pagination_links'
				page.replace_html 'distance_type', :partial => '/squirts/buddies_distance_type' 
				page.replace_html 'squirts_bg', :partial => '/squirts/form_update'
				page.visual_effect :highlight,:tester,  :duration => 2.5 if !flash[:notice].blank?
				page[:squirts_type].value = @cur_squirt_page
			end
		end
	end

	
	def create
		my_squirt
		if params[:squirt] && params[:squirt][:message] && !params[:squirt][:message].strip.empty?
       if !@squirt.nil?
				 @squirt.destroy
			 end	 
			@squirt = Squirt.create(:message=>params[:squirt][:message],:user_id=>current_user.id)
			flash[:notice] = "Your squirt message is saved"
			if params[:page_name] == "buddies"
				my_buddies
			else	
				fresh_squirts
				fresh_squirts_update
			end
		end

	end
	
	def add_remove_buddy
		@squirt = Squirt.find(params[:squirt_id])
		friend = @squirt.user
		if params[:status] == 'add'
			current_user.friends_by_me << friend
			flash.now[:notice] = " #{friend.name} added to My Buddies"
		else
			current_user.remove_friendship_with(friend)
			flash.now[:notice] = " #{friend.name} removed from My Buddies"
		end
		(params[:page_name] == "buddies") ? my_buddies  : index # if users added or remove buddies from fresh_squirts(index)/my buddies tab
	end
	
	def my_squirt
				@squirt = current_user.squirt
	end
	
	def my_squirt_message_update
		my_squirt
		updated=false
		if params[:squirt][:message] && (params[:squirt][:message].strip != '')
			updated=true	
			if @squirt &&  !@squirt.nil?
				@squirt.update_attribute("message",params[:squirt][:message]) 
				flash[:notice] = "Your squirt message is updated now"
			else			
				@squirt = Squirt.create(:message=>params[:squirt][:message],:user_id=>current_user.id)
				flash[:notice] = "Your squirt message is saved"
			end
		end
		render:update do |page|
			page.replace_html 'squirts_list', :partial => 'squirts/my_squirt_list' if updated
			page.replace_html 'total_squirts_msg', " #{!current_user.squirt.nil? ?  1 : 0} <span class='result'>results</span>"
			page[:squirt_message].value = @squirt.message if !@squirt.nil?
		end
	end
	
	def my_squirt_message_delete
		if Squirt.exists?(params[:id])
			 Squirt.find(params[:id]).destroy
			 flash[:notice] = "Your squirt message is deleted"
		end
		my_squirt
		val=@squirt && !@squirt.blank? ? @squirt.message: ''
		render:update do |page|
			page.replace_html 'my_squirt_text_message', :partial => 'squirts/my_squirt_text_message'	
			page.replace_html 'msg_count', :text => "<span id='msg_count' style='margin-left: 6px; font-size: 25px; color:#376eae; font-weight: bold; '>#{120-val.length}	</span>"
			page.replace_html 'total_squirts_msg', " #{!current_user.squirt.nil? ?  1 : 0} <span class='result'>results</span>"
			page.replace_html 'squirts_list', :partial => 'squirts/my_squirt_list'			
			page.visual_effect(:highlight,'tester', :duration => 2.5)
		end
	end
=begin	
	def destroy # post in method: delete
		if Squirt.exists?(params[:id])
			Squirt.find(params[:id]).destroy
			my_squirt 
			render :update do |page|
				page.replace_html 'latest_squirt', :partial => '/squirts/last_squirt'
				page.replace_html 'delete_squirt_link', :partial => '/squirts/delete_squirt_link' 		
			end
		end
	end
=end
	def destroy # post in method: delete
		if Squirt.exists?(params[:id])
			Squirt.find(params[:id]).destroy
		  fresh_squirts
			fresh_squirts_update
		end
		end
	
	def distance_search_type
	params[:type] && params[:type]=="Miles" ?  type="Miles" : type="Kms"
		session[:distance_type]=type
		params[:my_buddies] && params[:my_buddies]=="true" ? my_buddies : index
	end
	
end