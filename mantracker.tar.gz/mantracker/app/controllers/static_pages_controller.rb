class StaticPagesController < ApplicationController
   layout 'demo'
  def aboutus
  end
  def contactus
  end
  def privacy_policy
  end
  def advertise
  end
end
