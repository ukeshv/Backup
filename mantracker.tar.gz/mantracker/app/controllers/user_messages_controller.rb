class UserMessagesController < ApplicationController
layout 'users'
before_filter :login_required
before_filter :load_footer_links

  def compose_message
			session[:my_buddies_tab]="my_buddies_tab" if params[:reply] && params[:reply]=="MYBUDDIES_SEND_MSG"
			session[:compose_user] = params[:user_id]
			@compose_message = User.find_by_id(params[:user_id])
			@user_image=Image.find(@compose_message.image_id)
			render :update do |page|
					page.replace_html 'messages_part',:partial=>"/partials/compose_a_message",:locals=>{:reply=>params[:reply],:tab=>params[:tab]}
			end
  end


 def open_inbox_message
		 session[:open_message_id] = ""
			 @message = Message.find_by_id(params[:message_id])
			 @message.update_attributes(:is_read=>true)
			 if @message.parent_msg_id.nil?
			 session[:open_message_id] = @message.id
			 else
			 session[:open_message_id] = @message.parent_msg_id
			 end
			 @message_threads = @message.message_thread
			 render :update do |page|
						page.replace_html 'messages_part' ,:partial=>"/partials/opened_message"
			 end
		end

 def open_msg_sent_saved_trash
			 @message = Message.find_by_id(params[:message_id])
			 @message.update_attributes(:is_read=>true)
			 @message_threads = @message.message_thread
			 render :update do |page|
						page.replace_html 'messages_part' ,:partial=>"/partials/opened_message2"
			 end
	 end
	 
	 def msg_inbox_read
			 msg_ids = params[:message_ids].split(',')
			 @read_message_id = Message.find(:all, :select => "id", :conditions => ["id in (?) and is_read = 1 and is_saved = 0 and is_deleted = 0 and receiver_id = ?",msg_ids,current_user])
			 @read_message = []
			 #@read_message_id.collect {|x| @read_message << x.id}
			 render :update do |page|
					 @read_message_id.each do |x|
							 @read_message = x.id
							 page.call "select_read_status_inbox", "check_#{@read_message}"
					 end
			 end
	 end 
	 
	 def msg_inbox_saved
			 msg_ids = params[:message_ids].split(',')
			 @read_message_id = Message.find(:all, :select => "id", :conditions => ["id in (?) and is_saved = 1 and is_read = 1 and is_deleted = 0 and receiver_id = ?",msg_ids,current_user])
			 @read_message = []
			 #@read_message_id.collect {|x| @read_message << x.id}
			 render :update do |page|
					 @read_message_id.each do |x|
							 @read_message = x.id
							 page.call "select_read_status_saved", "check_#{@read_message}"
					 end
			 end
	 end 
	 
	 def msg_inbox_trash
			 msg_ids = params[:message_ids].split(',')
			 @read_message_id = Message.find(:all, :select => "id", :conditions => ["id in (?) and is_saved = 0 and is_read = 1 and is_deleted = 1 and receiver_id = ?",msg_ids,current_user])
			 @read_message = []
			 #@read_message_id.collect {|x| @read_message << x.id}
			 render :update do |page|
					 @read_message_id.each do |x|
							 @read_message = x.id
							 page.call "select_read_status_trash", "check_#{@read_message}"
					 end
			 end
	 end 

		def inbox_action
      msg_ids = params[:message_ids].split(',')
      messages = Message.find(:all,:conditions=>['id in (?)',msg_ids])
			if session[:messages_tab] != "sent"
					if params[:option_value] == "Move To Trash"
						messages.each do |message|
								@read_status = message.is_read
								message.update_attributes(:is_deleted=>true,:is_saved=>false,:is_read =>@read_status)
						end
				end
				if params[:option_value] == "Save"
						messages.each do |message|
								@read_status = message.is_read
								message.update_attributes(:is_deleted=>false,:is_saved=>true,:is_read =>@read_status)
						end
				end
				if params[:option_value] == "Move To Inbox"
						messages.each do |message|
								@read_status = message.is_read
								message.update_attributes(:is_deleted=>false,:is_saved=>false,:is_read =>@read_status)
						end
				end
		  else
					if params[:option_value] == "Move To Trash"
						messages.each do |message|
								@read_status = message.is_read
								message.update_attributes(:is_deleted=>true,:is_saved=>false,:is_read =>@read_status,:sender_is_deleted=>true)
						end
				end
				if params[:option_value] == "Save"
						messages.each do |message|
								@read_status = message.is_read
								message.update_attributes(:is_deleted=>false,:is_saved=>true,:is_read =>@read_status,:sender_is_saved=>true)
						end
				end
				if params[:option_value] == "Move To Inbox"
						messages.each do |message|
								@read_status = message.is_read
								message.update_attributes(:is_deleted=>false,:is_saved=>false,:is_read =>@read_status)
						end
				end
			end			
			if session[:messages_tab]=="inbox"			
				@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)	
				@total_messages = current_user.inbox_messages
			elsif session[:messages_tab]=="sent"
				@total_messages = current_user.sent_messages
				@messages = current_user.sent_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
			elsif session[:messages_tab]=="saved"
				@total_messages = Message.find(:all, :conditions => ["(receiver_id=? and is_saved=1) or (sender_id=? and sender_is_saved=1)",current_user,current_user], :order => 'updated_at DESC') 
				@messages = Message.find(:all, :conditions => ["(receiver_id=? and is_saved=1) or (sender_id=? and sender_is_saved=1)",current_user,current_user], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT) 
			else
				@total_messages = Message.find(:all, :conditions => ["(receiver_id=? and is_deleted=1) or (sender_id=? and sender_is_deleted=1)",current_user,current_user], :order => 'updated_at DESC')
				@messages = Message.find(:all, :conditions => ["(receiver_id=? and is_deleted=1) or (sender_id=? and sender_is_deleted=1)",current_user,current_user], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
			end
			
      #@messages = current_user.saved_messages.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 5 if session[:messages_tab]=="saved"
      #@messages = current_user.deleted_messages.paginate :page => params[:page], :order => 'updated_at DESC', :per_page =>5 if session[:messages_tab]=="trash" 
								@all_msg_id = []
			 @messages.collect {|x| @all_msg_id << x.id}
				render :update do |page|
				if session[:messages_tab]	== "inbox"
						page.replace_html 'message_tab' ,:partial=>'/partials/inbox'
				elsif session[:messages_tab] == "sent"
						page.replace_html 'message_tab' ,:partial=>'/partials/sent'
				elsif session[:messages_tab] == "saved"
						page.replace_html 'message_tab' ,:partial=>'/partials/saved'
				elsif session[:messages_tab] == "trash"
						page.replace_html 'message_tab' ,:partial=>'/partials/trash_message'
				end
				
        page.replace_html 'flashnotice',"selected Message(s) sent to trash" if params[:option_value] == "Move To Trash"
        page.replace_html 'flashnotice',"selected Message(s) are saved" if params[:option_value] == "Save"
        page.replace_html 'flashnotice',"selected Message(s) are sent to inbox" if params[:option_value] == "Move To Inbox"
        page.visual_effect :fade,'flashnotice',:duration => 2.5
				end
		end
		
		def send_a_message
				if !params[:reply].nil?
						reply = params[:reply]
						else
						reply = ''		
				end
				if params[:tab]
						@tracker_ids = current_user.trackers.find(:all,:conditions=>['updated_at > ?',Date.today-12]).collect{|x| x.viewed_user_id}
						@users = User.find(:all,:conditions=>['id IN (?)',@tracker_ids]).paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 12
						@online_users = User.find(:all,:conditions=>['online_status = ? and online_at >= ? and id IN (?)',true,Time.now.utc,@tracker_ids])
						@t_time = Tracker.find(:all,:conditions=>['user_id = ? and viewed_user_id IN (?)',current_user.id,@tracker_ids])
						@t1 = {}
						@t_time.each do |t|
						@t1["#{t.viewed_user_id}"] = t.updated_at.strftime("%A %B %d") + " at " +t.updated_at.strftime("%H.%M%p")
						end

						session[:messages_tab] = params[:tab]
				else
						session[:messages_tab] = "inbox"
				end
				@total_messages = current_user.inbox_messages
				@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
				@all_msg_id = []
				@messages.collect {|x| @all_msg_id << x.id}
				if params[:unlock_photos]
						check_photo_view_exists(params[:receiver_id],false)
				end
				
				if params[:lock_photos]
						#check_photo_view_exists(params[:receiver_id],true)
						PrivatePhotoView.delete_all("user_id = #{current_user.id} and viewer_id = #{params[:receiver_id]}")
				end
				if params[:save_as_template]
						render :update do |page|
					if !params[:parent_msg_id].blank?
						page.replace_html 'show_template_list',:partial=>'/partials/name_a_template',:locals=>{:subject =>params[:message][:subject],:body =>params[:message][:body],:receiver_id=>params[:receiver_id],:parent_msg_id=>params[:parent_msg_id] }
						else
						page.replace_html 'change_display',:partial=>'/partials/name_a_template',:locals=>{:subject =>params[:message][:subject],:body =>params[:message][:body],:receiver_id=>params[:receiver_id],:parent_msg_id=>nil }
						end
				end
				else
				@message = Message.create(:sender_id=>current_user.id,:receiver_id=>params[:receiver_id],:parent_msg_id=>params[:parent_msg_id],:subject=>params[:message][:subject],:body=>params[:message][:body],:reply_type=>reply)
				if session[:my_buddies_tab] && session[:my_buddies_tab]=="my_buddies_tab"
						session[:my_buddies_tab]=nil
						revert_to_buddies_tab
				else
				render :update do |page|
						page.replace_html 'messages_part',:partial=>'/partials/messages'
            page.replace_html 'flashnotice',"Message sent successfully"
						page.delay(3) do 
								page[:flashnotice].innerHTML = ""
						end
            #page.visual_effect :fade,'flashnotice',:duration => 2.5
					end
				end
				end
		end
			
		def revert_to_buddies_tab
			@friends_ids=[]
			@friends_ids<< current_user.friends_by_me_ids
			@friends_ids<< current_user.friends_for_me_ids
			@friends_ids = @friends_ids.flatten
			params[:tab]=="my buddies" 
			@friends_ids =@friends_ids.paginate :page => params[:page], :per_page => 15
				render :update do |page|
					page.replace_html 'messages_part', :partial=>"/partials/my_buddies"			
				end
		end
		
		def check_photo_view_exists(id,val)
			photo = 	PrivatePhotoView.find_by_user_id_and_viewer_id(current_user.id,id)
			if photo
					photo.update_attributes(:is_locked=>val)
			else
		     PrivatePhotoView.create(:user_id=>current_user.id,:viewer_id=>params[:receiver_id],:is_locked=>val)
		  end
		end
		
	def save_a_template
		@message = Message.create(:sender_id=>current_user.id,:receiver_id=>params[:receiver_id],:parent_msg_id=>[:parent_msg_id],:subject=>params[:subject],:body=>params[:body])
		@total_messages = current_user.inbox_messages
		@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
		@all_msg_id = []
		@messages.collect {|x| @all_msg_id << x.id}
		if current_user.templates.count < 3
			@template1= Template.create(:user_id=>current_user.id,:subject=>params[:subject],:name=>params[:name],:body=>params[:body])
			render :update do |page|
				page.replace_html 'messages_part',:partial=>'/partials/messages'
				page.replace_html 'flashnotice',"Message sent successfully"
				page.visual_effect :fade,'flashnotice',:duration => 2.5
			end
		else
			render :update do |page|
				page.replace_html 'messages_part',:partial=>'/partials/messages'
				page.replace_html 'flashnotice',"Message sent successfully and template not saved"
				page.visual_effect :fade,'flashnotice',:duration => 2.5
			end
		end	
	end
		
		def select_a_template
				render :update do |page|
				if params[:message_id]
          page.replace_html 'show_template_list',:partial=>'/partials/template_list',:locals=>{:message_id =>params[:message_id]}
				else
         page.replace_html 'change_display',:partial=>'/partials/template_list',:locals=>{:message_id =>nil}
				end
				end
		end
		
		def edit_a_template
				@user_template = Template.find_by_id(params[:id])
					if !params[:message_id].blank?
				render :update do |page|
						page.replace_html 'show_template_list',:partial=>'/partials/edit_template',:locals=>{:message_id=>params[:message_id]}
				end
				else
				render :update do |page|
						page.replace_html 'change_display',:partial=>'/partials/edit_template',:locals=>{:message_id=>nil}
				end
				end
				
		end
		
		def delete_a_template
				@user_template = Template.find_by_id(params[:id])
				@user_template.destroy
				if !params[:message_id].blank?
				render :update do |page|
						page.replace_html 'show_template_list',:partial=>'/partials/template_list',:locals=>{:message_id=>params[:message_id]}
				end
		    else
				render :update do |page|
						page.replace_html 'change_display',:partial=>'/partials/template_list',:locals=>{:message_id=>nil}
				end
				end
				
		end
		
		def load_template
				if !params[:message_id].blank?
				@message = Message.find_by_id(params[:message_id])
				@message_threads = @message.message_thread
				@user_template = Template.find_by_id(params[:id])
				render :update do |page|
						page.replace_html 'show_template_list',:partial=>'/partials/reply_message'
				end
				else
			  @compose_message = User.find_by_id(session[:compose_user])
			  @user_image=Image.find(@compose_message.image_id)
				@user_template = Template.find_by_id(params[:id])
				render :update do |page|
						page.replace_html 'change_display',:partial=>'/partials/reply_message'
				end
		    end
		
		end
		
		def save_edit_template
				@t = Template.find_by_id(params[:template_id])
				@t.update_attributes(:body=>params[:body])
				if !params[:message_id].blank?
				render :update do |page|
						page.replace_html 'show_template_list',:partial=>'/partials/template_list',:locals=>{:message_id =>params[:message_id]}
						end
				else
				render :update do |page|
						page.replace_html 'change_display',:partial=>'/partials/template_list',:locals=>{:message_id =>nil}
						end
		   end
		
		end
      
      def close_message_template
				if !params[:message_id].blank?
						@message = Message.find_by_id(params[:message_id])
						render :update do |page|
								page.replace_html 'show_template_list',:partial=>'/partials/reply_message'
						end
				else
			@compose_message = User.find_by_id(session[:compose_user])
			@user_image=Image.find(@compose_message.image_id)
        render :update do |page|
						page.replace_html 'change_display',:partial=>'/partials/reply_message'
				end
				end
      end
      
      def close_editmessage_template
				if !params[:message_id].blank?
        render :update do |page|
        page.replace_html 'show_template_list',:partial=>'/partials/template_list',:locals=>{:message_id =>params[:message_id]}
		end
		else
        render :update do |page|
        page.replace_html 'change_display',:partial=>'/partials/template_list',:locals=>{:message_id =>nil}
				end
		end
		
		end
		
      def close_message
      @tracker_ids = current_user.trackers.find(:all,:conditions=>['updated_at > ?',Date.today-12]).collect{|x| x.viewed_user_id} if session[:messages_tab] == "trackers_tab"
      @users = User.find(:all,:conditions=>['id IN (?)',@tracker_ids]).paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 12 if session[:messages_tab] == "trackers_tab"
			@online_users = User.find(:all,:conditions=>['online_status = ? and online_at >= ? and id IN (?)',true,Time.now.utc,@tracker_ids])
			if session[:messages_tab]=="inbox"
				@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.inbox_messages	
			elsif session[:messages_tab]=="sent"
				@messages = current_user.sent_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.sent_messages	
			elsif session[:messages_tab]=="saved"
				@messages = current_user.saved_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.saved_messages	
			elsif session[:messages_tab]=="trash"
				@messages = current_user.deleted_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.deleted_messages	
			end
			@messages = @messages.nil? ? [] : @messages
			@all_msg_id = []
			@messages.collect {|x| @all_msg_id << x.id}
			@t_time = Tracker.find(:all,:conditions=>['user_id = ? and viewed_user_id IN (?)',current_user.id,@tracker_ids])
			@t1 = {}
			@t_time.each do |t|
			@t1["#{t.viewed_user_id}"] = t.updated_at.strftime("%A %B %d") + " at " +t.updated_at.strftime("%H.%M%p")
				end

				if 	session[:my_buddies_tab] && session[:my_buddies_tab]=="my_buddies_tab"
						session[:my_buddies_tab]=nil
						revert_to_buddies_tab
				else
        render :update do |page|
					page.replace_html 'messages_part',:partial=>'/partials/messages' if session[:messages_tab]
					page.call('initialiseScrollParams')
				end
			end
		end
		
      def close_message2
				#@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.inbox_messages	if session[:messages_tab]=="inbox"
				#@messages = current_user.sent_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.sent_messages	if session[:messages_tab]=="sent"
				#@messages = current_user.saved_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.saved_messages	if session[:messages_tab]=="saved"
				#@messages = current_user.deleted_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.deleted_messages	if session[:messages_tab]=="trash"
				if 	session[:messages_tab] == "sent"
						@total_messages = current_user.sent_messages
						@messages = current_user.sent_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
				elsif session[:messages_tab] == "saved"
						@total_messages = Message.find(:all, :conditions => ["(receiver_id=? and is_saved=1) or (sender_id=? and sender_is_saved=1)",current_user,current_user], :order => 'updated_at DESC') 
					@messages = Message.find(:all, :conditions => ["(receiver_id=? and is_saved=1) or (sender_id=? and sender_is_saved=1)",current_user,current_user], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT) 
				else 
						@total_messages = Message.find(:all, :conditions => ["(receiver_id=? and is_deleted=1) or (sender_id=? and sender_is_deleted=1)",current_user,current_user], :order => 'updated_at DESC')
			@messages = Message.find(:all, :conditions => ["(receiver_id=? and is_deleted=1) or (sender_id=? and sender_is_deleted=1)",current_user,current_user], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
				end
				@all_msg_id = []
				@messages.collect {|x| @all_msg_id << x.id}
        render :update do |page|
        page.replace_html 'messages_part',:partial=>'/partials/messages'
				page.call('initialiseScrollParams')
        end
      end
      
      def show_message_part
				session[:messages_tab] = "inbox"
				@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT); @total_messages = current_user.inbox_messages
				@all_msg_id = []
				@messages.collect {|x| @all_msg_id << x.id}
        render :update do |page|
          page.replace_html 'messages_part',:partial=>'/partials/messages'
					page.call('initialiseScrollParams')
        end
      end
      
      def show_inbox_message
					session[:messages_tab] = "inbox"
        #~ @messages = current_user.inbox_messages.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 5
				@total_messages = current_user.inbox_messages
				@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
				@all_msg_id = []
				@messages.collect {|x| @all_msg_id << x.id}
         render :update do |page|
          page.replace_html 'messages_part',:partial=>'/partials/messages'
					page.call('initialiseScrollParams')
        end
      end
      
      def show_sent_message
					session[:messages_tab] = "sent"
        #~ @messages = current_user.sent_messages.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 5
				@total_messages = current_user.sent_messages
				@messages = current_user.sent_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
									@all_msg_id = []
			 @messages.collect {|x| @all_msg_id << x.id}
        render :update do |page|
          page.replace_html 'messages_part',:partial=>'/partials/messages'
					page.call('initialiseScrollParams')
        end
      end
      
      def show_saved_message
				session[:messages_tab] = "saved"
				if session[:messages_tab]=="saved"
					@total_messages = Message.find(:all, :conditions => ["(receiver_id=? and is_saved=1) or (sender_id=? and sender_is_saved=1)",current_user,current_user], :order => 'updated_at DESC') 
					@messages = Message.find(:all, :conditions => ["(receiver_id=? and is_saved=1) or (sender_id=? and sender_is_saved=1)",current_user,current_user], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT) 
				end
				@all_msg_id = []
				@messages.collect {|x| @all_msg_id << x.id}
				render :update do |page|
					page.replace_html 'messages_part',:partial=>'/partials/messages'
					page.call('initialiseScrollParams')
				end
      end
      
	def show_trash_message
		session[:messages_tab]= "trash"
		if session[:messages_tab]=="trash"
			@total_messages = Message.find(:all, :conditions => ["(receiver_id=? and is_deleted=1) or (sender_id=? and sender_is_deleted=1)",current_user,current_user], :order => 'updated_at DESC')
			@messages = Message.find(:all, :conditions => ["(receiver_id=? and is_deleted=1) or (sender_id=? and sender_is_deleted=1)",current_user,current_user], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
		end		
		@all_msg_id = []
		@messages.collect {|x| @all_msg_id << x.id}
		render :update do |page|
			page.replace_html 'messages_part',:partial=>'/partials/messages'
			page.call('initialiseScrollParams')
		end
	end
		
		def sort_message
				session[:messages_tab] = "inbox" if params[:tab] == "inbox"
				session[:messages_tab] = "sent"   if params[:tab] == "sent"
				session[:messages_tab] = "saved" if params[:tab] == "saved"
				session[:messages_tab] = "trash" if params[:tab] == "trash"
				if (params[:tab] == "inbox" and params[:val] == "")
						@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
						@total_messages = current_user.inbox_messages
				elsif (params[:tab] == "inbox" and params[:val] == "SQUIRTS REPLY")
					 @messages = current_user.inbox_messages.find(:all, :conditions=>['reply_type =?',params[:val]], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
					 @total_messages = current_user.inbox_messages	if (params[:tab] == "inbox" and params[:val] == "SQUIRTS REPLY")
				elsif (params[:tab] == "inbox" and params[:val] == "PROFILE REPLY")
					 @messages = current_user.inbox_messages.find(:all, :conditions=>['reply_type =?',params[:val]], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
					 @total_messages = current_user.inbox_messages
					 
				elsif (params[:tab] == "sent" and params[:val] == "")
						@messages = current_user.sent_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
						@total_messages = current_user.sent_messages
				elsif (params[:tab] == "sent" and params[:val] == "SQUIRTS REPLY")
						@messages = current_user.sent_messages.find(:all, :conditions=>['reply_type =?',params[:val]], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
						@total_messages = current_user.sent_messages
				elsif (params[:tab] == "sent" and params[:val] == "PROFILE REPLY")
						@messages = current_user.sent_messages.find(:all, :conditions=>['reply_type =?',params[:val]], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
						@total_messages = current_user.sent_messages	
						
				elsif (params[:tab] == "saved" and params[:val] == "")
						@messages = current_user.saved_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
						@total_messages = current_user.saved_messages
				elsif (params[:tab] == "saved" and params[:val] == "SQUIRTS REPLY")
						@messages = current_user.saved_messages.find(:all, :conditions=>['reply_type =?',params[:val]], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
						@total_messages = current_user.saved_messages
				elsif (params[:tab] == "saved" and params[:val] == "PROFILE REPLY")
						@messages = current_user.saved_messages.find(:all, :conditions=>['reply_type =?',params[:val]], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
						@total_messages = current_user.saved_messages
						
				elsif (params[:tab] == "trash" and params[:val] == "")
						@messages = current_user.deleted_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
						@total_messages = current_user.deleted_messages
				elsif (params[:tab] == "trash" and params[:val] == "SQUIRTS REPLY")
						@messages = current_user.deleted_messages.find(:all, :conditions=>['reply_type =?',params[:val]], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
						@total_messages = current_user.deleted_messages
				elsif (params[:tab] == "trash" and params[:val] == "PROFILE REPLY")
						@messages = current_user.deleted_messages.find(:all, :conditions=>['reply_type =?',params[:val]], :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
						@total_messages = current_user.deleted_messages						
				end

				@all_msg_id = []
				@messages.collect {|x| @all_msg_id << x.id}
				render :update do |page|
					page.replace_html 'inbox_container',:partial=>'/partials/list_messages'
					page[:current_message_count].innerHTML = @messages.length
			end
		end

		
		def send_to_trash
		  @messages = current_user.inbox_messages.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 5
      @messages = current_user.sent_messages.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 5
      @messages = current_user.saved_messages.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 5
      @messages = current_user.deleted_messages.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 5

				@message = Message.find_by_id(params[:id])
				@message.update_attributes(:is_deleted=>true)
				render :update do |page|
						page.replace_html 'messages_part',:partial=>'/partials/messages'
            page.replace_html 'flashnotice',"Message sent to trash"
            page.visual_effect :fade,'flashnotice',:duration => 2.5
				end
		end
		
		def add_remove_to_buddies
		 @message = Message.find_by_id(params[:messageid])
  	 @message_threads = @message.message_thread
		@user = User.find_by_id(params[:id])
				friend = @user
			if params[:act_type] == 'add'
			render :update do |page|
				current_user.friends_by_me << friend
				page.replace_html 'messages_part' ,:partial=>"/partials/opened_message"
				page.replace_html 'added_buddy',"Added as your buddy"
        page.visual_effect :fade,'added_buddy',:duration => 2.5
					end
				else
				render :update do |page|
				current_user.remove_friendship_with(friend)
				page.replace_html 'messages_part' ,:partial=>"/partials/opened_message"
				page.replace_html 'added_buddy',"Removed from your list"
        page.visual_effect :fade,'added_buddy',:duration => 2.5
				 end
			end
	end
	
	def block_unblock_user
		 @message = Message.find_by_id(params[:messageid])
  	 @message_threads = @message.message_thread
			if params[:act_type] == 'block'
			render :update do |page|
				@block_user = BlockedUser.create(:user_id=>current_user.id,:blocker_id=>params[:id])
				page.replace_html 'messages_part' ,:partial=>"/partials/opened_message"
				page.replace_html 'added_buddy',"Blocked"
        page.visual_effect :fade,'added_buddy',:duration => 2.5
					end
				else
				render :update do |page|
				@unblock_user = BlockedUser.find_by_user_id_and_blocker_id(current_user.id,params[:id])
				@unblock_user.destroy
				page.replace_html 'messages_part' ,:partial=>"/partials/opened_message"
				page.replace_html 'added_buddy',"unblocked"
        page.visual_effect :fade,'added_buddy',:duration => 2.5
				 end
			end
	end
	
	def unsend_message
			@message = Message.find_by_id(params[:id])
			@message.destroy
      @messages = current_user.sent_messages.paginate :page => params[:page], :order => 'updated_at DESC', :per_page => 5
			session[:messages_tab] = "sent"
			render :update do |page|
        page.replace_html 'messages_part',:partial=>'/partials/messages'
        page.replace_html 'flashnotice',"Message unsend" 
        page.visual_effect :fade,'flashnotice',:duration => 2.5
			end
	end
	
		def show_trackers
				session[:messages_tab] = "trackers_tab"
				user = current_user
				@tracker_ids = user.trackers.find(:all,:conditions=>['updated_at > ?',Date.today-12]).collect{|x| x.viewed_user_id}
				@users = User.find(:all,:conditions=>['id IN (?)',@tracker_ids]).paginate :page => params[:page], :order => 'updated_at DESC', :per_page =>12
				@online_users = User.find(:all,:conditions=>['online_status = ? and online_at >= ? and id IN (?)',true,Time.now.utc - 10,@tracker_ids])
				@t_time = Tracker.find(:all,:conditions=>['user_id = ? and viewed_user_id IN (?)',current_user.id,@tracker_ids])
				@t1 = {}
				@t_time.each do |t|
				@t1["#{t.viewed_user_id}"] = t.updated_at.strftime("%A %B %d") + " at " +t.updated_at.strftime("%H.%M%p")
				end
				
				render :update do |page|
					page.replace_html 'messages_part',:partial=>'/partials/messages'
				end
		end

end
