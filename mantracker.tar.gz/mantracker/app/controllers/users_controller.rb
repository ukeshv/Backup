class UsersController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  include RespondsToParent
  before_filter :login_required, :except=>[:new,:signup1,:save_user_detail,:save_user_location,:save_user_photo,:partial3,:save_user_profile_detail,:create,:activate,:reset_signup_form]
  before_filter :load_footer_links
  layout :change_layout

  # render new.rhtml
  def new
    @user = User.new
  end

  def signup1
    reset_session
  end
	
  def reset_signup_form
    reset_session
    render :update do |page|				
		  page.hide "name_error"
			page.hide "password_error"
			page.hide "password_confirmation_error"
			page.hide "password_confirmation_imgerror"
			page.hide "email_error"
			page.hide "email_confirmation_error"
			page.hide "email_imgerror"
			page.hide "email_tick"
      page.hide 'replace_map'
      page.show 'user_partial'
			page.call 'clear_map_input'
    end
  end
			
  def save_user_detail
    @user = User.new
    @user.step = 10
    @user.name = params[:name]
    @user.password = params[:password]
    @user.password_confirmation = params[:password_confirmation]
    @user.email = params[:email]
    @user.email_confirmation = params[:email_confirmation]
    if @user.valid?
      render :update do |page|
        session[:user_name] = params[:name]
        session[:user_email] = params[:email]
        session[:user_password] = params[:password]
        session[:user_confirm_password] = params[:password_confirmation]
        session[:user_age] = params[:age]
        page.hide 'user_partial'
        page.show 'replace_map'
				page.call 'focus_map_input'
      end
    end
  end
 
  def save_user_location
    render :update do |page|
      session[:address] = params[:search]
      session[:latitude] = params[:latitude]
      session[:longitude] = params[:longitude]
      page.replace_html 'replace_map', :partial=>'step3'
		end

  end
 
  def save_user_photo
    if params[:image]
      @image1 = Image.new(params[:image])
      @image1.position=1
      @image1.save
    end
    if @image1.save
      session[:image] = @image1
      #create.wants.html do
      responds_to_parent do
	      render :update do |page|
	        page['upload_form'].reset
          @image = Image.find(:last,:conditions=>['thumbnail = ?','small'])
					page.show 'images_partial'
					page.show 'image_tick'
					page[:completed3].src = "/images/step3_completed.jpg"  
					page.hide "default_image"
					page.hide "image_error"
					page.hide "ajax_image3"
	        page.replace_html "images_partial", :partial =>'image'
					page.call 'validate_step3'
					page.show 'continue_container'
          #    page.visual_effect :appear, "ajax_image1"
	      end
      end
		else 
      responds_to_parent do
	      render :update do |page|
	        #page['upload_form'].reset
          @image = Image.find(:last)
					page.hide "image_tick"
	        page.show "images_partial"
					page[:face1].src = "/images/face.jpg"
				  page[:completed3].src = "/images/step3_hover.jpg" 
					page.show "image_error"
					page.hide "ajax_image3"
          if !(@image1.errors['content_type'].nil?)
            page[:pro_img].innerHTML = "You can only upload images (JPG, GIF or PNG) "
          else
            page[:pro_img].innerHTML = "Images should be smaller than 4 MB in size"
          end
					page.hide 'continue_container'
          #  page.visual_effect :appear, "ajax_image1"
	      end
      end

		end
    #end

  end
		
  def partial3
    render :update do |page|
      page.replace_html 'replace_map', :partial=>'step4'
    end
			
	end
 
  def save_user_profile_detail
    title = params[:user][:title]
    description = params[:user][:description]
    render :update do |page|
      @user = User.new
      @user.name= session[:user_name]
      @user.email = session[:user_email]
      @user.password = session[:user_password]
      @user.password_confirmation = session[:user_confirm_password]
      @user.image_id = session[:image].id if !session[:image].nil?
      @user.save
      @user.images << session[:image] if !session[:image].nil?
      @profile = Profile.new
			@profile.name = session[:user_name]
      @profile.age = session[:user_age]
      @profile.address = session[:address]
      @profile.latitude = session[:latitude]
      @profile.longitude = session[:longitude]
      @profile.title = title
      @profile.description = description
      @profile.user_id = @user.id
      @profile.save
      # flash[:notice] = "Thanks for signing up!  We're sending you an email with your activation code."
      page.replace_html 'replace_map', :partial=>'thanks_signup'
    end
  end
   
  def create
		if request.xhr?
      valid_user_age = false
      @user = User.new
      @user.name = params[:name]
      @user.password = params[:password]
      @user.password_confirmation = params[:password_confirmation]
      @user.email = params[:email]
      @user.email_confirmation = params[:confirm_email]
      @user.step = params[:step].to_i
		
		  if @user.step == 5
       if params[:age].to_i >= 18 
        session[:valid_user_age] = true
       else
        session[:age] = nil
        session[:valid_user_age] = false
       end
       if params[:terms].to_i == 1
        session[:valid_user_terms] = true
       else
				session[:valid_user_terms] = false
       end
		  end
		
		  valid_user_age = session[:valid_user_age]
		  valid_user_terms = session[:valid_user_terms]
		
      if @user.valid?
				 
				render :update do |page|
						
          page.hide "name_error"
          page.show 'name_tooltip' if @user.step == 1
						
          page.hide "password_error"
          page.show "password_tooltip" if (@user.step == 3 || @user.step == 4)
          page.hide "password_confirmation_error"
          page.hide "password_confirmation_tooltip"
						
          page.hide "email_error"
          page.show "email_tooltip" if (@user.step == 2 || @user.step == 6)
          page.hide "email_confirmation_error"
          page.hide "email_confirmation_tooltip"
						
          page.show "age_error" if !valid_user_age
          page.hide "age_error" if valid_user_age
          page.show "terms_error" if !valid_user_terms
          page.hide "terms_error" if valid_user_terms
          page.show 'age_tooltip' if @user.step == 5
						
          page.show "name_tick" if @user.step == 1
          page.show "email_tick" if ((@user.step == 2 || @user.step == 6) and (params[:email] && params[:confirm_email]) and (@user.errors['email'].nil? && @user.errors['confirm_email'].nil?))
          page.show "password_confirmation_tick" if ((@user.step == 3 || @user.step == 4) and (params[:password] && params[:password_confirmation] && @user.errors['password'].nil? && @user.errors['password_confirmation'].nil? ))
						
          page.hide "name_imgerror" if @user.step == 1
          page.hide "email_imgerror" if (@user.step == 2 || @user.step == 6)
          page.hide "password_confirmation_imgerror" if (@user.step == 3 || @user.step == 4)
						
					if @user.errors.blank? && valid_user_age && valid_user_terms 
						page.call 'show_form_if_all_fields_ticked'
					else
            page.hide 'hide_submit' #if !@user.errors.blank? || valid_user_age == false || valid_user_terms == false
				  end
				
          page[:completed1].src = "/images/step1_completed.jpg" if @user.errors.blank? && valid_user_age
          page[:completed1].src = "/images/step1_hover.jpg" if !@user.errors.blank? || valid_user_age == false
          page.hide 'age_tooltip' if @user.errors.blank? && valid_user_age && valid_user_terms
						
				end
      else
				
        render :update do |page|
          for h,k in @user.errors
						if !@user.errors["#{h}"].nil?
							page.show "#{h}_error"    
						  page.show "#{h}_tooltip"
              if h == "password"
                page.show "password_confirmation_imgerror"
              elsif h == "email_confirmation"
                page.show "email_imgerror"
              else
                page.show "#{h}_imgerror"
              end
							page.replace_html "#{h}_error","<div class='member_white'>#{k}</div>"
						end          
						page.hide "name_error" if @user.errors['name'].nil?
						page.hide "name_tooltip" if @user.errors['name'].nil?
						page.hide "name_tick" if !@user.errors['name'].nil?
						
						page.hide "password_error" if @user.errors['password'].nil? 
						page.hide "password_tooltip" if (@user.errors['password'].nil? || !@user.errors['password_confirmation'].nil?)
						page.hide "password_confirmation_error" if @user.errors['password_confirmation'].nil? 
						page.hide "password_confirmation_tooltip" if @user.errors['password_confirmation'].nil? 
				    page.hide "password_confirmation_tick" if !(@user.errors['password_confirmation'].nil? and @user.errors['password'].nil?)
					  page.hide "password_confirmation_imgerror"  if (@user.errors['password_confirmation'].nil? and @user.errors['password'].nil?)
						
						page.hide "email_error" if @user.errors['email'].nil? 
						page.hide "email_tooltip" if (@user.errors['email'].nil? || !@user.errors['email_confirmation'].nil?)
						page.hide "email_confirmation_error" if @user.errors['email_confirmation'].nil? 
						page.hide "email_confirmation_tooltip" if @user.errors['email_confirmation'].nil? 
				    page.hide "email_tick" if !(@user.errors['email_confirmation'].nil? and @user.errors['email'].nil?)
					  page.hide "email_imgerror"  if (@user.errors['email_confirmation'].nil? and @user.errors['email'].nil?)
						
						page.show "age_error" if valid_user_age == false
						page.hide "age_tooltip" if valid_user_age
						
						page.hide 'hide_submit' if !@user.errors.blank? || valid_user_age == false
						page[:completed1].src = "/images/step1_hover.jpg" if @user.errors.blank? || valid_user_age == false
					end
				end 
      end
    end

  end


  def activate
    logout_keeping_session!
    user = User.find_by_activation_code(params[:activation_code]) unless params[:activation_code].blank?
    case
    when (!params[:activation_code].blank?) && user && !user.active?
      user.activate!
      flash[:notice] = "Signup complete! Please sign in to continue."
      redirect_to '/'
    when params[:activation_code].blank?
      flash[:error] = "The activation code was missing.  Please follow the URL from your email."
      redirect_back_or_default('/')
    else 
      flash[:error]  = "We couldn't find a user with that activation code -- check your email? Or maybe you've already activated -- try signing in."
      redirect_back_or_default('/')
    end
  end

	def dashboard
    session[:messages_tab] = "inbox"
    session[:current_tab]="profile"
    @user=current_user
    @user_profile=@user.profile
    @user_image = Image.find(@user.image_id) if @user.image_id
    @primary_photo_id=@user.image_id if @user.image_id
		@total_messages = current_user.inbox_messages
		@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :limit => Message::PAGINATION_COUNT)
		#@messages = current_user.inbox_messages.find(:all, :order => "updated_at DESC")
		#@messages_count = current_user.inbox_messages.count
    @all_msg_id = []
    @messages.collect {|x| @all_msg_id << x.id}
    photo_upload
  end
  
  def photo_upload
		find_public_and_private_images
		@user=current_user 
    if params[:image]
      if !params[:image][:uploaded_data].nil?
        if params[:image][:is_private] == "true"
          params[:image][:position]=@private_images.length + 1
          flash[:photo_upload_msg] = fading_flash_message("Please delete a private photo first", 5)  if @private_images.length >=10
          #flash[:photo_upload_msg]= "Please delete a private photo first" if @private_images.length >=10
          @user.images << Image.new(params[:image]) if !params[:image][:uploaded_data].blank? if @private_images.length < 10
          if !@user.save #if @private_images.length < 10
            flash[:photo_upload_msg] = fading_flash_message("Images should be smaller than 4 MB in size", 5)
            #flash[:photo_upload_msg]= "Images should be smaller than 4 MB in size"
          end

        elsif params[:image][:is_private] == "false"
          params[:image][:position]= @public_images.length + 1
          flash[:photo_upload_msg] = fading_flash_message("Please delete a public photo first", 5)  if @public_images.length >=10
          #flash[:photo_upload_msg]= "Please delete a public photo first" if @public_images.length >= 10
          @user.images << Image.new(params[:image]) if !params[:image][:uploaded_data].blank? if @public_images.length < 10
          if !@user.save #if @public_images.length < 10
            flash[:photo_upload_msg] = fading_flash_message("Images should be smaller than 4 MB in size", 5)
            #flash[:photo_upload_msg]= "Images should be smaller than 4 MB in size"
          end
        end
        redirect_to dashboard_path
      else
        #flash[:photo_upload_msg]= "Choose a photo"
        flash[:photo_upload_msg] = fading_flash_message("Choose a photo", 5)
      end
    end
  end

	
	def profile_details
		@user=current_user 
		@user_profile=@user.profile
		@body_hairtypes=BodyHairtype.find(:all)
		@heights=Height.find(:all)
		@ethnicities = Ethnicity.find(:all)
		@hairtypes = Hairtype.find(:all)
		@bodytypes = Bodytype.find(:all)	
	end
	
	def display_stats
		profile_details
		partial_name = params[:stats]
		render :update do |page|
			page.replace_html 'list', :partial=>"/partials/#{partial_name}" 	if partial_name
		end
	end
	
	def update
		profile_details
		current_profile = (params[:age] ? "age" : nil)		
		@user.profile.is_age_required = (current_profile == "age" ? true : false)
		
		current_profile = (params[:weight]  ? "weight" : nil) if current_profile.nil?		
		@user.profile.is_weight_required = (current_profile == "weight" ? true : false)
		
		current_profile = (params[:height_id] && !params[:height_id].blank?) ? "height_id" : nil if current_profile.nil?
		@user.profile.is_height_required = (current_profile == "height_id" ? true : false)
		
		current_profile = (params[:tattoos] ? "tattoos" : nil) if current_profile.nil?
		current_profile = (params[:interests]  ? "interests" : nil) if current_profile.nil?
		
		current_profile = (params[:hairtype_id] && !params[:hairtype_id].blank?) ? "hairtype_id" : nil if current_profile.nil?
		current_profile = (params[:ethnicity_id] && !params[:ethnicity_id].blank?) ? "ethnicity_id" : nil if current_profile.nil?
		current_profile = (params[:bodytype_id] && !params[:bodytype_id].blank?) ? "bodytype_id" : nil if current_profile.nil?
		current_profile = (params[:body_hairtype_id] && !params[:body_hairtype_id].blank?) ? "body_hairtype_id" : nil if current_profile.nil?
		
		@user.profile.update_attributes(:"#{current_profile}"=>params["#{current_profile}"]) if  current_profile && !current_profile.empty?		
		
		if @user.profile.errors["#{current_profile}"].nil?
			render :update do |page|
				page.replace_html 'list', :partial=>"/partials/profile"			
			end
		else
			@profile_error = @user.profile.errors["#{current_profile}"]
			render :update do |page|
				page.replace_html "user_profile_#{current_profile}",@profile_error
			end
		end	
		
	end
	
	def profile_title
		@user = current_user
    @user.profile.update_attribute("title",params[:title])
    render :nothing=>:false
	end
	
	def profile_description
		@user = current_user
    @user.profile.update_attribute("description",params[:description])
    render :nothing=>:false
	end
	
	def  photo_order_update_for_public
		@user=current_user
		i=1
		list=params[:list]
		if (list && !list.empty? && list.length <= 10 )
			if (params[:list] && (params[:list].length > 0 ))
        params[:list].each { |x|
					if (x.to_i  > 0)
						image= Image.find(x.to_i)
						image.update_attributes(:position=>i,:is_private=>false)
						Image.find(:all, :conditions => ['parent_id = ?', image.id]).collect{|x| x.update_attributes(:is_private => false, :position => i)}
						i=i+1
					end
				}
			end
		end
		update_public_photo
	end
		
	def photo_order_update_for_private
		@user=current_user
		i=1
		list=params[:list]
		if (list && !list.empty? && list.length <= 10 )
			if (params[:list] && (params[:list].length > 0 ))
        params[:list].each { |x|
          if (x.to_i  > 0 )
            image= Image.find(x.to_i)
            image.update_attributes(:position=>i,:is_private=>true)
            thumb_images = Image.find_all_by_parent_id(image.id)
            thumb_images.each do |x|
              x.update_attributes(:position=>i,:is_private=>true)
            end
            i=i+1
          end
				}
			end
		end		
    update_private_photo
		end		

	def update_public_photo
		find_public_and_private_images
		#commented these lines temporarily
		render :update do |page|
			#~ page.replace_html 'public_photos_container', :partial=>"/partials/public_photos"
			page.call('enableDisableDragDrop')
			page.call('addTextMessageToContainer', 'public')
    #~ page.call 'public_photos'
		#	page.call 'public_photo_check'
		#	page.call 'private_photo_check'
		end
		end
		
	def update_private_photo
		find_public_and_private_images
		#commented these lines temporarily
		render :update do |page|
			#~ page.replace_html 'private_photos_container', :partial=>"/partials/private_photos"
			page.call('enableDisableDragDrop')
			page.call('addTextMessageToContainer', 'private')
    #~ page.call 'private_photos'
		#	page.call 'public_photo_check'
		#	page.call 'private_photo_check'
		end
	end
	
	def make_primary_photo
		@user =current_user
		params[:status]=="true" ? id=params[:id] : id=@user.images.first.id
		@user.update_attribute("image_id",id)
		@user_image = Image.find(params[:id])
		@primary_photo_id=@user_image.id
		render :update do |page|
			page.replace_html 'photo_view_panel', :partial=>"/partials/photo_view"			
			page[:user_profile_msg].innerHTML = "Your primary photo successfully updated."	
			page.visual_effect(:appear, 'user_profile_msg',  :duration => 1.5)
			page.visual_effect(:fade, 'user_profile_msg',  :duration => 2.5)
		end
	end
	
	#Clicking a single photo in public or private areas and primary image area should be replaced with the selected photo
	def photo_view
		@user = current_user
    @user_image = Image.find(params[:id])
		@primary_photo_id=@user_image.id
		#update_private_public_photo 
		render :update do |page|
      page.replace_html 'photo_view_panel', :partial=>"/partials/photo_view"
		end
	end
	
	def photo_type
		@user = current_user 
		find_public_and_private_images
		status = params[:status]=="public" ? false : true
		position = params[:status]=="public" ?  @public_images.length + 1  : @private_images.length + 1
		if (@public_images.length && @public_images.length < 10 &&  params[:status]=="public" ) ||  ( @private_images && @private_images.length < 10 &&  params[:status]=="private" )
			selected_image = Image.find_by_id(params[:id])
			selected_image.update_attributes(:is_private=>status,:position=>position)
			thumb_images = Image.find_all_by_parent_id(selected_image.id)
      thumb_images.each do |x|
        x.update_attributes(:position=>position,:is_private=>status)
			end
		end
		@user_image = Image.find(current_user.image_id)
		@primary_photo_id=@user_image.id
		find_public_and_private_images
		#update_private_public_photo 
		render :update do |page|	
			page.replace_html 'public_photos_container', :partial=>"/partials/public_photos"
			page.replace_html 'private_photos_container', :partial=>"/partials/private_photos"
			page.replace_html 'photo_view_panel', :partial=>"/partials/photo_view"
    page.call 'both_photos'
			#page.call 'public_photo_check'
			#page.call 'private_photo_check'
		end
	end
		
	def remove_photo
		@user=current_user
		unless (@user.image_id==params[:id].to_i)
			@image =Image.find(params[:id])
			@image.destroy
		  flash[:success] = "Photo successfully deleted."
		else
			flash[:success]="You cannot delete your primary photo.."
		end
		respond_to do |format|
			format.html { redirect_to(dashboard_path()) }
			format.xml  { head :ok }
    end
	end		
	
  def change_layout
    (action_name=="signup1") ? "register" : "users"
  end
	
	def update_private_public_photo
		find_public_and_private_images
		#commented these lines temporarily
		render :update do |page|
    page.replace_html 'user_photo', :partial=>"/partials/photos"
    page.call 'both_photos'
		#	page.call 'public_photo_check'
		#	page.call 'private_photo_check'
		end
	end
	
  def verify_address
    location = GeoKit::Geocoders::GoogleGeocoder.geocode(params[:address])
    if location.success? && !(params[:address].blank?)
      current_user.profile.update_attributes(:address=>params[:address],:latitude=>location.lat,:longitude=>location.lng)
      render :update do |page|
        page[:show_addr_msg].innerHTML = "#{current_user.name} <img alt='verified' src='/images/img_correct.gif' />"
      end
    else
      render :update do |page|
        page[:show_addr_msg].innerHTML = "#{current_user.name} <img alt='error' src='/images/img_wrong.gif' />"
      end
    end
  end
 
	def change_large_img
			@image = Image.find(params[:img_id])
			render :update do |page|
					page.replace_html 'profile_big_image', :partial=>"/partials/profile_change_large_img"
			end
	end
	
	def user_profile_view
		@user=User.find(params[:id])
		@user_profile=@user.profile
		if params[:search]
      @profile_ids = Profile.find(:all,:conditions=>"id IN (#{session[:profile_ids].join(",")})").collect{|x| x.user_id}
		else
      user_profile_sidebar_images
		end
		user_profile_images(params[:id])
		viewed = @user.trackers.collect{|x| x.viewed_user_id}
		if ((@user.id != current_user.id) && !viewed.include?(current_user.id))
      tracker = Tracker.create(:user_id=>params[:id],:viewed_user_id=>current_user.id)
		elsif viewed.include?(current_user.id)
      @user_tracker = Tracker.find_by_user_id_and_viewed_user_id(@user.id,current_user.id)
      @user_tracker.update_attributes(:updated_at=>Time.now)
		else
		end

		if request.xhr?
			render :update do |page|
			if params[:called_from]=='profile'
          page.replace_html 'profile_detail_container', :partial=>"/partials/profile_view"
					#page.hide "dash_profile_edit"
			else	
        if params[:search]
          page.show 'squirts_list'
          page.replace_html 'squirts_list', :partial=>"/partials/profile_view" ,:locals=>{:search=>'search'}
          page.hide 'profile_page'
        else
					page.replace_html 'squirts_list', :partial=>"/partials/profile_view"			
					page.hide "squirts_bg" 			
        end
			 end	
      end
		end
  end

	def remove_friend_from_buddies
		@friends_ids=[]
		friend=User.find_by_id(params[:id])
		current_user.remove_friendship_with(friend)
		online_and_offline_users
		@friends_ids =@friends_ids.paginate :page => params[:page], :per_page => 15	
		render :update do |page|
			page.replace_html 'messages_part', :partial=>"/partials/my_buddies"			
		end
	end
	
	def show_on_line_buddies_list
		@friends_ids=[]
		
		if params[:online_users_only] #To display online user and offline users
			params[:online_users_only] && params[:online_users_only]=="true" ? online_users_only  : online_and_offline_users
		elsif params[:filter_type] #To display online user filter by alphabetical or most newly added 
			params[:filter_type] && params[:filter_type]=="alphabetical" ? buddies_name_order_by_asc  : newly_added_buddies_list		
		end
		
		@friends_ids =@friends_ids.paginate :page => params[:page], :per_page => 15
		render :update do |page|
			page.replace_html 'user_buddies_list', :partial=>"/partials/buddies_list"			
			page.replace_html 'buddies_pagination_top', :partial=>"/partials/pagination_for_my_buddies"			
			page.replace_html 'buddies_pagination_buttom', :partial=>"/partials/pagination_for_my_buddies"	
			page.replace_html 'page_info_top', :partial=>"/partials/pagination_info"	
			page.replace_html 'page_info_buttom', :partial=>"/partials/pagination_info"	
		end
	end
	
	def online_users_only
		@friends_ids<< current_user.friends_by_me_ids
    @friends_ids<< current_user.friends_for_me_ids
    @friends_ids = @friends_ids.flatten
		online_users_status_checking 
	end
	
	def online_users_status_checking
		online_user_ids=[]
		@friends_ids.each { |friend_id|
      user=User.find_by_id(friend_id)
      online_user_ids<<user.id if user.online_status? && !user.online_at.nil? &&  (user.online_at+10 >= Time.now.utc)
		}
		@friends_ids=online_user_ids.flatten
	end
	
	def online_and_offline_users
		@friends_ids<< current_user.friends_by_me_ids
    @friends_ids<< current_user.friends_for_me_ids
    @friends_ids = @friends_ids.flatten	
	end
	
	def buddies_name_order_by_asc
		params[:status] && params[:status]=="true" ? online_users_only  : online_and_offline_users
		@friends_ids=User.find(:all,:conditions=>['id IN (?)',@friends_ids],:order => 'name ASC',:select => ['id']).collect{|x| x.id}
	end
	
	def newly_added_buddies_list
		@friends_ids<< current_user.friendships_by_me.sort!{|a,b|b.created_at <=> a.created_at}.collect{|x| x.friend_id}
		@friends_ids<< current_user.friendships_for_me.sort!{|a,b|b.created_at <=> a.created_at}.collect{|x| x.user_id}
		@friends_ids=@friends_ids.flatten
		if params[:status] && params[:status]=="true" #newly added llist display for online users only
			online_users_status_checking
		end
		
	end
	
	def change_msg_tab
		@friends_ids=[]
    @friends_ids<< current_user.friends_by_me_ids
    @friends_ids<< current_user.friends_for_me_ids
    @friends_ids = @friends_ids.flatten
		if params[:tab] && params[:tab]=="my buddies" 
			@friends_ids =@friends_ids.paginate :page => params[:page], :per_page => 15
			render :update do |page|
				page.replace_html 'messages_part', :partial=>"/partials/my_buddies"			
			end
		end
	end
	
	def online_status_update
		current_user.update_attribute("online_at",Time.now)
		render :update do |page|
		end
	end
	
	def custom_profile_stats
		@user=current_user 
		@custom_stat=CustomStat.find_by_id(params[:custom_stat_id])
		render :update do |page|
			page.replace_html 'list', :partial=>"/partials/custom_profile_stats" 	if @custom_stat
		end
	end
	
	def custom_profile_update
		if params[:profile_type] && params[:profile_type]=="dropdown"
			profile_type_dropdown
		elsif params[:profile_type] && params[:profile_type]=="radio"
			profile_type_radio
		elsif params[:profile_type] && params[:profile_type]=="checkbox"
			profile_type_checkbox
		elsif params[:profile_type] && (params[:profile_type]=="textarea") || (params[:profile_type]=="textbox")
			params[:message] && !params[:message].strip.empty? ? create_or_update_custom_stat_value(params[:message].strip) : custom_profile_error_msg
		end
	
	end
	
	def create_or_update_custom_stat_value(value)
		@customstats_value=CustomStatsValue.find(:first,:conditions=>['custom_stat_id = ? && user_id = ?',params[:custom_stat_id],current_user.id])
		if @customstats_value.nil?
			@custom_stats_value=CustomStatsValue.create(:user_id=>current_user.id,:custom_stat_id=>params[:custom_stat_id],:field_value=>value)
		else
			customstats_value=	@customstats_value.update_attribute("field_value",value)
		end
    profile_updated_successfully #user profile partials called here
	end
	
	def profile_type_dropdown
		params[:option] && params[:option] !="-Select-" ? create_or_update_custom_stat_value(params[:option]) : custom_profile_error_msg
	end
	
	def profile_type_radio
    params[:selected_value] && !params[:selected_value].nil? ? create_or_update_custom_stat_value(params[:selected_value]) : custom_profile_error_msg
	end
		
	def profile_type_checkbox
		if params[:selected_value] 
      selected_value=params[:selected_value].join(",")
      create_or_update_custom_stat_value(selected_value)
		else
			custom_profile_error_msg
		end
	end
		
	def custom_profile_error_msg
		render :update do |page|
			page.show "custom_profile_dropdown"
		end
	end
	
	def profile_updated_successfully
		profile_details
		render :update do |page|
      page.replace_html 'list', :partial=>"/partials/profile"
		end
	end
	
	def add_remove_buddy
		@user=User.find(params[:user_id])
    friend = @user
		    
		if params[:status] == 'add'
			current_user.friends_by_me << friend
			msg= " #{friend.name} added to My Buddies"
		else
			current_user.remove_friendship_with(friend)
			msg= " #{friend.name} removed from My Buddies"
		end
    render :update do |page|
      page.replace_html 'add_remove_buddy', :partial=>"/partials/add_remove_buddy"
      page.replace_html 'profile_view_success_msg',"#{msg}"
      page.visual_effect :appear,'profile_view_success_msg',:duration => 2
      page.delay(5) do
        page[:profile_view_success_msg].innerHTML = ""
      end
      #page.visual_effect :fade,'profile_view_success_msg',:duration => 2.5
    end
	end
	
	def find_public_and_private_images
		@public_images = Image.find(:all,:conditions => ["is_private = ? and attachable_id = ? and attachable_type = ?",false,current_user.id,'User'],:order=>'position')
		@private_images = Image.find(:all,:conditions => ["is_private = ? and attachable_id = ? and attachable_type = ?",true,current_user.id,'User'],:order=>'position')
	end	
	
	
	def block_unblock_user
		@user =User.find(params[:id])
		@friend =User.find(params[:id])
		params[:status] && params[:status] == 'block' ? user_block : user_unblock
		render :update do |page|
      page.replace_html 'block_unblock_member', :partial=>"/partials/block_unblock_member"
      page.replace_html 'profile_view_success_msg',"#{@msg1}"
      page.visual_effect :appear,'profile_view_success_msg',:duration => 1
      page.delay(5) do
        page[:profile_view_success_msg].innerHTML = ""
      end
      #page.visual_effect :fade,'profile_view_success_msg',:duration => 2.5
    end
	end
	
	def user_block
		@block_user = BlockedUser.create(:user_id=>current_user.id,:blocker_id=>params[:id])
		@msg1= "#{@friend.name} is blocked successfully."
	end
	
	def user_unblock
		@unblock_user = BlockedUser.find_by_user_id_and_blocker_id(current_user.id,params[:id])
		@unblock_user.destroy 
		@msg1= " #{@friend.name} is unblocked successfully." 
	end
	
	def append_message
		if params[:message_type] == 'inbox'
			@messages = current_user.inbox_messages.find(:all, :order => 'updated_at DESC', :offset => params[:count], :limit => 3)
		elsif params[:message_type] == 'sent'
			@messages = current_user.sent_messages.find(:all, :order => 'updated_at DESC', :offset => params[:count], :limit => 3)
		elsif params[:message_type] == 'saved'
			@messages = Message.find(:all, :conditions => ["(receiver_id=? and is_saved=1) or (sender_id=? and sender_is_saved=1)",current_user,current_user], :order => 'updated_at DESC', :offset => params[:count], :limit => 3) 
		else
			@messages = Message.find(:all, :conditions => ["(receiver_id=? and is_deleted=1) or (sender_id=? and sender_is_deleted=1)",current_user,current_user], :order => 'updated_at DESC', :offset => params[:count], :limit => 3)
		end			
		@all_msg_id = []
    @messages.collect {|x| @all_msg_id << x.id}
		render :update do |page|
			if @messages.length > 0
				page.insert_html 'bottom', 'inbox_messages', :partial => '/partials/inbox_messages'
				#~ page.call('updateCurrentMessageCount', @messages.length)
				page.assign('_messageDiv.ajaxFired', false)
				page.assign('_messageDiv.offsetCount', (params[:count].to_i + 3))
			else
				#~ page.call('moveScrollerToTop')
				page.assign('_messageDiv.stopAjax', true)
			end			
		end		
	end
	
	def show_private_photos
			@user = User.find_by_id(params[:id])
			@photo_tab = params[:photo_tab]
			#@user_private_images = [ ]
			#@buddies_list = user.friends_by_me_ids
			#@u_view =  PrivatePhotoView.find_by_user_id_and_viewer_id(user_id,current_user)
			#			if !@u_view.nil?
								@user_private_images = Image.find(:all,:conditions => ["is_private = ? and attachable_id = ? and attachable_type = ?",true,@user.id,'User'],:order=>'position')
			#			end
			
			render :update do |page|
					#page.hide "prof_public_photos" 
					page.replace_html 'prof_public_photos', :partial=>"/partials/profile_private_photos"
					page.replace_html 'photos_title', :partial=>"/partials/title_of_photos"
			end
	end
	
	def show_public_photos
			@user = User.find_by_id(params[:id])
			@photo_tab = params[:photo_tab]
			@profile_userpublic_images = Image.find(:all,:conditions =>["is_private = ? and attachable_id = ? and attachable_type = ?",false,@user.id,'User'],:order=>'position')
			render :update do |page|
					#page.hide "prof_private_photos" 
					page.replace_html 'pro_pri_photo', :partial=>"/partials/profile_public_photos"
					page.replace_html 'photos_title', :partial=>"/partials/title_of_photos"
			end
			
	end
	
	private
	def collection
		@collection = Image.real
	end
		
end
