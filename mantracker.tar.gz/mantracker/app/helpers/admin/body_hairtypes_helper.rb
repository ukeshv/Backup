module Admin::BodyHairtypesHelper
end
