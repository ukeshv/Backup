module Admin::BodytypesHelper
end
