module Admin::EmailNotificationsHelper
end
