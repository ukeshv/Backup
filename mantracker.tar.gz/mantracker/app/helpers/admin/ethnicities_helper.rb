module Admin::EthnicitiesHelper
end
