module Admin::HairtypesHelper
end
