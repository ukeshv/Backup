module Admin::UsersHelper
	def customprofile_value(user_id,id)
		@user=User.find(user_id)
		val=@user.custom_stats_values.find(:first,:conditions=>['custom_stat_id= ?',id])
		return !val.nil? ? val.field_value : ""
  end
	
  def custom_profile_selected_item(custom_stat_id,user_id)
   @selected= CustomStatsValue.find(:first,:conditions=>['custom_stat_id = ? && user_id = ?',custom_stat_id,user_id])
    return @selected_item=@selected && !@selected.nil? ? @selected.field_value.to_i : 0
  end
	
 def custom_profile_checkbox_selected_item(custom_stat_id,user_id)
		@selected= CustomStatsValue.find(:first,:conditions=>['custom_stat_id = ? && user_id = ?',custom_stat_id,user_id])
		arr=[]
		selected_arr=[]
		arr=@selected && @selected.field_value ? @selected.field_value.split(",") : ""
		temp_arr=arr
		arr && arr.each { |a| selected_arr<< a.to_i}
		@size=selected_arr.size + 3
		return selected_arr
end
  
end
