module ApplicationHelper
  def body_class
    "#{controller.controller_name} #{controller.controller_name}-#{controller.action_name}"
  end

  def user_message_thunb(id)
   user=User.find(id)
   on_line_status=user.online_status? && !user.online_at.nil? &&  (user.online_at+10 >= Time.now.utc) ?  "border:2px solid red;" : ""
   user_image=Image.find(user.image_id)
  return user_image ? "<img src='#{user_image.public_filename(:message_thumb)}' style='#{on_line_status}' title='#{user.name}'/>" : "<img src='/images/message_thumb.jpg' title='message_thumb' />"
  end
	
  def user_trackers_thumb(id)
   user=User.find(id)
   on_line_status=user.online_status? && !user.online_at.nil? &&  (user.online_at+10 >= Time.now.utc) ?  "border:2px solid red;" : ""
   user_image=Image.find(user.image_id)
  return user_image ? "<img src='#{user_image.public_filename(:small)}' style='#{on_line_status}' title='#{user.name}'/><span>#{user.name} <img onclick=\"compose_track_msg(#{user.id},'trackers_tab');\" src='/images/buddies_msg.jpg' alt='mail' /><br/>#{time(user.created_at)}</span>" : "<img src='/images/message_thumb.jpg' title='message_thumb' />"
  end

 def friend_name(id)
   @user=User.find(id)
   return @user ? @user.name : ""
 end
 
   def msg_distance_calculation(currentuser,user)
			 distances = currentuser.profile.distance_to(user.profile)
			 if (distances.round <= 1)
			  return "#{distances.round} Mile Away "
			 else
				 return "#{distances.round} Miles Away "
			 end	 
	 end
	 
	def user_photo_view(id)
				photo_view =  PrivatePhotoView.find_by_user_id_and_viewer_id(current_user.id,id)
				return photo_view
	end
	
  def highlight_msg_tab(val)
		a=["inbox","sent","saved","trash"]
		return  a.include?(val) ? "current" :  ""
		end		

		def  fetch_city(address)
				location = GeoKit::Geocoders::GoogleGeocoder.geocode(address)
				if location.success?
						if location.precision == "city"
								return location.city
						elsif location.precision == "state"
								return location.state
						elsif location.precision == "country"
								return location.country
						else
								return address
						end
				else
						return address
				end
		end
		
	
end
