module SearchUsersHelper

		def  setting_min_max_age
				@age = Profile.find(:all).collect {|x| x.age}
				@age_min = @age.min
				@age_max = @age.max
				return @age_min, @age_max
		end
		
		
		def  setting_min_max_weight
				@weight = Profile.find(:all, :conditions => ["weight IS NOT NULL"]).collect {|x| x.weight}
				@weight_min = @weight.min
				@weight_max = @weight.max
				return @weight_min, @weight_max
		end
		
end
