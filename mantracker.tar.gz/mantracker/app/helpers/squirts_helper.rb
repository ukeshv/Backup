module SquirtsHelper
	
	def updated_time_in_words(from_time)
		return from_time && !from_time.blank? ? "< #{distance_of_time_in_words_to_now(from_time, include_seconds = false)} ago" : ""
	end

	def updated_time_in_capitalwords(from_time)
		return from_time && !from_time.blank? ? " #{(distance_of_time_in_words_to_now(from_time, include_seconds = false).upcase)} AGO" : ""
	end
	
	def squirt_msg_user_distance(id,type)
		type=="Kms" ? unit={:units=>:kms} :  unit={:units=>:miles}
		user=User.find(id)
		if (current_user.id !=id)
			distances=current_user.profile.distance_to(user.profile,unit)
		  return distances && distances > 1 ?  "#{distances.round} #{type}" :  "#{distances.round} #{type}"
		else
			return ""
		end
	end
	
	def time(time)
      current_time = Time.now
      scrap_updated_time = time.to_time
      time_period = (current_time - scrap_updated_time)    
      time_in_mins = (time_period/60)
      time_in_hours = time_period/(60*60)
      days =  (time_in_hours/24)    
         if days <= 1  
         if time_in_mins < 60
            if time_period < 60
               return (time_period.to_i.to_s + " " + "secs ago")
               elsif time_period > 60
         return (time_in_mins.to_i.to_s + " " + "mins ago")
      end               
         elsif time_in_mins < 0
            return (0.to_s + " " + "mins ago")
         end
            return (time_in_hours.to_i.to_s + " " + "hours ago")
      else
         return (days.to_i.to_s + " "  + "days ago ")
      end
   end
	
	def squirts_wrap_text(txt, col = 35)
    txt.gsub(/(.{1,#{col}})( +|$\n?)|(.{1,#{col}})/,
    "\\1\\3\n") 
  end 
	
end