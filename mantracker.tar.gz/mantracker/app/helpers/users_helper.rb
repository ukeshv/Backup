module UsersHelper
  
  #
  # Use this to wrap view elements that the user can't access.
  # !! Note: this is an *interface*, not *security* feature !!
  # You need to do all access control at the controller level.
  #
  # Example:
  # <%= if_authorized?(:index,   User)  do link_to('List all users', users_path) end %> |
  # <%= if_authorized?(:edit,    @user) do link_to('Edit this user', edit_user_path) end %> |
  # <%= if_authorized?(:destroy, @user) do link_to 'Destroy', @user, :confirm => 'Are you sure?', :method => :delete end %> 
  #
  #
  def if_authorized?(action, resource, &block)
    if authorized?(action, resource)
      yield action, resource
    end
  end

  #
  # Link to user's page ('users/1')
  #
  # By default, their login is used as link text and link title (tooltip)
  #
  # Takes options
  # * :content_text => 'Content text in place of user.login', escaped with
  #   the standard h() function.
  # * :content_method => :user_instance_method_to_call_for_content_text
  # * :title_method => :user_instance_method_to_call_for_title_attribute
  # * as well as link_to()'s standard options
  #
  # Examples:
  #   link_to_user @user
  #   # => <a href="/users/3" title="barmy">barmy</a>
  #
  #   # if you've added a .name attribute:
  #  content_tag :span, :class => :vcard do
  #    (link_to_user user, :class => 'fn n', :title_method => :login, :content_method => :name) +
  #          ': ' + (content_tag :span, user.email, :class => 'email')
  #   end
  #   # => <span class="vcard"><a href="/users/3" title="barmy" class="fn n">Cyril Fotheringay-Phipps</a>: <span class="email">barmy@blandings.com</span></span>
  #
  #   link_to_user @user, :content_text => 'Your user page'
  #   # => <a href="/users/3" title="barmy" class="nickname">Your user page</a>
  #
  def link_to_user(user, options={})
    raise "Invalid user" unless user
    options.reverse_merge! :content_method => :login, :title_method => :login, :class => :nickname
    content_text      = options.delete(:content_text)
    content_text    ||= user.send(options.delete(:content_method))
    options[:title] ||= user.send(options.delete(:title_method))
    link_to h(content_text), user_path(user), options
  end

  #
  # Link to login page using remote ip address as link content
  #
  # The :title (and thus, tooltip) is set to the IP address 
  #
  # Examples:
  #   link_to_login_with_IP
  #   # => <a href="/login" title="169.69.69.69">169.69.69.69</a>
  #
  #   link_to_login_with_IP :content_text => 'not signed in'
  #   # => <a href="/login" title="169.69.69.69">not signed in</a>
  #
  def link_to_login_with_IP content_text=nil, options={}
    ip_addr           = request.remote_ip
    content_text    ||= ip_addr
    options.reverse_merge! :title => ip_addr
    if tag = options.delete(:tag)
      content_tag tag, h(content_text), options
    else
      link_to h(content_text), login_path, options
    end
  end

  #
  # Link to the current user's page (using link_to_user) or to the login page
  # (using link_to_login_with_IP).
  #
  def link_to_current_user(options={})
    if current_user
      link_to_user current_user, options
    else
      content_text = options.delete(:content_text) || 'not signed in'
      # kill ignored options from link_to_user
      [:content_method, :title_method].each{|opt| options.delete(opt)} 
      link_to_login_with_IP content_text, options
    end
end

	def existing_emails
		u = User.find :all
		u.collect{|x|x.email}.join(',')
	end
  
  def user_age(age)
   return age ? "#{age} years old" : "Age" 
 end  
 
 def user_weight(weight)
   return weight ?  "#{weight} pounds"  : "Weight" 
  end

  def profile_info_stats(val,stats)
     return eval("current_user.profile.#{stats}").nil? ? "#{stats.titleize}" : eval("current_user.profile.#{stats}.name")
   end
   
 def is_primary_photo(id)
   return current_user.image_id==id ? "checked" :  ""
 end
 
 def squirt_user_image(id)
   user=User.find(id)
   user_image=Image.find(user.image_id)
  return user_image ? "<img src='#{user_image.public_filename(:squirt_thumb)}' title='#{user.name}'/>" : "<img src='/images/squirts_thumb.jpg' title='squirts thumb' />"
end

 def user_profile_image(id)
   user=User.find(id)
   user_image=Image.find(user.image_id)
  return user_image ? "<img src='#{user_image.public_filename(:profile_thumb)}' title='#{user.name}'/>" : "<img src='/images/profile_thumb.jpg' title='profile_thumb' />"
end

 def user_profile_quick_view(id)
   @user_obj=User.find(id)
   user_image=Image.find(@user_obj.image_id)
  return user_image ? "<img src='#{user_image.public_filename(:quick_view_small)}' title='#{@user_obj.name}'/>" : "<img src='/images/profile_small.jpg' title='profile_small' />"
end

def user_profile_quick_view_current(id)
   @user_obj=User.find(id)
   user_image=Image.find(@user_obj.image_id)
  return user_image ? "<img src='#{user_image.public_filename(:quick_view_medium)}' title='#{@user_obj.name}' onclick='search_profile_view(#{@user_obj.id})';/>" : "<img src='/images/profile_small.jpg' title='profile_small' />"
end

def browse_user_profile_quick_view_current(id)
   @user_obj=User.find(id)
   user_image=Image.find(@user_obj.image_id)
  return user_image ? "<img src='#{user_image.public_filename(:quick_view_medium)}' title='#{@user_obj.name}' onclick='browse_profile_view(#{@user_obj.id})';/>" : "<img src='/images/profile_small.jpg' title='profile_small' />"
end

 def user_custom_profile
   @custom_stats=CustomStat.find(:all)
   return @custom_stats
 end
 
 def custom_stat_options(id)
   @custom_stat_options = CustomStatOption.find(:all,:conditions=>['custom_stat_id = ?',@custom_stat.id])
   return @custom_stat_options
 end
 
 def selected_item(custom_stat_id)
   @selected= CustomStatsValue.find(:first,:conditions=>['custom_stat_id = ? && user_id = ?',custom_stat_id,current_user.id])
  return @selected_item=@selected && !@selected.nil? ? @selected.field_value.to_i : 0
 end
  
  def selected_item_for_check_bok(custom_stat_id)
   @selected=[]
   selected= CustomStatsValue.find(:first,:conditions=>['custom_stat_id = ? && user_id = ?',custom_stat_id,current_user.id])
   return @selected=selected && selected.field_value.split(",")
 end
  
  def custom_profile_textbox_or_textarea_value(custom_stat_id)
    customstatsvalue=CustomStatsValue.find(:first,:conditions=>['custom_stat_id = ? && user_id = ?',custom_stat_id,current_user.id])
    return customstatsvalue  && customstatsvalue.field_value && !customstatsvalue.field_value.nil? ?  customstatsvalue.field_value : ""
  end
  
  def custom_profile_value(custom_stat_id,field_type,custom_stat_title)
    customstatsvalue=CustomStatsValue.find(:first,:conditions=>['custom_stat_id = ? && user_id = ?',custom_stat_id,current_user.id])
    
    if (field_type=="textarea") ||  (field_type=="textbox")
      if !customstatsvalue.nil?
        val=customstatsvalue.field_value 
      else
        val=custom_stat_title
      end
    elsif (field_type=="radio") || (field_type=="dropdown") 
        customstatoption=CustomStatOption.find(:first,:conditions=>['custom_stat_id = ? && id = ?',custom_stat_id , customstatsvalue.field_value]) if customstatsvalue
        val= !customstatoption.nil? && !customstatoption.option_value.empty? ?  customstatoption.option_value : custom_stat_title
    elsif (field_type=="checkbox")
       values=selected_item_for_check_bok(custom_stat_id)
       value_message=""
         value_message=[]
         values && values.each do |value|     
           customstatoption=CustomStatOption.find(:first,:conditions=>['custom_stat_id = ? && id = ?',custom_stat_id , value])
           value_message<< customstatoption.option_value if customstatoption
          end
          val=!value_message.empty? ? value_message.join(",") : custom_stat_title
    end
        return val && !val.empty? && (val.length > 20) ?  "#{val.slice(0,15)}..."  :  val
  end
      
  def custom_profile_value_for_profile_view(custom_stat_id,field_type,custom_stat_title,user_id)
    customstatsvalue=CustomStatsValue.find(:first,:conditions=>['custom_stat_id = ? && user_id = ?',custom_stat_id,user_id])
    if (field_type=="textarea") ||  (field_type=="textbox")
      val=customstatsvalue && !customstatsvalue.nil? ?  customstatsvalue.field_value : "-"
    elsif (field_type=="radio") || (field_type=="dropdown") 
      customstatoption=CustomStatOption.find(:first,:conditions=>['custom_stat_id = ? && id = ?',custom_stat_id , customstatsvalue.field_value]) if customstatsvalue
        val= !customstatoption.nil? && !customstatoption.option_value.empty? ?  customstatoption.option_value : "-"
    elsif (field_type=="checkbox")
      values=selected_item_for_check_bok(custom_stat_id)
       value_message=""
         value_message=[]
         values && values.each do |value|     
           customstatoption=CustomStatOption.find(:first,:conditions=>['custom_stat_id = ? && id = ?',custom_stat_id , value])
           value_message<< customstatoption.option_value if customstatoption
          end
          val=!value_message.empty? ? value_message.join(",") : "-"
    end
    @value= val   
    return val && !val.empty? && (val.length > 10) ?  "#{val.slice(0,10)}..."  :  val
  end
      
  def wrap_text(txt, col = 40)
    if txt && !txt.empty?
       return txt.gsub(/(.{1,#{col}})( +|$\n?)|(.{1,#{col}})/,   "\\1\\3\n") 
    else
        return  ""
    end
  end   
      
end
