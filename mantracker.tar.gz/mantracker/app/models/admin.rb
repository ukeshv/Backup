require 'digest/sha1'
class Admin < ActiveRecord::Base
  include Authentication
  #include Authentication::ByPassword
  include Authentication::ByCookieToken
  
  attr_accessor :password

  validates_presence_of  :username
  validates_uniqueness_of  :username
  validates_format_of  :username, :with => Authentication.name_regex,  :message => Authentication.bad_name_message, :allow_nil => true
  validates_length_of  :username, :maximum => 100

  validates_presence_of  :email
  validates_length_of  :email, :within => 6..100 #r@a.wk
  validates_uniqueness_of  :email
  validates_format_of  :email, :with => Authentication.email_regex, :message => Authentication.bad_email_message
  
  validates_presence_of     :password,                   :if => :password_required?
  validates_presence_of     :password_confirmation,      :if => :password_required?
  validates_confirmation_of :password,                   :if => :password_required?
  validates_length_of       :password, :within => 6..40, :if => :password_required?

  before_save :encrypt_password

   # HACK HACK HACK -- how to do attr_accessible from here?
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  attr_accessible :email, :username, :password, :password_confirmation

  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  #
  # uff.  this is really an authorization, not authentication routine.  
  # We really need a Dispatch Chain here or something.
  # This will also let us return a human error message.
  #
  def self.authenticate(username, password)
    return nil if username.blank? || password.blank?
    u = find_by_username(username.downcase) # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  def username=(value)
    write_attribute :username, (value ? value.downcase : nil)
  end

  def email=(value)
    write_attribute :email, (value ? value.downcase : nil)
  end

  def self.password_digest(password, salt)
    digest = REST_AUTH_SITE_KEY
    REST_AUTH_DIGEST_STRETCHES.times do
      digest = secure_digest(digest, salt, password, REST_AUTH_SITE_KEY)
    end
    digest
  end      

  def encrypt(password)
    self.class.password_digest(password, salt)
  end
  
  def authenticated?(password)
    crypted_password == encrypt(password)
  end
  
  # before filter 
  def encrypt_password
    return if password.blank?
    self.salt = self.class.make_token if new_record?
    self.crypted_password = encrypt(password)
  end
  def password_required?
    crypted_password.blank? || !password.blank?
  end

  protected
    
end
