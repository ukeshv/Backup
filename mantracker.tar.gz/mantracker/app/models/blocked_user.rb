class BlockedUser < ActiveRecord::Base
		belongs_to :user
end
