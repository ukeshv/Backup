class BodyHairtype < ActiveRecord::Base
	has_many :profiles
	
	validates_presence_of :name, :message=>"Body Hair type can't be blank"
	validates_uniqueness_of :name,:case_sensitive => false,:message=>"Body Hair type already exists"
	
end