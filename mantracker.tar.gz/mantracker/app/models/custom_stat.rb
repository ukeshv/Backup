class CustomStat < ActiveRecord::Base
	has_many:custom_stat_options,:dependent => :destroy
	has_many:custom_stats_values,:dependent => :destroy
	
	validates_presence_of :field_type, :message=>"Please select a field type."
	validates_presence_of :title, :message=>"Please enter title."
	
	 FIELD_TYPE = [["--Field type--",""], [ 'Textbox', 'textbox'], [ 'Textarea', 'textarea'], [ 'Radio', 'radio'],
	 [ 'Checkbox', 'checkbox'],[ 'Dropdown', 'dropdown']].freeze
	 
end