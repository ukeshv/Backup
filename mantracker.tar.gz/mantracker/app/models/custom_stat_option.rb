class CustomStatOption < ActiveRecord::Base
	belongs_to:custom_stat
end