class CustomStatsValue < ActiveRecord::Base
	belongs_to:user
	belongs_to:custom_stat
end
