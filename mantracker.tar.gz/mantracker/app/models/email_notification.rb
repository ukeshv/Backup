class EmailNotification < ActiveRecord::Base
	
	def self.send_email_notifications
			notifications = EmailNotification.find(:all,:conditions=>['is_sent = 0'])
			for notification in notifications
				UserMailer.deliver_notification_mail(notification)
				notification.update_attribute(:is_sent,1)
			end        
		end
							
end
