class Enquiry < ActiveRecord::Base
end
