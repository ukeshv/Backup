class Ethnicity < ActiveRecord::Base
	has_many :profiles
	validates_presence_of :name, :message=>"Ethnicity can't be blank"
	validates_uniqueness_of :name,:case_sensitive => false,:message=>"Ethnicity already exists"
	
end
