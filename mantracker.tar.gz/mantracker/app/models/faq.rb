class Faq < ActiveRecord::Base
end
