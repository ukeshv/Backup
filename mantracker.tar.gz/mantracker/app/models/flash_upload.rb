require 'RMagick'
#~ include Magick

class FlashUpload < ActiveRecord::Base
		has_attachment :content_type => ['image/pjpeg','image/jpeg', 'image/jpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg','application/x-shockwave-flash'],
		:storage => :file_system, :path_prefix => 'public/flashfiles',:thumbnails => {:upper =>[532,315],:lower =>[955,113]},:max_size => 4.megabytes   #not sure for flash files
		belongs_to :attachable, :polymorphic=>true # yet to learn on this
		validates_as_attachment
	
	def FlashUpload.resize_profile_image(image_obj)
		image_path = RAILS_ROOT + '/public' + image_obj.public_filename
		resized_image_path = RAILS_ROOT + '/public' + image_obj.public_filename(:small)
		if File.exists?(image_path) && File.exists?(resized_image_path)	
			clone_image = Magick::Image.read(image_path).first
			clone_image.crop_resized!(142,161)
			clone_image.write(resized_image_path)
		end	
	end
	
end
