class FooterLink < ActiveRecord::Base
		validates_presence_of :title, :message=>"Provide Title"
		validates_length_of   :title, :in => 3..10, :message => "Title should be in 3 to 10 characters"
    validates_format_of :link, :with =>/(^$)|(^(http|https):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(([0-9]{1,5})?\/.*)?$)/,  :message=>"Provide valid link"
end
