class Friendship < ActiveRecord::Base
	belongs_to :user
	#~ belongs_to :buddy, :class_name => "User", :foreign_key => 'buddy_id'
	
	belongs_to :friendshipped_for_me, :class_name => "User", :foreign_key => 'user_id'
	belongs_to :friendshipped_by_me, :class_name => "User", :foreign_key => 'friend_id'
end
