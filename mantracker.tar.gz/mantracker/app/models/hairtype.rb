class Hairtype < ActiveRecord::Base
	has_many :profiles
	
	validates_presence_of :name, :message=>"Hair type can't be blank"
	validates_uniqueness_of :name,:case_sensitive => false,:message=>"Hair type already exists"

end