class HomepageSetting < ActiveRecord::Base
		attr_accessor :step

		has_many :flash_uploads, :as => :attachable #currently attachable is not important
		belongs_to :attachable, :polymorphic=>true # yet to learn on this
		validates_presence_of :title, 	:if => Proc.new { |x| x.step == 1 },:message=>"Required field"
		validates_presence_of :place_holder , 	:if => Proc.new { |x| x.step == 1 },:message=>"Required field"
		validates_numericality_of :place_holder ,:if => Proc.new { |x| x.step == 1 },:message=>"Numbers only"
		validates_length_of   :title, :in => 3..50, :message => "Title should be in 3 to 50 characters"
end
