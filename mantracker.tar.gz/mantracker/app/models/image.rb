class Image < ActiveRecord::Base
	has_attachment :content_type => :image, 
					:storage => :file_system, 
					:size => 0.kilobytes..4.megabytes,:thumbnails => { :small => [142,161],:thumb => [42,34],:message_thumb=>[40,41],:squirt_thumb=>[95,68],:profile_thumb=>[205,159],:quick_view_small=>[64,78],:quick_view_medium=>[76,78] }, :path_prefix => 'public/pictures'

	belongs_to :attachable,:polymorphic=>true

	validates_as_attachment
	
	named_scope :real, :conditions => {:parent_id => nil}
	
	after_save :resize_profile_image
	
	def validate
    errors.add_to_base("You must choose a file to upload") unless self.filename

    unless self.filename == nil

      # Images should only be GIF, JPEG, or PNG
      [:content_type].each do |attr_name|
        enum = attachment_options[attr_name]
        unless enum.nil? || enum.include?(send(attr_name))
				errors.add attr_name,"You can only upload images (JPG, GIF or PNG)"
          #errors.add_to_base("You can only upload images (JPG, GIF or PNG)")
        end
      end

      # Images should be less than 5 MB
      [:size].each do |attr_name|
        enum = attachment_options[attr_name]
        unless enum.nil? || enum.include?(send(attr_name))
				errors.add attr_name,"Images should be smaller than 4 MB in size"
          #errors.add_to_base("Images should be smaller than 4 MB in size")
        end
      end

    end
	end
	
	def resize_profile_image		
		FlashUpload.resize_profile_image(self)
  end

end

