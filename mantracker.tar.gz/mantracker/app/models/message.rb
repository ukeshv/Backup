class Message < ActiveRecord::Base
		
		PAGINATION_COUNT = 10
		
		belongs_to :user 
    belongs_to :sender, :class_name=>'User', :foreign_key=>:sender_id
		belongs_to :receiver, :class_name=>'User', :foreign_key=>:receiver_id
		

		def message_thread
				msg_thread = Message.find(:all,:conditions=>['id=?',self.id],:order=>'created_at asc') if self.parent_msg_id.nil?
			#	msg_thread << Message.find_by_id(self.id) if self.parent_msg_id.nil?
				msg_thread = Message.find(:all,:conditions=>['parent_msg_id =? and created_at < ?',self.parent_msg_id,self.created_at],:order=>'created_at asc') if !self.parent_msg_id.nil?
				msg_thread << Message.find_by_id(self.parent_msg_id) if !self.parent_msg_id.nil?
				return msg_thread
		end
		
		def self.delete_in_sent_trash_messages
				@messages = Message.find(:all,:conditions=>['is_saved = ? and created_at < ?',false,Date.today-14])
				@messages.each do |message|
					message.destroy
				end
		end
		
end