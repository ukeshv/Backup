class Profile < ActiveRecord::Base
	
	attr_accessor :is_age_required,:is_height_required,:is_weight_required
	acts_as_mappable :default_formula => :sphere, :lat_column_name => :latitude, :lng_column_name => :longitude

	#Associations
	belongs_to :user
	belongs_to :height
	belongs_to :hairtype
	belongs_to :body_hairtype
	belongs_to :bodytype
	belongs_to :ethnicity
	validates_numericality_of :age, :greater_than => 18, :if =>Proc.new { |profile| profile.is_age_required == true },:message=>"Age must be greater than 18"
	validates_numericality_of :height_id, :if =>Proc.new { |profile| profile.is_height_required == true },:message=>"Select your height"
	validates_numericality_of :weight, :if =>Proc.new { |profile| profile.is_weight_required == true }, :message=>"Provide valid weight"
	#~ validates_presence_of :interests
	#~ validates_presence_of :tattoos
	#~ validates_presence_of :body_hairtype_id,:message=>"Select your body hair type"
	#~ validates_presence_of :hairtype_id,:message=>"Select your hair type"
	#~ validates_presence_of :ethnicity_id,:message=>"Select your ethnicity type"
	#~ validates_presence_of :bodytype_id,:message=>"Select your body type"
end