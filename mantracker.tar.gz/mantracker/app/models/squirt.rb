class Squirt < ActiveRecord::Base
	belongs_to :user

	def posted_by?(user_obj)
		if self.user.id == user_obj.id
			return true
		else
			return false
		end
	end
	
	#This method is used to delete all the squirts except the last squirt for each user(after changing the has_many :squirts to has_one :squirt)
	def self.find_last_squirt
		user_ids = self.find(:all).collect{|x| x.user_id}
		squirt_ids = []
		for user_id in user_ids.uniq
			squirt_ids << self.find(:last, :conditions => [ "user_id = ?", user_id]).id
		end	
		self.delete_all(["id NOT IN (?)",squirt_ids])
		end	

		#this method is to delete squirts which are created before 30 days
		def self.squirts_auto_del
				@all_squits = Squirt.find(:all)
				@all_squits.each do |i|
						if i.created_at < Time.now - 30.days
								Squirt.delete_all("id = #{i.id}")								
						end
				end
		end
		
	
end
