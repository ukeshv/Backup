require 'digest/sha1'

class User < ActiveRecord::Base
		
		has_many :images, :as => :attachable,:dependent => :destroy
		#has_many :public_images, :class_name => 'Image', :foreign_key => 'attachable_id', :conditions => ["images.is_private=false"],:order=>'images.position'
		#has_many :private_images, :class_name => 'Image',:foreign_key => 'attachable_id', :conditions => ["images.is_private=true"],:order=>'images.position'
		belongs_to :attachable,:polymorphic=>true		
		has_one :profile ,:dependent => :destroy
		has_many:custom_stats_values ,:dependent => :destroy
		has_one :squirt, :order => ['updated_at DESC'] ,:dependent => :destroy
		has_many :friendships
		has_many :templates ,:dependent => :destroy
		has_many :messages 
		has_many :sent_messages, :foreign_key=>:sender_id, :class_name=>'Message',:conditions => ["is_deleted = ? and is_saved = ?",false,false] ,:dependent => :destroy
	  has_many :inbox_messages, :foreign_key=>:receiver_id, :class_name=>'Message',:conditions => ["is_deleted = ? and is_saved = ?",false,false] ,:dependent => :destroy
		has_many :saved_messages, :foreign_key=>:receiver_id, :class_name=>'Message',:conditions => ["is_deleted = ? and is_saved = ?",false,true]
		has_many :deleted_messages ,:foreign_key=>:receiver_id , :class_name=>'Message',:conditions => ["is_deleted = ?",true]

		#~ has_many :buddies, :foreign_key => 'user_id', :class_name => 'User', :through => :user_buddies
		has_many :friendships_by_me, :foreign_key => 'user_id', :class_name => 'Friendship' ,:dependent => :destroy
		has_many :friends_by_me, :through => :friendships_by_me, :source => :friendshipped_by_me
		
		has_many :private_photo_views ,:dependent => :destroy
		has_many :user_private_photo_viewers , :foreign_key => 'viewer_id' ,:class_name=>'PrivatePhotoView' ,:dependent => :destroy
		has_many :blocked_users ,:dependent => :destroy
		has_many :users_blocked_user_ids , :foreign_key => 'blocker_id',:class_name=>'BlockedUser',:dependent => :destroy
		has_many :trackers  ,:dependent => :destroy
		has_many :tracker_users ,:foreign_key=>'viewed_user_id',:class_name=>'Tracker' ,:dependent => :destroy
		has_many :saved_searches ,:dependent => :destroy
		
		has_many :friendships_for_me, :foreign_key => 'friend_id', :class_name => 'Friendship',:dependent => :destroy
		has_many :friends_for_me, :through => :friendships_for_me, :source => :friendshipped_for_me	
		
		has_one :profile_image, :foreign_key => :id, :primary_key => :image_id, :class_name => 'Image'
		
		attr_accessor :step
		attr_accessor :email_confirmation		

		include Authentication
		include Authentication::ByPassword
		include Authentication::ByCookieToken

		validates_presence_of :name,:if =>Proc.new { |user| user.validate_signup?(1) || user.validate_signup?(10) }, :message => "Contact name can't be blank"
		validates_format_of :name,:with => /^\w+$/i, :if =>Proc.new { |user| user.validate_signup?(1) || user.validate_signup?(10) }, :message => "Should contain only letters"
		validates_length_of :name,:minimum => 3 ,:if =>Proc.new { |user| user.validate_signup?(1) || user.validate_signup?(10) }, :too_short=>"Name is too short"
		validates_uniqueness_of :name,:if =>Proc.new { |user| user.validate_signup?(1) || user.validate_signup?(10) }, :message=>"Name already taken", :case_sensitive => false

		validates_presence_of :email , :if =>Proc.new { |user| user.validate_signup?(2) || user.validate_signup?(10) || user.validate_signup?(11) },:message=>"Email can't be blank"
		validates_uniqueness_of :email , :if =>Proc.new { |user| user.validate_signup?(2) || user.validate_signup?(10) || user.validate_signup?(11) },:message=>"Email already in use, please enter another one", :case_sensitive => false
		validates_format_of :email,:with => Authentication.email_regex, :if =>Proc.new { |user| user.validate_signup?(2) || user.validate_signup?(10) || user.validate_signup?(11)}, :message => 'Should look like an email address.'
		#validates_presence_of :email_confirmation,:if =>Proc.new { |user| user.validate_signup?(6) },:message=>"Email confirmation can't be blank"
		validates_confirmation_of :email,:if =>Proc.new { |user| user.validate_signup?(6) || user.validate_signup?(10)},:message=>"Email doesn't match"
		
		validates_format_of :email,:with => Authentication.email_regex, :if =>Proc.new { |user| user.validate_signup?(6) || user.validate_signup?(10) || user.validate_signup?(11)}, :message => 'Should look like an email address.'

validates_uniqueness_of :email,:with => Authentication.email_regex, :if =>Proc.new { |user| user.validate_signup?(6) || user.validate_signup?(10) || user.validate_signup?(11)}, :message => 'Email addresses do not match, please re-enter them'

		validates_presence_of :password,:if =>Proc.new { |user| user.validate_signup?(3) || user.validate_signup?(10) },:message=>"Password can't be blank"
		validates_length_of :password,:if =>Proc.new { |user| user.validate_signup?(3) || user.validate_signup?(10) } , :within => 4..20, :too_short=>"password length is too short",:too_long =>"password length is too long"
		validates_presence_of :password_confirmation,:if =>Proc.new { |user| user.validate_signup?(4) || user.validate_signup?(10) },:message=>"Password confirmation can't be blank"
		validates_length_of :password_confirmation,:if =>Proc.new { |user| user.validate_signup?(4) || user.validate_signup?(10) } , :within => 4..20, :too_short=>"password length is too short",:too_long =>"password length is too long"
		validates_confirmation_of :password,:if =>Proc.new { |user| user.validate_signup?(4) || user.validate_signup?(10) },:message=>"Password doesn't match"

		before_create :make_activation_code 

		# HACK HACK HACK -- how to do attr_accessible from here?
		# prevents a user from submitting a crafted form that bypasses activation
		# anything else you want your user to change should be added here.
		attr_accessible :email, :name, :password, :password_confirmation,:last_loggedin

	def validate_signup?( step1 )          
		if (step == step1)
		return true
		else
		return false
end
	end	


  # Activates the user in the database.
  def activate!
    @activated = true
    self.activated_at = Time.now.utc
    self.activation_code = nil
    save(false)
  end

  # Returns true if the user has just been activated.
  def recently_activated?
    @activated
  end

  def active?
    # the existence of an activation code means they have not activated yet
    activation_code.nil?
  end

  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  #
  # uff.  this is really an authorization, not authentication routine.  
  # We really need a Dispatch Chain here or something.
  # This will also let us return a human error message.
  #
  def self.authenticate(email, password)
    return nil if email.blank? || password.blank?
    u = find :first, :conditions => ['email = ? and activated_at IS NOT NULL', email] # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  def login=(value)
    write_attribute :login, (value ? value.downcase : nil)
  end

  def email=(value)
    write_attribute :email, (value ? value.downcase : nil)
  end

	def name
		raw_name = read_attribute( "name" )
		raw_name = raw_name.humanize unless raw_name.nil?
		raw_name
	end
		
	# methods for friends-association
	def remove_friendship_with(friend_obj)
		if self.friends_by_me.include?(friend_obj)
			friend_relation = Friendship.find(:first, :conditions => ['user_id = ? && friend_id = ?', self.id, friend_obj.id])
			friend_relation.destroy
		end
		if self.friends_for_me.include?(friend_obj)
			friend_relation = Friendship.find(:first, :conditions => ['user_id = ? && friend_id = ?', friend_obj.id, self.id])
			friend_relation.destroy
		end
	end
	
	def make_friendship_with(friend_obj)
		unless self.friends_by_me.include?(friend_obj) # runs only for unknown users, not for friends
			Friendship.create(:user_id => self.id, :friend_id => friend_obj.id)
		end
	end
	
	def friends?(friend_obj) # plain check both are friends or not
		if (self.friends_by_me.include?(friend_obj)) || (self.friends_for_me.include?(friend_obj))
			return true 
		else
			return false
		end
	end
	
	def friends_by_me?(friend_obj) # used to check the i have added him/her as my friend or not.
		if self.friends_by_me.include?(friend_obj)
			return true 
		else
			return false
		end
	end
	
	def friends_for_me?(friend_obj) # used to check i am in friends list of him/her
		if self.friends_for_me.include?(friend_obj)
			return true 
		else
			return false
		end
	end
	# methods for friends-association	
	
	# check user is online
  def is_online
		return	self.online_status
  end
	
	def is_friend_of_me(friendid)
			friend = Friendship.find_by_user_id_and_friend_id(self.id,friendid)
			if friend
					return true
				else
							return false
					end
			end
			
	def is_blocked(friendid)
			blocked = BlockedUser.find_by_user_id_and_blocker_id(self.id,friendid)
			if blocked
					return true
				else
							return false
					end
			end
			
  def viewed_user(id)
			user = User.find_by_id(id)
	end
	
		def make_new_activation_code
				self.activation_code = self.class.make_token
		end

	
  protected
	    		
  def password_required?
    new_record? ? (crypted_password.blank? || !password.blank?) : !password.blank?
  end

	def make_activation_code
    self.activation_code = self.class.make_token
end

end
