class UserMailer < ActionMailer::Base
  def signup_notification(user)
    setup_email(user)
    @subject    += 'Please activate your new account'
  
    @body[:url]  = "#{APP_CONFIG[:site_url]}/activate/#{user.activation_code}"
  
  end
  
  def activation(user)
    setup_email(user)
    @subject    += 'Your account has been activated!'
    @body[:url]  = "#{APP_CONFIG[:site_url]}/"
  end
  
  def notification_mail(notification)
    @subject     = "#{notification.subject}"
    @from        = "#{APP_CONFIG[:admin_email]}"
    @sent_on     = Time.now
    @recipients  = "#{notification.email}"
    @content_type = "text/html"
    @body[:notification] = notification
  end

  def new_email_notification(user,email)
		@recipients  = email
		@subject    = 'Activate Your account!'
		@from        = "#{APP_CONFIG[:admin_email]}"
		@sent_on     = Time.now
		@body[:user] = user
		@body[:email] = email
		@body[:url]  = "#{APP_CONFIG[:site_url]}/new_email/activate_new_email/#{user.activation_code}"
  end

  def contact_us_mail(user,msg)
		@recipients  = "support@mantracker.com"
		@subject    = 'Enquiry '
    @from        = "#{user.email}"
		@body[:name] = user.name
		@body[:message] = msg
  end

  def feedback_mail(user,msg)
		@recipients  = "feedback@mantracker.com"
		@subject    = 'Feedback '
    @from        = "#{user.email}"
		@body[:name] = user.name
		@body[:message] = msg
	end
  
  protected
    def setup_email(user)
      @recipients  = "#{user.email}"
      @from        = "#{APP_CONFIG[:admin_email]}"
      @subject     = "[#{APP_CONFIG[:site_name]}] "
      @sent_on     = Time.now
      @body[:user] = user
    end
end
