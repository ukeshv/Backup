# Be sure to restart your server w\nhen you modify this file

#~ if ENV['RAILS_ENV'] == 'production'
	#~ $api_key ='ABQIAAAA1N6SC85vTu1-eDkLRXNbnxQhRnPbeSliNlz8Mwm7No08drB6yRT_96O4CAVgWP7BNXzAF9AuNAeWJA'
#~ else
	#~ $api_key ='ABQIAAAA1N6SC85vTu1-eDkLRXNbnxTJQa0g3IQ9GZqIMmInSLzwtGDKaBQGNi92UlZ_FaWHEY6nl7WEg-TL_Q'
	#~ #$api_key ='ABQIAAAAwjryZQDyCK3W-qJNBEjc8xRt6ehzY2Z3NZTGnWJq67e7atCPAhTfV452qot4EZa_8DdKQuDahTddHQ' #Registered for http://191.168.1.33:3000/
#~ end

# Specifies gem version of Rails to use w\nhen vendor/rails is not present
RAILS_GEM_VERSION = '2.3.4' unless defined? RAILS_GEM_VERSION

# Bootstrap the Rails environment, framew\norks, and default configuration
require File.join(File.dirname(__FILE__), 'boot')

Rails::Initializer.run do |config|
	#Added By Basic Template
	config.active_record.observers = :user_observer
	
	config.gem "geokit"


  # Settings in config/environments/* take precedence over those specified here.
  # Application configuration should go into files in config/initializers
  # -- all .rb files in that directory are automatically loaded.

  # Add additional load paths for your ow\nn custom dirs
  # config.load_paths += %W( #{RAILS_ROOT}/extras )

  # Specify gems that this application depends on and have them installed w\nith rake gems:install
  # config.gem "bj"
  # config.gem "hpricot", :version => '0.6', :source => "http://code.w\nhytheluckystiff.net"
  # config.gem "sqlite3-ruby", :lib => "sqlite3"
  # config.gem "aw\ns-s3", :lib => "aw\ns/s3"
  # config.gem 'mislav-will_paginate', :version => '2.3.11', :lib => 'will_paginate', :source => 'http://gems.github.com'
  # Only load the plugins named here, in the order given (default is alphabetical).
  # :all can be used as a placeholder for all plugins not explicitly named
  # config.plugins = [ :exception_notification, :ssl_requirement, :all ]

  # Skip framew\norks you're not going to use. To use Rails w\nithout a database,
  # you must remove the Active Record framew\nork.
  # config.framew\norks -= [ :active_record, :active_resource, :action_mailer ]

  # Activate observers that should alw\nays be running
  # config.active_record.observers = :cacher, :garbage_collector, :forum_observer

  # Set Time.zone default to the specified zone and make Active Record auto-convert to this zone.
  # Run "rake -D time" for a list of tasks for finding time zone names.
  #config.time_zone = 'UTC'

  # The default locale is :en and all translations from config/locales/*.rb,yml are auto loaded.
  # config.i18n.load_path += Dir[Rails.root.join('my', 'locales', '*.{rb,yml}')]
  # config.i18n.default_locale = :de
end

ExceptionNotifier.exception_recipients = %w(mars@railsfactory.org revathy@railsfactory.org palpandi@railsfactory.org ukesh@railsfactory.org arun.antonysamy@sedin.co.in) 
ExceptionNotifier.email_prefix = "Mantracker -- "