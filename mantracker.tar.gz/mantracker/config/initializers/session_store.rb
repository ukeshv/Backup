# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_mantracker_dating_session',
  :secret      => '5028b7cee327c696125c86c9c91d98e9ca35d55bc624b92e9d6674c998e739fcf570db7da0c77c286d4e11181a81bc88bc48e2b9e9a4a243a38ece8afb9ae6b9'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
