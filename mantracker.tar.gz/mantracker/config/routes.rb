ActionController::Routing::Routes.draw do |map|
  map.root :controller => 'sessions',:action=>'index'
  map.admin '/admin', :controller => 'admins', :action => 'new'
  map.admin_logout '/admin/logout', :controller => 'admins', :action => 'destroy'
  map.logout '/logout', :controller => 'sessions', :action => 'destroy'
  map.login '/login', :controller => 'sessions', :action => 'new'
  map.register '/register', :controller => 'users', :action => 'create'
  #map.signup '/signup', :controller => 'users', :action => 'new'
  map.logout '/logout', :controller => 'sessions', :action => 'destroy'
  map.activate '/activate/:activation_code', :controller => 'users', :action => 'activate', :activation_code => nil  
  map.activate_new_email '/new_email/activate_new_email/:activation_code', :controller => 'settings', :action => 'activate_new_email', :activation_code => nil  
  map.forgot_password '/forgot_password', :controller => 'passwords', :action => 'new'
  map.change_password '/change_password/:reset_code', :controller => 'passwords', :action => 'reset'
  map.aboutus '/aboutus', :controller => 'static_pages', :action => 'aboutus'
  map.contactus '/contactus', :controller => 'static_pages', :action => 'contactus'
  map.privacypolicy '/privacypolicy', :controller => 'static_pages', :action => 'privacy_policy'
  map.advertise '/advertise', :controller => 'static_pages', :action => 'advertise'
	#map.signup '/signup',:controller =>'users' , :action=>'signup1'
	map.dashboard '/dashboard',:controller =>'users' , :action=>'dashboard'
	map.remove_photo '/remove_photo/:id',:controller =>'users' , :action=>'remove_photo'
	#map.photo_type '/users/photo_type',:controller =>'users' , :action=>'photo_type'
  map.display_stats '/display_stats/:stats', :controller => 'users', :action => 'display_stats',:method=>"post"
  map.custom_profile '/custom_profile_update/:id', :controller => 'users', :action => 'custom_profile_update',:method=>"post"
  map.display_custom_profile_stats '/display_custom_profile_stats/:custom_stat_id', :controller => 'users', :action => 'custom_profile_stats',:method=>"post"
  map.my_squirt_message_delete '/squirts/my_latest_squirt/:id', :controller => 'squirts', :action => 'my_squirt_message_delete'
  map.freeze_account '/settings/freeze_account/', :controller => 'settings', :action => 'freeze_account'
  map.my_settings '/settings/my_settings/:current_tab', :controller => 'settings', :action => 'my_settings'
  map.faq '/settings/faq/:current_tab', :controller => 'settings', :action => 'faq'
  map.feedback '/settings/feedback/:current_tab', :controller => 'settings', :action => 'feedback'
  map.contact_us '/settings/contact_us/:current_tab', :controller => 'settings', :action => 'contact_us'
  
  map.my_settings_partial '/settings/my_setting_partial/:current_tab', :controller => 'settings', :action => 'my_setting_partial'
  map.faq_partial '/settings/faq_partial/:current_tab', :controller => 'settings', :action => 'faq_partial'
  map.feedback_partial '/settings/feedback_partial/:current_tab', :controller => 'settings', :action => 'feedback_partial'
  map.contact_us_partial '/settings/contact_us_partial/:current_tab', :controller => 'settings', :action => 'contact_us_partial'
  
  map.show_results '/search_users/show_results', :controller => 'search_users', :action => 'show_results'
  
  
  map.resources :users, :collection=>{:partial3=>:post, :append_message => :post}
  map.resources :passwords	
	map.resources :squirts, :collection => {:add_remove_buddy => :post, :my_buddies => :get,:my_squirt => :get,:my_squirt_message_update => :post,:distance_search_type => :post}
  map.resource :session
  map.resource :admins
  map.resources :settings
  map.resources :search_users, :collection=>{:search => :get}
  map.resources :browse_users
  
  map.namespace(:admin) do |admin|
    admin.resources :bodytypes
    admin.resources :ethnicities
    admin.resources :body_hairtypes
    admin.resources :hairtypes
    admin.resources :heights
    admin.resources :custom_stats
    admin.resources :users
    admin.resources :email_notifications
		admin.resources :faqs
		admin.resources :enquiries
		admin.resources :feedbacks
		admin.resources :homepage_settings
  end 
  map.user_change_password_by_admin '/admin/users/:id/change_password', :controller => 'admin/users', :action => 'change_password'
  
  map.change_msg_tab '/change_message_tab/:tab', :controller => 'users', :action => 'change_msg_tab'
  map.show_on_line_buddies_list '/show_on_line_buddies_list/', :controller => 'users', :action => 'show_on_line_buddies_list'
  map.user_on_line_status_update '/online_status_update/', :controller => 'users', :action => 'online_status_update'
  
  map.remove_friend_from_buddies '/remove_friend_from_buddies/:id', :controller => 'users', :action => 'remove_friend_from_buddies'
  map.profile_view '/user_profile_view/:id', :controller => 'users', :action => 'user_profile_view'
  map.change_cur_squirt '/change_cur_squirt/', :controller => 'squirts', :action => 'change_cur_squirt'
  map.display_edit_bodytype_name '/edit_bodytype/:id', :controller => 'admin/bodytypes', :action => 'edit'
  map.display_edit_ethnicity_name '/edit_ethnicity/:id', :controller => 'admin/ethnicities', :action => 'edit'
  map.display_edit_body_hairtype_name '/edit_body_hairtype/:id', :controller => 'admin/body_hairtypes', :action => 'edit'
  map.display_edit_hairtype_name '/edit_hairtype/:id', :controller => 'admin/hairtypes', :action => 'edit'
  map.display_edit_height_name '/edit_height/:id', :controller => 'admin/heights', :action => 'edit'
	
	# Homepage Setting
	map.homepage_setting '/homepage_setting', :controller => 'admin/homepage_settings', :action => 'index'
	map.admin_flash_list1 '/admin/flash_list1', :controller => 'admin/homepage_settings', :action => 'list_dynamic1_flash'
	map.admin_new_flash1 '/admin/new_flash1', :controller => 'admin/homepage_settings', :action => 'dynamic_area1'
	map.admin_new_flash2 '/admin/new_flash2', :controller => 'admin/homepage_settings', :action => 'dynamic_area2'
	map.admin_flash_list2 '/admin/flash_list2', :controller => 'admin/homepage_settings', :action => 'list_dynamic2_flash'
	map.admin_edit_flash1 '/admin/edit_flash1/:id', :controller => 'admin/homepage_settings', :action => 'flash_edit'
	map.admin_edit_flash2 '/admin/edit_flash2/:id', :controller => 'admin/homepage_settings', :action => 'flash_edit2'
  
  map.admin_footer_setting '/admin/footer_setting', :controller => 'admin/homepage_settings', :action => 'footer_links'
  map.admin_edit_footer '/admin/edit_footer/:id', :controller => 'admin/homepage_settings', :action => 'edit_footer_links'
	
	map.change_flash_image '/change_flash_image/:id', :controller=>'sessions', :action =>'change_flash_image'
	
	#map.homepage_setting_flash_del '/homepage_setting/flash_del', :controller => 'admin/homepage_settings', :action => 'dynamic_area1'
	#map.homepage_setting_new_dynamic1 '/homepage_setting/dynamic_area1', :controller => 'admin/homepage_settings', :action => 'dynamic_area1'
  # The priority is based upon order of creation: first created -> highest priority.

  # Sample of regular route:
  #   map.connect 'products/:id', :controller => 'catalog', :action => 'view'
  # Keep in mind you can assign values other than :controller and :action

  # Sample of named route:
  #   map.purchase 'products/:id/purchase', :controller => 'catalog', :action => 'purchase'
  # This route can be invoked with purchase_url(:id => product.id)

  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   map.resources :products

  # Sample resource route with options:
  #   map.resources :products, :member => { :short => :get, :toggle => :post }, :collection => { :sold => :get }

  # Sample resource route with sub-resources:
  #   map.resources :products, :has_many => [ :comments, :sales ], :has_one => :seller
  
  # Sample resource route with more complex sub-resources
  #   map.resources :products do |products|
  #     products.resources :comments
  #     products.resources :sales, :collection => { :recent => :get }
  #   end

  # Sample resource route within a namespace:
  #   map.namespace :admin do |admin|
  #     # Directs /admin/products/* to Admin::ProductsController (app/controllers/admin/products_controller.rb)
  #     admin.resources :products
  #   end

  # You can have the root of your site routed with map.root -- just remember to delete public/index.html.
  # map.root :controller => "welcome"

  # See how all your routes lay out with "rake routes"

  # Install the default routes as the lowest priority.
  # Note: These default routes make all actions in every controller accessible via GET requests. You should
  # consider removing or commenting them out if you're using named routes and resources.
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
end
