class CreateProfiles < ActiveRecord::Migration
  def self.up
    create_table :profiles do |t|
			t.column :user_id,:integer
			t.column :age	,:integer
			t.column :body_hairtype_id,:integer
			t.column :bodytype_id,:integer
			t.column :ethnicity_id,:integer
			t.column :hairtype_id,:integer
			t.column :height_id,:integer
			t.column :weight,:integer
			t.column :address,:text
			t.column :latitude,:string,:limit=>50
			t.column :longitude,:string,:limit=>50
      t.column :title,:string
			t.column :description,:text
			t.column :tattoos,:text
			t.column :interests,:text
			t.column :dob,:date
      t.timestamps
    end
  end

  def self.down
    drop_table :profiles
  end
end
