class CreateImages < ActiveRecord::Migration
  def self.up
    create_table :images, :force => true do |t|
      t.integer :attachable_id
      t.string :attachable_type
      t.integer :size
      t.string :content_type
      t.string :filename
      t.integer :height
      t.integer :width
      t.integer :parent_id
      t.string :thumbnail
      t.boolean :is_private,:default=>false
      t.integer :position
      t.timestamps
    end
  end

  def self.down
    drop_table :images
  end
end
