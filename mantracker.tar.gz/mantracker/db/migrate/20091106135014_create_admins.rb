class CreateAdmins < ActiveRecord::Migration
    def self.up
    create_table "admins", :force => true do |t|
  
      t.column :username,:string, :limit => 100, :default => '', :null => true
      t.column :email,:string, :limit => 100
      
      t.column :crypted_password,:string, :limit => 40
      t.column :salt,:string, :limit => 40
      
      t.column :created_at,:datetime
      t.column :updated_at,:datetime
      
    end
  Admin.create!(:username=>'admin', :password=>'mantracker', :password_confirmation=>'mantracker', :email=>'admin@mantracker.com')
  end

  def self.down
    drop_table "admins"
  end
  
end