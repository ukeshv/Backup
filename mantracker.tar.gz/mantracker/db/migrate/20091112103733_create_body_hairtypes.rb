class CreateBodyHairtypes < ActiveRecord::Migration
  def self.up
    create_table :body_hairtypes do |t|
      t.column :name,:string
      t.timestamps
    end
  end

  def self.down
    drop_table :body_hairtypes
  end
end
