class CreateFriendships < ActiveRecord::Migration
	def self.up
		create_table :friendships do |t|	
			t.column :user_id, :int
			t.column :friend_id, :int
			t.timestamps	
		end
	end
	
	def self.down
		drop_table :friendships
	end
end
