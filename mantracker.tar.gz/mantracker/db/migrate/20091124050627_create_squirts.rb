class CreateSquirts < ActiveRecord::Migration
	def self.up
		create_table :squirts do |t|
			t.integer :user_id
			t.string :message, :limit => 120
			t.timestamps
		end
	end
	
	def self.down
		drop_table :squirts
	end
end
