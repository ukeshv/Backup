class CreatePrivatePhotoViews < ActiveRecord::Migration
  def self.up
    create_table :private_photo_views do |t|
				t.integer :user_id,:viewer_id
				t.boolean :is_locked,:default=>true
        t.timestamps
    end
  end

  def self.down
    drop_table :private_photo_views
  end
end
