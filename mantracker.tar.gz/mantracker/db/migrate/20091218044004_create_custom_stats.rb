class CreateCustomStats < ActiveRecord::Migration
  def self.up
    create_table :custom_stats do |t|
      t.column :title,:string
      t.column :field_type,:string
      t.column :active_status,:boolean,:default=>true
      t.column :is_mandatory,:boolean,:default=>false
      t.column :created_at,:datetime
      t.column :updated_at,:datetime
    end
  end

  def self.down
    drop_table :custom_stats
  end
end
