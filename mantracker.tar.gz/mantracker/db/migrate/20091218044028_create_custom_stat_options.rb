class CreateCustomStatOptions < ActiveRecord::Migration
  def self.up
    create_table :custom_stat_options do |t|
      t.column :custom_stat_id,:integer
      t.column :option_value,:text
      t.column :created_at,:datetime
      t.column :updated_at,:datetime
    end
  end

  def self.down
    drop_table :custom_stat_options
  end
end
