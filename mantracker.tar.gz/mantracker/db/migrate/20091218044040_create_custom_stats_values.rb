class CreateCustomStatsValues < ActiveRecord::Migration
  def self.up
    create_table :custom_stats_values do |t|
      t.column :user_id,:integer
      t.column :custom_stat_id,:integer
      t.column :field_value,:text
      t.column :created_at,:datetime
      t.column :updated_at,:datetime
    end
  end

  def self.down
    drop_table :custom_stats_values
  end
end
