class CreateTrackers < ActiveRecord::Migration
  def self.up
    create_table :trackers do |t|
			t.integer :user_id,:viewed_user_id
      t.timestamps
    end
  end

  def self.down
    drop_table :trackers
  end
end
