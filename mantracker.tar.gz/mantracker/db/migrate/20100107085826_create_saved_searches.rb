class CreateSavedSearches < ActiveRecord::Migration
  def self.up
    create_table :saved_searches do |t|
		  t.column :name,:string
			t.column :user_id,:integer
		  t.column :address,:text
			t.column :miles_kms,:string
			t.column :latitude,:string,:limit=>50
			t.column :longitude,:string,:limit=>50
      t.column :profile_keyword,:string
  		t.column :age_from	,:integer
			t.column :age_to	,:integer
			t.column :height_from,:integer
			t.column :height_to,:integer
			t.column :weight_from,:integer
			t.column :weight_to,:integer
			t.column :bodytype_id,:string
			t.column :body_hairtype_id,:string
			t.column :hairtype_id,:string
			t.column :ethnicity_id,:integer
			t.column :tattoos,:string
			t.column :interests,:string
      t.timestamps
    end
  end

  def self.down
    drop_table :saved_searches
  end
end
