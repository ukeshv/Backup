class AddColumnInHeight < ActiveRecord::Migration
  def self.up
			add_column :heights,:h_value,:float
  	  names = Height.find(:all).collect{|x| x.name}
			names.each do |name|
			height = Height.find_by_name(name)
			h=	name.gsub('inches','')
			h1 = h.scan('"')
					if !h1.empty?
					h2 = h.gsub('"','.')
					height.h_value = h2
					height.save
					else
					height.h_value = h
					height.save
					end
			end

  end
			
  def self.down
			remove_column :heights,:h_value
  end
end
