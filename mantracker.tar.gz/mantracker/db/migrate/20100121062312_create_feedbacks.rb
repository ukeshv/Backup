class CreateFeedbacks < ActiveRecord::Migration
  def self.up
    create_table :feedbacks do |t|
		 t.integer :user_id
		 t.string :name,:user_email
		 t.text :description
      t.timestamps
	end
	add_column :users ,:is_freezed,:boolean,:default=>false
	add_column :users ,:is_private_photos_locked,:boolean
  end

  def self.down
    drop_table :feedbacks
		remove_column :users ,:is_freezed
		remove_column :users ,:is_private_photos_locked
  end
end
