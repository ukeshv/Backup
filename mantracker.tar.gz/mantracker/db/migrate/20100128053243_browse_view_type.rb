class BrowseViewType < ActiveRecord::Migration
  def self.up
			add_column :users ,:browse_view_type,:boolean,:default=>true
  end

  def self.down
				remove_column :users ,:browse_view_type,:boolean
  end
end
