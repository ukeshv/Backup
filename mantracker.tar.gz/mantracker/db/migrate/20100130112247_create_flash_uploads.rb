class CreateFlashUploads < ActiveRecord::Migration
  def self.up
    create_table :flash_uploads do |t|
				t.column :attachable_id, :integer
				t.column :attachable_type, :string
				t.column :size, :integer
				t.column :content_type, :string
				t.column :filename, :string
				t.column :height, :integer
				t.column :width, :integer
				t.column :thumbnail, :string
				t.column :parent_id, :integer
				t.timestamps
    end
  end

  def self.down
    drop_table :flash_uploads
  end
end
