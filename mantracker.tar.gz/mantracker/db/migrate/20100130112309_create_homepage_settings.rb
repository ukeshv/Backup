class CreateHomepageSettings < ActiveRecord::Migration
  def self.up
    create_table :homepage_settings do |t|
				t.column :title, :string
				t.column :place_holder, :integer, :limit => 2
				t.column :is_primary, :boolean,:default => false
				t.timestamps
    end
		HomepageSetting.create(:title=>"SIMPLE & CLEAR INTERFACE FOR OPTIMAL CRUISING",:place_holder=>1)
		HomepageSetting.create(:title=>"ALWAYS-VISIBLE MESSAGING ",:place_holder=>2)
		HomepageSetting.create(:title=>"ACCURATE DISTANCE RESULTS BETWEEN MEMBERS",:place_holder=>3)
		HomepageSetting.create(:title=>"INTERACTIVE BROWSE & SEARCH",:place_holder=>4)
		HomepageSetting.create(:title=>"CUSTOM SETTINGS",:place_holder=>5)
		HomepageSetting.create(:title=>"SQUIRTS",:place_holder=>6)
  end

  def self.down
    drop_table :homepage_settings
  end
end
