class CreateFooterLinks < ActiveRecord::Migration
  def self.up
    create_table :footer_links do |t|
      t.column :title , :string
      t.column :link , :string
      t.timestamps
    end
    FooterLink.create(:title=>"Link1")
    FooterLink.create(:title=>"Link2")
    FooterLink.create(:title=>"Link3")
    FooterLink.create(:title=>"Link4")
    FooterLink.create(:title=>"Link5")
  end

  def self.down
    drop_table :footer_links
  end
end
