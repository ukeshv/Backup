class MissColMess < ActiveRecord::Migration
  def self.up
    add_column :messages, :sender_is_saved, :boolean, :default => false
    add_column :messages, :sender_is_deleted, :boolean, :default => false
  end

  def self.down
    remove_column :messages, :sender_is_saved
    remove_column :messages, :sender_is_deleted
  end
end
