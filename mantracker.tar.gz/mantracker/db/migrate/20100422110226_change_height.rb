class ChangeHeight < ActiveRecord::Migration
  def self.up
    change_column :heights,:h_value,:string
  end

  def self.down
    change_column :heights,:h_value,:float
  end
end
