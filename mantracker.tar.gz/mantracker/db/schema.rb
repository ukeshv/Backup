# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20100422110226) do

  create_table "admins", :force => true do |t|
    t.string   "username",         :limit => 100, :default => ""
    t.string   "email",            :limit => 100
    t.string   "crypted_password", :limit => 40
    t.string   "salt",             :limit => 40
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "blocked_users", :force => true do |t|
    t.integer  "user_id"
    t.integer  "blocker_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "body_hairtypes", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "bodytypes", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "custom_stat_options", :force => true do |t|
    t.integer  "custom_stat_id"
    t.text     "option_value"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "custom_stats", :force => true do |t|
    t.string   "title"
    t.string   "field_type"
    t.boolean  "active_status", :default => true
    t.boolean  "is_mandatory",  :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "custom_stats_values", :force => true do |t|
    t.integer  "user_id"
    t.integer  "custom_stat_id"
    t.text     "field_value"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "email_notifications", :force => true do |t|
    t.string   "email",      :limit => 50
    t.string   "subject"
    t.text     "message"
    t.boolean  "is_sent",                  :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "enquiries", :force => true do |t|
    t.string   "name"
    t.string   "user_email"
    t.string   "message"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "ethnicities", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "faqs", :force => true do |t|
    t.string   "title"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "feedbacks", :force => true do |t|
    t.integer  "user_id"
    t.string   "name"
    t.string   "user_email"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "flash_uploads", :force => true do |t|
    t.integer  "attachable_id"
    t.string   "attachable_type"
    t.integer  "size"
    t.string   "content_type"
    t.string   "filename"
    t.integer  "height"
    t.integer  "width"
    t.string   "thumbnail"
    t.integer  "parent_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "footer_links", :force => true do |t|
    t.string   "title"
    t.string   "link"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "friendships", :force => true do |t|
    t.integer  "user_id"
    t.integer  "friend_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "hairtypes", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "heights", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "h_value"
  end

  create_table "homepage_settings", :force => true do |t|
    t.string   "title"
    t.integer  "place_holder", :limit => 2
    t.boolean  "is_primary",                :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "images", :force => true do |t|
    t.integer  "attachable_id"
    t.string   "attachable_type"
    t.integer  "size"
    t.string   "content_type"
    t.string   "filename"
    t.integer  "height"
    t.integer  "width"
    t.integer  "parent_id"
    t.string   "thumbnail"
    t.boolean  "is_private",      :default => false
    t.integer  "position"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "messages", :force => true do |t|
    t.integer  "receiver_id"
    t.integer  "sender_id"
    t.integer  "parent_msg_id"
    t.string   "subject"
    t.text     "body"
    t.boolean  "is_saved",          :default => false
    t.boolean  "is_read",           :default => false
    t.boolean  "is_deleted",        :default => false
    t.string   "reply_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "sender_is_saved",   :default => false
    t.boolean  "sender_is_deleted", :default => false
  end

  create_table "passwords", :force => true do |t|
    t.integer  "user_id"
    t.string   "reset_code"
    t.datetime "expiration_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "private_photo_views", :force => true do |t|
    t.integer  "user_id"
    t.integer  "viewer_id"
    t.boolean  "is_locked",  :default => true
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "profiles", :force => true do |t|
    t.integer  "user_id"
    t.integer  "age"
    t.integer  "body_hairtype_id"
    t.integer  "bodytype_id"
    t.integer  "ethnicity_id"
    t.integer  "hairtype_id"
    t.integer  "height_id"
    t.integer  "weight"
    t.text     "address"
    t.string   "latitude",         :limit => 50
    t.string   "longitude",        :limit => 50
    t.string   "title"
    t.text     "description"
    t.text     "tattoos"
    t.text     "interests"
    t.date     "dob"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "name"
  end

  create_table "saved_searches", :force => true do |t|
    t.string   "name"
    t.integer  "user_id"
    t.text     "address"
    t.string   "miles_kms"
    t.string   "latitude",         :limit => 50
    t.string   "longitude",        :limit => 50
    t.string   "profile_keyword"
    t.integer  "age_from"
    t.integer  "age_to"
    t.integer  "height_from"
    t.integer  "height_to"
    t.integer  "weight_from"
    t.integer  "weight_to"
    t.string   "bodytype_id"
    t.string   "body_hairtype_id"
    t.string   "hairtype_id"
    t.integer  "ethnicity_id"
    t.string   "tattoos"
    t.string   "interests"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "squirts", :force => true do |t|
    t.integer  "user_id"
    t.string   "message",    :limit => 120
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "templates", :force => true do |t|
    t.integer  "user_id"
    t.string   "name"
    t.string   "subject"
    t.text     "body"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "trackers", :force => true do |t|
    t.integer  "user_id"
    t.integer  "viewed_user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.string   "name",                      :limit => 100, :default => ""
    t.string   "email",                     :limit => 100
    t.integer  "image_id"
    t.string   "crypted_password",          :limit => 40
    t.string   "salt",                      :limit => 40
    t.string   "activation_code",           :limit => 40
    t.datetime "activated_at"
    t.string   "remember_token",            :limit => 40
    t.datetime "remember_token_expires_at"
    t.boolean  "status",                                   :default => true
    t.datetime "last_loggedin"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "online_status",                            :default => false
    t.datetime "online_at"
    t.boolean  "is_freezed",                               :default => false
    t.boolean  "is_private_photos_locked"
    t.boolean  "browse_view_type",                         :default => true
  end

end
