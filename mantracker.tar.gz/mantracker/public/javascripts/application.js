// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults

var photosCount = {};
var sortableStatus = {};
sortableStatus.forPublic = true;
sortableStatus.forPrivate = true;

function compose_track_msg(id,tab){    
new Ajax.Request("/user_messages/compose_message/?user_id="+id+"&tab="+tab,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader1');}, onLoading:function(request){Element.show('ajax-loader1');},insertion:Insertion.Top}); return false;
}
function sort_message(val,tab){
new Ajax.Request("/user_messages/sort_message/?val="+val+"&tab="+tab,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader1');}, onLoading:function(request){Element.show('ajax-loader1');},insertion:Insertion.Top}); return false;
}

function unsend_message(id){
new Ajax.Request("/user_messages/unsend_message/?id="+id,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function show_private_photos(id){
new Ajax.Request("/users/show_private_photos/?id="+id+"&photo_tab=priv",{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function show_public_photos(id){
new Ajax.Request("/users/show_public_photos/?id="+id+"&photo_tab=pub",{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function block_unblock(id,act_type,msg_id){
new Ajax.Request("/user_messages/block_unblock_user/?id="+id+"&act_type="+act_type+"&messageid="+msg_id,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader1');}, onLoading:function(request){Element.show('ajax-loader1');},insertion:Insertion.Top}); return false;
}

function add_to_buddies(id,act_type,msg_id){
new Ajax.Request("/user_messages/add_remove_to_buddies/?id="+id+"&act_type="+act_type+"&messageid="+msg_id,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader1');}, onLoading:function(request){Element.show('ajax-loader1');},insertion:Insertion.Top}); return false;
}

function send_to_trash(id){
new Ajax.Request("/user_messages/send_to_trash/?id="+id,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader1');}, onLoading:function(request){Element.show('ajax-loader1');},insertion:Insertion.Top}); return false;
}

function compose_msg(id,reply){
new Ajax.Request("/user_messages/compose_message/?user_id="+id+"&reply="+reply,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_send_message_img');}, onLoading:function(request){Element.show('ajax_send_message_img');},insertion:Insertion.Top}); return false;
}

function save_edit_template(id,body,message_id){
new Ajax.Request("/user_messages/save_edit_template/?template_id="+id+"&body="+body+"&message_id="+message_id,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader1');}, onLoading:function(request){Element.show('ajax-loader1');},insertion:Insertion.Top}); return false;
}

function show_sent_message(){
new Ajax.Request("/user_messages/show_sent_message/",{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader1');}, onLoading:function(request){Element.show('ajax-loader1');},insertion:Insertion.Top}); return false;
}

function show_saved_message(){
new Ajax.Request("/user_messages/show_saved_message/",{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader1');}, onLoading:function(request){Element.show('ajax-loader1');},insertion:Insertion.Top}); return false;
}

function show_trash_message(){
new Ajax.Request("/user_messages/show_trash_message/",{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader1');}, onLoading:function(request){Element.show('ajax-loader1');},insertion:Insertion.Top}); return false;
}

function show_inbox_message(){
new Ajax.Request("/user_messages/show_inbox_message/",{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader1');}, onLoading:function(request){Element.show('ajax-loader1');},insertion:Insertion.Top}); return false;
}

function show_message_part(){
new Ajax.Request("/user_messages/show_message_part/",{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function select_all(classname)
{
  var check_boxes= document.getElementsByName(classname);
  val = 0;
  for(i=0;i<check_boxes.length;i++)
  {
    check_boxes[i].checked=true;
  }
  return false;
}


function unselect_all(classname)
{
  var check_boxes= document.getElementsByName(classname);
  val =0;
  for(i=0;i<check_boxes.length;i++)
  {
    check_boxes[i].checked=false;
  }
  return false;
}

function select_read_inbox(classname,opt_val)
{
		arr=[];
		var check_boxes= document.getElementsByName(classname);
		for(i=0;i<check_boxes.length;i++)
		{
				arr.push(check_boxes[i].value);
		}
		new Ajax.Request("/user_messages/msg_inbox_read/?message_ids="+arr+"&option_value="+opt_val,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function select_read_saved(classname,opt_val)
{
		arr=[];
		var check_boxes= document.getElementsByName(classname);
		for(i=0;i<check_boxes.length;i++)
		{
				arr.push(check_boxes[i].value);
		}
		new Ajax.Request("/user_messages/msg_inbox_saved/?message_ids="+arr+"&option_value="+opt_val,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function select_read_trash(classname,opt_val)
{
		arr=[];
		var check_boxes= document.getElementsByName(classname);
		for(i=0;i<check_boxes.length;i++)
		{
				arr.push(check_boxes[i].value);
		}
		new Ajax.Request("/user_messages/msg_inbox_trash/?message_ids="+arr+"&option_value="+opt_val,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function select_read_status_inbox(clas)
{
		//alert("classname");
		$(clas).checked=true;
}

function select_read_status_saved(clas)
{
		//alert("classname");
		$(clas).checked=true;
}

function select_read_status_trash(cla)
{
		//alert("classname");
		$(cla).checked=true;
}

function move_to_trash(classname,opt_val){
  var check_boxes= document.getElementsByName(classname);
        arr = [ ];
                for(i=0;i<check_boxes.length;i++){
                        if(check_boxes[i].checked==true)
                        arr.push(check_boxes[i].value);
                }
                if (arr.length > 0){  
        new Ajax.Request("/user_messages/inbox_action/?message_ids="+arr+"&option_value="+opt_val,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
        }
        else{
        $('flashnotice').innerHTML = "<font color='red'>Select messages </font>"
        return false
        }

}

function open_msg(id){
new Ajax.Request("/user_messages/open_inbox_message?message_id="+id,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function open_msg_sent_saved_trash(id){
new Ajax.Request("/user_messages/open_msg_sent_saved_trash?message_id="+id,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function close_msg_template(id){
new Ajax.Request("/user_messages/close_message_template/?message_id="+id,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function close_edit_msg_template(id){
new Ajax.Request("/user_messages/close_editmessage_template/?message_id="+id,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function close_msg(){
new Ajax.Request("/user_messages/close_message/",{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function close_msg2(){
new Ajax.Request("/user_messages/close_message2/",{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function get_selected_temp(message_id){
               var cn = document.getElementsByClassName('dk_chk')
               var select ='';
								for(i=0;i<cn.length;i++){
										if(cn[i].checked==true)
										{
										select = cn[i].value;
										}
								}
							 new Ajax.Request('/user_messages/load_template?id='+select+'&message_id='+message_id,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function save_template(subject,body,name,receiver_id,parent_msg_id){
var temp_subject = subject
var temp_body = body
var temp_name = name
var temp_receiver_id = receiver_id
var temp_parent_msg_id = parent_msg_id
params = $H({subject: temp_subject, body: temp_body, name: temp_name,receiver_id: temp_receiver_id,parent_msg_id: temp_parent_msg_id}).toQueryString();
new Ajax.Request('/user_messages/save_a_template', {asynchronous: true, evalScripts:true, parameters:params});
}

function show_template(id){
new Ajax.Request('/user_messages/select_a_template/?message_id='+id,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function compose_show_template(){
new Ajax.Request('/user_messages/select_a_template/',{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

function edit_del_template(id,act_type){
               var cn = document.getElementsByClassName('dk_chk')
               var select ='';
                                                                               for(i=0;i<cn.length;i++){
                                                                                                               if(cn[i].checked==true)
                                                                                                               {
                                                                                                               select = cn[i].value;
                                                                                                               }
                                                                               }
               if(act_type == 'edit'){                                                         
                               new Ajax.Request('/user_messages/edit_a_template?id='+select+'&message_id='+id,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
               }
               if(act_type == 'del'){
                               new Ajax.Request('/user_messages/delete_a_template?id='+select+'&message_id='+id,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
               }
}


function hide_signup_tooltips(tooltipid){
	$(tooltipid).hide()
}

function show_signup_tooltips(tooltipid){
if($('hide_submit').style.display == 'none')
	$(tooltipid).show();
}

function assign_terms_val(){
if($('user_terms').checked == true){
$('user_terms').value = 1;}
else{
$('user_terms').value = 0;}
}

/* validate contact name */
function validate_name(){
if($('user_name').value == ''){
		$('name_tooltip').show()
		$('name_error').innerHTML = "Name can't be blank"
		$('name_error').show()
		$('password_tooltip').hide()
		$('password_error').hide()
		$('password_confirmation_tooltip').hide()
		$('password_confirmation_error').hide()
		$('email_tooltip').hide()
		$('email_error').hide()
		$('age_tooltip').hide()
		$('age_error').hide()
		$('hide_submit').hide()
		//$('user_name').focus()
	return false;
	}
	else
	{
		$('name_tooltip').hide()
		$('name_error').hide()
	return true;
	}
}

/* validate contact name length*/
function validate_length(){
if($('user_name').value.length < 3){
		$('name_tooltip').show()
		$('name_error').innerHTML = "Name length is too short"
		$('name_error').show()
		$('password_tooltip').hide()
		$('password_error').hide()
		$('password_confirmation_tooltip').hide()
		$('password_confirmation_error').hide()
		$('email_tooltip').hide()
		$('email_error').hide()
		$('age_tooltip').hide()
		$('age_error').hide()
		$('hide_submit').hide()
		//$('user_name').focus()
	return false;
	}
else if($('user_name').value.length > 16){
		$('name_tooltip').show()
		$('name_error').innerHTML = "Name length is too long"
		$('name_error').show()
		$('password_tooltip').hide()
		$('password_error').hide()
		$('password_confirmation_tooltip').hide()
		$('password_confirmation_error').hide()
		$('email_tooltip').hide()
		$('email_error').hide()
		$('age_tooltip').hide()
		$('age_error').hide()
		$('hide_submit').hide()
		//$('user_name').focus()
	return false;
	}
	else
	{
		$('name_tooltip').hide()
		$('name_error').hide()
	return true;
	}
}

function validate_password(){
if($('user_password').value==''){
	if(document.activeElement.id == 'user_password'){
			$('name_tooltip').hide()
			$('name_error').show()
			$('password_tooltip').show()
			$('password_error').innerHTML = "password can't be blank"
			$('password_error').show()
			$('password_confirmation_tooltip').hide()
			$('password_confirmation_error').hide()
			$('email_tooltip').hide()
			$('email_error').hide()
			$('age_tooltip').hide()
			$('age_error').hide()
			$('hide_submit').hide()
			//$('user_name').focus()
			//$('user_password').focus()
		return false;
	} //checking active element
	}
	else if($('user_password_confirmation').value==''){
	if(document.activeElement.id == 'user_password_confirmation'){
		$('name_tooltip').hide()
		$('name_error').show()
		$('password_tooltip').hide()
		$('password_error').hide()
		$('password_confirmation_tooltip').show()
		$('password_confirmation_error').innerHTML = "password confirmation can't be blank"
		$('password_confirmation_error').show()
		$('email_tooltip').hide()
		$('email_error').hide()
		$('age_tooltip').hide()
		$('age_error').hide()
		$('hide_submit').hide()
		//$('user_name').focus()
		//$('user_password_confirmation').focus()
	return false;
	}
	}
	else{
		$('password_tooltip').hide()
		$('password_error').hide()
		$('password_confirmation_tooltip').hide()
		$('password_confirmation_error').hide()
		return true;
	}
}

/* validate password length*/
function validatepwdLength(){
if($('user_password').value.length < 4){
		$('name_tooltip').hide()
		$('name_error').show()
		$('password_tooltip').show()
		$('password_error').innerHTML = "Password length is too short"
		$('password_error').show()
		$('password_confirmation_tooltip').hide()
		$('password_confirmation_error').hide()
		$('email_tooltip').hide()
		$('email_error').hide()
		$('age_tooltip').hide()
		$('age_error').hide()
		$('hide_submit').hide()
		//$('user_name').focus()
		//$('user_password').focus()
	return false;
	}
else if($('user_password').value.length > 21){
		$('name_tooltip').hide()
		$('name_error').show()
		$('password_tooltip').show()
		$('password_error').innerHTML = "Password length is too long"
		$('password_error').show()
		$('password_confirmation_tooltip').hide()
		$('password_confirmation_error').hide()
		$('email_tooltip').hide()
		$('email_error').hide()
		$('age_tooltip').hide()
		$('age_error').hide()
		$('hide_submit').hide()
		//$('user_name').focus()
		//$('user_password').focus()
	return false;
	}
	else{
		$('password_tooltip').hide()
		$('password_error').hide()
		return true;
	}
}


/* validate pwd and confirm pwd*/
function validatecpwd(){
if(($('user_password').value.strip()) != $('user_password_confirmation').value.strip()){
		$('name_tooltip').hide()
		$('name_error').hide()
		$('password_tooltip').hide()
		$('password_error').hide()
		$('password_confirmation_tooltip').show()
		$('password_confirmation_error').innerHTML ="Password doesn't match confirmation"
		$('password_confirmation_error').show()
		$('email_tooltip').hide()
		$('email_error').hide()
		$('age_tooltip').hide()
		$('age_error').hide()
		$('hide_submit').hide()
		//$('user_name').focus()
		//$('user_password_confirmation').focus()
	return false;
	}
	else{
		$('password_confirmation_tooltip').hide()
		$('password_confirmation_error').hide()
		$('password_confirmation_tick').show()
		return true;
	}
}


/* Email format validation*/
function validateEmail(){
var emailRegEx = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
str = document.getElementById('user_email').value;
if(str.match(emailRegEx)){
return true;
}else{
if(document.activeElement.id == 'user_email'){
		$('name_tooltip').hide()
		$('name_error').hide()
		$('password_tooltip').hide()
		$('password_error').hide()
		$('password_confirmation_tooltip').hide()
		$('password_confirmation_error').hide()
		$('email_tooltip').show()
		$('email_error').innerHTML = "Invalid email format"
		$('email_error').show()
		$('age_tooltip').hide()
		$('age_error').hide()
		//$('user_email').focus()
return false;
}
}
}

function check_email_uniq(emailval){
if($('existing_emails')){
			var existingemails = $('existing_emails').value.strip().split(',');	
			for (i=0;i<existingemails.length;i++){
				if(existingemails[i]== emailval) {
						$('name_tooltip').hide()
						$('name_error').hide()
						$('password_tooltip').hide()
						$('password_error').hide()
						$('password_confirmation_tooltip').hide()
						$('password_confirmation_error').hide()
						$('email_tooltip').show()
						$('email_error').innerHTML = "Email already exists"
						$('email_error').show()
						$('age_tooltip').hide()
						$('age_error').hide()
						//$('user_email').focus()
						$('hide_submit').hide()
							break;
							return false;
				}
				else{
				$('email_tooltip').hide()
				$('email_error').hide()
				return true;
				}
			}
}
else{
return true;
}

}


/* validate pwd and confirm pwd*/
function validateconfirm_email(){
if(($('user_email').value.strip()) != $('user_confirm_email').value.strip()){
if(document.activeElement.id=='user_confirm_email'){
		$('name_tooltip').hide()
		$('name_error').hide()
		$('password_tooltip').hide()
		$('password_error').show()
		$('password_confirmation_tooltip').hide()
		$('password_confirmation_error').hide()
		$('email_tooltip').show()
		$('email_error').innerHTML = "Email doesn't match confirmation"
		$('email_error').show()
		$('age_tooltip').hide()
		$('age_error').hide()
		$('hide_submit').hide()
		//$('user_name').focus()
	//$('user_email').focus()
	return false;
	}
	}
	else{
		$('email_tooltip').hide()
		$('email_error').hide()
		$('email_tick').show()
		return true;
	}
}



function age_limit(){
if( ($('terms').checked == true) && ($('user_age').value.strip() < 18)){
		$('name_tooltip').hide()
		$('name_error').hide()
		$('password_tooltip').hide()
		$('password_error').hide()
		$('password_confirmation_tooltip').hide()
		$('password_confirmation_error').hide()
		$('email_tooltip').hide()
		$('email_error').hide()
		$('age_tooltip').show()
		$('age_error').innerHTML = "Provide valid age"
		$('age_error').show()
		//$('user_age').focus()
return false;
}
else{
$('age_tooltip').hide()
$('age_error').hide()
return true;
}
}

function validate_step1(){
output = (validate_name() &&validate_length() && validate_password() && validatepwdLength() && validatecpwd() && validateEmail() && check_email_uniq($('user_email').value) && validateconfirm_email() && age_limit())
		if(output){
		$('completed1').src = "/images/step1_completed.jpg"
		$('hide_submit').show()
		}
		else{
		$('completed1').src = "/images/step1_hover.jpg"
		$('hide_submit').hide()
		}
}

//step 4 validation

function submit_validation(){
if(($('user_title').value.length >= 25) && ($('user_description').value.length >= 60))
{
if(document.activeElement.id=='user_description')
{
		$('user_discription_tooltip').hide()
		$('user_discription_error').hide()
}
else
{
		$('user_title_tooltip').hide()
		$('user_title_error').hide()
}
		$('completed4').src = "/images/step4_completed.jpg"
		$('profile_submit').show()
}
else
{
		if(document.activeElement.id=='user_description')
		{
				$('user_discription_tooltip').show()
				$('user_discription_error').show()
		}
		else
		{
				$('user_title_error').hide()
		}
		$('completed4').src = "/images/step4_hover.jpg"
		$('profile_submit').hide()
}
}


function load_char(val)
{ 
input = val.length;
num_val = 60 - input
$('letter').innerHTML=  "<span style='margin-left:10px;font-size:25px;color:#a6d2f7;font-weight:bold;'>"+num_val+"</span>"
if(parseInt(input) >= 25 )
{
$('headline_tick').show()
$('user_title_error').hide()
submit_validation()
}
else
{
$('user_title_tooltip').show()
$('user_title_error').show()
$('headline_tick').hide()
$('profile_submit').hide()
}
}

function check_length(val)
{
maxLen = 650;
$('user_description').value = $('user_description').value.substring(0, maxLen);
num_val = maxLen - $('user_description').value.length
input=$('user_description').value.length
$('txt_letter').innerHTML= "<span style='margin-left:10px;font-size:25px;color:#a6d2f7;font-weight:bold;'>"+num_val+"</span>"
if(parseInt(input) >= 60)
{
$('description_tick').show()
$('user_discription_tooltip').hide()
$('user_discription_error').hide()
load_char($('user_title').value)
//submit_validation()
}
else
{
$('user_discription_tooltip').show()
$('user_discription_error').show()
$('description_tick').hide()
$('profile_submit').hide()
//submit_validation()
}
}


function show_profile_tooltip(id){
		if(id == 'user_title'){
		$('user_title_tooltip').show()
		}
		else if(id == 'user_description'){
		$('user_discription_tooltip').show()
		}
}

function hide_profile_tooltip(id){
		if(id == 'user_title'){
		$('user_title_tooltip').hide()
		}
		else if(id == 'user_description'){
		$('user_discription_tooltip').hide()
		}
}

		function validate_map(){
		val = gSearchForm.input.value
		if((val != '') && ($('lat_val').value != '') && ($('lng_val').value != '')){		
		$('map_tooltip').hide()
		$('map_error').hide()
		$('completed2').src = "/images/step2_completed.jpg"
		$('map_submit').show()
		$('map_tick').show()
		return true;
		}		
		else{
		$('map_tooltip').show()
		$('map_error').show()
		$('map_tick').hide()
		$('map_submit').hide()
		return false;
		}
		}

function show_tooltip(id){
if(id == 'name_tooltip'){
		$('name_tooltip').show()
		$('password_confirmation_tooltip').hide()
		$('password_tooltip').hide()
		$('email_tooltip').hide()
		$('email_confirmation_tooltip').hide()
		$('age_tooltip').hide()
}
else if(id == 'password_tooltip'){
		$('password_tooltip').show()
		$('password_confirmation_tooltip').hide()
		$('name_tooltip').hide()
		$('email_tooltip').hide()
		$('email_confirmation_tooltip').hide()
		$('age_tooltip').hide()
}
else if(id == 'password_confirmation_tooltip'){
		$('password_confirmation_tooltip').show()
		$('password_tooltip').hide()
		$('name_tooltip').hide()
		$('email_tooltip').hide()
		$('email_confirmation_tooltip').hide()
		$('age_tooltip').hide()
}
else if(id == 'email_tooltip'){
		$('email_tooltip').show()
		$('email_confirmation_tooltip').hide()
		$('password_tooltip').hide()
		$('password_confirmation_tooltip').hide()
		$('name_tooltip').hide()
		$('age_tooltip').hide()
}
else if(id == 'email_confirmation_tooltip'){
		$('email_confirmation_tooltip').show()
		$('email_tooltip').hide()
		$('password_tooltip').hide()
		$('password_confirmation_tooltip').hide()
		$('name_tooltip').hide()
		$('age_tooltip').hide()
}
else if(id == 'age_tooltip'){
		$('age_tooltip').show()
		$('email_tooltip').hide()
		$('email_confirmation_tooltip').hide()
		$('password_tooltip').hide()
		$('password_confirmation_tooltip').hide()
		$('name_tooltip').hide()
		$('hide_submit').hide()
}
}

function validate_step(){
var name = $('user_name').value
var password = $('user_password').value
var confirmation_pwd = $('user_password_confirmation').value
var email = $('user_email').value
var confirmation_email = $('user_confirm_email').value
var age = $('user_age').value
params = $H({name: name, password: password, password_confirmation: confirmation_pwd, email: email, email_confirmation: confirmation_email, age: age}).toQueryString();
return new Ajax.Request('/users/save_user_detail/', {asynchronous: true, evalScripts: true, parameters:params, method: 'POST'});
}


function formValidator1(element){ 
	var search = document.getElementById('search');
	if(notEmpty_new(search, "Provide search text",element)){
		return true;
		}
  return false;
}


function notEmpty_new(elem, helperMsg,element){
  
	if(elem.value.trim().length == 0){ 
		$('search_text').innerHTML = helperMsg;
		$('search_text').style.display = 'block';
		$('flashnotice').style.display = 'none';
		document.getElementById(element).style.display = 'none';
		return false;
	}
	return true;
}

String.prototype.trim = function() {
a = this.replace(/^\s+/, '');
return a.replace(/\s+$/, '');
};

function profile_update(option) {

	if (option=="title") {
		var title = $('user_profile_title').value.trim()
		params = $H({title: title}).toQueryString();
		new Ajax.Request('/users/profile_title/', {asynchronous: true, evalScripts: true, parameters:params, method: 'POST'});
	}
	else {
		var description = $('user_description').value.trim()
		params = $H({description: description}).toQueryString();
		new Ajax.Request('/users/profile_description/', {asynchronous: true, evalScripts: true, parameters:params, method: 'POST'});
	}
}

function update_profile_title_char(val){
input = val.length;
num_val = 60 - input
$('letter').innerHTML=  "<span style='margin-left:10px;font-size:25px;color:#a6d2f7;font-weight:bold;'>"+num_val+"</span>"
}

function update_profile_desc_char(val)
{
maxLen = 650;
$('user_description').value = $('user_description').value.substring(0, maxLen);
$('txt_letter').innerHTML= "<span style='float:right;font-size:25px;color:#a6d2f7;font-weight:bold;'>"+(maxLen-$('user_description').value.length)+"</span>"
}

function update_squirts_char(val){
input = val.length;
num_val = 120 - input
$('squirts_count').innerHTML=  "<span id='msg_count' style='margin-left: 6px; font-size: 25px; color:#376eae; font-weight: bold; '>"+num_val+"</span>"
}

function make_primary()
{
	 params = $H({id: $('image_id').value,status: $('make_primary_photo').checked}).toQueryString();
	 new Ajax.Request('/users/make_primary_photo/', {asynchronous: true, evalScripts: true, parameters:params, method: 'POST'});
}

function change_image_type(type)
{ 
   	params = $H({id: $('image_id').value,status: type}).toQueryString();
	 new Ajax.Request('/users/photo_type/', {asynchronous: true, evalScripts: true, parameters:params, method: 'post'});
	 return false;
}

function clear_textbox()
{
	$('squirt_message').value = '';
	$('squirt_message').focus();
}

function remove_squirt(div_id)
{
	var parent_element = $('squirts_list');
	parent_element.childNodes[1].removeChild($(div_id));
}

function checkAddress(addr)
{
new Ajax.Request("/users/verify_address?address="+addr,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
}

function numericOnly(evt) 
{ 
    var charCode = (evt.which) ? evt.which : window.event.keyCode; 
 
    if (charCode <= 13) 
    { 
        return true; 
    } 
    else 
    { 
        var keyChar = String.fromCharCode(charCode); 
        var re = /[0-9]/ 
        return re.test(keyChar); 
    } 
}

function show_online_users_only(val) 
{
	params = $H({online_users_only: val}).toQueryString();
	new Ajax.Request('/users/show_on_line_buddies_list/', {asynchronous: true, evalScripts: true, parameters:params, method: 'POST'});
}

function show_online_users_filter(val)
{
	status=$('on_line_user').checked
	params = $H({filter_type: val,status: status}).toQueryString();
	new Ajax.Request('/users/show_on_line_buddies_list/', {asynchronous: true, evalScripts: true, parameters:params, method: 'POST'});
}


function reverst_squirt()
{ 
	 new Ajax.Request("/squirts/index/",{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader_for_profile_view');}, onLoading:function(request){Element.show('ajax_loader_for_profile_view');},insertion:Insertion.Top}); return false;
}

function revert_to_search()
{ 
	 new Ajax.Request("/search_users/show_results?search_val="+''+"&back_to_Search="+'',{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader_for_profile_view');}, onLoading:function(request){Element.show('ajax_loader_for_profile_view');},insertion:Insertion.Top}); return false;
}


		function addtxt(input,dropVal) {
			var obj=document.getElementById(input);
			obj.value = obj.value + dropVal;
		}
		
		function check_validation(){
		 var val = true;                                           
        val = validateSubject(val);
        val = validateMessage(val);        
		    return val;
		}
		
		function validateSubject(val){
		var subject_text = document.getElementById('email_notification_subject');
		var sub_error = document.getElementById('subject_error');
		if (subject_text.value=='' || subject_text.value==null){
			sub_error.innerHTML="<font color='red'>Subject cannot be blank</font>";
			sub_error.style.display='';
			val = false;   
		}
		else{
		 sub_error.style.display='none';   
		}
		return val;
		}
		
	  function validateMessage(val){
		var msg_text = document.getElementById('email_notification_message');
		var msg_error1 = document.getElementById('msg_error');
		if (msg_text.value=='' || msg_text.value==null){
			msg_error1.innerHTML="<font color='red'>Message cannot be blank</font>";
			msg_error1.style.display='';
			val = false;   
		}
		else{
		 msg_error1.style.display='none';   
		}
		return val;
		}
	
function stat_optionsshowhide(val) {
if (val=="textarea" || val=="textbox")  
	{ 	$('stats_options').hide(); }
else { $('stats_options').show();  }

}

function photo_image_view(img_id) { 
new Ajax.Request("/users/photo_view/?id="+img_id,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader');}, onLoading:function(request){Element.show('ajax_loader');},insertion:Insertion.Top}); return false;
}


function add_remove_buddy(user_id,status) { 
new Ajax.Request("/users/add_remove_buddy/?user_id="+user_id+"&status="+status,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_add_remove_img');}, onLoading:function(request){Element.show('ajax_add_remove_img');},insertion:Insertion.Top}); return false;
}

function profile_view(user_id, calledFrom) { 
if(calledFrom == 'profile'){
  new Ajax.Request("/users/user_profile_view/?id="+user_id+"&called_from="+calledFrom,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader');}, onLoading:function(request){Element.show('ajax_loader');},insertion:Insertion.Top}); return false;
 }else{
  new Ajax.Request("/users/user_profile_view/?id="+user_id,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader');}, onLoading:function(request){Element.show('ajax_loader');},insertion:Insertion.Top}); return false;
 }
}

function search_profile_view(user_id) { 
new Ajax.Request("/users/user_profile_view/?id="+user_id+"&search=",{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader');}, onLoading:function(request){Element.show('ajax_loader');},insertion:Insertion.Top}); return false;
}

function browse_profile_view(user_id) { 
new Ajax.Request("/browse_users/index/?id="+user_id+"&browse=",{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader');}, onLoading:function(request){Element.show('ajax_loader');},insertion:Insertion.Top}); return false;
}

function quick_list_profile_view(view_type) { 
new Ajax.Request("/browse_users/quick_list_profile_view/?view_type="+view_type,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader');}, onLoading:function(request){Element.show('ajax_loader');},insertion:Insertion.Top}); return false;
}

function block_unblock(id,status){
new Ajax.Request("/users/block_unblock_user/?id="+id+"&status="+status,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_block_unblock_img');}, onLoading:function(request){Element.show('ajax_block_unblock_img');},insertion:Insertion.Top}); 
return false;
}

function changeBox() 
{
  document.getElementById('div1').style.display='none';
  document.getElementById('div2').style.display='';
  document.getElementById('password').focus();
}
function restoreBox() 
{
	if(document.getElementById('password').value=='')
	{
	  document.getElementById('div1').style.display='';
	  document.getElementById('div2').style.display='none';
	}

}

function changeBox1() 
{
  document.getElementById('div3').style.display='none';
  document.getElementById('div4').style.display='';
  document.getElementById('password_confirmation').focus();
}
function restoreBox1() 
{
	if(document.getElementById('password_confirmation').value=='')
	{
	  document.getElementById('div3').style.display='';
	  document.getElementById('div4').style.display='none';
	}
}

//If user provides values for first step and after that,if they click on 'join free' button,we will be resetting values

function reset_form1_values()
{
$('user_name').value = '';
$('user_password').value = '';
$('user_password_confirmation').value = '';
$('user_email').value = '';
$('user_confirm_email').value = '';
$('user_age').value = '';
$('searchform').value = "";
$('user_terms').checked = false;
$('name_tick').hide();
$('name_imgerror').hide();
$('password_confirmation_tick').hide();
$('password_confirmation_imgerror').hide();
$('email_tick').hide();
$('email_imgerror').hide();
}

// this input box is created by map.js
function focus_map_input(){
 document.getElementsByName('search')[0].focus() 
}

// this input box is created by map.js
function clear_map_input(){
 document.getElementsByName('search')[0].value="" 
 document.getElementById('map').hide()
}


function show_form_if_all_fields_ticked(){
		if($('name_tick').style.display != 'none' && $('password_confirmation_tick').style.display != 'none' && $('email_tick').style.display != 'none'){ $('hide_submit' ).show()}
}	


function extractIds(x)
{
	//~ var x = Sortable.serialize( 'List1',{ name: 'list' });	
	if(x.include('&'))		// runs for more than one elements available in sortable items
	{
		var y = x.split('&list[]=');
		y[0] = y[0].split('list[]=')[1];
	}
	else		// runs for less than or equal to one element available in sortable items
	{
		var y = new Array();
		var li_id = x.substr((x.length-1),1);		
		if(li_id != 0)
		{
			y[0] = li_id;
		}
	}
	return y;
}

function enableDisableDragDrop()
{	
	//~ var publicIdsArray = extractIds(Sortable.serialize( 'List1',{ name: 'list' }));
	//~ var privateIdsArray = extractIds(Sortable.serialize( 'List2',{ name: 'list' }));
	updatePhotoCounts('public');
	if(photosCount.public >= 10)
	{
		// disable sortable for Public container, enable only draggable
		disableSortable('public');
	}
	else
	{
		// nothing to modify
		//~ if(sortableStatus.forPublic)
		//~ {	}
		//~ else
		//~ {			
			enableSortable('public');
		//~ }
	}
	updatePhotoCounts('private');
	if(photosCount.private >= 10)
	{
		// disable sortable for private container, enable only draggable
		disableSortable('private');
	}
	else
	{
		// nothing to modify
		enableSortable('private');
	}
	
}

function disableSortable(container_type)
{
	var divId = (container_type == 'public')? 'List1' : 'List2';
	var idsArray = extractIds(Sortable.serialize( divId,{ name: 'list' }));
	Sortable.destroy($(divId));
	for(var i=0; i<idsArray.length; i++)
	{
		new Draggable('list_' + idsArray[i], {revert: true});
	}
	if(container_type == 'public')
		sortableStatus.forPublic = false;
	else
		sortableStatus.forPrivate = false;
}

function enableSortable(container_type)
{
	var divId = (container_type == 'public')? 'List1' : 'List2';
	var actionName = (container_type == 'public')? 'photo_order_update_for_public' : 'photo_order_update_for_private';
	
	if(container_type == 'public')	{
		sortableStatus.forPublic = true;	}
	else	{
		sortableStatus.forPrivate = true;	}
	
	Sortable.create(divId, 
	{
		containment: ['List1','List2'], tag: 'li', dropOnEmpty: true, onUpdate:function(e)
		{
			if(sortableStatus.forPublic || sortableStatus.forPrivate)
			{
				var list = Sortable.serialize( divId,{ name: 'list' });
				var idArray = extractIds(list);
				var commonPhotoCount = (container_type == 'public')? photosCount.public : photosCount.private;
				if((idArray.length) > commonPhotoCount)
				{				
					alignPhotoPositions(idArray, container_type);
					new Ajax.Request('/users/' + actionName + '/', {asynchronous: true, evalScripts: true, parameters: list, method: 'POST'});					
					return false;
				}				
			}
			else
			{
				// alert('onchange called for destroyed sortable object');
			}
		}
	});	
}

function updatePhotoCounts(container_type)
{
	if(container_type == 'private')
	{		
		if(sortableStatus.forPrivate)
		{
			var list = extractIds(Sortable.serialize( 'List2',{ name: 'list' }));
			photosCount.private = list.length;
		}
		else
		{
			photosCount.private = (photosCount.private - 1);
		}
	}
	else 
	{
		if(sortableStatus.forPublic)
		{
			var list = extractIds(Sortable.serialize( 'List1',{ name: 'list' }));
			photosCount.public = list.length;
		}
		else
		{
			photosCount.public = (photosCount.public - 1);
		}
	}
}

function alignPhotoPositions(ids, containerType)
{	
	for(var i=0; i<ids.length; i++)
	{
		if(i > 4)
		{
			$('photoDiv_' + ids[i]).style.paddingTop = '5px';
		}
		else
		{
			if($('photoDiv_' + ids[i]) == null)
			{
				jQuery('#list_' + ids[i])[0].remove();				
			}
			else
			{
				$('photoDiv_' + ids[i]).style.paddingTop = '0px';
			}
			addTextMessageToContainer(containerType);
		}
	}
}


function addTextMessageToContainer(container_type)
{
	if(container_type == 'public')
	{
		if(photosCount.private == 0)
		{
			jQuery('#List2').append("<li style='list-style-type: none; width: 120px; position: relative;' id='list_0' class='testlist'><div id='private_photo' class='pro_thumb'>No Private Photos</div></li>")				
		}
	}
	else
	{
		if(photosCount.public == 0)
		{
			jQuery('#List1').append("<li style='list-style-type: none; width: 120px; position: relative;' id='list_0' class='testlist'><div id='public_photo' class='pro_thumb'>No Public Photos</div></li>")				
		}
	}
}

var _messageDiv = {};
_messageDiv.offsetCount = 10;
_messageDiv.stopAjax = false;

function initialiseScrollParams()
{
	_messageDiv.offsetCount = 10;
	_messageDiv.stopAjax = false;
}

function divScrollingEvent(elementObject, messageType)
{
	_messageDiv.ajaxFired = false;
	_messageDiv.totalHeight = elementObject.scrollHeight;
	_messageDiv.viewHeight = elementObject.clientHeight;
	_messageDiv.topContentHeight = elementObject.scrollTop;	
	_messageDiv.scrolledHeight = _messageDiv.viewHeight + _messageDiv.topContentHeight;
	
	if(_messageDiv.scrolledHeight >= (_messageDiv.totalHeight - 5))
	{		
		if(_messageDiv.ajaxFired)
		{
			// alert('alredy running');
		}
		else
		{
			if(_messageDiv.stopAjax)
			{
				//~ moveScrollerToTop();
				return false;	
			}
			else
			{
				_messageDiv.ajaxFired = true;
				new Ajax.Request('/users/append_message', {parameters: 'count=' + _messageDiv.offsetCount + '&message_type=' + messageType, asynchronous:true, evalScripts:true, method:'post'});			
				return false;
			}
		}
	}
}

function moveScrollerToTop()
{
	$('inbox_messages').scrollTop = ($('inbox_messages').scrollHeight - ($('inbox_messages').clientHeight + 30));	
}

function updateCurrentMessageCount(addedCount)
{
	$('current_message_count').innerHTML = parseInt($('current_message_count').innerHTML) + parseInt(addedCount);
}

function newMemberChange()
{
document.getElementById('myprofile').className=""
document.getElementById('newmember').className="current2"
document.getElementById('faq_layout').className=""
document.getElementById('contact_layout').className=""
document.getElementById('feedback_layout').className=""
document.getElementById('browse').className=""
document.getElementById('search').className=""
document.getElementById('squirts').className=""
}

function faqChange()
{
document.getElementById('myprofile').className=""
document.getElementById('newmember').className=""
document.getElementById('faq_layout').className="current2"
document.getElementById('contact_layout').className=""
document.getElementById('feedback_layout').className=""
document.getElementById('browse').className=""
document.getElementById('search').className=""
document.getElementById('squirts').className=""
}
function contactChange()
{
document.getElementById('myprofile').className=""
document.getElementById('newmember').className=""
document.getElementById('faq_layout').className=""
document.getElementById('contact_layout').className="current2"
document.getElementById('feedback_layout').className=""
document.getElementById('browse').className=""
document.getElementById('search').className=""
document.getElementById('squirts').className=""
}
function feedBackChange()
{
document.getElementById('myprofile').className=""
document.getElementById('newmember').className=""
document.getElementById('faq_layout').className=""
document.getElementById('contact_layout').className=""
document.getElementById('feedback_layout').className="current2"
document.getElementById('browse').className=""
document.getElementById('search').className=""
document.getElementById('squirts').className=""
}

 function create_slider(min, max, step, def){
	 A_TPL21h = {
		'b_vertical' : false,
		'b_watch': true,
		'n_controlWidth': 288,
		'n_controlHeight': 7,
		'n_sliderWidth': 15,
		'n_sliderHeight': 56,
		'n_pathLeft' : -6,
		'n_pathTop' : -24,
		'n_pathLength' : 286,
		's_imgControl': '/images/bar.jpg',
		's_imgSlider': '/images/slider.png',
		'n_zIndex': 1
	}

	 A_INIT21h = {
		's_form' : 0,
		's_name': 'sliderValue21h',
		'n_minValue' : 0,
		'n_maxValue' : 100,
		'n_value' : 5,
		'n_step' : 1
	}
	
	A_INIT21h['n_minValue'] = min;
	A_INIT21h['n_maxValue'] = max;
	A_INIT21h['n_value'] = def;
	A_INIT21h['n_step'] = step;	
	new slider(A_INIT21h, A_TPL21h);
}

function appendTextToLoader(distanceType, pageType)
{
		if (distanceType == "miles_hover")
		{ var textContent = "Already in Miles"; }
		if 	(distanceType == "kms")
		{ var textContent = "Switching to Kms"; }
		if (distanceType == "miles")
		{  var textContent = "Switching to Miles"; }
		if 	(distanceType == "km_hover")
		{ var textContent = "Already in Kms"; }
	//var textContent = (distanceType == 'miles')? 'Switching to Miles' : 'Switching to Kms';	
	var spanObj = $j("<span id='temporaryText' style='padding-bottom: 10px;'>" + textContent + "</span>");
	var childrenObj = $j('#ajax_loader').find("span");
	if(childrenObj.length == 0)
	{
		$j('#ajax_loader').append(spanObj);
		if(pageType == 'squirts')
		{
			$j('#ajax_loader').css('margin-left', '100px');
		}
		else if(pageType == 'search' || pageType == 'browse')
		{
			$j('#ajax_loader').css('width', '150px');
		}
	}
}

function removeTextFromLoader()
{
	$j('#temporaryText').remove();
	if(pageType == 'squirts')
	{
		$j('#ajax_loader').css('margin-left', '203px');
	}
	else if(pageType == 'search' || pageType == 'browse')
	{
		$j('#ajax_loader').css('width', '100px');
	}
}


function change_large_img(img_id,user_id)
{
		//alert(img_id);
		//alert(user_id);
		new Ajax.Request("/users/change_large_img/?img_id="+img_id+"&user_id="+user_id,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
}

