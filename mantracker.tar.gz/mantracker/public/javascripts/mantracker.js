function get_val(){

		get_other_params();
		get_online_status();
		get_body_type_val();
		get_ethnicity_val();
		body_hair_type_val();
		hair_type_val();
	 params = $H({squirts_search: search, distance: search_distance, profile_keyword: profile_keyword,body_types: body_type ,ethnicities: ethnicity,tatoos: tatoos,body_hair_types: body_hair_type,hair_types: hair_type,interests: interests,age: age,weight: weight,height: height,online_user_status: online_user});
	 new Ajax.Request('/search_users/search', {asynchronous: true, evalScripts:true, parameters:params});
}

function save_search_val(){
		get_other_params();
		get_online_status();
		get_search_val();
		get_body_type_val();
		get_ethnicity_val();
		body_hair_type_val();
		hair_type_val();

	 params = $H({squirts_search: search, distance: search_distance, profile_keyword: profile_keyword,body_types: body_type ,ethnicities: ethnicity,tatoos: tatoos,body_hair_types: body_hair_type,hair_types: hair_type,interests: interests,age: age,weight: weight,height: height,online_user_status: online_user,search_val: searchval});
	 new Ajax.Request('/search_users/show_results', {asynchronous: true, evalScripts:true, parameters:params.toQueryString()});
}

/* Get age , height,  weight , keyword , distance , tatoos and interests values */	
function get_other_params(){
    age = document.getElementById('amount').value
    weight= document.getElementById('amount2').value
    height= document.getElementById('amount1').value
	  search = document.getElementById('search_user').value
	  search_distance = document.getElementById('sliderValue1h').value
	  profile_keyword = document.getElementById('profile_content').value
	  tatoos = document.getElementById('tatoos').value
	  interests = document.getElementById('interests').value
		
	 return age,weight,height,search,search_distance,profile_keyword,tatoos,interests;
}

/* To show only online users */
function get_online_status(){
		if(document.getElementById('user_online_state').checked==true){
		 online_user = true;
		}
		else{
		 online_user = false;
		}
		return online_user;
}

/* To save the search */
function get_search_val(){
		searchval = ''
		if(searchval ==''){
		 search_val = ''
		}
		if(searchval !=''){
		search_val = ''
		}
		return search_val;
}

/* To get body type ids in array*/
function get_body_type_val(){
		body_type_ids=[]
		check_boxes= document.getElementsByName('body_type[]');
		val = 0;
		for(i=0;i<check_boxes.length;i++)
		{
		if(check_boxes[i].checked==true){
				body_type_ids.push(check_boxes[i].value);
				}
		}
		body_type = body_type_ids.join(",");
		document.getElementById('body_type_ids').value = body_type
		return body_type_ids;
}

/* To get ethnicity ids in array*/
function get_ethnicity_val(){
		ethnicity_ids =[]
		check_boxes1 = document.getElementsByName('ethnicity[]');
		val = 0;
		for(i=0;i<check_boxes1.length;i++)
		{
				if(check_boxes1[i].checked==true){
				ethnicity_ids.push(check_boxes1[i].value);
				}
		}
		ethnicity = ethnicity_ids.join(",");
		document.getElementById('ethnicity_ids').value = ethnicity
		return ethnicity_ids;
}

function body_hair_type_val(){
		body_hair_type_ids=[]
			check_boxes2 = document.getElementsByName('body_hair_type[]');
			val = 0;
			for(i=0;i<check_boxes2.length;i++)
			{
			 if(check_boxes2[i].checked==true){
						body_hair_type_ids.push(check_boxes2[i].value);
						}
			}
					 body_hair_type = body_hair_type_ids.join(",");
					 document.getElementById('body_hair_type_ids').value = body_hair_type
		return body_hair_type_ids;			 
}

function hair_type_val(){
			hair_type_ids=[]
			check_boxes3 = document.getElementsByName('hair_type[]');
			val = 0;
			for(i=0;i<check_boxes3.length;i++)
			{
			 if(check_boxes3[i].checked==true){
						hair_type_ids.push(check_boxes3[i].value);
						}
			}
			 hair_type = hair_type_ids.join(",");
			 document.getElementById('hair_type_ids').value = hair_type
		return hair_type_ids;
}

		function clear_searchform(){ 
		}
		
function online_users_in_browse(){
   get_online_status()
	 var location = document.getElementById('browse_user').value;
	 new Ajax.Request('/browse_users/index?online_user_status='+online_user+'&browse_location='+location, {asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader');}, onLoading:function(request){Element.show('ajax_loader');},insertion:Insertion.Top}); return false;
}

function calc_mile_distance(val,location,distance){
window.location = "/browse_users/?browse_location="+location+"&browse_distance="+val+"&distance_type="+distance
//~ new Ajax.Request("/browse_users/index?browse_location="+location+"&browse_distance="+val+"&distance_type="+distance, {asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader');}, onLoading:function(request){Element.show('ajax_loader');},insertion:Insertion.Top}); return false;
}
function calc_20_mile_distance(val1,val2,location,distance){
new Ajax.Request("/browse_users/index?browse_location="+location+"&start_distance="+val1+"&browse_distance="+val2+"&distance_type="+distance, {asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax_loader');}, onLoading:function(request){Element.show('ajax_loader');},insertion:Insertion.Top}); return false;
}
