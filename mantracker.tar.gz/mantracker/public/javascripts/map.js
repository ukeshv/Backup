    <!-- Replace with http://www.google.com/jsapi -->

    //<![CDATA[
    google.load('search', '1');
    google.load('maps', '2');
    // Our global state
    var gLocalSearch;
    var gMap;
    var gSelectedResults = [];
    var gCurrentResults = [];
    var gSearchForm;

    // Create our "tiny" marker icon
    var gSmallIcon = null;


    // Set up the map and the local searcher.
    function OnLoad() {
		  $('map').hide()
      gSmallIcon = new google.maps.Icon();
      gSmallIcon.image = "/images/iconr.png";
      gSmallIcon.shadow = "/images/shadow.png";
      gSmallIcon.iconSize = new google.maps.Size(12, 20);
      gSmallIcon.shadowSize = new google.maps.Size(22, 20);
      gSmallIcon.iconAnchor = new google.maps.Point(6, 20);
      gSmallIcon.infoWindowAnchor = new google.maps.Point(5, 1);
      
      gSearchForm = new google.search.SearchForm(false, document.getElementById("searchform"));
      gSearchForm.setOnSubmitCallback(null, CaptureForm);
      //gSearchForm.input.focus(); commented this line for IE issue

      // Initialize the map
      gMap = new google.maps.Map2(document.getElementById("map"));
      gMap.addControl(new google.maps.SmallMapControl());
      gMap.addControl(new google.maps.MapTypeControl());
      gMap.setCenter(new google.maps.LatLng(37.4419, -122.1419), 13);

      // Initialize the local searcher
      gLocalSearch = new google.search.LocalSearch();
      gLocalSearch.setCenterPoint(gMap);
      gLocalSearch.setSearchCompleteCallback(null, OnLocalSearch);

      // Execute the initial search
      gSearchForm.execute("");
				 var gbutton =  document.getElementsByClassName('gsc-search-button')
				 for(i=0;i<gbutton.length;i++){
				 gbutton[i].value=''
				}
				var gtxt =  document.getElementsByClassName('gsc-branding-text')
				for(j=0;j<gtxt.length;j++){
				 gtxt[j].hide()
				}
				var glogo =  document.getElementsByClassName('gsc-branding-img-noclear')
				for(j=0;j<glogo.length;j++){
				 glogo[j].hide()
				}
      gMap.checkResize(); 
		}

    // Called when Local Search results are returned, we clear the old
    // results and load the new ones.
    function OnLocalSearch() {
			$('map_error').show()
			$('map_submit').hide()
			$('map_tick').hide()
      if (!gLocalSearch.results) return;
      var searchWell = document.getElementById("searchwell");

      // Clear the map and the old search well
      searchWell.innerHTML = "";
      for (var i = 0; i < gCurrentResults.length; i++) {
        if (!gCurrentResults[i].selected()) {
          gMap.removeOverlay(gCurrentResults[i].marker());
        }
      }

      gCurrentResults = [];
      for (var i = 0; i < gLocalSearch.results.length; i++) {
        gCurrentResults.push(new LocalResult(gLocalSearch.results[i]));
      }

      var attribution = gLocalSearch.getAttribution();
      if (attribution) {
        document.getElementById("searchwell").appendChild(attribution);
      }

      // move the map to the first result
      var first = gLocalSearch.results[0];
			//alert(first.lat); alert(first.lng);
			$('lat_val').value= first.lat;
			$('lng_val').value= first.lng;
			
      lt = parseFloat(first.lat) + 0.499
      lg = parseFloat(first.lng) - 0.3
      gMap.panTo(new google.maps.LatLng(lt,lg));
		 var gtitle =document.getElementsByClassName('gs-title')
		 var gaddress =document.getElementsByClassName('gs-address')
		 var gphone =document.getElementsByClassName('gs-phone')
		 var gdirection =document.getElementsByClassName('gs-directions')
		 var gselect =  document.getElementsByClassName('select')
			if(gtitle.length>0){for(i=0;i<gtitle.length;i++){	gtitle[i].hide();}	}
			
			if(gaddress.length>0){for(j=0;j<gaddress.length;j++){gaddress[j].hide();} }
		
			if(gphone.length>0){for(k=0;k<gphone.length;k++){gphone[k].hide();	}}
		
			if(gdirection.length>0){for(a=0;a<gdirection.length;a++){gdirection[a].hide();}}
		
			if(gselect.length>0){for(b=0;b<gselect.length;b++){gselect[b].hide();}}
			validate_map();
      gMap.checkResize(); 
    }
		 
    // Cancel the form submission, executing an AJAX Search API search.
    function CaptureForm(searchForm) {
		$('map').hide()
		$('map_submit').hide()
		$('map_tick').hide()
		$('searchwell').hide()
		if($('map_tooltip')){
		  $('map_tooltip').show()
			}
      gLocalSearch.execute(searchForm.input.value);
      return false;
    }



    // A class representing a single Local Search result returned by the
    // Google AJAX Search API.
    function LocalResult(result) {
		  this.result_ = result;
      this.resultNode_ = this.unselectedHtml();
      document.getElementById("searchwell").appendChild(this.resultNode_);
      gMap.addOverlay(this.marker(gSmallIcon));
    }

    // Returns the GMap marker for this result, creating it with the given
    // icon if it has not already been created.
    LocalResult.prototype.marker = function(opt_icon) {

      if (this.marker_) return this.marker_;
      var marker = new google.maps.Marker(new google.maps.LatLng(parseFloat(this.result_.lat),
                                         parseFloat(this.result_.lng)),
                               opt_icon);
      GEvent.bind(marker, "click", this, function() {
        marker.openInfoWindow(this.selected() ? this.selectedHtml() :
                                                this.unselectedHtml());
      });
		  gMap.setCenter(new google.maps.LatLng(parseFloat(this.result_.lat), parseFloat(this.result_.lng)), 8);
      this.marker_ = marker;
      return marker;
    }

    // "Saves" this result if it has not already been saved
    LocalResult.prototype.select = function() {
		
      if (!this.selected()) {
        this.selected_ = true;

        // Remove the old marker and add the new marker
        gMap.removeOverlay(this.marker());
        this.marker_ = null;
        gMap.addOverlay(this.marker(G_DEFAULT_ICON));

        // Add our result to the saved set
        document.getElementById("selected").appendChild(this.selectedHtml());

        // Remove the old search result from the search well
        this.resultNode_.parentNode.removeChild(this.resultNode_);
      }
    }

    // Returns the HTML we display for a result before it has been "saved"
    LocalResult.prototype.unselectedHtml = function() {

				$('map').show()
			if($('map_tooltip')){
		  $('map_tooltip').hide()
		  $('map_error').hide()
			}
		
      var container = document.createElement("div");
      container.className = "unselected";
      container.appendChild(this.result_.html.cloneNode(true));
      var saveDiv = document.createElement("div");
      saveDiv.className = "select";
      saveDiv.innerHTML = "Save this location";
      GEvent.bindDom(saveDiv, "click", this, function() {
        gMap.closeInfoWindow();
        this.select();
        gSelectedResults.push(this);
      });
      container.appendChild(saveDiv);
      return container;
    }

    // Returns the HTML we display for a result after it has been "saved"
    LocalResult.prototype.selectedHtml = function() {
      return this.result_.html.cloneNode(true);
    }

    // Returns true if this result is currently "saved"
    LocalResult.prototype.selected = function() {
      return this.selected_;
    }

    google.setOnLoadCallback(OnLoad, true);
    //]]>
