require 'test_helper'

class Admin::BodyHairtypesHelperTest < ActionView::TestCase
end
