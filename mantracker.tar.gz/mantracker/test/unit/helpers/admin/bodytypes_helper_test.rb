require 'test_helper'

class Admin::BodytypesHelperTest < ActionView::TestCase
end
