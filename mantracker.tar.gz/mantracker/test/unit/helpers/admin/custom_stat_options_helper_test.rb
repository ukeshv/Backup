require 'test_helper'

class Admin::CustomStatOptionsHelperTest < ActionView::TestCase
end
