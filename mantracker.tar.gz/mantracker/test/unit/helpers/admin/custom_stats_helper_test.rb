require 'test_helper'

class Admin::CustomStatsHelperTest < ActionView::TestCase
end
