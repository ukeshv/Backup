require 'test_helper'

class Admin::EmailNotificationsHelperTest < ActionView::TestCase
end
