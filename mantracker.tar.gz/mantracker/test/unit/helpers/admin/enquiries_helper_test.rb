require 'test_helper'

class Admin::EnquiriesHelperTest < ActionView::TestCase
end
