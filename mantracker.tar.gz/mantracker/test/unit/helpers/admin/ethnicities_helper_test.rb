require 'test_helper'

class Admin::EthnicitiesHelperTest < ActionView::TestCase
end
