require 'test_helper'

class Admin::FeedbacksHelperTest < ActionView::TestCase
end
