require 'test_helper'

class Admin::HairtypesHelperTest < ActionView::TestCase
end
