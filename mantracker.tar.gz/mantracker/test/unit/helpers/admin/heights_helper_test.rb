require 'test_helper'

class Admin::HeightsHelperTest < ActionView::TestCase
end
