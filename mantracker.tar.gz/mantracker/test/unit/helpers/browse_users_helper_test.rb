require 'test_helper'

class BrowseUsersHelperTest < ActionView::TestCase
end
