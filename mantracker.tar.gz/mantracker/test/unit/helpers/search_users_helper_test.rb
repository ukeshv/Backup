require 'test_helper'

class SearchUsersHelperTest < ActionView::TestCase
end
