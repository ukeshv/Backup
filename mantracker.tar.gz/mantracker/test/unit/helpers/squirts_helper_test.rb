require 'test_helper'

class SquirtsHelperTest < ActionView::TestCase
end
