require 'test_helper'

class UserMessagesHelperTest < ActionView::TestCase
end
