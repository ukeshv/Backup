class AccountsController < ApplicationController
#layout 'home'	
layout 'newadmin'	

# # Change password action  
   def update
   return unless request.post?
   current_user.skip_pwd = 1
     if User.authenticate(current_user.email, params[:old_password])
       if ((params[:password] == params[:password_confirmation]) && !params[:password_confirmation].blank?)
         current_user.password_confirmation = params[:password_confirmation]
         current_user.password = params[:password]        
	
	if current_user.save
           flash[:notice] = "Password successfully updated."
           redirect_to(:controller=>'users',:action=>'dashboard')
         else
           flash[:error] = "Password Should be of length 8 and contain atleast one integer."
           redirect_to :controller=>'users', :action => 'edit_profile'
	 end
   
       else
         flash[:error] = "New password does not match the password confirmation."
         @old_password = params[:old_password]
         redirect_to :controller=>'users', :action => 'edit_profile'
       end
     else
       flash[:error] = "Your old password is incorrect."
       redirect_to :controller=>'users', :action => 'edit_profile'
     end 
   end
end
