class AdminController < ApplicationController
  before_filter :check_admin_officeadmin,:except=>[:login,:flashupload_whitepaper]
  #before_filter :check_valid_adminlogin,:except=>[:login,:formsummary,:edit_form]
  layout 'newadmin',:except=>[:login,:show_admin,:edit_admin,:new_admin,:show_user,:edit_user,:new_user,:advanced_search,:flashupload_whitepaper] 
  require 'csv'
	protect_from_forgery :except=>[:new_admin,:edit_admin,:show_admin,:new_user,:edit_user,:show_user,:global_users,:admin_search,:list_users,:user_search,:add_officefollowup,:flashupload_whitepaper,:office_form,:formslist_search]
	session :cookie_only => false, :only => [:flashupload_whitepaper]
 
  def index
    @recent_submittedforms = Formsubmission.find(:all,:conditions=>['submitted_date > ?',Date.today-7],:limit=>5)
    @closing_officeforms = Officeform.find(:all,:conditions=>['submission_end_date > ?',Date.today+7],:limit=>5)
    @new_officeforms = Officeform.find(:all,:conditions=>['created_at > ?',Date.today-7],:limit=>5)
  end


  def change_password
	  @user = User.find(params[:id])
		return unless request.post?
    if ((params[:password] == params[:password_confirmation]) && !params[:password_confirmation].blank?)
          @user.password_confirmation = params[:password_confirmation]
          @user.password = params[:password]
					@user.skip_pwd = 1					
					@user.skip_office = 1					
		  if @user.update_attributes(:password=>params[:password],:password_confirmation=>params[:password_confirmation])
            flash[:notice] = "Password successfully updated."
            redirect_to(:controller=>'admin',:action=>'list_users')
      else
            flash.now[:error] = "Password must be Minimum 8 character and 1 integer."
            render :action => 'change_password'
	    end
    else
          flash.now[:error] = "New password does not match the password confirmation."
          render :action => 'change_password'      
    end
  end

  def login
    return unless request.post?  
    @admin= Admin.authenticate(params[:login], params[:password])
    if @admin && @admin.active_status == true
	session[:admin_id] = @admin.id
	redirect_to(:action=>'index')
	else
	flash.now[:error] = "Invalid account details"
	render :action=>'login'	
	end
end

#To change status of public user / global admin status as active or inactive for selected checkboxes

	def active_inactive_users(prms, current_model, user_or_admin)
		if !params["inactive_all.x"].nil?         
			if !prms.nil?
				prms.each {|x|          
				inactive_user = current_model.find(x)
				inactive_user.update_attributes(:active_status=>false)
				flash.now[:notice] = "The Selected #{user_or_admin} Are Inactivated"
				}           
			end
		end
		if !params["active_all.x"].nil?   
			if !prms.nil?
				prms.each {|x|
				active_user = current_model.find(x)   
				active_user.update_attributes(:active_status=>true)
				flash.now[:notice] = "The Selected #{user_or_admin} Are Activated"
				}            
			end
		end
	end

#List Public Users

	def list_users
		params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
		active_inactive_users(params[:user], User, "Users")
		sort_users
	end

#Sort Public Users

	def sort_users
		session[:publicuser_search] = false
	  @users = User.paginate(:all,:select=>['id,firstname,lastname,email,city,state,active_status'],:order =>params[:sort],:per_page =>params[:per_page],:page=>params[:page])
		if request.xml_http_request?
			render :update do |page|
				page.replace_html "users_list", :partial=>'users_list'
			end	
		end
	end

#To add a new public user

  def new_user
    @user = User.new
  end
	
#To create a new public user

  def create_user
    @user = User.new(params[:user])
    if  @user.save
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html 'flashnotice',"User created successfully"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
    else
			show_errorsof_publicuser_field(action = 'create')
    end
  end	  

#To display errors of public user fields when creating or updating

	def show_errorsof_publicuser_field(action)
		render :update do |page|       
			for h in @user.errors
				if !@user.errors["#{h[0]}"].nil?
					page.show "#{h[0]}_user"              
					page.replace_html "#{h[0]}_user","#{h[1]}"
				end          
				page.hide "email_user" if @user.errors['email'].nil?
				page.hide "password_user" if @user.errors['password'].nil? if action == 'create'
				page.hide "password_confirmation_user" if @user.errors['password_confirmation'].nil? if action == 'create'
				page.hide "firstname_user" if @user.errors['firstname'].nil?
				page.hide "address1_user" if @user.errors['address1'].nil?
				page.hide "city_user" if @user.errors['city'].nil?
				page.hide "state_user" if @user.errors['state'].nil?
				page.hide "zip_user" if @user.errors['zip'].nil?
			end
		end 
	end

#To show details of a public user

  def show_user
		@user = User.find(params[:id])
  end

#To edit details of a public user

  def edit_user
		@user = User.find(params[:id])
  end

#To update details of a public user

  def update
		@user = User.find(params[:id])
		if @user.update_attributes(params[:user])
			@users = User.paginate(:all,:order =>params[:sort],:per_page =>10,:page=>params[:page])
					render :update do |page|
						page.hide 'modal_container'
						page.hide 'modal_overlay'
						page.replace_html "users_list", :partial=>'users_list'
						page.replace_html 'flashnotice',"User Updated successfully"
						page.visual_effect :fade,'flashnotice',:duration => 1.5
					end
		else
				show_errorsof_publicuser_field(action = 'update')
		end
  end

#To clear session of logged in global admin 

  def logout
		reset_session
		session[:admin_id] = nil
		flash[:notice] = "You have been logged out."
		redirect_to(:action=>'login')
  end 

#To view list of forms submitted by an public user

	def office_form
		@user = User.find(params[:id])
		check_login
		session[:users_formslistsearch] = false
		sort_list_officeforms
	end

#To sort list of forms submitted by an public user

	def sort_list_officeforms
		params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])
		@list_forms = Formsubmission.paginate :per_page =>params[:per_page],:page=>params[:page],:conditions =>['user_id = ? ',params[:id]],:order =>params[:sort],:include=>[:office,:followup_value]	  
		if request.xml_http_request?
			render :update do |page|      
				page.replace_html "forms_list",:partial=>'list_office_form'
			end	
		end	
	end

#To search list of forms submitted by an public user

	def formslist_search
		@user = User.find(params[:id])
		session[:users_formslistsearch] = true
		params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page]) 

		conditions = "user_id = #{params[:id]} and ((offices.name like '%%"+params[:search_txt].to_s+"%%') or (org_name like '%%"+params[:search_txt].to_s+"%%') or (project_description like '%%"+params[:search_txt].to_s+"%%'))"  if !params[:search_txt].blank?
		options = {:per_page=>params[:per_page], :page=>params[:page], :order=>params[:sort], :include=>[:office], :conditions=>conditions}

		if !params[:search_txt].blank?
			@list_forms = Formsubmission.paginate(options)
			if @list_forms.empty?
				options[:conditions]="user_id = #{params[:id]}"
				@list_forms = Formsubmission.paginate(options) 
				formslistsearch(flash_error='flasherror',search_result_error="Your Search produced no results for #{params[:search_txt]}")
			else
				formslistsearch(flash_notice='flashnotice',search_result_notice="Your Search results for #{params[:search_txt]}")
			end
		else
			options[:conditions]="user_id = #{params[:id]}"
			@list_forms = Formsubmission.paginate(options) 
			formslistsearch(flash_error='flasherror',search_result_error="Provide search text")
		end
	end

#To display appropriate for flashing error and notices when search is done

	def formslistsearch(flash,search_result)
		render :update do |page|
			page.replace_html "forms_list",:partial=>'list_office_form'
			page.show(flash) if params[:sort].nil?
			page.replace_html flash, search_result if params[:sort].nil?
			page.visual_effect :fade,flash,:duration => 1.5 if params[:sort].nil?
		end	
	end

#To display summary of a single form

  def formsummary
		@form_submission = Formsubmission.find(params[:id])
		if !@form_submission.submitted_date.nil?
		@comments =  @form_submission.comments.find(:all, :order=>'created_at DESC') 
		@committee_comments =  @form_submission.committee_member_comments.find(:all, :order=>'created_at DESC') 
		@office_form = @form_submission.office.officeform
		@custom_values =  CustomValue.find :all,:conditions=>['formsubmission_id = ? and custom_fields.active_status = ?',@form_submission.id,true],:include=>[:custom_field]    
		agency = Agency.find_by_name(@form_submission.agency_name)  if !@form_submission.agency_name.blank? || !@form_submission.agency_name.nil?
		@agency_custom_values =  agency.nil? ? [ ] : (AgencyCustomValue.find :all,:conditions=>['formsubmission_id = ? and agency_custom_fields.agency_id = ? and agency_custom_fields.active_status = ?',@form_submission.id,agency.id,true],:include=>[:agency_custom_field])    
		check_officeadmin(@form_submission.office_id)
		if (session[:officeadmin_id] || session[:officeuser_id]) && session[:office_id]
			@current_login = session[:officeadmin_id] ? session[:officeadmin_id] : session[:officeuser_id]
			@logged_office_admin	= Officeadmin.find(@current_login)
			assign_category_role
			assign_editform_role	
			@referers = Officeadmin.find(:all,:conditions=>['office_id = ? and id != ?',session[:office_id],@current_login])
			@form_original_version = @form_submission.versions.latest
		elsif session[:admin_id]
			@referers = Admin.find(:all,:conditions=>['id != ?',session[:admin_id]])	
		end
		else
			redirect_to(:action=>'login')
		end	
  end

#To display summary of a single form i.e., original form submitted by public user - retreived from form_submissions_versions and custom_values_versions tables

	def usersummary
	@form = Formsubmission.find(params[:id])
	@form_submission = @form.versions.latest
	@office_form = @form.office.officeform	
	@custom_values =  CustomValueVersion.find :all,:conditions=>['formsubmission_id = ?',@form.id]
	agency = Agency.find_by_name(@form.agency_name)
	@agency_custom_values = agency.nil? ? [ ] : (AgencyCustomValueVersion.find :all,:conditions=>['formsubmission_id = ? and agency_custom_fields.agency_id = ? and agency_custom_fields.active_status = ?',@form.id,agency.id,true],:include=>[:agency_custom_field] ) 
	end	

#To check if office admin/user has updating category permission or not 

	def assign_category_role
		if @logged_office_admin.is_admin == true
			@category_permission = true
			find_categories
		elsif @logged_office_admin.is_admin == false && @logged_office_admin.category_role == true
			find_categories
			@category_permission = true
		else
			@category_permission = false
		end
	end

#To find if any categories present to display in drop down or not

	def find_categories
		unless @logged_office_admin.office.followup_fields.empty?
			@categories = @logged_office_admin.find_defaultvalues
		else
			@categories = nil
		end
	end	

#To check if office admin/user has editing form permission or not

	def assign_editform_role
		if @logged_office_admin.is_admin == true
			@edit_permission = true	
		elsif @logged_office_admin.is_admin == false && @logged_office_admin.editform == true
			@edit_permission = true	
		else
			@edit_permission = false	
		end
	end	

	def add_officefollowup
	  @form_submission = Formsubmission.find(params[:id])
    @form_submission.update_attributes(:office_followup=>params[:followup_val])
			render :update do |page|
  			page.replace_html 'success_msg',"<font color='green'>Followup updated for form Successfully</font>"
			end
	end

#To add comment for a form

	def add_comment
		@form_submission = Formsubmission.find(params[:id])
		unless params[:comment][:comment].empty? || params[:comment][:comment].blank?	  
			c = Comment.new(:comment => params[:comment][:comment])
			@form_submission.comments << c    
			if session[:office_id] && session[:officeadmin_id]
				c.update_attributes(:followup_updatedby=>session[:officeadmin_id],:followup_updated=>2)	
			elsif session[:office_id] && session[:officeuser_id]
				c.update_attributes(:followup_updatedby=>session[:officeuser_id],:followup_updated=>3)		
			else
				c.update_attributes(:followup_updatedby=>session[:admin_id],:followup_updated=>1)	
			end
		end
		if (session[:officeadmin_id] || session[:officeuser_id]) && session[:office_id]
			@current_login = session[:officeadmin_id] ? session[:officeadmin_id] : session[:officeuser_id]
			@logged_office_admin	= Officeadmin.find(@current_login)
			assign_category_role
			@referers = Officeadmin.find(:all,:conditions=>['office_id = ? and id != ?',session[:office_id],@current_login])
		elsif session[:admin_id]
			@referers = Admin.find(:all,:conditions=>['id != ?',session[:admin_id]])
		end
		find_referrer_mail
		save_followup_value
		@comments =  @form_submission.comments.find(:all, :order=>'created_at DESC')
		if !params[:comment][:comment].empty? || !params[:comment][:comment].blank?		
			params[:referrer][:id].blank? ? update_after_comment_referring('Comment Posted Successfully','green') : update_after_comment_referring('Comment Posted and Mail sent successfully','green')
		elsif (params[:comment][:comment].empty? || params[:comment][:comment].blank?) and (params[:referrer][:id].blank?) and (params[:followup_value].nil? || params[:followup_value][:field_value].blank?)
			if !params[:followup_value].nil?
			update_after_comment_referring('Enter Comment (or) Select Referrer Mail','red')
			else
			update_after_comment_referring('Enter Comment (or) Select Category','red')
			end	
		else	
			update_after_comment_referring('Followup(s) updated for form Successfully','green')
		end	
	end

#To display error or flash notices after adding comment or referring form to an users belongs to his/her office

	def update_after_comment_referring(display_txt,error_or_notice)
		if !params[:comment][:comment].empty? || !params[:comment][:comment].blank?
			@last_comment = @form_submission.comments.find(:last) 
			render :update do |page|
				page.replace_html 'formcomment',:partial=>'showcomment',:locals=>{:comments=>@comments,:form_submission=>@form_submission,:referers=>@referers} 
				page.visual_effect :highlight, 'formcomment'
				
				page.replace_html 'success_msg',"<font color='#{error_or_notice}'>#{display_txt}</font>"
				page.visual_effect :highlight, "comment_#{@last_comment.id}" 
				page.visual_effect :highlight, 'success_msg'
				page[:comment_comment].value = ""
			end
		else
			render :update do |page|
				page.replace_html 'formcomment',:partial=>'showcomment',:locals=>{:comments=>@comments,:form_submission=>@form_submission,:referers=>@referers} 
				page.visual_effect :highlight, 'formcomment'

				page.replace_html 'success_msg',"<font color='#{error_or_notice}'>#{display_txt}</font>"
				page.visual_effect :highlight, 'success_msg'
				page[:comment_comment].value = ""
			end	
		end
	end	

#To create or edit the field_value,followupfield_id and formsubmission_id in Followup Value table i.e.,to change the category of a form specified by another office user/admin

	def save_followup_value
		if @category_permission == true
			if !params[:followup_value].nil?
			unless params[:followup_value][:field_value].blank?
			@f = @logged_office_admin.office.followup_fields
				@f.each do |f|
					@s = f.id if f.default_value.include?(params[:followup_value][:field_value]) #To find the followup_field id of selected category from drop down
				end
				saved_followup_val = FollowupValue.find_by_formsubmission_id_and_followup_field_id(@form_submission.id,@s)
				if saved_followup_val.nil?
					@followup_value = FollowupValue.create(:formsubmission_id=>@form_submission.id,:followup_field_id=>@s,:field_value=>params[:followup_value][:field_value])
				else
					saved_followup_val.update_attributes(:field_value=>params[:followup_value][:field_value])
				end
			end
		end
		end
	end

#To find who is the referrer and also the referred to person

	def find_referrer_mail
		unless params[:referrer][:id].blank?
			if (session[:officeadmin_id] || session[:officeuser_id]) && session[:office_id]
				officemember = Officeadmin.find(@current_login)
				referredmember = Officeadmin.find(params[:referrer][:id])
				OfficeadminMailer.deliver_mail_referrer(referredmember,officemember,@form_submission)
			elsif session[:admin_id]
				adminmember = Admin.find(session[:admin_id])
				referredmember = Admin.find(params[:referrer][:id])
				AdminNotifier.deliver_mail_referrer(referredmember,adminmember,@form_submission)
			end	
		end	
	end

#To download whitepaper uploaded when form is submitted

	def download_whitepaper
		@form_submission = Formsubmission.find(params[:id])
		@whitepaper = @form_submission.whitepaper_upload
		filepath = @whitepaper.public_filename
		system "clamscan -r #{filepath}"
      a = `clamscan -r #{filepath}`
      if a.scan(/Infected files:(.*)Data scanned/m).to_s.strip == 1
        flash[:error] = "Download file has been infected"
        redirect_to(:action=>'formsummary',:id=>params[:id])
      else
				if File.exists? filepath
				send_file filepath
				else
				redirect_to(:action=>'formsummary',:id=>params[:id])
				end
      end  
		
	end

#To download whitepaper uploaded when form is submitted

	def download_original_whitepaper
		@original_version = WhitepaperUploadVersion.find_original_version(params[:id])
		 if !@original_version.nil?
			@whitepaper = WhitepaperUpload.find(@original_version.whitepaper_upload_id)
			filepath = @whitepaper.public_filename
			system "clamscan -r #{filepath}"
			a = `clamscan -r #{filepath}`
				if a.scan(/Infected files:(.*)Data scanned/m).to_s.strip == 1
					flash[:error] = "Download file has been infected"
					redirect_to(:action=>'formsummary')
				else
					if File.exists? filepath
						send_file filepath
					else
						redirect_to(:action=>'formsummary')
					end
			 end  
		 else
			redirect_to(:action=>'formsummary',:id=>params[:id])
		end
	end

#To upload whitepaper when form is submitted using swf upload

 def flashupload_whitepaper
		@form = Formsubmission.find(params[:id])
		@whitepaper_upload = @form.create_whitepaper_upload(:uploaded_data => params[:Filedata])
		 filelocation = @whitepaper_upload.public_filename
      system "clamscan -r #{filelocation}"
      a = `clamscan -r #{filelocation}`
      if a.scan(/Infected files:(.*)Data scanned/m).to_s.strip == 1
        @whitepaper_upload.destroy
        flash[:error] = "You have uploaded a infected file"
        redirect_to(:controller=>'users',:action=>'edit_form',:id=>@form.office.id,:id1=>@form.office.officeform.id)
      else
        session[:whitepaper_upload] = @whitepaper_upload.id if !@whitepaper_upload.nil?
        render :nothing => true
      end  
 end

#To edit the form submitted by public user , either to submit or submit

 def edit_form
	current_login = (session[:officeadmin_id] ? session[:officeadmin_id] : session[:officeuser_id])
	unless current_login.nil?
	logged_office_admin = Officeadmin.find(current_login) 
	if (logged_office_admin.editform || logged_office_admin.is_admin) #To check if logged in office admin/user has permission to edit the form or not
		session[:is_uploaded] = nil
		@form_submission = Formsubmission.find(params[:id])
		session[:admin_formid] = @form_submission.id if session[:admin_formid].nil?
		check_officeadmin(@form_submission.office_id)
		@custom_fields = CustomField.find(:all,:conditions=>['office_id = ? and active_status = ?',@form_submission.office.id,true])
		 if @form_submission.agency_name.blank? && params[:form_submission].blank?
        @agency_custom_fields = [ ]
      elsif !@form_submission.agency_name.blank? && params[:form_submission].blank? 
        @agency = Agency.find_by_name(@form_submission.agency_name)      
        @agency_custom_fields = AgencyCustomField.find(:all,:conditions=>['agency_id = ? and active_status = ?',@agency.id,true])
      elsif !params[:form_submission][:agency_name].blank?      
        @agency = Agency.find_by_name(params[:form_submission][:agency_name])      
        @agency_custom_fields = AgencyCustomField.find(:all,:conditions=>['agency_id = ? and active_status = ?',@agency.id,true])
      else 
        @agency_custom_fields = [ ]        
      end
		@office_form = @form_submission.office.officeform
		@user = @form_submission.user
     
		@false_ids = [ ]
		@customfields_status = [ ]
		@length_err_false_ids = [ ]
		@agency_false_ids = [ ]
		@agencycustomfields_status = [ ]
		@agency_length_err_false_ids = [ ]
		@agency = Agency.find(:first)
		@agency_account = Agencyaccount.find_by_agency_id(@agency.id)
		set_checkbox_val #When edit_form page is loaded first time,radio buttons like is_lobby_list and is_funding_under_law should retain the vlaue from DB			
      
		return unless request.post?
		session[:is_uploaded] = params[:is_uploaded]  
		@form_submission.attributes = params[:form_submission] #To retain the form values, if any error .
      
		@form_submission.off_form = @office_form             
		checkbox_val #Method called to retain values when any errors in form occurs    
		whitepaper_errflag = false      
		rep_status = true
    customfield_status = true  
    agencycustomfield_status = true  
		if params[:check_yes_no_lobbylist].to_i == 1 && @office_form.representative_section == true
			rep_status = representative_fieldscheck      
		end
  
		if @office_form.white_paper == true && @office_form.project_section == true
			if params[:is_uploaded].blank? || params[:is_uploaded].empty?
				whitepaper_errflag = true    
				flash.now[:error1] = "Upload White Paper for Project"
			end		
		end
		
		customfield_status = customfields_check if !@custom_fields.empty?
		agencycustomfield_status = agencycustomfields_check if !@agency_custom_fields.empty?
		
		if whitepaper_errflag == false
			if rep_status == true && customfield_status == true && agencycustomfield_status == true
				if @form_submission.update_attributes(params[:form_submission])
					@form_submission.update_attributes(:is_draft => 0)
					save_lobby_list #To save the yes / no value of is_lobby_list in representative section
					save_is_funding_under_law #To save the yes / no value of is_funding_under_law in project section
					save_lastupdated_by #To save last edited by / on firstname and lastname 
					#upload_whitepaper #Method to Upload a white paper for Project Section
					save_customfields #If office(s) has custom fields and requires values to be entered by public user and saved in CustomValue table.
					save_agencycustomfields #If office(s) has custom fields and requires values to be entered by public user and saved in CustomValue table.
					redirect_to(:action=>'formsummary',:id=>@form_submission.id)    
				else
					render :action => 'edit_form',:id=>@office_form.id
				end
			else
				render :action => 'edit_form',:id=>@office_form.id
			end
		else
			render :action => 'edit_form',:id=>@office_form.id
		end
	else
		session[:officeadmin_id] = nil
		session[:officeuser_id] = nil
		session[:admin_id] = nil
		redirect_to officelogin_path
	end
	else #unless current_login
		session[:officeadmin_id] = nil
		session[:officeuser_id] = nil
		session[:admin_id] = nil
		redirect_to officelogin_path
	end			
 end

def customfields_check
  @net_customfields = @custom_fields.collect{|x|x.id }
  @active_customfields =  params[:custom_field].collect{|x| (x[0].split('_'))[2].to_i}
  @radio_customfields = @net_customfields - @active_customfields
  @radio_customfields.each do |radio_customfield|
    mandatory = CustomField.find(radio_customfield).is_mandatory
    @false_ids << radio_customfield if mandatory == true
    @customfields_status << false if mandatory == true
  end

   params[:custom_field].each do |customfield|
      split_customfield = customfield[0].split('_')
       customfieldid = split_customfield[2]
       
       cv = CustomValue.find_or_create_by_custom_field_id_and_formsubmission_id(customfieldid,@form_submission.id)
       if cv.update_attributes(:field_value=>customfield[1])
        @customfields_status << true
       else
        @false_ids << customfieldid
        @customfields_status << false 
       end  
      
   end 
    if @customfields_status.include?(false)
      return false
    else
      return true  
    end  
	end
	
	def agencycustomfields_check
  @net_agency_customfields = @agency_custom_fields.collect{|x|x.id }
  @active_agency_customfields =  params[:agency_custom_field].collect{|x| (x[0].split('_'))[2].to_i}
  @radio_agency_customfields = @net_agency_customfields - @active_agency_customfields
  @radio_agency_customfields.each do |radio_agency_customfield|
    mandatory = AgencyCustomField.find(radio_agency_customfield).is_mandatory
    @agency_false_ids << radio_agency_customfield if mandatory == true
    @agencycustomfields_status << false if mandatory == true
  end

   params[:agency_custom_field].each do |agencycustomfield|
      split_agencycustomfield = agencycustomfield[0].split('_')
       agencycustomfieldid = split_agencycustomfield[2]
       
       cv = AgencyCustomValue.find_or_create_by_agency_custom_field_id_and_formsubmission_id(agencycustomfieldid,@form_submission.id)
       if cv.update_attributes(:field_value=>agencycustomfield[1])
        @agencycustomfields_status << true
       else
        @agency_false_ids << agencycustomfieldid
        @agencycustomfields_status << false 
       end  
      
   end 
    if @agencycustomfields_status.include?(false)
      return false
    else
      return true  
    end  
	end
	
	def save_customfields
  unless params[:custom_field].nil?
    params[:custom_field].each do |customfield|
      split_customfield = customfield[0].split('_')
       customfieldid = split_customfield[2]
       cv = CustomValue.find_or_create_by_custom_field_id_and_formsubmission_id(customfieldid,@form_submission.id)
       cv.update_attributes(:field_value=>customfield[1])
    end
    end
  end

  def save_agencycustomfields
  unless params[:agency_custom_field].nil?
    params[:agency_custom_field].each do |agencycustomfield|
      split_agencycustomfield = agencycustomfield[0].split('_')
       agencycustomfieldid = split_agencycustomfield[2]
       cv = AgencyCustomValue.find_or_create_by_agency_custom_field_id_and_formsubmission_id(agencycustomfieldid,@form_submission.id)
       cv.update_attributes(:field_value=>agencycustomfield[1])
    end
    end
  end
	
 def save_lastupdated_by
	current_login = (session[:officeadmin_id] ? session[:officeadmin_id] : session[:officeuser_id])
	logged_office_admin = Officeadmin.find(current_login)
	@form_submission.update_attributes(:lastupdated_by => logged_office_admin.full_name)
 end

  def upload_whitepaper
    unless params[:whitepaper_upload].nil?
      unless params[:whitepaper_upload][:uploaded_data].blank?
        @whitepaper_upload = @form_submission.create_whitepaper_upload(params[:whitepaper_upload])
      end
    end
  end

	def save_lobby_list
		@form_submission.update_attributes(:is_lobby_list => params[:check_yes_no_lobbylist])
	end

	def save_is_funding_under_law
		@form_submission.update_attributes(:is_funding_under_law => params[:check_yes_no_fund_underlaw])
	end

	def set_checkbox_val
			@rep_is_lobbylist = @form_submission.is_lobby_list
			@fund_is_underlaw = @form_submission.is_funding_under_law
	end

  def checkbox_val
    @contact_same_address_as_org = params[:contact_form_same_org_address] #To retain the checkbox value for Contact section
    @sr_contact_same_address_as_org = params[:sr_contact_form_same_org_address] #To retain the checkbox value for Senior Contact section
    @rep_is_lobbylist = params[:check_yes_no_lobbylist]
    @fund_is_underlaw = params[:check_yes_no_fund_underlaw]
  end
 
 def global_users
	params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
	active_inactive_users(params[:admin], Admin, "Admins")
	sort_global_users
end
 
 
	def sort_global_users
		session[:globaladmin_search] = false
		@admin = Admin.paginate(:all,:select=>['id,firstname,lastname,email,city,state,active_status'],:order =>params[:sort],:per_page =>params[:per_page],:page=>params[:page])  
		if request.xml_http_request?
			render :update do |page|      
				page.replace_html "global_usr",:partial=>'global'
			end			
		end
	end


  def new_admin
    @admin = Admin.new
  end


  def create_admin
     @admin = Admin.new(params[:admin])
    if  @admin.save
			@admin = Admin.paginate(:all,:order =>params[:sort],:per_page =>10,:page=>params[:page]) 
			replace_listof_globaladmin_field(txt = 'Created')			
    else
			show_errorsof_globaladmin_field
    end
end

#To display errors of global admin fields when creating or updating

def show_errorsof_globaladmin_field
			render :update do |page|
        for h in @admin.errors
        if !@admin.errors["#{h[0]}"].nil?
              page.show "#{h[0]}_admin"              
              page.replace_html "#{h[0]}_admin","#{h[1]}"
        end          
              page.hide "login_admin" if @admin.errors['login'].nil?
              page.hide "email_admin" if @admin.errors['email'].nil?
              page.hide "password_admin" if @admin.errors['password'].nil?
              page.hide "password_confirmation_admin" if @admin.errors['password_confirmation'].nil?
              page.hide "firstname_admin" if @admin.errors['firstname'].nil?
              page.hide "address1_admin" if @admin.errors['address1'].nil?
              page.hide "city_admin" if @admin.errors['city'].nil?
              page.hide "state_admin" if @admin.errors['state'].nil?
              page.hide "zip_admin" if @admin.errors['zip'].nil?
        end
      end 
end  

#To replace list of global admin fields after creating or updating

  def replace_listof_globaladmin_field(txt)
			render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html 'global_usr',:partial=>'global'
          page.replace_html 'flashnotice',"Admin #{txt} successfully"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
				end
  end 

  def show_admin
	@admin = Admin.find(params[:id])
  end


  def edit_admin
	@admin = Admin.find(params[:id])
  end


  def update_admin
	@admin = Admin.find(params[:id])
	if @admin.update_attributes(params[:admin])
		@admin = Admin.paginate(:all,:order =>params[:sort],:per_page =>10,:page=>params[:page])
			replace_listof_globaladmin_field(txt = 'Updated')
	else
			show_errorsof_globaladmin_field
	end
  end

#To Change the status of an public user /global admin as InActive

def inactive_admin_user_status
	modify_status_for = params[:mod]
	current_model = (params[:tab] == 'Admin' ? Admin : User) 
	current_admin_or_user = current_model.find(params[:id])
	current_admin_or_user.update_attributes(:active_status => false)	 
		render :update do |page|
      page.hide "#{modify_status_for}activestatus_#{current_admin_or_user.id}"  
      page.show "#{modify_status_for}inactivestatus_#{current_admin_or_user.id}"  
      page.show 'flashnotice'
      page.replace_html 'flashnotice',"#{current_model} Deactivated successfully"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end
end	

#To Change the status of an public user /global admin as Active

def active_admin_user_status
	modify_status_for = params[:mod]
	current_model = (params[:tab] == 'Admin' ? Admin : User) 
	current_admin_or_user = current_model.find(params[:id])
	current_admin_or_user.update_attributes(:active_status => true)	 
		render :update do |page|
      page.hide "#{modify_status_for}inactivestatus_#{current_admin_or_user.id}"  
      page.show "#{modify_status_for}activestatus_#{current_admin_or_user.id}"  
      page.show 'flashnotice'
      page.replace_html 'flashnotice',"#{current_model} Activated successfully"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end
end	

  def generate_csv_for_global_admin_or_public_user(var)
		report = StringIO.new
		
		CSV::Writer.generate(report, ',') do |csv|
		csv << %w(Name
		Email
		Address
		City
		State
		Zip
		Phone
		Fax
		Status
		)
		
		var.each do |adm_or_usr|
						
		status = (adm_or_usr.active_status == true ? "Active" : "Inactive")
		
		csv << [adm_or_usr.fullname,
		adm_or_usr.email,
		adm_or_usr.address,
		adm_or_usr.city,
		adm_or_usr.state,
		adm_or_usr.zip,
		adm_or_usr.phone,
		adm_or_usr.fax,
		status]
		end
		end
		report
	end

  def export_admin
		var = export(params[:admin], session[:globaladmin_search], Admin, params[:search_txt].to_s)
		report = generate_csv_for_global_admin_or_public_user(var)
		report.rewind
		send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'admin.csv')
	end
	
	def admin_search
		params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
		session[:globaladmin_search] = true
		
		conditions = "(firstname like '%%"+params[:search_txt].to_s+"%%') or (lastname like '%%"+params[:search_txt].to_s+"%%') or (email like '%%"+params[:search_txt].to_s+"%%') or (city like '%%"+params[:search_txt].to_s+"%%') or (state like '%%"+params[:search_txt].to_s+"%%')" if !params[:search_txt].blank?
		
		options = {:per_page => params[:per_page],:page => params[:page],:order => params[:sort],:conditions => conditions}
		
		if !params[:search_txt].blank?
		@admin = Admin.paginate(options)          
			if @admin.empty?
				options[:conditions] = nil
			@admin = Admin.paginate(options)
				adminsearch(flash_error='flasherror',search_result_error="Your Search produced no results for #{params[:search_txt]}")
			else
				adminsearch(flash_notice='flashnotice',search_result_notice="Your Search results for #{params[:search_txt]}")
			end
		else
			@admin = Admin.paginate(options)
			adminsearch(flash_error='flasherror',search_result_error="Provide search text")
		end
  end

	def adminsearch(flash,search_result)
			render :update do |page|
						page.replace_html "global_usr",:partial=>'global'
						page.show(flash) if params[:sort].nil?
						page.replace_html flash, search_result if params[:sort].nil?
						page.visual_effect :fade,flash,:duration => 1.5 if params[:sort].nil?
			end	
	end

  def user_search
		params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
		session[:publicuser_search] = true
		
		conditions = "(firstname like '%%"+params[:search_txt].to_s+"%%') or (lastname like '%%"+params[:search_txt].to_s+"%%') or (email like '%%"+params[:search_txt].to_s+"%%') or (city like '%%"+params[:search_txt].to_s+"%%') or (state like '%%"+params[:search_txt].to_s+"%%')" if !params[:search_txt].blank?
		
		options = {:per_page => params[:per_page],:page => params[:page],:order => params[:sort],:conditions => conditions}
		
		if !params[:search_txt].blank?
			@users = User.paginate(options)          
			if @users.empty?
				options[:conditions] = nil
			 @users = User.paginate(options)
				usersearch(flash_error='flasherror',search_result_error="Your Search produced no results for #{params[:search_txt]}")
			else
				usersearch(flash_notice='flashnotice',search_result_notice="Your Search results for #{params[:search_txt]}")
			end
		else
			@users = User.paginate(options)
			usersearch(flash_error='flasherror',search_result_error="Provide search text")
		end
  end
	
	def usersearch(flash,search_result)
		render :update do |page|
					page.replace_html "users_list",:partial=>'users_list'
					page.show(flash) if params[:sort].nil?
					page.replace_html flash, search_result if params[:sort].nil?
					page.visual_effect :fade,flash,:duration => 1.5 if params[:sort].nil?
		end	
end


#Method called for Auto Save the form values through javascript
  def update_formvalues
    @form_submission = Formsubmission.find(params[:form_submission_val])
    @form_submission.update_attributes(params[:form_submission])
    @office_form = @form_submission.office.officeform
    render :nothing => true
  end


	def export(prms, session, current_model, prms_search)
		if !prms.nil?
			var = current_model.find(:all,:conditions=>['id in (?)',prms])
		elsif session == true
			var = current_model.find(:all,:conditions=>["(firstname like '%%"+prms_search+"%%') or (lastname like '%%"+prms_search+"%%') or (email like '%%"+prms_search+"%%') or (city like '%%"+prms_search+"%%') or (state like '%%"+prms_search+"%%')"])	
			var = current_model.find(:all)	if var.empty?
		else
			var = current_model.find(:all)
		end  
		return var
	end

#To export the list of Admins as PDF
	def export_adminpdf
		var = export(params[:admin], session[:globaladmin_search], Admin, params[:search_txt].to_s)
		res =  Admin.export_adminpdf(var)  
		send_data res.render, :filename => "List of Admins", :type => "application/pdf" 
	end

#To export the list of Public Users as PDF
	def export_userpdf
		var = export(params[:user], session[:publicuser_search], User, params[:search_txt].to_s)
		res = Admin.export_userpdf(var)  
		send_data res.render, :filename => 'List of Public Users', :type => "application/pdf" 
	end
  
#To export the Form summary details as PDF
	def export_summarypdf
		res = Admin.export_summarypdf(params[:id])
		send_data res.render, :filename => 'Form summary Details', :type => "application/pdf" 
	end


  def representative_fieldscheck

    status = true  
    if params[:form_submission][:representative_firstname].blank?
        @fname_blankerror = "Please provide FirstName"
		status = false
    end
	
	if params[:form_submission][:representative_firmname].blank?
        @firmname_blankerror = "Please provide FirmName"
		status = false
    end
    
	if params[:form_submission][:representative_email].blank?
        @email_blankerror = "Please provide Email"
		status = false
	end
	unless params[:form_submission][:representative_email].blank?
	   unless params[:form_submission][:representative_email] =~ /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i
             @email_blankerror = "Please provide valid Email <br/>"
			 	status = false
	   end
    end
 
	if params[:form_submission][:representative_address1].blank?
        @address_blankerror = "Please provide Address1"
		status = false
    end
    
	if params[:form_submission][:representative_city].blank?
        @city_blankerror = "Please provide City"
		status = false
    end

    if params[:form_submission][:representative_state].blank?
        @state_blankerror = "Please provide State"
		status = false
    end

    if params[:form_submission][:representative_zip].blank?
        @zip_blankerror = "Please provide Zip"
		status = false
	end
	
	 unless params[:form_submission][:representative_zip].blank?
       unless params[:form_submission][:representative_zip] =~ /^\d{5}$/i
			@zip_formaterror = "Please provide Zip code as digits <br/>"
				status = false
	   end
	end
		 
    if params[:form_submission][:representative_phone].blank?
        @phone_blankerror = "Please provide Phone"
		status = false
	end
	
	unless params[:form_submission][:representative_phone].blank?
	  unless params[:form_submission][:representative_phone] =~/^[2-9]\d{2}-\d{3}-\d{4}$/i
            @phone_blankerror = "Please provide valid Phone Number <br/>"
				status = false
	  end
	end
	
	return status
  end

#To Export the list of Submitted forms in an OfficeAdmin and Global Admin as a CSV file

  def export_csvforms
	  if session[:office_id] && (session[:officeadmin_id] || session[:officeuser_id])
		if !params[:formslist].nil?  
		@list_forms = Formsubmission.find(:all,:conditions =>['id in (?) and office_id = ? and is_draft = ? and submitted_date is not NULL',params[:formslist],session[:office_id],false])	
		else	
		@list_forms = Formsubmission.find(:all,:conditions =>['office_id = ? and is_draft = ? and submitted_date is not NULL',session[:office_id],false])
		end
	  else
		if !params[:formslist].nil?  
		@list_forms = Formsubmission.find(:all,:conditions =>['id in (?) and office_id = ?',params[:formslist],params[:id]])	
		else			
		@list_forms = Formsubmission.find(:all,:conditions =>['office_id = ?',params[:id]])
		end
	  end
    
		report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
      csv << FORM_TITLES        
      @list_forms.each do |list_form|
        csv << values(list_form)
      end
    end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'list_forms.csv')
	end
	
	
	def export_user
		var = export(params[:user], session[:publicuser_search], User, params[:search_txt].to_s)
		report = generate_csv_for_global_admin_or_public_user(var)
		report.rewind
		send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'user.csv')
	end
	
	def export_user_csvforms
		if !params[:formslist].nil?  
		@list_forms = Formsubmission.find(:all,:conditions =>['id in (?) and user_id = ?',params[:formslist],params[:id]])	
		elsif session[:users_formslistsearch] ==	true	
				@list_forms = Formsubmission.find(:all,:conditions =>["user_id = ? and ((offices.name like '%%"+params[:search_txt].to_s+"%%') or (org_name like '%%"+params[:search_txt].to_s+"%%') or (project_description like '%%"+params[:search_txt].to_s+"%%'))",params[:id]],:include=>[:office])
		@list_forms = Formsubmission.find(:all,:conditions =>['user_id = ?',params[:id]]) if @list_forms.empty?
		else
			@list_forms = Formsubmission.find(:all,:conditions =>['user_id = ?',params[:id]])
		end
	  
		report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
      csv << FORM_TITLES.unshift("OfficeName")
        
      @list_forms.each do |list_form|
        csv << values(list_form).unshift(list_form.office.name)
      end
    end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'list_forms.csv')
  end

	
	def export_pdfforms
	  if session[:office_id] && (session[:officeadmin_id] || session[:officeuser_id])
		if !params[:formslist].nil?    
		@list_forms = Formsubmission.find(:all,:conditions =>['id in (?) and office_id = ? and is_draft = ? and submitted_date is not NULL',params[:formslist],session[:office_id],false])	
		else	
		@list_forms = Formsubmission.find(:all,:conditions =>['office_id = ? and is_draft = ? and submitted_date is not NULL',session[:office_id],false])
		end
	  else
		if !params[:formslist].nil?    
		@list_forms = Formsubmission.find(:all,:conditions =>['id in (?) and office_id = ?',params[:formslist],params[:id]])	
		else			
		@list_forms = Formsubmission.find(:all,:conditions =>['office_id = ?',params[:id]])
		end
	  end	  
    res =  Office.export_list_forms_pdf(@list_forms)
    send_data res.render, :filename => 'List of Submitted Forms', :type => "application/pdf" 
 end

def exportpdf_formsummary
	formsubmission_id = params[:id]
	res = Admin.export_summarypdf(formsubmission_id,2)
	send_data res.render, :filename => 'Form Summary.pdf', :type => "application/pdf" 
end

	def select_user
		if params[:selected_user].nil? || params[:selected_user] == "OfficeAdmins"
			@select_type_name = "officeadmin[]"
			@select_users = Officeadmin.find(:all,:conditions=>['is_admin = 1'])
		elsif params[:selected_user] == "OfficeUsers"	
			@select_type_name = "officeuser[]"
			@select_users = Officeadmin.find(:all,:conditions=>['is_admin = 0'])
		else
			@select_type_name = "publicuser[]"
			@select_users = User.find(:all,:conditions=>['email != ?',""])
		end	
		render :update do |page|
			page.replace_html 'list_users', :partial=>'user_list_dropdown' , :object => @select_users, :local=>{:name=>@select_type_name}
		end	
	end	

	def email_notifications
		@select_type_name = "officeadmin[]"
		@select_users = Officeadmin.find(:all,:conditions=>['is_admin = 1'])
		return unless request.post?
		if !params[:officeadmin].nil? && !params[:officeadmin].empty?
			if params[:officeadmin].include?("0")
				params[:officeadmin] = Officeadmin.find(:all,:conditions=>['is_admin = 1']).collect{|x| x.id}
			end	
			for user_id in params[:officeadmin]
				user = Officeadmin.find(user_id) 
				str = params[:email_notification][:message]
				str1 = str.gsub('[firstname]',user.firstname)
				str2 =  str1.gsub('[email]',user.email)
				#puts str2.inspect
				x= EmailNotification.create(:email=>user.email,:receiver_type=>"Officeadmin",:receiver_id=>user.id,:subject=>params[:email_notification][:subject],:message=>str2)
				flash.now[:notice] = "Successfully saved"
		 end
		elsif !params[:officeuser].nil? && !params[:officeuser].empty?
			if params[:officeuser].include?("0")
				params[:officeuser] = Officeadmin.find(:all,:conditions=>['is_admin = 0']).collect{|x| x.id}
			end	
			for user_id in params[:officeuser]
				user = Officeadmin.find(user_id) 
				str = params[:email_notification][:message]
				str1 = str.gsub('[firstname]',user.firstname)
				str2 =  str1.gsub('[email]',user.email)
				#puts str2.inspect
				x= EmailNotification.create(:email=>user.email,:receiver_type=>"Officeadmin",:receiver_id=>user.id,:subject=>params[:email_notification][:subject],:message=>str2)
				flash.now[:notice] = "Successfully saved"
		  end
		elsif !params[:publicuser].nil? && !params[:publicuser].empty?
			if params[:publicuser].include?("0")
				params[:publicuser] = User.find(:all,:conditions=>['email != ?',""]).collect{|x| x.id}
			end	
			for user_id in params[:publicuser]
				user = User.find(user_id) 
				str = params[:email_notification][:message]
				str1 = str.gsub('[firstname]',user.firstname)
				str2 =  str1.gsub('[email]',user.email)
				#puts str2.inspect
				x= EmailNotification.create(:email=>user.email,:receiver_type=>"User",:receiver_id=>user.id,:subject=>params[:email_notification][:subject],:message=>str2)
				flash.now[:notice] = "Successfully saved"
		  end
		else
     flash.now[:error]	= "Select send mail to option"		 
		end	
	end	
	
	#To Update Agency CustomFields , Based on selection of Agency . Called through Javascript
  def change_agency_customfields
    @form_submission = session[:status]== 'user' ? Formsubmission.find(session[:formid]) : Formsubmission.find(session[:admin_formid]) 
    @agency = Agency.find_by_name(params[:aname])
    @agency_custom_fields = @agency.agency_custom_fields.find(:all,:conditions=>['agency_id = ? and active_status = ?',@agency.id,true])
    @agency_false_ids = [ ]
    @agency_length_err_false_ids = [ ]
		if !@agency_custom_fields.empty? || !@agency_custom_fields.blank?
			render :update do |page|
				page.replace_html "list_agency_customfields",:partial=>'users/list_agency_customfields'
			end
		else
			render :update do |page|
				page.reload()
			end
		end	
  end
end