class AgencyController < ApplicationController
  before_filter :check_admin_officeadmin
  layout 'newadmin',:except=>[:show,:edit,:new,:account,:edit_account,:show_account,:show_subaccount,:edit_subaccount]
  protect_from_forgery :except=>[:new,:show,:edit,:list,:agency_search,:account,:show_account,:edit_account,:account_list,:agencyaccount_search,:show_subaccount,:edit_subaccount,:subaccount_list,:agencyfield_update]
  require 'csv'
  
  def index
  end


  def new
    @agency = Agency.new
  end


  def create
    @agency = Agency.new(params[:agency])
	if  @agency.save
    add_customfields
    @agencies = Agency.paginate(:all,:order =>params[:sort],:per_page =>10,:page=>params[:page],:order=>'created_at desc')
	render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html 'agency_sort',:partial=>'list_agency'
          page.replace_html 'flashnotice',"New Agency Is Created"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
    else
        render :update do |page|
       
        for h in @agency.errors
        if !@agency.errors["#{h[0]}"].nil?
              page.show "#{h[0]}_agency"              
              page.replace_html "#{h[0]}_agency","#{h[1]}"
        end          
              page.hide "name_agency" if @agency.errors['name'].nil?
        end
        end
    end
  end

  def show
    @agency = Agency.find(params[:id])
  end	  

  def add_customfields
	  1.upto(15) {|i|
 	  @custom_field = AgencyCustomField.create(:agency_id=>@agency.id,:field_name=> "custom#{i}",:field_type=>'Textbox',:active_status=>0 )
	  }
  end

#To update Agency field name using In Place Editor

  def agencyfield_update
    customfield = AgencyCustomField.find(params[:id])
    customfield.update_attributes(:field_name=>params[:value])
    render :text => customfield.field_name
  end


 # Manage custom fields form
 
  def manage_fields
    @err =[]
    @agency = Agency.find(params[:id])
    @agency_custom_fields = AgencyCustomField.find(:all,:conditions=>['agency_id = ?',@agency.id])    
    check_login
    return unless request.post?
    params[:agency_field].each do |agencyfield|
    split_agencyfield = agencyfield[0].split('_')
    agencyfieldid = split_agencyfield[2]
    o = AgencyCustomField.find(agencyfieldid)
      if o.update_attributes(:active_status=>params["agency_field"]["active_status_#{agencyfieldid}"],:field_type=>params["agency_field"]["field_type_#{agencyfieldid}"],:is_mandatory=>params["agency_field"]["is_mandatory_#{agencyfieldid}"],:is_length_enabled=>params["agency_field"]["is_enabled_#{agencyfieldid}"],:max_length=>params["agency_field"]["max_length_#{agencyfieldid}"])
      else
      @err << "#{o.id}"
      end
    end
    if @err.empty?
      flash[:notice] = "Agency Custom Fields has been updated"
      redirect_to(:controller=>'agency',:action=>'manage_fields')
    else
			render :action=>'manage_fields'
	end
  end



  def list
    params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])
	
    if !params["inactive_all.x"].nil?         
     if !params[:agencylist].nil?
     params[:agencylist].each {|x|          
     inactive_agency = Agency.find(x)
     inactive_agency.update_attributes(:delete_status=>false)
     flash[:notice] ="The Selected Agencies Are Inactivated"
    }           
     end
    end
    if !params["active_all.x"].nil?   
     if !params[:agencylist].nil?
     params[:agencylist].each {|x|
     active_agency = Agency.find(x)   
     active_agency.update_attributes(:delete_status=>true)
     flash[:notice] ="The Selected Agencies Are Activated"
    }            
     end
 end
sort_agency

end
 
 
 def sort_agency
    session[:agen_search] = false
  @agencies = Agency.paginate(:all,:order =>params[:sort],:per_page =>params[:per_page],:page=>params[:page],:order=>'created_at desc')
if request.xml_http_request?
	render :update do |page|
		page.replace_html"agency_sort",:partial=>"list_agency"
	end
	end
end

  
  def edit
    @agency = Agency.find(params[:id])
  end


  def update
    @agency = Agency.find(params[:id])
    if @agency.update_attributes(params[:agency])
      @agencies = Agency.paginate(:all,:order =>params[:sort],:per_page =>10,:page=>params[:page])
	    render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html 'agency_sort',:partial=>'list_agency'
          page.replace_html 'flashnotice',"Agency Updated"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
    else
        render :update do |page|
       
        for h in @agency.errors
        if !@agency.errors["#{h[0]}"].nil?
              page.show "#{h[0]}_agency"              
              page.replace_html "#{h[0]}_agency","#{h[1]}"
        end          
              page.hide "name_agency" if @agency.errors['name'].nil?
        end
        end
    end
  end


  def delete
    @agency = Agency.find(params[:id])
    @agency.update_attributes(:delete_status => 1)	 
        render :update do |page|
      page.hide "agencyinactivestatus_#{@agency.id}"  
      page.show "agencyactivestatus_#{@agency.id}" 
      page.show 'flashnotice'      
      page.replace_html 'flashnotice',"Agency Activated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end	
  end	  


  def active
    @agency = Agency.find(params[:id])
    @agency.update_attributes(:delete_status => 0)	 
	    render :update do |page|
      page.hide "agencyactivestatus_#{@agency.id}"  
      page.show "agencyinactivestatus_#{@agency.id}"  
      page.show 'flashnotice'
      page.replace_html 'flashnotice',"Agency Inactivated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
  end
end

  def account
	@agency = Agency.find(params[:id])
    @agency_account = Agencyaccount.find(:all,:conditions=>['agency_id = ? and parent_id = 0',params[:id]] )
    @agencyaccount = Agencyaccount.new
  end


  def manage_account
	#@agency_account = Agencyaccount.find(:all,:conditions=>['agency_id = ?',params[:id]] )
    @agency = Agency.find(params[:id])
    @agencyaccount = Agencyaccount.new(params[:agencyaccount])
	if @agencyaccount.valid?
    if params[:agencyaccount][:parent_id].blank?
		@agency.agencyaccounts.create(:name =>params[:agencyaccount][:name],:parent_id=>0,:agency_id=>params[:id])
	else
		@agency.agencyaccounts.create(:name =>params[:agencyaccount][:name],:parent_id=>params[:agencyaccount][:parent_id],:agency_id=>params[:id])
  end
  		   @agency_account = Agencyaccount.paginate(:all,:per_page =>10,:page=>params[:page],:conditions=>['agency_id = ? and parent_id = 0',params[:id]],:order =>params[:sort] )
      render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html "agencyaccount_sort",:partial=>"list_agency_account"
          page.replace_html 'flashnotice',"Agency Account Created"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
    else
   		render :update do |page|
			for h in @agencyaccount.errors
        if !@agencyaccount.errors["#{h[0]}"].nil?
              page.show "#{h[0]}_agencyaccount"              
              page.replace_html "#{h[0]}_agencyaccount","#{h[1]}"
        end          
              page.hide "name_agencyaccount" if @agencyaccount.errors['name'].nil?
        end
			end 
    end
  end 
  
  def agencysearch ( flash, search_result)
		render :update do |page|
					page.replace_html "agency_sort",:partial=>'list_agency'
					page.show(flash) if params[:sort].nil?
					page.replace_html flash, search_result if params[:sort].nil?
					page.visual_effect :fade,flash,:duration => 1.5 if params[:sort].nil?
				end	
	end
  
  def agency_search
    params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
    session[:agen_search] = true
    
    conditions = "(name like '%%"+params[:search_txt].to_s+"%%')"  if !params[:search_txt].blank?
    options = {:per_page => params[:per_page],:page => params[:page],:order => params[:sort],:conditions => conditions}
    
		if !params[:search_txt].blank?
       @agencies = Agency.paginate(options)
		 
			if @agencies.empty?
        options[:conditions] = nil
        @agencies = Agency.paginate(options)
        agencysearch(flash_error='flasherror',search_result_error="Your Search produced no results for #{params[:search_txt]}")
      else
        agencysearch(flash_notice='flashnotice',search_result_notice="Your Search results for #{params[:search_txt]}")
      end
    else
			@agencies = Agency.paginate(options)
      agencysearch(flash_error='flasherror',search_result_error="Provide search text")
      
    end
  end



  def account_list
    session[:agencyaccountlist_search] = false
    if !params["inactive_all.x"].nil?         
     if !params[:agencyaccountlist].nil?
     params[:agencyaccountlist].each {|x|          
     inactive_agency = Agencyaccount.find(x)
     inactive_agency.update_attributes(:delete_status=>false)
     flash[:notice] ="The Selected Agencies Are Inactivated"
     }           
     end
   end
   if !params["active_all.x"].nil?   
    if !params[:agencyaccountlist].nil?
    params[:agencyaccountlist].each {|x|
    active_agency = Agencyaccount.find(x)   
    active_agency.update_attributes(:delete_status=>true)
    flash[:notice] ="The Selected Agencies Are Activated"
    }            
    end
   end
sort_account
end

 def sort_account
      params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])
    @agency = Agency.find(params[:id])
    @agencyaccounts = Agencyaccount.paginate(:all,:per_page =>params[:per_page],:page=>params[:page],:conditions=>['agency_id = ? and parent_id = 0',params[:id]],:order =>params[:sort] )
if request.xml_http_request?
	render :update do |page|
		page.replace_html"agencyaccount_sort",:partial=>"list_agency_account"
	end
	end
end

 def agencyaccount_search
   @agency = Agency.find(params[:id])
   session[:agencyaccountlist_search] = true
    params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
    
    conditions =  "agency_id = #{params[:id]} and parent_id = 0 and (name like '%%"+params[:search_txt].to_s+"%%')"  if !params[:search_txt].blank?
    
    options = {:per_page => params[:per_page],:page => params[:page],:order => params[:sort],:conditions => conditions}
    
		if !params[:search_txt].blank?
       @agencyaccounts = Agencyaccount.paginate(options)
		 
			if @agencyaccounts.empty?
       options[:conditions] = "agency_id = #{params[:id]} and parent_id = 0"
       @agencyaccounts = Agencyaccount.paginate(options)
       agencyaccountsearch(flash_error='flasherror',search_result_error="Your Search produced no results for #{params[:search_txt]}")
      else
        agencyaccountsearch(flash_notice='flashnotice',search_result_notice="Your Search results for #{params[:search_txt]}")
      end
		else
      options[:conditions] = "agency_id = #{params[:id]} and parent_id = 0"
			@agencyaccounts = Agencyaccount.paginate(options)
      agencyaccountsearch(flash_error='flasherror',search_result_error="Provide search text")
		end
  end
  
  def agencyaccountsearch(flash,search_result)
		render :update do |page|
					page.replace_html "agencyaccount_sort",:partial=>'list_agency_account'
					page.show(flash) if params[:sort].nil?
					page.replace_html flash, search_result if params[:sort].nil?
					page.visual_effect :fade,flash,:duration => 1.5 if params[:sort].nil?
		end	
end


def subaccount_list
    if !params["inactive_all.x"].nil?         
     if !params[:agencysubaccountlist].nil?
     params[:agencysubaccountlist].each {|x|          
     inactive_agency = Agencyaccount.find(x)
     inactive_agency.update_attributes(:delete_status=>false)
     flash[:notice] ="The Selected Agencies Are Inactivated"
     }           
     end
   end
   if !params["active_all.x"].nil?   
    if !params[:agencysubaccountlist].nil?
    params[:agencysubaccountlist].each {|x|
    active_agency = Agencyaccount.find(x)   
    active_agency.update_attributes(:delete_status=>true)
    flash[:notice] ="The Selected Agencies Are Activated"
    }            
    end
   end
sort_subaccount
end

 def sort_subaccount
   params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])
    @agency_account = Agencyaccount.find(params[:id])	 
    @agency_subaccount = Agencyaccount.paginate(:all,:order=>params[:sort],:per_page =>params[:per_page],:page=>params[:page],:conditions=>['parent_id = ?',params[:id]] )
if request.xml_http_request?
	render :update do |page|
		page.replace_html"agencysubaccount_sort",:partial=>"list_agency_subaccount"
	end
	end
end


  def show_account
    @agency_account = Agencyaccount.find(params[:id])
  end	

  def show_subaccount
    @agency_account = Agencyaccount.find(params[:id])
  end
  
  def edit_account
    @agencyaccount = Agencyaccount.find(params[:id])
  end


  def update_account
    @agency_account = Agencyaccount.find(params[:id])
    if @agency_account.update_attributes(params[:agencyaccount])
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html 'flashnotice',"Agency Account is Updated"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
   else
    render :update do |page|
			for h in @agency_account.errors
        if !@agency_account.errors["#{h[0]}"].nil?
              page.show "#{h[0]}_agency_account"              
              page.replace_html "#{h[0]}_agency_account","#{h[1]}"
        end          
              page.hide "name_agency_account" if @agency_account.errors['name'].nil?
        end
			end 
    end
  end

  def edit_subaccount
    @agencyaccount = Agencyaccount.find(params[:id])
  end


  def update_subaccount
    @agency_account = Agencyaccount.find(params[:id])
    if @agency_account.update_attributes(params[:agencyaccount])
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html 'flashnotice',"Agency Sub Account is Updated"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
    else
    render :update do |page|
			for h in @agency_account.errors
        if !@agency_account.errors["#{h[0]}"].nil?
              page.show "#{h[0]}_agency_account"              
              page.replace_html "#{h[0]}_agency_account","#{h[1]}"
        end          
              page.hide "name_agency_account" if @agency_account.errors['name'].nil?
        end
			end
    end
  end

  def inactive_account
    @agency = Agencyaccount.find(params[:ide])
    @agency.update_attributes(:delete_status => 1)	 
    render :update do |page|
      page.hide "agencyinactivestatus_#{@agency.id}"  
      page.show "agencyactivestatus_#{@agency.id}" 
      page.show 'flashnotice'      
      page.replace_html 'flashnotice',"Agency Account Activated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end	
  end	  


  def active_account
    @agency = Agencyaccount.find(params[:ide])
    @agency.update_attributes(:delete_status => 0)	 
    render :update do |page|
      page.hide "agencyactivestatus_#{@agency.id}"  
      page.show "agencyinactivestatus_#{@agency.id}"  
      page.show 'flashnotice'
      page.replace_html 'flashnotice',"Agency Account Inactivated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end
  end

  def inactive_subaccount
    @agency = Agencyaccount.find(params[:ide])
    @agency.update_attributes(:delete_status => 1)	 
    render :update do |page|
      page.hide "agencysubaccountinactivestatus_#{@agency.id}"  
      page.show "agencysubaccountactivestatus_#{@agency.id}" 
      page.show 'flashnotice'      
      page.replace_html 'flashnotice',"Agency Sub Account Activated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end	
  end	  


  def active_subaccount
    @agency = Agencyaccount.find(params[:ide])
    @agency.update_attributes(:delete_status => 0)	 
    render :update do |page|
      page.hide "agencysubaccountactivestatus_#{@agency.id}"  
      page.show "agencysubaccountinactivestatus_#{@agency.id}"  
      page.show 'flashnotice'
      page.replace_html 'flashnotice',"Agency Sub Account Inactivated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end
  end


  def exportcsv_agency
    if !params[:agencylist].nil?
    @agency = Agency.find(:all,:conditions=>['id in (?)',params[:agencylist]])
    elsif session[:agen_search] == true
      @agency = Agency.find(:all,:conditions=>["(name like '%%"+params[:search_txt].to_s+"%%')"])
      @agency = Agency.find(:all) if @agency.empty?	 
    
    else	
    @agency = Agency.find(:all)
    end
    
    report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
      csv << %w(Name
		Status
		)
        
      @agency.each do |agency|
          
      	status = (agency.delete_status == true ? "Active" : "Inactive")

          
        csv << [agency.name,
		status]
      end
    end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'agency.csv')

  end

  def exportpdf_agency
    if !params[:agencylist].nil?
    @agency = Agency.find(:all,:conditions=>['id in (?)',params[:agencylist]])	 
    elsif session[:agen_search] == true
      @agency = Agency.find(:all,:conditions=>["(name like '%%"+params[:search_txt].to_s+"%%')"])
      @agency = Agency.find(:all) if @agency.empty?	     
    else	
    @agency = Agency.find(:all)
    end   
  
	res =  Agency.export_agencypdf(@agency)  
	send_data res.render, :filename => 'List of Agencies.pdf', :type => "application/pdf" 
 end

  def exportcsv_agency_account
  @agency = Agency.find(params[:id])
  if !params[:agencyaccountlist].nil?
  @agency_account = Agencyaccount.find(:all,:conditions=>['id in (?) and agency_id = ? and parent_id = 0',params[:agencyaccountlist],params[:id]])
  elsif session[:agencyaccountlist_search] == true
    @agency_account = Agencyaccount.find(:all,:conditions=>["parent_id = 0 and (name like '%%"+params[:search_txt].to_s+"%%')"])
    @agency_account = Agencyaccount.find(:all,:conditions =>['agency_id = ? and parent_id = 0',params[:id]]) if @agency_account.empty?
    
  else
  @agency_account = Agencyaccount.find(:all,:conditions=>['agency_id = ? and parent_id = 0',params[:id]])	  
  end
  
    report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
      csv << %w(AgencyAccountName
		Status
		)
        
      @agency_account.each do |agency|
          
      	status = (agency.delete_status == true ? "Active" : "Inactive")

          parent_name = (agency.parent.name  if !agency.parent.nil? )
        csv << [agency.name,status]
      end
    end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'agency_account.csv')

  end
  
def exportpdf_agency_account
  @agency = Agency.find(params[:id])
  if !params[:agencyaccountlist].nil?
    @agency_account = Agencyaccount.find(:all,:conditions=>['id in (?) and agency_id = ? and parent_id = 0',params[:agencyaccountlist],params[:id]])
    elsif session[:agencyaccountlist_search] == true
    @agency_account = Agencyaccount.find(:all,:conditions=>["parent_id = 0 and (name like '%%"+params[:search_txt].to_s+"%%')"])
    @agency_account = Agencyaccount.find(:all,:conditions =>['agency_id = ? and parent_id = 0',params[:id]]) if @agency_account.empty?
  else
    @agency_account = Agencyaccount.find(:all,:conditions=>['agency_id = ? and parent_id = 0',params[:id]])	  
  end

  res =  Agencyaccount.export_agencyaccountpdf(@agency_account,@agency)  
  send_data res.render, :filename => 'List of Agency Accounts.pdf', :type => "application/pdf" 
end  

  def exportcsv_agency_subaccount
  @agency_account = Agencyaccount.find(params[:id])
  if !params[:agencysubaccountlist].nil?
  @agency_account = Agencyaccount.find(:all,:conditions=>['id in (?) and parent_id = ?',params[:agencysubaccountlist],params[:id]])
  else
  @agency_account = Agencyaccount.find(:all,:conditions=>['parent_id = ?',params[:id]])	  
  end
  
    report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
      csv << %w(AgencyAccountName
		Status
		)
        
      @agency_account.each do |agency|
          
      	status = (agency.delete_status == true ? "Active" : "Inactive")

          parent_name = (agency.parent.name  if !agency.parent.nil? )
        csv << [agency.name,status]
      end
    end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'agency_subaccount.csv')

  end

def exportpdf_agency_subaccount
  @agency_account = Agencyaccount.find(params[:id])
  if !params[:agencysubaccountlist].nil?
  @agency_subaccount = Agencyaccount.find(:all,:conditions=>['id in (?) and parent_id = ?',params[:agencysubaccountlist],params[:id]])
  else
  @agency_subaccount = Agencyaccount.find(:all,:conditions=>['parent_id = ?',params[:id]])	  
  end

  res =  Agencyaccount.export_agencysubaccountpdf(@agency_subaccount,@agency_account)  
  send_data res.render, :filename => 'List of Agency SubAccounts.pdf', :type => "application/pdf" 
end  

def assign_agencycustomfields
	agencyids = AgencyCustomField.find(:all).collect{|x| x.agency_id}.uniq
  unless agencyids.empty?
	agencies = Agency.find(:all,:conditions=>['id not in (?)',agencyids])
  else
  agencies = Agency.find(:all)  
  end
	for agency in agencies
	  1.upto(15) {|i|
 	  @custom_field = AgencyCustomField.create(:agency_id=>agency.id,:field_name=> "custom#{i}",:field_type=>'Textbox',:active_status=>0 )
	  }
	  end
  end
  
def help_text
   @agency = Agency.find(params[:id])
   return unless request.post?
   @agency = Agency.find(params[:id])
   if !params[:agency][:help_text].empty? || !params[:agency][:help_text].blank?
   @agency.update_attributes(:help_text=>params[:agency][:help_text])
   flash.now[:notice] = "Successfully updated."
   else
     flash.now[:error] = "Form Help text cannot be blank"
   end  
end  

end