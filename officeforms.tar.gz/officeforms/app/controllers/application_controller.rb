# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  helper :all # include all helpers, all the time
  include AuthenticatedSystem
  include SimpleCaptcha::ControllerHelpers
  include ExceptionNotifiable
  # See ActionController::RequestForgeryProtection for details
  # Uncomment the :secret if you're not using the cookie session store
  protect_from_forgery :secret => '092d65515f938d69f97fcda2196f4e7b'
  $show_pages = [
  ['10', 10],
  ['50', 50],
  ['100',100]
  ]
  
  

#To check if User has logged_in and also logged_in User is an authorized User

  def authorizeduser
    unless session[:user_id]
      session[:return_to] = request.request_uri
      flash[:notice] = "Please log in"
      redirect_to login_path
    end
  end   


#To check if Admin has logged_in and also logged_in Admin is an authorized Admin

  def authorizedadmin
    unless session[:admin_id]
      reset_session
      flash[:notice] = "Please log in"
      redirect_to(:controller=>'admin',:action=>'login')
    end
  end   


#To check if Office Admin has logged_in and also logged_in Office Admin is an authorized Office Admin

  def authorized_officeadmin
    unless session[:officeadmin_id] || session[:office_id]
      reset_session
      flash[:notice] = "Please log in"
      redirect_to(:controller=>'office_admin',:action=>'login')
    end
  end 

#To check if Office Admin has logged_in and also logged_in Office Admin is an authorized Office Admin

  def authorized_officeuser
    unless session[:officeuser_id] || session[:office_id]
      reset_session
      flash[:notice] = "Please log in"
      redirect_to(:controller=>'office_admin',:action=>'login')
    end
  end 

#To check if Office Admin has logged_in and also logged_in Office Admin is an authorized Office Admin

  def authorized_committeeadmin
    unless session[:committeeadmin_id] || session[:committee_id]
      reset_session
      flash[:notice] = "Please log in"
      redirect_to(:controller=>'committee_member',:action=>'login')
    end
  end 

#To check if Office Admin has logged_in and also logged_in Office Admin is an authorized Office Admin

  def authorized_committeeuser
    unless session[:committeeuser_id] || session[:committee_id]
      reset_session
      flash[:notice] = "Please log in"
      redirect_to(:controller=>'committee_member',:action=>'login')
    end
  end 

#To check if Office Admin cannot able to see any of the Global Admins pages.

  def check_valid_adminlogin
    if session[:officeadmin_id] || session[:office_id]
      redirect_to(:controller=>'office_admin',:action=>'index')		
    end
  end

#Before filter Function called to redirect to appropriate action based on admin or office admin login 

  def check_admin_officeadmin
    visited = request.request_uri
    if session[:admin_id]
      authorizedadmin
    elsif session[:officeadmin_id]
      authorized_officeadmin
    elsif session[:officeuser_id]
      authorized_officeuser
    elsif session[:committeeadmin_id]
      authorized_committeeadmin
    elsif session[:committeeuser_id]
      authorized_committeeuser
    else
        if visited.include?('office_admin')	
        redirect_to(:controller=>'office_admin',:action=>'login')
        elsif visited.include?('committee')
        redirect_to(:controller=>'committee_member',:action=>'login')			  
        else
        redirect_to(:controller=>'admin',:action=>'login')			    
        end  
    end
  end

  def check_committee_officeadmin
  if session[:committeeadmin_id]
  authorized_committeeadmin  
  elsif session[:committeeuser_id]
  authorized_committeeuser
  end  
  end

  def check_login
    if session[:admin_id]
      @who_loggedin = 1 #Admin Logged In
    elsif session[:officeadmin_id] && session[:office_id]
      @who_loggedin = 2 # Office Admin Logged In
    elsif session[:officeuser_id] && session[:office_id]
      @who_loggedin = 3 # Office User Logged In
    elsif session[:committeeadmin_id] && session[:committee_id]
      @who_loggedin = 4 # Committee Admin Logged In
    elsif session[:committeeuser_id] && session[:committee_id]
      @who_loggedin = 5 # Committee User Logged In  
    else
      @who_loggedin = nil #Nobody has logged in
    end
    return @who_loggedin
  end

#To make sure the logged in office admin can perform edit,view his/her own office details only.

  def check_officeadmin(officeid)
    if check_login == 2 #Method in application.rb , to check if admin/officeadmin has loggedin
      unless officeid == session[:office_id]
	    if session[:office_id] && session[:officeadmin_id]
	    redirect_to(:controller=>'office_admin',:action=>'index')	    
	  else
	    reset_session
	    redirect_to(:controller=>'office_admin',:action=>'login')	    
	  end
      end    
    end
  end

#To make sure the logged in office admin can perform edit,view his/her own office details only.

  def check_officeuser(officeid)
    if check_login == 3 #Method in application.rb , to check if admin/officeadmin has loggedin
      unless officeid == session[:office_id]
      	    if session[:office_id] && session[:officeuser_id]
	    redirect_to(:controller=>'office_admin',:action=>'index')	    
	  else
	    reset_session
	    redirect_to(:controller=>'office_admin',:action=>'login')	    
	  end
      end    
    end
  end

#To make sure the logged in committee admin can perform edit,view his/her own office details only.

  def check_committeeadmin(committeeid)
    if check_login == 4 #Method in application.rb , to check if admin/committeeadmin has loggedin
      unless committeeid == session[:committee_id]
	    if session[:committee_id] && session[:committeeadmin_id]
	    redirect_to(:controller=>'committee_member',:action=>'index')	    
	  else
	    reset_session
	    redirect_to(:controller=>'committee_member',:action=>'login')	    
	  end
      end    
    end
  end

#To make sure the logged in committee admin can perform edit,view his/her own office details only.

  def check_committeeuser(committeeid)
    if check_login == 5 #Method in application.rb , to check if admin/committeeadmin has loggedin
      unless committeeid == session[:committee_id]
      if session[:committee_id] && session[:committeeuser_id]
	    redirect_to(:controller=>'committee_member',:action=>'index')	    
	  else
	    reset_session
	    redirect_to(:controller=>'committee_member',:action=>'login')	    
	  end
      end    
    end
  end

def values(form)
[
  form.user.full_name,form.user.email,form.org_type,form.org_name,form.org_address1,form.org_address2,form.org_city,form.org_state,form.org_zip,form.org_phone,form.org_fax,form.org_activities,
  form.contact_firstname,form.contact_lastname,form.contact_email,form.contact_address1,form.contact_address2,form.contact_city,form.contact_state,form.contact_zip,form.contact_phone,form.contact_mobile,
  form.sr_contact_firstname,form.sr_contact_lastname,form.sr_contact_email,form.sr_contact_address1,form.sr_contact_address2,form.sr_contact_city,form.sr_contact_state,form.sr_contact_zip,form.sr_contact_phone,form.sr_contact_mobile,
  form.representative_firstname,form.representative_lastname,form.representative_firmname,form.representative_email,form.representative_address1,form.representative_address2,form.representative_city,form.representative_state,form.representative_zip,form.representative_phone,form.representative_mobile,
  form.project_description,form.significance,form.expansion_description,form.fundlaw_description,form.endorsements,form.total_cost,form.amount_requested,
  form.agency_name,form.agency_account,form.agency_sub_account,form.type_of_request,
  form.fund_pe,form.fund_line,form.fund_history_2003,  form.fund_history_2004,form.fund_history_2005,form.fund_history_2006,form.fund_history_2007,form.fund_history_2008,
  form.submitted_date,form.office_questions,form.office_reviewer1,form.office_reviewer2,form.office_reviewer3
 ]
end

 FORM_TITLES =  %w(UserName UserEmail OrgType OrgName	OrgAddress1 OrgAddress2 OrgCity	OrgState	OrgZip	OrgPhone OrgFax	OrgActivities
		ContactFirstname	ContactLastname	ContactEmail	ContactAddress1	ContactAddress2	ContactCity	ContactState	ContactZip	ContactPhone	ContactMobile
		SeniorContactFirstname SeniorContactLastname SeniorContactEmail SeniorContactAddress1 SeniorContactAddress2 SeniorContactCity SeniorContactState SeniorContactZip SeniorContactPhone SeniorContactMobile
		RepFirstname RepLastname	RepFirmname	RepEmail	RepAddress1	RepAddress2	RepCity	RepState	RepZip	RepPhone	RepMobile
		ProjectDescription	Significance	ExpansionDescription	FundlawDescription	Endorsements	TotalCost	AmountRequested
		AgencyName	AgencyAccount	AgencySubAccount	TypeofRequest
		FundPe	FundLine	FundHistory-2003	FundHistory-2004	FundHistory-2005	FundHistory-2006	FundHistory-2007	FundHistory-2008
		SubmittedDate	OfficeQuestions	OfficeReviewer1	OfficeReviewer2	OfficeReviewer3
		)

end
