class CommitteeController < ApplicationController
  before_filter :check_committee_officeadmin
  layout 'newadmin',:except=>[:show,:edit,:new,:new_admin,:show_admin,:edit_admin]  
  protect_from_forgery :except=>[:new,:show,:edit,:new_admin,:show_admin,:edit_admin,:list,:committee_search,:get_emails,:list_forms,:list_members]
  require 'csv'

  #For creating new Committee

  def new
    @committee = Committee.new
  end

#To create new Committee

  def create
    @committee = Committee.new(params[:committee])
    if  @committee.save
      @committees = Committee.paginate(:all,:order=>params[:sort],:per_page =>10,:page=>params[:page])
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
           page.replace_html "list_committee",:partial=>'committee_list'
          page.replace_html 'flashnotice',"New Committee #{@committee.name} Created Successfully and Now Create Committee Admin"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
       end
    else
        render :update do |page|
       
          for h in @committee.errors
            if !@committee.errors["#{h[0]}"].nil?
                  page.show "#{h[0]}_committee"              
                  page.replace_html "#{h[0]}_committee","#{h[1]}"
            end          
                page.hide "name_committee" if @committee.errors['name'].nil?
                page.hide "contact_firstname_committee" if @committee.errors['contact_firstname'].nil?
                page.hide "contact_email_committee" if @committee.errors['contact_email'].nil?
                page.hide "address1_committee" if @committee.errors['address1'].nil?
                page.hide "city_committee" if @committee.errors['city'].nil?
                page.hide "state_committee" if @committee.errors['state'].nil?
                page.hide "zip_committee" if @committee.errors['zip'].nil?
                page.hide "phone_committee" if @committee.errors['phone'].nil?
          end #for loop end
        end #render page end
    end
  end	  

#To Export the list of Committee as a CSV file

  def export
	if !params[:committee].nil?
	  @committees = Committee.find(:all,:conditions=>['id in (?)',params[:committee]])	
	elsif session[:comm_search] == true
		@committees = Committee.find(:all,:conditions=>["(contact_firstname like '%%"+params[:search_txt].to_s+"%%') or (contact_lastname like '%%"+params[:search_txt].to_s+"%%') or (name like '%%"+params[:search_txt].to_s+"%%') or (contact_email like '%%"+params[:search_txt].to_s+"%%')"])  
		@committees = Committee.find(:all) if @committees.empty?
	else
	  @committees = Committee.find(:all)
	end    
    
    report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
      csv << %w(Name
		ContactName
		City
		State
		Zip
		Phone
		Email
		Fax
		Status
		)
        
      @committees.each do |committee|
          
	status = (committee.active_status == true ? "Active" : "Inactive")
          
        csv << [committee.name,
	 committee.contact_firstname,
	 committee.city,
         committee.state,
         committee.zip,
         committee.phone,
	 committee.contact_email,
         committee.fax,
         status]
      end
    end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'committee.csv')

  end

  def export_pdf
	if !params[:committee].nil?
	  @committees = Committee.find(:all,:conditions=>['id in (?)',params[:committee]])
	elsif session[:comm_search] == true
		@committees = Committee.find(:all,:conditions=>["(contact_firstname like '%%"+params[:search_txt].to_s+"%%') or (contact_lastname like '%%"+params[:search_txt].to_s+"%%') or (name like '%%"+params[:search_txt].to_s+"%%') or (contact_email like '%%"+params[:search_txt].to_s+"%%')"])  
		@committees = Committee.find(:all) if @committees.empty?	
	else
	  @committees = Committee.find(:all)
  end    
  
	res =  Committee.export_pdf(@committees)  
	send_data res.render, :filename => 'List of Committees', :type => "application/pdf" 
end


#To Export the list of Admins/User in an Committee as a CSV file

  def export_admin_user
	if !params[:committee_member].nil?
	  @committee_member = CommitteeMember.find(:all,:conditions=>['id in (?) and committee_id = ?',params[:committee_member],params[:id]])	
	else
	  @committee_member = CommitteeMember.find(:all,:conditions=>['committee_id = ?',params[:id]])	    
	end    
    
    report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
      csv << %w(Name
		Email
		Address
		City
		State
		Zip
		Phone
		Fax
		Admin/User
		Status
		)
        
      @committee_member.each do |committee|
          
	status = (committee.active_status == true ? "Active" : "Inactive")
	admin_user = (committee.is_admin == true ? "Admin" : "User")

          
        csv << [committee.firstname,
	committee.email,
         committee.address1,
	 committee.city,
         committee.state,
         committee.zip,
         committee.phone,
         committee.fax,
	 admin_user,
         status]
      end
    end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'committeemember.csv')

  end


  def export_admin_user_pdf
	committee = Committee.find(params[:id])  
      	if !params[:committee_member].nil?
	  @committee_member = CommitteeMember.find(:all,:conditions=>['id in (?) and committee_id = ?',params[:committee_member],params[:id]])	
	else
	  @committee_member = CommitteeMember.find(:all,:conditions=>['committee_id = ?',params[:id]])	    
	end 
  
    res =  CommitteeMember.export_admin_user_pdf(@committee_member,committee)
    send_data res.render, :filename => 'List ofCommittee Members', :type => "application/pdf" 
 end


#To Change the status of an office as Active

  def inactive
    @committee = Committee.find(params[:id])
    @committee.update_attributes(:active_status => true)	
    render :update do |page|
      page.hide "committeeinactivestatus_#{@committee.id}"  
      page.show "committeeactivestatus_#{@committee.id}" 
      page.show 'flashnotice'      
      page.replace_html 'flashnotice',"Selected Committee is Activated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end	    
  end	  

#To Change the status of an office as InActive

  def active
    @committee = Committee.find(params[:id])
    @committee.update_attributes(:active_status => false)
    render :update do |page|
      page.hide "committeeactivestatus_#{@committee.id}"  
      page.show "committeeinactivestatus_#{@committee.id}"  
      page.show 'flashnotice'
      page.replace_html 'flashnotice',"Selected Committee is Inactivated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end    
  end

#For New Admins/Users in Office

  def new_admin
    @committee = Committee.find(params[:id])
    @committee_member  = CommitteeMember.new
    @offices = Office.find :all
  end  

#To Create Admins/Users in Office

  def create_admin
    @committee = Committee.find(params[:id])
    @offices = Office.find :all
    @committee_member  = CommitteeMember.new(params[:committee_member])
    @committee_member.committee_id = @committee.id
    unless (!params[:committee_member][:office_id].empty? && !params[:committee_member][:officemember_type].nil?) || (params[:committee_member][:office_id].empty? && params[:committee_member][:officemember_type].nil?)
    @committee_member.officeid_val = 1 if params[:committee_member][:office_id].empty?
    @committee_member.officemember_val = 1 if params[:committee_member][:officemember_type].nil?
     end    
    if @committee_member.save
		AdminNotifier.deliver_signup_notification(@committee_member)
    @committee_members  = @committee.committee_members.paginate :order=>params[:sort],:page=>params[:page],:per_page=>10
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html "committee_member",:partial=>"committee_member"
          page.replace_html 'flashnotice',"Committee Member Created Successfully"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
    else
      render :update do |page|
        for h in @committee_member.errors
          if !@committee_member.errors["#{h[0]}"].nil?
          page.show "#{h[0]}_committee_member"              
          page.replace_html "#{h[0]}_committee_member","#{h[1]}"
          end          
            page.hide "login_committee_member" if @committee_member.errors['login'].nil?
            page.hide "email_committee_member" if @committee_member.errors['email'].nil?
            page.hide "password_committee_member" if @committee_member.errors['password'].nil?
            page.hide "password_confirmation_committee_member" if @committee_member.errors['password_confirmation'].nil?
            page.hide "firstname_committee_member" if @committee_member.errors['firstname'].nil?
            page.hide "address1_committee_member" if @committee_member.errors['address1'].nil?
            page.hide "city_committee_member" if @committee_member.errors['city'].nil?
            page.hide "state_committee_member" if @committee_member.errors['state'].nil?
            page.hide "zip_committee_member" if @committee_member.errors['zip'].nil?
            page.hide "phone_committee_member" if @committee_member.errors['phone'].nil?
            page.hide "office_id_committee_member" if @committee_member.errors['office_id'].nil?
            page.hide "officemember_type_committee_member" if @committee_member.errors['officemember_type'].nil?
          end
      end
    end
  end	
#To List Committee Details / Activate or Deactivate selected committees

  def list
    params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
  	if session[:committee_id].nil?  
    if !params["inactive_all.x"].nil?         
      if !params[:committee].nil?
        params[:committee].each {|x|          
          inactive_committee = Committee.find(x)
          inactive_committee.update_attributes(:active_status=>false)
          flash[:notice] ="The Selected Committees Are Inactivated"
        }           
      end
    end
    if !params["active_all.x"].nil?   
      if !params[:committee].nil?
        params[:committee].each {|x|
          active_committee = Committee.find(x)   
          active_committee.update_attributes(:active_status=>true)
          flash[:notice] ="The Selected Committees Are Activated"
        }            
      end
    end
    sort_committee
    else
    redirect_to(:controller=>'admin',:action=>'login')
    end
   end
  
  
  def sort_committee
        session[:comm_search] = false
    @committees = Committee.paginate(:all,:order=>params[:sort],:per_page =>params[:per_page],:page=>params[:page])	      
    if request.xml_http_request?
    render :update do |page|
    page.replace_html"list_committee",:partial=>'committee_list'
    end
    end
  end

  def committee_search
    params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
    session[:comm_search] = true
    
    conditions = "(contact_firstname like '%%"+params[:search_txt].to_s+"%%') or (contact_lastname like '%%"+params[:search_txt].to_s+"%%') or (name like '%%"+params[:search_txt].to_s+"%%') or (contact_email like '%%"+params[:search_txt].to_s+"%%')"
    
    options = {:per_page => params[:per_page],:page => params[:page],:order => params[:sort],:conditions => conditions}
    
		if !params[:search_txt].blank?
       @committees = Committee.paginate(options)  
		 
			if @committees.empty?
        options[:conditions] = nil
        @committees = Committee.paginate(options)
				render :update do |page|
					page.replace_html "list_committee",:partial=>'committee_list'
					page.show('flasherror') if params[:sort].nil?
					page.replace_html 'flasherror',"Your Search produced no results for #{params[:search_txt]}" if params[:sort].nil?
					page.visual_effect :fade,'flasherror',:duration => 1.5 if params[:sort].nil?
				end	
			else
				render :update do |page|
					page.replace_html "list_committee",:partial=>'committee_list'
					page.show('flashnotice') if params[:sort].nil?
					page.replace_html 'flashnotice',"Your Search results for #{params[:search_txt]}" if params[:sort].nil?
					page.visual_effect :fade,'flashnotice',:duration => 1.5 if params[:sort].nil?
				end
			end
		else
			@committees = Committee.paginate(options)
				render :update do |page|
					page.replace_html "list_committee",:partial=>'committee_list'
					page.show('flasherror') if params[:sort].nil?
					page.replace_html 'flasherror',"Provide search text" if params[:sort].nil?
					page.visual_effect :fade,'flasherror',:duration => 1.5 if params[:sort].nil?
		    end	
		end
  end


def formslist_search
  @committees = Committee.find :all
  @committee = Committee.find(params[:id])
  check_login
  check_committeeadmin(@committee.id)
  check_committeeuser(@committee.id)
  
  if !params[:search_txt].nil?
      @list_forms = CommitteeFormsubmission.paginate(:all,:per_page =>10,:page=>params[:page],:conditions =>[" committee_id = ? and ((users.firstname like '%%"+params[:search_txt].to_s+"%%') or (users.lastname like '%%"+params[:search_txt].to_s+"%%'))",@committee.id],:include=>[{:formsubmission=>:user},[:officeadmin]])	  

    flash.now[:notice] = "Your Search Results for #{params[:search_txt]}"
	if @list_forms.empty?
         @list_forms = CommitteeFormsubmission.paginate(:all,:per_page =>10,:page=>params[:page],:conditions =>[" committee_id = ?",@committee.id],:include=>[{:formsubmission=>:user},[:officeadmin]])	
          flash.now[:notice] = "Your Search Produced No Results"	
          render :action=> "list_forms"
        else
          render :action=> "list_forms"    
        end
  end
end
  
# To show  committee details
  def show
    @committee = Committee.find(params[:id])
     check_committeeadmin(@committee.id)    
     check_committeeuser(@committee.id)  
  end
  
# To edit  committee details
  def edit
    @committee = Committee.find(params[:id])
    if check_login != 5 #Committee User should not edit the committee details and Committee admin can edit the details
     check_committeeadmin(@committee.id)
    else
      redirect_to(:controller=>'committee_member',:action=>'login')	     
    end
   end


#To List Admin/User Details in an office/ Activate or Deactivate selected admins/users in an office.

  def list_members
  params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	  
    if !params["inactive_all.x"].nil?         
      if !params[:committee_member].nil?
        params[:committee_member].each {|x|          
          inactive_committeemember = CommitteeMember.find(x)
          inactive_committeemember.update_attributes(:active_status=>0)
          flash[:notice1] ="The Selected Committee Admins/Users Are Inactivated"
        }           
      end
    end
    if !params["active_all.x"].nil?   
      if !params[:committee_member].nil?
        params[:committee_member].each {|x|
          active_committeemember = CommitteeMember.find(x)   
          active_committeemember.update_attributes(:active_status=>1)
          flash[:notice1] ="The Selected Committee Admins/Users Are Activated"
        }            
      end
    end
     sort_admin_user
  end
  
  
  def sort_admin_user
    @committee = Committee.find(params[:id])
    @committee_members  = @committee.committee_members.paginate :order=>params[:sort],:page=>params[:page],:per_page=>params[:per_page]
    if request.xml_http_request?
    render :update do |page|
    page.replace_html "committee_member",:partial=>"committee_member"
    end
    end
    check_login
    check_committeeadmin(@committee.id)
  end

#To Change the status of an office admin/user as Active

  def inactive_member
    @committee_member = CommitteeMember.find(params[:id])
    @committee_member.update_attributes(:active_status => true)	
    render :update do |page|
      page.hide "committeememberinactivestatus_#{@committee_member.id}"  
      page.show "committeememberactivestatus_#{@committee_member.id}" 
      page.show 'flashnotice'      
      page.replace_html 'flashnotice',"Selected Committee Admin/User is Activated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end	     
  end	  

#To Change the status of an office admin/user as InActive

  def active_member
    @committee_member = CommitteeMember.find(params[:id])
    @committee_member.update_attributes(:active_status => false)	 
    render :update do |page|
      page.hide "committeememberactivestatus_#{@committee_member.id}"  
      page.show "committeememberinactivestatus_#{@committee_member.id}"  
      page.show 'flashnotice'
      page.replace_html 'flashnotice',"Selected committee Admin/User is Inactivated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end    
  end

   
  def update
    @committee = Committee.find(params[:id])
        if @committee.update_attributes(params[:committee])
		if check_login == 1 #Method in application.rb , to check if admin/officeadmin has loggedin
    @committees = Committee.paginate(:all,:order=>params[:sort],:per_page =>10,:page=>params[:page])	
    render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html"list_committee",:partial=>'committee_list',:locals=>{:committees=>@committees}
          page.replace_html 'flashnotice',"Committee Details are Updated"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end  
		else
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html 'flashnotice',"Committee Details are Updated"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
          page.redirect_to(:controller=>'committee_member',:action =>'index')
        end
		end
    else
        render :update do |page|
       
          for h in @committee.errors
            if !@committee.errors["#{h[0]}"].nil?
                  page.show "#{h[0]}_committee"              
                  page.replace_html "#{h[0]}_committee","#{h[1]}"
            end          
                page.hide "name_committee" if @committee.errors['name'].nil?
                page.hide "contact_firstname_committee" if @committee.errors['contact_firstname'].nil?
                page.hide "contact_email_committee" if @committee.errors['contact_email'].nil?
                page.hide "address1_committee" if @committee.errors['address1'].nil?
                page.hide "city_committee" if @committee.errors['city'].nil?
                page.hide "state_committee" if @committee.errors['state'].nil?
                page.hide "zip_committee" if @committee.errors['zip'].nil?
                page.hide "phone_committee" if @committee.errors['phone'].nil?
          end #for loop end
        end #render page end
    end
  end
  
  #To Show Admins/Users in Committee

  def show_admin
    @committee_admin_user = CommitteeMember.find(params[:id])
    @office = Office.find_by_id(@committee_admin_user.office_id)
    check_committeeadmin(@committee_admin_user.committee_id)
  end
  
  #To Edit Admins/Users in Committee

  def edit_admin
    @committee_member  = CommitteeMember.find(params[:id])
    @offices = Office.find :all
    check_committeeadmin(@committee_member.committee_id)
  end
  
#To Update Admins/Users in committee

  def update_admin
    @offices = Office.find :all
    @committee_member  = CommitteeMember.find(params[:id])
    @committee = Committee.find(@committee_member.committee_id)
    unless (!params[:committee_member][:office_id].empty? && !params[:committee_member][:officemember_type].nil?) || (params[:committee_member][:office_id].empty? && params[:committee_member][:officemember_type].nil?)
    @committee_member.officeid_val = 1 if params[:committee_member][:office_id].empty?
    @committee_member.officemember_val = 1 if params[:committee_member][:officemember_type].nil?
     end  
    if @committee_member.update_attributes(params[:committee_member])
      @committee_members  = @committee.committee_members.paginate :order=>params[:sort],:page=>params[:page],:per_page=>10
      if check_login == 1 #Method in application.rb , to check if admin/officeadmin has loggedin
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html "committee_member",:partial=>"committee_member"
          page.replace_html 'flashnotice',"Committee Admin/User Updated Successfully"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
      else
          flash[:notice2] ="Committee Admin/User Updated Successfully"
          redirect_to :action =>'list_members',:id=>@committee_member.committee_id
      end    
    else
      render :update do |page|
        for h in @committee_member.errors
          if !@committee_member.errors["#{h[0]}"].nil?
          page.show "#{h[0]}_committee_member"              
          page.replace_html "#{h[0]}_committee_member","#{h[1]}"
          end          
            page.hide "login_committee_member" if @committee_member.errors['login'].nil?
            page.hide "email_committee_member" if @committee_member.errors['email'].nil?
            page.hide "password_committee_member" if @committee_member.errors['password'].nil?
            page.hide "password_confirmation_committee_member" if @committee_member.errors['password_confirmation'].nil?
            page.hide "firstname_committee_member" if @committee_member.errors['firstname'].nil?
            page.hide "address1_committee_member" if @committee_member.errors['address1'].nil?
            page.hide "city_committee_member" if @committee_member.errors['city'].nil?
            page.hide "state_committee_member" if @committee_member.errors['state'].nil?
            page.hide "zip_committee_member" if @committee_member.errors['zip'].nil?
            page.hide "phone_committee_member" if @committee_member.errors['phone'].nil?
            page.hide "office_id_committee_member" if @committee_member.errors['office_id'].nil?
            page.hide "officemember_type_committee_member" if @committee_member.errors['officemember_type'].nil?
          end
      end
    end
  end
  
#To Delete Admins/Users in committee

  def delete_admin
    @committee_member = CommitteeMember.find(params[:id])
    @committee_member.destroy
    @committee_member.committee_member_comments.destroy_all    
    check_committeeadmin(@committee_member.committee_id)
    redirect_to :action =>'list_members',:id=>@committee_member.committee_id
  end

  def list_forms
    if params[:commit] == "Send E-mail" 
    send_email
    end 
	  @committee = Committee.find(params[:id])
	  check_login
	  check_committeeadmin(@committee.id)
	  check_committeeuser(@committee.id)
	  sort_list_forms
  end

def sort_list_forms
   @committees = Committee.find :all
   params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
   @list_forms = CommitteeFormsubmission.paginate :per_page =>params[:per_page],:page=>params[:page],:conditions =>['committee_id = ? ',params[:id]],:order =>params[:sort],:include=>[{:formsubmission=>:user},[:officeadmin]]
 	if request.xml_http_request?
      render :update do |page|      
      page.replace_html "committee_forms_list",:partial=>'forms_list'
    end	
    end	
	end

def send_email
   unless params[:formslist].nil?
    if session[:committee_id] && (session[:committeeadmin_id])
      committee_member = CommitteeMember.find(session[:committeeadmin_id])
    else
      committee_member = CommitteeMember.find(session[:committeeuser_id])
    end  
    user_ids = Formsubmission.find(:all,:conditions=>['id in (?)',params[:formslist]]).collect{|x|x.user_id}.uniq
    recipients_emails = User.find(:all,:conditions=>['id in (?)',user_ids]).collect{|x|x.email}
    for email in recipients_emails
      CommitteeadminMailer.deliver_form_submitters(committee_member,email)
    end
    flash.now[:notice] = "E-mail sent to user(s)"
    flash.now[:error] = ""
  else
    flash.now[:error] = "Select User(s) to send E-mail"
  end
end  

def get_emails
    @formids = params[:sel_forms]
    @split_formids = @formids.split(',')
    @list_committeeforms = CommitteeFormsubmission.find(:all,:conditions =>['id in (?) ',@split_formids]).collect{|x| x.formsubmission_id}
    user_forms = Formsubmission.find(:all,:conditions=>['id in (?)',@list_committeeforms]).collect{|x| x.user_id}
    @user_emails = User.find(:all,:conditions=>['id in (?)',user_forms]).collect{|x| x.email}
    @user_emails = @user_emails.join(',')
    if !@user_emails.blank? || !@user_emails.empty?
    render :update do |page|
      page.replace_html 'temp-ctrl-model',"<a href='mailto:"+ "#{@user_emails}"+"?subject=Form submission comment/question'" + "id='send-email'>Send E-mail</a>"
    end
    else
    render :update do |page|
      page.replace_html 'temp-ctrl-model',"Send E-mail"
    end
    end
end 

end
