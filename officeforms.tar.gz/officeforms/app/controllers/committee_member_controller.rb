class CommitteeMemberController < ApplicationController
  before_filter :check_committee_officeadmin,:except=>[:login,:index]
  layout 'newadmin',:except=>[:login] 
  require 'csv'
  
  def login
    return unless request.post?  
    @committeemember = CommitteeMember.authenticate(params[:login], params[:password])
    if @committeemember && @committeemember.active_status == true && @committeemember.is_admin == true
      session[:committeeadmin_id] = @committeemember.id
      session[:committee_id] = @committeemember.committee_id
      redirect_to(:action=>'index')
    elsif @committeemember && @committeemember.active_status == true && @committeemember.is_admin == false
      session[:committeeuser_id] = @committeemember.id
      session[:committee_id] = @committeemember.committee_id
      redirect_to(:action=>'index')  
    else
      flash.now[:error] = "Invalid account details"
      render :action=>'login'	
    end
  end  
  
  def index
    session[:office_id] = nil
    session[:officeadmin_id] = nil
    session[:officeuser_id] = nil
  @recent_submittedforms = CommitteeFormsubmission.find(:all,:conditions=>['created_at > ? and committee_id = ?',Date.today-7,session[:committee_id]],:limit=>10)
  end
  
  def logout
    reset_session
    session[:committeeadmin_id] = nil
    session[:committeeuser_id] = nil
    session[:committee_id] = nil
    session[:office_id] = nil
    session[:officeadmin_id] = nil
    session[:officeuser_id] = nil
    flash[:notice] = "You have been logged out."
    redirect_to(:controller=>'committee_member',:action=>'login')
  end 

 def add_comment
 unless params[:committee_member_comment][:comment].empty? || params[:committee_member_comment][:comment].blank? 
    @form_submission = Formsubmission.find(params[:id])	  
    c = CommitteeMemberComment.new(:comment => params[:committee_member_comment][:comment])
    c.committee_member_id = session[:committeeadmin_id] ? session[:committeeadmin_id] : session[:committeeuser_id]
    @form_submission.committee_member_comments << c    
    @form_submission.update_attributes(:committee_followup=>params[:form_submission][:committee_followup])
    @committee_comments =  @form_submission.committee_member_comments.find(:all, :order=>'created_at DESC') 
    render :update do |page|
	page.replace_html 'committeeformcomment',:partial=>'committeeshowcomment',:locals=>{:committee_comments=>@committee_comments,:form_submission=>@form_submission}    
	page.replace_html 'success_msg',"<font color='green'>Comment Posted Successfully</font>"
	page[:committee_member_comment_comment].value = ""
    end
else
    render :update do |page|
	page.replace_html 'success_msg',"<font color='red'>Enter Your Comments</font>"
    end	
end

	
  end

end
