class HomeController < ApplicationController
layout 'newhome',:except=>[:index,:create]
  def index
  end
  
  def create
    self.current_user = User.authenticate(params[:email], params[:password])
    if !params[:email].blank? || !params[:password].blank?
    if logged_in?
      session[:user_id] = current_user.id    
      redirect_to(:controller=>'users',:action=>'dashboard')
      flash[:notice] = "Logged in successfully"
    else
	flash.now[:error] = "Invalid Email/Password"	    
      render :action => 'index'
    end
    else
	flash.now[:error] = "Enter Email and Password"	    
      render :action => 'index'
    end
  end
  
  
  
  
end
