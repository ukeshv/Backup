class OfficeAdminController < ApplicationController
  before_filter :check_admin_officeadmin,:except=>[:login,:index]
  layout 'newadmin',:except=>[:login] 
  protect_from_forgery :except=>[:create_user]
  require 'csv'

  def index
    unless session[:committeeadmin_id].nil?
    committee_member = CommitteeMember.find(session[:committeeadmin_id]) 
    session[:office_id] = committee_member.office_id
      if committee_member.officemember_type == "Admin"
        session[:officeadmin_id] = "c"
      end
      if committee_member.officemember_type == "User"
        session[:officeuser_id] = "d"
      end
    end
    unless session[:committeeuser_id].nil?
    committee_member = CommitteeMember.find(session[:committeeuser_id]) 
    session[:office_id] = committee_member.office_id
      if committee_member.officemember_type == "User"
        session[:officeuser_id] = "d"
      end
      if committee_member.officemember_type == "Admin"
        session[:officeadmin_id] = "c"
      end
    end
    @recent_submittedforms = Formsubmission.find(:all,:conditions=>['submitted_date > ? and office_id = ?',Date.today-7,session[:office_id]],:limit=>10)
  end

  def login
    return unless request.post?  
    @officeadmin= Officeadmin.authenticate(params[:login], params[:password])
    if @officeadmin && @officeadmin.active_status == true && @officeadmin.is_admin == true
      session[:officeadmin_id] = @officeadmin.id
      session[:office_id] = @officeadmin.office_id
      redirect_to(:action=>'index')
    elsif @officeadmin && @officeadmin.active_status == true && @officeadmin.is_admin == false
      session[:officeuser_id] = @officeadmin.id
      session[:office_id] = @officeadmin.office_id
      redirect_to(:action=>'index')    
    else
      flash.now[:error] = "Invalid account details"
      render :action=>'login'	
    end
  end
  
    def new_user
    @user = User.new
  end


  def create_user
  @user = User.new(params[:user])
	@user.skip_office = 1
	if  @user.save
		@user.update_attributes(:active_status=> true,:activated_at=>Time.now.utc,:activation_code=>nil)
		add_officeform_publicuser
      if params[:mail_user].to_i==1
      @office_users= Officeadmin.find(:all, :conditions => ["is_admin = ? and active_status = ? and receive_notifications = ? and office_id = ?", false, true, true, session[:office_id] ])
      current_login = session[:officeadmin_id] ? session[:officeadmin_id] : session[:officeuser_id]
      @office_admin	= Officeadmin.find(current_login)
        if !@office_users.empty?
        for officeuser in @office_users
          OfficeadminMailer.deliver_submitnewform_notification(officeuser,@office_admin,@form_sub.id)
        end
        end
      end
		flash[:notice] = "User created successfully"
		redirect_to(:controller=>'admin', :action=>'edit_form',:id=>@form_sub.id)
	else
		render :action=>'new_user'
	end
  end  
  
  def add_officeform_publicuser
    @office_form = Officeform.find_by_office_id(session[:office_id])
    @form_sub = Formsubmission.new
    @form_sub.office_id = @office_form.office_id
    @form_sub.user_id = @user.id
    @form_sub.is_draft = true
    @form_sub.save	  
  end	

  def newform
    @office_form = Officeform.find_by_office_id(session[:office_id])
    @form_sub = Formsubmission.new
    @form_sub.office_id = @office_form.office_id
    @form_sub.is_draft = true
    if session[:officeadmin_id]
      @officeadmin = Officeadmin.find(session[:officeadmin_id])
    else
      @officeadmin = Officeadmin.find(session[:officeuser_id])  
    end  
    if @officeadmin.is_admin == true
      @form_sub.submitted_by = "OfficeAdmin"
    elsif @officeadmin && @officeadmin.active_status == true && @officeadmin.is_admin == false
      @form_sub.submitted_by = "OfficeUser" 
    end
    @form_sub.submitted_adminuser_id = @officeadmin.id
    @form_sub.save
    redirect_to(:controller=>'admin', :action=>'edit_form',:id=>@form_sub.id)	  
  end


  def logout
    reset_session
    session[:officeadmin_id] = nil
    session[:officeuser_id] = nil
    session[:office_id] = nil
    session[:committeeadmin_id] = nil
    session[:committeeuser_id] = nil
    session[:committee_id] = nil
    flash[:notice] = "You have been logged out."
    redirect_to(:controller=>'office_admin',:action=>'login')
  end 
  
end
