class OfficeController < ApplicationController
  before_filter :check_admin_officeadmin,:except=>[:assign_customfields]
  layout 'newadmin',:except=>[:show,:edit,:new,:show_admin,:edit_admin,:new_admin,:forms_advancedsearch,:send_emails,:edit_followup_field,:delete_followup_field]
  protect_from_forgery :except=>[:new,:show,:edit,:new_admin,:show_admin,:edit_admin,:list,:office_search,:get_emails,:list_forms,:formslist_search,:add_priority,:forms_advancedsearch,:view_officeform,:officefield_update]
  require 'csv'

  def index
  end

  def get_emails
    @formids = params[:sel_forms]
    @split_formids = @formids.split(',')
    user_forms = Formsubmission.find(:all,:conditions=>['id in (?)',@split_formids]).collect{|x| x.user_id}
    @user_emails = User.find(:all,:conditions=>['id in (?)',user_forms]).collect{|x| x.email}
    @user_emails = @user_emails.join(',')
    if !@user_emails.blank? || !@user_emails.empty?
    render :update do |page|
      page.replace_html 'temp-ctrl-model',"<a href='mailto:"+ "#{@user_emails}"+"?subject=Form submission comment/question'" + "id='send-email'>Send E-mail</a>"
    end
    else
    render :update do |page|
      page.replace_html 'temp-ctrl-model',"Send E-mail"
    end
    end
  end 

  def send_emails
    @formsids = params[:id]
    @split_formsids = @formsids.split(',')
    @forms_users = Formsubmission.find(:all,:conditions=>['id in (?)',@split_formsids]).collect{|x| x.user_id}.uniq
    @emails = User.find(:all,:conditions=>['id in (?)',@forms_users]).collect{|x|x.email}
 end
  
  def list_forms
    unless params[:committee_formsubmission].nil?# && params[:commit].nil?
    submit_committee
    end
	  @office = Office.find(params[:id])
	  check_login
	  check_officeadmin(@office.id)
	  check_officeuser(@office.id)
	  sort_list_forms
  end

def sort_list_forms
   @office = Office.find(params[:id])
    check_login
	  check_officeadmin(@office.id)
	  check_officeuser(@office.id)
   @committees = Committee.find :all
   session[:officeformslist_search] = false
   params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])
	  if session[:office_id] && (session[:officeadmin_id] || session[:officeuser_id])
      current_login = session[:officeadmin_id] ? session[:officeadmin_id] : session[:officeuser_id]
      @logged_office_admin	= Officeadmin.find(current_login)
      priority_permission
      category_permission
      find_selcategory_followupvalues
      find_all_or_selected_category_forms_of_office
	  else
      @list_forms = Formsubmission.find_forms_office(params[:id],params[:per_page],params[:page],params[:sort])
	end
	if request.xml_http_request?
      render :update do |page|      
      page.replace_html "forms_list",:partial=>'forms_list'
    end	
    end	
	end


  def find_all_or_selected_category_forms_of_office
    if (params[:sel_category].nil?) || (params[:sel_category].blank?) || params[:sel_category] == "All"
        @list_forms = Formsubmission.find_all_forms_or_all_categories_of_office(params[:id],params[:per_page],params[:page],params[:sort])
      else
        @list_forms = Formsubmission.find_selected_category_forms_of_office(@sel_categoryforms,params[:per_page],params[:page],params[:sort])
      end   
  end  

def formslist_search
	params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])				
  @committees = Committee.find :all
  @office = Office.find(params[:id])
  check_login
  check_officeadmin(@office.id)
  check_officeuser(@office.id)
  session[:officeformslist_search] = true
  if !params[:search_txt].blank?
        if session[:office_id] && (session[:officeadmin_id] || session[:officeuser_id])
          current_login = session[:officeadmin_id] ? session[:officeadmin_id] : session[:officeuser_id]
          @logged_office_admin	= Officeadmin.find(current_login)
          priority_permission
          category_permission
          find_selcategory_followupvalues
          if (params[:sel_category].nil?) || (params[:sel_category].blank?) || params[:sel_category] == "All"
          @list_forms = Formsubmission.find_forms_of_all_category_with_searchtxt(params[:search_txt],params[:id],params[:per_page],params[:page],params[:sort])
          else
          @list_forms = Formsubmission.find_forms_of_selected_category_with_searchtxt(@sel_categoryforms,params[:search_txt],params[:id],params[:per_page],params[:page],params[:sort])
          end
        else
          @list_forms = Formsubmission.find_all_forms_with_searchtxt(params[:search_txt],params[:id],params[:per_page],params[:page],params[:sort])
         end
        if @list_forms.empty?
              if session[:office_id] && (session[:officeadmin_id] || session[:officeuser_id])
                find_selcategory_followupvalues
                find_all_or_selected_category_forms_of_office
              else
                @list_forms = Formsubmission.find_forms_office(params[:id],params[:per_page],params[:page],params[:sort])
              end 
            formslistsearch(flash_error='flasherror',search_result_error="Your Search produced no results for #{params[:search_txt]}")              
        else
          formslistsearch(flash_notice='flashnotice',search_result_notice="Your Search results for #{params[:search_txt]}")
        end
		else
          if session[:office_id] && (session[:officeadmin_id] || session[:officeuser_id])
            current_login = session[:officeadmin_id] ? session[:officeadmin_id] : session[:officeuser_id]
            @logged_office_admin	= Officeadmin.find(current_login)
            priority_permission
            category_permission
            find_selcategory_followupvalues
            find_all_or_selected_category_forms_of_office
          else
            @list_forms = Formsubmission.find_forms_office(params[:id],params[:per_page],params[:page],params[:sort])
          end
          formslistsearch(flash_error='flasherror',search_result_error="Provide search text")
  end
  end

#To display the flash notice and errors along with replacing the list with new results thro ajax - formslist_search

  def formslistsearch(flash,search_result)
		render :update do |page|
					page.replace_html "forms_list",:partial=>'forms_list'
					page.show(flash) if params[:sort].nil?
					page.replace_html flash, search_result if params[:sort].nil?
					page.visual_effect :fade,flash,:duration => 1.5 if params[:sort].nil?
		end	
  end

def find_selcategory_followupvalues
      if !params[:sel_category].blank? && params[:sel_category] != "All"
        @sel_categoryforms = FollowupValue.category_followupvalues(params[:sel_category],params[:id]).collect{|x|x.formsubmission_id}
      end
end  

def priority_permission
      if @logged_office_admin.is_admin == true
        @priority_permission = true
      elsif @logged_office_admin.is_admin == false && @logged_office_admin.priority_role == true
        @priority_permission = true
      else
        @priority_permission = false
      end
end

def category_permission
      if session[:officeadmin_id] || session[:officeuser_id]
        @category_permission = true
        @categories = @logged_office_admin.find_defaultvalues if !@logged_office_admin.office.nil? and !@logged_office_admin.office.followup_fields.empty?
      else
        @category_permission = false
      end
end  

def forms_advancedsearch
  @office = Office.find(params[:id])
end  

  def update_advancedsearch
    @committees = Committee.find :all
    @office = Office.find(params[:id])
    @conditions_string = []
    @conditions_string << "office_id = '#{@office.id}' and is_draft = false and submitted_date is not NULL"
      if params[:search_query].nil?
      amount_querystring
      city_state_querystring
      formsubmit_querystring
      formstatus_querystring
      @search_query = @conditions_string.join(" AND ")
      else
      @search_query = params[:search_query]
      end  
      @list_forms = Formsubmission.paginate(:all,:conditions =>[@search_query],:per_page =>10,:page=>params[:page])
      
      if request.xml_http_request?
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html "forms_list",:partial=>'forms_list',:locals=>{:list_forms=>@list_forms,:search_query=>@search_query}
        end
      else 
        render :action=> "list_forms"      
      end
  end

  def amount_querystring
    if params[:amount_range] == "1"
      @conditions_string << "amount_requested > '#{params[:amount]}' " if !params[:amount].blank?
    else
      @conditions_string << "amount_requested < '#{params[:amount]}' " if !params[:amount].blank?  
    end
    params[:low_amount] ||= 0
    params[:high_amount] ||= 0
    if params[:high_amount].to_i != 0 && params[:low_amount].to_i != 0
    @conditions_string << "amount_requested > '#{params[:low_amount]}' AND amount_requested < '#{params[:high_amount]}' " 
    end
  end

  def city_state_querystring    
      @conditions_string << "(org_city LIKE '%%#{params[:org_city]}%%')"  if !params[:org_city].blank?
      @conditions_string << "(org_state LIKE '%%#{ params[:organisation][:state]}%%')"  if !params[:organisation][:state].blank?
  end   

  def formsubmit_querystring
    params[:form_submit][:start_date] = nil if params[:form_submit][:start_date].blank?
    params[:form_submit][:end_date] = nil if params[:form_submit][:end_date].blank?
    if !params[:form_submit][:start_date].nil? && !params[:form_submit][:end_date].nil?
      @conditions_string << "submitted_date > '#{(params[:form_submit][:start_date]).to_date}' AND submitted_date < '#{(params[:form_submit][:end_date]).to_date}' " 
    end
  end

  def formstatus_querystring    
     if params[:form_status] == "1"
      @conditions_string << "(is_draft = false)"  if !params[:form_status].blank?
     elsif params[:form_status] == "2" 
      @conditions_string << "(is_draft = true)"  if !params[:form_status].blank? 
    end
  end  

  #For creating new Office

  def new
    @office = Office.new
  end

#To create new Office

  def create
    @office = Office.new(params[:office])
    if  @office.save
    add_officeform
    add_customfields
    @offices = Office.paginate(:all,:order=>params[:sort],:per_page =>10,:page=>params[:page])
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html "list_office",:partial=>'office_list',:locals=>{:offices=>@offices}
          page.replace_html 'flashnotice',"New Office #{@office.name} Created Successfully and Now Create Office Admin"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
    else
      show_errorsof_office_field
    end
  end	  

  def add_officeform
    @default_form = Defaultform.find :first
    @office_form = Officeform.new(@default_form.attributes)
    @office_form.office_id = @office.id
    @office_form.active_status = true
    @office_form.save
  end


#To display errors of office fields when creating or updating

def show_errorsof_office_field
      render :update do |page|
       
        for h in @office.errors
        if !@office.errors["#{h[0]}"].nil?
              page.show "#{h[0]}_office"              
              page.replace_html "#{h[0]}_office","#{h[1]}"
        end          
              page.hide "name_office" if @office.errors['name'].nil?
              page.hide "firstname_office" if @office.errors['firstname'].nil?
              page.hide "address1_office" if @office.errors['address1'].nil?
              page.hide "city_office" if @office.errors['city'].nil?
              page.hide "state_office" if @office.errors['state'].nil?
              page.hide "zip_office" if @office.errors['zip'].nil?
              page.hide "phone_office" if @office.errors['phone'].nil?
              page.hide "contact_firstname_office" if @office.errors['contact_firstname'].nil?
              page.hide "contact_email_office" if @office.errors['contact_email'].nil?
        end
        end
end  

  def add_customfields
	  1.upto(15) {|i|
 	  @custom_field = CustomField.create(:office_id=>@office.id,:field_name=> "custom#{i}",:field_type=>'Textbox',:active_status=>0 )
	  }
  end

#To update Office field name using In Place Editor

  def officefield_update
    customfield = CustomField.find(params[:id])
    customfield.update_attributes(:field_name=>params[:value])
    render :text => customfield.field_name
  end

#To Edit Office Details

  def edit
    @office = Office.find(params[:id])
    if check_login != 3 #Office User should not edit the office details and Office admin can edit the details
     check_officeadmin(@office.id)
    else
      redirect_to(:controller=>'office_admin',:action=>'login')	     
    end
  end

#To Update Office Details

  def update
    @office = Office.find(params[:id])
    @officefields = OfficeField.find(:all,:conditions=>['office_id = ? and active_status = ?',@office.id,true])
    unless params[:office_field].nil?
    params[:office_field].each do |officefield|
      split_officefield = officefield[0].split('_')
      officefieldid = split_officefield[2]
      o = OfficeField.find(officefieldid)
      o.update_attributes(:field_value=>officefield[1])
    end
    end
    if @office.update_attributes(params[:office])
      @offices = Office.paginate(:all,:order=>params[:sort],:per_page =>10,:page=>params[:page])
      if check_login == 1 #Method in application.rb , to check if admin/officeadmin has loggedin
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html "list_office",:partial=>'office_list',:locals=>{:offices=>@offices}
          page.replace_html 'flashnotice',"Office Details are Updated"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
      else
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html 'flashnotice',"Office Details are Updated"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
          page.redirect_to(:controller=>'office_admin',:action =>'index')
        end
      end
    else
      show_errorsof_office_field
    end
  end

#To Show Office Details

  def show
    @office = Office.find(params[:id])
     check_officeadmin(@office.id)    
     check_officeuser(@office.id)    
   end	  

#To change status of office list / list_office_admin_user status as active or inactive for selected checkboxes

  def active_inactive_listoffice_or_list_office_admin_user(prms, current_model, user_or_admin)
		if !params["inactive_all.x"].nil?         
			if !prms.nil?
				prms.each {|x|          
				inactive_user = current_model.find(x)
				inactive_user.update_attributes(:active_status=>false)
				flash.now[:notice] = "The Selected #{user_or_admin} Are Inactivated"
				}           
			end
		end
		if !params["active_all.x"].nil?   
			if !prms.nil?
				prms.each {|x|
				active_user = current_model.find(x)   
				active_user.update_attributes(:active_status=>true)
				flash.now[:notice] = "The Selected #{user_or_admin} Are Activated"
				}            
			end
		end
	end

#To List Office Details / Activate or Deactivate selected offices

  def list
    params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
		if session[:office_id].nil?  
			active_inactive_listoffice_or_list_office_admin_user(params[:office], Office, "Admins Offices")
			sort_office
		else
			 redirect_to(:controller=>'admin',:action=>'login')
		end
  end

  def sort_office
    session[:off_search] = false
    @offices = Office.paginate(:all,:order=>params[:sort],:per_page =>params[:per_page],:page=>params[:page])	      
    if request.xml_http_request?
      render :update do |page|
      page.replace_html"list_office",:partial=>'office_list'
      end
    end
  end

#To Export the list of Offices as a CSV file

  def export
	@offices = export_lisf_of_offices_as_csv_and_pdf    
    report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
      csv << %w(Name
		Type
		Address
		City
		State
		Zip
		Phone
		Fax
		MemberName
		MemberState
		MemberDistrict
		ContactName
		ContactEmail
		Status
		)
        
      @offices.each do |office|
          
	status = (office.active_status == true ? "Active" : "Inactive")
          
        csv << [office.name,
         office.office_type,
         office.address,
	 office.city,
         office.state,
         office.zip,
         office.phone,
         office.fax,
	 office.full_name, 
	 office.member_state, 
	 office.member_district, 
	 office.contactname, 
	 office.contact_email, 
         status]
      end
    end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'office.csv')

  end

#To Change the status of an office /office members as Active

def active_office_or_officemember_status
	modify_status_for = params[:mod]
	current_model = (params[:tab] == 'Office' ? Office : Officeadmin) 
	current_admin_or_user = current_model.find(params[:id])
	current_admin_or_user.update_attributes(:active_status => true)	 
		render :update do |page|
      page.hide "#{modify_status_for}inactivestatus_#{current_admin_or_user.id}"  
      page.show "#{modify_status_for}activestatus_#{current_admin_or_user.id}"  
      page.show 'flashnotice'
      page.replace_html 'flashnotice',"#{current_model} Activated successfully"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end
end	

#To Change the status of an office /office members as Inactive

def inactive_office_or_officemember_status
	modify_status_for = params[:mod]
	current_model = (params[:tab] == 'Office' ? Office : Officeadmin) 
	current_admin_or_user = current_model.find(params[:id])
	current_admin_or_user.update_attributes(:active_status => false)	 
		render :update do |page|
      page.hide "#{modify_status_for}activestatus_#{current_admin_or_user.id}"  
      page.show "#{modify_status_for}inactivestatus_#{current_admin_or_user.id}"  
      page.show 'flashnotice'
      page.replace_html 'flashnotice',"#{current_model} Deactivated successfully"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end
end	

#For New Admins/Users in Office

  def new_admin
    @office = Office.find(params[:id])
    @office_admin_user  = Officeadmin.new
  end  
  
  def permissions(true_or_false)
    @office_admin_user.priority_role = true_or_false
    @office_admin_user.category_role = true_or_false
    @office_admin_user.editform = true_or_false
    @office_admin_user.receive_notifications = true_or_false
  end
  
#To Create Admins/Users in Office

  def create_admin
    @office = Office.find(params[:id])
    @office_admin_user  = Officeadmin.new(params[:office_admin_user])
    @office_admin_user.office_id = @office.id
    if params[:office_admin_user][:is_admin].to_i == 1 # By default officeadmins roles will be enabled for priority and category
      permissions(true)
    else
      permissions(false)
    end  
    if  @office_admin_user.save
      if session[:office_id] && session[:officeadmin_id]
        if params[:chk_admin_user].to_i == 2
          @office_admin_user.update_attributes(:priority_role=>params[:temp_office_admin_user][:priority_role_temp],:category_role=>params[:temp_office_admin_user][:category_role_temp],:editform=>params[:temp_office_admin_user][:editform_temp],:receive_notifications=>params[:temp_office_admin_user][:receive_notifications_temp])
        end  
      end  
		AdminNotifier.deliver_signup_notification(@office_admin_user)
    @office_admins_users  = @office.office_admins_users.paginate :order=>params[:sort],:page=>params[:page],:per_page=>10
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html "admin_user",:partial=>"office_admin_user"
          page.replace_html 'flashnotice',"Office Admin/User Created Successfully"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
    else
      show_errorsof_office_admin_user_field
    end
  end	


#To display errors of Office admins/users fields when creating or updating

def show_errorsof_office_admin_user_field
      render :update do |page|
        for h in @office_admin_user.errors
          if !@office_admin_user.errors["#{h[0]}"].nil?
          page.show "#{h[0]}_office_admin_user"              
          page.replace_html "#{h[0]}_office_admin_user","#{h[1]}"
          end          
            page.hide "login_office_admin_user" if @office_admin_user.errors['login'].nil?
            page.hide "email_office_admin_user" if @office_admin_user.errors['email'].nil?
            page.hide "password_office_admin_user" if @office_admin_user.errors['password'].nil?
            page.hide "password_confirmation_office_admin_user" if @office_admin_user.errors['password_confirmation'].nil?
            page.hide "firstname_office_admin_user" if @office_admin_user.errors['firstname'].nil?
            page.hide "address1_office_admin_user" if @office_admin_user.errors['address1'].nil?
            page.hide "city_office_admin_user" if @office_admin_user.errors['city'].nil?
            page.hide "state_office_admin_user" if @office_admin_user.errors['state'].nil?
            page.hide "zip_office_admin_user" if @office_admin_user.errors['zip'].nil?
            page.hide "phone_office_admin_user" if @office_admin_user.errors['phone'].nil?
          end
      end 
end  

#To Edit Admins/Users in Office

  def edit_admin
    @office_admin_user  = Officeadmin.find(params[:id])
    check_officeadmin(@office_admin_user.office_id)
  end

#To Update Admins/Users in Office

  def update_admin
    @office_admin_user  = Officeadmin.find(params[:id])
    @office = Office.find(@office_admin_user.office_id)
    prev_priority_value = @office_admin_user.priority_role #To retain value given by office admin .should not be changed when updated by global admin
    prev_category_value = @office_admin_user.category_role
    prev_editform_value = @office_admin_user.editform
    prev_notification_value = @office_admin_user.receive_notifications
    if params[:office_admin_user][:is_admin].to_i == 1 # By default officeadmins roles will be enabled for priority and category
      permissions(true)
    else
      permissions(false)
    end 
    if @office_admin_user.update_attributes(params[:office_admin_user])
      if session[:office_id] && session[:officeadmin_id]
        if params[:chk_admin_user].to_i == 2
          @office_admin_user.update_attributes(:priority_role=>params[:temp_office_admin_user][:priority_role_temp],:category_role=>params[:temp_office_admin_user][:category_role_temp],:editform=>params[:temp_office_admin_user][:editform_temp],:receive_notifications=>params[:temp_office_admin_user][:receive_notifications_temp])
        end
      elsif session[:admin_id]
        @office_admin_user.update_attributes(:priority_role=>prev_priority_value,:category_role=>prev_category_value,:editform=>prev_editform_value,:receive_notifications=>prev_notification_value)
      end
      @office_admins_users  = @office.office_admins_users.paginate :order=>params[:sort],:page=>params[:page],:per_page=>10
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html "admin_user",:partial=>"office_admin_user"
          page.replace_html 'flashnotice',"Office Admin/User Updated Successfully"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
     else
        show_errorsof_office_admin_user_field
    end
  end

#To Show Admins/Users in Office

  def show_admin
    @office_admin_user = Officeadmin.find(params[:id])
    check_officeadmin(@office_admin_user.office_id)
  end

#To Delete Admins/Users in Office

  def delete_admin
    @office_admin_user = Officeadmin.find(params[:id])
    @office_admin_user.destroy 
    check_officeadmin(@office_admin_user.office_id)
    redirect_to :action =>'list_office_admin_user',:id=>@office_admin_user.office_id
  end

#To List Admin/User Details in an office/ Activate or Deactivate selected admins/users in an office.

  def list_office_admin_user
		params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])
    active_inactive_listoffice_or_list_office_admin_user(params[:office_admin_user], Officeadmin, "Admins/Users")
    if params[:commit] == "Send Email" 
      officemembers_send_email
    end
     sort_admin_user
  end
   
  def sort_admin_user
	  @office = Office.find(params[:id])
      @office_admins_users  = @office.office_admins_users.paginate :order=>params[:sort],:page=>params[:page],:per_page=>params[:per_page]
    if request.xml_http_request?
      render :update do |page|
      page.replace_html"admin_user",:partial=>"office_admin_user"
    end
    end
    check_login
    check_officeadmin(@office.id)
  end
  
#To Export the list of Admins/User in an Office as a CSV file

  def export_admin_user
	if !params[:office_admin_user].nil?
	  @office_admin_user = Officeadmin.find(:all,:conditions=>['id in (?) and office_id = ?',params[:office_admin_user],params[:id]])	
	else
	  @office_admin_user = Officeadmin.find(:all,:conditions=>['office_id = ?',params[:id]])	    
	end    
    
    report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
      csv << %w(Name
		Email
		Address
		City
		State
		Zip
		Phone
		Fax
		Admin/User
		Status
		)
        
      @office_admin_user.each do |office_admin_user|
          
	status = (office_admin_user.active_status == true ? "Active" : "Inactive")
	admin_user = (office_admin_user.is_admin == true ? "Admin" : "User")

          
        csv << [office_admin_user.full_name,
	office_admin_user.email,
         office_admin_user.address,
	 office_admin_user.city,
         office_admin_user.state,
         office_admin_user.zip,
         office_admin_user.phone,
         office_admin_user.fax,
	 admin_user,
         status]
      end
    end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'officeadmin_user.csv')

  end

#To View and Update the form settings of an office.

  def view_officeform
    @office_form = Officeform.find_by_office_id(params[:id])
    check_login
    check_officeadmin(@office_form.office_id)
    return unless request.post?
    if @office_form.update_attributes(params[:office_form])
    flash.now[:notice] = "Office Form Settings has been updated for #{@office_form.office.name}"
		else
		flash.now[:error] = "Office Form Settings has not been updated for #{@office_form.office.name}"		
		render :action=>'view_officeform'		
		end
  end

  def office_search
    params[:per_page] = ((params[:per_page].nil? || params[:per_page].to_i == 0 ) ? 10 : params[:per_page])	
    session[:off_search] = true
    
    conditions = "(firstname like '%%"+params[:search_txt].to_s+"%%') or (lastname like '%%"+params[:search_txt].to_s+"%%') or (name like '%%"+params[:search_txt].to_s+"%%') or (contact_firstname like '%%"+params[:search_txt].to_s+"%%') or (contact_lastname like '%%"+params[:search_txt].to_s+"%%') or (contact_email like '%%"+params[:search_txt].to_s+"%%')"
    
    options = {:per_page => params[:per_page],:page => params[:page],:order => params[:sort],:conditions => conditions}
    
		if !params[:search_txt].blank?
       @offices = Office.paginate(options)
		 
			if @offices.empty?
        options[:conditions] = nil
        @offices = Office.paginate(options)
        officesearch(flash_error='flasherror',search_result_error="Your Search produced no results for #{params[:search_txt]}")
			else
        officesearch(flash_notice='flashnotice',search_result_notice="Your Search results for #{params[:search_txt]}")
			end
		else
			@offices = Office.paginate(options)
      officesearch(flash_error='flasherror',search_result_error="Provide search text")	
		end
  end

#To display the flash notice and errors along with replacing the list with new results thro ajax - office_search

def officesearch(flash,search_result)
		render :update do |page|
					page.replace_html "list_office",:partial=>'office_list'
					page.show(flash) if params[:sort].nil?
					page.replace_html flash, search_result if params[:sort].nil?
					page.visual_effect :fade,flash,:duration => 1.5 if params[:sort].nil?
		end	
end

#To Export the list of Offices as a PDF file

  def export_pdf
	@offices = export_lisf_of_offices_as_csv_and_pdf
  res =  Office.export_pdf(@offices)  
	send_data res.render, :filename => 'List of Offices', :type => "application/pdf" 
end

#To check the condition to export as CSV & PDF in list of offices 
def export_lisf_of_offices_as_csv_and_pdf
  if !params[:office].nil?
	  @offices = Office.find(:all,:conditions=>['id in (?)',params[:office]])
  elsif session[:off_search] == true
     @offices = Office.find(:all,:conditions=>["(firstname like '%%"+params[:search_txt].to_s+"%%') or (lastname like '%%"+params[:search_txt].to_s+"%%') or (name like '%%"+params[:search_txt].to_s+"%%') or (contact_firstname like '%%"+params[:search_txt].to_s+"%%') or (contact_lastname like '%%"+params[:search_txt].to_s+"%%') or (contact_email like '%%"+params[:search_txt].to_s+"%%')"])
     @offices = Office.find(:all) if @offices.empty?	    
	else
	  @offices = Office.find(:all)
	end  
  @offices  
end

  def export_admin_user_pdf
	office = Office.find(params[:id])  
      	if !params[:office_admin_user].nil?
	  @office_admin_users = Officeadmin.find(:all,:conditions=>['id in (?) and office_id = ?',params[:office_admin_user],params[:id]])	
	else
	  @office_admin_users = Officeadmin.find(:all,:conditions=>['office_id = ?',params[:id]])	    
	end 
  
    res =  Officeadmin.export_admin_user_pdf(@office_admin_users,office)
    send_data res.render, :filename => 'List of Office Admins-Users', :type => "application/pdf" 
 end

#Office User Can Edit Office FollowUp for Submitted Form

def edit_officefollowup
@form_submission = Formsubmission.find(params[:id])
@office_form = @form_submission.office.officeform
return unless request.post?
@form_submission.update_attributes(params[:form_submission])
@form_submission.update_attributes(:followup_updatedby=>session[:officeuser_id])
redirect_to(:controller=>'office',:action=>'list_forms',:id=>@form_submission.office_id)
end

 # Manage custom fields form
 
  def manage_fields
			@err =[]
    @office = Office.find(params[:id])
    @custom_fields = CustomField.find(:all,:conditions=>['office_id = ?',@office.id])
    @followup_field = FollowupField.new(params[:followup_field])
    @followup_fields = @office.followup_fields
    check_login
    check_officeadmin(@office.id)
    return unless request.post?
		params[:office_field].each do |officefield|
		split_officefield = officefield[0].split('_')
		officefieldid = split_officefield[2]
		o = CustomField.find(officefieldid)
		if o.update_attributes(:active_status=>params["office_field"]["active_status_#{officefieldid}"],:field_type=>params["office_field"]["field_type_#{officefieldid}"],:is_mandatory=>params["office_field"]["is_mandatory_#{officefieldid}"],:is_length_enabled=>params["office_field"]["is_enabled_#{officefieldid}"],:max_length=>params["office_field"]["max_length_#{officefieldid}"])
		else
		@err << "#{o.id}"
		end
end
		if @err.empty?
	    flash[:notice] = "Manage Form Settings has been updated"
    	redirect_to(:controller=>'office',:action=>'manage_fields')
	else
			render :action=>'manage_fields'
	end
end

def add_followup_field
  @followup_field = FollowupField.new(params[:followup_field])
  render :update do |page|
      page.show 'edit_office_followup_field'
      page.replace_html 'edit_office_followup_field',:partial=>'add_followup_field'      
  end
end

def create_followup_field
  @followup_field = FollowupField.new(params[:followup_field])
  @office = Office.find(session[:office_id])
  @followup_field.office_id = @office.id
  if @followup_field.save
    replace_listof_followup_field
  else
    show_errorsof_followup_field
  end  
end 

#To replace list of followup fields after creating or updating

  def replace_listof_followup_field
    @followup_fields = @office.followup_fields
    render :update do |page|
      page.replace_html "list_followup_field", :partial => "list_followup_field", :locals =>{:followup_fields=>@followup_fields}
      page.hide 'edit_office_followup_field'      
    end
  end  

#To display errors of followup fields when creating or updating

def show_errorsof_followup_field
    render :update do |page|
        for h in @followup_field.errors
          if !@followup_field.errors["#{h[0]}"].nil?
          page.show "#{h[0]}_followup_field"              
          page.replace_html "#{h[0]}_followup_field","#{h[1]}"
        end
          page.hide "default_value_followup_field" if @followup_field.errors['default_value'].nil?        
        end      
    end 
end  

def edit_followup_field
  @followup_field = FollowupField.find(params[:id])
  render :update do |page|
      page.show 'edit_office_followup_field'
      page.replace_html 'edit_office_followup_field',:partial=>'edit_followup_field'      
  end
end  

def update_followup_field
  @followup_field = FollowupField.find(params[:id])
  @office = Office.find(session[:office_id])
  @followup_field.office_id = @office.id
  if @followup_field.update_attributes(params[:followup_field])
    replace_listof_followup_field
  else
    show_errorsof_followup_field  
  end  
end

def assign_customfields
	officeids = CustomField.find(:all).collect{|x| x.office_id}.uniq
  unless officeids.empty?
	offices = Office.find(:all,:conditions=>['id not in (?)',officeids])
  else
  offices = Office.find(:all)  
  end
	for office in offices
	  1.upto(15) {|i|
 	  @custom_field = CustomField.create(:office_id=>office.id,:field_name=> "custom#{i}",:field_type=>'Textbox',:active_status=>0 )
	  }
	  end
end

def submit_committee
 users = []
 err_users = []
 s_flag = false
 e_flag = false
 unless params[:committee_formsubmission][:committee_id].blank?
 unless params[:formslist].nil?
  params[:formslist].each do |formid|
      c=CommitteeFormsubmission.new
      c.committee_id = params[:committee_formsubmission][:committee_id]
      c.formsubmission_id = formid
      c.officeadmin_id = (session[:officeadmin_id] ? session[:officeadmin_id] : session[:officeuser_id])
      if c.valid?
       c.save
       s_flag = true
            users += c.formsubmission.user.full_name.to_a
      else
            err_users += c.formsubmission.user.full_name.to_a
       e_flag = true
       end
       flash.now[:notice] = "Form for #{users.to_sentence} submitted to Committee #{c.committee.name}<br/>" if s_flag == true
       flash.now[:error] = "Form for #{err_users.to_sentence} not submitted to Committee #{c.committee.name}" if e_flag == true
     end
  else
      flash.now[:error] = "Select Form(s) to submit to Committee"
  end
  else
      flash.now[:error] = "Select Committee to submit Form(s)"
  end
end

def add_priority
    prev_priorities = Formsubmission.find(:all,:conditions=>['priority is NOT NULL']).collect{|x| x.priority} #To find existing  priority numbers
    @prior_val = params[:value].to_i
    current_formid  = params[:id]
    form_sub = Formsubmission.find(params[:id])
    if prev_priorities.include?(@prior_val) && form_sub.priority != @prior_val && @prior_val != 0 #To check if entered priority is already been given for any other form
    high_priorities = Formsubmission.find(:all,:conditions=>['priority is NOT NULL and priority >= ?',@prior_val])
        high_priorities.each do |highpriority|
          hp = highpriority.priority+1
          highpriority.update_attributes(:priority=>hp)
        end
    form_sub.update_attributes(:priority=>@prior_val)
    @office = Office.find(session[:office_id])
    @committees = Committee.find :all
	 @list_forms = Formsubmission.paginate :per_page =>10,:page=>params[:page],:conditions =>['office_id = ? and is_draft = ? and submitted_date is not NULL',@office.id,false],:order =>params[:sort],:include=>[:user]	  
render :update do |page|
       page.replace "priority_#{form_sub.id}","<span id='priority_#{form_sub.id}' title='Click to edit'>#{@prior_val}</span><script type='text/javascript'>
//<![CDATA[
new Ajax.InPlaceEditor('priority_#{form_sub.id}', '/office/add_priority/#{form_sub.id}', {size:10})
//]]>
</script>"
      high_priorities.each do |highpriority|
        page.replace "priority_#{highpriority.id}","<span id='priority_#{highpriority.id}' title='Click to edit'>#{highpriority.priority}</span><script type='text/javascript'>
//<![CDATA[
new Ajax.InPlaceEditor('priority_#{highpriority.id}', '/office/add_priority/#{highpriority.id}', {size:10})
//]]>
</script>"
      end 
   end
   else
      form_sub.update_attributes(:priority=>@prior_val)
      render :text => form_sub.priority   
    end
end

def send_email
    if session[:office_id] && (session[:officeadmin_id])
      office_member = Officeadmin.find(session[:officeadmin_id])
    else
      office_member = Officeadmin.find(session[:officeuser_id])
    end  
    user_ids = Formsubmission.find(:all,:conditions=>['id in (?)',params[:formslist]]).collect{|x|x.user_id}.uniq
    recipients_emails = User.find(:all,:conditions=>['id in (?)',user_ids]).collect{|x|x.email}
    for email in recipients_emails
      OfficeadminMailer.deliver_form_submitters(office_member,email)
    end
    
    if request.xml_http_request?
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html 'flashnotice',"E-mail sent to user(s)"
          page.visual_effect :highlight,'flashnotice',:duration => 1.5
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
    else 
        render :action=> "list_forms"      
    end
end 

def officemembers_send_email
   unless params[:office_admin_user].nil?
    if session[:admin_id]
      admin = Admin.find(session[:admin_id])
    end  
    officemembers_emails = Officeadmin.find(:all,:conditions=>['id in (?)',params[:office_admin_user]]).collect{|x|x.email}
    for email in officemembers_emails
      AdminNotifier.deliver_sendmail_officemembers(admin,email)
    end
    flash.now[:notice] = "E-mail sent to Office Member(s)"
    flash.now[:error] = ""
  else
    flash.now[:error] = "Select Office Member(s) to send E-mail"
  end
end  

def delete_followup_field
   @followup_field = FollowupField.find(params[:id])
  @followup_field.destroy
   @office = Office.find(session[:office_id])
   @followup_fields = @office.followup_fields
   render :update do |page|
      page.replace_html "list_followup_field", :partial => "list_followup_field", :locals =>{:followup_fields=>@followup_fields}
    end
  end 
  
 def help_text
   @office = Office.find(session[:office_id])
   return unless request.post?
   @office = Office.find(session[:office_id])
   if !params[:office][:help_text].empty? || !params[:office][:help_text].blank?
   @office.update_attributes(:help_text=>params[:office][:help_text])
   flash.now[:notice] = "Successfully updated."
   else
     flash.now[:error] = "Form Help text cannot be blank"
   end  
 end   

end
