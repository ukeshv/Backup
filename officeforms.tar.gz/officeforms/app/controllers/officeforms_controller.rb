class OfficeformsController < ApplicationController
	
def g_checkout_callback
 fn = File.open(RAILS_ROOT + "/public/g1.txt",'a')
 fn.write("#{params.inspect} PARAMS \n") 
 fn.write("OVER \n") 
 fn.close
 render :nothing=>true
end	
end
