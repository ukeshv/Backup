class OrgtypeController < ApplicationController
	before_filter :check_admin_officeadmin
	layout 'newadmin',:except=>[:new,:show,:edit]
	protect_from_forgery :except=>[:new,:show,:edit]
	require 'csv'
	
    def index
    end
    
  def list
	  
	  
	   if !params["inactive_all.x"].nil?         
      if !params[:org_type].nil?
        params[:org_type].each {|x|          
          inactive_org_type = Organization.find(x)
          inactive_org_type.update_attributes(:delete_status=>false)
          flash[:notice] ="The Selected Organizations Are Inactivated"
        }           
      end
    end
    if !params["active_all.x"].nil?   
      if !params[:org_type].nil?
        params[:org_type].each {|x|
          active_org_type = Organization.find(x)   
          active_org_type.update_attributes(:delete_status=>true)
          flash[:notice] ="The Selected Organizations Are Activated"
        }            
      end
  end
  sort_org_type
  end
  
  
  
  def sort_org_type
		session[:organization_search] = false
 	 @org_type = Organization.paginate(:all,:order =>params[:sort],:per_page =>10,:page=>params[:page])      
    if request.xml_http_request?
       render :update do |page|	
	   page.replace_html"list_org_type",:partial=>"org_type_list"
       end
    end
  end

  def org_search
		session[:organization_search] = true
		if !params[:search_txt].blank?
		@org_type = Organization.paginate(:conditions=>["(name like '%%"+params[:search_txt].to_s+"%%')"], :per_page => 10, :page => params[:page], :order=>params[:sort])          
			if @org_type.empty?
			@org_type = Organization.paginate(:all,:per_page =>10,:page=>params[:page], :order=>params[:sort])
				render :update do |page|
					page.replace_html "list_org_type",:partial=>'org_type_list'
					page.show('flasherror') if params[:sort].nil?
					page.replace_html 'flasherror',"Your Search produced no results for #{params[:search_txt]}" if params[:sort].nil?
					page.visual_effect :fade,'flasherror',:duration => 1.5 if params[:sort].nil?
				end	
			else
				render :update do |page|
					page.replace_html "list_org_type",:partial=>'org_type_list'
					page.show('flashnotice') if params[:sort].nil?
					page.replace_html 'flashnotice',"Your Search results for #{params[:search_txt]}" if params[:sort].nil?
					page.visual_effect :fade,'flashnotice',:duration => 1.5 if params[:sort].nil?
				end
			end
		else
			@org_type = Organization.paginate(:all,:per_page =>10,:page=>params[:page], :order=>params[:sort])
				render :update do |page|
					page.replace_html "list_org_type",:partial=>'org_type_list'
					page.show('flasherror') if params[:sort].nil?
					page.replace_html 'flasherror',"Provide search text" if params[:sort].nil?
					page.visual_effect :fade,'flasherror',:duration => 1.5 if params[:sort].nil?
		    end	
		end
  end


  def new
	   @org_type = Organization.new
   end


def create
	@org_type = Organization.new(params[:org_type])
	if  @org_type.save
		    @org_type = Organization.paginate(:all,:order=>params[:sort],:per_page =>10,:page=>params[:page])
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html"list_org_type",:partial=>"org_type_list"
          page.replace_html 'flashnotice',"New Organization Is Created"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end
	else
		render :update do |page|
			for h in @org_type.errors
        if !@org_type.errors["#{h[0]}"].nil?
              page.show "#{h[0]}_org_type"              
              page.replace_html "#{h[0]}_org_type","#{h[1]}"
        end          
              page.hide "name_org_type" if @org_type.errors['name'].nil?
        end
			end
	end
end	  

def show
	@org_type = Organization.find(params[:id])
end	  

    def edit
		@org_type = Organization.find(params[:id])
	end
 
    def update
		@org_type = Organization.find(params[:id])
	 if @org_type.update_attributes(params[:org_type])
			@org_type = Organization.paginate(:all,:order=>params[:sort],:per_page =>10,:page=>params[:page])
        render :update do |page|
          page.hide 'modal_container'
          page.hide 'modal_overlay'
          page.replace_html"list_org_type",:partial=>"org_type_list"
          page.replace_html 'flashnotice',"Organisation is Updated"
          page.visual_effect :fade,'flashnotice',:duration => 1.5
        end 
	 else
		render :update do |page|
			for h in @org_type.errors
        if !@org_type.errors["#{h[0]}"].nil?
              page.show "#{h[0]}_org_type"              
              page.replace_html "#{h[0]}_org_type","#{h[1]}"
        end          
              page.hide "name_org_type" if @org_type.errors['name'].nil?
        end
			end
	end
	end
  
    def inactive
		@org_type = Organization.find(params[:id])
		@org_type.update_attributes(:delete_status => true)	 
	render :update do |page|
      page.hide "orginactivestatus_#{@org_type.id}"  
      page.show "orgactivestatus_#{@org_type.id}" 
      page.show 'flashnotice'      
      page.replace_html 'flashnotice',"Organization Is Activated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end
    end	  
  
    def active
	    @org_type = Organization.find(params[:id])
        @org_type.update_attributes(:delete_status => false)	 
		render :update do |page|
      page.hide "orgactivestatus_#{@org_type.id}"  
      page.show "orginactivestatus_#{@org_type.id}"  
      page.show 'flashnotice'
      page.replace_html 'flashnotice',"Organization Is Inactivated"
      page.visual_effect :highlight,'flashnotice',:duration => 1.5
      page.visual_effect :fade,'flashnotice',:duration => 1.5
    end
  end
  
  
  
  def export_org_type
			if !params[:org_type].nil?
	  @org_type = Organization.find(:all,:conditions=>['id in (?)',params[:org_type]])
	elsif session[:organization_search] == true
	  @org_type = Organization.find(:all,:conditions=>["(name like '%%"+params[:search_txt].to_s+"%%')"])	
		@org_type = Organization.find(:all) if @org_type.empty?	
	else
	  @org_type = Organization.find(:all)
	end  
		
   
    report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
      csv << %w(Name
		Status
		)
        
      @org_type.each do |org_type|
          
      	status = (org_type.delete_status == true ? "Active" : "Inactive")

          
        csv << [org_type.name,
		status]
      end
    end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'org_type.csv')

  end
end
