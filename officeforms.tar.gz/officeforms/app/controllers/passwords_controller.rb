class PasswordsController < ApplicationController
	 layout 'newhome',:except=>[:new_admin,:create_admin,:edit_admin,:update_admin] 
   
   # Enter email address to recover password 
   def new
   end
  
   # Forgot password action
   def create    
     return unless request.post?
   if @user = User.find_for_forget(params[:email])
       @user.forgot_password
       @user.save      
       flash[:notice] = "A password reset link has been sent to your email address."
     redirect_to login_path
     else
       flash.now[:error] = "Could not find a user with that email address."
       render :action => 'new'
     end  
   end
   
   # Action triggered by clicking on the /reset_password/:id link recieved via email
   # Makes sure the id code is included
   # Checks that the id code matches a user in the database
   # Then if everything checks out, shows the password reset fields
   def edit
     if params[:id].nil?
       render :action => 'new'
       return
     end
     @user = User.find_by_password_reset_code(params[:id]) if params[:id]
     raise if @user.nil?
   rescue
     logger.error "Invalid Reset Code entered."
     flash[:notice] = "Sorry - That is an invalid password reset code. Please check your code and try again. (Perhaps your email client inserted a carriage return?)"
 #redirect_back_or_default('/')
     redirect_to login_path
   end
     
   # Reset password action /reset_password/:id
   # Checks once again that an id is included and makes sure that the password field isn't blank
   def update
     if params[:id].nil?
       render :action => 'new'
       return
     end
     if params[:password].blank?
       flash[:error] = "Password field cannot be blank."
       render :action => 'edit', :id => params[:id]
       return
     end
     @user = User.find_by_password_reset_code(params[:id]) if params[:id]
     raise if @user.nil?
     return if @user unless params[:password]
	if (params[:password] == params[:password_confirmation])
		@user.password_confirmation = params[:password_confirmation]
		@user.password = params[:password]
		@user.skip_pwd = 1
		if @user.save
			@user.reset_password        
			flash[:notice] = "Password reset."
		else
			flash[:error] = "Password Should be of length 8 and contain atleast one integer."
			render :action => 'edit', :id => params[:id]
			return
		end  	
	else
		flash[:error] = "Password mismatch."
		render :action => 'edit', :id => params[:id]
	return
	end
      redirect_to login_path
   rescue
     logger.error "Invalid Reset Code entered"
     flash[:error] = "Sorry - That is an invalid password reset code. Please check your code and try again"
     redirect_to login_path
   end
   
    # Enter email address to recover password office_admin
   def new_admin
   end
   
   # Forgot password action for office_admin
   def create_admin    
     return unless request.post?
   if @officeadmin = Officeadmin.find_for_forget(params[:email])
       @officeadmin.forgot_password
       @officeadmin.save      
       OfficeadminMailer.deliver_forgot_password(@officeadmin) 
       flash[:notice] = "A password reset link has been sent to your email address."
     redirect_to :controller=>'office_admin', :action=>'login'
     else
       flash.now[:error] = "Could not find a user with that email address."
       render :action => 'new_admin'
     end  
   end
   
   # Action triggered by clicking on the /reset_password/:id link recieved via email
   # Makes sure the id code is included
   # Checks that the id code matches a user in the database
   # Then if everything checks out, shows the password reset fields
   def edit_admin
     if params[:id].nil?
       render :action => 'new_admin'
       return
     end
     @officeadmin = Officeadmin.find_by_password_reset_code(params[:id]) if params[:id]
     raise if @officeadmin.nil?
   rescue
     logger.error "Invalid Reset Code entered."
     flash[:notice] = "Sorry - That is an invalid password reset code. Please check your code and try again. (Perhaps your email client inserted a carriage return?)"
 #redirect_back_or_default('/')
     redirect_to :controller=>'office_admin', :action=>'login'
   end
     
   # Reset password action /reset_password/:id
   # Checks once again that an id is included and makes sure that the password field isn't blank
   def update_admin
     if params[:id].nil?
       render :action => 'new_admin'
       return
     end
     if params[:password].blank?
       flash[:error] = "Password field cannot be blank."
       render :action => 'edit_admin', :id => params[:id]
       return
     end
     @officeadmin = Officeadmin.find_by_password_reset_code(params[:id]) if params[:id]
     raise if @officeadmin.nil?
     return if @officeadmin unless params[:password]
       if (params[:password] == params[:password_confirmation])
     @officeadmin.password_confirmation = params[:password_confirmation]
     @officeadmin.password = params[:password]
     @officeadmin.reset_password        
     flash[:notice] = @officeadmin.save ? "Password reset." : "Password not reset."
     OfficeadminMailer.deliver_reset_password(@officeadmin) 
=begin     
		unless !@officeadmin.save?
			flash[:notice] ="Password reset."   
			OfficeadminMailer.deliver_reset_password(@officeadmin) 
		else
			flash[:notice]="Password not reset."	
		end
=end		
       else
         flash[:error] = "Password mismatch."
         render :action => 'edit_admin', :id => params[:id]
       return
       end  
       redirect_to :controller=>'office_admin', :action=>'login'
   rescue
     logger.error "Invalid Reset Code entered"
     flash[:error] = "Sorry - That is an invalid password reset code. Please check your code and try again"
     redirect_to :controller=>'office_admin', :action=>'login'
   end

end
