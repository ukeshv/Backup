# This controller handles the login/logout function of the site.  
class SessionsController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
    before_filter :authorizeduser,:except=>[:new,:create]
    include AuthenticatedSystem
    protect_from_forgery :except=>[:create]
    layout 'newhome'  
  # render new.rhtml
  def new
  end

  def create
    self.current_user = User.authenticate(params[:email], params[:password])
    if !params[:email].blank? || !params[:password].blank?
    if logged_in?
      session[:user_id] = current_user.id
      if session[:return_to]    
      redirect_to session[:return_to]
      else        
      redirect_to(:controller=>'users',:action=>'dashboard')
      end
      flash[:notice] = "Logged in successfully"
    else
	flash.now[:error] = "Invalid Email/Password"	    
      render :action => 'new'
    end
    else
	flash.now[:error] = "Enter Email and Password"	    
      render :action => 'new'
    end
  end

  def destroy
   user = current_user
    user.update_attribute(:last_loggedin,Time.now)
    self.current_user.forget_me if logged_in?
    cookies.delete :auth_token
    session[:user_id] = nil
    reset_session
    flash[:notice] = "You have been logged out."
    redirect_to(:controller=>'sessions',:action=>'new')
  end
end
