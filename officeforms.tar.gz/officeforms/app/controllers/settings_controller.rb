class SettingsController < ApplicationController
  before_filter :check_admin_officeadmin
  layout 'newadmin'
  protect_from_forgery :except=>[:view_default_form]
  def index
  end
  
def view_default_form
@default_form = Defaultform.find :first
    return unless request.post?
  if @default_form.update_attributes(params[:default_form])
    flash.now[:notice] = "Default Form Settings has been updated"
		else
				flash.now[:error] = "Default Form Settings has not been updated"
				render :action=>'view_default_form'
		end
end	
 
end
