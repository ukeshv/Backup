class UsersController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  before_filter :authorizeduser, :except=>[:new,:create,:activate,:officelist,:search_office,:flashupload_whitepaper]
  include AuthenticatedSystem
  layout :change_layout  ,:except=>[:help_text,:agency_help_text]
  require 'csv'
  protect_from_forgery :except=>[:create,:update,:edit_form,:flashupload_whitepaper,:update_formvalues,:confirm_formsubmission,:help_text,:agency_help_text]
  session :cookie_only => false, :only => [:flashupload_whitepaper]

  # render new.rhtml
  def new
  end


  def create
    cookies.delete :auth_token
    @user = User.new(params[:user])
    @user.active_status = true
    @user.skip_pwd = 1
    if @user.valid_with_captcha? 
      @user.save
      if @user.errors.empty?
        UserMailer.deliver_signup_notification(@user)
        redirect_to login_path
        flash[:notice] = "Thanks for signing up!Activation link has been sent to your mail..Click on the link to activate your account."
      else
        render :action => 'new'
      end
    else
      flash.now[:error] = "Mismatch in Captcha"
      render :action => 'new'
    end
  end


  def activate
    self.current_user = params[:activation_code].blank? ? false : User.find_by_activation_code(params[:activation_code])
    if logged_in? && !current_user.active?
      current_user.activate
      flash[:notice] = "Your account has been activated.Login Now !"
    end
    redirect_to(:action=>'dashboard')
  end


  def dashboard
   sort_forms	  
  end

  def sort_forms
	@form_submissions = Formsubmission.paginate :page=>params[:page],:per_page=>10,:conditions=>['user_id = ?',current_user.id],:order =>params[:sort],:include=>[:office=>:officeform]
	if request.xml_http_request?
		render :update do |page|
			page.replace_html "users_dashboard", :partial=>'user_dashboard'
		end	
	end
  end

def delete_form_dash
	  @dash_form = Formsubmission.find(params[:id])
          @dash_form.destroy 
	  flash[:notice]="Formsubmission has been deleted from draft"
   	redirect_to :action=>'dashboard'
	end

  def office_list
  officeforms_officeids = Officeform.find(:all,:conditions=>['submission_end_date is NOT NULL']).collect{|x| x.office_id}
  @offices = Office.paginate :order =>params[:sort], :page=>params[:page],:per_page=>10,:conditions=>['active_status = ? and id in (?)',true,officeforms_officeids]
    if request.xml_http_request?
      render :update do |page|      
      page.replace_html "office",:partial=>'list_offices'
    end			
  end
end

  def officelist
  officeforms_officeids = Officeform.find(:all,:conditions=>['submission_end_date is NOT NULL']).collect{|x| x.office_id}
  @offices = Office.paginate :order =>params[:sort], :page=>params[:page],:per_page=>10,:conditions=>['active_status = ? and id in (?)',true,officeforms_officeids]
    if request.xml_http_request?
      render :update do |page|      
      page.replace_html "officelist",:partial=>'offices_list'
    end			
  end
end

def office_search
  officeforms_officeids = Officeform.find(:all,:conditions=>['submission_end_date is NOT NULL']).collect{|x| x.office_id}
  if !params[:search].nil?
    @offices = Office.paginate(:conditions=>["((name like '%%"+params[:search].to_s+"%%') or (firstname like '%%"+params[:search].to_s+"%%') or (lastname like '%%"+params[:search].to_s+"%%')) and id in (?)",officeforms_officeids], :per_page => 10, :page => params[:page])          
    flash.now[:notice] = "Your Search Results for #{params[:search]}"	
      if @offices.empty?
        @offices = Office.paginate :order =>params[:sort], :page=>params[:page],:per_page=>10,:conditions=>['active_status = ? and id in (?)',true,officeforms_officeids]
        flash.now[:notice] = "Your Search Produced No Results"	
        render :action=> "office_list"
      else
        render :action=> "office_list"
      end
  end
end

def search_office
  officeforms_officeids = Officeform.find(:all,:conditions=>['submission_end_date is NOT NULL']).collect{|x| x.office_id}
  if !params[:search].nil?
    @offices = Office.paginate(:conditions=>["(name like '%%"+params[:search].to_s+"%%') or (firstname like '%%"+params[:search].to_s+"%%') or (lastname like '%%"+params[:search].to_s+"%%')"], :per_page => 10, :page => params[:page])          
    flash.now[:notice] = "Your Search Results for #{params[:search]}"	
      if @offices.empty?
        @offices = Office.paginate :order =>params[:sort], :page=>params[:page],:per_page=>10,:conditions=>['active_status = ? and id in (?)',true,officeforms_officeids]
        flash.now[:notice] = "Your Search Produced No Results"	
        render :action=> "officelist"
      else
        render :action=> "officelist"
      end
  end
end

  def manage_forms
    @user = current_user
    @office = Office.find(params[:id])
    sort_manageforms
  end

  def sort_manageforms
 @form_submissions = Formsubmission.paginate :page=>params[:page],:per_page=>10,:conditions=>['user_id = ? and formsubmissions.office_id = ?',current_user.id,@office.id],:order =>params[:sort],:include=>[:office=>:officeform]
	if request.xml_http_request?
		render :update do |page|
			page.replace_html "manageforms", :partial=>'manageforms'
		end	
	end
  end

def delete_form
	  @manage_form = Formsubmission.find(params[:id])
          @manage_form.destroy 
	  flash[:notice]="Formsubmission has been deleted from draft"
   	redirect_to :action=>'manage_forms',:id=>@manage_form.office_id
	end

 def upload_whitepaper
    unless params[:whitepaper_upload].nil?
      unless params[:whitepaper_upload][:uploaded_data].blank?
        @whitepaper_upload = @form_submission.create_whitepaper_upload(params[:whitepaper_upload])
      end
    end
  end

#To check if the uploaded file size is less than 2 MB and content type is doc or pdf.
  def whitepaper_invalid 
    @whitepaper_upload=WhitepaperUpload.new(params[:whitepaper_upload])
    if @whitepaper_upload.valid?
      return false
    else
      return true
   end 
  end  

#To preview the summary of the submitted form, but saved as draft only.Not submitted.After confirmation only, form gets saved.
  def formpreview
    if Formsubmission.exists?(params[:id])
      @form_submission = Formsubmission.find(params[:id])
      @office_form = @form_submission.office.officeform
      @custom_values =  CustomValue.find :all,:conditions=>['formsubmission_id = ? and custom_fields.active_status = ?',@form_submission.id,true],:include=>[:custom_field]    
      agency = Agency.find_by_name(@form_submission.agency_name) if !@form_submission.agency_name.blank? || !@form_submission.agency_name.nil?
      @agency_custom_values =  agency.nil? ? [ ] : (AgencyCustomValue.find :all,:conditions=>['formsubmission_id = ? and agency_custom_fields.agency_id = ? and agency_custom_fields.active_status = ?',@form_submission.id,agency.id,true],:include=>[:agency_custom_field])    
      if !@form_submission.submitted_date.nil?
        redirect_to(:action=>'office_list')
      end
    else
      redirect_to(:action=>'office_list')
    end
  end


#To Update Agency Accounts drop down, Based on selection of Agency . Called through Javascript
  def change_agencyaccounts
    @agency = Agency.find_by_name(params[:t1])
    @agency_accounts = Agencyaccount.find(:all,:conditions=>['agency_id = ?',@agency.id])
    render :update do |page|
      page.replace_html "list_agencyaccounts",:partial=>'list_agencyaccounts'
    end
  end


#To Update Agency Sub Accounts drop down, Based on selection of Agency Account . Called through Javascript
  def change_agency_subaccounts
    @agency_account = Agencyaccount.find_by_name(params[:t2])
    @agency_subaccounts = Agencyaccount.sub_account(@agency_account.id)
    render :update do |page|
      page.replace_html "list_agency_subaccounts",:partial=>'list_agency_subaccounts'
    end
  end


#To Edit the profile details of an logged in User
  def edit_profile
    @user = current_user
  end


#To update the profile details of an logged in User
  def update
    @user = current_user
    if @user.update_attributes(params[:user])
      flash[:notice] = "Profile Updated successfully"
      redirect_to :action =>'edit_profile'
    else
      render :action =>'edit_profile'
    end
  end


#To show the summary of the submitted form
  def formsummary
    @user = current_user
    if Formsubmission.exists?(params[:id])
      @form_submission = Formsubmission.find(params[:id])
      @office_form = @form_submission.office.officeform  
      @custom_values =  CustomValue.find :all,:conditions=>['formsubmission_id = ? and custom_fields.active_status = ?',@form_submission.id,true],:include=>[:custom_field]   
      agency = Agency.find_by_name(@form_submission.agency_name)  if !@form_submission.agency_name.blank? || !@form_submission.agency_name.nil?
      @agency_custom_values =  agency.nil? ? [ ] : (AgencyCustomValue.find :all,:conditions=>['formsubmission_id = ? and agency_custom_fields.agency_id = ? and agency_custom_fields.active_status = ?',@form_submission.id,agency.id,true],:include=>[:agency_custom_field] ) 
      unless @form_submission.user_id == current_user.id && !@form_submission.submitted_date.nil? #To check if Form is submitted by this user or not
	redirect_to(:action=>'office_list')
      end
    else
      redirect_to(:action=>'office_list')
    end
   end

def submit_newform
  office = Office.find_by_name(params[:officename])
  session[:is_uploaded] = nil
  session[:formid] = nil
  end_date = ( office.officeform.submission_end_date.to_date > Date.today ? true : false)
  show_details = office.officeform.active_status
  if show_details && end_date
  redirect_to(:controller=>'users',:action=>'edit_form',:id=>office.id,:id1=>office.officeform.id) 
  else
  redirect_to(:controller=>'users',:action=>'manage_forms',:id=>office.id) 
  end
end

  def flashupload_whitepaper
      @form = Formsubmission.find(params[:id])
			@whitepaper_upload = @form.create_whitepaper_upload(:uploaded_data => params[:Filedata])
      filelocation = @whitepaper_upload.public_filename
      system "clamscan -r #{filelocation}"
      a = `clamscan -r #{filelocation}`
      if a.scan(/Infected files:(.*)Data scanned/m).to_s.strip == 1
        @whitepaper_upload.destroy
        flash[:error] = "You have uploaded a infected file"
        redirect_to(:controller=>'users',:action=>'edit_form',:id=>@form.office.id,:id1=>@form.office.officeform.id)
      else
        session[:whitepaper_upload] = @whitepaper_upload.id if !@whitepaper_upload.nil?
        render :nothing => true
      end  
 end  

  def edit_form
    session[:is_uploaded] = nil
    unless params[:id1] #after submitting form,it comes here ... When form is saved as draft and opened again for submitting
      @form_submission = Formsubmission.find(params[:id])
      @office_form = @form_submission.office.officeform
      @custom_fields = CustomField.find(:all,:conditions=>['office_id = ? and active_status = ?',@form_submission.office.id,true])
      session[:formid] = @form_submission.id if session[:formid].nil?
      if @form_submission.agency_name.blank? && params[:form_submission].blank?
        @agency_custom_fields = [ ]
      elsif !@form_submission.agency_name.blank? && params[:form_submission].blank? 
        @agency = Agency.find_by_name(@form_submission.agency_name)      
        @agency_custom_fields = AgencyCustomField.find(:all,:conditions=>['agency_id = ? and active_status = ?',@agency.id,true])
      elsif !params[:form_submission][:agency_name].blank?      
        @agency = Agency.find_by_name(params[:form_submission][:agency_name])      
        @agency_custom_fields = AgencyCustomField.find(:all,:conditions=>['agency_id = ? and active_status = ?',@agency.id,true])
      else 
        @agency_custom_fields = [ ]        
      end
    end
    
    if @form_submission.nil? #New Record save, if not exists already # first time when i click on link submit new form ..comes here
      @office = Office.find(params[:id]) if params[:id1]
      @form_submission = Formsubmission.create(:user_id=>current_user.id,:office_id=>@office.id,:is_draft=>1) if session[:formid].nil?
      session[:formid] = @form_submission.id if session[:formid].nil?
      @form_submission = Formsubmission.find(session[:formid]) unless session[:formid].nil?
      @office_form = @form_submission.office.officeform
      @custom_fields = CustomField.find(:all,:conditions=>['office_id = ? and active_status = ?',@office.id,true])
      
      #To be changed - temp code
      if !params[:form_submission].nil? && params[:form_submission][:agency_name] 
        agency_name = params[:form_submission][:agency_name]
        @agency = Agency.find_by_name(agency_name)
      elsif !@form_submission.nil? 
        @agency = Agency.find_by_name(@form_submission.agency_name)
      end         
      @agency_custom_fields = [ ]
      #@agency_custom_fields = AgencyCustomField.find(:all,:conditions=>['agency_id = ? and active_status = ?',@agency.id,true])
    end
      @false_ids = [ ]
      @agency_false_ids = [ ]
      @length_err_false_ids = [ ]
      @agency_length_err_false_ids = [ ]
      @customfields_status = [ ]
      @agencycustomfields_status = [ ]
      @agency = Agency.find(:first)
      @agency_account = Agencyaccount.find_by_agency_id(@agency.id) unless @agency.nil?
      set_checkbox_val #When edit_form page is loaded first time,radio buttons like is_lobby_list and is_funding_under_law should retain the vlaue from DB
      if @form_submission.user_id == current_user.id && @form_submission.submitted_date.nil?
    return unless request.post?
    session[:is_uploaded] = params[:is_uploaded]  
    @form_submission.attributes = params[:form_submission] #To retain the form values, if any error .
    if params["office_form_draft.x"].nil?
      @form_submission.off_form = @office_form
    end
    
    checkbox_val #Method called to retain values when any errors in form occurs
    whitepaper_errflag = false
    rep_status = true
    agency_status = true
    customfield_status = true
    agencycustomfield_status = true
    check_max_word_status = true
	if params["office_form_draft.x"].nil?
      if params[:check_yes_no_lobbylist].to_i == 1 && @office_form.representative_section == true
    	 rep_status = representative_fieldscheck      
     end
     if params[:check_yes_no_fund_pe].to_i == 1 && @office_form.agency_section == true
    	 agency_status = agency_fieldscheck      
     end
     customfield_status = customfields_check if !@custom_fields.empty?
     agencycustomfield_status = agencycustomfields_check if !@agency_custom_fields.empty?
     check_max_word_status = check_max_word
     end
      
        unless params["office_form.x"].nil?
          if @office_form.white_paper == true && @office_form.project_section == true
            if params[:is_uploaded].blank? || params[:is_uploaded].empty?
              whitepaper_errflag = true    
               flash.now[:error1] = "Upload White Paper"
              end
          end
        end


        if whitepaper_errflag == false

              if rep_status == true && customfield_status == true && agencycustomfield_status == true
                if check_max_word_status == true
                    if @form_submission.update_attributes(params[:form_submission])
                    save_lobby_list #To save the yes / no value of is_lobby_list in representative section
                    save_is_funding_under_law #To save the yes / no value of is_funding_under_law in project section
                    save_is_fund_pe #To save the yes / no value of fund_pe in agency section
                    #upload_whitepaper #Method to Upload a white paper for Project Section
                    save_customfields #If office(s) has custom fields and requires values to be entered by public user and saved in CustomValue table.
                    save_agencycustomfields #If office(s) has custom fields and requires values to be entered by public user and saved in AgencyCustomValue table.
                          if params["office_form_draft.x"].nil?
                          session[:formid] = nil
                          session[:is_uploaded] = nil    
                          redirect_to(:action=>'formpreview',:id=>@form_submission.id)    
                          else
                          session[:formid] = nil
                          session[:is_uploaded] = nil
                          flash[:notice] = "Office Form Saved as Draft"
                          redirect_to(:controller=>'users',:action=>'manage_forms',:id=>@form_submission.office.id)    
                          end
                    else #for form_submission update_attributes
                    render :action => 'edit_form',:id=>@office_form.id
                    end
                else #for check_max_word_status
                    render :action => 'edit_form',:id=>@office_form.id
                end  
              else #for rep_status
              render :action => 'edit_form',:id=>@office_form.id
              end
        else #for whitepaper_errflag
        render :action => 'edit_form',:id=>@office_form.id
        end
      else #If Form Submissions user id does not match with the current user id.
        redirect_to(:action=>'office_list')
      end
   end

def customfields_check
  @net_customfields = @custom_fields.collect{|x|x.id }
  @active_customfields =  params[:custom_field].collect{|x| (x[0].split('_'))[2].to_i}
  @radio_customfields = @net_customfields - @active_customfields
  @radio_customfields.each do |radio_customfield|
    mandatory = CustomField.find(radio_customfield).is_mandatory
    @false_ids << radio_customfield if mandatory == true
    @customfields_status << false if mandatory == true
  end

   params[:custom_field].each do |customfield|
      split_customfield = customfield[0].split('_')
       customfieldid = split_customfield[2]
       
       cv = CustomValue.find_or_create_by_custom_field_id_and_formsubmission_id(customfieldid,@form_submission.id)
       cv.save_customvalue_version = true
       unless (CustomField.find(customfieldid).is_length_enabled && customfield[1].gsub(/\s+/," ").strip.count(" ") >= CustomField.find(customfieldid).max_length)
           if cv.update_attributes(:field_value=>customfield[1])
            @customfields_status << true
           else
            @false_ids << customfieldid
            @customfields_status << false 
           end  
        else
          @length_err_false_ids << customfieldid
          @customfields_status << false 
        end  
   end 
    if @customfields_status.include?(false)
      return false
    else
      return true  
    end  
end

def agencycustomfields_check
  @net_agencycustomfields = @agency_custom_fields.collect{|x|x.id }
  @active_agencycustomfields =  params[:agency_custom_field].collect{|x| (x[0].split('_'))[2].to_i}
  @radio_agencycustomfields = @net_agencycustomfields - @active_agencycustomfields
  @radio_agencycustomfields.each do |radio_agencycustomfield|
    mandatory = AgencyCustomField.find(radio_agencycustomfield).is_mandatory
    @agency_false_ids << radio_agencycustomfield if mandatory == true
    @agencycustomfields_status << false if mandatory == true
  end

   params[:agency_custom_field].each do |agencycustomfield|
      split_agencycustomfield = agencycustomfield[0].split('_')
       agencycustomfieldid = split_agencycustomfield[2]
       
       cv = AgencyCustomValue.find_or_create_by_agency_custom_field_id_and_formsubmission_id(agencycustomfieldid,@form_submission.id)
       cv.save_agencycustomvalue_version = true
       unless (AgencyCustomField.find(agencycustomfieldid).is_length_enabled && agencycustomfield[1].gsub(/\s+/," ").strip.count(" ") >= AgencyCustomField.find(agencycustomfieldid).max_length)
           if cv.update_attributes(:field_value=>agencycustomfield[1])
            @agencycustomfields_status << true
           else
            @agency_false_ids << agencycustomfieldid
            @agencycustomfields_status << false 
           end  
        else
          @agency_length_err_false_ids << agencycustomfieldid
          @agencycustomfields_status << false 
        end  
   end 
    if @agencycustomfields_status.include?(false)
      return false
    else
      return true  
    end  
end

def save_is_fund_pe
  @form_submission.update_attributes(:fund_pe => params[:check_yes_no_fund_pe])
end

def save_lobby_list
  @form_submission.update_attributes(:is_lobby_list => params[:check_yes_no_lobbylist])
end

def save_is_funding_under_law
  @form_submission.update_attributes(:is_funding_under_law => params[:check_yes_no_fund_underlaw])
end

def set_checkbox_val
    @rep_is_lobbylist = @form_submission.is_lobby_list
    @fund_is_underlaw = @form_submission.is_funding_under_law
    @fund_is_pe = @form_submission.fund_pe
end

 #Method called to retain values when any errors in form occurs
  def checkbox_val
    @contact_same_address_as_org = params[:contact_form_same_org_address] #To retain the checkbox value for Contact section
    @sr_contact_same_address_as_org = params[:sr_contact_form_same_org_address] #To retain the checkbox value for Senior Contact section
    @rep_is_lobbylist = params[:check_yes_no_lobbylist] #To retain the radio buton value for Is Lobby List in Representative Section
    @fund_is_underlaw = params[:check_yes_no_fund_underlaw] #To retain the radio buton value for Is Funding Under Law in Project Section
    @fund_is_pe = params[:check_yes_no_fund_pe] #To retain the radio buton value for Is Funding PE in Agency Section
  end


  def agencyname_val # No Need
    unless params[:form_submission][:agency_name].blank?
      @sel_agency = params[:form_submission][:agency_name] #To get the selected Agency name 
      agency =  Agency.find_by_name(@sel_agency)  #To get the selected Agency id
      @agency_accounts = Agencyaccount.find(:all,:conditions=>['agency_id = ?',agency.id]) #To get the Agency Accounts of selected Agency name 
    end
  end


  def agencyaccount_val # No Need
    unless params[:form_submission][:agency_account].blank?
      @sel_agencyaccount = params[:form_submission][:agency_account] #To get the selected Agency Account name 
      agency_account = Agencyaccount.find_by_name(@sel_agencyaccount)  #To get the selected Agency Account id
      @agency_subaccounts = Agencyaccount.sub_account(agency_account.id) #To get the Agency Sub Accounts of selected Agency Account name 
    end
  end

  def save_customfields
  unless params[:custom_field].nil?
    params[:custom_field].each do |customfield|
      split_customfield = customfield[0].split('_')
       customfieldid = split_customfield[2]
       cv = CustomValue.find_or_create_by_custom_field_id_and_formsubmission_id(customfieldid,@form_submission.id)
       cv.save_customvalue_version = true
       cv.update_attributes(:field_value=>customfield[1])
    end
    end
  end

  def save_agencycustomfields
  unless params[:agency_custom_field].nil?
    params[:agency_custom_field].each do |agencycustomfield|
      split_agencycustomfield = agencycustomfield[0].split('_')
       agencycustomfieldid = split_agencycustomfield[2]
       cv = AgencyCustomValue.find_or_create_by_agency_custom_field_id_and_formsubmission_id(agencycustomfieldid,@form_submission.id)
       cv.save_agencycustomvalue_version = true
       cv.update_attributes(:field_value=>agencycustomfield[1])
    end
    end
  end

#Method called to Submit the form finally after user's confirmation.
  def confirm_formsubmission
     @user = current_user
    @form_submission =  Formsubmission.find(params[:id])
    
    cv = CustomValue.find_all_by_formsubmission_id(@form_submission.id)
    cv.each do |x|
    custom_value_latest_version = x.versions.latest.version
    x.clear_old_version(custom_value_latest_version)
    end 
    
    acv = AgencyCustomValue.find_all_by_formsubmission_id(@form_submission.id)
    acv.each do |x|
    agency_custom_value_latest_version = x.versions.latest.version
    x.clear_old_version(agency_custom_value_latest_version)
    end 
    
    
    latest_version = @form_submission.versions.latest.version if !@form_submission.versions.empty?
    @form_submission.clear_old_version(latest_version) if !latest_version.nil?
    @form_submission.save_formsubmission_version = true    
    @form_submission.update_attributes(:submitted_date=>Time.now,:is_draft=>0)
    WhitepaperUploadVersion.find_all_versions(@form_submission.id)
     @custom_values =  CustomValue.find :all,:conditions=>['formsubmission_id = ? and custom_fields.active_status = ?',@form_submission.id,true],:include=>[:custom_field]    
      agency = Agency.find_by_name(@form_submission.agency_name) if !@form_submission.agency_name.blank? || !@form_submission.agency_name.nil?
      @agency_custom_values =  agency.nil? ? [ ] : (AgencyCustomValue.find :all,:conditions=>['formsubmission_id = ? and agency_custom_fields.agency_id = ? and agency_custom_fields.active_status = ?',@form_submission.id,agency.id,true],:include=>[:agency_custom_field])    
   UserMailer.deliver_form_submission(@form_submission,@user,@custom_values,@agency_custom_values)
    @office_users= Officeadmin.find(:all, :conditions => ["is_admin = ? and active_status = ? and receive_notifications = ? and office_id = ?", false, true, true, @form_submission.office_id ])
      if !@office_users.empty?
        for officeuser in @office_users
          OfficeadminMailer.deliver_submitnewform_notification_by_public_user(officeuser,@user,@form_submission.id)
        end
        end
    redirect_to(:action=>'office_list')
  end


#After Uploading White paper, User can download the same using this method.
  def download_whitepaper
    @form_submission = Formsubmission.find(params[:id])
    @whitepaper = @form_submission.whitepaper_upload
    filepath = @whitepaper.public_filename
    system "clamscan -r #{filepath}"
      a = `clamscan -r #{filepath}`
      if a.scan(/Infected files:(.*)Data scanned/m).to_s.strip == 1
        flash[:error] = "Download file has been infected"
        redirect_to(:action=>'dashboard')
      else
          if File.exists? filepath
          send_file filepath
          else
          redirect_to(:action=>'dashboard')
          end
      end  
   end


#Method called for Auto Save the form values through javascript
  def update_formvalues
    @form_submission = Formsubmission.find(params[:form_submission_val])
    @form_submission.update_attributes(params[:form_submission])
    @office_form = Officeform.find_by_office_id(@form_submission.office_id)
    save_customfields
    save_agencycustomfields
    render :nothing => true
  end


#List of Submitted Forms by Loggedin User
  def submitted_forms
    @user = current_user  
    form_submission = Formsubmission.find(:all,:conditions=>['user_id = ? and submitted_date is not NULL and is_draft = ?',current_user.id,0])
    office_ids = form_submission.collect{|x| x.office_id}
    @office_forms = Officeform.paginate :page=>params[:page],:per_page=>10,:conditions=>['officeforms.office_id in (?) and offices.active_status = ?',office_ids,true],:include=>[:office]
  end


#List of New Forms that can be submitted by Loggedin User
  def new_forms
    @user = current_user  
    form_submission = Formsubmission.find(:all,:conditions=>['user_id = ?',@user.id])
    office_ids = form_submission.collect{|x| x.office_id}
    unless office_ids.empty? || office_ids.blank?
      @office_forms = Officeform.paginate :page=>params[:page],:per_page=>10,:conditions=>['officeforms.office_id not in (?) and officeforms.active_status = ? and officeforms.submission_end_date > ? and offices.active_status = ?',office_ids,true,Date.today(),true],:include=>[:office]
    else
      @office_forms = Officeform.paginate :page=>params[:page],:per_page=>10,:conditions=>['officeforms.active_status = ? and officeforms.submission_end_date > ? and offices.active_status = ?',true,Date.today(),true],:include=>[:office]
    end
  end


#List of Forms that are saved as draft by Loggedin User
  def drafted_forms
    @user = current_user  
    form_submission = Formsubmission.find(:all,:conditions=>['user_id = ? and submitted_date is NULL and is_draft = ?',@user.id,1])
    office_ids = form_submission.collect{|x| x.office_id}
    @office_forms = Officeform.paginate :page=>params[:page],:per_page=>10,:conditions=>['officeforms.office_id in (?) and officeforms.active_status = ? and officeforms.submission_end_date > ? and offices.active_status = ?',office_ids,true,Date.today(),true],:include=>[:office]
  end

  def export_formsummary
    @user = current_user  
    @form_submission = Formsubmission.find(params[:id])  
    @custom_values =  CustomValue.find :all,:conditions=>['formsubmission_id = ? and custom_fields.active_status = ?',@form_submission.id,true],:include=>[:custom_field]      
    @agency_custom_values =  AgencyCustomValue.find :all,:conditions=>['formsubmission_id = ? and agency_custom_fields.active_status = ?',@form_submission.id,true],:include=>[:agency_custom_field]      
    report = StringIO.new
    
    CSV::Writer.generate(report, ',') do |csv|
	    
	@h1 = [ ]
	
        if @form_submission.office.officeform.organization_section == true    
        	@h1 +=    ['OrgType','OrgName','OrgAddress1','OrgAddress2','OrgCity','OrgState','OrgZip','OrgPhone','OrgFax','OrgActivities'] 
        end
     
        if @form_submission.office.officeform.contact_section == true    
		@h1 +=    ['ContactFirstname','ContactLastname','ContactEmail','ContactAddress1','ContactAddress2','ContactCity','ContactState','ContactZip','ContactPhone','ContactMobile'] 
	end	
      
	if @form_submission.office.officeform.sr_contact_section == true    
		@h1 +=    ['SeniorContactFirstname','SeniorContactLastname','SeniorContactEmail','SeniorContactAddress1','SeniorContactAddress2','SeniorContactCity','SeniorContactState','SeniorContactZip','SeniorContactPhone','SeniorContactMobile'] 
	end	
      
	if @form_submission.office.officeform.representative_section == true    
		@h1 +=    ['RepFirstname','RepLastname','RepFirmname','RepEmail','RepAddress1','RepAddress2','RepCity','RepState','RepZip','RepPhone','RepMobile'] 
	end	
	

        if @form_submission.office.officeform.project_section == true  	
		@h1 += ['ProjectDescription','Significance','ExpansionDescription','FundlawDescription','Endorsements','TotalCost','AmountRequested']
	end
	
        if @form_submission.office.officeform.agency_section == true  		
		@h1 += ['AgencyName','AgencyAccount','AgencySubAccount','TypeofRequest','FundPe','FundLine','FundHistory-2003','FundHistory-2004','FundHistory-2005','FundHistory-2006','FundHistory-2007','FundHistory-2008']
        end

     unless @agency_custom_values.empty?
      @agency_custom_values.each do |acv|
        @h1 += ["#{acv.agency_custom_field.field_name}"]
      end  
      end

      unless @custom_values.empty?
      @custom_values.each do |cv|
        @h1 += ["#{cv.custom_field.field_name}"]
      end  
    end
    

        csv << @h1
        
       @h2 = [ ]
	
        if @form_submission.office.officeform.organization_section == true    
        	@h2 +=    ["#{@form_submission.org_type}","#{@form_submission.org_name}","#{@form_submission.org_address1}","#{@form_submission.org_address2}","#{@form_submission.org_city}","#{@form_submission.org_state}","#{@form_submission.org_zip}","#{@form_submission.org_phone}","#{@form_submission.org_fax}","#{@form_submission.org_activities}"] 
        end
     
        if @form_submission.office.officeform.contact_section == true    
		@h2 +=    ["#{@form_submission.contact_firstname}","#{@form_submission.contact_lastname}","#{@form_submission.contact_email}","#{@form_submission.contact_address1}","#{@form_submission.contact_address2}","#{@form_submission.contact_city}","#{@form_submission.contact_state}","#{@form_submission.contact_zip}","#{@form_submission.contact_phone}","#{@form_submission.contact_mobile}"]
	end	
      
	if @form_submission.office.officeform.sr_contact_section == true    
		@h2 +=   ["#{@form_submission.sr_contact_firstname}","#{@form_submission.sr_contact_lastname}","#{@form_submission.sr_contact_email}","#{@form_submission.sr_contact_address1}","#{@form_submission.sr_contact_address2}","#{@form_submission.sr_contact_city}","#{@form_submission.sr_contact_state}","#{@form_submission.sr_contact_zip}","#{@form_submission.sr_contact_phone}","#{@form_submission.sr_contact_mobile}"]
	end	
      
	if @form_submission.office.officeform.representative_section == true    
		@h2 +=   ["#{@form_submission.representative_firstname}","#{@form_submission.representative_lastname}","#{@form_submission.representative_firmname}","#{@form_submission.representative_email}","#{@form_submission.representative_address1}","#{@form_submission.representative_address2}","#{@form_submission.representative_city}","#{@form_submission.representative_state}","#{@form_submission.representative_zip}","#{@form_submission.representative_phone}","#{@form_submission.representative_mobile}"]
	end	
	
        if @form_submission.office.officeform.project_section == true  	
		@h2 += ["#{@form_submission.project_description}","#{@form_submission.significance}","#{@form_submission.expansion_description}","#{@form_submission.fundlaw_description}","#{@form_submission.endorsements}","#{@form_submission.total_cost}","#{@form_submission.amount_requested}" ]
	end
	
        if @form_submission.office.officeform.agency_section == true  		
		@h2 += ["#{@form_submission.agency_name}","#{@form_submission.agency_account}","#{@form_submission.agency_sub_account}","#{@form_submission.type_of_request}","#{@form_submission.fund_pe}","#{@form_submission.fund_line}","#{@form_submission.fund_history_2003}","#{@form_submission.fund_history_2004}","#{         @form_submission.fund_history_2005}","#{@form_submission.fund_history_2006}","#{@form_submission.fund_history_2007}","#{@form_submission.fund_history_2008}" ]
        end
	
      unless @agency_custom_values.empty?
      @agency_custom_values.each do |acv|
      @h2 += ["#{acv.field_value}"]
      end  
      end
  
      unless @custom_values.empty?
      @custom_values.each do |cv|
      @h2 += ["#{cv.field_value}"]
      end  
      end
  
  
        csv << @h2

   end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => "#{@form_submission.office.name} Office Form Summary.csv")

  end

  def change_layout
    (action_name=="new" || action_name=="create" || action_name=="officelist"  || action_name=="search_office") ? "newhome" : "newadmin"
  end

def agency_fieldscheck
  status = true  
    if params[:form_submission][:fund_line].blank?
        @fundline_blankerror = "Please provide Fund Line"
		status = false
  end
end  

  def representative_fieldscheck

    status = true  
    if params[:form_submission][:representative_firstname].blank?
        @fname_blankerror = "Please provide FirstName"
		status = false
    end
	
	if params[:form_submission][:representative_firmname].blank?
        @firmname_blankerror = "Please provide FirmName"
		status = false
    end
    
	if params[:form_submission][:representative_email].blank?
        @email_blankerror = "Please provide Email"
		status = false
	end
	unless params[:form_submission][:representative_email].blank?
	   unless params[:form_submission][:representative_email] =~ /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i
             @email_blankerror = "Please provide valid Email <br/>"
			 	status = false
	   end
    end
 
	if params[:form_submission][:representative_address1].blank?
        @address_blankerror = "Please provide Address1"
		status = false
    end
    
	if params[:form_submission][:representative_city].blank?
        @city_blankerror = "Please provide City"
		status = false
    end

    if params[:form_submission][:representative_state].blank?
        @state_blankerror = "Please provide State"
		status = false
    end

    if params[:form_submission][:representative_zip].blank?
        @zip_blankerror = "Please provide Zip"
		status = false
	end
	
	 unless params[:form_submission][:representative_zip].blank?
       unless params[:form_submission][:representative_zip] =~ /^\d{5}$/i
			@zip_formaterror = "Please provide Zip code as digits <br/>"
				status = false
	   end
	end
		 
    if params[:form_submission][:representative_phone].blank?
        @phone_blankerror = "Please provide Phone"
		status = false
	end
	
	unless params[:form_submission][:representative_phone].blank?
	  unless params[:form_submission][:representative_phone] =~/^[2-9]\d{2}-\d{3}-\d{4}$/i
            @phone_blankerror = "Please provide valid Phone Number <br/>"
				status = false
	  end
	end
	
	return status
  end


def exportpdf_formsummary
	formsubmission_id = params[:id]
	res = Admin.export_summarypdf(formsubmission_id,1)
	send_data res.render, :filename => 'Form Summary.pdf', :type => "application/pdf" 
end

def export_csvforms
	@office = Office.find(params[:id])
		if !params[:form_sub].nil?  
		@list_forms = Formsubmission.find(:all,:conditions =>['id in (?) and user_id = ? and formsubmissions.office_id = ?',params[:form_sub],current_user.id,@office.id])	
		else			
		@list_forms = Formsubmission.find(:all,:conditions =>['user_id = ? and formsubmissions.office_id = ?',current_user.id,@office.id])
		end
	  
    
    report = StringIO.new
    csv_result(@list_forms,report)
    
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'list_forms.csv')
  end

def export_csvformslist
	
	if !params[:form_sub].nil?  
	@list_forms = Formsubmission.find(:all,:conditions =>['id in (?) and user_id = ?',params[:form_sub],current_user.id])	
	else
	@list_forms = Formsubmission.find(:all,:conditions =>['user_id = ?',current_user.id])
	end
	  
    
    report = StringIO.new
    csv_result(@list_forms,report)
    
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'list_forms.csv')
  end

def csv_result(list_forms,report)
	CSV::Writer.generate(report, ',') do |csv|
      csv << %w(UserName
		UserEmail
		OrgType
		OrgName
		OrgAddress1
		OrgAddress2
		OrgCity
		OrgState
		OrgZip
		OrgPhone
		OrgFax
		OrgActivities
		ContactFirstname
		ContactLastname
		ContactEmail
		ContactAddress1
		ContactAddress2
		ContactCity
		ContactState
		ContactZip
		ContactPhone
		ContactMobile
		SeniorContactFirstname  
		SeniorContactLastname 
		SeniorContactEmail 
		SeniorContactAddress1 
		SeniorContactAddress2 
		SeniorContactCity 
		SeniorContactState 
		SeniorContactZip 
		SeniorContactPhone 
		SeniorContactMobile
		RepFirstname
		RepLastname
		RepFirmname
		RepEmail
		RepAddress1
		RepAddress2
		RepCity
		RepState
		RepZip
		RepPhone
		RepMobile
		ProjectDescription
		Significance
		ExpansionDescription
		FundlawDescription
		Endorsements
		TotalCost
		AmountRequested
		AgencyName
		AgencyAccount
		AgencySubAccount
		TypeofRequest
		FundPe
		FundLine
		FundHistory-2003
		FundHistory-2004
		FundHistory-2005
		FundHistory-2006
		FundHistory-2007
		FundHistory-2008
		SubmittedDate
		)
        
      @list_forms.each do |list_form|
        csv << [list_form.user.full_name,
	 list_form.user.email,
	 list_form.org_type,
	 list_form.org_name, 
         list_form.org_address1,
         list_form.org_address2,
         list_form.org_city,
         list_form.org_state,
         list_form.org_zip,
         list_form.org_phone,
         list_form.org_fax,
         list_form.org_activities,
	 list_form.contact_firstname,
	 list_form.contact_lastname, 
         list_form.contact_email,
         list_form.contact_address1,
         list_form.contact_address2,
         list_form.contact_city,
         list_form.contact_state,
         list_form.contact_zip,
         list_form.contact_phone,
         list_form.contact_mobile,
	 list_form.sr_contact_firstname,
	 list_form.sr_contact_lastname, 
         list_form.sr_contact_email,
         list_form.sr_contact_address1,
         list_form.sr_contact_address2,
         list_form.sr_contact_city,
         list_form.sr_contact_state,
         list_form.sr_contact_zip,
         list_form.sr_contact_phone,
         list_form.sr_contact_mobile,
	 list_form.representative_firstname,
	 list_form.representative_lastname, 
         list_form.representative_firmname,
         list_form.representative_email,
         list_form.representative_address1,
         list_form.representative_address2,
         list_form.representative_city,
         list_form.representative_state,
         list_form.representative_zip,
         list_form.representative_phone,
         list_form.representative_mobile,
	 list_form.project_description,
	 list_form.significance, 
         list_form.expansion_description,
         list_form.fundlaw_description,
         list_form.endorsements,
         list_form.total_cost,
         list_form.amount_requested,
	 list_form.agency_name,
	 list_form.agency_account, 
         list_form.agency_sub_account,
         list_form.type_of_request,
         list_form.fund_pe,
         list_form.fund_line,
         list_form.fund_history_2003,
         list_form.fund_history_2004,
         list_form.fund_history_2005,
         list_form.fund_history_2006,
         list_form.fund_history_2007,
         list_form.fund_history_2008,
         list_form.submitted_date]
      end
    end
end

def idle
  session[:user_id] = nil
  flash[:notice] = "You have been idle for more than 10 minutes.Please Login"
  redirect_to login_path
end  

def check_max_word
  status = true
  
  if params[:form_submission][:org_activities]
    if (@office_form.is_org_activities_length_enabled == true && params[:form_submission][:org_activities].gsub(/\s+/," ").strip.count(" ") >= @office_form.org_activities_max_length)
      @org_activities_err = "Organization activities exceeds maximum words to be entered"
   status = false
   end
  end  
  
  if params[:form_submission][:project_description]
    if (@office_form.is_project_description_length_enabled == true && params[:form_submission][:project_description].gsub(/\s+/," ").strip.count(" ") >= @office_form.project_description_max_length)
      @project_description_err = "Project Description exceeds maximum words to be entered"
   status = false
   end
  end  
 
  if params[:form_submission][:significance]
    if (@office_form.is_significance_length_enabled == true && params[:form_submission][:significance].gsub(/\s+/," ").strip.count(" ") >= @office_form.significance_max_length)
    @significance_length_err = "Significance length exceeds maximum words to be entered"
   status = false
   end
  end  
  
  if params[:form_submission][:expansion_description]
    if (@office_form.is_expansion_description_length_enabled == true && params[:form_submission][:expansion_description].gsub(/\s+/," ").strip.count(" ") >= @office_form.expansion_description_max_length)
      @expansion_description_err = "Expansion Description exceeds maximum words to be entered"
   status = false
   end
  end  
 
  if params[:form_submission][:fundlaw_description]
    if (@office_form.is_fundlaw_description_length_enabled == true && params[:form_submission][:fundlaw_description].gsub(/\s+/," ").strip.count(" ") >= @office_form.fundlaw_description_max_length)
    @fundlaw_description_err = "Fundlaw Description exceeds maximum words to be entered"  
   status = false
   end
  end  

  if params[:form_submission][:endorsements]
    if (@office_form.is_endorsements_length_enabled == true && params[:form_submission][:endorsements].gsub(/\s+/," ").strip.count(" ") >= @office_form.endorsements_max_length)
      @endorsements_err = "Endorsements Length exceeds maximum words to be entered"
   status = false
   end
  end  
 
 
  if params[:form_submission][:fund_history_2003] 
   if (@office_form.is_fund_history_2003_length_enabled == true && params[:form_submission][:fund_history_2003].gsub(/\s+/," ").strip.count(" ") >= @office_form.fund_history_2003_max_length)
    @fund_2003_length_err = "Bill Funding History for 2003 exceeds maximum words to be entered" 
   status = false
   end
  end  
 
  if params[:form_submission][:fund_history_2004] 
   if (@office_form.is_fund_history_2004_length_enabled == true && params[:form_submission][:fund_history_2004].gsub(/\s+/," ").strip.count(" ") >= @office_form.fund_history_2004_max_length)
     @fund_2004_length_err = "Bill Funding History for 2004 exceeds maximum words to be entered" 
   status = false
   end
  end
 
  if params[:form_submission][:fund_history_2005] 
   if (@office_form.is_fund_history_2005_length_enabled == true && params[:form_submission][:fund_history_2005].gsub(/\s+/," ").strip.count(" ") >= @office_form.fund_history_2005_max_length)
     @fund_2005_length_err = "Bill Funding History for 2005 exceeds maximum words to be entered" 
   status = false
   end
 end
 
  if params[:form_submission][:fund_history_2006] 
   if (@office_form.is_fund_history_2006_length_enabled == true && params[:form_submission][:fund_history_2006].gsub(/\s+/," ").strip.count(" ") >= @office_form.fund_history_2006_max_length)
     @fund_2006_length_err = "Bill Funding History for 2006 exceeds maximum words to be entered" 
   status = false
   end
 end
 
  if params[:form_submission][:fund_history_2007] 
   if (@office_form.is_fund_history_2007_length_enabled == true && params[:form_submission][:fund_history_2007].gsub(/\s+/," ").strip.count(" ") >= @office_form.fund_history_2007_max_length)
     @fund_2007_length_err = "Bill Funding History for 2007 exceeds maximum words to be entered" 
   status = false
   end
 end
 
  if params[:form_submission][:fund_history_2008] 
   if (@office_form.is_fund_history_2008_length_enabled == true && params[:form_submission][:fund_history_2008].gsub(/\s+/," ").strip.count(" ") >= @office_form.fund_history_2008_max_length)
     @fund_2008_length_err = "Bill Funding History for 2008 exceeds maximum words to be entered" 
   status = false
   end
 end
 return status
end  

#To Update Agency CustomFields , Based on selection of Agency . Called through Javascript
  def change_agency_customfields
    @form_submission = session[:status]== 'user' ? Formsubmission.find(session[:formid]) : Formsubmission.find(session[:admin_formid]) 
    @agency = Agency.find_by_name(params[:aname])
    @agency_custom_fields = @agency.agency_custom_fields.find(:all,:conditions=>['active_status = ?',true])
    @agency_false_ids = [ ]
    @agency_length_err_false_ids = [ ]
    if !@agency_custom_fields.empty? || !@agency_custom_fields.blank?
    render :update do |page|
      page.replace_html "list_agency_customfields",:partial=>'users/list_agency_customfields'
    end
    else
      render :update do |page|
      page.reload()
    end
    end
  end

  
  def help_text
    @office = Office.find(params[:id])
  end  

  def agency_help_text
    @agency = Agency.find(params[:id])
  end  
 
   
end


