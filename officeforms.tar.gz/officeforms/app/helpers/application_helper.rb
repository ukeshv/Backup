# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper

def getcustomval(formid,cf_id)
	cv = CustomValue.find_by_formsubmission_id_and_custom_field_id(formid,cf_id)
end

def getagencycustomval(formid,acf_id)
	acv = AgencyCustomValue.find_by_formsubmission_id_and_agency_custom_field_id(formid,acf_id)
end	

  def getofficedetail(committeeadmin)
	if committeeadmin.officemember_type == "Admin" || committeeadmin.officemember_type == "User"
	is_officeadmin = true	
  else
	is_officeadmin = false
  end	
  return is_officeadmin
  end

 def display_star(officeform_field)
    if officeform_field == true
      return "<span class='star'>*</span>"
    else
      return "&nbsp;"	
    end
  end

 def display_customfield_star(is_mandatory)
    if is_mandatory == true
      return "<span class='star'>*</span>"
    else
      return "&nbsp;"	
    end
  end

 def display_agency_customfield_star(is_mandatory)
    if is_mandatory == true
      return "<span class='star'>*</span>"
    else
      return "&nbsp;"	
    end
  end

  def display_orgtypes
    org_types = Organization.find(:all)
    return "#{select('form_submission','org_type',org_types.collect{|x| [x.name,x.name]},{:include_blank=>true},:class=>:colorborder)}"
  end

   
  def display_agencies(status)
		session[:status] = status
    agencies = Agency.find(:all)
    return "#{select :form_submission,:agency_name,agencies.collect{|x| [x.name,x.name]},{:prompt=>"Select Agency"},{:onChange => "show_agency_customfields(this.value,'#{status}');",:class=>:colorborder} }"
  end	


  def display_agencyaccounts(agencyid)
    agency_accounts = Agencyaccount.find(:all,:conditions=>['agency_id = ?',agencyid])
    return "#{select(:form_submission,:agency_account,agency_accounts.collect{|x| [x.name,x.name]},{:prompt=>"Select Agency Account"},{:onChange => "show_agency_subaccounts(this.value);",:class=>:colorborder})}"
  end	
  
  def display_agency_subaccounts(agencyaccountid)
    agency_subaccounts = Agencyaccount.find(:all,:conditions=>['parent_id = (?)',agencyaccountid])
    return "#{select(:form_submission,:agency_sub_account,agency_subaccounts.collect{|x| [x.name,x.name]},{:prompt=>"Select Agency SubAccount"},{:class=>:colorborder})}"
end

 def sort_link_helper(text, parameter, options)
    update = options.delete(:update)
    action = options.delete(:action)
    controller = options.delete(:controller)
    page = options.delete(:page)
		per_page = options.delete(:per_page)
		sel_category = options.delete(:sel_category)
		search_txt = options.delete(:search_txt)
    id = options.delete(:id)
    key = parameter
    key += " DESC" if params[:sort] == parameter
    options = {
        :url => {:controller=>controller,:action => action,:id => id, :sort => key, :page => page ,:per_page => per_page,:sel_category => sel_category,:search_txt => search_txt },
        :update => update,
				:loading =>"Element.show('ajax_image1')",
        :complete => "Element.hide('ajax_image1')"

    }
      link_to_remote(text, options)
  end


def general_dateformat1(dateval)
	return dateval.strftime("%b-%d,%y") 
end

def comment_updatedby(c)
	unless c.followup_updatedby.nil?
	if c.followup_updated == 1
	a = Admin.find(c.followup_updatedby)
	name =  a.firstname
	name += " " + a.lastname if !a.lastname.nil?
	elsif  c.followup_updated == 2
	o = Officeadmin.find(c.followup_updatedby)
	name =  o.firstname
	name += " " + o.lastname if !o.lastname.nil?
	else
	o = Officeadmin.find(c.followup_updatedby)
	name =  o.firstname
	name += " " + o.lastname if !o.lastname.nil?
	end	
	else
	name = "Unknown"
	end

	return name
end

def commented_dateformat(dateval)
	return dateval.strftime("%b-%d %H:%M %p") 
end


def display_label(option_name,max_value)
	if option_name == true
		return "Maximum #{max_value} words"
	else
		return "&nbsp;"
  end		
end	

end
  
  