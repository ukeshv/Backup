module OrgtypeHelper
end
