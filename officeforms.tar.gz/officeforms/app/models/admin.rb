require 'digest/sha1'
class Admin < ActiveRecord::Base
  # Virtual attribute for the unencrypted password
attr_accessor :password
  
  
  validates_presence_of  :email,:message=>'Email Cant be blank'
  validates_presence_of  :login,:message=>'Login Cant be blank'
  validates_presence_of  :password,:if => :password_required?,:message=>'Password Cant be blank'
  validates_presence_of  :password_confirmation,:if => :password_required?,:message=>'Please retype your password'
  validates_length_of  :password, :within => 4..40, :if => :password_required?, :too_short => 'Password must be at least 4 characters.Please provide a longer password', :too_long=> 'password can be no longer than 40 characters. Please provide a shorter password'
  validates_confirmation_of :password,:if => :password_required?,:message=>"doesn't match with the confirmation password"
  validates_length_of  :login,:within => 3..40, :too_short => 'Login must be at least 3 characters.Please provide a longer Name', :too_long=> 'Login can be no longer than 40 characters. Please provide a shorter Name'
  validates_length_of  :email,:within => 3..100
  validates_uniqueness_of :login,:email, :case_sensitive => false
  validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/i,:message=>"Please provide a valid Email Address"  

  validates_presence_of :firstname,:message=>'Name cant be blank'
  validates_length_of :firstname, :within => 2..40, :too_short => 'First Name must be at least 2 characters long.  Please provide a longer Name', :too_long=> 'First Name can be no longer than 40 characters. Please provide a shorter Name'
  validates_presence_of :address1,:message=>'Address cant be blank'
  validates_presence_of :city,:message=>'City cant be blank'
  validates_presence_of :state,:message=>'State cant be blank'
  
  validates_length_of :zip, :is => 5, :message=>"Zip code Should be of length 5"
  validates_numericality_of :zip, :message=>"Zip code Should be Numbers"
  
  before_save :encrypt_password
  
  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  def self.authenticate(login, password)
    u = find_by_login(login) # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  # Encrypts some data with the salt.
  def self.encrypt(password, salt)
    Digest::SHA1.hexdigest("--#{salt}--#{password}--")
  end

  # Encrypts the password with the user salt
  def encrypt(password)
    self.class.encrypt(password, salt)
  end

  def authenticated?(password)
    crypted_password == encrypt(password)
  end

  def fullname
    return self.firstname + ' ' + self.lastname 
  end

  def address
	return self.address1 + ' ' + self.address2
  end

  def activestatus
    if self.active_status == true
      return "Active"
    else
      return "Inactive"	
    end
  end

  def self.export_adminpdf(admins)
    self.pdf_admin(admins)
  end # def ends

  def self.pdf_admin(admins)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    
    pdf = admintable(pdf,admins)
    return pdf
  end

  def self.admintable(pdf,admins)
    pdf.select_font("Helvetica")

    PDF::SimpleTable.new do |tab|
      tab.title = "List of Admins"
      tab.column_order.push(*%w(from1 to1 from3 from2 to2 to3 from4 to5 to4))

      tab.columns["from1"] = PDF::SimpleTable::Column.new("from1") { |col|
       col.heading = "Name"
      }
      tab.columns["to1"] = PDF::SimpleTable::Column.new("to1") { |col|
       col.heading = "Email"
      }
      tab.columns["from2"] = PDF::SimpleTable::Column.new("from2") { |col|
        col.heading = "City"
     }
     tab.columns["to2"] = PDF::SimpleTable::Column.new("to2") { |col|
       col.heading = "State"
     }
      tab.columns["from3"] = PDF::SimpleTable::Column.new("from3") { |col|
       col.heading = "Address"
     }
	 tab.columns["to3"] = PDF::SimpleTable::Column.new("to3") { |col|
       col.heading = "Zip"
     }
      tab.columns["from4"] = PDF::SimpleTable::Column.new("from4") { |col|
       col.heading = "Phone"
     }
       tab.columns["to5"] = PDF::SimpleTable::Column.new("to5") { |col|
       col.heading = "Fax"
     }
      tab.columns["to4"] = PDF::SimpleTable::Column.new("to4") { |col|
       col.heading = "Status"
     }

     tab.show_lines    = :all
     tab.show_headings = true
     tab.orientation   = :center
     tab.position      = :center
     tab.width = pdf.page_width - 25

    data = [ ]

    for admin in admins
      data += [
         { "from1" => "#{admin.fullname}", "to1" => "#{admin.email}","from2" => "#{admin.city}", "to2" => "#{admin.state}","from3" => "#{admin.address}", "to3" => "#{admin.zip}","from4" => "#{admin.phone}", "to5" => "#{admin.fax}", "to4" => "#{admin.activestatus}" }
        ]
    end

      tab.data.replace data
      tab.render_on(pdf)
    end
    return pdf
  end   

 def self.export_userpdf(users)
    self.pdf_user(users)
  end # def ends

  def self.pdf_user(users)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    
    pdf = usertable(pdf,users)
    return pdf
  end

  def self.usertable(pdf,users)
    pdf.select_font("Helvetica")

    PDF::SimpleTable.new do |tab|
      tab.title = "List of Public Users"
      tab.column_order.push(*%w(from1 to1 from3 from2 to2  to3 from4 to5 to4))

      tab.columns["from1"] = PDF::SimpleTable::Column.new("from1") { |col|
       col.heading = "Name"
      }
      tab.columns["to1"] = PDF::SimpleTable::Column.new("to1") { |col|
       col.heading = "Email"
      }
      tab.columns["from2"] = PDF::SimpleTable::Column.new("from2") { |col|
        col.heading = "City"
     }
     tab.columns["to2"] = PDF::SimpleTable::Column.new("to2") { |col|
       col.heading = "State"
     }
      tab.columns["from3"] = PDF::SimpleTable::Column.new("from3") { |col|
       col.heading = "Address"
     }
	 tab.columns["to3"] = PDF::SimpleTable::Column.new("to3") { |col|
       col.heading = "Zip"
     }
      tab.columns["from4"] = PDF::SimpleTable::Column.new("from4") { |col|
       col.heading = "Phone"
     }
        tab.columns["to5"] = PDF::SimpleTable::Column.new("to5") { |col|
       col.heading = "Fax"
     }
      tab.columns["to4"] = PDF::SimpleTable::Column.new("to4") { |col|
       col.heading = "Status"
     }

     tab.show_lines    = :all
     tab.show_headings = true
     tab.orientation   = :center
     tab.position      = :center
     tab.width = pdf.page_width - 25

    data = [ ]

    for user in users
      data += [
         { "from1" => "#{user.full_name}", "to1" => "#{user.email}","from2" => "#{user.city}", "to2" => "#{user.state}","from3" => "#{user.address}", "to3" => "#{user.zip}","from4" => "#{user.phone}", "to4" => "#{user.fax}", "to4" => "#{user.activestatus}"  }
        ]
    end

      tab.data.replace data
      tab.render_on(pdf)
    end
    return pdf
  end   


  def self.export_summarypdf(id,from)
	@summary = Formsubmission.find(id)
	self.pdf_summary(@summary,from)
  end # def ends

  def self.pdf_summary(summary,from)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    pdf = org_table(pdf,summary)
    pdf = contact_table(pdf,summary)
    pdf = sr_contact_table(pdf,summary)
    pdf = representative_table(pdf,summary)
    pdf = project_table(pdf,summary)
    pdf = agency_table(pdf,summary)
    pdf = agencycustomfield_table(pdf,summary)
    pdf = customfield_table(pdf,summary)
    if from == 2
    pdf = officefollowup_table(pdf,summary)
    end
    return pdf
  end

  def self.org_table(pdf,summary)
 summary = Formsubmission.find(summary.id)
 office_form = summary.office.officeform
 if  office_form.organization_section == true
    PDF::SimpleTable.new do |tab|
      tab.title = "Organization section"
      tab.column_order.push(*%w(Description Content))

        tab.columns["Description"] = PDF::SimpleTable::Column.new("Description")
	tab.columns["Description"].width = 150
	
        tab.columns["Content"] = PDF::SimpleTable::Column.new("Content")

        tab.show_lines    = :all
        tab.show_headings = false
        tab.orientation   = :center
        tab.position      = :center
        tab.width         = pdf.page_width - 150
      
       
     data = [
          { "Description" => "Organization type", "Content" => "#{summary.org_type}"},
          { "Description" => "Organization Name", "Content" => "#{summary.org_name}"},
          { "Description" => "Organization Address1", "Content" => "#{summary.org_address1}"},
          { "Description" => "Organization Address2", "Content" => "#{summary.org_address2}"},
          { "Description" => "Organization City", "Content" => "#{summary.org_city}"},
          { "Description" => "Organization State", "Content" => "#{summary.org_state}" },
          { "Description" => "Organization Zip", "Content" => "#{summary.org_zip}"},
          { "Description" => "Organization Phone", "Content" => "#{summary.org_phone}"},
          { "Description" => "Organization Fax", "Content" => "#{summary.org_fax}"},
          { "Description" => "Organization Activities", "Content" => "#{summary.org_activities}"}
          ]

        
        tab.data.replace data
        tab.render_on(pdf)
	end
	  end
      return pdf
	
	  end   

  def self.contact_table(pdf,summary)
 summary = Formsubmission.find(summary.id)
  office_form = summary.office.officeform
 if  office_form.contact_section == true
    PDF::SimpleTable.new do |tab|
      tab.title = "Contact section"
      tab.column_order.push(*%w(Description Content))

        tab.columns["Description"] = PDF::SimpleTable::Column.new("Description")
	tab.columns["Description"].width = 150
	
        tab.columns["Content"] = PDF::SimpleTable::Column.new("Content")

        tab.show_lines    = :all
        tab.show_headings = false
        tab.orientation   = :center
        tab.position      = :center
        tab.width         = pdf.page_width - 150
      
       
     data = [
          { "Description" => "Contact Firstname", "Content" => "#{summary.contact_firstname}"},
          { "Description" => "Contact Name", "Content" => "#{summary.contact_lastname}"},
          { "Description" => "Contact Email", "Content" => "#{summary.contact_email}"},
          { "Description" => "Contact Address1", "Content" => "#{summary.contact_address1}"},
          { "Description" => "Contact Address2", "Content" => "#{summary.contact_address2}"},
          { "Description" => "Contact City", "Content" => "#{summary.contact_city}"},
          { "Description" => "Contact State", "Content" => "#{summary.contact_state}" },
          { "Description" => "Contact Zip", "Content" => "#{summary.contact_zip}"},
          { "Description" => "Contact Phone", "Content" => "#{summary.contact_phone}"},
          { "Description" => "Contact Fax", "Content" => "#{summary.contact_mobile}"},
          
          ]

        
        tab.data.replace data
        tab.render_on(pdf)
	end
	end
      return pdf
	  end   
  def self.sr_contact_table(pdf,summary)
 summary = Formsubmission.find(summary.id)
  office_form = summary.office.officeform
 if  office_form.sr_contact_section == true
    PDF::SimpleTable.new do |tab|
      tab.title = "Senior Contact section"
      tab.column_order.push(*%w(Description Content))

        tab.columns["Description"] = PDF::SimpleTable::Column.new("Description")
	tab.columns["Description"].width = 150
	
        tab.columns["Content"] = PDF::SimpleTable::Column.new("Content")

        tab.show_lines    = :all
        tab.show_headings = false
        tab.orientation   = :center
        tab.position      = :center
        tab.width         = pdf.page_width - 150
      
       
     data = [
          { "Description" => "Senior Contact FirstName", "Content" => "#{summary.sr_contact_firstname}"},
          { "Description" => "Senior Contact LastName", "Content" => "#{summary.sr_contact_lastname}"},
          { "Description" => "Senior Contact Email", "Content" => "#{summary.sr_contact_email}"},
          { "Description" => "Senior Contact Address1", "Content" => "#{summary.sr_contact_address1}"},
          { "Description" => "Senior Contact Address2", "Content" => "#{summary.sr_contact_address2}"},
          { "Description" => "Senior Contact City", "Content" => "#{summary.sr_contact_city}"},
          { "Description" => "Senior Contact State", "Content" => "#{summary.sr_contact_state}" },
          { "Description" => "Senior Contact Zip", "Content" => "#{summary.sr_contact_zip}"},
          { "Description" => "Senior Contact Phone", "Content" => "#{summary.sr_contact_phone}"},
          { "Description" => "Senior Contact Mobile", "Content" => "#{summary.sr_contact_mobile}"},
          
          ]

        
        tab.data.replace data
        tab.render_on(pdf)
	end
	end
      return pdf
	  end   
  def self.representative_table(pdf,summary)
 summary = Formsubmission.find(summary.id)
  office_form = summary.office.officeform
 if  office_form.representative_section == true
    PDF::SimpleTable.new do |tab|
      tab.title = "Representative section"
      tab.column_order.push(*%w(Description Content))

        tab.columns["Description"] = PDF::SimpleTable::Column.new("Description")
	tab.columns["Description"].width = 150
	
        tab.columns["Content"] = PDF::SimpleTable::Column.new("Content")

        tab.show_lines    = :all
        tab.show_headings = false
        tab.orientation   = :center
        tab.position      = :center
        tab.width         = pdf.page_width - 150
      
       
     data = [
          { "Description" => "Representative FirstName", "Content" => "#{summary.representative_firstname}"},
          { "Description" => "Representative LastName", "Content" => "#{summary.representative_lastname}"},
          { "Description" => "Representative FirmName", "Content" => "#{summary.representative_firmname}"},
          { "Description" => "Representative Email", "Content" => "#{summary.representative_email}"},
          { "Description" => "Representative Address1", "Content" => "#{summary.representative_address1}"},
          { "Description" => "Representative Address2", "Content" => "#{summary.representative_address2}"},
          { "Description" => "Representative City", "Content" => "#{summary.representative_city}"},
          { "Description" => "Representative State", "Content" => "#{summary.representative_state}" },
          { "Description" => "Representative Zip", "Content" => "#{summary.representative_zip}"},
          { "Description" => "Representative Phone", "Content" => "#{summary.representative_phone}"},
          { "Description" => "Representative Mobile", "Content" => "#{summary.representative_mobile}"},
           ]

        
        tab.data.replace data
        tab.render_on(pdf)
	end
	end
      return pdf
	  end   

  def self.project_table(pdf,summary)
 summary = Formsubmission.find(summary.id)
 office_form = summary.office.officeform
 if  office_form.project_section == true
  
    PDF::SimpleTable.new do |tab|
      tab.title = "Project section"
      tab.column_order.push(*%w(Description Content))

        tab.columns["Description"] = PDF::SimpleTable::Column.new("Description")
	tab.columns["Description"].width = 150
	
        tab.columns["Content"] = PDF::SimpleTable::Column.new("Content")

        tab.show_lines    = :all
        tab.show_headings = false
        tab.orientation   = :center
        tab.position      = :center
        tab.width         = pdf.page_width - 150
      
       
     data = [
          { "Description" => "Project Description", "Content" => "#{summary.project_description}"},
          { "Description" => "Significance", "Content" => "#{summary.significance}"},
          { "Description" => "Expansion Description", "Content" => "#{summary.expansion_description}"},
          { "Description" => "Is Funding Under Law", "Content" => "#{summary.is_funding_under_law}"},
          { "Description" => "Fundlaw Description", "Content" => "#{summary.fundlaw_description}"},
          { "Description" => "Endorsements", "Content" => "#{summary.endorsements}"},
          { "Description" => "Total Cost", "Content" => "#{summary.total_cost}"},
          { "Description" => "Amount Requested", "Content" => "#{summary.amount_requested}" },
          
           ]

        
        tab.data.replace data
        tab.render_on(pdf)
	end
	end
      return pdf
	  end   

  def self.agency_table(pdf,summary)
 summary = Formsubmission.find(summary.id)
 office_form = summary.office.officeform
 if  office_form.agency_section == true
  
    PDF::SimpleTable.new do |tab|
      tab.title = "Agency section"
      tab.column_order.push(*%w(Description Content))

        tab.columns["Description"] = PDF::SimpleTable::Column.new("Description")
	tab.columns["Description"].width = 150
	
        tab.columns["Content"] = PDF::SimpleTable::Column.new("Content")

        tab.show_lines    = :all
        tab.show_headings = false
        tab.orientation   = :center
        tab.position      = :center
        tab.width         = pdf.page_width - 150
      
       
     data = [
          { "Description" => "Agency Name", "Content" => "#{summary.agency_name}"},
          { "Description" => "Agency Account", "Content" => "#{summary.agency_account}"},
          { "Description" => "Agency Sub Account", "Content" => "#{summary.agency_sub_account}"},
          { "Description" => "Type Of Request", "Content" => "#{summary.type_of_request}"},
          { "Description" => "Fund PE", "Content" => "#{summary.fund_pe}"},
          { "Description" => "Fund Line", "Content" => "#{summary.fund_line}" },
          { "Description" => "Fund History 2003", "Content" => "#{summary.fund_history_2003}"},
          { "Description" => "Fund History 2004", "Content" => "#{summary.fund_history_2004}"},
          { "Description" => "Fund History 2005", "Content" => "#{summary.fund_history_2005}"},
          { "Description" => "Fund History 2006", "Content" => "#{summary.fund_history_2006}"},
          { "Description" => "Fund History 2007", "Content" => "#{summary.fund_history_2007}"},
          { "Description" => "Fund History 2008", "Content" => "#{summary.fund_history_2008}"},
           ]

        
        tab.data.replace data
        tab.render_on(pdf)
	end
	end
      return pdf
	  end   


    def self.customfield_table(pdf,summary)
    summary = Formsubmission.find(summary.id)
    @custom_values =  CustomValue.find :all,:conditions=>['formsubmission_id = ? and custom_fields.active_status = ?',summary.id,true],:include=>[:custom_field]
    @data = [ ]
    unless @custom_values.empty?

    PDF::SimpleTable.new do |tab|
    tab.title = "OFFICE-SPECIFIC CRITERIA"
    tab.column_order.push(*%w(Description Content))

    tab.columns["Description"] = PDF::SimpleTable::Column.new("Description")
    tab.columns["Description"].width = 150

    tab.columns["Content"] = PDF::SimpleTable::Column.new("Content")

    tab.show_lines    = :all
    tab.show_headings = false
    tab.orientation   = :center
    tab.position      = :center
    tab.width         = pdf.page_width - 150

    @custom_values.each do |cv| 
    @data += [
    { "Description" => "#{cv.custom_field.field_name}", "Content" => "#{cv.field_value}"},
    ]
    end


    tab.data.replace @data
    tab.render_on(pdf)
    end
    end
    return pdf
  end
  
  def self.agencycustomfield_table(pdf,summary)
    summary = Formsubmission.find(summary.id)
    @agency_custom_values =  AgencyCustomValue.find :all,:conditions=>['formsubmission_id = ? and agency_custom_fields.active_status = ?',summary.id,true],:include=>[:agency_custom_field]
    @data = [ ]
    unless @agency_custom_values.empty?

    PDF::SimpleTable.new do |tab|
    tab.title = "AGENCY-SPECIFIC CRITERIA"
    tab.column_order.push(*%w(Description Content))

    tab.columns["Description"] = PDF::SimpleTable::Column.new("Description")
    tab.columns["Description"].width = 150

    tab.columns["Content"] = PDF::SimpleTable::Column.new("Content")

    tab.show_lines    = :all
    tab.show_headings = false
    tab.orientation   = :center
    tab.position      = :center
    tab.width         = pdf.page_width - 150

    @agency_custom_values.each do |acv| 
    @data += [
    { "Description" => "#{acv.agency_custom_field.field_name}", "Content" => "#{acv.field_value}"},
    ]
    end


    tab.data.replace @data
    tab.render_on(pdf)
    end
    end
    return pdf
    end


def self.officefollowup_table(pdf,summary)
 summary = Formsubmission.find(summary.id)
 office_form = summary.office.officeform
 if  summary.office_followup == true
  
    PDF::SimpleTable.new do |tab|
      tab.title = " OFFICE FOLLOWUP"
      tab.column_order.push(*%w(Description Content))

        tab.columns["Description"] = PDF::SimpleTable::Column.new("Description")
	tab.columns["Description"].width = 150
	
        tab.columns["Content"] = PDF::SimpleTable::Column.new("Content")

        tab.show_lines    = :all
        tab.show_headings = false
        tab.orientation   = :center
        tab.position      = :center
        tab.width         = pdf.page_width - 150
      
       
     data = [
          { "Description" => "Office Questions", "Content" => "#{summary.office_questions}"},
          { "Description" => "Office Reviewer1", "Content" => "#{summary.office_reviewer1}"},
          { "Description" => "Office Reviewer2", "Content" => "#{summary.office_reviewer2}"},
          { "Description" => "Office Reviewer3", "Content" => "#{summary.office_reviewer3}"}
            ]

        
        tab.data.replace data
        tab.render_on(pdf)
	end
	end
      return pdf
	  end   




  protected
    # before filter 
    def encrypt_password
      return if password.blank?
      self.salt = Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{login}--") if new_record?
      self.crypted_password = encrypt(password)
    end
    
    def password_required?
      crypted_password.blank? || !password.blank?
    end
end
