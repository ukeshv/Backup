class AdminNotifier < ActionMailer::Base
	
  def signup_notification(office_admin_user)
    setup_email(office_admin_user)
    @recipients  = "#{office_admin_user.email}"
    @subject    += 'Your Account has been created'

 end

   def sendmail_officemembers(admin,recipient)
    @subject  = "Test Mail to Form Submitters - "
    @from = "#{admin.email}"
    @recipients  = recipient
    @content_type = "text/html"
    @body[:admin] = admin
  end  
  
  def mail_referrer(recipient,adminmember,form)
    @subject  = "Form for Reference - "
    @from = "#{adminmember.email}"
    @recipients  = "#{recipient.email}"
    @content_type = "text/html"
    @body[:adminmember] = adminmember
    @body[:recipient] = recipient
    @body[:form] = form
    @body[:url] = $site_url +  "admin/formsummary/#{form.id}"
  end   
  
  def notification_mail(notification)
    @subject     = "#{notification.subject}"
    @from        = "admin@hillforms.com"
    @sent_on     = Time.now
    @recipients  = "#{notification.email}"
    @content_type = "text/html"
    @body[:notification] = notification
  end  
  
  protected
  def setup_email(office_admin_user)
    @recipients  = "#{office_admin_user.email}"
    @from        = "admin@hillforms.com"
    @subject     = "[office forms - RailsFactory] "
    @sent_on     = Time.now
    @content_type = "text/html"
    @body[:office_admin_user] = office_admin_user
  end
  

end
