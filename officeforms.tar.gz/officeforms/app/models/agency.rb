class Agency < ActiveRecord::Base
  has_many :agencyaccounts	
  has_many :agency_custom_fields	
  validates_presence_of :name, :message=>"Agency Name can't be blank"
  validates_length_of :name, :in => 5..30,:too_short => 'Agency Name must be at least 5 characters long.', :too_long=> 'Agency Name can be no longer than 30 characters.' 
  validates_uniqueness_of :name, :message=>'Name is Already choosen'
  
   def deletestatus
    if self.delete_status == true
      return "Active"
    else
      return "InActive"	
    end
  end 
  
   def self.export_agencypdf(agencies)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    
    pdf = table(pdf,agencies)
    return pdf
  end # def ends

  def self.table(pdf,agencies)
    pdf.select_font("Helvetica")

    PDF::SimpleTable.new do |tab|
      tab.title = "List of Agencies"
      tab.column_order.push(*%w(from1 to1))

      tab.columns["from1"] = PDF::SimpleTable::Column.new("from1") { |col|
       col.heading = "Agency Name"
      }
      tab.columns["to1"] = PDF::SimpleTable::Column.new("to1") { |col|
       col.heading = "Active Status"
      }

    tab.show_lines    = :all
     tab.show_headings = true
     tab.orientation   = :center
     tab.position      = :center
     tab.width = pdf.page_width - 25

    data = [ ]

    for agency in agencies
      data += [
         { "from1" => "#{agency.name}", "to1" => "#{agency.deletestatus}" },
        ]
    end

      tab.data.replace data
      tab.render_on(pdf)
    end
    return pdf
  end   
 
 
  #Adding custom fields for agencies 
  def self.assign_customfields
   agencyids = AgencyCustomField.find(:all).collect{|x| x.agency_id}.uniq
   unless agencyids.empty?
   agencies = Agency.find(:all,:conditions=>['id not in (?)',agencyids])
   else
   agencies = Agency.find(:all)  
   end
   for agency in agencies
   1.upto(15) {|i|
   @custom_field = AgencyCustomField.create(:agency_id=>agency.id,:field_name=> "custom#{i}",:field_type=>'Textbox',:active_status=>0 )
   }
   end
  end 
  
  
end
