class AgencyCustomField < ActiveRecord::Base
	belongs_to :agency	
	has_one :agency_custom_value
	validates_numericality_of :max_length,:greater_than=>0,:if=>Proc.new{|agency_custom_field| agency_custom_field.is_length_enabled ==true}, :message=>"provide text length"	
end
