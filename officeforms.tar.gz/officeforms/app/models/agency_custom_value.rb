class AgencyCustomValue < ActiveRecord::Base
	
	attr_accessor :save_agencycustomvalue_version
  acts_as_versioned :if => Proc.new { |agencycustomvalue| agencycustomvalue.save_agencycustomvalue_version == true }
	
	belongs_to :agency_custom_field
	belongs_to :formsubmission
	
	
  validates_presence_of :field_value,:if => Proc.new { |agencycustomvalue| agencycustomvalue.validate_agencycustom_field?(true,'is_mandatory' ) }, :message=>"Provide Field Value"
	
	# to validate All fields from Formsubmission value
  def validate_agencycustom_field?( val,f )
    unless self.agency_custom_field.nil?
      if (eval("self.agency_custom_field.#{f}") == val)
        return true
      else    
        return false
      end
    else
      return false
    end  
  end
	
	def clear_old_version(version)
    self.class.versioned_class.delete_all ["#{self.class.version_column} < ? and #{self.class.versioned_foreign_key} = ?", version, id]  
	end 
	
end
