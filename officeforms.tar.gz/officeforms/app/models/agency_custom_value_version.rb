class AgencyCustomValueVersion < ActiveRecord::Base
	
	belongs_to :agency_custom_field
	belongs_to :formsubmission
	
end
