class Agencyaccount < ActiveRecord::Base
	   belongs_to :agency
#acts_as_tree :foreign_key => "parent_id"
       belongs_to :parent,:class_name =>"Agencyaccount",:foreign_key => "parent_id"
       has_many :children,:class_name =>"Agencyaccount",:foreign_key => "parent_id"
      
	   validates_presence_of :name, :message=>"Agency Account Name can't be blank"
	   validates_length_of :name, :in => 5..30,:too_short => 'Name must be at least 5 characters long.  Please provide a longer Name', :too_long=> 'Name can be no longer than 30 characters. Please provide a shorter Name' 
       validates_uniqueness_of :name, :message=>'Name is Already choosen'
  
  
  def self.sub_account(id)
       @sub_account = Agencyaccount.find(:all,:conditions=>['parent_id = (?)',id])
  end     

   def deletestatus
    if self.delete_status == true
      return "Active"
    else
      return "InActive"	
    end
  end 
  
   def self.export_agencyaccountpdf(agencyaccounts,agency)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    
    pdf = table(pdf,agencyaccounts,agency)
    return pdf
  end # def ends

  def self.table(pdf,agencyaccounts,agency)
    pdf.select_font("Helvetica")

    PDF::SimpleTable.new do |tab|
      tab.title = "List of Agency Accounts - #{agency.name}"
      tab.column_order.push(*%w(from1 to1))

      tab.columns["from1"] = PDF::SimpleTable::Column.new("from1") { |col|
       col.heading = "Agency Account Name"
      }
      tab.columns["to1"] = PDF::SimpleTable::Column.new("to1") { |col|
       col.heading = "Active Status"
      }

    tab.show_lines    = :all
     tab.show_headings = true
     tab.orientation   = :center
     tab.position      = :center
     tab.width = pdf.page_width - 25

    data = [ ]

    for agencyaccount in agencyaccounts
      data += [
         { "from1" => "#{agencyaccount.name}", "to1" => "#{agencyaccount.deletestatus}" },
        ]
    end

      tab.data.replace data
      tab.render_on(pdf)
    end
    return pdf
  end   

   def self.export_agencysubaccountpdf(agencysubaccounts,agencyaccount)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    
    pdf = table1(pdf,agencysubaccounts,agencyaccount)
    return pdf
  end # def ends

  def self.table1(pdf,agencysubaccounts,agencyaccount)
    pdf.select_font("Helvetica")

    PDF::SimpleTable.new do |tab|
      tab.title = "List of Agency Sub Accounts - #{agencyaccount.name}"
      tab.column_order.push(*%w(from1 to1))

      tab.columns["from1"] = PDF::SimpleTable::Column.new("from1") { |col|
       col.heading = "Agency SubAccount Name"
      }
      tab.columns["to1"] = PDF::SimpleTable::Column.new("to1") { |col|
       col.heading = "Active Status"
      }

    tab.show_lines    = :all
     tab.show_headings = true
     tab.orientation   = :center
     tab.position      = :center
     tab.width = pdf.page_width - 25

    data = [ ]

    for agencysubaccount in agencysubaccounts
      data += [
         { "from1" => "#{agencysubaccount.name}", "to1" => "#{agencysubaccount.deletestatus}" },
        ]
    end

      tab.data.replace data
      tab.render_on(pdf)
    end
    return pdf
  end   



end
