class Committee < ActiveRecord::Base

#Associations

has_many :committee_members

#Validations

validates_presence_of :name,:message=>"Please provide Committee Name"
validates_uniqueness_of :name, :message=>"Committee Name already exists"

validates_presence_of :contact_firstname,:message=>"Please provide Committee Contact FirstName"
validates_presence_of :contact_email,:message=>"Please provide Committee Contact Email"
validates_format_of :contact_email, :with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i ,:message=>"Please provide a valid Email Address"  

validates_presence_of :address1,:message=>"Please provide Committee Address"
validates_presence_of :city,:message=>"Please provide City"
validates_presence_of :state,:message=>"Please select State"
validates_length_of :zip, :is => 5, :message=>"Zip code Should be of length 5"
validates_numericality_of :zip, :message=>"Zip code Should be Numbers"	
 
 validates_format_of :phone, :with => (/^[2-9]\d{2}-\d{3}-\d{4}$/i) ,:message=>"Please provide a valid Phone Number"    

  def activestatus
    if self.active_status == true
      return "Active"
    else
      return "Inactive"	
    end
  end


  def self.export_pdf(committees)
    self.pdf_committee(committees)
  end # def ends

  def self.pdf_committee(committees)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    
    pdf = table(pdf,committees)
    return pdf
  end
  
    def self.table(pdf,committees)
    pdf.select_font("Helvetica")

    PDF::SimpleTable.new do |tab|
      tab.title = "List of Committees"
      tab.column_order.push(*%w(from1 to1 from2 to2 from3 to3 from4 to4))

      tab.columns["from1"] = PDF::SimpleTable::Column.new("from1") { |col|
       col.heading = "Name"
      }
      tab.columns["to1"] = PDF::SimpleTable::Column.new("to1") { |col|
       col.heading = "Contact Name"
      }
      tab.columns["from2"] = PDF::SimpleTable::Column.new("from2") { |col|
        col.heading = "Address"
     }
     tab.columns["to2"] = PDF::SimpleTable::Column.new("to2") { |col|
       col.heading = "City"
     }
      tab.columns["from3"] = PDF::SimpleTable::Column.new("from3") { |col|
       col.heading = "State"
     }
	 tab.columns["to3"] = PDF::SimpleTable::Column.new("to3") { |col|
       col.heading = "Zip"
     }
      tab.columns["from4"] = PDF::SimpleTable::Column.new("from4") { |col|
       col.heading = "Phone"
     }
      tab.columns["to4"] = PDF::SimpleTable::Column.new("to4") { |col|
       col.heading = "Status"
     }

     tab.show_lines    = :all
     tab.show_headings = true
     tab.orientation   = :center
     tab.position      = :center
     tab.width = pdf.page_width - 25

    data = [ ]

    for committee in committees
      data += [
            { "from1" => "#{committee.name}", "to1" => "#{committee.contact_firstname}","from2" => "#{committee.address1}", "to2" => "#{committee.city}" ,"from3" => "#{committee.state}", "to3" => "#{committee.zip}","from4" => "#{committee.phone}", "to4" => "#{committee.activestatus}"  }
        ]
    end

      tab.data.replace data
      tab.render_on(pdf)
    end
    return pdf
  end   

end
