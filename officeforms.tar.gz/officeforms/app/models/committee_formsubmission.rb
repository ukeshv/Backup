class CommitteeFormsubmission < ActiveRecord::Base

#Associations
belongs_to :formsubmission
belongs_to :committee
belongs_to :officeadmin

validates_uniqueness_of :committee_id, :scope => [:formsubmission_id, :officeadmin_id]

end


