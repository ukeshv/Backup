require 'digest/sha1'
class CommitteeMember < ActiveRecord::Base
  
# Virtual attribute for the unencrypted password
attr_accessor :password
attr_accessor :officeid_val
attr_accessor :officemember_val

#Associations

belongs_to :committee
belongs_to :office
has_many :committee_member_comments

	validates_presence_of  :email,:message=>'CommitteeMember Email Cant be blank'
	validates_presence_of  :login,:message=>'CommitteeMember Login Cant be blank'
	validates_presence_of  :password,:if => :password_required?,:message=>'Password Cant be blank'
	validates_presence_of  :password_confirmation,:if => :password_required?,:message=>'Please retype your password'
	validates_length_of  :password, :within => 4..40, :if => :password_required?
	validates_confirmation_of :password,:if => :password_required?,:message=>'Mismatch in Passwords'
	validates_length_of  :email,:within => 3..100
	validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/i,:message=>"Please provide a valid Email Address"  
	validates_length_of  :login,:within => 3..40
	validates_uniqueness_of :login,:email, :case_sensitive => false
	
	validates_presence_of :firstname,:message=>"Please provide Member FirstName"
	validates_presence_of :address1,:message=>"Please provide CommitteeMember Address"
	validates_presence_of :city,:message=>"Please provide City"
	validates_presence_of :state,:message=>"Please provide State"
	validates_length_of :zip, :is => 5, :message=>"Zip code Should be of length 5"
	validates_numericality_of :zip, :message=>"Zip code Should be Numbers"	

	validates_format_of :phone, :with => (/^[2-9]\d{2}-\d{3}-\d{4}$/i) ,:message=>"Please provide a valid Phone Number"  
	validates_presence_of :office_id,:if =>Proc.new { |committeemember| committeemember.validate_officeidval?( 1 ) },:message=>"Please Select an Office"  
	validates_presence_of :officemember_type,:if =>Proc.new { |committeemember| committeemember.validate_officememberval?( 1 ) },:message=>"Please Select an Office Member Type"  
  
  before_save :encrypt_password  

# to validate field values depending upon step value available
    def validate_officeidval?( step1 )          
         if (officeid_val == step1)
          return true
        else
          return false
        end
      end

# to validate field values depending upon step value available
    def validate_officememberval?( step1 )          
         if (officemember_val == step1)
          return true
        else
          return false
        end
      end
      
  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  def self.authenticate(login, password)
    u = find_by_login(login) # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  # Encrypts some data with the salt.
  def self.encrypt(password, salt)
    Digest::SHA1.hexdigest("--#{salt}--#{password}--")
  end

  # Encrypts the password with the user salt
  def encrypt(password)
    self.class.encrypt(password, salt)
  end

  def authenticated?(password)
    crypted_password == encrypt(password)
  end

def full_name
    return self.firstname + ' ' + self.lastname 
  end

def self.office_admins(officeid)
	find :all,:conditions=>['office_id = ?',officeid]
end

def self.find_for_forget(email)
     find :first, :conditions => ['email = ?', email]
   end

   def forgot_password
     @forgotten_password = true
     self.make_password_reset_code
   end

  def recently_forgot_password?
     @forgotten_password
   end

 def recently_reset_password?
     @reset_password
   end

 def reset_password
     # First update the password_reset_code before setting the
     # reset_password flag to avoid duplicate email notifications.
     update_attribute(:password_reset_code, nil)
     @reset_password = true
   end 
   
     def self.export_admin_user_pdf(committee_members,committee)
    self.pdf_committeeadmin(committee_members,committee)
  end # def ends

  def self.pdf_committeeadmin(committee_members,committee)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    
    pdf = table(pdf,committee_members,committee)
    return pdf
  end
  
    def self.table(pdf,committee_members,committee)
    pdf.select_font("Helvetica")

    PDF::SimpleTable.new do |tab|
      tab.title = "List of Admins/Users - #{committee.name}"
      tab.column_order.push(*%w(from1 to1 from2 to2 from3 to3 from4 to4 from5))

      tab.columns["from1"] = PDF::SimpleTable::Column.new("from1") { |col|
       col.heading = "Name"
      }
      tab.columns["to1"] = PDF::SimpleTable::Column.new("to1") { |col|
       col.heading = "Email"
      }
      tab.columns["from2"] = PDF::SimpleTable::Column.new("from2") { |col|
        col.heading = "Address"
     }
     tab.columns["to2"] = PDF::SimpleTable::Column.new("to2") { |col|
       col.heading = "City"
     }
      tab.columns["from3"] = PDF::SimpleTable::Column.new("from3") { |col|
       col.heading = "State"
     }
      tab.columns["to3"] = PDF::SimpleTable::Column.new("to3") { |col|
       col.heading = "Zip"
     }
      tab.columns["from4"] = PDF::SimpleTable::Column.new("from3") { |col|
       col.heading = "Phone"
     }
      tab.columns["to4"] = PDF::SimpleTable::Column.new("to3") { |col|
       col.heading = "Admin/User"
     }
      tab.columns["from5"] = PDF::SimpleTable::Column.new("from5") { |col|
       col.heading = "Status"
     }

     tab.show_lines    = :all
     tab.show_headings = true
     tab.orientation   = :center
     tab.position      = :center
     tab.width = pdf.page_width - 25

    data = [ ]

    for member in committee_members
      data += [
         { "from1" => "#{member.firstname}", "to1" => "#{member.email}","from2" => "#{member.address1}", "to2" => "#{member.city}" ,"from3" => "#{member.state}", "to3" => "#{member.zip}","from4" => "#{member.phone}","to4" => "#{member.admin_status}","from5" => "#{member.activestatus}" },
        ]
    end

      tab.data.replace data
      tab.render_on(pdf)
    end
    return pdf
  end   

  def activestatus
    if self.active_status == true
      return "Active"
    else
      return "Inactive"	
    end
  end

  def admin_status
    if self.is_admin == true
      return "Admin"
    else
      return "User"	
    end
  end

  protected
    # before filter 
    def encrypt_password
      return if password.blank?
      self.salt = Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{login}--") if new_record?
      self.crypted_password = encrypt(password)
    end
    
    def password_required?
      crypted_password.blank? || !password.blank?
    end
    
      def make_password_reset_code
      self.password_reset_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
    end

end
