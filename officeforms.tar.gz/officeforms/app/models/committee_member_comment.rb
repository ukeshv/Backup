class CommitteeMemberComment < ActiveRecord::Base
belongs_to :formsubmission  
belongs_to :committee_member  
end
