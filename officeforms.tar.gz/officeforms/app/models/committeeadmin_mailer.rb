class CommitteeadminMailer < ActionMailer::Base
  
   def form_submitters(committeemember,recipient)
    @subject  = "Test Mail to Form Submitters - "
    @from = "#{committeemember.email}"
    @recipients  = recipient
    @content_type = "text/html"
    @body[:committeemember] = committeemember
  end  
  
end
