class CustomField < ActiveRecord::Base
  has_one :custom_value
  belongs_to :office
	validates_numericality_of :max_length,:greater_than=>0,:if=>Proc.new{|custom_field| custom_field.is_length_enabled ==true}, :message=>"provide text length"	
end
