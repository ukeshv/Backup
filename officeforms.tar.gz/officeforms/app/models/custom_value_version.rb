class CustomValueVersion < ActiveRecord::Base
	
	belongs_to :custom_field
  belongs_to :formsubmission
	
end
