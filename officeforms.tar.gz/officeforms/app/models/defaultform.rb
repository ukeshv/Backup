class Defaultform < ActiveRecord::Base
		
		validates_numericality_of :org_activities_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_org_activities_length_enabled ==true}, :message=>"provide text length"	
		validates_numericality_of :project_description_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_project_description_length_enabled ==true}, :message=>"provide text length"	
		validates_numericality_of :significance_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_significance_length_enabled ==true}, :message=>"provide text length"	
		validates_numericality_of :expansion_description_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_expansion_description_length_enabled  	 ==true}, :message=>"provide text length"	
		validates_numericality_of :fundlaw_description_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_fundlaw_description_length_enabled ==true}, :message=>"provide text length"	
		validates_numericality_of :endorsements_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_endorsements_length_enabled ==true}, :message=>"provide text length"	
		validates_numericality_of :fund_history_2003_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_fund_history_2003_length_enabled ==true}, :message=>"provide text length"	
		validates_numericality_of :fund_history_2004_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_fund_history_2004_length_enabled ==true}, :message=>"provide text length"	
		validates_numericality_of :fund_history_2005_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_fund_history_2005_length_enabled ==true}, :message=>"provide text length"	
		validates_numericality_of :fund_history_2006_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_fund_history_2006_length_enabled ==true}, :message=>"provide text length"	
		validates_numericality_of :fund_history_2007_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_fund_history_2007_length_enabled ==true}, :message=>"provide text length"	
		validates_numericality_of :fund_history_2008_max_length,:greater_than=>0,:if=>Proc.new{|default_form| default_form.is_fund_history_2008_length_enabled ==true}, :message=>"provide text length"	
		
end
