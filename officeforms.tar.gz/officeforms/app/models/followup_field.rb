class FollowupField < ActiveRecord::Base
  #validates_presence_of :field_name, :message=>"Field Name can't be blank"
  validates_presence_of :default_value, :message=>"Default Value can't be blank"
  
  belongs_to :office
  has_one :followup_value,  :dependent=>:destroy
  
end
