class FollowupValue < ActiveRecord::Base
	belongs_to :followup_field
	belongs_to :formsubmission
	
	def self.category_followupvalues(category,id)
		find(:all,:conditions=>['field_value = ? and followup_fields.office_id = ?',category,id],:include=>[:followup_field])
	end

end
  