class Formsubmission < ActiveRecord::Base
  
  attr_accessor :off_form #This value can be enabled or disabled,based on validation required for Form Submission - Important Field for Form Submission Validation
  attr_accessor :save_formsubmission_version
  acts_as_commentable
  acts_as_versioned :if => Proc.new { |formsubmission| formsubmission.save_formsubmission_version == true }
#Associations

  belongs_to :office
  belongs_to :user
  belongs_to :attachable, :polymorphic => true
  has_one :whitepaper_upload, :as=>:attachable,:dependent=>:destroy
  has_many :committee_formsubmissions
  has_many :committee_member_comments
  has_many :custom_values
  has_many :agency_custom_values
  has_one :followup_value

#Validations

  validates_presence_of :org_type,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('organization_section',true,'org_type' ) }, :message=>"Provide Organization Type"
  validates_presence_of :org_name,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('organization_section',true,'org_name' ) }, :message=>"Provide Organization Name"
  validates_presence_of :org_address1,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('organization_section',true,'org_address1' ) }, :message=>"Provide Organization Address #1"
  validates_presence_of :org_address2,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('organization_section', true,'org_address2' ) }, :message=>"Provide Organization Address #2"
  validates_presence_of :org_city,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('organization_section', true,'org_city' ) }, :message=>"Provide Organization City"
  validates_presence_of :org_state,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('organization_section',  true,'org_state' ) }, :message=>"Provide Organization State"
  validates_presence_of :org_zip,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'organization_section', true,'org_zip' ) }, :message=>"Provide Organization Zip Code"
  validates_length_of :org_zip,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'organization_section', true,'org_zip' ) },:is => 5, :message=>"Organization Zip Should be of length 5"
  validates_numericality_of :org_zip,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'organization_section', true,'org_zip' ) },:message=>"Organization Zip Should be Numbers" 
  validates_format_of :org_phone, :with => (/^[2-9]\d{2}-\d{3}-\d{4}$/i),:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('organization_section', true,'org_phone' ) }, :message=>"Provide Valid Organization Phone Number"
  validates_presence_of :org_fax,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'organization_section', true,'org_fax' ) }, :message=>"Provide Organization Fax"
  validates_presence_of :org_activities,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('organization_section',  true,'org_activities' ) }, :message=>"Provide Organization Activities"

  validates_presence_of :contact_firstname,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section',true,'contact_firstname' ) }, :message=>"Provide Contact's Firstname"
  validates_presence_of :contact_lastname,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section', true,'contact_lastname' ) }, :message=>"Provide Contact's Lastname"
  validates_presence_of :contact_email,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section', true,'contact_email' ) }, :message=>"Provide Contact's Email"
  validates_presence_of :contact_address1,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section', true,'contact_address1' ) }, :message=>"Provide Contact's Address #1"
  validates_presence_of :contact_address2,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section', true,'contact_address2' ) }, :message=>"Provide Contact's Address #2"
  validates_presence_of :contact_city,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section', true,'contact_city' ) }, :message=>"Provide Contact's City"
  validates_presence_of :contact_state,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section', true,'contact_state' ) }, :message=>"Provide Contact's State"
  validates_length_of :contact_zip, :is => 5,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section',  true,'contact_zip' ) }, :message=>"Contact's Zip code Should be of 5 digit"
  validates_numericality_of :contact_zip,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section',  true,'contact_zip' ) }, :message=>"Provide Contact's Zip code as Numbers"  
  validates_format_of :contact_phone, :with => (/^[2-9]\d{2}-\d{3}-\d{4}$/i),:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section', true,'contact_phone' ) }, :message=>"Provide Valid Contact's Phone Number"
  validates_presence_of :contact_mobile,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('contact_section', true,'contact_mobile' ) }, :message=>"Provide Contact's Mobile Number"

  validates_presence_of :sr_contact_firstname,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('sr_contact_section', true,'sr_contact_firstname' ) }, :message=>"Provide Senior Contact's Firstname"
  validates_presence_of :sr_contact_lastname,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('sr_contact_section',  true,'sr_contact_lastname' ) }, :message=>"Provide Senior Contact's Lastname"
  validates_presence_of :sr_contact_email,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'sr_contact_section', true,'sr_contact_email' ) }, :message=>"Provide Senior Contact's Email"
  validates_presence_of :sr_contact_address1,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('sr_contact_section',  true,'sr_contact_address1' ) }, :message=>"Provide Senior Contact's Address #1"
  validates_presence_of :sr_contact_address2,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'sr_contact_section', true,'sr_contact_address2' ) }, :message=>"Provide Senior Contact's Address #2"
  validates_presence_of :sr_contact_city,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('sr_contact_section',  true,'sr_contact_city' ) }, :message=>"Provide Senior Contact's City"
  validates_presence_of :sr_contact_state,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('sr_contact_section',  true,'sr_contact_state' ) }, :message=>"Provide Senior Contact's State"
  validates_length_of :sr_contact_zip, :is => 5,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('sr_contact_section',  true,'sr_contact_zip' ) }, :message=>"Senior Contact's Zip code Should be of 5 digit"
  validates_numericality_of :sr_contact_zip,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('sr_contact_section',  true,'sr_contact_zip' ) }, :message=>"Provide Senior Contact's Zip code as Numbers"  
  validates_format_of :sr_contact_phone, :with => (/^[2-9]\d{2}-\d{3}-\d{4}$/i),:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('sr_contact_section',  true,'sr_contact_phone' ) }, :message=>"Provide Valid Senior Contact Phone Number"
  validates_presence_of :sr_contact_mobile,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('sr_contact_section',  true,'sr_contact_mobile' ) }, :message=>"Provide Senior Contact Mobile"
 
  validates_presence_of :project_description,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('project_section', true,'project_description' ) }, :message=>"Provide Project Description"
  validates_presence_of :significance,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('project_section', true,'significance' ) }, :message=>"Provide Significance"
  validates_presence_of :expansion_description,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'project_section',true,'expansion_description' ) }, :message=>"Provide Expansion Description"
  
  validates_presence_of :endorsements,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'project_section',true,'endorsements' ) }, :message=>"Provide Endorsements"
  validates_numericality_of :total_cost,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('project_section', true,'total_cost' ) }, :message=>"Provide Valid Total Cost"
  validates_numericality_of  :amount_requested,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?('project_section', true,'amount_requested' ) }, :message=>"Provide Valid Amount Requested"

  validates_presence_of :agency_name,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'agency_section',true,'agency_name' ) }, :message=>"Provide Agency Name"
  validates_presence_of :agency_account,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'agency_section', true,'agency_account' ) }, :message=>"Provide Agency Account"
  validates_presence_of :agency_sub_account,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'agency_section', true,'agency_sub_account' ) }, :message=>"Provide Agency Sub Account"
  validates_presence_of :type_of_request,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?(  'agency_section',true,'type_of_request' ) }, :message=>"Provide Request Type"
  #validates_presence_of :fund_pe,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?(  'agency_section',true,'fund_pe' ) }, :message=>"Provide Fund PE"
  #validates_presence_of :fund_line,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'agency_section', true,'fund_line' ) }, :message=>"Provide Fund Line"
  validates_presence_of :fund_history_2003,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'agency_section', true,'fund_history_2003' ) }, :message=>"Provide Fund History for 2003"
  validates_presence_of :fund_history_2004,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?(  'agency_section',true,'fund_history_2004' ) }, :message=>"Provide Fund History for 2004"
  validates_presence_of :fund_history_2005,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'agency_section', true,'fund_history_2005' ) }, :message=>"Provide Fund History for 2005"
  validates_presence_of :fund_history_2006,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'agency_section', true,'fund_history_2006' ) }, :message=>"Provide Fund History for 2006"
  validates_presence_of :fund_history_2007,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'agency_section', true,'fund_history_2007' ) }, :message=>"Provide Fund History for 2007"
  validates_presence_of :fund_history_2008,:if => Proc.new { |formsubmission| formsubmission.validate_officeform_field?( 'agency_section', true,'fund_history_2008' ) }, :message=>"Provide Fund History for 2008"
  

# to validate All fields from Formsubmission value
  def validate_officeform_field?( off_form_section,val,f )
    unless self.off_form.nil?          
      if (eval("self.off_form.#{f}") == val && eval("self.off_form.#{off_form_section}") == val)
        return true
      else    
        return false
      end
    else
      return false
    end
  end


  def self.user_formsubmission_status(user_form,user)	
    unless user_form.nil?
      if user_form.is_draft == true && user_form.submitted_date.nil? 
        formstatus = "no" #saved as draft
      else
        formstatus = "yes" #submitted
      end
    else
      formstatus = "NA" #submitted    
    end
    return formstatus
  end


  def self.user_formsubmission_date(user_form,user)	
    unless user_form.nil?
      unless user_form.submitted_date.nil?
        sub_date =  user_form.submitted_date.strftime("%d- %b- %y")
      else
        sub_date =  "Drafted on " + user_form.updated_at.strftime("%d- %b- %y")
      end
    else
      sub_date =  " - "
    end
    return sub_date
  end

#For unsaved/unsumbitted forms, user will get reminder notificaitons with list and links from 5 days before the deadline date 

  def self.members_submitform_soon
    closing_officeforms  = Officeform.find :all,:conditions=>['officeforms.active_status = ? and officeforms.submission_end_date > ? and officeforms.submission_end_date < ? and offices.active_status = ?',true,(Date.today),(Date.today+5),true],:include=>[:office]
    closing_officeforms_officeids = closing_officeforms.collect{|x| x.office_id}
    find :all,:conditions=>['office_id in (?) and is_draft = ? and submitted_date is NULL',closing_officeforms_officeids,true]
  end

  #To find forms submitted for an office

  def self.find_forms_office(officeid,per_page,page,sort)
    paginate :conditions =>['office_id = ? ',officeid],:per_page =>per_page,:page=>page,:order =>sort,:include=>[:user,:followup_value]	  
  end

  #To find all forms submitted for an office or forms under all category for an office

  def self.find_all_forms_or_all_categories_of_office(officeid,per_page,page,sort)
    paginate :conditions =>['office_id = ? and is_draft = ? and submitted_date is not NULL',officeid,false],:per_page =>per_page,:page=>page,:order =>sort,:include=>[:user,:followup_value]
  end

  #To find forms submitted for an office under selected category

  def self.find_selected_category_forms_of_office(selected_categoryforms,per_page,page,sort)
    paginate :conditions =>['formsubmissions.id in (?) and is_draft = ? and submitted_date is not NULL',selected_categoryforms,false],:per_page =>per_page,:page=>page,:order =>sort,:include=>[:user,:followup_value]    
  end  

  #To find all forms submitted for an office under all category with search text

  def self.find_forms_of_all_category_with_searchtxt(search,officeid,per_page,page,sort)
    paginate :conditions =>["formsubmissions.office_id = ? and is_draft = ? and submitted_date is not NULL and ((users.firstname like '%%"+search+"%%') or (org_name like '%%"+search+"%%') or (project_description like '%%"+search+"%%'))",officeid,false],:per_page =>per_page,:page=>page,:order =>sort,:include=>[:user,:followup_value]
  end  

  #To find all forms submitted for an office under selected category with search text

  def self.find_forms_of_selected_category_with_searchtxt(selected_categoryforms,search,officeid,per_page,page,sort)
    paginate :conditions =>["formsubmissions.id in (?) and formsubmissions.office_id = ? and is_draft = ? and submitted_date is not NULL and ((users.firstname like '%%"+search+"%%') or (org_name like '%%"+search+"%%') or (project_description like '%%"+search+"%%'))",selected_categoryforms,officeid,false],:per_page =>per_page,:page=>page,:order =>sort,:include=>[:user,:followup_value]
  end  
  
  #To find all forms submitted for an office with search text when logged in as global admin

  def self.find_all_forms_with_searchtxt(search,officeid,per_page,page,sort)
    paginate :conditions =>["formsubmissions.office_id = ? and ((users.firstname like '%%"+search+"%%') or (org_name like '%%"+search+"%%') or (project_description like '%%"+search+"%%'))",officeid],:per_page =>per_page,:page=>page,:order =>sort,:include=>[:user,:followup_value]
  end  
  
   def clear_old_version(version)
      self.class.versioned_class.delete_all ["#{self.class.version_column} = ? and #{self.class.versioned_foreign_key} = ?", version, id]  
   end    
  
end
