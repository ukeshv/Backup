class Office < ActiveRecord::Base

#Associations

has_one :officeform
has_many :officeadmins,:class_name=>'Officeadmin',:conditions=>['is_admin = ?',true]
has_many :officeusers,:class_name=>'Officeadmin',:conditions=>['is_admin = ?',false]
has_many :office_admins_users,:class_name=>'Officeadmin'
has_many :formsubmissions
has_many :custom_fields
has_many :committee_members
has_many :followup_fields

#Validations

validates_presence_of :name,:message=>"Please provide Office Name"
validates_uniqueness_of :name, :message=>"Office Name already exists"
    
validates_presence_of :firstname,:message=>"Please provide Member FirstName"
validates_presence_of :address1,:message=>"Please provide Office Address"
validates_presence_of :city,:message=>"Please provide City"
validates_presence_of :state,:message=>"Please provide State"
validates_length_of :zip, :is => 5, :message=>"Zip code Should be of length 5"
validates_numericality_of :zip, :message=>"Zip code Should be Numbers"	

validates_presence_of :contact_firstname,:message=>"Please provide Office Contact FirstName"
validates_presence_of :contact_email,:message=>"Please provide Office Contact Email"
 validates_format_of :contact_email, :with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i ,:message=>"Please provide a valid Email Address"  
 
 validates_format_of :phone, :with => (/^[2-9]\d{2}-\d{3}-\d{4}$/i) ,:message=>"Please provide a valid Phone Number"  


  def full_name
    "#{firstname}  #{lastname}"
  end
	
  def address
	return self.address1 + ' ' + self.address2
  end

  def contactname
	return self.contact_firstname + ' ' + self.contact_lastname
  end

  def self.active_offices
    find :all,:conditions=>['offices.active_status = ? and officeforms.submission_end_date is not NULL',true],:include=>[:officeform],:order=>['officeforms.submission_end_date asc']
  end
	
  def activestatus
    if self.active_status == true
      return "Active"
    else
      return "Inactive"	
    end
  end
	
	
  def self.export_pdf(offices)
    self.pdf_office(offices)
  end # def ends

  def self.pdf_office(offices)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    
    pdf = table(pdf,offices)
    return pdf
  end

  def self.table(pdf,offices)
    pdf.select_font("Helvetica")

    PDF::SimpleTable.new do |tab|
      tab.title = "List of Offices"
      tab.column_order.push(*%w(from1 to1 from2 to2 from3 to3 from4 to4))

      tab.columns["from1"] = PDF::SimpleTable::Column.new("from1") { |col|
       col.heading = "Name"
      }
      tab.columns["to1"] = PDF::SimpleTable::Column.new("to1") { |col|
       col.heading = "Member Name"
      }
      tab.columns["from2"] = PDF::SimpleTable::Column.new("from2") { |col|
        col.heading = "Address"
     }
     tab.columns["to2"] = PDF::SimpleTable::Column.new("to2") { |col|
       col.heading = "City"
     }
      tab.columns["from3"] = PDF::SimpleTable::Column.new("from3") { |col|
       col.heading = "State"
     }
	 tab.columns["to3"] = PDF::SimpleTable::Column.new("to3") { |col|
       col.heading = "Zip"
     }
      tab.columns["from4"] = PDF::SimpleTable::Column.new("from4") { |col|
       col.heading = "Phone"
     }
      tab.columns["to4"] = PDF::SimpleTable::Column.new("to4") { |col|
       col.heading = "Status"
     }

     tab.show_lines    = :all
     tab.show_headings = true
     tab.orientation   = :center
     tab.position      = :center
     tab.width = pdf.page_width - 25

    data = [ ]

    for office in offices
      data += [
            { "from1" => "#{office.name}", "to1" => "#{office.full_name}","from2" => "#{office.address}", "to2" => "#{office.city}" ,"from3" => "#{office.state}", "to3" => "#{office.zip}","from4" => "#{office.phone}", "to4" => "#{office.activestatus}"  }
        ]
    end

      tab.data.replace data
      tab.render_on(pdf)
    end
    return pdf
  end   

  def address
	return self.address1 + ' ' + self.address2
  end

  def self.export_list_forms_pdf(list_forms)
    self.pdf_list_forms(list_forms)
  end

  def self.pdf_list_forms(list_forms)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    
    pdf = list_formtable(pdf,list_forms)
    return pdf
  end

  def self.list_formtable(pdf,list_forms)
    pdf.select_font("Helvetica")

    PDF::SimpleTable.new do |tab|
      tab.title = "List of Submitted Forms"
      tab.font_size = 4
      tab.column_order.push(*%w(from1 to1 from2 to2  to3 from4 to4 from5 to5))

      tab.columns["from1"] = PDF::SimpleTable::Column.new("from1") { |col|
       col.heading = "OrgType"
      }
      tab.columns["to1"] = PDF::SimpleTable::Column.new("to1") { |col|
       col.heading = "OrgName"
      }
      tab.columns["from2"] = PDF::SimpleTable::Column.new("from2") { |col|
        col.heading = "OrgAddress1"
     }
     tab.columns["to2"] = PDF::SimpleTable::Column.new("to2") { |col|
       col.heading = "OrgAddress2"
     }
      tab.columns["from3"] = PDF::SimpleTable::Column.new("from3") { |col|
       col.heading = "OrgCity"
     }
	 tab.columns["to3"] = PDF::SimpleTable::Column.new("to3") { |col|
       col.heading = "OrgState"
     }
      tab.columns["from4"] = PDF::SimpleTable::Column.new("from4") { |col|
       col.heading = "OrgZip"
     }
      tab.columns["to4"] = PDF::SimpleTable::Column.new("to4") { |col|
       col.heading = "OrgPhone"
     }
      tab.columns["from5"] = PDF::SimpleTable::Column.new("from5") { |col|
       col.heading = "OrgFax"
     }
      tab.columns["to5"] = PDF::SimpleTable::Column.new("to5") { |col|
       col.heading = "OrgActivities"
     }
   
     tab.show_lines    = :all
     tab.show_headings = true
     tab.orientation   = :center
     tab.position      = :center
     tab.width = pdf.page_width

    data = [ ]

    for list_form in list_forms
      data += [
         { "from1" => "#{list_form.org_type}", "to1" => "#{list_form.org_name}","from2" => "#{list_form.org_address1}", "to2" => "#{list_form.org_address2}","from3" => "#{list_form.org_city}", "to3" => "#{list_form.org_state}","from4" => "#{list_form.org_zip}", "to4" => "#{list_form.org_phone}" ,"from5" => "#{list_form.org_fax}", "to5" => "#{list_form.org_activities}"}
        ]
    end

      tab.data.replace data
      tab.render_on(pdf)
    end
    return pdf
  end   


end
