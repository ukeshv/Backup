class OfficeField < ActiveRecord::Base
end
