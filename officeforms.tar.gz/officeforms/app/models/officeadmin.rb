require 'digest/sha1'
class Officeadmin < ActiveRecord::Base

#Associations

belongs_to :office
has_many :committee_formsubmissions

# Virtual attribute for the unencrypted password
attr_accessor :password
  

	validates_presence_of  :email,:message=>'Admin/User Email Cant be blank'
	validates_presence_of  :login,:message=>'Admin Login Cant be blank'
	validates_presence_of  :password,:if => :password_required?,:message=>'Password Cant be blank'
	validates_presence_of  :password_confirmation,:if => :password_required?,:message=>'Please retype your password'
	validates_length_of  :password, :within => 4..40, :if => :password_required?
	validates_confirmation_of :password,:if => :password_required?,:message=>'Mismatch in Passwords'
	validates_length_of  :email,:within => 3..100
	validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/i,:message=>"Please provide a valid Email Address"  
	validates_length_of  :login,:within => 3..40
	validates_uniqueness_of :login,:email, :case_sensitive => false
	
	validates_presence_of :firstname,:message=>"Please provide Member FirstName"
	validates_presence_of :address1,:message=>"Please provide Office Address"
	validates_presence_of :city,:message=>"Please provide City"
	validates_presence_of :state,:message=>"Please select State"
	validates_length_of :zip, :is => 5, :message=>"Zip code Should be of length 5"
	validates_numericality_of :zip, :message=>"Zip code Should be Numbers"	

	validates_format_of :phone, :with => (/^[2-9]\d{2}-\d{3}-\d{4}$/i) ,:message=>"Please provide a valid Phone Number" 
  
  before_save :encrypt_password

  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  def self.authenticate(login, password)
    u = find_by_login(login) # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  # Encrypts some data with the salt.
  def self.encrypt(password, salt)
    Digest::SHA1.hexdigest("--#{salt}--#{password}--")
  end

  # Encrypts the password with the user salt
  def encrypt(password)
    self.class.encrypt(password, salt)
  end

  def authenticated?(password)
    crypted_password == encrypt(password)
  end

def full_name
    return self.firstname + ' ' + self.lastname 
  end

def self.office_admins(officeid)
	find :all,:conditions=>['office_id = ?',officeid]
end

def self.find_for_forget(email)
     find :first, :conditions => ['email = ?', email]
   end

   def forgot_password
     @forgotten_password = true
     self.make_password_reset_code
   end

  def recently_forgot_password?
     @forgotten_password
   end

 def recently_reset_password?
     @reset_password
   end

 def reset_password
     # First update the password_reset_code before setting the
     # reset_password flag to avoid duplicate email notifications.
     update_attribute(:password_reset_code, nil)
     @reset_password = true
   end 

  def activestatus
    if self.active_status == true
      return "Active"
    else
      return "Inactive"	
    end
  end

  def admin_status
    if self.is_admin == true
      return "Admin"
    else
      return "User"	
    end
  end

  #To join all the default values(separated by a line) of Followup fields for an office and to display in a drop down

  def find_defaultvalues
    default_values = self.office.followup_fields.collect{|x| x.default_value}
    categories = default_values#.join(',').gsub(',',' ').split(' ')
    return categories
  end

  def self.export_admin_user_pdf(office_admins_users,office)
    self.pdf_officeadmin(office_admins_users,office)
  end # def ends

  def self.pdf_officeadmin(office_admins_users,office)
    require 'pdf/writer'
    require 'pdf/simpletable'
    pdf = PDF::Writer.new
    lines=[]
    
    pdf = table(pdf,office_admins_users,office)
    return pdf
  end

  def self.table(pdf,office_admins_users,office)
    pdf.select_font("Helvetica")

    PDF::SimpleTable.new do |tab|
      tab.title = "List of Admins/Users - #{office.name}"
      tab.column_order.push(*%w(from1 to1 from2 to2 from3 to3 from4 to4 from5))

      tab.columns["from1"] = PDF::SimpleTable::Column.new("from1") { |col|
       col.heading = "Name"
      }
      tab.columns["to1"] = PDF::SimpleTable::Column.new("to1") { |col|
       col.heading = "Email"
      }
      tab.columns["from2"] = PDF::SimpleTable::Column.new("from2") { |col|
        col.heading = "Address"
     }
     tab.columns["to2"] = PDF::SimpleTable::Column.new("to2") { |col|
       col.heading = "City"
     }
      tab.columns["from3"] = PDF::SimpleTable::Column.new("from3") { |col|
       col.heading = "State"
     }
      tab.columns["to3"] = PDF::SimpleTable::Column.new("to3") { |col|
       col.heading = "Zip"
     }
      tab.columns["from4"] = PDF::SimpleTable::Column.new("from3") { |col|
       col.heading = "Phone"
     }
      tab.columns["to4"] = PDF::SimpleTable::Column.new("to3") { |col|
       col.heading = "Admin/User"
     }
      tab.columns["from5"] = PDF::SimpleTable::Column.new("from5") { |col|
       col.heading = "Status"
     }

     tab.show_lines    = :all
     tab.show_headings = true
     tab.orientation   = :center
     tab.position      = :center
     tab.width = pdf.page_width - 25

    data = [ ]

    for office_admin_user in office_admins_users
      data += [
         { "from1" => "#{office_admin_user.full_name}", "to1" => "#{office_admin_user.email}","from2" => "#{office_admin_user.address}", "to2" => "#{office_admin_user.city}" ,"from3" => "#{office_admin_user.state}", "to3" => "#{office_admin_user.zip}","from4" => "#{office_admin_user.phone}","to4" => "#{office_admin_user.admin_status}","from5" => "#{office_admin_user.activestatus}" },
        ]
    end

      tab.data.replace data
      tab.render_on(pdf)
    end
    return pdf
  end   

  def address
	return self.address1 + ' '+ self.address2
  end	
	
	
  protected
    # before filter 
    def encrypt_password
      return if password.blank?
      self.salt = Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{login}--") if new_record?
      self.crypted_password = encrypt(password)
    end
    
    def password_required?
      crypted_password.blank? || !password.blank?
    end
    
      def make_password_reset_code
      self.password_reset_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
    end
end
