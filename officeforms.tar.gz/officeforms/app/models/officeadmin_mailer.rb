class OfficeadminMailer < ActionMailer::Base
	
  def submitnewform_notification_by_public_user(officeuser,user,formid)
   @subject  = 'New Form has been submitted by public user'
   @from = "#{$site_admin_email}"
   @recipients  = "#{officeuser.email}"
   @content_type = "text/html"
   @body[:officeuser] = officeuser
   @body[:user] = user
   @body[:url] = $site_url + "office_admin/formsummary/#{formid}"
  end
  
  def submitnewform_notification(officeuser,officeadmin,formid)
   @subject  = 'New Form has been submitted'
   @from = "#{officeadmin.email}"
   @recipients  = "#{officeuser.email}"
   @content_type = "text/html"
   @body[:officeuser] = officeuser
   @body[:officeadmin] = officeadmin
   @body[:url] = $site_url + "admin/formsummary/#{formid}"
  end
  
  
   def forgot_password(officeadmin)
     setup_email(officeadmin)
     @subject    += 'You have requested to change your password'
     @body[:url]  =   $site_url +  "passwords/edit_admin/#{officeadmin.password_reset_code}"
   end
  
   def reset_password(officeadmin)
     setup_email(officeadmin)
     @subject    += 'Your password has been reset.'
   end

   def form_submitters(officeadmin,recipient)
    @subject  = "Form submission comment/question - "
    @from = "#{officeadmin.email}"
    @recipients  = recipient
    @content_type = "text/html"
    @body[:officeadmin] = officeadmin
  end 

  def mail_referrer(recipient,officemember,form)
    @subject  = "Form for Reference - "
    @from = "#{officemember.email}"
    @recipients  = "#{recipient.email}"
    @content_type = "text/html"
    @body[:officemember] = officemember
    @body[:recipient] = recipient
    @body[:form] = form
    @body[:url] = $site_url +  "admin/formsummary/#{form.id}"
  end 
  
  protected
    def setup_email(officeadmin)
      @recipients  = "#{officeadmin.email}"
      @from        = "#{$site_admin_email}"
      @subject     ="Hillforms.com - "
      @sent_on     = Time.now
      @body[:officeadmin] = officeadmin
    end
    
end
