class Organization < ActiveRecord::Base
	validates_presence_of :name, :message=>"Organization Name can't be blank"
    validates_length_of :name, :in => 5..30, :message=>"Organization Name should be between 5 to 20 characters", :too_short => 'Name must be at least 2 characters long.  Please provide a longer Name', :too_long=> 'Name can be no longer than 40 characters. Please provide a shorter Name' 
    validates_uniqueness_of :name, :message=>'Name is Already choosen'

end
