require 'digest/sha1'
class User < ActiveRecord::Base
  # Virtual attribute for the unencrypted password
  attr_accessor :password
  attr_accessor :skip_pwd
  attr_accessor :skip_office
  apply_simple_captcha
  
  validates_presence_of     :email,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) },:message=>'Provide Email'
  validates_length_of       :email,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) },:within => 3..100
  validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i ,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) },:message=>"Provide a valid Email Address"  
  validates_uniqueness_of  :email, :case_sensitive => false,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) },:message=>"Email has already been taken"  
  
  validates_presence_of     :password,:if => :password_required?,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) },:message=>'Provide Password'
  validates_presence_of     :password_confirmation, :if => :password_required?,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) },:message=>'Please retype your password'
  #validates_length_of       :password, :within => 4..40, :if => :password_required?
  validates_confirmation_of :password,:if => :password_required?,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) },:message=>"Doesn't match with the confirmation password"
  validates_format_of :password, :with => /^(?=.*\d)[*\w]{8,40}$/ , :if =>Proc.new { |user| user.validate_pwd?( 1 ) },:message=>"Password Should be of length 8 and contain atleast one integer. "
  
  validates_presence_of :firstname,:message=>'Provide First Name'
  #validates_presence_of :lastname,:message=>'Provide Last Name'
  validates_length_of :firstname, :within => 2..40,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) }, :too_short => 'First Name must be at least 2 characters long.  Please provide a longer Name', :too_long=> 'First Name can be no longer than 40 characters. Please provide a shorter Name'
  validates_presence_of :address1,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) },:message=>'Provide Address #1'
  validates_presence_of :city,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) },:message=>'Provide City'
  validates_presence_of :state,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) },:message=>'Provide State'
  
  validates_length_of :zip, :is => 5,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) }, :message=>"Zip code Should be of length 5"
  validates_numericality_of :zip,:unless =>Proc.new { |user| user.validate_officesubmit?( 1 ) }, :message=>"Zip code Should be Numbers"  
  
  before_save :encrypt_password
  before_create :make_activation_code 
  
  has_many :formsubmissions
  
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  #attr_accessible :email, :password, :password_confirmation


#------------------------------------------------------------------------------
#  Constants
#------------------------------------------------------------------------------

#States In US  
    STATES = [
    [ 'Alabama', 'Alabama'],
    [ 'Alaska', 'Alaska'], 
    [ 'AmericanSamoa', 'AmericanSamoa'], 
    [ 'Arizona', 'Arizona'], 
    [ 'Arkansas', 'Arkansas'],
    [ 'California', 'California'],
    [ 'Colorado', 'Colorado'],
    [ 'Connecticut', 'Connecticut'],
    [ 'Delaware', 'Delaware'],
    [ 'District of Columbia', 'District of Columbia'],
    [ 'FederatedStates of Micronesia', 'FederatedStates of Micronesia'],
    [ 'Florida', 'Florida'],
    [ 'Georgia', 'Georgia'],
    [ 'Guam', 'Guam'],
    [ 'Hawaii', 'Hawaii'],
    [ 'Idaho', 'Idaho'],
    [ 'Illinois', 'Illinois'],
    [ 'Indiana', 'Indiana'],
    [ 'Iowa', 'Iowa'],
    [ 'Kansas', 'Kansas'],
    [ 'Kentucky', 'Kentucky'],
    [ 'Louisiana', 'Louisiana'],
    [ 'Maine', 'Maine'],
    [ 'MarshallIslands', 'MarshallIslands'],
    [ 'Maryland', 'Maryland'],
    [ 'Massachusetts', 'Massachusetts'],
    [ 'Michigan', 'Michigan'],
    [ 'Minnesota', 'Minnesota'],
    [ 'Mississippi', 'Mississippi'],
    [ 'Missouri', 'Missouri'],
    [ 'Montana', 'Montana'],
    [ 'Nebraska', 'Nebraska'],
    [ 'Nevada', 'Nevada'],
    [ 'New Jersey', 'New Jersey'],
    [ 'New Hampshire', 'New Hampshire'],
    [ 'New Mexico', 'New Mexico'  ],
    [ 'New York', 'New York'  ],
    [ 'North Carolina', 'North Carolina'  ],
    [ 'North Dakota', 'North Dakota'  ],
    [ 'NorthernMariana Islands', 'NorthernMariana Islands'  ],
    [ 'Ohio', 'Ohio'  ],
    [ 'Oklahoma', 'Oklahoma'  ],
    [ 'Oregon', 'Oregon'  ],
    [ 'Pennsylvania', 'Pennsylvania'  ],
    [ 'Puerto Rico', 'Puerto Rico'  ],
    [ 'Republic of Palau', 'Republic of Palau'  ],
    [ 'Rhode Island', 'Rhode Island'  ],
    [ 'South Carolina', 'South Carolina'  ],
    [ 'South Dakota', 'South Dakota'  ],
    [ 'Tenessee', 'Tenessee'  ],
    [ 'Texas', 'Texas'  ],
    [ 'U.S. MinorOutlying Islands', 'U.S. MinorOutlying Islands'  ],
    [ 'Utah', 'Utah'  ],
    [ 'Vermont', 'Vermont'  ],
    [ 'VirginIslands', 'VirginIslands'  ],
    [ 'Virginia', 'Virginia'  ],
    [ 'Washington', 'Washington'  ],
    [ 'West Virginia', 'West Virginia'  ],
    [ 'Wisconsin', 'Wisconsin'  ],
    [ 'Wyoming', 'Wyoming'  ]   
  ].freeze


# to validate field values depending upon step value available
    def validate_pwd?( step1 )          
         if (skip_pwd == step1)
          return true
        else
          return false
        end
      end

# to validate field values depending upon step value available
    def validate_officesubmit?( step2 )          
         if (skip_office == step2)
          return true
        else
          return false
        end
      end

  # Activates the user in the database.
  def activate
    @activated = true
    self.activated_at = Time.now.utc
    self.activation_code = nil
    save(false)
  end

  def active?
    # the existence of an activation code means they have not activated yet
    activation_code.nil?
  end

  # Authenticates a user by their email name and unencrypted password.  Returns the user or nil.
  def self.authenticate(email, password)
    u = find :first, :conditions => ['email = ? and activated_at IS NOT NULL', email] # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  # Encrypts some data with the salt.
  def self.encrypt(password, salt)
    Digest::SHA1.hexdigest("--#{salt}--#{password}--")
  end

  # Encrypts the password with the user salt
  def encrypt(password)
    self.class.encrypt(password, salt)
  end

  def authenticated?(password)
    crypted_password == encrypt(password)
  end

  def remember_token?
    remember_token_expires_at && Time.now.utc < remember_token_expires_at 
  end

  # These create and unset the fields required for remembering users between browser closes
  def remember_me
    remember_me_for 2.weeks
  end

  def remember_me_for(time)
    remember_me_until time.from_now.utc
  end

  def remember_me_until(time)
    self.remember_token_expires_at = time
    self.remember_token            = encrypt("#{email}--#{remember_token_expires_at}")
    save(false)
  end

  def forget_me
    self.remember_token_expires_at = nil
    self.remember_token            = nil
    save(false)
  end

  # Returns true if the user has just been activated.
  def recently_activated?
    @activated
  end

 def self.find_for_forget(email)
     find :first, :conditions => ['email = ? and activated_at IS NOT NULL', email]
   end
 

   def forgot_password
     @forgotten_password = true
     self.make_password_reset_code
   end

  def recently_forgot_password?
     @forgotten_password
   end

 def recently_reset_password?
     @reset_password
   end

 def reset_password
     # First update the password_reset_code before setting the
     # reset_password flag to avoid duplicate email notifications.
     update_attribute(:password_reset_code, nil)
     @reset_password = true
   end  

def fullname
    return self.firstname + ' ' + self.lastname 
  end


def full_name
    return self.firstname + ' ' + self.lastname 
  end

def address
    return self.address1 + ' ' + self.address2
  end
  
  def self.active_users
	find :all,:conditions=>['active_status = ?',true]  
  end

  def activestatus
    if self.active_status == true
      return "Active"
    else
      return "Inactive"	
    end
  end
	
	def address
	return self.address1 + ' ' + self.address2
  end

	
  protected
    # before filter 
    def encrypt_password
      return if password.blank?
      self.salt = Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{email}--") if new_record?
      self.crypted_password = encrypt(password)
    end
      
    def password_required?
      crypted_password.blank? || !password.blank?
    end
    
    def make_activation_code

      self.activation_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
    end
    
  def make_password_reset_code
      self.password_reset_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
    end
  
  
end
