class UserMailer < ActionMailer::Base
  def signup_notification(user)
    setup_email(user)
    @subject    += 'Please activate your new account'
  
    @body[:url]  =  $site_url + "activate/#{user.activation_code}"
  
  end
  
  def activation(user)
    setup_email(user)
    @subject    += 'Your account has been activated!'
    @body[:url]  =  $site_url + 'login'
  end
  
   def forgot_password(user)
     setup_email(user)
     @subject    += 'You have requested to change your password'
     @body[:url]  =   $site_url +  "reset_password/#{user.password_reset_code}"
   end
  
   def reset_password(user)
     setup_email(user)
     @subject    += 'Your password has been reset.'
   end
   
   def form_submission(form_submission,user,custom_values,agency_custom_values)
	setup(form_submission,user)
	officeform = form_submission.office.officeform
	@subject +='Form Submission'
	@body[:office_form] = officeform
	@body[:form_submission] = form_submission
	@body[:custom_values] = custom_values
	@body[:agency_custom_values] = agency_custom_values
	@content_type = "text/html"
   end
 
   def submitform_soon_notification(form_submission)
    @subject  = 'Reminder: Your Form Submission Date is about to expire soon'
    @from = %("App2 Admin" <admin@app2.com>)
    @recipients  = "#{form_submission.user.email}"
    @content_type = "text/html"
    @body[:form_submission] = form_submission
    @body[:url] = $site_url + 'login'
  end 
 
  protected
    def setup_email(user)
      @recipients  = "#{user.email}"
      @from        = "#{$site_admin_email}"
      @subject     ="Hillforms.com - "
      @sent_on     = Time.now
      @body[:user] = user
    end
    
    def setup(form_submission,user)
      @recipients  = "#{user.email}"
      @from        = "#{$site_admin_email}"
      @subject     ="Hillforms.com - "
      @sent_on     = Time.now
      @body[:user] = user   
    end
end
