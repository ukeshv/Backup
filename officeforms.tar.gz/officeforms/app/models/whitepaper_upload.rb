class WhitepaperUpload < ActiveRecord::Base

has_attachment :storage => :file_system,:path_prefix => '/data/whitepapers'  

belongs_to :attachable, :polymorphic => true

attr_accessor :save_whitepaper_version #when a upload of a form is destroyed,there will be no cloning of white paper uploaded .If this variable is not used,second version for a form will be saved.
acts_as_versioned :if => Proc.new { |whitepaper| whitepaper.save_whitepaper_version == true } #there will be no second version of white paper for a form

	#validates_as_attachment
=begin	
	def validate
      # Files should only be DOC or PDF
      [:content_type].each do |attr_name|
        enum = attachment_options[attr_name]
        unless enum.nil? || enum.include?(send(attr_name))
          self.errors.add :content_type,"You can only upload DOC or PDF files"
        end
      end
      
      # File size should be from 1 Byte to 2 MB
      [:size].each do |attr_name|
        enum = attachment_options[attr_name]
        unless enum.nil? || enum.include?(send(attr_name))
          self.errors.add :size,"File size should be less than 2 MB"
        end  
      end
      
  end	
=end	
end
