class WhitepaperUploadVersion < ActiveRecord::Base
	
 def self.find_all_versions(form_id)
	last_rec = find(:last,:conditions=>["attachable_id 	= ? and attachable_type = ?",form_id,"Formsubmission"])
	
	last_id = last_rec.id if !last_rec.nil?
	
	all_versions = find(:all,:conditions=>["attachable_id 	= ? and attachable_type = ? and id not in (?)",form_id,"Formsubmission",last_id]).collect{|x|x.id} if !last_id.nil?
	
	self.delete_all ["id in (?)",all_versions]	
	
 end

 def self.find_original_version(form_id)
	 find(:first,:conditions=>["attachable_id 	= ? and attachable_type = ?",form_id,"Formsubmission"])	 
 end	

end
