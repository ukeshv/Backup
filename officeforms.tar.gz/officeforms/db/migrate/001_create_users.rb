class CreateUsers < ActiveRecord::Migration
  def self.up
    create_table :users do |t|
	t.column :email, :string,:limit=>50
	t.column :crypted_password, :string, :limit => 40  
	t.column :salt, :string, :limit => 40  
	t.column :activation_code, :string,:limit => 40  
	t.column :activated_at,:datetime
	t.column :firstname, :string,:limit=>100
	t.column :lastname, :string,:limit=>100
	t.column :address1, :string,:limit=>100
	t.column :address2, :string,:limit=>100
	t.column :city, :string,:limit=>50
	t.column :state, :string,:limit=>50
	t.column :phone, :string,:limit=>20
	t.column :zip, :string,:limit=>10
	t.column :fax, :string,:limit=>20
	t.column :last_loggedin,:datetime   
	t.column :active_status, :boolean,:default=>false
	t.column :password_reset_code,:string, :limit => 40 
	t.column :remember_token,:string,:limit=>100  
	t.column :remember_token_expires_at ,:datetime
	t.column :created_at, :datetime
	t.column :updated_at, :datetime
      end
  end

  def self.down
    drop_table :users
  end
end
