class CreateOffices < ActiveRecord::Migration
  def self.up
    create_table :offices do |t|
       t.column :name, :string,:limit=>100
       t.column :firstname, :string,:limit=>100
       t.column :lastname, :string,:limit=>100
	   t.column :address1, :string,:limit=>100
       t.column :address2, :string,:limit=>100
       t.column :city, :string,:limit=>50
       t.column :state, :string,:limit=>50
       t.column :zip, :string,:limit=>10
	t.column :phone, :string,:limit=>20
       t.column :fax, :string,:limit=>20
	   t.column :contact_firstname, :string,:limit=>100
       t.column :contact_lastname, :string,:limit=>100
	   t.column :contact_email, :string,:limit=>50
	   t.column :active_status, :boolean,:default =>true
	   t.column :created_at, :datetime
       t.column :updated_at, :datetime
       t.column :created_by, :datetime
       t.column :updated_by, :datetime
  
    end
  end

  def self.down
    drop_table :offices
  end
end
