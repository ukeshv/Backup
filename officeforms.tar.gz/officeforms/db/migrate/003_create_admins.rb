class CreateAdmins < ActiveRecord::Migration
  def self.up
    create_table :admins do |t|
       t.column :login, :string,:limit=>100
       t.column :email, :string,:limit=>50
       t.column :crypted_password, :string,:limit=>40
       t.column :salt, :string,:limit=>40
       t.column :firstname, :string,:limit=>50
       t.column :lastname, :string,:limit=>50
	   t.column :address1, :string,:limit=>100
       t.column :address2, :string,:limit=>100
       t.column :city, :string,:limit=>50
       t.column :state, :string,:limit=>50
       t.column :zip, :string,:limit=>10
	t.column :phone, :string,:limit=>20
       t.column :fax, :string,:limit=>20
	   t.column :active_status, :boolean
	   t.column :created_at, :datetime
       t.column :updated_at, :datetime


    end
    Admin.create!(:login=>'admin', :email=>'admin@railsfactory.com',:firstname=>'Admin', :lastname=>'RailsFactory', :password=>'officeforms', :password_confirmation=>'officeforms',:address1=>'Piedras No 623',:city=>'LOS ANGELES',:state=>'California',:zip=>'90201',:active_status=>true)
  end

  def self.down
    drop_table :admins
  end
end
