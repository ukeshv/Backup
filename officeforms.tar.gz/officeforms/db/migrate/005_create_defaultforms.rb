class CreateDefaultforms < ActiveRecord::Migration
  def self.up
    create_table :defaultforms do |t|
		
	t.column :organization_section,:boolean
	t.column :org_type, :boolean
	t.column :org_name, :boolean
	t.column :org_address1, :boolean
	t.column :org_address2, :boolean
	t.column :org_city, :boolean
	t.column :org_state, :boolean
	t.column :org_zip, :boolean
	t.column :org_phone, :boolean
	t.column :org_fax, :boolean
	t.column :org_activities, :boolean

	t.column :contact_section,:boolean
	t.column :contact_firstname, :boolean
	t.column :contact_lastname, :boolean
	t.column :contact_email, :boolean
	t.column :contact_address1, :boolean
	t.column :contact_address2, :boolean
	t.column :contact_city, :boolean
	t.column :contact_state, :boolean
	t.column :contact_zip, :boolean
	t.column :contact_phone, :boolean
	t.column :contact_mobile, :boolean

	t.column :sr_contact_section,:boolean
	t.column :sr_contact_firstname, :boolean
	t.column :sr_contact_lastname, :boolean
	t.column :sr_contact_email, :boolean
	t.column :sr_contact_address1, :boolean
	t.column :sr_contact_address2, :boolean
	t.column :sr_contact_city, :boolean
	t.column :sr_contact_state, :boolean
	t.column :sr_contact_zip, :boolean
	t.column :sr_contact_phone, :boolean
	t.column :sr_contact_mobile, :boolean

	t.column :representative_section,:boolean
	t.column :is_lobby_list, :boolean
	t.column :representative_firstname, :boolean
	t.column :representative_lastname, :boolean
	t.column :representative_email, :boolean
	t.column :representative_firmname, :boolean
	t.column :representative_address1, :boolean
	t.column :representative_address2, :boolean
	t.column :representative_city, :boolean
	t.column :representative_state, :boolean
	t.column :representative_zip, :boolean
	t.column :representative_phone, :boolean
	t.column :representative_mobile, :boolean

	t.column :project_section,:boolean
	t.column :project_description, :boolean
	t.column :white_paper, :boolean
	t.column :significance, :boolean
	t.column :expansion_description, :boolean
	t.column :is_funding_under_law, :boolean
	t.column :fundlaw_description, :boolean
	t.column :endorsements, :boolean
	t.column :total_cost, :boolean
	t.column :amount_requested, :boolean

	t.column :agency_section,:boolean
	t.column :agency_name,:boolean
	t.column :agency_account,:boolean
	t.column :agency_sub_account,:boolean
	t.column :type_of_request,:boolean
	t.column :fund_pe,:boolean
	t.column :fund_line,:boolean
	t.column :fund_history_2003,:boolean
	t.column :fund_history_2004,:boolean
	t.column :fund_history_2005,:boolean
	t.column :fund_history_2006,:boolean
	t.column :fund_history_2007,:boolean
	t.column :fund_history_2008,:boolean
	t.timestamps
   end
  end

  def self.down
    drop_table :defaultforms
  end
end
