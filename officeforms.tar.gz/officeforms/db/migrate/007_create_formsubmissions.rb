class CreateFormsubmissions < ActiveRecord::Migration
  def self.up
    create_table :formsubmissions do |t|
       t.column:office_id,:integer 
	   t.column:user_id,:integer
     	t.column :org_type, :string,:limit=>100
		t.column :org_name, :string,:limit=>100
       t.column :org_address1, :string,:limit=>100
       t.column :org_address2, :string,:limit=>100
       t.column :org_city, :string,:limit=>50
       t.column :org_state, :string,:limit=>50
       t.column :org_zip, :string,:limit=>10
	t.column :org_phone, :string,:limit=>20
       t.column :org_fax, :string,:limit=>20
	   t.column :org_activities, :text
	   
	   
	   t.column :contact_firstname, :string,:limit=>100
	   t.column :contact_lastname, :string,:limit=>100
	   t.column :contact_email, :string,:limit=>50
       t.column :contact_address1, :string,:limit=>100
       t.column :contact_address2, :string,:limit=>100
       t.column :contact_city, :string,:limit=>50
       t.column :contact_state, :string,:limit=>50
       t.column :contact_zip, :string,:limit=>10
       t.column :contact_phone, :string,:limit=>20
       t.column :contact_mobile, :string,:limit=>20
	   
	   
	   t.column :sr_contact_firstname, :string,:limit=>100
	   t.column :sr_contact_lastname, :string,:limit=>100
	   t.column :sr_contact_email, :string,:limit=>50
       t.column :sr_contact_address1, :string,:limit=>100
       t.column :sr_contact_address2, :string,:limit=>100
       t.column :sr_contact_city, :string,:limit=>50
       t.column :sr_contact_state, :string,:limit=>50
       t.column :sr_contact_zip, :string,:limit=>10
	t.column :sr_contact_phone, :string,:limit=>20
       t.column :sr_contact_mobile, :string,:limit=>20
	   
	   t.column :is_lobby_list, :boolean,:default=>true
	   t.column :representative_firstname, :string,:limit=>100
	   t.column :representative_lastname, :string,:limit=>100
	   t.column :representative_email, :string,:limit=>50
	   t.column :representative_firmname, :string,:limit=>100
	   t.column :representative_address1, :string,:limit=>100
       t.column :representative_address2, :string,:limit=>100
       t.column :representative_city, :string,:limit=>50
       t.column :representative_state, :string,:limit=>50
       t.column :representative_zip, :string,:limit=>10
        t.column :representative_phone, :string,:limit=>20
       t.column :representative_mobile, :string,:limit=>20
	   
	   
	   t.column :project_description, :text
	   t.column :significance, :text
       t.column :expansion_description, :text
       t.column :is_funding_under_law, :boolean,:default=>true
       t.column :fundlaw_description, :text
       t.column :endorsements, :text
       t.column :total_cost, :float,:default=>0.0
       t.column :amount_requested, :float,:default=>0.0
	   
	   
       t.column :agency_name,:string,:limit=>100
	   t.column :agency_account,:string,:limit=>100
	   t.column :agency_sub_account,:string,:limit=>100
	   t.column :type_of_request,:string,:limit=>50
	   t.column :fund_pe,:string,:limit=>100
	   t.column :fund_line,:string,:limit=>100
	   t.column :fund_history_2003,:text
	   t.column :fund_history_2004,:text
	   t.column :fund_history_2005,:text
	   t.column :fund_history_2006,:text
	   t.column :fund_history_2007,:text
	   t.column :fund_history_2008,:text
	   t.column :submitted_date,:datetime
	   t.column :is_draft,:boolean,:default=>false
	   t.timestamps
    end
  end

  def self.down
    drop_table :formsubmissions
  end
end
