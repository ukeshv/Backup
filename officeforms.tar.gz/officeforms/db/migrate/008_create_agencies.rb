class CreateAgencies < ActiveRecord::Migration
  def self.up
    create_table :agencies do |t|

       t.column :name, :string,:limit=>50
	    t.column :delete_status,:boolean,:default=>false
		 t.column :created_at, :datetime
       t.column :updated_at, :datetime
    end
  end

  def self.down
    drop_table :agencies
  end
end
