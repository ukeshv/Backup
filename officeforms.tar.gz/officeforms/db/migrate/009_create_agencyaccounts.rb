class CreateAgencyaccounts < ActiveRecord::Migration
  def self.up
    create_table :agencyaccounts do |t|
		t.column :agency_id,:integer
		t.column :name,:string,:limit=>50
        t.column :parent_id,:integer,:default=>0		
		t.column :delete_status,:boolean,:default=>false
        t.column :created_at, :datetime
        t.column :updated_at, :datetime
	    t.column :created_by, :datetime
        t.column :updated_by, :datetime
 
    end
  end

  def self.down
    drop_table :agencyaccounts
  end
end
