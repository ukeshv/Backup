class CreateOrganizations < ActiveRecord::Migration
  def self.up
    create_table :organizations do |t|
        t.column :name,:string,:limit=>100
        t.column :delete_status,:boolean,:default=>false
        t.column :created_by, :string,:limit=>50
        t.column :updated_by, :string,:limit=>50 
		t.timestamps
    end

Organization.create!(:name=>"Public",:delete_status=>true,:created_by=>"admin",:updated_by=>"admin")
Organization.create!(:name=>"Private Non-Profit",:delete_status=>true,:created_by=>"admin",:updated_by=>"admin")
Organization.create!(:name=>"Private For-Profit",:delete_status=>true,:created_by=>"admin",:updated_by=>"admin")
end
  def self.down
    drop_table :organizations
  end
end
