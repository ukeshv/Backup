class CreateWhitepaperUploads < ActiveRecord::Migration
  def self.up
    create_table :whitepaper_uploads do |t|
	t.column :attachable_id,:integer
	t.column :attachable_type,:string,:limit=>50
	t.column :filename,:string,:limit=>100
	t.column :content_type,:string,:limit=>100
	t.column :size,:integer
      t.timestamps
    end
  end

  def self.down
    drop_table :whitepaper_uploads
  end
end
