class AddFormsubmission < ActiveRecord::Migration
  def self.up
	add_column :formsubmissions,:office_followup,:boolean,:default=>false
	add_column :formsubmissions,:office_questions,:text
	add_column :formsubmissions,:office_reviewer1,:text
	add_column :formsubmissions,:office_reviewer2,:text
	add_column :formsubmissions,:office_reviewer3,:text
  end

  def self.down
  	remove_column :formsubmissions,:office_followup
	remove_column :formsubmissions,:office_questions
	remove_column :formsubmissions,:office_reviewer1
	remove_column :formsubmissions,:office_reviewer2
	remove_column :formsubmissions,:office_reviewer3
  end
end

