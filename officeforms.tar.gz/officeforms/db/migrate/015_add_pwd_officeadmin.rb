class AddPwdOfficeadmin < ActiveRecord::Migration
  def self.up
	  add_column :officeadmins,:password_reset_code,:string, :limit => 40
  end

  def self.down
	  remove_column :officeadmins,:password_reset_code
  end
end
