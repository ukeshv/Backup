class AddOffice < ActiveRecord::Migration
  def self.up
	add_column :offices,:member_state,:string,:limit=>50
	add_column :offices,:member_district,:string,:limit=>50
  end

  def self.down
	remove_column :offices,:member_state
	remove_column :offices,:member_district
  end
end
