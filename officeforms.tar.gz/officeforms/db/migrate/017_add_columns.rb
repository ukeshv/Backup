class AddColumns < ActiveRecord::Migration
  def self.up
	  add_column :offices,:office_type,:string,:limit=>100
	  add_column :officeforms,:projectreq_fy,:string,:limit=>100
  end

  def self.down
	  remove_column :offices,:office_type
	  remove_column :officeforms,:projectreq_fy
  end
end
