class AddComment < ActiveRecord::Migration
  def self.up
	create_table :comments, :force => true do |t|
	    t.column :commentable_id, :integer
	    t.column :commentable_type, :string	
	    t.column :comment, :string
	    t.column :created_at, :datetime
	    t.column :title, :string, :limit => 50
	    t.column :user_id, :integer
	end
  
  end

  def self.down
	  drop_table :comments
  end
end
