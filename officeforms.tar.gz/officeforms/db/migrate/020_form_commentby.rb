class FormCommentby < ActiveRecord::Migration
  def self.up
	  add_column :formsubmissions,:followup_updated,:integer
  end

  def self.down
	  remove_column :formsubmissions,:followup_updated
  end
end
