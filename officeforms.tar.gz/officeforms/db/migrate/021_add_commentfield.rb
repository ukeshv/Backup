class AddCommentfield < ActiveRecord::Migration
  def self.up
	add_column :comments,:followup_updatedby,:integer
	add_column :comments,:followup_updated,:integer	
  end

  def self.down
	remove_column :comments,:followup_updatedby
	remove_column :comments,:followup_updated	
  end
end
