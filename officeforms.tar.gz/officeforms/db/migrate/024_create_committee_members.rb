class CreateCommitteeMembers < ActiveRecord::Migration
  def self.up
    create_table :committee_members do |t|
	t.column :committee_id,:integer 
	t.column :is_admin, :boolean
	t.column :login, :string,:limit=>100
	t.column :email, :string,:limit=>50
	t.column :crypted_password, :string,:limit=>40
	t.column :salt, :string,:limit=>40
	t.column :firstname, :string,:limit=>100
	t.column :lastname, :string,:limit=>100
	t.column :address1, :string,:limit=>100
	t.column :address2, :string,:limit=>100
	t.column :city, :string,:limit=>50
	t.column :state, :string,:limit=>50
	t.column :zip, :string,:limit=>10
	t.column :phone, :string,:limit=>20
	t.column :fax, :string,:limit=>20
	t.column:office_id,:integer 
	t.column:officemember_type,:string,:limit=>40
	t.column :active_status, :boolean,:default=>true
	t.column :password_reset_code,:string, :limit => 40 
	t.column :created_at, :datetime
	t.column :updated_at, :datetime
    end
  end

  def self.down
    drop_table :committee_members
  end
end
