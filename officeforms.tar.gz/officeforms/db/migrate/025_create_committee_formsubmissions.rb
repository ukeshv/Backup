class CreateCommitteeFormsubmissions < ActiveRecord::Migration
  def self.up
    create_table :committee_formsubmissions do |t|
	t.column :committee_id,:integer 
	t.column :formsubmission_id,:integer 
	t.column :officeadmin_id, :integer
	t.column :created_at, :datetime
    end
  end

  def self.down
    drop_table :committee_formsubmissions
  end
end
