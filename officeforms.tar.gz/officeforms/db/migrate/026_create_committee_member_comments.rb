class CreateCommitteeMemberComments < ActiveRecord::Migration
  def self.up
    create_table :committee_member_comments do |t|
	t.column :formsubmission_id,:integer 
	t.column :committee_member_id,:integer 
	t.column :comment, :text
	t.column :created_at, :datetime
    end
  end

  def self.down
    drop_table :committee_member_comments
  end
end
