class AddCommitteefollowup < ActiveRecord::Migration
  def self.up
    	add_column :formsubmissions,:committee_followup,:boolean,:default=>false
  end

  def self.down
    	remove_column :formsubmissions,:committee_followup
  end
end
