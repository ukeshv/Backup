class CreateCustomValues < ActiveRecord::Migration
  def self.up
    create_table :custom_values do |t|
      t.column :formsubmission_id,:integer
      t.column :custom_field_id,:integer
      t.column :field_value,:text
      t.timestamps
    end
  end

  def self.down
    drop_table :custom_values
  end
end
