class AddOfficefields < ActiveRecord::Migration
  def self.up
    add_column :officeadmins,:committee_id,:integer
    add_column :officeadmins,:committeemember_type,:string,:limit=>40
  end

  def self.down
    remove_column :officeadmins,:committee_id
    remove_column :officeadmins,:committeemember_type
  end
end
