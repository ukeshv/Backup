class RemoveOfficefields < ActiveRecord::Migration
  def self.up
    remove_column :officeadmins,:committee_id
    remove_column :officeadmins,:committeemember_type
  end

  def self.down
  end
end
