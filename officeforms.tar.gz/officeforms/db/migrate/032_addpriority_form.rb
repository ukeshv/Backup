class AddpriorityForm < ActiveRecord::Migration
  def self.up
    add_column :formsubmissions,:priority,:integer
  end

  def self.down
    remove_column :formsubmissions,:priority
  end
end
