class CreateFollowupFields < ActiveRecord::Migration
  def self.up
    create_table :followup_fields do |t|
	    t.column :office_id,:integer
	    t.column :field_name,:string,:limit=>100
	    t.column :field_type,:string,:limit=>100,:default=>"Textbox-Textarea-Dropdown"
      t.column :active_status,:boolean,:default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :followup_fields
  end
end
