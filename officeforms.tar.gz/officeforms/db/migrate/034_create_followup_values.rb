class CreateFollowupValues < ActiveRecord::Migration
  def self.up
    create_table :followup_values do |t|
      t.column :formsubmission_id,:integer
      t.column :followup_field_id,:integer
      t.column :field_value,:text
      t.timestamps
    end
  end

  def self.down
    drop_table :followup_values
  end
end
