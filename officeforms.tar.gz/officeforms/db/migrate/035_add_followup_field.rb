class AddFollowupField < ActiveRecord::Migration
  def self.up
    change_column :followup_fields,:field_type,:string,:limit=>100,:default=>"Dropdown"
    change_column :followup_fields,:active_status,:boolean,:default=>true
    add_column :followup_fields,:default_value,:text
  end

  def self.down
    change_column :followup_fields,:field_type,:string,:limit=>100,:default=>"Textbox-Textarea-Dropdown"
    change_column :followup_fields,:active_status,:boolean,:default=>false
    remove_column :followup_fields,:default_value
  end
end
