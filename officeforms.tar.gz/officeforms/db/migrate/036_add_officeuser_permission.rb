class AddOfficeuserPermission < ActiveRecord::Migration
  def self.up
    add_column :officeadmins,:priority_role,:boolean
    add_column :officeadmins,:category_role,:boolean
  end

  def self.down
    remove_column :officeadmins,:priority_role
    remove_column :officeadmins,:category_role
  end
end
