class AddCustomValues < ActiveRecord::Migration
  def self.up
    add_column :custom_fields,:is_mandatory,:boolean,:default=>false
  end

  def self.down
    remove_column :custom_fields,:is_mandatory
  end
end
