class ChangeAgencyfield < ActiveRecord::Migration
  def self.up
    change_column :formsubmissions,:fund_pe,:boolean,:default=>true
  end

  def self.down
    change_column :formsubmissions,:fund_pe,:string,:limit=>100
  end
end
