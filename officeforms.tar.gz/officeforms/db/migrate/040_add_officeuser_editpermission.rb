class AddOfficeuserEditpermission < ActiveRecord::Migration
  def self.up
    add_column :officeadmins,:editform,:boolean
  end

  def self.down
    remove_column :officeadmins,:editform
  end
end
