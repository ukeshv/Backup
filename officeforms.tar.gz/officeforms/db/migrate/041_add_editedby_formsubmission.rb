class AddEditedbyFormsubmission < ActiveRecord::Migration
  def self.up
    add_column :formsubmissions,:lastupdated_by,:string
  end

  def self.down
    remove_column :formsubmissions,:lastupdated_by
  end
end
