class CreateEmailNotifications < ActiveRecord::Migration
  def self.up
    create_table :email_notifications do |t|
      t.column :email, :string,:limit=>50
      t.column :receiver_type, :string
      t.column :receiver_id, :integer
      t.column :subject, :string, :limit=>50
      t.column :message, :text
      t.column :is_sent, :boolean,:default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :email_notifications
  end
end
