class CreateAgencyCustomFields < ActiveRecord::Migration
  def self.up
    create_table :agency_custom_fields do |t|
      t.column :agency_id,:integer
      t.column :field_name,:string,:limit=>100
      t.column :field_type,:string,:limit=>50
      t.column :active_status,:boolean,:default=>false
      t.column :is_mandatory,:boolean,:default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :agency_custom_fields
  end
end
