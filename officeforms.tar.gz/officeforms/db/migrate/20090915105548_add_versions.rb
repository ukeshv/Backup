class AddVersions < ActiveRecord::Migration
  def self.up
    Formsubmission.create_versioned_table
    CustomValue.create_versioned_table
  end

  def self.down
    Formsubmission.drop_versioned_table
    CustomValue.drop_versioned_table
  end
end
