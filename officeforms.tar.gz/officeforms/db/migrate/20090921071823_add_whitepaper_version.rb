class AddWhitepaperVersion < ActiveRecord::Migration
  def self.up
    WhitepaperUpload.create_versioned_table
  end

  def self.down
    WhitepaperUpload.drop_versioned_table
  end
end
