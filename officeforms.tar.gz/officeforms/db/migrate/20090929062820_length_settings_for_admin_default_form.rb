class LengthSettingsForAdminDefaultForm < ActiveRecord::Migration
  def self.up

		add_column :defaultforms,:is_org_activities_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:org_activities_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_project_description_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:project_description_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_significance_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:significance_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_expansion_description_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:expansion_description_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_fundlaw_description_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:fundlaw_description_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_endorsements_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:endorsements_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_fund_history_2003_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:fund_history_2003_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_fund_history_2004_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:fund_history_2004_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_fund_history_2005_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:fund_history_2005_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_fund_history_2006_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:fund_history_2006_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_fund_history_2007_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:fund_history_2007_max_length,:integer,:default=>0
				
		add_column :defaultforms,:is_fund_history_2008_length_enabled,:boolean,:default =>false
		add_column :defaultforms,:fund_history_2008_max_length,:integer,:default=>0
		Defaultform.create(:organization_section=>true,:org_type=>true,:org_name=>true,:org_address1=>true,:org_address2=>false,:org_city=>true,:org_state=>true,:org_zip=>true,:org_phone=>true,:org_fax=>true,:org_activities=>true,:contact_section=>true,:contact_firstname=>true,:contact_lastname=>false,:contact_email=>true,:contact_address1=>true,:contact_address2=>false,:contact_city=>true,:contact_state=>true,:contact_zip=>true,:contact_phone=>true,:contact_mobile=>false,:sr_contact_section=>true,:sr_contact_firstname=>true,:sr_contact_lastname=>false,:sr_contact_email=>true,:sr_contact_address1=>true,:sr_contact_address2=>false,:sr_contact_city=>true,:sr_contact_state=>true,:sr_contact_zip=>true,:sr_contact_phone=>true,:sr_contact_mobile=>false,:representative_section=>true,:is_lobby_list=>true,:representative_firstname=>true,:representative_lastname=>false,:representative_email=>true,:representative_firmname=>true,:representative_address1=>true,:representative_address2=>false,:representative_city=>true,:representative_state=>true,:representative_zip=>true,:representative_phone=>true,:representative_mobile=>false,:project_section=>true,:project_description=>true,:white_paper=>true,:significance=>true,:expansion_description=>true,:is_funding_under_law=>true,:fundlaw_description=>true,:endorsements=>true,:total_cost=>true,:amount_requested=>true,:agency_section=>true,:agency_name=>true,:agency_account=>true,:agency_sub_account=>true,:type_of_request=>true,:fund_pe=>true,:fund_line=>true,:fund_history_2003=>true,:fund_history_2004=>true,:fund_history_2005=>true,:fund_history_2006=>true,:fund_history_2007=>true,:fund_history_2008=>true)  
  end

  def self.down
		remove_column :defaultforms,:is_org_activities_length_enabled
		remove_column :defaultforms,:org_activities_max_length
				
		remove_column :defaultforms,:is_project_description_length_enabled
		remove_column :defaultforms,:project_description_max_length
				
		remove_column :defaultforms,:is_significance_length_enabled
		remove_column :defaultforms,:significance_max_length
				
		remove_column :defaultforms,:is_expansion_description_length_enabled
		remove_column :defaultforms,:expansion_description_max_length
				
		remove_column :defaultforms,:is_fundlaw_description_length_enabled
		remove_column :defaultforms,:fundlaw_description_max_length
				
		remove_column :defaultforms,:is_endorsements_length_enabled
		remove_column :defaultforms,:endorsements_max_length
				
		remove_column :defaultforms,:is_fund_history_2003_length_enabled
		remove_column :defaultforms,:fund_history_2003_max_length
				
		remove_column :defaultforms,:is_fund_history_2004_length_enabled
		remove_column :defaultforms,:fund_history_2004_max_length
				
		remove_column :defaultforms,:is_fund_history_2005_length_enabled
		remove_column :defaultforms,:fund_history_2005_max_length
				
		remove_column :defaultforms,:is_fund_history_2006_length_enabled
		remove_column :defaultforms,:fund_history_2006_max_length
				
		remove_column :defaultforms,:is_fund_history_2007_length_enabled
		remove_column :defaultforms,:fund_history_2007_max_length
				
		remove_column :defaultforms,:is_fund_history_2008_length_enabled
		remove_column :defaultforms,:fund_history_2008_max_length
  end
end
