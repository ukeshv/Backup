class LengthSettingsForOfficeadminDefaultForm < ActiveRecord::Migration
  def self.up
		add_column :officeforms,:is_org_activities_length_enabled,:boolean,:default =>false
		add_column :officeforms,:org_activities_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_project_description_length_enabled,:boolean,:default =>false
		add_column :officeforms,:project_description_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_significance_length_enabled,:boolean,:default =>false
		add_column :officeforms,:significance_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_expansion_description_length_enabled,:boolean,:default =>false
		add_column :officeforms,:expansion_description_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_fundlaw_description_length_enabled,:boolean,:default =>false
		add_column :officeforms,:fundlaw_description_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_endorsements_length_enabled,:boolean,:default =>false
		add_column :officeforms,:endorsements_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_fund_history_2003_length_enabled,:boolean,:default =>false
		add_column :officeforms,:fund_history_2003_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_fund_history_2004_length_enabled,:boolean,:default =>false
		add_column :officeforms,:fund_history_2004_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_fund_history_2005_length_enabled,:boolean,:default =>false
		add_column :officeforms,:fund_history_2005_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_fund_history_2006_length_enabled,:boolean,:default =>false
		add_column :officeforms,:fund_history_2006_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_fund_history_2007_length_enabled,:boolean,:default =>false
		add_column :officeforms,:fund_history_2007_max_length,:integer,:default=>0
				
		add_column :officeforms,:is_fund_history_2008_length_enabled,:boolean,:default =>false
		add_column :officeforms,:fund_history_2008_max_length,:integer,:default=>0

  end

  def self.down
		remove_column :officeforms,:is_org_activities_length_enabled
		remove_column :officeforms,:org_activities_max_length
				
		remove_column :officeforms,:is_project_description_length_enabled
		remove_column :officeforms,:project_description_max_length
				
		remove_column :officeforms,:is_significance_length_enabled
		remove_column :officeforms,:significance_max_length
				
		remove_column :officeforms,:is_expansion_description_length_enabled
		remove_column :officeforms,:expansion_description_max_length
				
		remove_column :officeforms,:is_fundlaw_description_length_enabled
		remove_column :officeforms,:fundlaw_description_max_length
				
		remove_column :officeforms,:is_endorsements_length_enabled
		remove_column :officeforms,:endorsements_max_length
				
		remove_column :officeforms,:is_fund_history_2003_length_enabled
		remove_column :officeforms,:fund_history_2003_max_length
				
		remove_column :officeforms,:is_fund_history_2004_length_enabled
		remove_column :officeforms,:fund_history_2004_max_length
				
		remove_column :officeforms,:is_fund_history_2005_length_enabled
		remove_column :officeforms,:fund_history_2005_max_length
				
		remove_column :officeforms,:is_fund_history_2006_length_enabled
		remove_column :officeforms,:fund_history_2006_max_length
				
		remove_column :officeforms,:is_fund_history_2007_length_enabled
		remove_column :officeforms,:fund_history_2007_max_length
				
		remove_column :officeforms,:is_fund_history_2008_length_enabled
		remove_column :officeforms,:fund_history_2008_max_length

  end
end
