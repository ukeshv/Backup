class LengthSettingsForCustomField < ActiveRecord::Migration
  def self.up
		add_column :custom_fields,:is_length_enabled,:boolean,:default =>false
		add_column :custom_fields,:max_length,:integer,:default=>0
  end

  def self.down
		remove_column :custom_fields,:is_length_enabled
		remove_column :custom_fields,:max_length
  end
end
