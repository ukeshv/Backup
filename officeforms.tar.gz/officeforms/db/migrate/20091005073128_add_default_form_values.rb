class AddDefaultFormValues < ActiveRecord::Migration
  def self.up
    sql = ActiveRecord::Base.connection();
    sql.execute "truncate table defaultforms"
    Defaultform.create(:organization_section=>true,:org_type=>true,:org_name=>true,:org_address1=>true,:org_address2=>false,:org_city=>true,:org_state=>true,:org_zip=>true,:org_phone=>true,:org_fax=>true,:org_activities=>true,:contact_section=>true,:contact_firstname=>true,:contact_lastname=>false,:contact_email=>true,:contact_address1=>true,:contact_address2=>false,:contact_city=>true,:contact_state=>true,:contact_zip=>true,:contact_phone=>true,:contact_mobile=>false,:sr_contact_section=>true,:sr_contact_firstname=>true,:sr_contact_lastname=>false,:sr_contact_email=>true,:sr_contact_address1=>true,:sr_contact_address2=>false,:sr_contact_city=>true,:sr_contact_state=>true,:sr_contact_zip=>true,:sr_contact_phone=>true,:sr_contact_mobile=>false,:representative_section=>true,:is_lobby_list=>true,:representative_firstname=>true,:representative_lastname=>false,:representative_email=>true,:representative_firmname=>true,:representative_address1=>true,:representative_address2=>false,:representative_city=>true,:representative_state=>true,:representative_zip=>true,:representative_phone=>true,:representative_mobile=>false,:project_section=>true,:project_description=>true,:white_paper=>true,:significance=>true,:expansion_description=>true,:is_funding_under_law=>true,:fundlaw_description=>true,:endorsements=>true,:total_cost=>true,:amount_requested=>true,:agency_section=>true,:agency_name=>true,:agency_account=>true,:agency_sub_account=>true,:type_of_request=>true,:fund_pe=>true,:fund_line=>true,:fund_history_2003=>true,:fund_history_2004=>true,:fund_history_2005=>true,:fund_history_2006=>true,:fund_history_2007=>true,:fund_history_2008=>true)  
  end

  def self.down
  end
end
