class CreateAgencyCustomValues < ActiveRecord::Migration
  def self.up
    create_table :agency_custom_values do |t|
      t.column :formsubmission_id,:integer
      t.column :agency_custom_field_id,:integer
      t.column :field_value,:text
      t.timestamps
    end
  end

  def self.down
    drop_table :agency_custom_values
  end
end
