class AddVersionForAgencyCustomValues < ActiveRecord::Migration
  def self.up
    AgencyCustomValue.create_versioned_table
  end

  def self.down
    AgencyCustomValue.drop_versioned_table
  end
end
