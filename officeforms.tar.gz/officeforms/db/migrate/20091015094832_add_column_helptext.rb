class AddColumnHelptext < ActiveRecord::Migration
  def self.up
    add_column :offices, :help_text, :text
    add_column :agencies, :help_text, :text
     offices = Office.find(:all)
    agencies = Agency.find(:all)
    for office in offices
      office.update_attributes(:help_text=>"Form help text..")
    end  
    for agency in agencies
      agency.update_attributes(:help_text=>"Form help text..")
    end  
  end

  def self.down
    remove_column :offices, :help_text
    remove_column :agencies, :help_text
  end
end
