// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults
function show_text_field(id,text_field1){
a = $('show_'+id)
a.show();
$(text_field1).value='0';
}
function hide_text_field(id,text_field1){
a = $('show_'+id)
a.hide();
$(text_field1).value='0';
}

function show_radio(id){
a = $('show_enabled_'+id)
b = $('show_disabled_'+id)
c = $('radio1_'+id).checked
a.show();
b.show();
if (c == true){
$('show_'+id).show();
}
}
function hide_radio(id){
a = $('show_enabled_'+id)
b = $('show_disabled_'+id)
c = $('show_'+id)
a.hide();
b.hide();
c.hide();
}

function wordCounter(val,form, field, maxlimit, col)
{
 var string="";
 var wordCount=0;
 var obj=eval("form."+field);
 var IsSpace=false;
 var WasSpace=false;
 var colName = "max_msg_"+col
 if (val == 'true'){
 for (var x=0;x<obj.value.length;x++)
  {
   WasSpace=IsSpace;
   IsSpace=(obj.value.charAt(x) == " ");
   
   if(IsSpace && ! WasSpace)
   {
    wordCount++;
    if(wordCount<=maxlimit)
     string+=" ";
   }
   else if(!IsSpace)
   {
    if(wordCount<maxlimit)
     string+=obj.value.charAt(x);
   }
  }
  if (wordCount >= maxlimit){
    document.getElementById(colName).style.color = 'red'
     obj.value=string;
}
else{
document.getElementById(colName).style.color = 'black'
obj.value=string;
}
  }
 }