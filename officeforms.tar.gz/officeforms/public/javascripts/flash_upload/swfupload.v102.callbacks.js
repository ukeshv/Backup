
var list=new Array(); 
var err=new Array(); 
var i=0;
function fileQueued(file, queuelength) {
  
	var listingfiles = document.getElementById("SWFUploadFileListingFiles");
  
 
  
 
  
 
	if(!listingfiles.getElementsByTagName("div")[0]) {
		
		var info = document.createElement("h4");		
		//info.appendChild(document.createTextNode("To discontinue uploading any song in the queue, simply click the (X)  image. To cancel all uploads, click 'Cancel Queue'."));
		
		listingfiles.appendChild(info);
		
		var div= document.createElement("div")
		listingfiles.appendChild(div);
	}
  
  if(err.indexOf(file.name)<0)
  {
  if(list.indexOf(file.name)<0) {
    if (window.list) {   
    list.push(file.name);
  }	
	listingfiles = listingfiles.getElementsByTagName("div")[0];
	
	var div = document.createElement("div");
	div.id = file.id;  
	div.className = "SWFUploadFileItem";
	div.innerHTML = "<br><span class='bluetext'>" + file.name +"</span><p><div class='brdiv'><span class='progress_Bar' id='" + file.id + "progress'></span></div></p>";
	//div.innerHTML = "<a id='"  + file.id + "deletebtn' class='cancelbtn' href='javascript:swfu.cancelFile(\"" + file.id + "\");'><!-- IE --></a><br>"+ file.name +"<p><div class='brdiv'><span class='progress_Bar' id='" + file.id + "progress'></span></div></p>"; temp
  }
  else{
  listingfiles = listingfiles.getElementsByTagName("div")[0];
  err.push(file.name);
	var div = document.createElement("div");
	div.id = file.id;  
	div.className = "SWFUploadFileItem";
	div.innerHTML = "<span class='star'>"+file.name+"already selected</span>";  
  }
  
	listingfiles.appendChild(div);
	}
	var queueinfo = document.getElementById("queueinfo");
	//queueinfo.innerHTML = queuelength + " Music file(s) queued";
	//queueinfo.innerHTML = list.length + " file queued"; temp
	document.getElementById(swfu.movieName + "UploadBtn").style.display = "block";
	//document.getElementById("cancelqueuebtn").style.display = "block"; temp

}


function uploadFileCancelled(file, queuelength) {
	var div = document.getElementById(file.id);
	//div.innerHTML = file.name + " - cancelled";
	//div.className = "SWFUploadFileItem uploadCancelled";    
  var progress_div = document.getElementById(file.id+'progress');
  
  progress_div.className = "progressBar cancelled";
	var queueinfo = document.getElementById("queueinfo");
	queueinfo.innerHTML = queuelength + " files queued";
	//queueinfo.innerHTML = list.length + " files queued";
}

function uploadFileStart(file, position, queuelength) {
	var div = document.getElementById("queueinfo");  
	//div.innerHTML = "Uploading file(s) " + position + " of " + queuelength;
	//div.innerHTML = "Uploading file " temp

	var div = document.getElementById(file.id);
  if(div)
  {
	div.className += " fileUploading";
  }
}

function uploadProgress(file, bytesLoaded) {

	var progress = document.getElementById(file.id + "progress");
  if(progress)
  {
	var percent = Math.ceil((bytesLoaded / file.size) * 200)
	progress.style.background = "#f0f0f0 url(/images/flash_images/bgimage.jpg) repeat -" + (200 - percent) + "px 0";
  }
}

function uploadError(errno) {
	// SWFUpload.debug(errno);
}

function uploadFileComplete(file) {
	var div = document.getElementById(file.id);
	div.className = "SWFUploadFileItem uploadCompleted";
}

function cancelQueue() {
	swfu.cancelQueue();
  var cancel_buttons=document.getElementsByClassName('cancelbtn');
  for( i=0; i<cancel_buttons.length;i++ )
    {
      cancel_buttons[i].className="can_cel";      
    }
  
	document.getElementById(swfu.movieName + "UploadBtn").style.display = "none";
	//document.getElementById("cancelqueuebtn").style.display = "none"; temp
}

function uploadQueueComplete(file) {
	var div = document.getElementById("queueinfo");
	//div.innerHTML = "All files uploaded..."  
	//document.getElementById("cancelqueuebtn").style.display = "none";  temp
 // return false
 //document.getElementById("mcontent").style.display = "none"; temp
 document.getElementById("SWFUploadFileListingFiles").innerHTML="";
 document.getElementById("SWFUpload_0UploadBtn").style.display = "none"; 
 document.getElementById("uploadblankerror").style.display = "none"; 
 if(document.getElementById("nouploaderror") != null ){
 document.getElementById("nouploaderror").style.display = "none"; }
 document.getElementById("is_uploaded").value = true;
 document.getElementById("succ_msg").innerHTML = "<h5 class='notice'>File "+ file.name+" uploaded</h5>";
 
  //window.location = '/articles/new/'+id_val;
  
}
