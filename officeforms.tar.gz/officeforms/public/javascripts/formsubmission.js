//Method for Displaying the Contact Address same as Organization address

function display_contactaddress() {
 if ($('contact_form_same_org_address').checked==true)  {   
    $('form_submission_contact_address1').value = $('form_submission_org_address1').value;
    $('form_submission_contact_address2').value = $('form_submission_org_address2').value;
    $('form_submission_contact_city').value = $('form_submission_org_city').value;
    $('form_submission_contact_state').value = $('form_submission_org_state').value;
    $('form_submission_contact_zip').value = $('form_submission_org_zip').value;
    $('form_submission_contact_phone').value = $('form_submission_org_phone').value;
  }
  else {   
    $('form_submission_contact_address1').value = '';
    $('form_submission_contact_address2').value = '';
    $('form_submission_contact_city').value = '';
    $('form_submission_contact_state').value = '';
    $('form_submission_contact_zip').value = '';
    $('form_submission_contact_phone').value = '';
  }
}

//Method for Displaying the Senior Contact Address same as Organization address

function display_sr_contactaddress() {
 if ($('sr_contact_form_same_org_address').checked==true)  {   
    $('form_submission_sr_contact_address1').value = $('form_submission_org_address1').value;
    $('form_submission_sr_contact_address2').value = $('form_submission_org_address2').value;
    $('form_submission_sr_contact_city').value = $('form_submission_org_city').value;
    $('form_submission_sr_contact_state').value = $('form_submission_org_state').value;
    $('form_submission_sr_contact_zip').value = $('form_submission_org_zip').value;
    $('form_submission_sr_contact_phone').value = $('form_submission_org_phone').value;
  }
  else {   
    $('form_submission_sr_contact_address1').value = '';
    $('form_submission_sr_contact_address2').value = '';
    $('form_submission_sr_contact_city').value = '';
    $('form_submission_sr_contact_state').value = '';
    $('form_submission_sr_contact_zip').value = '';
    $('form_submission_sr_contact_phone').value = '';
  }
}

//In Representative Section,if lobbylist has chosen as No,firstname,lastname,etc..etc are to be disabled.

function hide_firm_info() {
 $('form_submission_representative_firstname').disabled = true;
 $('form_submission_representative_lastname').disabled = true;
 $('form_submission_representative_email').disabled = true;
 $('form_submission_representative_firmname').disabled = true;
 $('form_submission_representative_address1').disabled = true;
 $('form_submission_representative_address2').disabled = true;
 $('form_submission_representative_city').disabled = true;
 $('form_submission_representative_state').disabled = true;
 $('form_submission_representative_zip').disabled = true;
 $('form_submission_representative_phone').disabled = true;
 $('form_submission_representative_mobile').disabled = true;
  $('disp_star_repfirstname').style.display = "none";
 $('disp_star_repfirmname').style.display = "none";
 $('disp_star_repemail').style.display = "none";
 $('disp_star_repaddress1').style.display = "none";
 $('disp_star_repcity').style.display = "none";
 $('disp_star_repstate').style.display = "none";
 $('disp_star_repzip').style.display = "none";
 $('disp_star_repphone').style.display = "none";
 $('lobbylist_check').value = '0';
 $('rep_fname_err').style.display = "none";
 $('rep_firm_err').style.display = "none";
 $('rep_email_err').style.display = "none";
 $('rep_add1_err').style.display = "none";
 $('rep_city_err').style.display = "none";
 $('rep_state_err').style.display = "none";
 $('rep_zip_err').style.display = "none";
 $('rep_phone_err').style.display = "none";
}

//In Representative Section,if lobbylist has chosen as Yes,firstname,lastname,etc..etc are to be enabled(if they are disabled).

function show_firm_info() {
 $('form_submission_representative_firstname').disabled = false;
 $('form_submission_representative_lastname').disabled = false;
 $('form_submission_representative_email').disabled = false;
 $('form_submission_representative_firmname').disabled = false;
 $('form_submission_representative_address1').disabled = false;
 $('form_submission_representative_address2').disabled = false;
 $('form_submission_representative_city').disabled = false;
 $('form_submission_representative_state').disabled = false;
 $('form_submission_representative_zip').disabled = false;
 $('form_submission_representative_phone').disabled = false;
 $('form_submission_representative_mobile').disabled = false;
 $('disp_star_repfirstname').style.display = "inline";
 $('disp_star_repfirmname').style.display = "inline";
 $('disp_star_repemail').style.display = "inline";
 $('disp_star_repaddress1').style.display = "inline";
 $('disp_star_repcity').style.display = "inline";
 $('disp_star_repstate').style.display = "inline";
 $('disp_star_repzip').style.display = "inline";
 $('disp_star_repphone').style.display = "inline";
  $('lobbylist_check').value = '1';
}

//In Project Section,if funding_underlaw has chosen as Yes,fundlaw descrition is to be enabled(if they are disabled).

function show_project_fund_info() {
 $('form_submission_fundlaw_description').disabled = false;
 $('fund_underlaw_check').value = '1';
}

//In Project Section,if funding_underlaw has chosen as No,fundlaw descrition is to be disabled.

function hide_project_fund_info() {
 $('form_submission_fundlaw_description').disabled = true;
 $('fund_underlaw_check').value = '0';
}

//In Project Section,if funding_underlaw has chosen as Yes,fundlaw descrition is to be enabled(if they are disabled).

function show_agency_fund_info() {
 $('form_submission_fund_line').disabled = false;
 $('fund_pe_check').value = '1';
}

//In Project Section,if funding_underlaw has chosen as No,fundlaw descrition is to be disabled.

function hide_agency_fund_info() {
 $('form_submission_fund_line').disabled = true;
 $('fund_pe_check').value = '0';
  $('agency_fundline_err').style.display = "none";
}

//Method called on body load.To retain the values of form elements same as before sumbitted.


function init_values(rep_val,proj_val,agency_val){
if(rep_val == true){
if($('lobbylist_check').value == '1')
{
  $('form_submission_is_lobbylist_true').checked = true;
  $('form_submission_representative_firstname').disabled = false;
  $('form_submission_representative_lastname').disabled = false;
  $('form_submission_representative_email').disabled = false;
  $('form_submission_representative_firmname').disabled = false;
  $('form_submission_representative_address1').disabled = false;
  $('form_submission_representative_address2').disabled = false;
  $('form_submission_representative_city').disabled = false;
  $('form_submission_representative_state').disabled = false;
  $('form_submission_representative_zip').disabled = false;
  $('form_submission_representative_phone').disabled = false;
  $('form_submission_representative_mobile').disabled = false;
  $('disp_star_repfirstname').style.display = "inline";
  $('disp_star_repfirmname').style.display = "inline";
  $('disp_star_repemail').style.display = "inline";
  $('disp_star_repaddress1').style.display = "inline";
  $('disp_star_repcity').style.display = "inline";
  $('disp_star_repstate').style.display = "inline";
  $('disp_star_repzip').style.display = "inline";
  $('disp_star_repphone').style.display = "inline";
}
else
{
  $('form_submission_is_lobbylist_false').checked = true;
  $('form_submission_representative_firstname').disabled = true;
  $('form_submission_representative_lastname').disabled = true;
  $('form_submission_representative_email').disabled = true;
  $('form_submission_representative_firmname').disabled = true;
  $('form_submission_representative_address1').disabled = true;
  $('form_submission_representative_address2').disabled = true;
  $('form_submission_representative_city').disabled = true;
  $('form_submission_representative_state').disabled = true;
  $('form_submission_representative_zip').disabled = true;
  $('form_submission_representative_phone').disabled = true;
  $('form_submission_representative_mobile').disabled = true;
}}
if(proj_val == true){
if($('fund_underlaw_check').value == '1')
{
 $('form_submission_is_funding_under_law_true').checked = true;
 $('form_submission_fundlaw_description').disabled = false;
}
else
{
 $('form_submission_is_funding_under_law_false').checked = true;
 $('form_submission_fundlaw_description').disabled = true;
}}
if(agency_val == true){
if($('fund_pe_check').value == '1')
{
 $('form_submission_fund_pe_true').checked = true;
 $('form_submission_fund_line').disabled = false;
}
else
{
 $('form_submission_fund_pe_false').checked = true;
 $('form_submission_fund_line').disabled = true;
}}

}

function show_agencyaccounts(agency_name)
{
new Ajax.Request("/users/change_agencyaccounts/?t1="+agency_name, {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('agency_ajax_image');}, onLoading:function(request){Element.show('agency_ajax_image');}});
}

function show_agency_subaccounts(agency_accountname)
{
new Ajax.Request("/users/change_agency_subaccounts/?t2="+agency_accountname, {asynchronous:true, evalScripts:true, onComplete:function(request){Element.hide('agencyaccount_ajax_image');}, onLoading:function(request){Element.show('agencyaccount_ajax_image');}});
}

function show_agency_customfields(agency,status)
{
if (status== 'user'){
 new Ajax.Request("/users/change_agency_customfields/?aname="+agency,{asynchronous:true, evalScripts:true, method:'get'});
}
else if (status == 'admin'){
 new Ajax.Request("/admin/change_agency_customfields/?aname="+agency,{asynchronous:true, evalScripts:true, method:'get'});
}
}

function representative_retainval()
{
if($('form_submission_is_lobbylist_true').checked == true)
{
err_alert = ""
err_alert = "Fields which are mentioned below are mandatory \n"	
	if(($('form_submission_representative_firstname').value).strip()==""){
	err_alert += "First Name, ";
	}
	if(($('form_submission_representative_firmname').value).strip()==""){
	err_alert += " Firm Name,";
	}
	if(($('form_submission_representative_email').value).strip()==""){
	err_alert += " Email,";
	}
	if(($('form_submission_representative_address1').value).strip()==""){
	err_alert += " Address1,";
	}
	if(($('form_submission_representative_city').value).strip()==""){
	err_alert += " City,";
	}
	if(($('form_submission_representative_state').value).strip()==""){
	err_alert += " State,";
	}
	if(($('form_submission_representative_zip').value).strip()==""){
	err_alert += " Zip,";
	}
	if(($('form_submission_representative_phone').value).strip()==""){
	err_alert += " Phone";
	}
alert(err_alert);
alert('hi');
}
else
alert('hdsadi');
}
