var c=1200; //Users sessions will be ended after 20 minutes of inactivity.
var t;
function timedelay()
{
c=1200;
clearTimeout(t);
timedCount();
}

function timedCount() {
  c=c-1;
  t=setTimeout("timedCount()",1000); //Time interval for calling timedCount function
  
  if (c==120){
  alert("You will be loggedout in 2 mins")
  }
  
  if (c==-1) {
    clearTimeout(t);
    document.title='Redirecting ...';
    var url = window.location.host;
    self.location = 'http://'+url+'/users/idle';
  }
}
window.onload=timedCount;