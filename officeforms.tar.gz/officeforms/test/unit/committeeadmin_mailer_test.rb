require File.dirname(__FILE__) + '/../test_helper'

class CommitteeadminMailerTest < ActionMailer::TestCase
  tests CommitteeadminMailer
  # replace this with your real tests
  def test_truth
    assert true
  end
end
