require File.dirname(__FILE__) + '/../test_helper'

class OfficeadminMailerTest < ActionMailer::TestCase
  tests OfficeadminMailer
  # replace this with your real tests
  def test_truth
    assert true
  end
end
