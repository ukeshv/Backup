class AdminController < ApplicationController
	before_filter :check_admin,:except=>['login'] 
	layout 'admin'
	
  def check_admin
    redirect_to login_path if !session[:admin]	
  end	

  def login
    key = params[:key]
    if key && (!key.blank? || !key.empty?)
      if key == "1q2w3e"
        session[:admin] = true
        redirect_to users_list_path
      else	
        redirect_to root_path
      end	
    else	
      redirect_to root_path
    end
  end

  def users_list
     @users = User.find :all
  end	

  def fights_list
     @fights = Fight.find :all
     @categories = Category.find :all
  end

  def edit_fight
    @fight = Fight.find(params[:id])
    @users = User.find :all
    @categories = Category.find :all
  end	

  def update_fight
    @fight = Fight.find(params[:id])
    @users = User.find :all
    @categories = Category.find :all
    @fight.fighter_one.update_attributes(:name=>params[:fighter_one_name])
    @fight.fighter_two.update_attributes(:name=>params[:fighter_two_name])
    if @fight.update_attributes(params[:fight])	    
      flash[:notice] = 'Fight was successfully created.'
      redirect_to fights_list_path
    else
     render :action=>"edit_fight"	
    end		
  end	

  def update_fight_of_the_day
    @today_fight = Fight.find_by_fight_of_the_day(true)
    @fight = Fight.find(params[:id]) 
    if @today_fight.nil?
	@fight.update_attributes(:fight_of_the_day=>true)
    else
      @today_fight.update_attributes(:fight_of_the_day=>false)
      @fight.update_attributes(:fight_of_the_day=>true)
    end
    flash[:notice] = 'Fight of the day was successfully updated.' 
    redirect_to fights_list_path    
  end	

  def update_status
    @fight = Fight.find(params[:id])
    @fight.update_attributes(:status=>!@fight.status)
    flash[:notice] = 'Fight status was successfully updated.' 
    redirect_to fights_list_path  
  end	
 
  def comments_list
	  @comments = Comment.find(:all,:order=>'created_at desc')
  end	

  def comment_delete
	 c = Comment.find(params[:id]) 
	 c.destroy
	     flash[:notice] = 'Comment was successfully deleted.' 
    redirect_to comments_list_path  
  end	

  def reports_list
	  @reports = ReportAbuse.find(:all,:order=>'created_at desc')
  end	

end
