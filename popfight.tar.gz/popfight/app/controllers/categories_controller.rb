class CategoriesController < ApplicationController
	
  def index
		@category_names = Category.all(:order=>'id').collect{|x| x.name}
		@fight_of_the_day = Fight.find_by_fight_of_the_day(true)
		@fight_of_the_day = Fight.last if @fight_of_the_day.nil?
  end

end
