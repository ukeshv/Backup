class FightsController < ApplicationController
	layout 'application', :except => [:share, :abuse, :statistics, :vote]
	protect_from_forgery :except=> [:share, :abuse, :statistics, :vote, :add_comment, :search]
  include Geokit::Geocoders
  geocode_ip_address
  
  def index
		@popular_fights = Fight.find :all, :conditions=>['status = ?', true], :order=>[:total_count], :limit=>25
  end
  
  
  # after user loginin, user may want to see a fight 
  # by selecting one from some list (where params[:id] = permalink ) or
  # by selecting a category (where params[:id] = category_id would be sent)
  def show
    if params[:category_name]
      # find a random fight from selected category
      @fight = random_fight( Category.find_by_name(params[:category_name]) )
		elsif params[:id].nil?	
		  # when user enters the site's home url, that can be before login too
			 # fight can be nil in some situations, so need to check for nil in View file
			@fight = random_fight
    else
      # find fight matching permalink choosen by user
      @fight = Fight.find_by_permalink_and_status(params[:id],true)
    end   

		if @fight
     @winner_link_1 = params[:category_name] ? vote_fight_path(@fight.permalink, :winner=>1, :category_name=>params[:category_name]) : vote_fight_path(@fight.permalink, :winner=>1)
     @winner_link_2 = params[:category_name] ? vote_fight_path(@fight.permalink, :winner=>2, :category_name=>params[:category_name]) : vote_fight_path(@fight.permalink, :winner=>2)
     @pass_link = params[:category_name] ? category_fight_path(params[:category_name]) : root_path

		 @category_name = @fight.category.name rescue 'Unknown'
     @comments = Comment.find(:all,:conditions=>['fight_id = ?',@fight.id],:order=>'created_at desc')
	   @comment = Comment.new    
		else 
		 flash[:notice] = "We couldn't find requested fight. Admin might have disabled this fight"	
		 redirect_to new_upload_path
		end
  end

  def search
    split_content = params[:search_text].strip.squeeze(" ").split(" ")
		split_content.collect! {|x| "'"+ "[[:<:]]"+ x + "[[:>:]]" + "'" }
    cond1 = split_content.join(' OR title RLIKE ')
    cond2 = split_content.join(' OR fighter_one_name RLIKE ')
    cond3 = split_content.join(' OR fighter_two_name RLIKE ')
    @fights = Fight.active_records.find(:all, :conditions=>"title RLIKE #{cond1} OR fighter_one_name RLIKE #{cond2} OR fighter_two_name RLIKE #{cond3}", :limit=>25, :order=>"created_at")
	end

  # statistics of fight will be updated with user selection
  # then  updated statistics will be shown to user
  def vote
		@fight = Fight.find_by_permalink(params[:id])
		@fight.update_winner(params[:winner])
    if session[:geo_location] && session[:geo_location].success
      @fight.increment_count_of_country(session[:geo_location].country_code, params[:winner])
    end
		if params[:category_name]
      render :action => 'statistics', :category_name=>params[:category_name]
		else
      render :action => 'statistics'
		end
  end
	
	
	def statistics
		@fight = Fight.find_by_permalink(params[:id])     		
	end
	
	
	def abuse
		@fight = Fight.find_by_permalink(params[:id])
		
		return unless params[:submit]
		@report_abuse = ReportAbuse.new(params[:report_abuse]) 
		@report_abuse.fight_id = @fight.id
		if @report_abuse.save			
			@fight.update_attributes(:report_abuse_count => @fight.report_abuse_count + 1)
			render :update do |page|
				page.hide "abuser_email_error"
				page.hide "reason_error"				
				page[:report_abuse_abuser_email].value = ""
				page[:report_abuse_reason].value = ""
				page.replace_html "success_msg", "<font color='green' size='2px'>This fight has been abused</font>"
			end	
		else
			render :update do |page|
				for h in @report_abuse.errors
					if !@report_abuse.errors["#{h[0]}"].nil?
						page.show "#{h[0]}_error"              
						page.replace_html "#{h[0]}_error","<font color='red' size='2px'>#{h[1]}</font>"
					end          					
					page.hide "abuser_email_error" if @report_abuse.errors['abuser_email'].nil?
					page.hide "reason_error" if @report_abuse.errors['reason'].nil?
				end
			end
		end	
	end
	
	#Method used to share fight with friends
	def share
		@fight = Fight.find_by_permalink(params[:id])		
		
		return unless params[:submit]
		@share_email = params[:share][:email]
		@share_to_address = params[:share][:to_address]
		error_flag = true
		render :update do |page|
			if params[:share][:email].strip.empty?
				page.replace_html 'share_email_error', "<font color='red' size='2px'>Enter your Email</font>"
				error_flag = false
			elsif (/^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i =~ params[:share][:email]).nil?
				page.replace_html 'share_email_error', "<font color='red' size='2px'>Invalid email format</font>"
				error_flag = false
			else
        page.replace_html 'share_email_error', ""
			end
			if params[:share][:to_address].strip.empty?
				page.replace_html 'share_to_address_error', "<font color='red' size='2px'>Recipients cannot be blank</font>"
				error_flag = false
			else
				duplicate_emails = []
				for	to_address in params[:share][:to_address].split(',')
					if (/^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i =~ to_address.strip).nil?
						duplicate_emails << to_address
					end
				end
				unless duplicate_emails.empty?
					page.replace_html 'share_to_address_error', "<font color='red' size='2px'>The following email addresses are not valid: " + duplicate_emails.join(',') + "</font>"
					error_flag = false
				end
			end
			if error_flag == true
				for	to_address in params[:share][:to_address].split(',')
					FightMailer.deliver_share_fight(params[:share][:email].strip, to_address.strip,@fight) rescue ""
				end				
				page.hide "share_email_error"
				page.hide "share_to_address_error"
				page[:share_email].value = ""
				page[:share_to_address].value = ""
				page.replace_html 'success_msg', "<font color='green' size='2px'>The pop fight is successfully shared</font>"
			end			
		end
	end	

  def add_comment
	 @comment = Comment.new(params[:comment]) 
	 @comment.fight_id = params[:id]
	if @comment.save
	@comments = Comment.find(:all,:conditions=>['fight_id = ?',params[:id]],:order=>'created_at desc')
	render :update do |page|
		page[:comment_fight_comment].value = ""
		page[:comment_name].value = ""
		page[:name_comment].innerHTML = ""
		page[:fight_comment_comment].innerHTML = ""
		page.replace_html 'fight_comments',:partial=>"comments"
		page.visual_effect :highlight,"comment_#{@comment.id}",:duration => 1.5
	end	
	else
	        render :update do |page|
        for h in @comment.errors
          if !@comment.errors["#{h[0]}"].nil?
          page.show "#{h[0]}_comment"              
          page.replace_html "#{h[0]}_comment","#{h[1]}"
          end          
        page.hide "name_comment" if @comment.errors['name'].nil?
        page.hide "fight_comment_comment" if @comment.errors['fight_comment'].nil?
        end
	end
	end
  end
	
 protected
  def random_fight(category=nil)
    fight = nil
    scoped_fights = category ? Fight.active_records.from_category(category.id) : Fight.active_records
		
    if scoped_fights.length == 0
     fight = nil
    elsif scoped_fights.length == 1
     fight = scoped_fights.first
		else
		fight = scoped_fights[rand(scoped_fights.length)]
		end
    fight
  end

	
end
