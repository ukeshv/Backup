class HomeController < ApplicationController
 
end
