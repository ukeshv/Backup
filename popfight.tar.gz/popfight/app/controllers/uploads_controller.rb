class UploadsController < ApplicationController
	protect_from_forgery :except => :create
	before_filter :login_required
	
	def new
		flash[:image_notice] ||= " You can upload any types of pictures with a maximum size of 3MB.  Example types: *.png, *.jpg, *.gif. These images will be displayed in public view for voting. You can see the voting results in my fights page"
		flash[:embed_notice] ||= " You can provide a pair of youtube embed code. These videos will be displayed in public view for voting. You can see the voting results in my fights page
"
		flash[:quote_notice] ||= "You can provide a pair of quotes. These quotes will be displayed in public view for voting. You can see the voting results in my fights page"
		flash[:image_error] = flash[:embed_error] = flash[:quote_error] = nil
	  @categories = Category.all(:order=>"id")
	end
	
	def create
		if params[:ct] == Fight::IMAGE
			upload_image
		elsif params[:ct] == Fight::EMBED
			upload_embeded
		elsif params[:ct] == Fight::QUOTE
			upload_quote
		end
	end
	
	private
	def upload_image
		attachment1 = Attachment.new(params[:fighter1])
		attachment2 = Attachment.new(params[:fighter2])
		fighter1 = Fighter.new(:name=>params[:fighter1_name])
		fighter2 = Fighter.new(:name=>params[:fighter2_name])
		fight = Fight.new(:title=>params[:fight_title])
		if attachment1.valid? && attachment2.valid?
			fight.category = fighter1.category = fighter2.category = Category.find_by_name(params[:fight_category])
			fight.user = fighter1.user = fighter2.user = current_user
			fighter1.save
			fighter2.save
			attachment1.attachable = fighter1
			attachment2.attachable = fighter2
			fight.fighter_one_id = fighter1.id
			fight.fighter_two_id = fighter2.id
			fight.content_type = params[:ct]
			fight.save!
			attachment1.save!
			attachment2.save!
			flash[:image_notice] = "Your fight has been successfully uploaded"
			#~ FightMailer.deliver_share_fight("admin@popfight.com", "popfight@railsfactory.org",fight) rescue ""
		else
			flash[:image_notice] = nil
			flash[:image_error] = "Unable to save your images, Please upload only images less than the size of 3MB"
			@categories = Category.all(:order=>"id")
			render :action=>'new' and return
		end
		
		redirect_to new_upload_path(:ct=> Fight::IMAGE)
	end
	
		def upload_embeded
 		fighter1 = Fighter.new(:name=>params[:fighter1_name], :embed_src=>clean_embed_content(params[:fighter1_embed_source]))
		fighter2 = Fighter.new(:name=>params[:fighter2_name], :embed_src=>clean_embed_content(params[:fighter2_embed_source]))
		fight = Fight.new(:title=>params[:fight_title])
		if fighter1.embed_src && fighter2.embed_src
			fight.category = fighter1.category = fighter2.category = Category.find_by_name(params[:fight_category])
			fight.user = fighter1.user = fighter2.user = current_user
 			fighter1.save!
 			fighter2.save!
			fight.fighter_one_id = fighter1.id
			fight.fighter_two_id = fighter2.id
			fight.content_type = params[:ct]
			fight.save!
			flash[:embed_notice] = "Your fight has been successfully uploaded"
			FightMailer.deliver_share_fight("admin@popfight.com", "popfight@railsfactory.org",fight) rescue ""
		else
			flash[:embed_notice] = nil
			flash[:embed_error] = "Unable to save your embed sources, Please check your embed content again"
			@categories = Category.all(:order=>"id")
			render :action=>'new' and return
		end
		
		redirect_to new_upload_path(:ct=> Fight::EMBED)
	end
	
		def upload_quote
 		fighter1 = Fighter.new(:name=>params[:fighter1_name], :quote=>clean_quote_content(params[:fighter1_quote]))
		fighter2 = Fighter.new(:name=>params[:fighter2_name], :quote=>clean_quote_content(params[:fighter2_quote]))
		fight = Fight.new(:title=>params[:fight_title])
		if fighter1.quote && fighter2.quote
			fight.category = fighter1.category = fighter2.category = Category.find_by_name(params[:fight_category])
			fight.user = fighter1.user = fighter2.user = current_user			
 			fighter1.save!
 			fighter2.save!
			fight.fighter_one_id = fighter1.id
			fight.fighter_two_id = fighter2.id
			fight.content_type = params[:ct]
			fight.save!
			flash[:quote_notice] = "Your fight has been successfully uploaded"
			FightMailer.deliver_share_fight("admin@popfight.com", "popfight@railsfactory.org",fight) rescue ""
		else
			flash[:quote_notice] = nil
			flash[:quote_error] = "Unable to save your quote content, Please check your quote content again"
			@categories = Category.all(:order=>"id")
			render :action=>'new' and return
		end
		
		redirect_to new_upload_path(:ct=> Fight::QUOTE)
	end
	
	def clean_embed_content(content)
		return nil unless content.include?("<object" && "<param" && "<embed")
		content.gsub(/width="\d+/,'width="194').gsub(/height="\d+/,'height="176')
	end
	
	def clean_quote_content(content)
		return nil if content.strip.empty?
 		return content
	end
	
end
