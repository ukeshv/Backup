class UsersController < ApplicationController
	protect_from_forgery :except => :rpx
	before_filter :login_required, :only => [:myfights] 


  # render new.rhtml
  def new
    redirect_back_or_default(root_path) if logged_in?
    @user = User.new
  end
 
  def create
    logout_keeping_session!
    @user = User.new(params[:user])
    success = @user && @user.save
    if success && @user.errors.empty?
      # Protects against session fixation attacks, causes request forgery
      # protection if visitor resubmits an earlier form using back
      # button. Uncomment if you understand the tradeoffs.
      # reset session
      self.current_user = @user # !! now logged in
      @user.update_attributes(:loggedin_count=>@user.loggedin_count + 1) 
      FightMailer.deliver_signup_mail(@user) rescue ""     
      redirect_back_or_default('/')
      flash[:notice] = "Thanks for signing up! you are now logged in successfully"
    else
      flash[:error]  = "You must fill all the mandatory(<font color='red'><b>*</b></font>) fields.Please try again ."
      render :action => 'new'
    end
  end
	
def rpx
  url = URI.parse "#{$rpx_auth_info_site}"
  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = (url.scheme == 'https')
  request = Net::HTTP::Get.new("#{url.path}?apiKey=#{$rpx_api_key}&token=#{params[:token]}")
  response, data = http.request(request)
  user = ActiveSupport::JSON.decode(data)  
  #puts user.inspect
  if user['profile'] and user['profile']['preferredUsername']
    @user = User.find_by_name_and_identifier_url(user['profile']['preferredUsername'],user['profile']['identifier'])
    if @user.nil?
      @user = User.create(:name=>user['profile']['preferredUsername'],:is_rpx=>true,:identifier_url=>user['profile']['identifier'],:loggedin_count=>1)
      self.current_user = @user
      flash[:notice] = "Logged in successfully"
      redirect_back_or_default('/')
    else
      @user.update_attributes(:loggedin_count=>@user.loggedin_count + 1)    
      self.current_user = @user
      flash[:notice] = "Logged in successfully"
      redirect_back_or_default('/')
    end
  else
    flash[:notice] = "Not able to fetch your details using Rpx...Try again with Rpx openID or Provide your details to signup"	  
    redirect_to signup_path
  end  
  #redirect_to root_path
  rescue 
  flash[:error] = "#{$!}"  
  redirect_to signup_path
end

def myfights
	@myfights = current_user.fights.all :limit=>25
end

	
end
