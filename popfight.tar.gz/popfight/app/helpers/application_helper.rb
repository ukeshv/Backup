# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper

	def find_category_count(category)
		fights = Fight.from_category(category)		
		return fights.length
	end
 
end
