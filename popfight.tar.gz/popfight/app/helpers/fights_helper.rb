module FightsHelper

 def country_details_of(fight, number)
	 res = ''
	 if(number=="1")
	     fight.fighter_one_country_details.each{ |k, v|	 res += ("<div class='clear'><!-- --></div><div class='light_name_head'>&nbsp;</div><div class='state_vote'>#{printable_name_of_country(k)} (#{v})</div>") } if fight.fighter_one_country_details
	 else
		fight.fighter_two_country_details.each{ |k, v|	 res += ("<div class='clear'><!-- --></div><div class='light_name_head'>&nbsp;</div><div class='state_vote'>#{printable_name_of_country(k)} (#{v})</div>") } if fight.fighter_two_country_details
	 end	
	 res
 end
 
 def printable_name_of_country(country_code)
	 country = Country.find_by_iso(country_code)
	 country ? country.printable_name : country_code
 end
 
 def switch_category
	 if params[:category_name]
	  "<br/><span><a style='font-size:12px; float:right; margin-top:-20px; margin-right:90px; color:white; text-decoration:none' title='watch fights from any category' href='#{root_path}'>Watch All Fights</a><br/></span>" 
	 else	
		"<br/><span><a style='font-size:12px; float:right; margin-top:-20px; margin-right:90px; color:white; text-decoration:none' title='watch fights only from #{@category_name} category' href='#{category_fight_path(@category_name)}'>Watch only #{@category_name.titleize} Fights</a><br/></span>" 
	 end
 end
 
end
