class Attachment < ActiveRecord::Base
	has_attachment :content_type => :image,
    :storage => :file_system,
    :path_prefix => 'public/uploaded_images',
    :size => 1.kilobyte..3.megabytes,
    :resize_to => '194x176',
		:thumbnails => {:thumb => '135x118>', :small=>'83x73>' }
		
		validates_as_attachment
		
		belongs_to :attachable, :polymorphic => true
end
