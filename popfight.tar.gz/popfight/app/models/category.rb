class Category < ActiveRecord::Base
	has_many :fights
	has_many :fighters
	
def fight_count
	count = Fight.count(:all,:conditions=>['category_id = ?',self.id])
	return count
end	

end
