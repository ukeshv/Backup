class Comment < ActiveRecord::Base
validates_presence_of :name,:message=>"Enter your name"	
validates_presence_of :fight_comment,:message=>"Enter your comment for this fight"	

def fight_title(f)
	f = Fight.find_by_id(f)
	return f.title
end	

def fight_permalink(f)
	f = Fight.find_by_id(f)
	return f.permalink
end	

end
