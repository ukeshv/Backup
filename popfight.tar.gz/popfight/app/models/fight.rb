class Fight < ActiveRecord::Base
  serialize :fighter_one_country_details
  serialize :fighter_two_country_details
  after_create :create_permalink
  before_save :update_vote_count, :update_fighter_names
  
  belongs_to :category
	belongs_to :user
	has_many :report_abuses,:class_name=>"ReportAbuse"
  named_scope :active_records, lambda { {:conditions=>["status = ?",true]} }
  named_scope :from_category, lambda {|category_id| {:conditions=>["category_id = ?", category_id]} }
  named_scope :having_id, lambda {|id| {:conditions=>["id = ?", id]} }
	
	

  IMAGE = 'image'
  QUOTE = 'quote'
  EMBED = 'embed'
 
  def title
		self[:title] || "Unknown Title"
	end
	
  def fighter_one_count
    self[:fighter_one_count] || 0
  end  

  def fighter_two_count
    self[:fighter_two_count] || 0
  end  


  def fighter_one
   @fighter_one || Fighter.find_by_id(self.fighter_one_id)
  end
 
  def fighter_two
   @fighter_two ||= Fighter.find_by_id(self.fighter_two_id)
  end
 
  def increment_count_of_country(country, winner)
    if winner == "1"
      h = self.fighter_one_country_details || {}
      h[country] = h[country].to_i + 1
		  self.fighter_one_country_details = h
    elsif winner == "2"
      h = self.fighter_two_country_details || {}
      h[country] = h[country].to_i + 1
		  self.fighter_two_country_details = h
    end
    self.save!
  end
  
  def update_winner(number)
    ( number=="1" ? self.fighter_one_count += 1 : self.fighter_two_count += 1 ) if number
    self.save if self.fighter_one_count_changed? || self.fighter_two_count_changed?
  end

 def create_permalink
	 str = "#{self.id}-#{self.fighter_one.name}-vs-#{self.fighter_two.name}"
	 self.permalink = str.gsub(/\W+/, '-').gsub(/^-+/,'').gsub(/-+$/,'').downcase
   self.save!
 end
 
 def update_vote_count
  self.total_count = self.fighter_one_count + self.fighter_two_count
 end 
 
  def update_fighter_names
	  self.fighter_one_name = self.fighter_one.name
	  self.fighter_two_name = self.fighter_two.name
  end
 
  def fight_content_of(f)
   if self.content_type == IMAGE
    if !f.attachment.nil?	
    "<img class='image' src='#{f.attachment.public_filename}' alt='#{f.attachment.filename}' />"
    else
    "<img class='image' src='/images/img_box.jpg' width='194' height='176' />"
    end	    
   elsif self.content_type == QUOTE
    "<span class='uppos'>#{f.quote}<span></span></span>"
   elsif self.content_type == EMBED
		 f.id== self.fighter_one.id ? "<span class='embed' id='em1'>#{f.embed_src}</span>" : "<span class='embed' id='em2'>#{f.embed_src}</span>"
   end    
 end
 
	def thumbnail_fight_content_of(f)            
		if self.content_type == IMAGE 
			if !f.attachment.nil?			
			  "<a href='/fights/#{self.permalink}' style='text-decoration:none'><img class='fight_img' src='#{f.attachment.public_filename(:small)}' alt='#{f.attachment.filename}' /></a>" 
			 else
			  "<a href='/fights/#{self.permalink}' style='text-decoration:none'><img class='fight_img' src='/images/img_box.jpg' width='83' height='73' /></a>" 
			end	 
		elsif self.content_type == QUOTE
			etc_string = (f.quote.length > 120) ? '...' : ''
			"<a href='/fights/#{self.permalink}' style='text-decoration:none'><span class='thumb_uppos'>#{f.quote[0..120]}#{'...'}<span></span></span></a>"
		elsif self.content_type == EMBED
			"<a href='/fights/#{self.permalink}' style='text-decoration:none'><span class='thumb_embed'><img src='#{fetch_img(f.embed_src)}' border=0 /></span></a>"
		end    
  end 
	
	def mail_thumbnail_fight_content_of(f)            
		if self.content_type == IMAGE                
			"<img style='float:left;margin-left:20px;margin-top:8px;' src='#{$app_url}#{f.attachment.public_filename(:small)}' alt='#{f.attachment.filename}' />"
		elsif self.content_type == QUOTE
			etc_string = (f.quote.length > 120) ? '...' : ''
			"<span style='width:220px;font-family:Arial, Helvetica, sans-serif;font-size:9px;margin-left:10px;margin-top:20px;color:#bdbdbd;padding-left:25px;margin-bottom:20px;line-height:22px;'>&quot;#{f.quote[0..120]}#{'...'}&quot;</span>"
		elsif self.content_type == EMBED
			"<span class='thumb_embed'><img src='#{mail_fetch_img(f.embed_src)}' border=0 /></span>"
		end    
  end
 
 #Fetching image for youtube videos
	def fetch_img(src)
    img_code = src.scan(/www.youtube.com\/v\/(.*?)&/) 
    if img_code
			img_url = "http://i3.ytimg.com/vi/#{img_code[0]}/default.jpg"
			response = Net::HTTP.get_response(URI.parse(img_url))
			if response.class.to_s=="Net::HTTPOK"
				img_src = "http://i3.ytimg.com/vi/#{img_code[0]}/default.jpg"
			else
				img_src = "/images/fighter1.jpg"
			end
			return img_src 
		else
			img_src = "/images/fighter1.jpg"
		end
	end
 
 #Fetching image for youtube videos
	def mail_fetch_img(src)
    img_code = src.scan(/www.youtube.com\/v\/(.*?)&/) 
    if img_code
			img_url = "http://i3.ytimg.com/vi/#{img_code[0]}/default.jpg"
			response = Net::HTTP.get_response(URI.parse(img_url))
			if response.class.to_s=="Net::HTTPOK"
				img_src = "http://i3.ytimg.com/vi/#{img_code[0]}/default.jpg"
			else
				img_src = "#{app_url}/images/fighter1.jpg"
			end
			return img_src 
		else
			img_src = "#{app_url}/images/fighter1.jpg"
		end
	end
end
