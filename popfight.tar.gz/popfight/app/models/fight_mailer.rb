class FightMailer < ActionMailer::Base
	def share_fight(from_address, to_address, fight)
		@recipients = "#{to_address}"
		@from = from_address
		@subject = "Share Popfight"
		@sent_on = Time.now
		@body[:site_url] = $app_url
		@content_type = "text/html"
		@body[:receiver] = to_address
		@body[:fight] = fight
	end
	
	def signup_mail(user)
		@recipients = "#{user.email}"
		@from = "admin@popfight.com"
		@subject = "Welcome to Popfight"
		@sent_on = Time.now
		@body[:site_url] = $app_url
		@content_type = "text/html"
		@body[:user] = user
	end
end
