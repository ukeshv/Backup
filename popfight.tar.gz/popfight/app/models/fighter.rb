class Fighter < ActiveRecord::Base
	has_one :attachment, :as => :attachable, :dependent => :destroy
	xss_terminate :except => [ :embed_src ]
	belongs_to :category
	belongs_to :user
	
	def name
		self[:name] || "Unknown"
	end
	
end
