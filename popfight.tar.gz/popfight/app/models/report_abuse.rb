class ReportAbuse < ActiveRecord::Base
	#Relationship
	belongs_to :fight
	
	#Validations
	
	validates_presence_of :abuser_email, :message => "Enter your Email Address"
	validates_presence_of :reason, :message => "Enter reason to abuse"
  validates_format_of :abuser_email,:with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i, :message => "Email is invalid"
  
def fight_title(f)
	f = Fight.find_by_id(f)
	return f.title
end	 
 
def fight_permalink(f)
	f = Fight.find_by_id(f)
	return f.permalink
end	 
 
end
