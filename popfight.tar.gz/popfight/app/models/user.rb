require 'digest/sha1'

class User < ActiveRecord::Base
  include Authentication
  include Authentication::ByPassword
  include Authentication::ByCookieToken

  validates_presence_of :name,:message=>"Name can't be blank"
  validates_format_of :name,:with => Authentication.name_regex,  :message => "Enter Valid Name", :allow_nil => true
  validates_length_of :name,:within => 2..100,:too_long=>"Name is too long (maximum is 100 characters)",:too_short=>"Name is too short (minimum is 2 characters)"

  validates_presence_of :email,:message=>"Email can't be blank",:if=>:not_using_rpx?
  validates_length_of :email,:within => 6..100,:too_short=>"Email is too short (minimum is 6 characters)",:too_long=>"Email is too long (maximum is 100 characters)",:if=>:not_using_rpx? #r@a.wk
  validates_uniqueness_of :email,:message=>"Email is already registered with popfight",:if=>:not_using_rpx?
  validates_format_of :email,:with => Authentication.email_regex, :message => "Email is invalid",:if=>:not_using_rpx? #Authentication.bad_email_message  

  # HACK HACK HACK -- how to do attr_accessible from here?
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  attr_accessible :email, :name, :password, :password_confirmation,:is_rpx,:loggedin_count,:identifier_url
	has_many :fights
	has_many :fighters

  def password_required?
    not_using_rpx? && (crypted_password.blank? || !password.blank?)
  end  
  
    def not_using_rpx?
    !is_rpx
  end
  
  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  #
  # uff.  this is really an authorization, not authentication routine.  
  # We really need a Dispatch Chain here or something.
  # This will also let us return a human error message.
  #
  def self.authenticate(email, password)
    return nil if email.blank? || password.blank?
    u = find_by_email(email.downcase) # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  def login=(value)
    write_attribute :login, (value ? value.downcase : nil)
  end

  def email=(value)
    write_attribute :email, (value ? value.downcase : nil)
  end

  def self.rpx_login_count
	self.count(:all,:conditions=>['is_rpx = ?',true])
  end	

def self.signup_count
	self.count(:all,:conditions=>['is_rpx = ?',false])
end	

  protected
    


end
