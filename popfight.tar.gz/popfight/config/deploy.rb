set :scm, :git
set :repository, "git@github.com:railsrumble/rr09-team-218.git"
set :application, "popfight"
set :branch, "railsrumble09"

set :linode_address, "74.207.227.238"

set :deploy_to, "/var/www/apps/#{application}"
set :user, "keyboard"
set :runner, "d3pl0y3n"
set :use_sudo, false

role :app, linode_address
role :web, linode_address
role :db,  linode_address, :primary => true

namespace :init do
  desc "create database.yml"
  task :database_yml do
    set :db_user, "daredevil"
    set :db_pass, "SCRj6Yme09"
    database_configuration =<<-EOF
---
login: &login
  adapter: mysql
  database: #{application}_production
  host: localhost
  username: #{db_user}
  password: #{db_pass}

production:
  <<: *login

EOF
    run "mkdir -p #{shared_path}/config"
    put database_configuration, "#{shared_path}/config/database.yml"
  end

end

namespace :localize do
  desc "copy shared configurations to current"
  task :copy_shared_configurations, :roles => [:app] do
    %w[database.yml].each do |f|
      run "ln -nsf #{shared_path}/config/#{f} #{current_path}/config/#{f}"
    end
  end
  desc "copy shared images to current"
  task :copy_shared_images, :roles => [:app] do
        run "ln -nfs /var/www/apps/popfight/shared/uploaded_images /var/www/apps/popfight/current/public/uploaded_images"
    end
end

namespace :deploy do
  desc "Restart Application"
  task :restart, :roles => :app do
    run "touch #{current_path}/tmp/restart.txt"
	end
end

after "deploy:setup", "init:database_yml"
after "deploy:symlink", "localize:copy_shared_configurations"
after "deploy:symlink", "localize:copy_shared_images"
