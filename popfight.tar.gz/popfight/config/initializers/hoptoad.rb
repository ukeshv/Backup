HoptoadNotifier.configure do |config|
  config.api_key = '4868bbe9790551ab9f95ee14e4073d43'
end