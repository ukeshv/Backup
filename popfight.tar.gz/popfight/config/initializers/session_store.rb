# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_popfight_session',
  :secret      => '3b8692b31f906cc40c24633a474ccb555dbb29f1b70173b9051da63e52b2580f08b69e9f4accf2ddf0d958ad8588a6f6c0a55e8953fbe03a2ebab3ff51a49cb0'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
