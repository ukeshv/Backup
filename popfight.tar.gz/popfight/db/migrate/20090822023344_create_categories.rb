class CreateCategories < ActiveRecord::Migration
  def self.up
    create_table :categories do |t|
      t.column :name,:string
      t.timestamps
    end
    Category.create(:name=>'Comedy')
    Category.create(:name=>'Entertainment')
    Category.create(:name=>'Education')
    Category.create(:name=>'News/Politics')
    Category.create(:name=>'Sports')
    Category.create(:name=>'Others')
  end

  def self.down
    drop_table :categories
  end
end
