class CreateFighters < ActiveRecord::Migration
  def self.up
    create_table :fighters do |t|
	t.column :name,:string
	t.column :user_id,:integer
	t.column :category_id,:integer
	t.column :embed_src,:text
	t.column :quote,:text
	t.column :type,:string
	t.column :status,:boolean,:default=>true
      t.timestamps
    end
  end

  def self.down
    drop_table :fighters
  end
end
