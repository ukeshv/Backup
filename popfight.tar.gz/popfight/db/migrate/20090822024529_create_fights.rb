class CreateFights < ActiveRecord::Migration
  def self.up
    create_table :fights do |t|
	t.column :title,:string
	t.column :fighter_one_id,:integer
	t.column :fighter_two_id,:integer
	t.column :user_id,:integer
	t.column :category_id,:integer
	t.column :permalink,:text
	t.column :fighter_one_count,:integer,:default=>0
	t.column :fighter_two_count,:integer,:default=>0
	t.column :total_count,:integer,:default=>0		
	t.column :country_details,:text
	t.column :fight_of_the_day,:boolean,:default=>false
	t.column :report_abuse_count,:integer,:default=>0
	t.column :status,:boolean,:default=>true	
      t.timestamps
    end
  end

  def self.down
    drop_table :fights
  end
end
