class AddContent < ActiveRecord::Migration
  def self.up
	  remove_column :fighters,:type
	  add_column :fights,:content_type,:string
  end

  def self.down
	  add_column :fighters,:type,:string
	  remove_column :fights,:content_type
  end
end
