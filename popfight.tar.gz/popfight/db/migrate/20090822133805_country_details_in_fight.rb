class CountryDetailsInFight < ActiveRecord::Migration
  def self.up
    rename_column :fights, :country_details, :fighter_one_country_details
    add_column :fights, :fighter_two_country_details, :text
  end

  def self.down
    rename_column :fights, :fighter_one_country_details, :country_details
    remove_column :fights, :fighter_two_country_details
  end
end
