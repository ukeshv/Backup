class AddFightersName < ActiveRecord::Migration
  def self.up
	  add_column :fights,:fighter_one_name,:string
	  add_column :fights,:fighter_two_name,:string
  end

  def self.down
	  remove_column :fights,:fighter_one_name
	  remove_column :fights,:fighter_two_name
  end
end
