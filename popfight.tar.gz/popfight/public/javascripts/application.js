// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults
function check_search_text(){
search_string = $('search_box').value.strip()
 if(search_string.length >=1 )
  return true
else
  return false
}