function assign_select_value(selectbox, boxIndex) {
var selected_value=selectbox.value;
document.getElementById('category_select_'+boxIndex).value=selected_value;
}

function assign_file_value(browse, boxIndex) {
var file_name=browse.value;
document.getElementById('file_select_'+boxIndex).value=file_name;
}

function toogle_tabs(event, selectedItem, form){
if(selectedItem.id=="upload1"){
document.getElementById('image_upload_form').style.display='block';
document.getElementById('embeded_upload_form').style.display='none';
document.getElementById('quotes_upload_form').style.display='none';
document.getElementById('image_error').innerHTML = "";
}
else if(selectedItem.id=="upload2"){
document.getElementById('image_upload_form').style.display='none';
document.getElementById('embeded_upload_form').style.display='block';
document.getElementById('quotes_upload_form').style.display='none';
document.getElementById('embed_error').innerHTML = "";
}
else if(selectedItem.id=="upload3"){
document.getElementById('image_upload_form').style.display='none';
document.getElementById('embeded_upload_form').style.display='none';
document.getElementById('quotes_upload_form').style.display='block';
document.getElementById('quote_error').innerHTML = "";
}

var a = new Array();
a.push(document.getElementById('upload1'));
a.push(document.getElementById('upload2'));
a.push(document.getElementById('upload3'));

for(i=0; i<3; i++){
a[i].className='';
}
selectedItem.className='current';
form.reset();
//$('flash_msg_container').innerHTML="";
Event.stop(event);
}

function set_upload_tab(content_type){
if(content_type=="image"){
document.getElementById('image_upload_form').style.display='block';
document.getElementById('embeded_upload_form').style.display='none';
document.getElementById('quotes_upload_form').style.display='none';
selectedItem = document.getElementById('upload1');
}
else if(content_type=="embed"){
document.getElementById('image_upload_form').style.display='none';
document.getElementById('embeded_upload_form').style.display='block';
document.getElementById('quotes_upload_form').style.display='none';
selectedItem = document.getElementById('upload2');
}
else if(content_type=="quote"){
document.getElementById('image_upload_form').style.display='none';
document.getElementById('embeded_upload_form').style.display='none';
document.getElementById('quotes_upload_form').style.display='block';
selectedItem = document.getElementById('upload3');
}

var a = new Array();
a.push(document.getElementById('upload1'));
a.push(document.getElementById('upload2'));
a.push(document.getElementById('upload3'));

for(i=0; i<3; i++){
a[i].className='';
}
selectedItem.className='current';
}

function submit_upload_form(form, form_name){
error_msg = ""
if ($(form_name+'_title').value.strip() == "")
 error_msg += "Title cannot be blank \n"
if ($(form_name+'_name1').value.strip() == "")
 error_msg += "Name1 cannot be blank \n"
 if ($(form_name+'_name2').value.strip() == "")
 error_msg += "Name2 cannot be blank \n"
 
 if (error_msg == "")
form.submit();
else {
alert("Unable to save your fight! \n\n" + error_msg);
return false;
}
}