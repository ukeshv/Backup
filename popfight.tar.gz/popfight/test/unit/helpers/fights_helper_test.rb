require 'test_helper'

class FightsHelperTest < ActionView::TestCase
end
