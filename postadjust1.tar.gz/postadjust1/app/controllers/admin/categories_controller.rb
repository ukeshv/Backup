class Admin::CategoriesController < ApplicationController
	layout 'admin'
    before_filter :admin_login_required
        protect_from_forgery :except=>[:delete_categories]

  # GET /categories
  # GET /categories.xml
  def index
    load_categories
    
    respond_to do |format|

      format.html # index.html.erb
      format.xml  { render :xml => @categories }
      format.js do
	render :update do |page|
	page.replace_html 'list_categories',:partial=>'categories'
	end
	end
    end
  end

  # GET /categories/1
  # GET /categories/1.xml
  def show
    @category = Category.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @category }
    end
  end

  # GET /categories/new
  # GET /categories/new.xml
  def new
    @category = Category.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @category }
    end
  end

  # GET /categories/1/edit
  def edit
	  load_categories
    @category = Category.find(params[:id])
	render :update do |page|
	page.replace_html "category_#{@category.id}",:partial=>'category_edit'
	end
  end

  # POST /categories
  # POST /categories.xml
  def create
    @category = Category.new(params[:category])
	if params[:selected][:id].empty? 
		@parentid = 0
		else
		@parentid = params[:selected][:id]
	end
	@category = Category.create(:parent_id=>@parentid,:name=>params[:category][:name],:status=>params[:category][:status])

    respond_to do |format|
      if @category.save
	load_categories
        flash[:notice] = 'Category was successfully created.'
        format.html { redirect_to(admin_category_path(@category)) }
        format.xml  { render :xml => @category, :status => :created, :location => @category }
	format.js do          
          render :update do |page|
            page[:category_name].value = ""
            page[:name_category].innerHTML = ""
            page.replace_html 'list_categories',:partial=>'categories'
            page.replace_html 'category_tree',:partial=>'select_category'
            page.replace_html 'goto',:partial=>'goto'
          end
        end 
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @category.errors, :status => :unprocessable_entity }
	        format.js do 
		show_hide_error_messages(@category,'category')
        end
      end
    end
  end
  
  	def show_hide_error_messages(obj,replacing_id)
	  render :update do |page|
	    for h in obj.errors
	      if !obj.errors["#{h[0]}"].nil?
		page.show "#{h[0]}_" +  replacing_id
		page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
	      end
	      page.hide "name_"+ replacing_id if obj.errors['name'].nil?
	    end
	  end
	end	


  # PUT /categories/1
  # PUT /categories/1.xml
  def update
	@category = Category.find(params[:id])
    respond_to do |format|
      if @category.update_attributes(params[:category])
	       	if !params[:selected][:id].empty?
	@category.update_attributes(:parent_id=>params[:selected][:id])
	end
	@categories = @category.self_and_siblings
        flash[:notice] = 'Category was successfully updated.'
        format.html { redirect_to(admin_category_path(@category)) }
        format.xml  { head :ok }
	format.js do          
	render :update do |page|
	page.replace_html 'list_categories',:partial=>'categories'
	page.replace_html 'category_tree',:partial=>'select_category'
        page.replace_html 'goto',:partial=>'goto'

	#page.visual_effect :highlight,"category_#{@category.id}",:duration => 1.5
	end
	end 

      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @category.errors, :status => :unprocessable_entity }
	format.js do 
	show_hide_error_messages(@category,'category_edit')
	end        

      end
    end
  end

  # DELETE /categories/1
  # DELETE /categories/1.xml
  def destroy
	  
    @category = Category.find(params[:id])
    @category.destroy
   # @category.children.delete_all
	load_categories
    respond_to do |format|
      format.html { redirect_to(admin_categories_path) }
      format.xml  { head :ok }
      format.js do
	render :update do |page|
	page.replace_html 'list_categories',:partial=>'categories'
        page.replace_html 'category_tree',:partial=>'select_category'
        page.replace_html 'goto',:partial=>'goto'
	end
      end
    end
  end
  
  def load_categories
	  sort_field = params[:sort].nil? ? 'name asc' : params[:sort]
	  @categories = Category.find(:all,:conditions=>['parent_id=?',0]).paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}"
	  if params[:category_id]
	  @categories = Category.find(:all,:conditions=>['parent_id=?',params[:category_id]]).paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}"
	  @category = Category.find_by_id(params[:category_id])
	  end
  end
  
    def delete_categories
    if !params[:category_ids].blank?
      category_ids = params[:category_ids].split(',')
      category_ids.each do |category|
        category = Category.find(category)
        category.destroy 
      end
    end
    load_categories
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @category }
      format.js do          
        render :update do |page|
	page.replace_html 'list_categories',:partial=>'categories'
        end
      end
    end
   end 
   
  
    def search
    if !params[:category].blank?
	@categories=Category.find(:all,:conditions=>[" (name like '%%"+params[:category].to_s+"%%')"],:order=>"created_at desc")
    else
      load_categories    
    end
    render :update do |page|
      page.replace_html 'list_categories',:partial=>'categories'
    end
  end  
  

  
end
