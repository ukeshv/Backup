class Admin::DutyStationsController < ApplicationController
  before_filter :admin_login_required
  layout 'admin'
  protect_from_forgery :except=>[:delete_duty_stations]
  
  # GET /duty_stations
  # GET /duty_stations.xml
  def index
    load_duty_stations
    load_countries_dropdown
    @duty_station = DutyStation.new

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @duty_stations }
       format.js do          
        replace_duty_stations
      end
    end
  end

  # GET /duty_stations/1
  # GET /duty_stations/1.xml
  def show
    @duty_station = DutyStation.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @duty_station }
    end
  end

  # GET /duty_stations/new
  # GET /duty_stations/new.xml
  def new
    @duty_station = DutyStation.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @duty_station }
    end
  end

  # GET /duty_stations/1/edit
  def edit
    load_countries_dropdown
    @duty_station = DutyStation.find(params[:id])
    render :update do |page|
      page.replace_html "duty_station_#{@duty_station.id}",:partial=>'duty_station_edit'
    end
  end

  # POST /duty_stations
  # POST /duty_stations.xml
  def create
    @duty_station = DutyStation.new(params[:duty_station])
    respond_to do |format|
      if @duty_station.save
        @post = @duty_station.create_post_report
           file_path = "#{RAILS_ROOT}/doc/TOC.html"
							File.open(file_path, 'r') do |f|
								@content =	f.read 
							end	
          @post.update_attribute(:content,@content)    
        load_duty_stations
        format.html { redirect_to(admin_duty_station_path(@duty_station)) }
        format.xml  { render :xml => @duty_station, :status => :created, :location => @duty_station }
         format.js do          
          render :update do |page|
            page[:duty_station_name].value = ""
            page[:name_duty_station].innerHTML = ""
            page[:duty_station_status].checked = false
            page[:country_id_duty_station].innerHTML = ""
            page[:duty_station_country_id].selectedIndex=0
            page.replace_html 'list_duty_stations',:partial=>'duty_stations'
            page.visual_effect :highlight,"duty_station_#{@duty_station.id}",:duration => 1.5
          end
        end 
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @duty_station.errors, :status => :unprocessable_entity }        
        format.js do 
          show_hide_error_messages(@duty_station,'duty_station')
        end        
      end
    end
  end

	def show_hide_error_messages(obj,replacing_id)
	  render :update do |page|
	    for h in obj.errors
	      if !obj.errors["#{h[0]}"].nil?
	        page.show "#{h[0]}_" +  replacing_id
	        page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
	      end
	      page.hide "name_"+ replacing_id if obj.errors['name'].nil?
	      page.hide "country_id_"+ replacing_id if obj.errors['country_id'].nil?
	    end
	  end
	end

    def replace_duty_stations
      render :update do |page|
        page.replace_html 'list_duty_stations',:partial=>'duty_stations'
      end
    end  

  # PUT /duty_stations/1
  # PUT /duty_stations/1.xml
  def update
    @duty_station = DutyStation.find(params[:id])

    respond_to do |format|
      if @duty_station.update_attributes(params[:duty_station])
        load_duty_stations
        format.html { redirect_to(admin_duty_station_path(@duty_station)) }
        format.xml  { head :ok }
        format.js do          
          render :update do |page|
            page.replace_html 'list_duty_stations',:partial=>'duty_stations'
            page.visual_effect :highlight,"duty_station_#{@duty_station.id}",:duration => 1.5
          end
        end
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @duty_station.errors, :status => :unprocessable_entity }
        format.js do 
          show_hide_error_messages(@duty_station,'duty_station_edit')
        end
      end
    end
  end

  # DELETE /duty_stations/1
  # DELETE /duty_stations/1.xml
  def destroy
    @duty_station = DutyStation.find(params[:id])
    @duty_station.destroy
    load_duty_stations
    
    respond_to do |format|
      format.html { redirect_to(admin_duty_stations_path) }
      format.xml  { head :ok }
      format.js do          
        replace_duty_stations
      end
    end
  end
  
  def load_duty_stations
    sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort]
    @duty_stations = DutyStation.paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}", :include=>[:country]
  end  
  
  # Get duty stations list as drop down
  def load_countries_dropdown
    @countries = Country.to_dropdown
  end
  
  def delete_duty_stations
    if !params[:duty_station_ids].blank?
      duty_station_ids = params[:duty_station_ids].split(',')
      duty_station_ids.each do |duty_station_id|
        duty_station = DutyStation.find(duty_station_id)
        duty_station.destroy 
      end
    end
    load_duty_stations
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @duty_stations }
      format.js do          
        render :update do |page|
        page.replace_html 'list_duty_stations',:partial=>'duty_stations'
        end
      end
    end
   end 
  
    def search
    if !params[:search_duty_station].blank?
	@duty_stations=DutyStation.paginate(:all,:conditions=>[" (name like '%%"+params[:search_duty_station].to_s+"%%') or (countries.country_name like '%%"+params[:search_duty_station].to_s+"%%')"],:order=>"created_at desc",:page=>params[:page],:per_page=>15, :include=>[:country])
    else
      load_duty_stations
      load_countries_dropdown    
    end
    render :update do |page|
      page.replace_html 'list_duty_stations',:partial=>'duty_stations'
    end
  end  

  
end
