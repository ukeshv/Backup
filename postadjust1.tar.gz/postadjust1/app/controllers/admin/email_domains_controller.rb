class Admin::EmailDomainsController < ApplicationController
  before_filter :admin_login_required
  layout 'admin'
  protect_from_forgery :except=>[:delete_email_domains]
  
  # GET /email_domains
  # GET /email_domains.xml
  def index
    load_email_domains
    @email_domain = EmailDomain.new
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @email_domains }
      format.js do          
        render :update do |page|
          page.replace_html 'list_email_domains',:partial=>'email_domains'
        end
      end
    end
  end

  # GET /email_domains/1
  # GET /email_domains/1.xml
  def show
    @email_domain = EmailDomain.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @email_domain }
    end
  end

  # GET /email_domains/new
  # GET /email_domains/new.xml
  def new
    @email_domain = EmailDomain.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @email_domain }
    end
  end

  # GET /email_domains/1/edit
  def edit
    @email_domain = EmailDomain.find(params[:id])
    render :update do |page|
      page.replace_html "email_domain_#{@email_domain.id}",:partial=>'email_domain_edit'
    end
  end

  # POST /email_domains
  # POST /email_domains.xml
  def create
    @email_domain = EmailDomain.new(params[:email_domain])
    
    respond_to do |format|
      if @email_domain.save
        load_email_domains
        format.html { redirect_to(admin_email_domain_path(@email_domain)) }
        format.xml  { render :xml => @email_domain, :status => :created, :location => @email_domain }
        format.js do          
          render :update do |page|
            page[:email_domain_domain].value = ""
            page[:domain_email_domain].innerHTML = ""
            page[:email_domain_status].checked = false
            page.replace_html 'list_email_domains',:partial=>'email_domains'
            page.visual_effect :highlight,"email_domain_#{@email_domain.id}",:duration => 1.5
          end
        end 
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @email_domain.errors, :status => :unprocessable_entity }
        format.js do 
          show_hide_error_messages(@email_domain,'email_domain')
        end
      end
    end
  end

	def show_hide_error_messages(obj,replacing_id)
	  render :update do |page|
	    for h in obj.errors
	      if !obj.errors["#{h[0]}"].nil?
	        page.show "#{h[0]}_" +  replacing_id
	        page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
	      end
	      page.hide "domain_"+ replacing_id if obj.errors['domain'].nil?
	    end
	  end
	end	

  # PUT /email_domains/1
  # PUT /email_domains/1.xml
  def update
    @email_domain = EmailDomain.find(params[:id])

    respond_to do |format|
      if @email_domain.update_attributes(params[:email_domain])
        load_email_domains
        flash[:notice] = 'EmailDomain was successfully updated.'
        format.html { redirect_to(admin_email_domain_path(@email_domain)) }
        format.xml  { head :ok }
        format.js do          
          render :update do |page|
            page.replace_html 'list_email_domains',:partial=>'email_domains'
            page.visual_effect :highlight,"email_domain_#{@email_domain.id}",:duration => 1.5
          end
        end 
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @email_domain.errors, :status => :unprocessable_entity }
        format.js do 
          show_hide_error_messages(@email_domain,'email_domain_edit')
        end        
      end
    end
  end

  # DELETE /email_domains/1
  # DELETE /email_domains/1.xml
  def destroy
    @email_domain = EmailDomain.find(params[:id])
    @email_domain.destroy
    load_email_domains
    
    respond_to do |format|
      format.html { redirect_to(admin_email_domains_path) }
      format.xml  { head :ok }
      format.js do          
        render :update do |page|
          page.replace_html 'list_email_domains',:partial=>'email_domains'
        end
      end
    end
  end
  
  def delete_email_domains
    if !params[:email_domain_ids].blank?
      email_domain_ids = params[:email_domain_ids].split(',')
      email_domain_ids.each do |email_domain_id|
        email_domain = EmailDomain.find(email_domain_id)
        email_domain.destroy 
      end
    end
    load_email_domains
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @email_domains }
      format.js do          
        render :update do |page|
        page.replace_html 'list_email_domains',:partial=>'email_domains'
        end
      end
    end
   end 
  
  def load_email_domains
    sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort]
    @email_domains = EmailDomain.paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}"
  end  
  
  def search
    if !params[:search_email_domain].blank?
      @email_domains = EmailDomain.paginate(:all,:conditions=>["(domain like '%%"+params[:search_email_domain].to_s+"%%')"],:order=>"created_at desc",:page=>params[:page],:per_page=>15)
    else
      load_email_domains    
    end
    render :update do |page|
      page.replace_html 'list_email_domains',:partial=>'email_domains'
    end
  end  
  
end
