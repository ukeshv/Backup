class Admin::FeedImportsController < ApplicationController
	before_filter :admin_login_required
  layout 'admin'
	
	 # GET /feed_imports
  # GET /feed_imports.xml
  def index
    @feed_imports = FeedImport.paginate :page=>params[:page],:per_page=>15,:order=>"created_at desc"
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @feed_imports }
    end
  end	
	
	# GET /feed_imports/new
  # GET /feed_imports/new.xml
  def new
    @feed_import = FeedImport.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @feed_import }
    end
  end	
	
	# POST /feed_imports
  # POST /feed_imports.xml
  def create
    @feed_import = FeedImport.new(params[:feed_import])
    
    respond_to do |format|
      if @feed_import.save
      flash[:notice] = 'FeedImport was successfully created.'
      format.html { redirect_to(admin_feed_imports_url) }
        format.xml  { render :xml => @feed_import, :status => :created, :location => @feed_import }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @feed_import.errors, :status => :unprocessable_entity }
      end
    end
  end
	
		# GET /feed_imports/1/edit
  def edit
    @feed_import = FeedImport.find(params[:id])
  end
	
	# PUT /feed_imports/1
  # PUT /feed_imports/1.xml
  def update
    @feed_import = FeedImport.find(params[:id])

    respond_to do |format|
      if @feed_import.update_attributes(params[:feed_import])
        flash[:notice] = 'FeedImport was successfully updated.'
        format.html { redirect_to(admin_feed_imports_url) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @feed_import.errors, :status => :unprocessable_entity }
      end
    end
  end
	
	def change_feed_imports_status
    if params[:feed_imports]
      if params[:commit] == "Activate Selected Feed Imports"
        params[:feed_imports].each do |feed_import|
          f = FeedImport.find(feed_import)
          f.update_attribute(:status,true)
        end  
        flash[:notice] = "Selected FeedImport(s) are Activated"
      else
        params[:feed_imports].each do |feed_import|
          f = FeedImport.find(feed_import)
          f.update_attribute(:status,false)
        end  
        flash[:notice] = "Selected FeedImport(s) are Deactivated"
      end  
      redirect_to admin_feed_imports_url
    else  
      flash[:error] = "Select FeedImport(s) to Activate/Deactivate"
      redirect_to admin_feed_imports_url
    end  
  end  
  
  def view_log
    require 'fileutils' 
    @feed_import = FeedImport.find(params[:id])
    log_directory_path = "#{RAILS_ROOT}/public/feed_imports/#{@feed_import.id}/log"
    if File.directory?("#{RAILS_ROOT}/public/feed_imports/#{@feed_import.id}/log")
      @log_files = Dir.entries(log_directory_path)
      @valid_log_files = [ ]
      @log_files.each do |log_file|
        if log_file != "." && log_file != ".."
          @valid_log_files << log_file
        end  
      end      
    else
      flash[:error] = "Directory for Log Files Not found for #{@feed_import.url}"
      redirect_to admin_feed_imports_url
    end
  end
  
  def download_csv   
    @feed_import = FeedImport.find(params[:id])
    log_directory_path = "#{RAILS_ROOT}/public/feed_imports/#{@feed_import.id}/log/"
    filepath = log_directory_path + params[:filename] + ".csv"
    if File.exists? filepath
     send_file filepath
    else
      flash[:notice] = "File not found"
	   redirect_to admin_feed_imports_url
    end
  end
	
end
