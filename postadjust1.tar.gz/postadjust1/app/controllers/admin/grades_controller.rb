class Admin::GradesController < ApplicationController
  layout 'admin'
  before_filter :admin_login_required
  protect_from_forgery :except=>[:delete_grades]
  
  # GET /grades
  # GET /grades.xml
  def index
     load_grades
    @grade = Grade.new

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @grades }
      format.js do
        render :update do |page|
          page.replace_html 'list_grades',:partial=>'grades'
        end
      end
    end
  end

  # GET /grades/1
  # GET /grades/1.xml
  def show
    @grade = Grade.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @grade }
    end
  end

  # GET /grades/new
  # GET /grades/new.xml
  def new
    @grade = Grade.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @grade }
    end
  end

  # GET /grades/1/edit
  def edit
    @grade = Grade.find(params[:id])
	render :update do |page|
	page.replace_html "grade_#{@grade.id}",:partial=>'grade_edit'
	end
  end

  # POST /grades
  # POST /grades.xml
  def create
    @grade = Grade.new(params[:grade])

    respond_to do |format|
      if @grade.save
	load_grades
        format.html { redirect_to(admin_grade_path(@grade)) }
        format.xml  { render :xml => @grade, :status => :created, :location => @grade }
	format.js do          
        render :update do |page|
           page[:grade_name].value = ""
           page[:name_grade].innerHTML = ""
           page[:grade_status].checked = false
           page.replace_html 'list_grades',:partial=>'grades'
           page.visual_effect :highlight,"grade_#{@grade.id}",:duration => 1.5
           end
        end 

      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @grade.errors, :status => :unprocessable_entity }
	format.js do
		show_hide_error_messages(@grade,'grade')
	end
      end
    end
  end
  
	def show_hide_error_messages(obj,replacing_id)
	  render :update do |page|
	    for h in obj.errors
	      if !obj.errors["#{h[0]}"].nil?
		page.show "#{h[0]}_" +  replacing_id
		page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
	      end
	      page.hide "name_"+ replacing_id if obj.errors['name'].nil?
	    end
	  end
	end	


  # PUT /grades/1
  # PUT /grades/1.xml
  def update
    @grade = Grade.find(params[:id])

    respond_to do |format|
      if @grade.update_attributes(params[:grade])
	load_grades
        flash[:notice] = 'Grade was successfully updated.'
        format.html { redirect_to(admin_grade_path(@grade)) }
        format.xml  { head :ok }
	format.js do
          render :update do |page|
            page.replace_html 'list_grades',:partial=>'grades'
            page.visual_effect :highlight,"grade_#{@grade.id}",:duration => 1.5
    end
    end
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @grade.errors, :status => :unprocessable_entity }
        format.js do 
          show_hide_error_messages(@grade,'grade_edit')
        end        
      end
    end
  end

  # DELETE /grades/1
  # DELETE /grades/1.xml
  def destroy
    @grade = Grade.find(params[:id])
    @grade.destroy
    load_grades
    
    respond_to do |format|
      format.html { redirect_to(grades_url) }
      format.xml  { head :ok }
      format.js do 
	      replace_grades
      end
    end
  end
  
    def load_grades
    sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort]
    @grades = Grade.paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}"
  end  
  
  def delete_grades
    if !params[:grade_ids].blank?
      grade_ids = params[:grade_ids].split(',')
      grade_ids.each do |grade_id|
        grade = Grade.find(grade_id)
        grade.destroy 
      end
    end
    load_grades
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @grades }
      format.js do          
        render :update do |page|
        page.replace_html 'list_grades',:partial=>'grades'
        end
      end
    end
   end 
  
  def replace_grades
	render :update do |page|
	page.replace_html 'list_grades',:partial=>'grades'
	end
end

  def search
    if !params[:search_grade].blank?
      @grades = Grade.paginate(:all,:conditions=>["(name like '%%"+params[:search_grade].to_s+"%%')"],:order=>"created_at desc",:page=>params[:page],:per_page=>15)
    else
      load_grades    
    end
    render :update do |page|
      page.replace_html 'list_grades',:partial=>'grades'
    end
  end  


end
