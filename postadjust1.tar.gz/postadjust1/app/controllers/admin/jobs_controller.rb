class Admin::JobsController < ApplicationController
	layout 'admin'
	  before_filter :admin_login_required
	protect_from_forgery :except=>[:approve_jobs,:reject_jobs]
	
	def index
		@jobs = Job.paginate(:all,:page=>params[:page], :per_page => 15, :order=>"created_at DESC")
	end
	
	def approve
		job = Job.find(params[:id])
		job.update_attribute(:status,true)
		flash[:notice] = "Approved the job"
		redirect_to admin_jobs_path
	end
	
	def reject
		job = Job.find(params[:id])
		job.update_attribute(:status,false)
		flash[:notice] = "Rejected the job"
		redirect_to admin_jobs_path
	end
		
	def approve_jobs
		  if !params[:job_ids].blank?
      job_ids = params[:job_ids].split(',')
      job_ids.each do |job_id|
        job = Job.find(job_id)
        job.update_attribute(:status,true) 
        flash[:notice] = "Selected job(s) are approved"
      end
    end
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @jobs }
      format.js do          
        render :update do |page|
        page.redirect_to admin_jobs_path
        end
      end
    end
	end
	
	def reject_jobs
		  if !params[:job_ids].blank?
      job_ids = params[:job_ids].split(',')
      job_ids.each do |job_id|
        job = Job.find(job_id)
        job.update_attribute(:status,false) 
        flash[:notice] = "Selected job(s) are rejected"
      end
    end
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @jobs }
      format.js do          
        render :update do |page|
        page.redirect_to admin_jobs_path
        end
      end
    end
	end
	
end
