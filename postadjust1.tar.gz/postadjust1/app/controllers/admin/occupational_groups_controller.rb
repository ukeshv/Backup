class Admin::OccupationalGroupsController < ApplicationController
	layout 'admin'
    before_filter :admin_login_required
    protect_from_forgery :except=>[:delete_occupational_groups]
  # GET /occupational_groups
  # GET /occupational_groups.xml
  def index
     load_occupational_groups
    @occupational_group = OccupationalGroup.new

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @occupational_groups }
      format.js do          
        render :update do |page|
	  page.replace_html 'list_occupational_groups',:partial=>'occupational_groups'
	end
      end
    end
  end

  # GET /occupational_groups/1
  # GET /occupational_groups/1.xml
  def show
    @occupational_group = OccupationalGroup.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @occupational_group }
    end
  end

  # GET /occupational_groups/new
  # GET /occupational_groups/new.xml
  def new
    @occupational_group = OccupationalGroup.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @occupational_group }
    end
  end

  # GET /occupational_groups/1/edit
  def edit
    @occupational_group = OccupationalGroup.find(params[:id])
        render :update do |page|
      page.replace_html "occupational_group_#{@occupational_group.id}",:partial=>'occupational_group_edit'
    end

  end

  # POST /occupational_groups
  # POST /occupational_groups.xml
  def create
    @occupational_group = OccupationalGroup.new(params[:occupational_group])

    respond_to do |format|
      if @occupational_group.save
	load_occupational_groups
        format.html { redirect_to(admin_occupational_group_path(@occupational_group)) }
        format.xml  { render :xml => @occupational_group, :status => :created, :location => @occupational_group }
	format.js do
	    render :update do |page|
            page[:occupational_group_name].value = ""
            page[:name_occupational_group].innerHTML = ""
            page[:occupational_group_status].checked = false
            page.replace_html 'list_occupational_groups',:partial=>'occupational_groups'
            page.visual_effect :highlight,"occupational_group_#{@occupational_group.id}",:duration => 1.5
	    end
	end
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @occupational_group.errors, :status => :unprocessable_entity }
	format.js do 
          show_hide_error_messages(@occupational_group,'occupational_group')
	end
      end
    end
  end
  
	def show_hide_error_messages(obj,replacing_id)
	  render :update do |page|
	    for h in obj.errors
	      if !obj.errors["#{h[0]}"].nil?
	        page.show "#{h[0]}_" +  replacing_id
	        page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
	      end
	      page.hide "name_"+ replacing_id if obj.errors['name'].nil?
	    end
	  end
	end	
  

  # PUT /occupational_groups/1
  # PUT /occupational_groups/1.xml
  def update
    @occupational_group = OccupationalGroup.find(params[:id])

    respond_to do |format|
      if @occupational_group.update_attributes(params[:occupational_group])
	load_occupational_groups
        flash[:notice] = 'OccupationalGroup was successfully updated.'
        format.html { redirect_to(@occupational_group) }
        format.xml  { head :ok }
	format.js do
          render :update do |page|
            page.replace_html 'list_occupational_groups',:partial=>'occupational_groups'
            page.visual_effect :highlight,"occupational_group_#{@occupational_group.id}",:duration => 1.5
          end
	end
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @occupational_group.errors, :status => :unprocessable_entity }
	format.js do
          show_hide_error_messages(@occupational_group,'occupational_group_edit')
	end
      end
    end
  end

  # DELETE /occupational_groups/1
  # DELETE /occupational_groups/1.xml
  def destroy
    @occupational_group = OccupationalGroup.find(params[:id])
    @occupational_group.destroy
    load_occupational_groups
    
    respond_to do |format|
      format.html { redirect_to(occupational_groups_url) }
      format.xml  { head :ok }
	format.js do          
         render :update do |page|
          page.replace_html 'list_occupational_groups',:partial=>'occupational_groups'
          end
        end
    end
  end
  
    def load_occupational_groups
    sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort]
    @occupational_groups = OccupationalGroup.paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}"
  end  
  
  def delete_occupational_groups
    if !params[:occupational_group_ids].blank?
      occupational_group_ids = params[:occupational_group_ids].split(',')
      occupational_group_ids.each do |occupational_group_id|
        occupational_group = OccupationalGroup.find(occupational_group_id)
        occupational_group.destroy 
      end
    end
    load_occupational_groups
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @occupational_groups }
      format.js do          
        render :update do |page|
        page.replace_html 'list_occupational_groups',:partial=>'occupational_groups'
        end
      end
    end
   end 
  
    def search
    if !params[:search_occupational_group].blank?
      @occupational_groups = OccupationalGroup.paginate(:all,:conditions=>["(name like '%%"+params[:search_occupational_group].to_s+"%%')"],:order=>"created_at desc",:page=>params[:page],:per_page=>15)
    else
      load_occupational_groups    
    end
    render :update do |page|
      page.replace_html 'list_occupational_groups',:partial=>'occupational_groups'
    end
  end  


end
