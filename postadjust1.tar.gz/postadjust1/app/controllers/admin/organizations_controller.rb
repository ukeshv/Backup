class Admin::OrganizationsController < ApplicationController
  layout 'admin'
    before_filter :admin_login_required
    protect_from_forgery :except=>[:delete_organizations]
	  # GET /organizations
  # GET /organizations.xml
  def index
    load_organizations
    
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @organizations }
	format.js do          
		replace_organizations
	end
    end
  end

  # GET /organizations/1
  # GET /organizations/1.xml
  def show
    @organization = Organization.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @organization }
    end
  end

  # GET /organizations/new
  # GET /organizations/new.xml
  def new
    @organization = Organization.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @organization }
    end
  end

  # GET /organizations/1/edit
  def edit
    @organization = Organization.find(params[:id])
        render :update do |page|
      page.replace_html "organization_#{@organization.id}",:partial=>'organization_edit'
    end

  end

  # POST /organizations
  # POST /organizations.xml
  def create
    @organization = Organization.new(params[:organization])

    respond_to do |format|
      if @organization.save
	load_organizations
        format.html { redirect_to(admin_organization_path(@organization)) }
        format.xml  { render :xml => @organization, :status => :created, :location => @organization }
	format.js do          
          render :update do |page|
            page[:organization_name].value = ""
            page[:name_organization].innerHTML = ""
            page[:organization_website].value = ""
            page[:website_organization].innerHTML = ""
            page.replace_html 'list_organizations',:partial=>'organizations'
            page.visual_effect :highlight,"organization_#{@organization.id}",:duration => 1.5
          end
        end 

      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @organization.errors, :status => :unprocessable_entity }
        format.js do 
		show_hide_error_messages(@organization,'organization')
        end
      end
    end
  end
  
	def show_hide_error_messages(obj,replacing_id)
	  render :update do |page|
	    for h in obj.errors
	      if !obj.errors["#{h[0]}"].nil?
		page.show "#{h[0]}_" +  replacing_id
		page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
	      end
	      page.hide "name_"+ replacing_id if obj.errors['name'].nil?
	      page.hide "website_"+ replacing_id if obj.errors['website'].nil?
	    end
	  end
	end	


  # PUT /organizations/1
  # PUT /organizations/1.xml
  def update
    @organization = Organization.find(params[:id])

    respond_to do |format|
      if @organization.update_attributes(params[:organization])
	load_organizations
        flash[:notice] = 'Organization was successfully updated.'
        format.html { redirect_to(admin_organization_path(@organization)) }
        format.xml  { head :ok }
	format.js do          
	render :update do |page|
	page.replace_html 'list_organizations',:partial=>'organizations'
	page.visual_effect :highlight,"organization_#{@organization.id}",:duration => 1.5
	end
	end 

      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @organization.errors, :status => :unprocessable_entity }
	
        format.js do 
		show_hide_error_messages(@organization,'organization_edit')
        end        
      end
    end
  end

  # DELETE /organizations/1
  # DELETE /organizations/1.xml
  def destroy
    @organization = Organization.find(params[:id])
    @organization.destroy
    load_organizations
    respond_to do |format|
      format.html { redirect_to(admin_organizations_path) }
      format.xml  { head :ok }
	format.js do          
	    replace_organizations
	end

    end
  end
  
    def load_organizations
    sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort]
    @organizations = Organization.paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}"
  end  
  
  def delete_organizations
    if !params[:organization_ids].blank?
      organization_ids = params[:organization_ids].split(',')
      organization_ids.each do |organization_id|
        organization = Organization.find(organization_id)
        organization.destroy 
      end
    end
    load_organizations
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @organizations }
      format.js do          
        render :update do |page|
        page.replace_html 'list_organizations',:partial=>'organizations'
        end
      end
    end
   end 


def replace_organizations
		render :update do |page|
	page.replace_html 'list_organizations',:partial=>'organizations'
	end
end

  def search
    if !params[:search_organization].blank?
	@organizations=Organization.paginate(:all,:conditions=>[" (name like '%%"+params[:search_organization].to_s+"%%') or (website like '%%"+params[:search_organization].to_s+"%%')"],:order=>"created_at desc",:page=>params[:page],:per_page=>15)
    else
      load_organizations    
    end
    render :update do |page|
      page.replace_html 'list_organizations',:partial=>'organizations'
    end
  end  


end
