class Admin::ScrapersController < ApplicationController
	before_filter :admin_login_required
  layout 'admin'
	
  # GET /scrapers
  # GET /scrapers.xml
  def index
    @scrapers = Scraper.paginate :page=>params[:page],:per_page=>15,:order=>"created_at desc"
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @scrapers }
    end
  end		
	
	# GET /scrapers/new
  # GET /scrapers/new.xml
  def new
    @scraper = Scraper.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @scraper }
    end
  end	
	
	# POST /scrapers
  # POST /scrapers.xml
  def create
    @scraper = Scraper.new(params[:scraper])
    
    respond_to do |format|
      if @scraper.save
      flash[:notice] = 'Scraper was successfully created.'
      format.html { redirect_to(admin_scrapers_url) }
        format.xml  { render :xml => @scraper, :status => :created, :location => @scraper }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @scraper.errors, :status => :unprocessable_entity }
      end
    end
  end
	
	# GET /scrapers/1/edit
  def edit
    @scraper = Scraper.find(params[:id])
  end
	
	# PUT /specific_content_types/1
  # PUT /specific_content_types/1.xml
  def update
    @scraper = Scraper.find(params[:id])

    respond_to do |format|
      if @scraper.update_attributes(params[:scraper])
        flash[:notice] = 'Scraper was successfully updated.'
        format.html { redirect_to(admin_scrapers_url) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @scraper.errors, :status => :unprocessable_entity }
      end
    end
  end
  
    # DELETE /duty_stations/1
  # DELETE /duty_stations/1.xml
  def destroy
    @scraper = Scraper.find(params[:id])
    @scraper.destroy
    flash[:notice] = "Scraper deleted successfully."
		redirect_to admin_scrapers_path
  end

  def view_xml
    require 'fileutils' 
    @scraper = Scraper.find(params[:id])
    xml_directory_path = "#{RAILS_ROOT}/public/scraping/#{@scraper.id}_#{@scraper.classname}/xml"
    if File.directory?("#{RAILS_ROOT}/public/scraping/#{@scraper.id}_#{@scraper.classname}/xml")
      @xml_files = Dir.entries(xml_directory_path)
      @valid_xml_files = [ ]
      @xml_files.each do |xml_file|
        if xml_file != "." && xml_file != ".."
          @valid_xml_files << xml_file
        end  
      end      
    else
      flash[:error] = "Directory for XML Files Not found for #{@scraper.url}"
      redirect_to admin_scrapers_url
    end
  end
  
  def download_xml    
    @scraper = Scraper.find(params[:id])
    xml_directory_path = "#{RAILS_ROOT}/public/scraping/#{@scraper.id}_#{@scraper.classname}/xml/"
    filepath = xml_directory_path + params[:filename] + ".xml"
    if File.exists? filepath
     send_file filepath
    else
      flash[:notice] = "File not found"
	   redirect_to admin_scrapers_url
    end
  end

  def view_log
    require 'fileutils' 
    @scraper = Scraper.find(params[:id])
    log_directory_path = "#{RAILS_ROOT}/public/scraping/#{@scraper.id}_#{@scraper.classname}/log"
    if File.directory?("#{RAILS_ROOT}/public/scraping/#{@scraper.id}_#{@scraper.classname}/log")
      @log_files = Dir.entries(log_directory_path)
      @valid_log_files = [ ]
      @log_files.each do |log_file|
        if log_file != "." && log_file != ".."
          @valid_log_files << log_file
        end  
      end      
    else
      flash[:error] = "Directory for Log Files Not found for #{@scraper.url}"
      redirect_to admin_scrapers_url
    end
  end
  
  def download_log    
    @scraper = Scraper.find(params[:id])
    log_directory_path = "#{RAILS_ROOT}/public/scraping/#{@scraper.id}_#{@scraper.classname}/log/"
    filepath = log_directory_path + params[:filename] + ".log"
    if File.exists? filepath
     send_file filepath
    else
      flash[:notice] = "File not found"
	   redirect_to admin_scrapers_url
    end
  end
  
  def download_csv   
    @scraper = Scraper.find(params[:id])
    csv_directory_path = "#{RAILS_ROOT}/public/scraping/#{@scraper.id}_#{@scraper.classname}/csv/"
    filepath = csv_directory_path + params[:filename] + ".csv"
    if File.exists? filepath
     send_file filepath
    else
      flash[:notice] = "File not found"
	   redirect_to admin_scrapers_url
    end
  end

  def change_scrapers_status
    if params[:scrapers]
      if params[:commit] == "Activate Selected Scraps"
        params[:scrapers].each do |scraper|
          s = Scraper.find(scraper)
          s.update_attribute(:status,true)
        end  
        flash[:notice] = "Selected Scraper(s) are Activated"
      elsif params[:commit] == "Deactivate Selected Scraps"
        params[:scrapers].each do |scraper|
          s = Scraper.find(scraper)
          s.update_attribute(:status,false)
        end  
        flash[:notice] = "Selected Scraper(s) are Deactivated"
      else
       delete_scrapers        
      end  
      redirect_to admin_scrapers_url
    else  
      flash[:error] = "Select Scraper(s) to Activate/Deactivate/Delete"
      redirect_to admin_scrapers_url
    end  
  end  
  
  def delete_scrapers
    params[:scrapers].each do |scraper|
    s = Scraper.find(scraper)
    s.destroy
    end  
    flash[:notice] = "Selected Scraper(s) are Deleted"
  end 

end
