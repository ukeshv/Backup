class Admin::SettingsController < ApplicationController
	before_filter :admin_login_required
  layout 'admin'
	
	def index
		@setting = Setting.find(:first)
	end

  def update
		@setting = Setting.find(params[:id])
		if @setting.update_attributes(params[:setting])
			render :update do |page|
			end			
		else
			show_hide_error_messages(@setting,'setting')
		end	
	end	


	def show_hide_error_messages(obj,replacing_id)
	  render :update do |page|
	    for h in obj.errors
	      if !obj.errors["#{h[0]}"].nil?
	        page.show "#{h[0]}_" +  replacing_id
	        page.replace_html "#{h[0]}_" + replacing_id, "#{h[1]}"
	      end
	      page.hide "max_invite_"+ replacing_id if obj.errors['max_invite'].nil?
	    end
	  end
	end	

end
