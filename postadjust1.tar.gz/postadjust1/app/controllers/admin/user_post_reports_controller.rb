class Admin::UserPostReportsController < ApplicationController
  before_filter :admin_login_required
  layout 'admin'
	 # GET /user_post_reports
  # GET /user_post_reports.xml
  def index
    redirect_to admin_post_reports_url
  end

  # GET /user_post_reports/1
  # GET /user_post_reports/1.xml
  def show
    @user_post_report = UserPostReport.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @user_post_report }
    end
  end

  # GET /user_post_reports/new
  # GET /user_post_reports/new.xml
  def new
    @user_post_report = UserPostReport.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @user_post_report }
    end
  end

  # GET /user_post_reports/1/edit
  def edit
    @user_post_report = UserPostReport.find(params[:id])
  end

  # POST /user_post_reports
  # POST /user_post_reports.xml
  def create
    @user_post_report = UserPostReport.new(params[:user_post_report])

    respond_to do |format|
      if @user_post_report.save
        flash[:notice] = 'UserPostReport was successfully created.'
        format.html { redirect_to(@user_post_report) }
        format.xml  { render :xml => @user_post_report, :status => :created, :location => @user_post_report }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @user_post_report.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /user_post_reports/1
  # PUT /user_post_reports/1.xml
  def update
    @user_post_report = UserPostReport.find(params[:id])

    respond_to do |format|
      if @user_post_report.update_attributes(params[:user_post_report])
        flash[:notice] = 'UserPostReport was successfully updated.'
        format.html { redirect_to(admin_user_post_reports_url) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @user_post_report.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /user_post_reports/1
  # DELETE /user_post_reports/1.xml
  def destroy
    @user_post_report = UserPostReport.find(params[:id])
    @user_post_report.destroy
    flash[:notice] = "UserPostReport was successfully deleted."
    respond_to do |format|
      format.html { redirect_to(admin_user_post_reports_url) }
      format.xml  { head :ok }
    end
  end
  
  def approve
    user_post_report = UserPostReport.find(params[:id])
    user_post_report.update_attribute(:is_approved,true)
    post_report = PostReport.find_by_duty_station_id(user_post_report.duty_station_id)
    post_report.update_attribute(:content,user_post_report.content)
    flash[:notice] = "UserPostReport was successfully approved"
    respond_to do |format|
      format.html { redirect_to(admin_user_post_reports_url) }
      format.xml  { head :ok }
    end
  end
  
  
end
