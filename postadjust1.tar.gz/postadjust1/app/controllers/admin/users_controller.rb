class Admin::UsersController < ApplicationController
	before_filter :admin_login_required
	layout 'admin'

	
	def index
		@users = User.paginate(:all,:page=>params[:page], :per_page => 15, :order=>"created_at DESC")
		
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @users }
      format.js do
        render :update do |page|
          page.replace_html 'list_users',:partial=>'users'
        end
      end
    end
	end
	
	def edit
		@organizations = Organization.active
		@occupational_groups = OccupationalGroup.active
		@duty_station = DutyStation.active
		@user = User.find(params[:id])
	end
	
	def update
		@organizations = Organization.active
		@occupational_groups = OccupationalGroup.active
		@duty_station = DutyStation.active
		@user = User.find(params[:id])
		 if params[:user][:duty_station_id].to_i != 0
			if @user.update_attributes(params[:user])
				if params[:user_photo][:uploaded_data] != ""
				@user_photo = UserPhoto.new(params[:user_photo])
				if @user_photo.valid?
				@user.user_photo=@user_photo
				else
				render :action=>'edit'
				return
				end
			end
			flash[:notice] = "#{@user.fullname} has been successfully updated"
			redirect_to admin_users_path
			else
			render :action=>'edit'	
		  end
		else
			flash[:duty_station_error] = "Please select duty station"
			render :action => "edit" 
			end
	end
	
	
		def approve
		user = User.find(params[:id])
		user.update_attribute(:status,true)
		flash[:notice] = "Approved the user"
		redirect_to admin_users_path
	end
	
	def reject
		user = User.find(params[:id])
		user.update_attribute(:status,false)
		flash[:notice] = "Rejected the user"
		redirect_to admin_users_path
	end
	
	def activate
		@user = User.find(params[:id])
		@user.activate!
		@user.update_attribute(:max_invite,5)
		flash[:notice] = "User activated successfully."
		redirect_to admin_users_path
	end
	
	def search
    if !params[:search_user].blank?
      @users = User.paginate(:all,:conditions=>["(firstname like '%%"+params[:search_user].to_s+"%%') or (lastname like '%%"+params[:search_user].to_s+"%%')"],:order=>"created_at desc",:page=>params[:page],:per_page=>15)
    end
    render :update do |page|
      page.replace_html 'list_users',:partial=>'users'
    end
  end  
	
	def destroy
		user = User.find(params[:id])
		user.destroy
		flash[:notice] = "User deleted successfully."
		redirect_to admin_users_path
	end
	
	def admin_rights
  	user = User.find(params[:id])
		admin_role = Role.find_by_name('admin')
    user.roles << admin_role
		flash[:notice] = "Successfully added."
		redirect_to admin_users_path
	end	
	
	def remove_admin_rights
		user = User.find(params[:id])
		user.role_ids = [2]
		flash[:notice] = "Successfully deleted."
		redirect_to admin_users_path
	end	
		
end
