class ApplicationController < ActionController::Base
  include ExceptionNotifiable
  include AuthenticatedSystem
  include RoleRequirementSystem

  helper :all # include all helpers, all the time
  protect_from_forgery :secret => 'b0a876313f3f9195e9bd01473bc5cd06'
  filter_parameter_logging :password, :password_confirmation
  rescue_from ActiveRecord::RecordNotFound, :with => :record_not_found
  
  before_filter :is_admin
  before_filter :load_duty_stations,:load_duty_stations_dropdown
  
  def find_max_invitation
    @max_invitations= Setting.find(:first).max_invite
  end
  
  
  # Get duty stations list
  def load_duty_stations
    @active_duty_stations ||= DutyStation.active
  end  
  
  # Get duty stations list as drop down
  def load_duty_stations_dropdown
    @duty_stations = DutyStation.active.to_dropdown
  end
  
  def load_job_duty_stations_dropdown
    @all_duty_stations = DutyStation.to_dropdown
  end  
  
  def is_admin
    if logged_in?
      @is_admin = (current_user.has_role? 'admin') ? true : false
    else
      @is_admin = false
    end
  end  
  
  def admin_login_required
    if logged_in?
      if !(current_user.has_role? 'admin')
        redirect_to '/'
      end
    else
      redirect_to '/'
    end   
  end   
  
  protected
  
  # Automatically respond with 404 for ActiveRecord::RecordNotFound
  def record_not_found
    render :file => File.join(RAILS_ROOT, 'public', '404.html'), :status => 404
  end
end

