class JobsController < ApplicationController
 #layout 'postadjust'
 layout 'postadjustnew'

 before_filter :login_required
 #before_filter :route_user, :except=>[:show]
 before_filter :load_owner,:only=>[:edit]
 before_filter :check_id_exist,:only=>[:show,:edit]
 protect_from_forgery :except=>[:delete_jobs]
  
  def check_id_exist
   j = Job.find_by_id(params[:id])
   if j.nil?
     redirect_to(jobs_path)
   end 
 end
  
  # GET /jobs
  # GET /jobs.xml
  def index
    load_job_duty_stations_dropdown
    @jobs = Job.paginate(:all,:conditions=>['user_id = ?',current_user.id],:page=>params[:page], :per_page => 15,:order=>"created_at DESC")
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @jobs }
    end
     rescue
     redirect_to(jobs_path)
  end

  # GET /jobs/1
  # GET /jobs/1.xml
  def show
    load_job_duty_stations_dropdown
    @job = Job.find(params[:id])
    result = @job.status
    myjob = current_user.jobs.include?(@job)
    if myjob || result 
      
     @organization = Organization.find(:all,:limit=>"3")
       if !@organization.empty?
      tmp_org =[]
      @organization.each do |org| 
        org_count = org.jobs.count(:conditions=>['status = true AND (closing_date > (?) or closing_date is NULL)',Date.today+1])
        tmp_org << org_count
      end
      if tmp_org.uniq.length == 1 && tmp_org[0].to_i == 0
          @org_tmp = true
        end
else        
  @org_tmp = true
      end        
        
      @occupation = OccupationalGroup.find(:all,:limit=>"3")
      if !@occupation.empty?
      tmp_occ =[]
      @occupation.each do |occ| 
        occ_count = occ.jobs.count(:conditions=>['status = true AND (closing_date > (?) or closing_date is NULL)',Date.today+1])
        tmp_occ << occ_count
      end
      if tmp_occ.uniq.length == 1 && tmp_occ[0].to_i == 0
          @occ_tmp = true
        end 
else        
  @occ_tmp = true
      end  
        
      respond_to do |format|
        format.html # show.html.erb
        format.xml  { render :xml => @job }
      end
    elsif !myjob && !result
      @organization = Organization.find(:all,:limit=>"3")
      @occupation = OccupationalGroup.find(:all,:limit=>"3")
      respond_to do |format|
        format.html { redirect_to(jobs_path) }
        format.xml  { render :xml => @job }
      end
   end  
  end

  # GET /jobs/new
  # GET /jobs/new.xml
  def new
	load_organizations 
	load_occupational_groups	
	load_duty_stations_dropdown
	load_job_duty_stations_dropdown
	load_grades
  
    @job = Job.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @job }
    end
  end

  # GET /jobs/1/edit
  def edit
  load_organizations 
	load_occupational_groups	
	load_duty_stations_dropdown
	load_job_duty_stations_dropdown
	load_grades
    @job = Job.find(params[:id])
  end

  # POST /jobs
  # POST /jobs.xml
  def create
	load_organizations 
	load_occupational_groups
	load_duty_stations_dropdown
	load_job_duty_stations_dropdown
	load_grades
    @job = Job.new(params[:job])
    @job.user_id = current_user.id
    @job.closing_date = params[:closing_date]
		@job.status = true
    respond_to do |format|
        if params[:job_upload][:uploaded_data] != ""
        @job_upload = JobUpload.new(params[:job_upload])
          if @job_upload.valid?
          @job.job_upload=@job_upload
          else
          render :action=>'new'
          return
          end
        end
      if @job.save
        flash[:notice] = 'Job was successfully created.'
        format.html { redirect_to(jobs_path) }
        format.xml  { render :xml => @job, :status => :created, :location => @job }
      else
        flash.now[:error] = "Some information was missing. Please see below for details."
        format.html { render :action => "new" }
        format.xml  { render :xml => @job.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /jobs/1
  # PUT /jobs/1.xml
  def update
  load_organizations 
	load_occupational_groups
	load_duty_stations_dropdown
	load_job_duty_stations_dropdown
	load_grades
    @job = Job.find(params[:id])
    respond_to do |format|
       if params[:job_upload][:uploaded_data] != ""
        @job_upload = JobUpload.new(params[:job_upload])
          if @job_upload.valid?
          @job.job_upload=@job_upload
          else
          render :action=>'edit'
          return
          end
        end
      if @job.update_attributes(params[:job])
        @job.update_attribute(:closing_date,params[:closing_date])
        flash[:notice] = 'Job was successfully updated.'
        format.html { redirect_to(jobs_path) }
        format.xml  { head :ok }
      else
        flash.now[:error] = "Some information was missing. Please see below for details."
        format.html { render :action => "edit" }
        format.xml  { render :xml => @job.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /jobs/1
  # DELETE /jobs/1.xml
  def destroy
    @job = Job.find(params[:id])
    @job.destroy

    respond_to do |format|
      flash[:notice] = 'Job was successfully deleted.'
      format.html { redirect_to(jobs_path) }
      format.xml  { head :ok }
    end
  end
  
  def delete_jobs
    if !params[:job_ids].blank?
      job_ids = params[:job_ids].split(',')
      job_ids.each do |job_id|
        job = Job.find(job_id)
        job.destroy 
        flash[:notice] = "Selected job(s) are deleted"
      end
    end
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @jobs }
      format.js do          
        render :update do |page|
        page.redirect_to jobs_path
        end
      end
    end
  end

  def download    
    job = Job.find(params[:id])
    f = job.job_upload
    filepath = f.full_filename
    if File.exists? filepath
     send_file filepath
    else
	   redirect_to jobs_path
    end
  end
  
  def load_organizations
	  @organizations = Organization.active
  end
  
  def load_occupational_groups
	  @occupational_groups = OccupationalGroup.active
 end
  
 def load_grades
	@grades = Grade.active
  end

  def load_owner
    if Job.exists?(params[:id])
      @job = Job.find(params[:id])
      result = current_user.jobs.include?(@job)
      if !result   
        redirect_to jobs_path
      end
    else
        redirect_to jobs_path
    end
  end
  
  def route_user
    unless is_admin      
      redirect_to search_jobs_path
    end
  end

end
