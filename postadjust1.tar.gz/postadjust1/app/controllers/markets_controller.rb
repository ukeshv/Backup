class MarketsController < ApplicationController
   layout 'postadjustnew',:except=>[:list_photos]

   before_filter :login_required
   before_filter :load_owner,:only=>[:edit]
   before_filter :check_id_exist,:only=>[:show,:edit]
   protect_from_forgery :except=>[:delete_markets,:list_photos,:photo_upload]
   
   
 def check_id_exist
   m = Market.find_by_id(params[:id])
   if m.nil?
     redirect_to(markets_path)
   end 
 end
 

  # GET /markets
  # GET /markets.xml
  def index
    load_categories
    @markets = Market.paginate(:all,:conditions=>['user_id = ?',current_user.id],:page=>params[:page], :per_page => 15, :order=>"created_at DESC")
    
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @markets }
    end
    rescue
    redirect_to(markets_path)
  end

  # GET /markets/1
  # GET /markets/1.xml
  def show
    load_categories
    @market = Market.find(params[:id])
    result = @market.status
    @ad_photos = @market.market_uploads
		if params[:image_id]
    attaching = @market.market_uploads.find(params[:image_id]) if params[:image_id]
    if File.exists? RAILS_ROOT + "/public#{attaching.public_filename(:large)}"
    @latest_ad_photo = attaching.public_filename(:large)
    else
     @latest_ad_photo = "/images/ad.jpg"
    end  
		#@latest_ad_photo = (params[:image_id].nil? ? (@market.attachings.last ? @market.attachings.last.asset.url(:thumb) : '') : attaching.asset.url(:thumb))
		else 
    @latest_ad_photo = @market.first_large_image_size
		end
    myad = current_user.markets.include?(@market)
    if myad || result 
      respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @market }
      format.js do
        render :update do |page|
          page.replace_html 'picture_ad', :partial=>'ad_picture'
        end  
      end
      end
   elsif !myad && !result
      respond_to do |format|
      format.html { redirect_to(markets_path) }
      format.xml  { render :xml => @market }
      end
    end  
  end

  # GET /markets/new
  # GET /markets/new.xml
  def new
    load_categories
    @market = Market.new
    @market.email = current_user.email
    @market.phone = current_user.phone
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @market }
    end
  end

  # GET /markets/1/edit
  def edit
    load_categories
    @market = Market.find(params[:id])
  end

  # POST /markets
  # POST /markets.xml
  def create
   @error_msg=[]
		load_categories
		@market = Market.new(params[:market])
		@market.user_id = current_user.id
		@market.price = 0.0 if @market.currency_format == "Free"
		respond_to do |format|
		(0..10).each{|x| 
    if params['files_list_'+x.to_s] && params['files_list_'+x.to_s] != ""
    p = Hash["image"=>{"uploaded_data"=>""}]
    p["image"]["uploaded_data"] = params["files_list_"+x.to_s]
    image = MarketUpload.new(p["image"])

    if image.valid?
      @market.market_uploads << image
    else
      @error_msg<<"Image or video files can only be in .jpg, .gif ,.png, .flv, .mpg, or .mpeg format" if image.errors['content_type'] && image.errors['content_type'].length > 0
      @error_msg<<"Image size can be upto 500 MB only" if image.errors['size'] && image.errors['size'].length > 0
    end
    end
    x+=1
	}
			if @market.save
				flash[:notice] = 'Advertisement was successfully created.'
				format.html { redirect_to(markets_path) }
				format.xml  { render :xml => @market, :status => :created, :location => @market }
			else
				flash.now[:error] = "Some information was missing. Please see below for details."
				format.html { render :action => "new" }
				format.xml  { render :xml => @market.errors, :status => :unprocessable_entity }
			end
			end
  end

  # PUT /markets/1
  # PUT /markets/1.xml
  def update
   @error_msg=[]
    load_categories
    @market = Market.find(params[:id])
     if params[:data]
    p = Hash["image"=>{"uploaded_data"=>""}]
    p["image"]["uploaded_data"] = params[:data]
    image = MarketUpload.new(p["image"])
       image = MarketUpload.new(p["image"])
     @market.market_uploads << image
      flash[:notice] = "Your photo has been successfully updated."
      redirect_to market_path(@market)
    else  
        respond_to do |format|
        (0..10).each{|x| 
        if params['files_list_'+x.to_s] && params['files_list_'+x.to_s] != ""
          p = Hash["image"=>{"uploaded_data"=>""}]
          p["image"]["uploaded_data"] = params["files_list_"+x.to_s]
          image = MarketUpload.new(p["image"])

          if image.valid?
            @market.market_uploads << image
          else
            @error_msg<<"Image or video files can only be in .jpg, .gif ,.png, .flv, .mpg, or .mpeg format" if image.errors['content_type'] && image.errors['content_type'].length > 0
            @error_msg<<"Image size can be upto 500 MB only" if image.errors['size'] && image.errors['size'].length > 0
          end
        end
        x+=1
        }
        if @market.update_attributes(params[:market])
           @market.update_attribute(:price,0.0) if @market.currency_format == "Free"
          flash[:notice] = 'Advertisement was successfully updated.'
          format.html { redirect_to(@market) }
          format.xml  { head :ok }
        else
          flash.now[:error] = "Some information was missing. Please see below for details."
          format.html { render :action => "edit" }
          format.xml  { render :xml => @market.errors, :status => :unprocessable_entity }
        end
      end
     end 
  end

  # DELETE /markets/1
  # DELETE /markets/1.xml
  def destroy
    @market = Market.find(params[:id])
    @market.destroy

    respond_to do |format|
      flash[:notice] = 'Advertisement was successfully deleted'
      format.html { redirect_to(markets_url) }
      format.xml  { head :ok }
    end
  end
  
  def delete_markets
    if !params[:market_ids].blank?
      market_ids = params[:market_ids].split(',')
      market_ids.each do |market_id|
        market = Market.find(market_id)
        market.destroy 
        flash[:notice] = "Selected Ad(s) are deleted"
      end
    end
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @markets }
      format.js do          
        render :update do |page|
        page.redirect_to markets_path
        end
      end
    end
   end 
  
  
  def load_categories
	  @categories = Category.active
  end
  
  def load_owner
    if Market.exists?(params[:id])
      @market = Market.find(params[:id])
      result = current_user.markets.include?(@market)
      if !result   
        redirect_to markets_path
      end
    else
        redirect_to markets_path
    end
  end
  
  def list_photos
    @market = Market.find(params[:id])
    @market_attachings = @market.market_uploads
  end
  
  def active_media
    if !params[:market_upload].nil?
    @market = Market.find(params[:id])
		@media = @market.market_uploads.find(:first,:conditions=>["id = ? and parent_id = ?",params[:market_upload][:parent_id],params[:id]])    
    prev_primary_attaching = @market.market_uploads.find_by_is_primary(true)
    prev_primary_attaching.update_attributes(:is_primary=>false) if !prev_primary_attaching.nil?    
		@media.update_attributes(:is_primary => true)  if @media
		flash[:notice] = 'Media activated successfully.'
    render :update do |page|
      page.redirect_to(markets_path)
    end  
    else
      render :update do |page|
        page[:active_error].innerHTML = "<font color='red'>Select Image to be set as Main picture</font>"
      end  
    end 
    end
  
  def remove_photo
    m = Market.find(params[:market_id])
    m.market_uploads.find_by_parent_id_and_parent_type_and_id(m.id,'Market',params[:id]).destroy
    flash[:notice] = "Successfully Deleted."
    redirect_to markets_path
  end
  
  
  def active_market_media(id)
    market = Market.find(id)
    if (market.attachings && market.attachings.find_by_is_primary(true))
    market_media = market.attachings.find_by_is_primary(true)
    media = market_media.asset.url(:thumb)
    elsif !market.attachings.empty?
    media = market.attachings.last.asset.url(:thumb)
		else
		media = "/images/ad.jpg"	
    end 
    return media
  end 
    
end
