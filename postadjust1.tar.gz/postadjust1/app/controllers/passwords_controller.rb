class PasswordsController < ApplicationController  
  #layout 'postadjust'
  layout 'postadjustnew'
  
  def new
    redirect_back_or_default(users_path) if logged_in?
    @password = Password.new
  end

  def create
    @password = Password.new(params[:password])
    @password.user = User.find_by_email(@password.email)
    if !params[:password][:email].empty?
      if @password.user
          if @password.user.activation_code.nil?    
                if @password.save
                    PasswordMailer.deliver_forgot_password(@password)
                    flash[:notice] = "A link to change your password has been sent to #{@password.email}."
                    redirect_to :action => :new
                else
                    flash.now[:error] = "Could not find a member with this email address."
                    render :action => :new
                end
          else
              flash.now[:error] = "Your Account is not activated. Please activate your account."
              render :action => :new
            end
      else
        flash.now[:error] = "Couldn't find user with this email address"
        render :action => :new
      end 
    else
        flash.now[:error] = "Provide Email Address"
        render :action => :new
    end
  end
  
  
  def reset
    begin
      @user = Password.find(:first, :conditions => ['reset_code = ? and expiration_date > ?', params[:reset_code], Time.now]).user
    rescue
      flash[:notice] = 'The change password URL you visited is either invalid or expired.'
      redirect_to new_password_path
    end    
  end

  def update_after_forgetting
  if params[:user][:password].blank?
       flash[:error] = "Password field cannot be blank."
       redirect_to :action => :reset, :reset_code => params[:reset_code]
       return
     end
    @user = Password.find_by_reset_code(params[:reset_code]).user
    
    if @user.update_attributes(params[:user])
      PasswordMailer.deliver_reset_password(@user)
      flash[:notice] = 'Password was successfully updated.'
      redirect_to login_path
    else
      flash[:error] = 'Password mismatch.'
      redirect_to :action => :reset, :reset_code => params[:reset_code]
    end
  end
  
  def update
    @password = Password.find(params[:id])

    if @password.update_attributes(params[:password])
      flash[:notice] = 'Password was successfully updated.'
      redirect_to(@password)
    else
      render :action => :edit
    end
  end
end
