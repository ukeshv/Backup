class PostReportsController < ApplicationController
	   #layout 'postadjust'
		 layout 'postadjustnew'

  before_filter :login_required
	before_filter :check_id_exist,:only=>[:show,:edit,:revision,:edit_revision]
	 
	def check_id_exist
		duty_station_id = ( params[:duty_station_id].nil? ? params[:id] : params[:duty_station_id] ) 
		if (params[:action] == "revision" || params[:action] == "edit_revision")
    pr = PostReport.find_by_id(duty_station_id)			
		else
		pr = PostReport.find_by_duty_station_id(duty_station_id)
		end	
		if pr.nil?
		redirect_to(users_path)
		end        
	end

 def new
	 redirect_to post_report_path(session[:current_duty_station_id])
 end
 

	def index
		session[:current_duty_station_id] = ( (params[:duty_station_id].to_i ==0) ? session[:current_duty_station_id] : params[:duty_station_id] )
		@station = DutyStation.find(session[:current_duty_station_id])
		@post_reports = PostReport.paginate :conditions=>['duty_station_id = ?',@station.id], :page => params[:page],  :per_page => 15,:order=>"created_at desc"
	end
		
	def show
		session[:current_duty_station_id] = ( params[:duty_station_id].nil? ? params[:id] : params[:duty_station_id] ) 
		@post_report = PostReport.find(:last,:conditions=>['duty_station_id = ?',session[:current_duty_station_id]]) 
	end

	def edit
		session[:current_duty_station_id] = ( params[:duty_station_id].nil? ? params[:id]	 : params[:duty_station_id] ) 
		@post_report = PostReport.find(:last,:conditions=>['duty_station_id = ?',session[:current_duty_station_id]])
	end

	def update
		station_id = params[:id]
		usr_id = current_user.id
		@post_report = PostReport.create(:user_id=>usr_id,:duty_station_id=>station_id,:content=>params[:content])
		flash[:notice] = "Successfully updated."
		redirect_to post_report_path(station_id)
	end
	
	def revision
		@post_report = PostReport.find(params[:id])
	end	
	
	def edit_revision
		@post_report = PostReport.find(params[:id])
	end
	
	def update_revision
		station_id = params[:id]
		usr_id = current_user.id
		@post_report = PostReport.create(:user_id=>usr_id,:duty_station_id=>station_id,:content=>params[:content],:reason=>params[:reason])
		flash[:notice] = "Successfully updated."
		redirect_to post_report_path(station_id)
	end
	
	
	
end
