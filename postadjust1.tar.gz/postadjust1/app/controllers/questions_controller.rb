class QuestionsController < ApplicationController
	#layout 'postadjust',:except=>[:comment,:map,:view_map_location,:comment_view_map_location]
	layout 'postadjustnew',:except=>[:comment,:map,:view_map_location,:comment_view_map_location]
  
  before_filter :check_id_exist,:only=>[:show]
	protect_from_forgery :except=>[:delete_questions,:comment,:map,:view_map_location,:comment_view_map_location]
  
  def check_id_exist
   q = Question.find_by_id(params[:id])
   if q.nil?
     redirect_to(questions_path) 
   end 
 end
 
 def rss
   	session[:current_duty_station_id] = ( params[:duty_station_id].nil? ? session[:current_duty_station_id] : params[:duty_station_id])
	
		@query = [ ] 
		@question_ids = [ ]
		@query << "(question_type LIKE '%%#{params[:search_description]}%%' OR description LIKE '%%#{params[:search_description]}%%') and (duty_station_id = '#{session[:current_duty_station_id]}')" if params[:search_description] and !params[:search_description].empty? 
		@query << "duty_station_id = #{session[:current_duty_station_id]}" if !params[:search_description] or params[:search_description].blank?
		@search_query = @query.join(" OR ")
		@question_ids << Question.find(:all,:conditions=>[@search_query]).collect{|x| x.id}

		
		@question_ids << Comment.find(:all,:conditions=>["comment LIKE '%%#{params[:search_description]}%%'"]) .collect{|x| x.commentable_id} if params[:search_description] and !params[:search_description].empty?
		@question_ids = @question_ids.flatten
		@questions = Question.paginate(:all,:conditions=>['id in (?)',@question_ids],:order=>'created_at desc', :page => params[:page],  :per_page => 20) 
		@user_postreport_results = PostReport.find(:all,:conditions=>["content LIKE '%%#{params[:search_description]}%%' and (duty_station_id = '#{session[:current_duty_station_id]}')"]) if params[:search_description] and !params[:search_description].empty? 
    render :layout=>false
 end
 

  # GET /questions
  # GET /questions.xml
  def index
     session[:current_duty_station_id] = ( params[:duty_station_id].nil? ? session[:current_duty_station_id] : params[:duty_station_id] )
     sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort]
    @questions = Question.paginate :conditions=>['user_id = ? and duty_station_id=?',current_user.id,session[:current_duty_station_id]], :page => params[:page],  :per_page => 15,:order=>"#{sort_field}"

   respond_to do |format|
     format.html # index.html.erb
	format.xml  { render :xml => @questions }
         end
  rescue
  redirect_to(questions_path) 
  end

  # GET /questions/1
  # GET /questions/1.xml
  def show
   @questions  = Question.find(params[:id])
   @comments = @questions.comments.paginate :order=>'created_at desc', :page => params[:page],  :per_page => 15
    
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @questions }
    end
    rescue
    redirect_to(question_path)
  end

  # GET /questions/new
  # GET /questions/new.xml
  def new
    @questions = Question.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @questions }
    end
  end

  # GET /questions/1/edit
  def edit
    #@questions = Question.find(params[:id])
    redirect_to questions_path
  end

  # POST /questions
  # POST /questions.xml
  def create
   session[:current_duty_station_id] = ( params[:duty_station_id].nil? ? session[:current_duty_station_id] : params[:duty_station_id] )
    @question = Question.new(params[:question])
    respond_to do |format|
      @question.user_id = current_user.id
      @question.duty_station_id = session[:current_duty_station_id]
      if @question.save
        flash[:notice] = 'Question was successfully created.'
        format.html { redirect_to(questions_path) }
        format.xml  { render :xml => @question, :status => :created, :location => @question }
	format.js do
		render :update  do |page|
			page.redirect_to dashboard_path
		end
	end
      end
    end
  end

  # PUT /questions/1
  # PUT /questions/1.xml
  def update
    @questions = Question.find(params[:id])

    respond_to do |format|
      if @questions.update_attributes(params[:questions])
        flash[:notice] = 'Question was successfully updated.'
        format.html { redirect_to(@questions) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @questions.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  def dashboard
	session[:current_duty_station_id] = ( params[:duty_station_id].nil? ? session[:current_duty_station_id] : params[:duty_station_id])
	
		@query = [ ] 
		@question_ids = [ ]
		@query << "(question_type LIKE '%%#{params[:search_description]}%%' OR description LIKE '%%#{params[:search_description]}%%') and (duty_station_id = '#{session[:current_duty_station_id]}')" if params[:search_description] and !params[:search_description].empty? 
		@query << "duty_station_id = #{session[:current_duty_station_id]}" if !params[:search_description] or params[:search_description].blank?
		@search_query = @query.join(" OR ")
		@question_ids << Question.find(:all,:conditions=>[@search_query]).collect{|x| x.id}

		
		@question_ids << Comment.find(:all,:conditions=>["comment LIKE '%%#{params[:search_description]}%%'"]) .collect{|x| x.commentable_id} if params[:search_description] and !params[:search_description].empty?
		@question_ids = @question_ids.flatten
		@questions = Question.paginate(:all,:conditions=>['id in (?)',@question_ids],:order=>'created_at desc', :page => params[:page],  :per_page => 20) 
		@user_postreport_results = PostReport.find(:all,:conditions=>["content LIKE '%%#{params[:search_description]}%%' and (duty_station_id = '#{session[:current_duty_station_id]}')"]) if params[:search_description] and !params[:search_description].empty? 
		 respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @questions }
    end
  end
  

  # DELETE /questions/1
  # DELETE /questions/1.xml
  def destroy
    @questions = Question.find(params[:id])
    @questions.destroy

    respond_to do |format|
      format.html { redirect_to(questions_url) }
      format.xml  { head :ok }
    end
  end
  
    def delete_questions
    if !params[:question_ids].blank?
      question_ids = params[:question_ids].split(',')
      question_ids.each do |question_id|
        question = Question.find(question_id)
        question.destroy 
	flash[:notice]="Selected question(s) are successfully deleted"
      end
    end
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @questions }
      format.js do          
        render :update do |page|
        page.redirect_to questions_path
        end
      end
    end
   end 
   
   def add_comments
	@questions= Question.find(params[:id])
        @comments = @questions.comments.paginate :order=>'created_at desc', :page => params[:page],  :per_page => 4
	respond_to do |format|
		unless params[:comment][:text].empty? 
		 @comment = Comment.new
		 @comment.comment = params[:comment][:text]
		 @comment.user_id = current_user.id
		 @comment.is_anonymous = params[:comment][:is_anonymous]
		 @comment.latitude = params[:comment][:latitude]
		 @comment.longitude = params[:comment][:longitude]
		 @questions.comments << @comment 
		 @questions.save
			format.xml  { render :xml => @questions }
			format.js do
				render :update  do |page|
					page.hide "comment_error"
					page.redirect_to dashboard_path
				end
			end
		else
			format.js do
				render :update  do |page|
				page.show "comment_error"
				end
			end
		end
	end
  end

  def comment
	   @questions  = Question.find(params[:id])
   end
   
   def map
   end
   
   def view_map_location
   end
      
   
end
