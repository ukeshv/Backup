class Search::JobsController < ApplicationController
	#layout 'postadjust'
	layout 'postadjustnew'
	#protect_from_forgery :except=>[:index]
	before_filter :login_required
	
	def rss
		session[:link_enable] = "title"
		session[:link_enable] = (params[:link].nil? ? session[:link_enable] : params[:link])
		session[:job_current_duty_station_id] = ( params[:station].blank? ? session[:current_duty_station_id] : params[:station] )
		@page = session[:link_enable] == "title" ? "25" : "10"
   	params.delete_if {|key, value| value.nil? || value.empty?}
		@param_hash=params.reject{|key, value| key == "range"}
		@params_length=@param_hash.length == 2 ? true : false
		
		@organizations = Organization.active	
		@occupational_groups = OccupationalGroup.active	
		@grades = Grade.active	
		
		load_refine_organizations
		load_refine_occupational_groups
		load_refine_grades
		load_duty_stations_dropdown
		load_job_duty_stations_dropdown
		@duty_station_jobs = Job.find(:all,:conditions=>['duty_station_id = ? and status = ? and (closing_date > (?) or closing_date is NULL)',session[:job_current_duty_station_id],true,Date.today+1],:limit=>3,:order=>'created_at desc')
		
		@jobs = [ ]
		@job_id = [ ]
		
		@refine_condition_string = [ ]

		if !@params_length
			search
			refine_search if !params[:rgrade].blank? || !params[:rorg].blank? || !params[:rocc].blank?
		end
   render :layout=>false
	end
	

	def index
		session[:link_enable] = "title"
		session[:link_enable] = (params[:link].nil? ? session[:link_enable] : params[:link])
		session[:job_current_duty_station_id] = ( params[:station].blank? ? session[:current_duty_station_id] : params[:station] )
		@page = session[:link_enable] == "title" ? "25" : "10"
   	params.delete_if {|key, value| value.nil? || value.empty?}
		@param_hash=params.reject{|key, value| key == "range"}
		@params_length=@param_hash.length == 2 ? true : false
		
		@organizations = Organization.active	
		@occupational_groups = OccupationalGroup.active	
		@grades = Grade.active	
		
		load_refine_organizations
		load_refine_occupational_groups
		load_refine_grades
		load_duty_stations_dropdown
		load_job_duty_stations_dropdown
		@duty_station_jobs = Job.find(:all,:conditions=>['duty_station_id = ? and status = ? and (closing_date > (?) or closing_date is NULL)',session[:job_current_duty_station_id],true,Date.today+1],:limit=>3,:order=>'created_at desc')
		
		@jobs = [ ]
		#@job_id = [ ]
		
		@refine_condition_string = [ ]
		@search_string = [ ]

		if !@params_length
			search
			refine_search if !params[:rgrade].blank? || !params[:rorg].blank? || !params[:rocc].blank?
		end

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @jobs }
    end
	end	
	
	def search	 
		 condition_string
		 #~ if !params[:station].blank? 
			 #~ @jobs = Job.paginate :conditions=>["id in (?) and status = true and duty_station_id = ? and (closing_date > (?) or closing_date is NULL)",@job_id,params[:station],Date.today+1],:order=>"created_at DESC", :per_page => @page,:page=>params[:page]
		#~ else	 
		 #~ @jobs = Job.paginate :conditions=>["id in (?) and status = true and (closing_date > (?) or closing_date is NULL)",@job_id,Date.today+1],:order=>"created_at DESC", :per_page => @page,:page=>params[:page]
		#~ end 
	end	
	
	def refine_search
		@refine_condition_string << "duty_station_id = #{params[:station]}" if !params[:station].blank?
		@refine_condition_string << "grade_id = #{params[:rgrade]}" if !params[:rgrade].blank?
		@refine_condition_string << "organization_id = #{params[:rorg]}" if !params[:rorg].blank?
		@refine_condition_string << "occupational_group_id = #{params[:rocc]}" if !params[:rocc].blank?
		@refine_condition_string << "status = true"
		@refine_search_query = @refine_condition_string.join(" AND ")
		@all_jobs = Job.find :all, :conditions=>["#{@refine_search_query} and (closing_date > (?) or closing_date is NULL)",Date.today+1],:order=>"created_at DESC"
		@jobs = @all_jobs.paginate :per_page => @page,:page=>params[:page]
	end	

	def condition_string
		@search_string << "organization_id = #{params[:org]}" if !params[:org].blank?
		@search_string << "occupational_group_id = #{params[:occ]}" if !params[:occ].blank?
		@search_string << "grade_id = #{params[:grade]}" if !params[:grade].blank?
		@search_string << "duty_station_id = #{params[:search_station]}" if !params[:search_station].blank?
		@search_string << "duty_station_id =#{params[:station]}" if !params[:station].blank?
		@search_string << "jobs.status = true"
		@search_string << "((title LIKE '%%#{params[:q]}%%') or (description LIKE '%%#{params[:q]}%%') or  (organizations.name LIKE '%%#{params[:q]}%%') or (occupational_groups.name LIKE '%%#{params[:q]}%%') or (duty_stations.name LIKE '%%#{params[:q]}%%') or (grades.name LIKE '%%#{params[:q]}%%'))"  if !params[:q].blank?
		@search_query = @search_string.join(" AND ")
		@all_jobs = Job.find :all, :conditions=>["#{@search_query} and (closing_date > (?) or closing_date is NULL)",Date.today+1],:include=>[:organization,:occupational_group,:duty_station,:grade],:order=>"jobs.created_at DESC"
		@jobs = @all_jobs.paginate :per_page => @page,:page=>params[:page]
	end
	
	def load_refine_organizations
		if !params[:org].blank?
	  @refine_organizations = Organization.find(:all,:conditions=>['status = true and id NOT IN (?)',params[:org]],:limit=>3)
		else
		@refine_organizations = Organization.find(:all,:conditions=>['status = true'],:limit=>3)	
	  end	
  end
  
  def load_refine_occupational_groups
		if !params[:occ].blank?
	  @refine_occupational_groups = OccupationalGroup.find(:all,:conditions=>['status = true and id NOT IN (?)',params[:occ]],:limit=>3) 
		else
	  @refine_occupational_groups = OccupationalGroup.find(:all,:conditions=>['status = true'],:limit=>3)
		end
 end

  def load_refine_grades
		if !params[:grade].blank?
	  @refine_grades = Grade.find(:all,:conditions=>['status = true and id NOT IN (?)',params[:grade]],:limit=>3) 
		else
	  @refine_grades = Grade.find(:all,:conditions=>['status = true'],:limit=>3)
		end
 end

end
