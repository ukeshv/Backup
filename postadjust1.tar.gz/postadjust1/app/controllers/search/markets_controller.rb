class Search::MarketsController < ApplicationController
	#layout 'postadjust'
	layout :change_layout
	
	before_filter :login_required
	
	def change_layout
    (action_name=="index") ? "postadjustnew" : "postadjust"
  end
	
	def rss
		load_categories
		session[:current_duty_station_id] = ( (params[:duty_station_id].to_i ==0) ? session[:current_duty_station_id] : params[:duty_station_id] )  
		session[:current_ads_type] = session[:current_ads_type].nil? ? 'All' : session[:current_ads_type]
		session[:current_ads_type] = ( params[:ads_type].nil? ? session[:current_ads_type] : params[:ads_type] ) 
		@cat_txt = Category.find(params[:category_id]) if !params[:category_id].blank?
		@station_txt = (params[:duty_station_id].to_i ==0) ? 'All' :  DutyStation.find(params[:duty_station_id].to_i).station_with_country_code
		sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort] 
		if params[:q] 
			condition_str 
		elsif session[:current_ads_type] == "All" or !session[:current_ads_type]
			@ads = Market.paginate :conditions=>['duty_station_id = ? and status = true', session[:current_duty_station_id]],:order=>"#{sort_field}", :per_page => 10,:page=>params[:page]
			else
			@ads = Market.paginate :conditions=>['duty_station_id = ? and ads_type = ? and status = true', session[:current_duty_station_id],session[:current_ads_type]],:order=>"#{sort_field}", :per_page => 10,:page=>params[:page]
		end
		render :layout=>false
	end
	
	
	def index
		load_categories
		session[:current_duty_station_id] = ( (params[:duty_station_id].to_i ==0) ? session[:current_duty_station_id] : params[:duty_station_id] )  
		session[:current_ads_type] = session[:current_ads_type].nil? ? 'All' : session[:current_ads_type]
		session[:current_ads_type] = ( params[:ads_type].nil? ? session[:current_ads_type] : params[:ads_type] ) 
		@cat_txt = Category.find(params[:category_id]) if !params[:category_id].blank?
		@station_txt = (params[:duty_station_id].to_i ==0) ? 'All' :  DutyStation.find(params[:duty_station_id].to_i).station_with_country_code
		sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort] 
		if params[:q] 
			condition_str 
		elsif session[:current_ads_type] == "All" or !session[:current_ads_type]
			@ads = Market.paginate :conditions=>['duty_station_id = ? and status = true', session[:current_duty_station_id]],:order=>"#{sort_field}", :per_page => 10,:page=>params[:page]
			else
			@ads = Market.paginate :conditions=>['duty_station_id = ? and ads_type = ? and status = true', session[:current_duty_station_id],session[:current_ads_type]],:order=>"#{sort_field}", :per_page => 10,:page=>params[:page]
		end
		respond_to do |format|
        format.html # show.html.erb
        format.xml  { render :xml => @ads }
      end
	end
	
	def condition_str
		  sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort] 
			str_arry = []
			str_arry << "(title LIKE '%%#{params[:q]}%%' or description LIKE '%%#{params[:q]}%%')" if params[:q] and !params[:q].empty? 
			str_arry << "(category_id=#{params[:category_id]})" if params[:category_id] and params[:category_id].to_i > 0
			str_arry << "(duty_station_id=#{params[:duty_station_id]})" if params[:duty_station_id] and params[:duty_station_id].to_i > 0
			str_arry << "(ads_type LIKE '%%#{session[:current_ads_type]}%%')" unless session[:current_ads_type] == "All"
			str_arry << "(status = true)"
			str = str_arry.join(' and ') if str_arry.length > 0
			@ads = Market.paginate :conditions=> str,:order=>"#{sort_field}", :per_page => 10,:page=>params[:page] if str
	end
	
	def load_categories
	  @categories = Category.active
  end
	
end
