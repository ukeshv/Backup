class Search::PeopleController < ApplicationController
	#layout 'postadjust'
	layout 'postadjustnew'
	
  def index
	session[:current_duty_station_id] = ( params[:duty_station_id].blank? ? session[:current_duty_station_id] : params[:duty_station_id] )
	@organizations = Organization.active	
	@occupational_groups = OccupationalGroup.active	
	@users = [ ]
	@adv_query = [ ]
	
	organization_list
	
	if params[:q] and  !params[:q].empty? 
	@users = User.paginate(:all,:conditions=>["(firstname LIKE '%%#{params[:q]}%%' or lastname LIKE '%%#{params[:q]}%%') and (duty_station_id = #{session[:current_duty_station_id]}) and (activated_at!='nil')" ],:order=>'created_at desc', :page => params[:page],  :per_page => 15)
	elsif params[:adv_search_text]
	advanced_search 
	elsif params[:org_id]
	@users = User.paginate(:all,:conditions=>["organization_id =? and (duty_station_id = #{session[:current_duty_station_id]}) and (activated_at!='nil')",params[:org_id]],:order=>'created_at desc', :page => params[:page],  :per_page => 15)
	else
	@users = User.paginate(:all,:conditions=>["duty_station_id = ? and (activated_at!='nil')",session[:current_duty_station_id]],:order=>'created_at desc', :page => params[:page],  :per_page => 15)
	end
 end


  def advanced_search
		@adv_query << "(firstname LIKE '%%#{params[:adv_search_text]}%%' or lastname LIKE '%%#{params[:adv_search_text]}%%')" if !params[:adv_search_text].blank?
		@adv_query << "activated_at!='nil'"
		@adv_query << "organization_id = #{params[:org]}"if !params[:org].blank?
		@adv_query << "occupational_group_id = #{params[:occ]}" if !params[:occ].blank?
		@adv_query << "duty_station_id = #{params[:duty_station_id]}" if !params[:duty_station_id].blank?
		@adv_query << "nationality = '#{params[:user][:nationality]}'" if !params[:user][:nationality].blank?
		@search_query = @adv_query.join(" AND ")
		@users= User.paginate(:all,:conditions=>[@search_query],:order=>'created_at desc', :page => params[:page],  :per_page => 15)
		organization_list
	end
	
	def organization_list
		@users_org = User.find(:all,:conditions=>["duty_station_id = ? and activated_at!='nil'",session[:current_duty_station_id] ]).collect{|x| x.organization_id}.uniq
		@orgs = Organization.find(:all,:conditions=>['id IN (?)',@users_org])
	end


end
