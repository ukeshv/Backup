class SessionsController < ApplicationController
  skip_before_filter :verify_authenticity_token, :only => :create
  #layout 'postadjust'
  layout 'postadjustnew'
  
  def index
    redirect_back_or_default(users_path) if logged_in?
  end  
  
  def new
    redirect_back_or_default(users_path) if logged_in?
  end

  def create
    logout_keeping_session!
    if using_open_id?
      open_id_authentication
    else
      password_authentication
    end
  end

  def destroy
    logout_killing_session!
    flash[:notice] = "You have been logged out."
    redirect_back_or_default(root_path)
  end
  
  def open_id_authentication
    authenticate_with_open_id do |result, identity_url|
      if result.successful? && self.current_user = User.find_by_identity_url(identity_url)
        successful_login
      else
        flash[:error] = result.message || "Sorry no user with that identity URL exists"
        @remember_me = params[:remember_me]
        render :action => :new
      end
    end
  end
  
  def supported_organizations
    #~ @b={}    
    #~ ("A".."Z").each { |letter|
         #~ @b[letter]  =  EmailDomain.find(:all,:conditions=>["domain REGEXP '^[#{letter}]' and status = true"],:order=>'domain asc')
    #~ }
    
     @b={}    
    ("A".."Z").each { |letter|
         @b[letter]  =  Organization.find(:all,:conditions=>["name REGEXP '^[#{letter}]' and status = true"],:order=>'name asc')
    }
  end  
  
  def contact_us
    return unless request.post?
    @enquiry = Enquiry.new(params[:enquiry])
    @enquiry.email = params[:email]
    @enquiry.subject = params[:subject]
    @enquiry.message = params[:message]
    if @enquiry.save
      flash.now[:notice] = "Successfully Saved."
      UserMailer.deliver_contact_us_mail(@enquiry)
    else
      render :action=>'contact_us'
    end       
  end  

  protected
  
  def password_authentication
    user = User.authenticate(params[:email], params[:password])
    if user
      self.current_user = user
      session[:current_duty_station_id] = current_user.duty_station.id
      successful_login
    else
      note_failed_signin
      @login = params[:login]
      @remember_me = params[:remember_me]
      render :action => :new
    end
  end
  
  def successful_login
    new_cookie_flag = (params[:remember_me] == "1")
    handle_remember_cookie! new_cookie_flag
    redirect_back_or_default(users_path)
    flash[:notice] = "Logged in successfully"
  end

  def note_failed_signin
    flash.now[:error] = "Your Email or password is incorrect."
    logger.warn "Failed login for '#{params[:login]}' from #{request.remote_ip} at #{Time.now.utc}"
  end
end
