require 'soap/wsdlDriver'
class UsersController < ApplicationController
  skip_before_filter :verify_authenticity_token, :only => :create
  before_filter :find_max_invitation, :only=>[:invitation]
  before_filter :load_domains
  before_filter :login_required,:only=>[:index,:edit,:update,:show,:profile,:invitation]
  before_filter :load_owner,:only=>[:show]
  before_filter :check_id_exist,:only=>[:profile]
  protect_from_forgery :except=>[:index]
  layout 'postadjustnew'
	
  
  def check_id_exist
   u =  User.find_by_id(params[:id])
   if u.nil?
		redirect_to(users_path)
		end   
  end 
  
  def rss
  session[:current_duty_station_id] = ( params[:duty_station_id].nil? ? session[:current_duty_station_id] : params[:duty_station_id] )
  @user = current_user
  @latest_jobs = Job.find(:all,:conditions=>['duty_station_id = ? and status = ?',session[:current_duty_station_id],true])
  @duty_station_jobs = Job.find(:all,:conditions=>['duty_station_id = ?',session[:current_duty_station_id]],:limit=>3,:order=>'created_at desc')
  @duty_station_ads = Market.find(:all,:conditions=>['duty_station_id = ?',session[:current_duty_station_id]],:limit=>3,:order=>'created_at desc')
  @latest_ads = Market.find(:all,:conditions=>['duty_station_id = ? and status = ?',session[:current_duty_station_id],true])
  @latest_questions = Question.find(:all,:conditions=>['duty_station_id = ?',session[:current_duty_station_id]])
  
  @group_results = @latest_jobs + @latest_ads + @latest_questions
  
  @results = @group_results.sort_by { |result| -result.created_at.to_i }.paginate(:per_page=>10,:page=>params[:page])
  render :layout=>false
  end  
  
  def index
  session[:current_duty_station_id] = ( params[:duty_station_id].nil? ? session[:current_duty_station_id] : params[:duty_station_id] )
  @user = current_user
  @latest_jobs = Job.find(:all,:conditions=>['duty_station_id = ? and status = ?',session[:current_duty_station_id],true])
  @duty_station_jobs = Job.find(:all,:conditions=>['duty_station_id = ?',session[:current_duty_station_id]],:limit=>3,:order=>'created_at desc')
  @duty_station_ads = Market.find(:all,:conditions=>['duty_station_id = ?',session[:current_duty_station_id]],:limit=>3,:order=>'created_at desc')
  @latest_ads = Market.find(:all,:conditions=>['duty_station_id = ? and status = ?',session[:current_duty_station_id],true])
  @latest_questions = Question.find(:all,:conditions=>['duty_station_id = ?',session[:current_duty_station_id]])
  
  @group_results = @latest_jobs + @latest_ads + @latest_questions
  
  @results = @group_results.sort_by { |result| -result.created_at.to_i }.paginate(:per_page=>10,:page=>params[:page])
  respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @results }
    end
  end  
  
  def new
     redirect_back_or_default(users_path) if logged_in?
    @invitation = Invitation.find_by_invitation_code(params[:invitation_code]) if params[:invitation_code]
    @user = User.new
    @user.email = @invitation.email if !@invitation.nil?
  end
 
  def create
    unless params[:invitation_code] || params[:accept]
      logout_keeping_session!
      if using_open_id?
        authenticate_with_open_id(params[:openid_url], :return_to => open_id_create_url, 
          :required => [:nickname, :email]) do |result, identity_url, registration|
          if result.successful?
            create_new_user(:identity_url => identity_url, :login => registration['nickname'], :email => registration['email'])
          else
            failed_creation(result.message || "Sorry, something went wrong")
          end
        end
      else
        create_new_user(params[:user])
      end
    else
      @invite_code = params[:accept]
      @invitation = Invitation.find_by_invitation_code(@invite_code)
      @user = User.new(params[:user])
      @user.is_user = true
      @user.email = @invitation.email
      if @user.valid?
        @user.register!
        @user.activate!
        @invitation.update_attributes(:invitation_code => nil,:invited_id=>@user.id,:max_invite=>5)
        org = Organization.find_by_name('Other')
        if org.nil?
          org = Organization.create(:name=>'Other',:website=>"http://postadjust.railsfactory.com",:status=>true)
        end        
        @user.update_attributes(:organization_id => org.id)
        flash[:notice] = "Registered Successfully."
        redirect_to login_path
      else
        render :action=>'new'
      end  
    end 
  end
  
  def activate
    logout_keeping_session!
    user = User.find_by_activation_code(params[:activation_code]) unless params[:activation_code].blank?
    case
    when (!params[:activation_code].blank?) && user && !user.active?
      user.activate!
      user.update_attribute(:max_invite,5)
      flash[:notice] = "Signup complete! Please sign in to continue."
      redirect_to login_path
    when params[:activation_code].blank?
      flash[:error] = "The activation code was missing.  Please follow the URL from your email."
      redirect_back_or_default(root_path)
    else 
      flash[:error]  = "We couldn't find a user with that activation code -- check your email? Or maybe you've already activated -- try signing in."
      redirect_back_or_default(root_path)
    end
  end
  
  def edit
	load_organizations 
	load_occupational_groups	
	load_duty_stations
		@user = User.find(current_user)
end

def update
	load_organizations 
	load_occupational_groups	
	load_duty_stations
	@user = User.find(current_user)
	    respond_to do |format|
   if params[:user][:duty_station_id].to_i != 0
      if @user.update_attributes(params[:user])
	      
	if params[:user_photo][:uploaded_data] != ""
		@user_photo = UserPhoto.new(params[:user_photo])
		if @user_photo.valid?
		@user.user_photo=@user_photo
		else
			render :action=>'edit'
			return
		end
	end
	if params[:user][:is_newsletter_notification]  == "1"
		@user.update_attribute('is_newsletter_notification', 1)
		else
		@user.update_attribute('is_newsletter_notification', 0)
	end
	session[:current_duty_station_id] = ( params[:user][:duty_station_id].nil? ? session[:current_duty_station_id] : params[:user][:duty_station_id] )
        flash[:notice] = 'User was successfully updated.'
        format.html { redirect_to(user_path(current_user)) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @user.errors, :status => :unprocessable_entity }
      end
  else
	  flash[:duty_station_error] = "Please select closest duty station"
        format.html { render :action => "edit" }
        format.xml  { render :xml => @user.errors, :status => :unprocessable_entity }
      end
    end

end

  def show
    @user = User.find(params[:id])
  	load_organizations 
	load_occupational_groups	
	load_duty_stations
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @user}
    end
  end

  
    def load_organizations
	  @organizations = Organization.active
  end
  
  def load_occupational_groups
	  @occupational_groups = OccupationalGroup.active
 end
  
 def load_duty_stations
	@duty_station = DutyStation.active
end

  def profile
	  @user = User.find(params[:id])
  end

  def duty_station_for_job
		 if params[:id]
		 @selected_duty_station =  params[:id]
		 @duty_station_jobs = Job.find(:all,:conditions=>['duty_station_id = ? and status = ?',params[:id],true],:limit=>3,:order=>'created_at desc')
      render :update do |page|
        page.call 'disableLoadingForJob'
				page.replace_html 'change_duty_station_for_job',:partial=>'user_duty_station_for_job'
			end
			end
		end
    
    def duty_station_for_ad
		 if params[:id]
		 @selected_duty_station =  params[:id]
		 @duty_station_ads = Market.find(:all,:conditions=>['duty_station_id = ? and status = ?',params[:id],true],:limit=>3,:order=>'created_at desc')
      render :update do |page|
        page.call 'disableLoadingForAd'
				page.replace_html 'change_duty_station_for_ad',:partial=>'user_duty_station_for_ad'
			end
			end
		end
		
  def load_owner
	    if User.exists?(params[:id])
	      @user = User.find(params[:id])
		      if @user !=current_user
			redirect_to users_path
		      end
	    else
		redirect_to users_path
	    end
  end

  def invitation
    @success_email = [ ]
		@result = {}
		@invite_details = {}
		@start = true
		     i = 1   
    return unless request.post?
      for email  in params[:email]
				prev_results = [ ] 
				proceed = [ ] 
				if !email.blank?
										@invite_details	 = {:email=>email,:firstname=>params[:firstname][i],:lastname=>params[:lastname][i],:message=>params[:invitation][:message]}
										@result["#{i}"+"_check_valid_format"] = check_valid_format(email)
										prev_results << @result["#{i}"+"_check_valid_format"]
										@result["#{i}"+"_check_registered_domain"] = check_registered_domain(email) if @result["#{i}"+"_check_valid_format"] == true
										prev_results << @result["#{i}"+"_check_registered_domain"]
										@result["#{i}"+"_check_in_invitation"] = check_in_invitation(email) if @result["#{i}"+"_check_registered_domain"] == true
										prev_results << @result["#{i}"+"_check_in_invitation"]
										@result["#{i}"+"_check_already_registered_and_activated"] = check_already_registered_and_activated(email) if @result["#{i}"+"_check_in_invitation"] == true
										prev_results << @result["#{i}"+"_check_already_registered_and_activated"] 
				
										prev_results.each do |result|
											if result == true || result.nil?
												proceed << true
											else
												proceed << false
											end	
										end	
										
										if !proceed.include?(false)
										@user = User.find_by_email(email)
										if !@user.nil?
                    @success_email << @user.email 
										already_in_postadjust_but_not_activate
										else
                    @success_email << email
										new_user(email,@invite_details[:firstname],@invite_details[:lastname],@invite_details[:message])
										end	
										end
				end
          i = i+1					
        end 
				@start = false
        flash.now[:notice] = "Mail sent to " + "#{@success_email.to_sentence}" if !@success_email.blank?
 end 
    
  def accept
    
  end    
    
  #domain is not in domain list, already in user table but not activate
  def already_in_postadjust_but_not_activate
    @user.update_attributes(:activation_code => nil, :activated_at => Time.now, :state =>'active')
    @invitation = Invitation.create(:user_id=>current_user.id,:email=>@user.email,:invited_id=>@user.id)
  end
  
  def check_in_invitation(email)
    invitation = Invitation.find_by_email(email)
    if !invitation.nil?
      return "Already Invited"
		else
			return true			
    end 
  end 
  
  def check_registered_domain(email)
    split_domains = email.split('@')
    tail_email = split_domains[1]
    if !$active_email_domains.nil?
      if $active_email_domains.include?(tail_email)
        return "This user can directly register in PostAdjust"
			else
				return true				
      end
		else
			return true	
    end      
  end    
  
	def check_already_registered_and_activated(email)
		user = User.find(:first,:conditions=>['email = ? and activation_code IS NULL',email])
    if !user.nil?
      return "This user is already registered in PostAdjust"
		else
			return true			
    end 
	end	
	
	def check_valid_format(email)
		if email =~ /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/
			return true			
		else	
			return "Provide Valid Email"
		end	
	end	
	
  #domain is not in domain list and new to postadjust  
  def new_user(email,fname,lname,msg)
     @invitation = Invitation.new
     @invitation.invitation_code = @invitation.make_token
     @invitation.user_id = current_user.id
     @invitation.email = email
     @invitation.firstname = fname
     @invitation.lastname = lname
     @invitation.message = msg
     @invitation.save
     UserMailer.deliver_invite(@invitation)
  end 
   
  def import_contacts
   
  end  
  
  def contact_list
    if params[:commit] == "Import Contacts"
      if (!params[:username].empty? && !params[:password].empty?) 
        unless params[:contacts]
       social_api
        else
          left_invitations = current_user.max_invite - current_user.invitations.length 
          @records = []
          params[:collections].to_s.split(',').each do |x| 
          @records << x
          end     
        end 
      else
      flash[:error] = "Username and Password can't be blank"
      redirect_to import_contacts_path
      end
    else
      left_invitations = current_user.max_invite - current_user.invitations.length 
      @records = []
      params[:collections].to_s.split(',').each do |x| 
      @records << x
      end
      if left_invitations >=params[:contacts].length
       add_invitation
      flash[:notice] = "Your invitation(s) sent successfully."
        redirect_to user_invitation_path
      else
        flash.now[:error] = "You have only #{left_invitations} invitations to send"
      end  
    end     
  end
  
  def social_api
     @records = []
        username = params[:username]
        password = params[:password]
        from = params[:from]
        secret_key = "5372F3436401EED6EA41826B1030CB9227700CBB3F20B98F"
        driver = SOAP::WSDLDriverFactory.new("http://socialapi.railsfactory.com/contacts/wsdl").create_rpc_driver
        results = driver.Getcontacts(username,password,from,secret_key)
           if eval(results)[0] == "FAILURE"
             flash[:error] = "User Name or Password is Incorrect"
              redirect_to import_contacts_path
           else  
            collection = eval(results)[1]
            collection.each do |x|
            @records << x[1]
            end  
          end
  end  
  
  def add_invitation
     params[:contacts].each do |contact|
        @invitation = Invitation.new
        @invitation.invitation_code = @invitation.make_token
        @invitation.user_id = current_user.id
        @invitation.email = contact
        @invitation.message = params[:message]
        @invitation.firstname = contact.split('@')[0]
        @invitation.save
        UserMailer.deliver_invite(@invitation)
      end
   end 
   

  protected
  
  def create_new_user(attributes)
    @user = User.new(attributes)
    @user.is_user = true
    if @user && @user.valid?
      if @user.not_using_openid?
      split_domains = @user.email.split('@')
      head_email = split_domains[0] + "@"
      tail_email = split_domains[1]
      if !$active_email_domains.nil?
      if !$active_email_domains.include?(tail_email)
      @user.deleted_at = nil
      @user.activation_code = @user.class.make_token
      @user.is_non_member = true
      @user.save
      @user.update_attribute(:state,'pending')
      UserMailer.deliver_nonmember_signup_notification(@user)
      else
      @user.is_non_member = false
      @user.register!          
      end
      end
      end      
    else
      @user.register_openid!
    end
    if @user.errors.empty?
      successful_creation(@user)
    else
      failed_creation
    end
  end
  
  def successful_creation(user)
    redirect_back_or_default(root_path)
    split_domains = @user.email.split('@')
      head_email = split_domains[0] + "@"
      tail_email = split_domains[1]
      if !$active_email_domains.nil?
        if !$active_email_domains.include?(tail_email)
        flash[:notice] = "Thanks for signing up!"
        flash[:notice] = "Your email is not in our list of approved organizations and contact info@postadjust.org"
        else
        flash[:notice] = "Thanks for signing up!"
        flash[:notice] << " We're sending you an email with your activation code." #if @user.not_using_openid?
        flash[:notice] << " You can now login with your OpenID." unless @user.not_using_openid?
        end
      end
  end
  
  def failed_creation(message = '')
    flash[:error] = message
    render :action => :new
  end
  
  # Get active email extensions list
  def load_domains
    $active_email_domains = EmailDomain.active.collect{|x| x.domain}
  end  
  


  
end
