module Admin::EmailDomainsHelper
end
