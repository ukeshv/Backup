module Admin::JobsHelper
end
