module Admin::OccupationalGroupsHelper
end
