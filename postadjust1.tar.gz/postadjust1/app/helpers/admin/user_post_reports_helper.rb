module Admin::UserPostReportsHelper
end
