module Admin::UsersHelper

def user_email_domain(user)
    if !user.email.blank?
    split_domains = user.email.split('@')
		return split_domains[1]
  end  
end

end
