module ApplicationHelper
  
  # Sets the page title and outputs title if container is passed in.
  # eg. <%= title('Hello World', :h2) %> will return the following:
  # <h2>Hello World</h2> as well as setting the page title.
  def title(str, container = nil)
    @page_title = str
    content_tag(container, str) if container
  end
  
  # Outputs the corresponding flash message if any are set
  def flash_messages
    messages = []
    %w(notice warning error).each do |msg|
      messages << content_tag(:div, html_escape(flash[msg.to_sym]), :class => "#{msg}",:id=>"#{msg}") unless flash[msg.to_sym].blank?
    end
    messages
  end
  
   def sort_link_helper(text, parameter, options, html_options=nil)
    key = parameter
    key += " DESC" if params[:sort] == parameter
    sorting_params=params.clone
    if params[:sort] == parameter 
      text =text
    elsif params[:sort]==("#{parameter} DESC")
      text =text
    end	
    link_to_remote text, {:loading => "$('ajax-loader').show();", :complete=>"$('ajax-loader').hide();", :url=>sorting_params.merge(:sort=>key), :method=>:get}, html_options
  end  
  
  def sort_link(text, parameter, options, html_options=nil)
	   key = parameter
	   key += " DESC" if params[:sort] == parameter
	   sorting_params=params.clone
	   if params[:sort] == parameter 
	   text =text
	   elsif params[:sort]==("#{parameter} DESC")
	   text =text
	   end        
	   link_to text, sorting_params.merge(:sort=>key)
  end  

  
  # Get categories and subcategories in tree structure  
     def display_trees(category_name)
    @ret = []
    for category_name in category_name
      if category_name.parent_id == 0
        @ret << category_name
        find_subtrees(category_name)
      end
    end
    return @ret
  end

  def find_subtrees(category_name)
    if(category_name.children.size > 0)
      category_name.children.each { |cat_names|
        @ret << cat_names
        if cat_names.children.size > 0
          find_subtrees(cat_names)
        end
      }
    end
  end

  def job_organization_name(job)
    job.organization.nil? ? "-" : job.organization.name
  end
  
  def job_occupational_group_name(job)
    job.occupational_group.nil? ? "-" : job.occupational_group.name
  end
  
  def job_grade_name(job)
    job.grade.nil? ? "-" :  job.grade.name
  end
  
  def job_duty_station_name(job)
    job.duty_station.nil? ? "-" : job.duty_station.station_with_country_code
  end
  
  def job_closing_date(job)
    job.closing_date.nil? ? "-" : job.closing_date.strftime("%d %B %Y")
  end
  
  def index_job_closing_date(job)
    job.closing_date.nil? ? "-" : job.closing_date.strftime("%d/%m/%Y")
  end
  
  def job_site(job)
    (job.jobsite.nil? or job.jobsite.empty?)  ? "-" : job.jobsite
  end
  
  def user_organization(user)
    user.organization.nil? ? "" : user.organization.name
  end  
  
  def user_occupational_group(user)
    user.occupational_group.nil? ? "" : user.occupational_group.name
  end
  
   def market_description(market)
    market.description.nil? ? "-" : market.description   
  end
  
  def market_price(market)
     #market.price.nil? ? "-" : market.currency_format+" "+market.price.to_s   
    if market.price.nil? 
      "-"
    elsif market.price == 0.0
      "Free"
     else
       market.currency_format+" "+market.price.to_s   
     end   
  end
  
  def market_organization(market)
    market.user.organization.nil? ? "-" : market.user.organization.name
  end

  
  def market_contact_phone(market)
    market.phone.blank? ?  "-"  : market.phone
  end
  
  def market_category_name(market)
    market.category.nil? ?  "-"  : market.category.name
  end
  
  def market_post_type_text(ads_type)
    if ads_type == "Sell"
      return "for Sale"
    elsif ads_type == "Rent"
      return "for Rental"
    else
      return "Wanted"
    end  
  end  
  
    def duty_station_name(dutystation_id)
      duty_station = DutyStation.find_by_id(dutystation_id) 
     name = duty_station.nil? ?  " " : duty_station.station_with_country_code
    end

  
   #Display name for comment
  def disp_name(userid, comment_id)
       user = User.find_by_id(userid)
       comment = Comment.find_by_id(comment_id)
       comment.is_anonymous == true ? "Anonymous" : user.fullname  
  end
  
  #Display user count in peoplesearch side bar
  def  user_count(org_id,duty_stn_id)
	  user = User.find(:all,:conditions=>["organization_id =? and duty_station_id = ? and activated_at!='nil'",org_id,duty_stn_id]).length
  end
  
  def select_duty_station_name(duty_stn_id)
	duty_station = DutyStation.find(duty_stn_id)
	duty_station.name
  end
  
  
  def comments_count(count)
	  count > 5 ? "View All #{count} Comments" : ""
  end
    
  
   def  question_type(q)
    if q.question_type == "question"
      return "Asks :"
    elsif q.question_type == "alert"
       return "Alerts :"
    elsif q.question_type == "recommendation"
      return "Recommends :"
		else 
      return "Informs :"
    end 
  end  
  
  def convert_link(str)
  if !str.blank?  
	str_arry = str.split(" ")
	new_str = []
	str_arry.each{ |s|
	if s.include?('@') 
		new_str << ("<a href='mailto:#{s}'>"+s+"</a>")
	elsif s.include?('http') or s.include?('https') or s.include?('www.')		
		new_str << ("<a href='#{s}' target=_blank>"+s+"</a>")
	else
		new_str << s
	end
	}
	str = new_str.join(' ')	
  end
	return str.to_s
end

  def active_market_media(id)
    market = Market.find(id)
    if (market.attachings && market.attachings.find_by_is_primary(true))
    market_media = market.attachings.find_by_is_primary(true)
    media = market_media.asset.url(:thumb)
    else
    media = market.attachings.last.asset.url(:thumb)
    end 
    return media
  end 
  
  def display_user(obj)
    obj.user.nil? ?  "Anonymous"  : obj.user.fullname
  end 
  
end
