module Search::JobsHelper

  def organization_name_with_count(org)
		org_count = org.jobs.count(:conditions=>['status = true AND (closing_date > (?) or closing_date is NULL)',Date.today+1])
		if org_count > 0 
	 "#{org.name}" +" "+ "(#{org_count})"
	  else
		""	
	  end
	end

  def occupational_name_with_count(occ)
		occ_count = occ.jobs.count(:conditions=>['status = true AND (closing_date > (?) or closing_date is NULL)',Date.today+1])
		if occ_count > 0
	 "#{occ.name}" +" "+ "(#{occ_count})"
	 else
		""
	 end
  end
 
	def grade_name_with_count(grade)
		grade_count = grade.jobs.count(:conditions=>['status = true AND (closing_date > (?) or closing_date is NULL)',Date.today+1])
		if grade_count > 0
	 "#{grade.name}" +" "+ "(#{grade_count})"
	  else
			""
		end	
	end

  def job_title_with_grade_and_station(job)
		if job.grade
		"#{job.title}"+" "+"(#{job.grade.name})"+","+" "+("#{job.duty_station.station_with_country_code}")
		else
		"#{job.title}"+" "+"(-)"+","+" "+("#{job.duty_station.station_with_country_code}")
		end	
	end	

  def count(station,org,occ,grade)
		net_query_string = [ ]
		net_query_string << "duty_station_id = #{station}" if !station.nil?
		net_query_string << "grade_id = #{grade}" if !grade.nil?
		net_query_string << "organization_id = #{org}" if !org.nil?
		net_query_string << "occupational_group_id = #{occ}" if !occ.nil?
		net_query_string << "status = true"
		net_query_string = net_query_string.join(" AND ")
		return Job.count(:all,:conditions=>["#{net_query_string} AND (closing_date > (?) or closing_date is NULL)",Date.today+1])	 
	end

def get_org(jobs)
	orgs1 = []
	jobs.each do |job|
		orgs1 << job.organization if !job.organization.nil?
	end	
	return orgs1.uniq
end	

	def org_name_with_count(org)
		station = params[:station] ||= params[:search_station]
		org_count = count(station,org.id,params[:occ],params[:grade])
		if org_count > 0
		"#{org.name}"+ " "+ "(#{org_count})"
		else
			""
		end
	end


def get_occ(jobs)
	occs1 = []
	jobs.each do |job|
		occs1 << job.occupational_group if !job.occupational_group.nil?
	end	
		return occs1.uniq
end	

	def occ_name_with_count(occ)
	  station = params[:station] ||= params[:search_station]
		occ_count = count(station,params[:org],occ.id,params[:grade])
		if occ_count > 0
		"#{occ.name}"+ " "+ "(#{occ_count})"
		else
			""
		end
	end

def get_grade(jobs)
	grades1 = []
	jobs.each do |job|
		grades1 << job.grade if !job.grade.nil?
	end	
		return grades1.uniq
end	

	def grade_name_with_count(grade)
		station = params[:station] ||= params[:search_station]
		grade_count = count(station,params[:org],params[:occ],grade.id)
		if grade_count > 0 
		"#{grade.name}"+ " "+ "(#{grade_count})"
		else
			""
		end	
	end

end
