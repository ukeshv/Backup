module Search::PeopleHelper
end
