class Category < ActiveRecord::Base
	
  acts_as_ordered_tree :foreign_key => :parent_id,:order  => :position
  validates_presence_of :name,:message=>'Provide Name'
  
	# Associations	
	has_many :markets
	
  	# Named scopes
	named_scope :active, :conditions =>["categories.status = ?",true]
	
	def display_status
		self.status == true ? 'Active' : 'Inactive'
	end	


end
