class Country < ActiveRecord::Base
	
	#Associations
	has_many :duty_stations
	
	acts_as_dropdown :text => :get_country_names, :order => "country_name ASC"
	
	#To display duty stations with country code as dropdown list	
	def get_country_names
		return "#{country_name}"
  end	
	
end
