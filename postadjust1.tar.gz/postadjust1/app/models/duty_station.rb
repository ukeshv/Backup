class DutyStation < ActiveRecord::Base
	
	# Associations	
	belongs_to :country
	has_many :users
	has_many :user_post_reports
	has_one :post_report,:dependent=>:destroy
	
	#Validations
	validates_presence_of :name,:message=>"Provide Duty Station Name"
	validate :country_must_exist
	validates_uniqueness_of :name, :scope => [:country_id],:message=>"Name and Country has already taken"
	
	has_many :jobs
	has_many :markets
	
	# Named scopes
	named_scope :active, :conditions =>["duty_stations.status = ?",true]
	
	acts_as_dropdown :text => :station_with_country_code, :order => "name ASC"
	
	#To display duty stations with country code as dropdown list	
	def station_with_country_code
		return "#{name}" + ", " + "#{self.country.country_code}"
  end	
	
	def display_status
		self.status == true ? 'Active' : 'Inactive'
	end	

	def country_must_exist
		errors.add(:country_id, "Select a Country") if country_id.nil?
	end

	
end
