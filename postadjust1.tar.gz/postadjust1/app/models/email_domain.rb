class EmailDomain < ActiveRecord::Base
	
	# Validations
	validates_uniqueness_of :domain,:message=>"Email Domain has already been taken"
  validates_format_of :domain,:with=> /^((?:[-a-z0-9]+.)+[a-z]{2,})$/ix,:message=>"Provide valid domain"

	
	# Named scopes
	named_scope :active, :conditions =>["email_domains.status = ?",true]
	
	def display_status
		self.status == true ? 'Active' : 'Inactive'
	end	
	
end
