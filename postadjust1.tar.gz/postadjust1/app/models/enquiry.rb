class Enquiry < ActiveRecord::Base
	
	validates_presence_of :email,:message=>"Provide Email"
	validates_presence_of :subject,:message=>"Provide Subject"
	validates_presence_of :message,:message=>"Provide Message"
	
	validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i ,:message=>"Please provide a valid Email Address"
  validates_length_of :subject, :within => 1..80,:too_long => "Enter subject between 1 and 80 characters long.",:too_short => "Enter subject between 1 and 80 characters long."
	
end
