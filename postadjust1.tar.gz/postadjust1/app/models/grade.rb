class Grade < ActiveRecord::Base
	
	# Validations
	validates_presence_of :name,:message=>"Provide Grade"
	validates_uniqueness_of :name,:message=>"Grade Name has already been taken"
	
	has_many :jobs
	
	# Named scopes
	named_scope :active, :conditions =>["grades.status = ?",true]
	
	def display_status
		self.status == true ? 'Active' : 'Inactive'
	end	

end
