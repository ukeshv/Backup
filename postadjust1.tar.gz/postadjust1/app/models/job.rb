class Job < ActiveRecord::Base
	
	attr_accessor :save_by_scrap 
	
	#Validations
	validates_presence_of :title,:message=>"Provide Title"	
	validates_presence_of :organization_id,:message=>"Provide Organization"	
	validates_presence_of :occupational_group_id,:if => Proc.new { |job| !job.save_by_scrap? },:message=>"Provide Occupational group"	
	validates_presence_of :duty_station_id,:message=>"Provide Duty station"	
	validates_presence_of :grade_id,:if => Proc.new { |job| !job.save_by_scrap? },:message=>"Provide Grade"	
	validates_format_of :jobsite, :with =>
        /(^$)|(^(http|https):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(([0-9]{1,5})?\/.*)?$)/ ,:if => Proc.new { |job| !job.jobsite.blank? },  :message=>"Provide valid jobsite"


	validates_uniqueness_of :domain, :scope => [:source_id],:if => Proc.new { |job| job.save_by_scrap? },:message=>"Record already exists with this source id for this domain"
	
	# Associations	
	belongs_to :organization
	belongs_to :duty_station
	belongs_to :occupational_group
	belongs_to :grade
	belongs_to :user
	
	has_one :job_upload, :as=>:attachable,:dependent=>:destroy

def display_status
	if self.status == true
		return 'Approved'
	else
    return 'Pending'		
	end
end

def self.deactivate_job
	@jobs=Job.find :all,:conditions=>['DATE(created_at)< ?',Date.today-90]
	@jobs.each do |job|
	job.update_attribute(:status,false)
	end
	end

  def save_by_scrap?
    if (self.save_by_scrap == true)
			return true
		else
			return false
		end
  end 
	

	 def self.matched_duty_station_id(a)
			if !a.nil?
			a.split(',').each do |x|
			@matched = DutyStation.find(:first,:conditions=>["name LIKE '%%#{x.strip}%%'"])
			if !@matched.nil?
			@x = @matched.id	
			break
			else		
			@x = DutyStation.find_by_name('Other').id 	
			end		
			end	 
			else
			@x = DutyStation.find_by_name('Other').id 
	   end
			return @x																 
	 end	 

end
