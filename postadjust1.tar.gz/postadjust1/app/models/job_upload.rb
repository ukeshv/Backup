class JobUpload < ActiveRecord::Base
	has_attachment :content_type => ['application/pdf', 'application/msword', 'text/plain'],:storage => :file_system
	belongs_to :attachable,:polymorphic=>true
	
	def validate
    errors.add_to_base("You must choose a file to upload") unless self.filename

    unless self.filename == nil

      # Files should only be DOC, PDF, or TXT
      [:content_type].each do |attr_name|
        enum = attachment_options[attr_name]
        unless enum.nil? || enum.include?(send(attr_name))
          errors.add(:content_type,"You can only upload files (.doc, .pdf or .txt)")
        end
      end
    end
  end
end
