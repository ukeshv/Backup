class Market < ActiveRecord::Base
	attr_accessor :check
	
	#Validations
	validates_presence_of :title,:message=>"Provide Title"	
	validates_presence_of :ads_type,:message=>"Provide Type"	
	validates_presence_of :category_id,:message=>"Provide Category"	
	validates_presence_of :duty_station_id,:message=>"Provide Duty Station"	
	validates_presence_of :price,:if => Proc.new{ |market| market.currency_format != "Free" },:message=>"Provide Price"	
	validates_numericality_of :price,:if => Proc.new{ |market| market.currency_format != "Free" }, :integer_only => true, :message => "Price should be digits"
	validates_presence_of :description,:message=>"Provide Description"	
	validates_presence_of :email	,:message=>"Provide Email"
	validates_format_of  :email,:with => /^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$/ ,  :message => "Provide valid email address"
	#validates_presence_of :phone, :if => Proc.new{ |market| market.use_my_contact_info == false },:message=>"Provide PhoneNumber"	
	 validates_format_of :phone,  :with => /^[0-9]/, :message =>"PhoneNumber should be digits"
	 validates_length_of :phone, :maximum => 15 ,:message=>"PhoneNumber length is too long(maximum 15 numbers)"	
	 
	 # for paperclip (polymorphic)
acts_as_polymorphic_paperclip 

	
	# Associations	
	belongs_to :user
	belongs_to :category
	belongs_to :duty_station
	 has_many :market_uploads, :as => :parent, :dependent=>:destroy
	
	def display_status
	if self.status == true
		return 'Active'
	else
    return 'Inactive'		
	end
 end


def self.deactivate_ad
	@ads=Market.find :all,:conditions=>['DATE(created_at)< ?',Date.today-90]
	@ads.each do |ad|
	ad.update_attribute(:status,false)
	end
end

def first_image
if self.market_uploads.length>0
	if self.market_uploads.find_by_is_primary(true)
		image = self.market_uploads.find_by_is_primary(true)
	else	
    image = self.market_uploads.find(:first)
	end	
image ? image.public_filename(:thumb) : "/images/ad.jpg"
else
"/images/ad.jpg"
end
end

def first_large_image_size
if self.market_uploads.length>0
	if self.market_uploads.find_by_is_primary(true)
		image = self.market_uploads.find_by_is_primary(true)
	else	
    image = self.market_uploads.find(:first)
	end	
	if image
		if File.exists? RAILS_ROOT + "/public#{image.public_filename(:large)}"
			image = image.public_filename(:large)
		else
			image = "/images/ad.jpg"
    end			
	else
		image = "/images/ad.jpg"
	end	
else
"/images/ad.jpg"
end
end
	
	def market_media(id)
    market = Market.find(id)
    if (market.attachings && market.attachings.find_by_is_primary(true))
    market_media = market.attachings.find_by_is_primary(true)
    media = market_media.asset.url(:thumb)
    else
    media = market.attachings.last.asset.url(:thumb)
    end 
    return media
  end
	
	ADS_TYPE = [["Select Type",""],
    [ 'Sell', 'Sell'],
    [ 'Rent', 'Rent'], 
    [ 'Wanted', 'Wanted']
                ].freeze
								
	CURRENCY_FORMAT = [[ '$', '$'],
    [ 'Yen', 'Yen'], 
    [ 'INR', 'INR'],
    [ 'Free', 'Free']
                ].freeze
	
end
