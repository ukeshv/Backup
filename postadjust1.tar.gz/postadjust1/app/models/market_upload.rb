class MarketUpload < ActiveRecord::Base
	has_attachment :content_type => ['image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg'],
:storage => :file_system,
:resize_to => '320x200>',
:thumbnails => {:small=> '71X58',:thumb => '100X100',:large=>'212x215'},
:path_prefix => 'public/attachments/market_uploads',
:min_size => 0.kilobytes,
:max_size => 10.megabytes,
:processor => :rmagick

validates_as_attachment
after_save :save_thumbnail
belongs_to :parent, :polymorphic => true  
	
	
 


   
  def save_thumbnail
    require 'RMagick'
    if self.content_type != "video/x-flv"
    @photo=self
    if @photo
      maxw =  80
      maxh =  50
      aspectratio = maxw.to_f / maxh.to_f
      pic = Magick::Image.read(RAILS_ROOT + "/public#{self.public_filename}").first
      picw = @photo.width
      pich = @photo.height
      picratio = picw.to_f / pich.to_f
      if picratio > aspectratio then
        scaleratio = maxw.to_f / picw
      else
        scaleratio = maxh.to_f / pich
      end
      begin
        thumb = scaleratio < 1 ? pic.resize(100,100) : pic       
        small = scaleratio < 1 ? pic.resize(71,58) : pic       
        large = scaleratio < 1 ? pic.resize(212,215) : pic       
        thumb_temp_path =(RAILS_ROOT + "/public/#{self.public_filename(:thumb)}")
        small_temp_path =(RAILS_ROOT + "/public/#{self.public_filename(:small)}")
        large_temp_path =(RAILS_ROOT + "/public/#{self.public_filename(:large)}")
        FileUtils.mkdir_p(File.dirname(thumb_temp_path))
        FileUtils.mkdir_p(File.dirname(small_temp_path))
        FileUtils.mkdir_p(File.dirname(large_temp_path))
        thumb.write(thumb_temp_path)
        small.write(small_temp_path)
        large.write(large_temp_path)
      rescue
        logger.info "Thumbnail cannot be generated"
      end
    end
  end
  end

	
end
