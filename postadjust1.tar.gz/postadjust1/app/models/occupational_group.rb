class OccupationalGroup < ActiveRecord::Base
	
	# Validations
	validates_presence_of :name,:message=>"Provide Group Name"
	validates_uniqueness_of :name,:message=>"Group Name has already been taken"
	
	# Associations
	has_many :jobs
	has_many :users
	
	# Named scopes
	named_scope :active, :conditions =>["occupational_groups.status = ?",true],:order=>'name asc'
	
	def display_status
		self.status == true ? 'Active' : 'Inactive'
	end	

end
