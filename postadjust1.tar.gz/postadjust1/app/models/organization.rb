class Organization < ActiveRecord::Base
	
	# Validations
	validates_presence_of :name,:message=>"Provide Organization Name"
	validates_uniqueness_of :name,:message=>"Name already taken"
	validates_uniqueness_of :website,:allow_blank=>true,:message=>"Url already taken"
	validates_format_of :website,:with => /^(http|https|ftp):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/ix ,:allow_blank=>true,:message=>"Provide Valid Url"
	
	# Associations
	has_many :jobs
	has_many :users
	
	# Named scopes
	named_scope :active, :conditions =>["organizations.status = ?",true],:order=>'name asc'
	
	def display_status
		self.status == true ? 'Active' : 'Inactive'
	end	

end
