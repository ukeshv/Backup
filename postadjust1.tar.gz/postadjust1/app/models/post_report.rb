class PostReport < ActiveRecord::Base
	
	# Associations	
	belongs_to :duty_station
	belongs_to :user
	
end
