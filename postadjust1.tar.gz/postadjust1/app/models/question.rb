class Question < ActiveRecord::Base
	acts_as_commentable
	
	belongs_to :user
	
	validates_presence_of :question_type ,:message=>'choose a type'
	validates_presence_of :description ,:message=>'post your question,alert etc..'
	validates_presence_of :duty_station_id ,:message=> 'Provide duty station'
end
