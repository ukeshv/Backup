class Scraper < ActiveRecord::Base
	
	validates_presence_of :domain,:message=>'Provide Domain'
	validates_format_of :domain,:with => /^(http|https|ftp):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/ix ,:message=>"Provide Valid Domain"
	validates_presence_of :classname,:message=>'Provide Classname'
	validates_presence_of :filename,:message=>'Provide Filename'
	validates_presence_of :url,:message=>'Provide Filename'
	validates_format_of :url,:with => /^(http|https|ftp):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/ix ,:message=>"Provide Valid Url"
	
	FREQUENCY = [[ 'Daily Once', 'Daily Once'],
    [ 'Weekly Once', 'Weekly Once'], 
    [ 'Monthly Once', 'Monthly Once']
                ].freeze

	#validate :check_presence_of_filename_or_classname

	def check_presence_of_filename_or_classname
		if self.filename.blank? && self.classname.blank?
			errors.add(:filename, "Provide Classname/filename")
			errors.add(:classname, "Provide Classname/filename")
		end	
	end	

  def self.active_scrapers
    self.find(:all, :conditions => ["status = ?", true])
  end
	
end
