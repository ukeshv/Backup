class Setting < ActiveRecord::Base
	
	validates_presence_of :max_invite,:message => "Enter Maximum Invite."
	validates_numericality_of :max_invite, :message => "Maximum Invite should be in numbers."
end
