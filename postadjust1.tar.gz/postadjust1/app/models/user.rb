require 'digest/sha1'

class User < ActiveRecord::Base
  include Authentication
  include Authentication::ByPassword
  include Authentication::ByCookieToken
  include Authorization::AasmRoles

  # Validations
  #validates_presence_of :login, :if => :not_using_openid?
  #validates_length_of :login, :within => 3..40, :if => :not_using_openid?
  #validates_uniqueness_of :login, :case_sensitive => false, :if => :not_using_openid?
  #validates_format_of :login, :with => RE_LOGIN_OK, :message => MSG_LOGIN_BAD, :if => :not_using_openid?
  #validates_format_of :name, :with => RE_NAME_OK, :message => MSG_NAME_BAD, :allow_nil => true
  #validates_length_of :name, :maximum => 100
  
  validates_presence_of :email, :if => :not_using_openid?,:message => "Enter your email address."
  validates_length_of :email, :within => 6..100, :if => :not_using_openid?, :message => MSG_EMAIL_BAD
  validates_uniqueness_of :email, :case_sensitive => false, :if => :not_using_openid?,:message => 'An account is already registered with this address.'
  #validate :valid_email_domain,:if =>Proc.new { |user| user.is_user? }
  validates_format_of :email, :with => /^([^@\s]+)@((?:[-a-z0-9]+.)+[a-z]{2,})$/i ,:message=>"Please provide a valid Email Address"

  validates_format_of :firstname, :with => RE_NAME_OK, :message => MSG_NAME_BAD, :allow_nil => true
  validates_length_of :firstname, :within => 2..20,:too_long => "Enter firstname between 2 and 20 characters long.",:too_short => "Enter firstname between 2 and 20 characters long."
  
  validates_presence_of :duty_station_id,:if =>Proc.new { |user| user.is_user? },:message=>"Please select closest duty station"  
  
  validates_format_of :phone,  :with => /^[0-9]/, :message =>"PhoneNumber should be digits", :allow_blank => true
  validates_length_of :phone, :maximum => 15 ,:message=>"PhoneNumber length is too long(maximum 15 numbers)"	, :allow_blank => true
  
  validates_uniqueness_of :identity_url, :unless => :not_using_openid?
  validate :normalize_identity_url
  
  # Relationships
  has_and_belongs_to_many :roles
  has_one :user_photo, :as=>:attachable,:dependent=>:destroy


  # HACK HACK HACK -- how to do attr_accessible from here?
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  #attr_accessible :email, :firstname, :password, :password_confirmation, :identity_url,:duty_station_id

  # Callbacks
  after_create :add_user_role

  attr_accessor :is_user,:is_non_member

	# Associations	
	belongs_to :duty_station
	belongs_to :organization
	belongs_to :occupational_group
  has_many :jobs, :dependent=>:destroy
  has_many :markets, :dependent=>:destroy
  has_many :questions, :dependent=>:destroy
  has_many :post_reports, :dependent=>:destroy
  has_many :invitations 
  #has_many :user_post_reports

	
  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  def self.authenticate(email, password)
    u = find :first, :conditions => ['email = ? and status = ? and activated_at IS NOT NULL', email,true] # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end
  
  # Check if a user has a role.
  def has_role?(role)
    list ||= self.roles.map(&:name)
    list.include?(role.to_s) || list.include?('admin')
  end
  
  def is_user?
    if (self.is_user == true)
			return true
		else
			return false
		end
  end  
  
  def valid_email_domain
    if !email.blank?
    split_domains = email.split('@')
    head_email = split_domains[0] + "@"
    tail_email = split_domains[1]
      unless head_email =~/^(?i-mx:\A[\w\.%\+\-]+@)$/
        errors.add(:email, "provide valid email")
      end
      if !$active_email_domains.nil?
        if !$active_email_domains.include?(tail_email)
          errors.add(:email, "provide valid email domain")
        end
      end
    end      
  end  
  
  # Not using open id
  def not_using_openid?
    identity_url.blank?
  end
  
  # Overwrite password_required for open id
  def password_required?
    new_record? ? not_using_openid? && (crypted_password.blank? || !password.blank?) : !password.blank?
  end

	def fullname
		 if self.lastname.nil?
		 return self.firstname
		 else
		 return self.firstname + ' ' + self.lastname
		 end
	 end
   
  def display_status
	if self.status == true
		return 'Approved'
	else
    return 'Pending'		
	end
  end

   #sending newsletter 
  def self.news_letter
          @users = User.find(:all,:conditions=>['is_newsletter_notification = ? and activation_code IS NULL',true])
          @users.each do |user|
          @duty_station = DutyStation.find(user.duty_station_id)
          @ads = Market.find(:all,:conditions=>['created_at < ? and created_at > ? and duty_station_id = ?',Date.today,Date.today-7,@duty_station.id])
          @jobs = Job.find(:all,:conditions=>['created_at < ? and created_at > ? and duty_station_id = ?',Date.today,Date.today-7,@duty_station.id])
          @post_report = PostReport.find(:last,:conditions=>['duty_station_id = ?',@duty_station.id])
          @questions = Question.find(:all,:conditions=>['created_at < ? and created_at > ? and duty_station_id = ?',Date.today,Date.today-7,@duty_station.id])
                  UserMailer.deliver_newsletter(user,@ads,@jobs,@post_report,@questions,@duty_station) 
                end
  end
              
  protected
    
  def make_activation_code
    self.deleted_at = nil
    self.activation_code = self.class.make_token
  end
  
  def normalize_identity_url
    self.identity_url = OpenIdAuthentication.normalize_url(identity_url) unless not_using_openid?
  rescue URI::InvalidURIError
    errors.add_to_base("Invalid OpenID URL")
  end
  
  def add_user_role
    self.roles << Role.find_by_name('user')
  end  
  
	NATIONALITY  = [ 'Afghan', 'Afghan'],
    [ 'Albanian', 'Albanian'],
    [ 'Algerian', 'Algerian'],
    [ 'American', 'American'],
    [ 'Andorran', 'Andorran'],
    [ 'Angolan', 'Angolan'],
    [ 'Antiguans', 'Antiguans'],
    [ 'Argentinean', 'Argentinean'],
    [ 'Armenian', 'Armenian'],
    [ 'Australian', 'Australian'],
    [ 'Austrian', 'Austrian'],
    [ 'Azerbaijani', 'Azerbaijani'],
    [ 'Bahamian', 'Bahamian'],
    [ 'Bahraini', 'Bahraini'],
    [ 'Bangladeshi', 'Bangladeshi'],
    [ 'Barbadian', 'Barbadian'],
    [ 'Barbudans', 'Barbudans'],
    [ 'Batswana', 'Batswana'],
    [ 'Belarusian', 'Belarusian'],
    [ 'Belgian', 'Belgian'],
    [ 'Belizean', 'Belizean'],
    [ 'Beninese', 'Beninese'],
    [ 'Bhutanese', 'Bhutanese'],
    [ 'Bolivian', 'Bolivian'],
    [ 'Bosnian', 'Bosnian'],
    [ 'Brazilian', 'Brazilian'],
    [ 'British', 'British'],
    [ 'Bruneian', 'Bruneian'],
    [ 'Bulgarian', 'Bulgarian'],
    [ 'Burkinabe', 'Burkinabe'],
    [ 'Burmese', 'Burmese'],
    [ 'Burundian', 'Burundian'],
    [ 'Cambodian', 'Cambodian'],
    [ 'Cameroonian', 'Cameroonian'],
    [ 'Canadian', 'Canadian'],
    [ 'Cape Verdean', 'Cape Verdean'],
    [ 'Central African', 'Central African'],
    [ 'Chadian', 'Chadian'],
    [ 'Chilean', 'Chilean'],
    [ 'Chinese', 'Chinese'],
    [ 'Colombian', 'Colombian'],
    [ 'Comoran', 'Comoran'],
    [ 'Congolese', 'Congolese'],
    [ 'Costa Rican', 'Costa Rican'],
    [ 'Croatian', 'Croatian'],
    [ 'Cuban', 'Cuban'],
    [ 'Cypriot', 'Cypriot'],
    [ 'Czech', 'Czech'],
    [ 'Danish', 'Danish'],
    [ 'Djibouti', 'Djibouti'],
    [ 'Dominican', 'Dominican'],
    [ 'Dutch', 'Dutch'],
    [ 'Dutchman', 'Dutchman'],
    [ 'Dutchwoman', 'Dutchwoman'],
    [ 'East Timorese', 'East Timorese'],
    [ 'Ecuadorean', 'Ecuadorean'],
    [ 'Egyptian', 'Egyptian'],
    [ 'Emirian', 'Emirian'],
    [ 'Equatorial Guinean', 'Equatorial Guinean'],
    [ 'Eritrean', 'Eritrean'],
    [ 'Estonian', 'Estonian'],
    [ 'Ethiopian', 'Ethiopian'],
    [ 'Fijian', 'Fijian'],
    [ 'Filipino', 'Filipino'],
    [ 'Finnish', 'Finnish'],
    [ 'French', 'French'],
    [ 'Gabonese', 'Gabonese'],
    [ 'Gambian', 'Gambian'],
    [ 'Georgian', 'Georgian'],
    [ 'German', 'German'],
    [ 'Ghanaian', 'Ghanaian'],
    [ 'Greek', 'Greek'],
    [ 'Grenadian', 'Grenadian'],
    [ 'Guatemalan', 'Guatemalan'],
    [ 'Guinea-Bissauan', 'Guinea-Bissauan'],
    [ 'Guinean', 'Guinean'],
    [ 'Guyanese', 'Guyanese'],
    [ 'Haitian', 'Haitian'],
    [ 'Herzegovinian', 'Herzegovinian'],
    [ 'Honduran', 'Honduran'],
    [ 'Hungarian', 'Hungarian'],
    [ 'I-Kiribati', 'I-Kiribati'],
    [ 'Icelander', 'Icelander'],
    [ 'Indian', 'Indian'],
    [ 'Indonesian', 'Indonesian'],
    [ 'Iranian', 'Iranian'],
    [ 'Iraqi', 'Iraqi'],
    [ 'Irish', 'Irish'],
    [ 'Israeli', 'Israeli'],
    [ 'Italian', 'Italian'],
    [ 'Ivorian', 'Ivorian'],
    [ 'Jamaican', 'Jamaican'],
    [ 'Japanese', 'Japanese'],
    [ 'Jordanian', 'Jordanian'],
    [ 'Kazakhstani', 'Kazakhstani'],
    [ 'Kenyan', 'Kenyan'],
    [ 'Kittian and Nevisian', 'Kittian and Nevisian'],
    [ 'Kuwaiti', 'Kuwaiti'],
    [ 'Kyrgyz', 'Kyrgyz'],
    [ 'Laotian', 'Laotian'],
    [ 'Latvian', 'Latvian'],
    [ 'Lebanese', 'Lebanese'],
    [ 'Liberian', 'Liberian'],
    [ 'Libyan', 'Libyan'],
    [ 'Liechtensteiner', 'Liechtensteiner'],
    [ 'Lithuanian', 'Lithuanian'],
    [ 'Luxembourger', 'Luxembourger'],
    [ 'Macedonian', 'Macedonian'],
    [ 'Malagasy', 'Malagasy'],
    [ 'Malawian', 'Malawian'],
    [ 'Malaysian', 'Malaysian'],
    [ 'Maldivan', 'Maldivan'],
    [ 'Malian', 'Malian'],
    [ 'Maltese', 'Maltese'],
    [ 'Marshallese', 'Marshallese'],
    [ 'Mauritanian', 'Mauritanian'],
    [ 'Mauritian', 'Mauritian'],
    [ 'Mexican', 'Mexican'],
    [ 'Micronesian', 'Micronesian'],
    [ 'Moldovan', 'Moldovan'],
    [ 'Monacan', 'Monacan'],
    [ 'Mongolian', 'Mongolian'],
    [ 'Moroccan', 'Moroccan'],
    [ 'Mosotho', 'Mosotho'],
    [ 'Motswana', 'Motswana'],
    [ 'Mozambican', 'Mozambican'],
    [ 'Namibian', 'Namibian'],
    [ 'Nauruan', 'Nauruan'],
    [ 'Nepalese', 'Nepalese'],
    [ 'Netherlander', 'Netherlander'],
    [ 'New Zealander', 'New Zealander'],
    [ 'Ni-Vanuatu', 'Ni-Vanuatu'],
    [ 'Nicaraguan', 'Nicaraguan'],
    [ 'Nigerian', 'Nigerian'],
    [ 'North Korean', 'North Korean'],
    [ 'Northern Irish', 'Northern Irish'],
    [ 'Norwegian', 'Norwegian'],
    [ 'Omani', 'Omani'],
    [ 'Pakistani', 'Pakistani'],
    [ 'Palauan', 'Palauan'],
    [ 'Panamanian', 'Panamanian'],
    [ 'Papua New Guinean', 'Papua New Guinean'],
    [ 'Paraguayan', 'Paraguayan'],
    [ 'Peruvian', 'Peruvian'],
    [ 'Polish', 'Polish'],
    [ 'Portuguese', 'Portuguese'],
    [ 'Qatari', 'Qatari'],
    [ 'Romanian', 'Romanian'],
    [ 'Russian', 'Russian'],
    [ 'Rwandan', 'Rwandan'],
    [ 'Saint Lucian', 'Saint Lucian'],
    [ 'Salvadoran', 'Salvadoran'],
    [ 'Samoan', 'Samoan'],
    [ 'San Marinese', 'San Marinese'],
    [ 'Sao Tomean', 'Sao Tomean'],
    [ 'Saudi', 'Saudi'],
    [ 'Scottish', 'Scottish'],
    [ 'Senegalese', 'Senegalese'],
    [ 'Serbian', 'Serbian'],
    [ 'Seychellois', 'Seychellois'],
    [ 'Sierra Leonean', 'Sierra Leonean'],
    [ 'Singaporean', 'Singaporean'],
    [ 'Slovakian', 'Slovakian'],
    [ 'Slovenian', 'Slovenian'],
    [ 'Solomon Islander', 'Solomon Islander'],
    [ 'Somali', 'Somali'],
    [ 'South African', 'South African'],
    [ 'South Korean', 'South Korean'],
    [ 'Spanish', 'Spanish'],
    [ 'Sri Lankan', 'Sri Lankan'],
    [ 'Sudanese', 'Sudanese'],
    [ 'Surinamer', 'Surinamer'],
    [ 'Swazi', 'Swazi'],
    [ 'Swedish', 'Swedish'],
    [ 'Swiss', 'Swiss'],
    [ 'Syrian', 'Syrian'],
    [ 'Taiwanese', 'Taiwanese'],
    [ 'Tajik', 'Tajik'],
    [ 'Tanzanian', 'Tanzanian'],
    [ 'Thai', 'Thai'],
    [ 'Togolese', 'Togolese'],
    [ 'Tongan', 'Tongan'],
    [ 'Trinidadian or Tobagonian', 'Trinidadian or Tobagonian'],
    [ 'Tunisian', 'Tunisian'],
    [ 'Turkish', 'Turkish'],
    [ 'Tuvaluan', 'Tuvaluan'],
    [ 'Ugandan', 'Ugandan'],
    [ 'Ukrainian', 'Ukrainian'],
    [ 'Uruguayan', 'Uruguayan'],
    [ 'Uzbekistani', 'Uzbekistani'],
    [ 'Venezuelan', 'Venezuelan'],
    [ 'Vietnamese', 'Vietnamese'],
    [ 'Welsh', 'Welsh'],
    [ 'Yemenite', 'Yemenite'],
    [ 'Zambian', 'Zambian'],
    [ 'Zimbabwean', 'Zimbabwean'].freeze
  
end
