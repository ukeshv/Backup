class UserMailer < ActionMailer::Base
  def signup_notification(user)
    setup_email(user)
    @subject << 'Please activate your new account'
    @bcc = "service@postadjust.org"
    @body[:url] = "#{APP_CONFIG[:site_url]}/activate/#{user.activation_code}"
  end
  
  def nonmember_signup_notification(user)
    setup_email(user)
    @bcc = "service@postadjust.org"
    @subject << 'Welcome to PostAdjust'
  end
  
  
  def activation(user)
    setup_email(user)
    @bcc = "service@postadjust.org"
    @subject << 'Your account has been activated!'
    @body[:url] = APP_CONFIG[:site_url]
  end
  
  def newsletter(user,ads,jobs,post_report,questions,duty_station)
          @recipients = "#{user.email}"
          @from = APP_CONFIG[:admin_email]
          @sent_on = Time.now
          @body[:user] = user
          @subject = 'News letter Notification'
          @body[:ads] = ads
          @body[:jobs] = jobs
          @body[:post_report] = post_report
          @body[:questions] = questions
          @body[:duty_station] = duty_station
          @content_type = "text/html"
  end
    
  def invite(invitation)
    @recipients = "#{invitation.email}"
    @from = APP_CONFIG[:admin_email]
    @sent_on = Time.now
    @body[:invitation] = invitation
    @subject = "Invitation from Postadjust"
    @body[:url] = "#{APP_CONFIG[:site_url]}/accept/#{invitation.invitation_code}"
  end 
  
  def feed_import_log(feed_import)
    @recipients = APP_CONFIG[:admin_email]
    @from = APP_CONFIG[:admin_email]
    @sent_on = Time.now
    @subject = "Feed Import Log"
    @body[:feed_import] = feed_import
  end 
  
  def contact_us_mail(enquiry)
    @recipients = APP_CONFIG[:admin_email]
    @from = "#{enquiry.email}"
    @sent_on = Time.now
    @subject = "#{enquiry.subject}"
    @body[:enquiry] = enquiry    
  end  
    
  protected
  
  def setup_email(user)
    @recipients = "#{user.email}"
    @from = APP_CONFIG[:admin_email]
    @subject = "[#{APP_CONFIG[:site_name]}] "
    @sent_on = Time.now
    @body[:user] = user
  end
end
