class UserPhoto < ActiveRecord::Base
	has_attachment :content_type => ['image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png'], :size => 0.megabyte..4.megabytes,:storage => :file_system,:thumbnails => { :large=> [120, 120],:thumb => [50, 50] }
	belongs_to :attachable,:polymorphic=>true
	
	def validate
    errors.add_to_base("You must choose a file to upload") unless self.filename

    unless self.filename == nil

      # Images should only be GIF, JPEG, or PNG
      [:content_type].each do |attr_name|
        enum = attachment_options[attr_name]
        unless enum.nil? || enum.include?(send(attr_name))
          errors.add(:content_type,"You can only upload images (JPG, GIF or PNG)")
        end
      end

      # Images should be less than 4 MB
      [:size].each do |attr_name|
        enum = attachment_options[attr_name]
        unless enum.nil? || enum.include?(send(attr_name))
          errors.add(:size,"Images should be smaller than 4 MB in size")
        end
      end

    end
  end
	
end

