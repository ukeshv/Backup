class UserPostReport < ActiveRecord::Base
	# Associations	
	belongs_to :user
	belongs_to :duty_station
	
	validates_presence_of :content ,:message=>'Content should be entered.'
	
end
