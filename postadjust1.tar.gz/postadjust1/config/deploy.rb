set :scm, :git
set :repository, "git@github.com:railsfactory/postadjust.git"
set :application, "postadjust"

set :amazon_address, "79.125.10.24"

set :deploy_to, "/var/www/apps/#{application}"
set :user, "deploy"
set :runner, "d3pl0y3n"
set :use_sudo, false

role :app, amazon_address
role :web, amazon_address
role :db,  amazon_address, :primary => true

namespace :init do
  desc "create database.yml"
  task :database_yml do
    set :db_user, "root"
    set :db_pass, "6naA3hTFj"
    database_configuration =<<-EOF
---
login: &login
  adapter: mysql
  database: #{application}_production
  host: localhost
  username: #{db_user}
  password: #{db_pass}

production:
  <<: *login

EOF
    run "mkdir -p #{shared_path}/config"
    put database_configuration, "#{shared_path}/config/database.yml"
  end

end

namespace :localize do
  desc "copy shared configurations to current"
  task :copy_shared_configurations, :roles => [:app] do
    %w[database.yml].each do |f|
      run "ln -nsf #{shared_path}/config/#{f} #{current_path}/config/#{f}"
    end
  end
	desc "copy shared images to current"

	task :copy_shared_images, :roles => [:app] do

    		run "mkdir -p #{current_path}/public/attachments"
		run "ln -nfs /var/www/apps/postadjust/shared/job_uploads /var/www/apps/postadjust/current/public/job_uploads"
		run "ln -nfs /var/www/apps/postadjust/shared/user_photos /var/www/apps/postadjust/current/public/user_photos"
		run "ln -nfs /var/www/apps/postadjust/shared/market_uploads /var/www/apps/postadjust/current/public/attachments/market_uploads"
		run "ln -nfs /var/www/apps/postadjust/shared/scraping /var/www/apps/postadjust/current/public/scraping"
	end
end

namespace :deploy do
  desc "Restart Application"
  task :restart, :roles => :app do
    run "touch #{current_path}/tmp/restart.txt"
	end
end

after "deploy:setup", "init:database_yml"
after "deploy:symlink", "localize:copy_shared_configurations"
after "deploy:symlink", "localize:copy_shared_images"

