ActionController::Routing::Routes.draw do |map|
 
  
  
   map.namespace(:admin) do |admin|
    admin.resources :email_domains
    admin.resources :duty_stations,:has_one=>[:post_report]
    admin.resources :organizations
    admin.resources :grades
    admin.resources :occupational_groups
    admin.resources :categories
    admin.resources :jobs
    admin.resources :post_reports
    admin.resources :user_post_reports
    admin.resources :users
    admin.resources :scrapers
    admin.resources :settings
    admin.resources :feed_imports
  end 
  
  map.namespace(:search) do |search|
    search.resources :jobs
    search.resources :markets
    search.resources :people
   end
  
  # Restful Authentication Rewrites
  map.logout '/logout', :controller => 'sessions', :action => 'destroy'
  map.login '/login', :controller => 'sessions', :action => 'new'
  map.register '/register', :controller => 'users', :action => 'create'
  map.signup '/signup', :controller => 'users', :action => 'new'
  map.accept '/accept/:invitation_code', :controller => 'users', :action => 'new', :invitation_code => nil
  map.activate '/activate/:activation_code', :controller => 'users', :action => 'activate', :activation_code => nil
  map.forgot_password '/forgot_password', :controller => 'passwords', :action => 'new'
  map.change_password '/change_password/:reset_code', :controller => 'passwords', :action => 'reset'
  map.open_id_complete '/opensession', :controller => "sessions", :action => "create", :requirements => { :method => :get }
  map.open_id_create '/opencreate', :controller => "users", :action => "create", :requirements => { :method => :get }
  map.profile '/profile/:id', :controller => 'users', :action => 'profile'
  map.dashboard '/questions/dashboard',:controller=>'questions',:action=>'dashboard'
  map.question_dashboard '/questions/dashboard.:format',:controller=>'questions',:action=>'dashboard'
  map.add_comments '/question/:id',:controller=>'questions',:action=>'add_comments'
  map.adv_search '/people/adv_search',:controller=>'search/people',:action=>'index'
  map.contact_us 'contact_us', :controller =>'sessions', :action => 'contact_us'
  
  map.display_edit_email_domain '/display_edit_email_domain/:id', :controller => 'admin/email_domains', :action => 'edit'
  map.search_email_domain '/search_email_domain', :controller => 'admin/email_domains', :action => 'search'
  map.delete_email_domains '/delete_email_domains', :controller => 'admin/email_domains', :action => 'delete_email_domains'
  
  map.display_edit_duty_station '/display_edit_duty_station/:id', :controller => 'admin/duty_stations', :action => 'edit'
  map.search_duty_station '/search_duty_station', :controller => 'admin/duty_stations', :action => 'search'
  map.delete_duty_stations '/delete_duty_stations', :controller => 'admin/duty_stations', :action => 'delete_duty_stations'
  
  map.display_edit_organization '/display_edit_organization/:id', :controller => 'admin/organizations', :action => 'edit'
  map.search_organization '/search_organization',:controller=>'admin/organizations',:action=>'search'
  map.delete_organizations '/delete_organizations', :controller => 'admin/organizations', :action => 'delete_organizations'
  
  map.display_edit_grade '/display_edit_grade/:id', :controller => 'admin/grades', :action => 'edit'
  map.search_grade '/search_grade',:controller=>'admin/grades',:action=>'search'
  map.delete_grades '/delete_grades', :controller => 'admin/grades', :action => 'delete_grades'
  
  map.display_edit_occupational_group '/display_edit_occupational_group/:id', :controller => 'admin/occupational_groups', :action => 'edit'
  map.search_occupational_group '/search_occupational_group',:controller=>'admin/occupational_groups',:action=>'search'
  map.delete_occupational_groups '/delete_occupational_groups', :controller => 'admin/occupational_groups', :action => 'delete_occupational_groups'
  
  map.display_edit_category '/display_edit_category/:id', :controller => 'admin/categories', :action => 'edit'
  map.display_edit_job '/display_edit_job/:id', :controller => 'jobs', :action => 'edit'
  map.delete_categories '/delete_categories', :controller => 'admin/categories', :action => 'delete_categories'
  
  map.move_category '/move_category/:id', :controller => 'admin/categories', :action => 'move_category'
  
  map.approve_user_post_report '/approve_user_post_report/:id', :controller => 'admin/user_post_reports', :action =>'approve' 
  
  map.post_report_revision '/post_report_revision/:id', :controller => 'post_reports',:action =>'revision'
  map.post_report_edit_revision '/post_report_revision/:id/edit', :controller => 'post_reports',:action =>'edit_revision'
  map.post_report_update_revision '/post_report_revision/:id/update', :controller => 'post_reports',:action =>'update_revision'
  
  map.about_us 'about_us' ,:controller => 'sessions', :action =>'about_us' #About us Page
  map.supported_organizations 'organizations' ,:controller => 'sessions', :action =>'supported_organizations' #Supported Organizations Page
  map.latest_activities_feed 'latest_activities_feed' ,:controller => 'users', :action =>'rss'
  map.marketplace_feed 'marketplace_feed' ,:controller => '/search/markets', :action =>'rss'
  map.jobs_feed 'jobs_feed' ,:controller => '/search/jobs', :action =>'rss'
  map.questions_feed 'questions_feed' ,:controller => 'questions', :action =>'rss'
  
  map.search_user '/search_user',:controller=>'admin/users',:action=>'search'
  map.market_active_media 'market_active_media/:id' , :controller=>'markets',:action=>'active_media' 
  map.admin_user_remove_admin_rights 'admin/users/remove_admin_rights/:id',:controller=>'admin/users',:action=>'remove_admin_rights'
  
  map.user_invitation '/users/invitation',:controller=>'/users', :action=>'invitation'
  map.search_scraper '/search_scraper',:controller=>'admin/scrapers',:action=>'search'
  map.view_log '/view_log/:id',:controller=>'admin/scrapers',:action=>'view_log'
  map.view_xml '/view_xml/:id',:controller=>'admin/scrapers',:action=>'view_xml'
  map.download_xml '/download_xml/:id/:filename',:controller=>'admin/scrapers',:action=>'download_xml'
  map.download_csv '/download_csv/:id/:filename',:controller=>'admin/scrapers',:action=>'download_csv'
  map.download_log '/download_log/:id/:filename',:controller=>'admin/scrapers',:action=>'download_log'
  map.import_contacts '/import_contacts', :controller=>'/users',:action=>'import_contacts'
  map.contact_list '/contact_list', :controller=>'/users',:action=>'contact_list'
  
  map.change_scrapers_status '/change_scrapers_status', :controller => 'admin/scrapers', :action => 'change_scrapers_status'  
  map.change_feed_imports_status '/change_feed_imports_status', :controller => 'admin/feed_imports', :action => 'change_feed_imports_status'  
  

  # Restful Authentication Resources
  map.resources :users
  map.resources :passwords
  map.resource :session
  map.resources :jobs
  map.resources :markets
  map.resources :questions
  map.resources :post_reports

  # Home Page
  map.root :controller => 'sessions', :action => 'index'

  # Install the default routes as the lowest priority.
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
end
