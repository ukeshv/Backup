class BortMigration < ActiveRecord::Migration
  def self.up
    # Create Sessions Table
    create_table :sessions do |t|
      t.string :session_id, :null => false
      t.text :data
      t.timestamps
    end

    add_index :sessions, :session_id
    add_index :sessions, :updated_at
    
    # Create OpenID Tables
    create_table :open_id_authentication_associations, :force => true do |t|
      t.integer :issued, :lifetime
      t.string :handle, :assoc_type
      t.binary :server_url, :secret
    end

    create_table :open_id_authentication_nonces, :force => true do |t|
      t.integer :timestamp, :null => false
      t.string :server_url, :null => true
      t.string :salt, :null => false
    end
    
    # Create Users Table
    create_table :users do |t|
      t.string :email, :limit => 100
      t.string :firstname, :limit => 100
      t.string :lastname, :limit => 100
      t.integer :duty_station_id
      t.integer :organization_id
      t.integer :occupational_group_id
      t.string :nationality, :limit => 100
      t.string :phone, :limit => 25
      t.string :linkedin, :limit => 100
      t.string :orkut, :limit => 100
      t.string :facebook, :limit => 100
      t.string :twitter, :limit => 100
      t.string :xing, :limit => 100
      t.boolean :is_newsletter_notification
      t.string :crypted_password, :limit => 40
      t.string :salt, :limit => 40
      t.string :activation_code, :limit => 40
      t.datetime :activated_at
      t.boolean :status,:default=>true
      t.string :remember_token, :limit => 40
      t.datetime :remember_token_expires_at
      t.datetime :deleted_at
      t.timestamps
      t.string :identity_url 
      t.string :login 
      t.string :state, :null => false, :default => 'passive'  
    end   
    
    # Create Passwords Table
    create_table :passwords do |t|
      t.integer :user_id
      t.string :reset_code
      t.datetime :expiration_date
      t.timestamps
    end
    
    # Create Roles Databases
    create_table :roles do |t|
      t.string :name
    end
    
    create_table :roles_users, :id => false do |t|
      t.belongs_to :role
      t.belongs_to :user
    end
    
    # Create admin role
    admin_role = Role.create(:name => 'admin')
    user_role = Role.create(:name => 'user')
    
    # Create default admin user
    user = User.create do |u|
      u.email = APP_CONFIG[:admin_email]
      u.password = u.password_confirmation = 'postadjust'
      u.firstname = "Admin"
      u.is_user = false
      u.duty_station_id = 1
    end
    
    # Activate user
    user.register!
    user.activate!
    
    # Add admin role to admin user
    user.roles << admin_role
  end

  def self.down
    # Drop all Bort tables
    drop_table :sessions
    drop_table :users
    drop_table :passwords
    drop_table :roles
    drop_table :roles_users
    drop_table :open_id_authentication_associations
    drop_table :open_id_authentication_nonces
  end
end
