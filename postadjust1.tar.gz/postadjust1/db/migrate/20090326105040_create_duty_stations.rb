class CreateDutyStations < ActiveRecord::Migration
  def self.up
    create_table :duty_stations do |t|
      t.string :name,:limit=>100
      t.integer :country_id
      t.boolean :status
      t.timestamps
    end
    DutyStation.create(:name=>APP_CONFIG[:default_duty_station],:country_id=>APP_CONFIG[:default_country_id],:status=>true)
  end

  def self.down
    drop_table :duty_stations
  end
end
