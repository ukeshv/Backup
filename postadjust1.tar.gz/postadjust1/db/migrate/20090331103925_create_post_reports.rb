class CreatePostReports < ActiveRecord::Migration
  def self.up
    create_table :post_reports do |t|
      t.text :content
      t.integer :duty_station_id
      t.timestamps
    end
  end

  def self.down
    drop_table :post_reports
  end
end
