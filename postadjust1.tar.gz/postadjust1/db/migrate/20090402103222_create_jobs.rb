class CreateJobs < ActiveRecord::Migration
  def self.up
    create_table :jobs do |t|
      t.integer :user_id
      t.string :title
      t.integer :organization_id
      t.integer :occupational_group_id
      t.integer :duty_station_id
      t.integer :grade_id
      t.datetime :closing_date
      t.boolean :status
      t.text :description
      t.text :contact_info

      t.timestamps
    end
  end

  def self.down
    drop_table :jobs
  end
end
