class CreateQuestions < ActiveRecord::Migration
  def self.up
    create_table :questions do |t|
	t.integer :user_id
	t.integer :duty_station_id 
	t.string :title
	t.text :description 
	t.string :question_type,:limit=> 100
	t.boolean :is_anonymous
	t.string :latitude 
	t.string :longitude
      t.timestamps
    end
  end

  def self.down
    drop_table :questions
  end
end
