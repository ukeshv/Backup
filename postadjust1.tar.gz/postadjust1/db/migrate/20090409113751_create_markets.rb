class CreateMarkets < ActiveRecord::Migration
  def self.up
    create_table :markets do |t|
      t.integer :user_id
      t.integer :category_id
      t.integer :duty_station_id
      t.string :ads_type
      t.string :title
      t.text :description
      t.float :price
      t.string :currency_format
      t.boolean :use_my_contact_info
      t.string :email
      t.string :phone
      t.boolean :status

      t.timestamps
    end
  end

  def self.down
    drop_table :markets
  end
end
