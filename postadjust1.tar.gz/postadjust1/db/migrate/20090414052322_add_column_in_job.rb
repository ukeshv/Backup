class AddColumnInJob < ActiveRecord::Migration
  def self.up
    add_column :jobs,:jobsite,:string
  end

  def self.down
    remove_column :jobs,:jobsite
  end
end
