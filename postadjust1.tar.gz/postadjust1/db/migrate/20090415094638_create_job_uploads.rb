class CreateJobUploads < ActiveRecord::Migration
  def self.up
    create_table :job_uploads do |t|
    t.integer :attachable_id 
    t.string :attachable_type,:limit =>100
    t.string :content_type ,:limit => 100 
    t.string :filename 
    t.integer :size 
    t.integer :parent_id
    t.string :thumbnail ,:limit=> 100 
    t.integer :width 
    t.integer :height 
    t.timestamps
    end
  end

  def self.down
    drop_table :job_uploads
  end
end
