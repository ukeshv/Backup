class CreateUserPostReports < ActiveRecord::Migration
  def self.up
    create_table :user_post_reports do |t|
      t.integer :user_id
      t.integer :duty_station_id
      t.text :content
      t.boolean :is_approved , :default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :user_post_reports
  end
end
