class AddColumnsInPostReport < ActiveRecord::Migration
  def self.up
    add_column :post_reports, :user_id, :integer
    add_column :post_reports, :reason, :text
    ds = DutyStation.find(:first)
    user = User.find(:first)
    ds.create_post_report(:user_id=>user.id)
  end

  def self.down
    remove_column :post_reports, :user_id
    remove_column :post_reports, :reason
  end
end
