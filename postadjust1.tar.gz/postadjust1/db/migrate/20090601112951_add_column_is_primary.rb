class AddColumnIsPrimary < ActiveRecord::Migration
  def self.up
    add_column :attachings, :is_primary , :boolean ,:default=>false
  end

  def self.down
    remove_column :attachings, :is_primary
  end
end
