class CreateScrapers < ActiveRecord::Migration
  def self.up
    create_table :scrapers do |t|
      t.string :domain
      t.string :classname
      t.string :filename
      t.datetime :last_run_at
      t.boolean :status,:default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :scrapers
  end
end
