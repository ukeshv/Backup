class CreateSettings < ActiveRecord::Migration
  def self.up
    create_table :settings do |t|
      t.integer :max_invite
      t.timestamps
    end
    Setting.create(:max_invite=>5)
  end

  def self.down
    drop_table :settings
  end
end
