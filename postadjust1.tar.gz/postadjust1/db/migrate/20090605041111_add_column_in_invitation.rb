class AddColumnInInvitation < ActiveRecord::Migration
  def self.up
    add_column :invitations, :firstname, :string
    add_column :invitations, :lastname, :string
    add_column :invitations, :message, :text
    add_column :scrapers, :url, :string
    add_column :jobs, :domain, :string
    add_column :jobs, :source_id, :integer
  end

  def self.down
    remove_column :invitations, :firstname
    remove_column :invitations, :lastname
    remove_column :invitations, :message
    remove_column :scrapers, :url
    remove_column :jobs, :domain
    remove_column :jobs, :source_id
  end
end
