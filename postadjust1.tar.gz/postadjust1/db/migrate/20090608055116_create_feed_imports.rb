class CreateFeedImports < ActiveRecord::Migration
  def self.up
    create_table :feed_imports do |t|
      t.string :url
      t.string :frequency
      t.datetime :last_import_at
      t.boolean :status,:default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :feed_imports
  end
end
