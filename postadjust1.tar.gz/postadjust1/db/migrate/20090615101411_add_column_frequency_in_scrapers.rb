class AddColumnFrequencyInScrapers < ActiveRecord::Migration
  def self.up
    add_column :scrapers, :frequency, :string
  end

  def self.down
    remove_column :scrapers, :frequency
  end
end
