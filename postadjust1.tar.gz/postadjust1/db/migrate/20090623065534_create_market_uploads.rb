class CreateMarketUploads < ActiveRecord::Migration
  def self.up
    create_table :market_uploads do |t|
      t.integer :parent_id
      t.string :parent_type
      t.string :content_type
      t.string :filename
      t.string :thumbnail
      t.integer :size
      t.integer :height
      t.integer :width
      t.boolean :is_primary ,:default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :market_uploads
  end
end
