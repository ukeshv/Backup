class CreateRecordInCountryAndDutyStation < ActiveRecord::Migration
  def self.up
    c=Country.create(:country_name=>'Other',:country_code=>'N/A')
    DutyStation.create(:name=>'Other',:country_id=>c.id,:status=>false)
  end

  def self.down
  end
end
