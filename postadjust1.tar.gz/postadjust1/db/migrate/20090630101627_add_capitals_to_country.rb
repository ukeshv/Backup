class AddCapitalsToCountry < ActiveRecord::Migration
  def self.up
    add_column :countries, :capital, :string
    country_with_capitals_file = File.expand_path(File.join(RAILS_ROOT, 'db/countries_with_capitals.csv'))
    sql = ActiveRecord::Base.connection();
    sql.execute "delete from countries"
    sql.execute "ALTER TABLE countries AUTO_INCREMENT=0"
    sql.execute "LOAD DATA INFILE '#{country_with_capitals_file}' INTO TABLE countries  FIELDS TERMINATED BY ';' ENCLOSED BY '\"' LINES TERMINATED BY '\n' (continent_code,country_code,country_3code,country_number,country_name,capital)";
    c=Country.create(:country_name=>'Other',:country_code=>'N/A')
    DutyStation.create(:name=>'Other',:country_id=>c.id,:status=>false)
  end

  def self.down
    remove_column :countries, :capital
  end
end
