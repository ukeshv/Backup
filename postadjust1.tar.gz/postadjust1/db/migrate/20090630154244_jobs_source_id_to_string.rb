class JobsSourceIdToString < ActiveRecord::Migration
  def self.up
    change_column :jobs, :source_id, :string
  end

  def self.down
    change_column :jobs, :source_id, :integer
  end
end
