class AddCapitalsAsDutystations < ActiveRecord::Migration
  def self.up
    countries = Country.find(:all)
    countries.each do |c|
      DutyStation.create(:name=>c.capital,:country_id=>c.id,:status=>false)
    end
  end

  def self.down
  end
end
