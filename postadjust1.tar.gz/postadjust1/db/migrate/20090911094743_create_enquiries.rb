class CreateEnquiries < ActiveRecord::Migration
  def self.up
    create_table :enquiries do |t|
      t.string :email, :limit =>50
      t.string :subject, :limit =>100
      t.text :message
      t.timestamps
    end
  end

  def self.down
    drop_table :enquiries
  end
end
