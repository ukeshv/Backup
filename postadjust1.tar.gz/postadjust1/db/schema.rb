# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20090911094743) do

  create_table "assets", :force => true do |t|
    t.string   "data_file_name"
    t.string   "data_content_type"
    t.integer  "data_file_size"
    t.integer  "attachings_count",  :default => 0
    t.datetime "created_at"
    t.datetime "data_updated_at"
  end

  create_table "attachings", :force => true do |t|
    t.integer  "attachable_id"
    t.integer  "asset_id"
    t.string   "attachable_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "is_primary",      :default => false
  end

  add_index "attachings", ["asset_id"], :name => "index_attachings_on_asset_id"
  add_index "attachings", ["attachable_id"], :name => "index_attachings_on_attachable_id"

  create_table "categories", :force => true do |t|
    t.string   "name"
    t.integer  "parent_id"
    t.integer  "position"
    t.boolean  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "comments", :force => true do |t|
    t.string   "title",            :limit => 50, :default => ""
    t.text     "comment"
    t.integer  "commentable_id",                 :default => 0,  :null => false
    t.string   "commentable_type", :limit => 15, :default => "", :null => false
    t.integer  "user_id",                        :default => 0,  :null => false
    t.boolean  "is_anonymous"
    t.datetime "created_at",                                     :null => false
    t.string   "latitude"
    t.string   "longitude"
  end

  add_index "comments", ["user_id"], :name => "fk_comments_user"

  create_table "countries", :force => true do |t|
    t.string "continent_code"
    t.string "country_code"
    t.string "country_3code"
    t.string "country_number"
    t.string "country_name"
    t.string "capital"
  end

  create_table "duty_stations", :force => true do |t|
    t.string   "name",       :limit => 100
    t.integer  "country_id"
    t.boolean  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "email_domains", :force => true do |t|
    t.string   "domain",     :limit => 100
    t.boolean  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "enquiries", :force => true do |t|
    t.string   "email",      :limit => 50
    t.string   "subject",    :limit => 100
    t.text     "message"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "feed_imports", :force => true do |t|
    t.string   "url"
    t.string   "frequency"
    t.datetime "last_import_at"
    t.boolean  "status",         :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "grades", :force => true do |t|
    t.string   "name",       :limit => 100
    t.boolean  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "invitations", :force => true do |t|
    t.string   "invitation_code", :limit => 40
    t.integer  "user_id"
    t.integer  "invited_id"
    t.string   "email",           :limit => 100
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "firstname"
    t.string   "lastname"
    t.text     "message"
  end

  create_table "job_uploads", :force => true do |t|
    t.integer  "attachable_id"
    t.string   "attachable_type", :limit => 100
    t.string   "content_type",    :limit => 100
    t.string   "filename"
    t.integer  "size"
    t.integer  "parent_id"
    t.string   "thumbnail",       :limit => 100
    t.integer  "width"
    t.integer  "height"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "jobs", :force => true do |t|
    t.integer  "user_id"
    t.string   "title"
    t.integer  "organization_id"
    t.integer  "occupational_group_id"
    t.integer  "duty_station_id"
    t.integer  "grade_id"
    t.datetime "closing_date"
    t.boolean  "status"
    t.text     "description"
    t.text     "contact_info"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "jobsite"
    t.string   "domain"
    t.string   "source_id"
  end

  create_table "market_uploads", :force => true do |t|
    t.integer  "parent_id"
    t.string   "parent_type"
    t.string   "content_type"
    t.string   "filename"
    t.string   "thumbnail"
    t.integer  "size"
    t.integer  "height"
    t.integer  "width"
    t.boolean  "is_primary",   :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "markets", :force => true do |t|
    t.integer  "user_id"
    t.integer  "category_id"
    t.integer  "duty_station_id"
    t.string   "ads_type"
    t.string   "title"
    t.text     "description"
    t.float    "price"
    t.string   "currency_format"
    t.boolean  "use_my_contact_info"
    t.string   "email"
    t.string   "phone"
    t.boolean  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "occupational_groups", :force => true do |t|
    t.string   "name"
    t.boolean  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "open_id_authentication_associations", :force => true do |t|
    t.integer "issued"
    t.integer "lifetime"
    t.string  "handle"
    t.string  "assoc_type"
    t.binary  "server_url"
    t.binary  "secret"
  end

  create_table "open_id_authentication_nonces", :force => true do |t|
    t.integer "timestamp",  :null => false
    t.string  "server_url"
    t.string  "salt",       :null => false
  end

  create_table "organizations", :force => true do |t|
    t.string   "name"
    t.string   "website",    :limit => 100
    t.boolean  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "passwords", :force => true do |t|
    t.integer  "user_id"
    t.string   "reset_code"
    t.datetime "expiration_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "post_reports", :force => true do |t|
    t.text     "content"
    t.integer  "duty_station_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "user_id"
    t.text     "reason"
  end

  create_table "questions", :force => true do |t|
    t.integer  "user_id"
    t.integer  "duty_station_id"
    t.string   "title"
    t.text     "description"
    t.string   "question_type",   :limit => 100
    t.boolean  "is_anonymous"
    t.string   "latitude"
    t.string   "longitude"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "roles", :force => true do |t|
    t.string "name"
  end

  create_table "roles_users", :id => false, :force => true do |t|
    t.integer "role_id"
    t.integer "user_id"
  end

  create_table "scrapers", :force => true do |t|
    t.string   "domain"
    t.string   "classname"
    t.string   "filename"
    t.datetime "last_run_at"
    t.boolean  "status",      :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "url"
    t.string   "frequency"
  end

  create_table "sessions", :force => true do |t|
    t.string   "session_id", :null => false
    t.text     "data"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "sessions", ["session_id"], :name => "index_sessions_on_session_id"
  add_index "sessions", ["updated_at"], :name => "index_sessions_on_updated_at"

  create_table "settings", :force => true do |t|
    t.integer  "max_invite"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tiny_mce_photos", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.integer  "user_id"
    t.string   "content_type"
    t.string   "filename"
    t.integer  "size"
    t.integer  "parent_id"
    t.string   "thumbnail"
    t.integer  "width"
    t.integer  "height"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "user_photos", :force => true do |t|
    t.integer  "attachable_id"
    t.string   "attachable_type", :limit => 100
    t.string   "content_type",    :limit => 100
    t.string   "filename"
    t.integer  "size"
    t.integer  "parent_id"
    t.string   "thumbnail",       :limit => 100
    t.integer  "width"
    t.integer  "height"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "user_post_reports", :force => true do |t|
    t.integer  "user_id"
    t.integer  "duty_station_id"
    t.text     "content"
    t.boolean  "is_approved",     :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.string   "email",                      :limit => 100
    t.string   "firstname",                  :limit => 100
    t.string   "lastname",                   :limit => 100
    t.integer  "duty_station_id"
    t.integer  "organization_id"
    t.integer  "occupational_group_id"
    t.string   "nationality",                :limit => 100
    t.string   "phone",                      :limit => 25
    t.string   "linkedin",                   :limit => 100
    t.string   "orkut",                      :limit => 100
    t.string   "facebook",                   :limit => 100
    t.string   "twitter",                    :limit => 100
    t.string   "xing",                       :limit => 100
    t.boolean  "is_newsletter_notification"
    t.string   "crypted_password",           :limit => 40
    t.string   "salt",                       :limit => 40
    t.string   "activation_code",            :limit => 40
    t.datetime "activated_at"
    t.boolean  "status",                                    :default => true
    t.string   "remember_token",             :limit => 40
    t.datetime "remember_token_expires_at"
    t.datetime "deleted_at"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "identity_url"
    t.string   "login"
    t.string   "state",                                     :default => "passive", :null => false
    t.text     "about_me"
    t.integer  "max_invite",                                :default => 0
  end

end
