require 'rubygems'
require 'mechanize'
require 'hpricot'
MAX_TRY = 5

class UnJobsOrganisationScraper
	
	#Method to fetch jobs as an Array
	def fetch_jobs_xml(url,domain,error_file_path)
			agent = WWW::Mechanize.new
			main = nil
			retrycount = 0
			
			begin
			 main = agent.get(url)
			rescue Timeout::Error
				if(retrycount < MAX_TRY)
					retrycount+=1
						File.open(error_file_path, 'a') do |f|
						f.write "Logfile created on #{Time.now}\n"
						f.write "err:#{$!} retrying Timeout\t"
						end
					sleep(2)
					retry
				 end
			rescue
				File.open(error_file_path, 'a') do |f|
						f.write "Logfile created on #{Time.now}\n"
						f.write "Fail - #{url}"
				end
			end

			return []  if main.nil?
			return result(main,domain)
	end

	#Method to push results obtained from each row into an Array
	def result(main,domain)
		main_rows = main.at("table[@class='jobs']").search("tr")

		arr = []
		# exclude titles of the table
		main_rows.shift

		main_rows.each do |row|
			 arr << scrapedResults(row,domain)
		 end
		 arr
	end

	#Method to fetch value of all fields in each row
	def scrapedResults(row,domain)
		h={}
		tds = row.search("td")	
		 h[:organisation] = tds[0].inner_text.scan(/[A-Za-z0-9 ]/).to_s.strip
		h[:duty_station] = tds[1].inner_text.strip.chop
		h[:grade] = tds[2].inner_text.scan(/[-A-Za-z0-9() ]/).to_s.strip
		h[:contractType] = tds[3].inner_text.strip.chop
		h[:title] = tds[4].at("a").inner_text.strip
		h[:jobsite] = tds[4].at("a")['href']+'?accepted=true'
		h[:closing_date] = tds[5].inner_text.scan(/[A-Za-z0-9]/).to_s.strip
		h[:postingRetrieved] = tds[6].inner_text.strip
		id = tds[4].at("a")['href'].split("http://unjoblist.org/lists/redirect/")
		h[:source_id] = id[1].chop
		h[:domain] = domain
		h
		rescue
		{}
	end

end