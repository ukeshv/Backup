// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults

  function check_all(current_obj_class)
  {
	var check_boxes= document.getElementsByClassName(current_obj_class);
	for(i=0;i<check_boxes.length;i++){
	check_boxes[i].checked=true;
	}
	}
    
  function uncheck_all(current_obj_class)
  {
    var check_boxes= document.getElementsByClassName(current_obj_class);
	for(i=0;i<check_boxes.length;i++){
	check_boxes[i].checked=false;
	}
	}
	
	function job_check_all(val,current_obj_class)
	{
	if (val == true)
	{
	check_all(current_obj_class)
	}
	else
	{
	uncheck_all(current_obj_class)
	}
	}
	
	function market_check_all(val,current_obj_class)
	{
	if (val == true)
	{
	check_all(current_obj_class)
	}
	else
	{
	uncheck_all(current_obj_class)
	}
	}
	
	function get_email_domains(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
	new Ajax.Request("/delete_email_domains/?email_domain_ids="+arr,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
	}
	
	function get_duty_stations(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
	new Ajax.Request("/delete_duty_stations/?duty_station_ids="+arr,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
	}
	
	function get_organizations(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
	new Ajax.Request("/delete_organizations/?organization_ids="+arr,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
	}
	
	function get_grades(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
	new Ajax.Request("/delete_grades/?grade_ids="+arr,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
	}
	
	function get_occupational_groups(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
	new Ajax.Request("/delete_occupational_groups/?occupational_group_ids="+arr,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
	}
	
	function get_categories(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
	new Ajax.Request("/delete_categories/?category_ids="+arr,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
	}

	
	function get_jobs(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
	if (arr.length > 0){	
	new Ajax.Request("/jobs/delete_jobs/?job_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	}
	else{
	Element.hide('flashmsg');
	Element.show('select_one');
	$('select_one').innerHTML += "<font color='red'>Select Job(s) to delete</font>"
	return false
	}
	}
	
	function get_jobs_approve(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
	if (arr.length > 0){
	new Ajax.Request("/admin/jobs/approve_jobs/?job_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	Element.hide('sel_job');
		}
	else {
	$('sel_job').innerHTML = "<font color='red'>Select job(s) to approve</font>"
	Element.show('sel_job');
	return false
	}
	}
	
	function get_jobs_reject(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
	if (arr.length > 0){
	new Ajax.Request("/admin/jobs/reject_jobs/?job_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	Element.hide('sel_job');
		}
	else {
	$('sel_job').innerHTML = "<font color='red'>Select job(s) to reject</font>"
	Element.show('sel_job');
	return false
	}
	}
	
	function get_markets(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
		if (arr.length > 0){
  	new Ajax.Request("/markets/delete_markets/?market_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
		Element.hide('select_one');
		$('flashNotice').innerHTML = "<font color='green'>Selected Ad(s) are successfully deleted</font>"
		Element.show('flashNotice')
		}
	else {
	Element.hide('flashmsg');
	Element.show('select_one');
	$('select_one').innerHTML = "<font color='red'>Select Ad(s) to delete</font>"
	return false
	}
	}
	
	function get_questions(current_obj_class)
       {
       var check_boxes= document.getElementsByClassName(current_obj_class);
       arr = [ ];
               for(i=0;i<check_boxes.length;i++){
                       if(check_boxes[i].checked==true)
                       arr.push(check_boxes[i].value);
               }    
	if (arr.length > 0){
	new Ajax.Request("/questions/delete_questions/?question_ids="+arr,{asynchronous:true, evalScripts:true,insertion:Insertion.Top}); return false;
	Element.hide('select_one');
	Element.show('flashNotice')
       }
       	else {
	$('select_one').innerHTML = "<font color='red'>Select question(s) to delete</font>"
	Element.hide('flashNotice');
	Element.show('select_one');
	return false
	}
	}


	
	function more_duty_station_jobs()
	{
	new Ajax.Request(document.myform.action,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top, parameters:$('myform').serialize(true)}); return false;		
	}
	
	function change_resultset(selected_dutystation,current_controller)
	{
	if((selected_dutystation != 0) && (current_controller != "jobs")) 
	document.dutystation_form.submit();
	}

	function change_peopledisplay(selected_dutystation)
	{
	if((selected_dutystation != 0)) 
	document.people_dutystation_form.submit();
	}


function check_attachment_file(){
var file_path = $('market_data').value
var file = file_path.toLowerCase()
if (file.length > 0)
{
	if ((file.match('.jpg') == '.jpg') || (file.match('.gif') == '.gif') || (file.match('.png') == '.png') || (file.match('.jpeg') == '.jpeg')){
	return true;
	}
	else{
	$('file_error').innerHTML = "<font color='red'>You can upload only .jpg,.gif,.png and .jpeg files</font>"
	return false;
  }
	}	
}

function control_check_attachment_file(){
var file_path = $('data').value
var file = file_path.toLowerCase()
if ((file.match('.jpg') == '.jpg') || (file.match('.gif') == '.gif') || (file.match('.png') == '.png') || (file.match('.jpeg') == '.jpeg')){
return true;
}
else{
$('file1_error').innerHTML = "<font color='red'>You can upload only .jpg,.gif,.png and .jpeg files</font>"
return false;
}
}

function toggle_button()
{
if ($('terms').checked == false)
{
$('term_error').innerHTML="<font color='red'>Please select the Terms of Service.</font>"
return false;
}
}

function count_image(len){
if (len >= 5){
alert("You can upload 5 pictures maximum for an Ad")
return false;
}
else{
return true;
}
}

function getSelectedValueForJob(val)
{
Element.show('ajax-loader')
station_selected_value = val;
}
function disableLoadingForJob(){
Element.hide('ajax-loader')
}

function getSelectedValueForAd(val)
{
Element.show('ajax-loader1')
station_selected_value = val;
}
function disableLoadingForAd(){
Element.hide('ajax-loader1')
}

	function form_xml()
	{
		 var cur_url = window.location.href;
                        var base_url = cur_url.split("/users");
                        var url = base_url[0]+"/latest_activities_feed"+base_url[1];
                        $('rss_link_ad').href = url
	}
	
function getSelectedValue(val)
{
if(val != 0)
{
Element.show('ajax-loader')
document.myform.submit();
}
}

function disableLoading(){
Element.hide('ajax-loader')
}

function display_category(id){
new Ajax.Request('categories?category_id='+id,{asynchronous:true, evalScripts:true,method:'get',onComplete:function(request){$('ajax-loader').hide();},onLoading:function(request){$('ajax-loader').show();}}) 
return false;
}

function comment_show_map() {
$('comment_one').hide();
$('show_map').show();
}

function comment_hide_map() {
$('comment_one').show();
$('show_map').hide();
}

function check_postquestion(){
type = $('question_question_type').value;
description = $('question_description').value;
if (type == '' && description == ''){
 $('type_error').show();
 $('desc_error').show();
 return false;
}
else if (type==''){
 $('type_error').show();
 $('desc_error').hide();

 return false;
 }
 else if (description == ''){
 $('desc_error').show();
 $('type_error').hide();
  return false;
 }
}

function check_search(){
  search_val = $('search_description').value
  if (search_val == ''){
    $('show_error').show();
    return false;
   }
   else {
     return true;
   }
}

function check_content(){
contents = tinyMCE.activeEditor.getContent();
if (contents.length==0){
$('content_error').innerHTML = "<font color='red'> Content should be entered</font>"
return false;
}
}

function check_content1(){
contents = tinyMCE.activeEditor.getContent();
if (contents.length==0){
$('content_error1').innerHTML = "<font color='red'> Content should be entered</font>"
return false;
}
}

	function form_xml_dashboard()
	{
		 var cur_url = window.location.href;
                        var base_url = cur_url.split("/questions/dashboard");
                        var url = base_url[0]+"/questions_feed"+base_url[1];
                        $('rss_link_ad').href = url
	}
	
		function form_xml_jobs()
	{
		 var cur_url = window.location.href;
                        var base_url = cur_url.split("/search/jobs");
                        var url = base_url[0]+"/jobs_feed"+base_url[1];
                        $('rss_link_ad').href = url
	}
	
		function form_xml_market()
	{
		 var cur_url = window.location.href;
                        var base_url = cur_url.split("/search/markets");
                        var url = base_url[0]+"/marketplace_feed"+base_url[1];
                        $('rss_link_ad').href = url
	}
	
		function get_contacts(current_obj_class)
		{
			var check_boxes= document.getElementsByClassName(current_obj_class);
			arr = [ ];
			for(i=0;i<check_boxes.length;i++){
				if(check_boxes[i].checked==true)
				arr.push(check_boxes[i].value);
			}
			if (arr.length == 0){
				Element.hide('flashmsg');
				Element.show('select_one');
				$('select_one').innerHTML = "<font color='red'>Select contact to import</font>"
				return false;
			}
			else{
				Element.hide('select_one');
				return true;
			}
		}