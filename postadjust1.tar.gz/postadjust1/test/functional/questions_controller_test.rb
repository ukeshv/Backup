require 'test_helper'

class QuestionsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:questions)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create questions" do
    assert_difference('Questions.count') do
      post :create, :questions => { }
    end

    assert_redirected_to questions_path(assigns(:questions))
  end

  test "should show questions" do
    get :show, :id => questions(:one).id
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => questions(:one).id
    assert_response :success
  end

  test "should update questions" do
    put :update, :id => questions(:one).id, :questions => { }
    assert_redirected_to questions_path(assigns(:questions))
  end

  test "should destroy questions" do
    assert_difference('Questions.count', -1) do
      delete :destroy, :id => questions(:one).id
    end

    assert_redirected_to questions_path
  end
end
