class AcquisitionsController < ApplicationController
  before_filter :login_required, :find_asset_manager
  layout 'user',:except=>['search', 'save_note', 'request_due_dil', 'deny_comments']
  include NotesHelper
  @@jus_saved = false
  @@time = Time.now
  helper_method :find_just_saved,:erase_just_saved
  
  def index
    sql_finder = "SELECT  properties.*
                  FROM properties,property_collateral_details
                  WHERE
                    properties.user_id <> #{current_user.id} AND
                    properties.state_id = 2 AND
                    properties.is_granted = 0   AND
                    properties.id NOT IN (select distinct property_id from property_state_logs where user_id = #{current_user.id} and property_id = properties.id and state_id  IN(3,6,4,5) ) AND
                    property_collateral_details.property_id = properties.id AND
                    properties.occupancy IS NOT NULL"
    @properties = Property.find_by_sql(sql_finder)
    if @properties.count > 0 # The following max query includes sale price and cap rate still ...
      max_sql = "SELECT MAX(properties.sale_price) as sale_max, MIN(properties.sale_price) as sale_min, MAX(properties.cap_rate) as cap_max, MIN(properties.cap_rate) as cap_min, MAX(properties.current_outstanding) as out_max,
                    MIN(properties.current_outstanding) as out_min, MAX(property_collateral_details.property_size) as size_max, MIN(property_collateral_details.property_size) as size_min,
	                  MAX(properties.occupancy) as occ_max, MIN(properties.occupancy)as occ_min,MAX(properties.annualized_noi) as ann_max, MIN(properties.annualized_noi) as ann_min
                 FROM properties,property_collateral_details,rent_rolls
                 WHERE
                  properties.user_id  <> #{current_user.id} AND
                  properties.state_id =2 AND
                  properties.is_granted = 0 AND
                  properties.id NOT IN (select distinct property_id from property_state_logs where user_id = #{current_user.id} and property_id = properties.id and state_id  IN(3,6,4))  AND
                  property_collateral_details.property_id = properties.id AND
                  properties.occupancy IS NOT NULL"

      @ranges = Property.find_by_sql(max_sql)
      @locations = @properties.collect { |i|  i.property_collateral_detail.state }.uniq
      @property_types = @properties.collect{ |i| i.property_collateral_detail.property_type_id }.uniq
      @property_types = PropertyType.find_by_sql("SELECT id,name FROM property_types WHERE id IN (#{@property_types.join(',')});")
      @properties = @properties.paginate :per_page => 3 ,:page=> params[:page]
    end
    if request.xhr?
      render :update do |page|
        page.replace_html "load_result", :partial => "partials/search_result"
      end
    end
  end

  def search
    locations = params[:locations].gsub('+',' ')
    types = params[:types].gsub("+",' ')
    cur_out = params[:cur_out_val].split('_')
    bs = params[:bs_val].split('_')
    annualized_noi = params[:annualized_noi_val].split('_')
    occupancy = params[:occupancy_val].split('_')
    property_sql =   "SELECT  properties.*
                   FROM properties,property_collateral_details
                   WHERE
                       properties.user_id <> #{current_user.id} AND
                       properties.state_id = 2 AND
                       properties.is_granted = 0 AND
                       properties.id NOT IN (select distinct property_id from property_state_logs where user_id = #{current_user.id} and property_id = properties.id and state_id  IN(3,6,4) ) AND
                       properties.annualized_noi BETWEEN #{annualized_noi.first} and #{annualized_noi.last} AND
                       properties.current_outstanding BETWEEN #{cur_out.first} and #{cur_out.last} AND
                       property_collateral_details.property_id = properties.id AND
                       property_collateral_details.state IN(#{locations}) AND
                       property_collateral_details.property_type_id IN (#{types}) AND
                       property_collateral_details.property_size BETWEEN #{bs.first} and #{bs.last} AND
                       properties.id NOT IN (select property_id from property_state_logs WHERE property_id = properties.id AND user_id = #{current_user.id} AND state_id IN(3,4,5,6))  AND
                       properties.occupancy BETWEEN #{occupancy.first} and #{occupancy.last}"
    @properties = Property.find_by_sql(property_sql)
    @properties = @properties.paginate :per_page => 3 ,:page=> params[:page]
    render :update do |page|
      page.replace_html "load_result", :partial => "partials/search_result"
    end
  end

  def saved_notes
    sql_finder = "SELECT  properties.*
                  FROM properties,property_collateral_details, rent_rolls
                  WHERE
                    properties.user_id <> #{current_user.id} AND
                    ((properties.state_id = 2 and properties.id IN(select distinct property_id from property_state_logs where user_id = #{current_user.id} and property_id = properties.id and state_id  IN(3,4,6)) ) or ( properties.state_id= 4 and properties.id IN(select distinct property_id from property_state_logs where user_id = #{current_user.id} and property_id = properties.id and state_id  IN(4))  ) ) AND
                    properties.is_granted = 0   AND
                    property_collateral_details.property_id = properties.id AND
                    properties.occupancy IS NOT NULL"
    @properties = Property.find_by_sql(sql_finder)
    @saved_properties = Property.find(:all, :conditions=>["((properties.state_id = ? && properties.is_granted = ? && properties.user_id != ? && (property_state_logs.state_id = ? && property_state_logs.user_id = ?)) or ((properties.state_id = ? or property_state_logs.state_id = ?) && property_state_logs.user_id = ?)) && properties.id IN (?)", 2, false, current_user.id, 3, current_user.id, 4, 6, current_user.id, @properties.collect{|x|x.id}], :include=>'property_state_logs')
    @properties = @saved_properties
    if @properties.count > 0
      max_sql = "SELECT MAX(properties.annualized_noi) as ann_max, MIN(properties.annualized_noi) as ann_min, MAX(properties.sale_price) as sale_max, MIN(properties.sale_price) as sale_min, MAX(properties.cap_rate) as cap_max, MIN(properties.cap_rate) as cap_min, MAX(properties.current_outstanding) as out_max,
                    MIN(properties.current_outstanding) as out_min, MAX(property_collateral_details.property_size) as size_max, MIN(property_collateral_details.property_size) as size_min,
	                  MAX(properties.occupancy) as occ_max, MIN(properties.occupancy) as occ_min
                 FROM properties,property_collateral_details,rent_rolls
                 WHERE
                  properties.id in (#{@properties.collect{|y|y.id}.join(',')}) AND
                  property_collateral_details.property_id = properties.id"

      @ranges = Property.find_by_sql(max_sql)
      @locations = @properties.collect { |i|  i.property_collateral_detail.state }.uniq
      @property_types = @properties.collect{ |i| i.property_collateral_detail.property_type_id }.uniq
      @property_types = PropertyType.find_by_sql("SELECT id,name FROM property_types WHERE id IN (#{@property_types.join(',')});")
      @properties = @properties.paginate :per_page => 3 ,:page=> params[:page]
    end
    if request.xhr?
      render :update do |page|
        page.replace_html "load_result", :partial => "/partials/search_result"
      end
    end
  end

  def search_saved_notes
    locations = params[:locations].gsub('+',' ')
    types = params[:types].gsub("+",' ')
    annualized_noi = params[:annualized_noi_val].split('_')
    cur_out = params[:cur_out_val].split('_')
    bs = params[:bs_val].split('_')
    occupancy = params[:occupancy_val].split('_')
    property_sql =   "SELECT  properties.*
                   FROM properties,property_collateral_details
                   WHERE
                       properties.user_id <> #{current_user.id} AND
                       ((properties.state_id = 2 and properties.id IN(select distinct property_id from property_state_logs where user_id = #{current_user.id} and property_id = properties.id and state_id  IN(3,4,6)) ) or ( properties.state_id= 4 and properties.id IN(select distinct property_id from property_state_logs where user_id = #{current_user.id} and property_id = properties.id and state_id = 4)  ) ) AND
                       properties.is_granted = 0   AND
                       properties.annualized_noi BETWEEN #{annualized_noi.first} and #{annualized_noi.last} AND
                       properties.current_outstanding BETWEEN #{cur_out.first} and #{cur_out.last} AND
                       property_collateral_details.property_id = properties.id AND
                       property_collateral_details.state IN(#{locations}) AND
                       property_collateral_details.property_type_id IN (#{types}) AND
                       property_collateral_details.property_size BETWEEN #{bs.first} and #{bs.last} AND
                       properties.occupancy BETWEEN #{occupancy.first} and #{occupancy.last}"

    @properties = Property.find_by_sql(property_sql)
    @properties = @properties.paginate :per_page => 3 ,:page=> params[:page]
    render :update do |page|
      page.replace_html "load_result", :partial => "partials/search_result"
    end
  end

  def acq_performance_review
      @notes = Property.find(:all,:conditions=>['property_state_logs.user_id = ? and property_state_logs.state_id = ?',current_user.id,5],:include=>['property_state_logs'], :order=> "properties.created_at desc") 
      @note = params[:id] ?  Property.find(params[:id]) : @notes.first
      if !@note.nil?
        @portfolio = @note.portfolio
        @prop = PropertyStateLog.find_by_state_id_and_property_id(5,@note.id)
        params[:buyer_id] = @prop.action_done_by
						 @time_line_actual = Actual.find(:all,:conditions=>["resource_id =? and resource_type=?",@note.id, 'Property'], :order => "month_and_year")
						 @time_line_rent_roll = RentRoll.find(:all,:conditions=>["resource_id =? and resource_type=?",@note, 'Property'], :order => "start_date")
						 if !(@time_line_actual.nil? || @time_line_actual.blank?)
							 @time_line_start_date = @time_line_actual.first.month_and_year
							 @time_line_end_date = @time_line_actual.last.month_and_year
						 elsif !(@time_line_rent_roll.nil? || @time_line_rent_roll.blank?)
								@time_line_start_date = @time_line_rent_roll.first.start_date
								@time_line_end_date = @time_line_rent_roll.last.end_date
						 end    
        if params[:data_hub] == "true"
          show_asset_docs
        end 
        if params[:start] && params[:end]
           @actual=Actual.find(:first,:conditions=>["resource_id=? AND resource_type=? AND start_date=? AND end_date=?",@note, 'Property', params[:start],params[:end]])
           @budget=Budget.find(:first,:conditions=>["resource_id=? AND resource_type=? AND start_date=? AND end_date=?",@note, 'Property', params[:start],params[:end]])
           @start_date = params[:start].to_date
           @end_date = params[:end].to_date
        else
           #start_date=!@performance_reviews.empty? ? @performance_reviews[0].start_date.strftime("%Y%m%d") :Date.today.strftime("%Y%m%d")
           #end_date=!@performance_reviews.empty? ? @performance_reviews[0].end_date.strftime("%Y%m%d") : Date.today.strftime("%Y%m%d")
           @actual=Actual.find(:first,:conditions=>["resource_id =? and resource_type=? and month_and_year = ?",@note, 'Property',@@time.beginning_of_month.strftime("%Y-%m-%d")])
           @budget=Budget.find(:first,:conditions=>["resource_id =? and resource_type=? and month_and_year = ? ",@note, 'Property',@@time.beginning_of_month.strftime("%Y-%m-%d")])
           @start_date = @@time.beginning_of_month.strftime("%Y-%m-%d")
           @end_date = @@time.end_of_month.strftime("%Y-%m-%d")
        end
        if !@actual.nil? and !@budget.nil?
        @actual_hash = {"Gross Revenue" =>[@actual.total_potential_gross_revenue,@budget.total_potential_gross_revenue],"Revenue Adjustment" =>[@actual.total_revenue_adjustments,@budget.total_revenue_adjustments],"Operating Expenses" =>[@actual.total_operating_expenses,@budget.total_operating_expenses],"Debt Services" =>[@actual.total_debt_service,@budget.total_debt_service],"Leasing And Capital Costs" =>[@actual.total_leasing_and_capital_costs,@budget.total_leasing_and_capital_costs],"Cash Flow After Debt Service" =>[@actual.cash_flow_after_debt_service_before_tax,@budget.cash_flow_after_debt_service_before_tax]}	if !@actual.nil? && !@budget.nil?	
        end 
        params[:id] = @note.id if !@note.nil?
        render :update do |page|
          page.call "active_title","performance_review"
          page.replace_html "overview", :partial => "/notes/portfolio_overview/"
        end
      end
  end  

  def show_datahub
    @folder=Folder.find(:first)
    @portfolio = @note.portfolio
    @folders = Folder.find(:all)
    @documents = Document.find(:all)
    @document_names = DocumentName.find(:all)
  end  
  
  def save_note
    if Property.exists?(params[:id])
      @note = Property.find(params[:id])
      @property_state_log = PropertyStateLog.find_or_create_by_state_id_and_user_id_and_action_done_by_and_property_id(:state_id=>3, :user_id=>current_user.id, :action_done_by=>current_user.id, :property_id=>@note.id)
      @@jus_saved = true
      flash[:notice] = "Note has been saved successfully"
      redirect_to saved_notes_acquisitions_path

    else
      render :text => "Note does not exists"
    end
  end
  
  def note_terms
    @note = Property.find(params[:id])
    @portfolio = @note.portfolio
    @property_borrower_detail=@note.property_borrower_detail
    @property_collateral_detail=@note.property_collateral_detail
    @property_deliquency_detail=@note.property_deliquency_detail
    @property_details_note_information=@note.property_details_note_information
    if request.xhr?
      render :update do |page|
        page.call "active_title","note_terms"
        page.replace_html "overview", :partial => "/notes/term_details/"
        #page[:current_note].innerHTML = @note.note_id
      end
    end
  end
    
	def acq_property_view
    @note = Property.find(params[:id])
    @portfolio = @note.portfolio
		@property = PropertyCollateralDetail.find_by_property_id(params[:id])
		@address = "#{@property.address},#{@property.city},#{@property.state}"
		render :update do |page|
			page.replace_html "overview", :partial => "/notes/property_view/"
			page.call "active_title","property_view"
			page.call 'load_map11',@address
		end		
	end

	def show_asset_docs
     @notes = Property.find(:all,:conditions=>['property_state_logs.user_id = ? and property_state_logs.state_id = ?',current_user.id,5],:include=>['property_state_logs'], :order=> "properties.created_at desc") 
    @note = params[:id] ?  Property.find(params[:id]) : @notes.first
    @portfolio = @note.portfolio
    @folder=Folder.find(:first,:conditions=>["property_id = ? and is_deleted = false",@note.id]) if !params[:list] 
    @folder=Folder.find(params[:folder_id],:conditions=>["property_id = ? and is_deleted = false",@note.id]) if params[:list] || params[:action] == "show_asset_files"
    folder_id = (params[:action] == "show_asset_files" && !@folder.parent_id == 0) ? @folder.parent_id : @folder.id
    @folders = Folder.find(:all,:conditions=>["property_id = ? and is_deleted = false and parent_id=? and is_deselected =?",@note.id,folder_id,false])
    @documents = Document.find(:all,:conditions=>["property_id = ? and is_deleted = false and folder_id=? and is_deselected =?",@note.id,folder_id,false] )
    update_page
  end

  def show_asset_files
    confirmed_notes
  end
  
  def acq_rent_roll
    @note = Property.find(params[:id])
    @portfolio = @note.portfolio
		@rent_roll= RentRoll.find(:last, :conditions=>['resource_id=? and resource_type=\'Property\'', params[:id] ])
    if @rent_roll
      @rent_details=RentDetail.paginate(:all, :conditions=>['rent_roll_id=?', @rent_roll.id ], :page=>params[:page], :per_page=>10)
    end
    @message="Rent roll not available for selected property"
    render :update do |page|
      page.replace_html "overview", :partial => "/rent_rolls/rent_roll/"
      page.replace_html "head_for_titles", :partial => "/acquisitions/titles/"
      page.call "active_title","rent_roll"
    end
  end

  def update_page
    if request.xhr?
      render :update do |page|
        #    page.replace_html "head_for_titles", :partial => "/acquisitions/titles/"
        page.replace_html 'overview',:partial=>'datahub_info'
        page.call "active_title","data_hub"
      end
    end
  end  


  
  def request_due_dil
    if Property.exists?(params[:id])
      @note = Property.find(params[:id])
      @property_state_log = PropertyStateLog.new
    else
      render :text => "Note does not exists"
    end    
  end
  
  def due_diligence_request
    if (params[:proof_document].nil? || params[:proof_document][:uploaded_data].nil?) && (params[:property_state_log].nil? || params[:property_state_log][:comments].empty?)
      responds_to_parent do 
        render :update do |page|
          page.replace_html "error_msg", :text=>"Please upload document supporting proof of funds or enter comments"
          page.hide "success_error_msg"
        end
      end
    else
      @property = Property.find(params[:id])
      @property.update_attributes(:state_id=>4)
      @proof_document = ProofDocument.new(params[:proof_document]) if !params[:proof_document].nil? && !params[:proof_document][:uploaded_data].nil?
      if params[:proof_document].nil?
        flag=1
      elsif @proof_document.temp_path?
        flag=1
      else 
        flag=2
      end
     #  if @proof_document.nil? || (!@proof_document.nil? && !@proof_document.temp_path.blank?)
      if flag==1
        @proof_document.user_id = current_user.id if @proof_document
        @property.proof_documents << @proof_document  if @proof_document
        #@proof_document.property_id = @property.id if @proof_document
        @proof_document.save  if @proof_document
        @property.save if @proof_document
        @property_state_log = PropertyStateLog.new(params[:property_state_log])
        @property_state_log.user_id = current_user.id
        @property_state_log.action_done_by = current_user.id
        @property_state_log.state_id = 4 #State 4 for due diligence requested
        @property_state_log.property_id = @property.id
        @property_state_log.save
        @properties = Property.find(:all, :conditions=>["properties.state_id = ? && properties.is_granted = ? && properties.user_id != ?", 2, false, current_user.id])
        @saved_properties = Property.find(:all, :conditions=>["properties.state_id = ? && properties.is_granted = ? && properties.user_id != ? && (property_state_logs.state_id = ? && property_state_logs.user_id = ?)", 2, false, current_user.id, 3, current_user.id], :include=>'property_state_logs')
        @properties = @properties - @saved_properties
        @locations = @properties.collect { |i|  i.property_collateral_detail.state }.uniq if @properties
        @property_types = @properties.collect{ |i| i.property_collateral_detail.property_type_id }.uniq if @properties
        @property_types = PropertyType.find_by_sql("SELECT id,name FROM property_types WHERE id IN (#{@property_types.join(',')});")  if !@property_types.empty?
        @properties = @properties.paginate :per_page => 3 ,:page=> params[:page]
        UserMailer.deliver_send_request_due_diligence(current_user, @property.user, @property)  rescue ''
        responds_to_parent do 
          render :update do |page|
             page.redirect_to "/acquisitions/saved_notes"
  #          page.replace_html "load_result", :partial => "/partials/search_result"
  #          page.hide 'modal_container'
  #          page.hide "modal_overlay"
  #          page.visual_effect(:highlight,'saved_notes_tab', :duration => 2.5,:startcolor=>"#FFFF33")
          end
        end
      else #!@file_upload.temp_path.blank?
        responds_to_parent do
          render :update do |page|
            page.replace_html 'error_display', "Please select a valid file to upload" 
          end
        end			
      end
    end
  end
  
  #Acquisitions - Ready for Due Diligence
  def confirmed_notes        
    @notes = Property.find(:all,:conditions=>['property_state_logs.user_id = ? and property_state_logs.state_id = ?',current_user.id,5],:include=>['property_state_logs'], :order=> "properties.created_at desc") 
    @note = params[:id] ?  Property.find(params[:id]) : @notes.first
    if !@note.nil?
      @portfolio = @note.portfolio
      @prop = PropertyStateLog.find_by_state_id_and_property_id(5,@note.id)
      params[:buyer_id] = @prop.action_done_by
						 @time_line_actual = Actual.find(:all,:conditions=>["resource_id =? and resource_type=?",@note.id, 'Property'], :order => "month_and_year")
						 @time_line_rent_roll = RentRoll.find(:all,:conditions=>["resource_id =? and resource_type=?",@note, 'Property'], :order => "start_date")
						 if !(@time_line_actual.nil? || @time_line_actual.blank?)
							 @time_line_start_date = @time_line_actual.first.month_and_year
							 @time_line_end_date = @time_line_actual.last.month_and_year
						 elsif !(@time_line_rent_roll.nil? || @time_line_rent_roll.blank?)
								@time_line_start_date = @time_line_rent_roll.first.start_date
								@time_line_end_date = @time_line_rent_roll.last.end_date
						 end    
      if params[:data_hub] == "true"
        show_asset_docs
      end 
      if params[:start] && params[:end]
         @actual=Actual.find(:first,:conditions=>["resource_id=? AND resource_type=? AND start_date=? AND end_date=?",@note, 'Property', params[:start],params[:end]])
         @budget=Budget.find(:first,:conditions=>["resource_id=? AND resource_type=? AND start_date=? AND end_date=?",@note, 'Property', params[:start],params[:end]])
         @start_date = params[:start].to_date
         @end_date = params[:end].to_date
      else
         #start_date=!@performance_reviews.empty? ? @performance_reviews[0].start_date.strftime("%Y%m%d") :Date.today.strftime("%Y%m%d")
         #end_date=!@performance_reviews.empty? ? @performance_reviews[0].end_date.strftime("%Y%m%d") : Date.today.strftime("%Y%m%d")
         @actual=Actual.find(:first,:conditions=>["resource_id =? and resource_type=? and month_and_year = ?",@note, 'Property',@@time.beginning_of_month.strftime("%Y-%m-%d")])
         @budget=Budget.find(:first,:conditions=>["resource_id =? and resource_type=? and month_and_year = ? ",@note, 'Property',@@time.beginning_of_month.strftime("%Y-%m-%d")])
         @start_date = @@time.beginning_of_month.strftime("%Y-%m-%d")
         @end_date = @@time.end_of_month.strftime("%Y-%m-%d")
      end
			if !@actual.nil? and !@budget.nil?
      @actual_hash = {"Gross Revenue" =>[@actual.total_potential_gross_revenue,@budget.total_potential_gross_revenue],"Revenue Adjustment" =>[@actual.total_revenue_adjustments,@budget.total_revenue_adjustments],"Operating Expenses" =>[@actual.total_operating_expenses,@budget.total_operating_expenses],"Debt Services" =>[@actual.total_debt_service,@budget.total_debt_service],"Leasing And Capital Costs" =>[@actual.total_leasing_and_capital_costs,@budget.total_leasing_and_capital_costs],"Cash Flow After Debt Service" =>[@actual.cash_flow_after_debt_service_before_tax,@budget.cash_flow_after_debt_service_before_tax]}	if !@actual.nil? && !@budget.nil?	
			end 
      params[:id] = @note.id if !@note.nil?
    end
  end  
  
  def deny_comments
    if PropertyStateLog.exists?(params[:id])
      @note = PropertyStateLog.find(params[:id])
    else
      render :text => "No comment to display"
    end
  end
  
  def resend_request
    if PropertyStateLog.exists?(params[:id])
      @note_state = PropertyStateLog.find(params[:id])
      UserMailer.deliver_send_request_due_diligence(current_user, @note_state.property.user, @note_state.property)  rescue ''
      render :update do |page|
        page.replace_html "msg_#{@note_state.property.id}", :text => "Request has been resent"
      end
    else
      render :text => "No comment to display"
    end    
  end

  def find_just_saved
    @@jus_saved
  end
  def erase_just_saved
    @@jus_saved = false
  end

end
