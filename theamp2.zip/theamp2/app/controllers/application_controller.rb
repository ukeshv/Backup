# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  # Included for exception notifier
  include ExceptionNotifiable
  # AuthenticatedSystem must be included for RoleRequirement, and is provided by installing acts_as_authenticates and running 'script/generate authenticated account user'.
  include AuthenticatedSystem
  # You can move this into a different controller, if you wish.  This module gives you the require_role helpers, and others.
  include RoleRequirementSystem
  #to use simple captcha
  #~ include SimpleCaptcha::ControllerHelpers 

  helper :all # include all helpers, all the time
  #protect_from_forgery # See ActionController::RequestForgeryProtection for details

  # add the settings for documents table field of state flag
  #@state_settings = {:root_files=>1 , :new_versionables=>2 }
 if RAILS_ENV != "development" 
    rescue_from Exception, :with => :page_problem
    rescue_from ActiveRecord::RecordNotFound, :with => :page_problem
    rescue_from ActionController::RoutingError, :with => :page_problem
    rescue_from ActionController::MethodNotAllowed, :with => :page_problem
    rescue_from ActionController::UnknownAction, :with => :page_problem
  end
  
  def page_problem(exception)
    ExceptionNotifier.deliver_exception_notification(exception, self, request)
    redirect_to page_error_url
  end

  # Scrub sensitive parameters from your log
  # filter_parameter_logging :password
  
  def admin_login_required
    if !(current_user && current_user.has_role?('Admin'))
      flash[:error] = "Please Login as Admin to continue"
      session[:return_to] = request.request_uri
      redirect_to login_path    
    end  
  end

  def login_required
    if !(current_user && (current_user.has_role?('Asset Manager')))
      flash[:error] = "Please login to continue"
      session[:return_to] = request.request_uri
      redirect_to login_path
    else
      session[:role] = 'Asset Manager'
    end
  end

  def find_asset_manager
    if !(current_user && current_user.has_role?('Asset Manager'))
      flash[:error] = "Please login as asset manager to continue"
      session[:return_to] = request.request_uri
      redirect_to login_path
    end
  end

  def shared_user_login_required
    if !(current_user && (current_user.has_role?('Shared User')))
      flash[:error] = "Please login to continue"
      session[:return_to] = request.request_uri
      redirect_to login_path
    else
      session[:role] = 'Shared User'
    end
  end  

  def user_required
    if !(current_user && (current_user.has_role?('Asset Manager') || current_user.has_role?('Shared User')))
      flash[:error] = "Please login to continue"
      session[:return_to] = request.request_uri
      redirect_to login_path
    end
  end

  def assign_shared_user_role(u)
    shared_user_role =  Role.find_by_name('Shared User')
    u.roles << shared_user_role
  end  

  def assign_asset_manager_role(u)
    asset_manager_role =  Role.find_by_name('Asset Manager')
    u.roles << asset_manager_role
  end 

end
