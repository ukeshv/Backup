class CollaborationHubController < ApplicationController
  before_filter :user_required
	include ApplicationHelper
	include CollaborationHubHelper
	layout 'user', :except=>['edit_user_image']

	def index
		find_portfolios_to_display_in_collabhub
		if (@portfolios.nil? || @portfolios.blank?)
			redirect_to welcome_path(:from_view_coll=>true)
		end
  end


	def my_profile
		 @user = current_user
		 @portfolios = current_user.portfolios.find(:all,:conditions=>["name != 'portfolio_created_by_system'"],:order=>"id desc")
				render :update do |page|
					page.replace_html  "overview",:partial=>"/collaboration_hub/profile"
					page.call "flash_writter",'Password was successfully updated.' if 	@password_updated
				end
	end
		
	def upload_profile_image		

	end

	def list_of_folders
		if params[:parent_id] == "-1"
			@folders = Folder.find(:all, :conditions => ["portfolio_id = ? and is_master = ? and parent_id = ? and is_deleted = ?",params[:portfolio_id],false,false,false])
		else
			@folders = Folder.find(:all, :conditions => ["parent_id = ? and is_deleted = ?",params[:parent_id],false])
			#@documents = Document.find(:all, :conditions => ["parent_id = ? and is_deleted = ?",params[:parent_id],false])
		end
			render :update do |page|
    		page.replace_html  "overview",:partial=>"/collaboration_hub/asset_list"
			end
	end

def change_user_name
	 @user = current_user
	 @user.update_attribute("#{params[:field]}",CGI.unescape(params[:name])) unless params[:name].strip.blank?
	 render :update do |page|
					page.replace_html 'profile_last_changed',"Last updated: #{@user.updated_at.strftime("%b %d, %Y")}"
	        page.call("do_user_name_update","#{params[:field]}","#{params[:name]}")
	 end
end	

 
 def update_password
	 @user = current_user
	 @user.is_shared_user = true
	 if params[:user][:password] == params[:user][:password_confirmation]
        if params[:user][:password].match(/(?=.*\d)(?=.*([A-Z]))(?=.*([a-z]))/).nil?
          flash[:error] = 'Password should contain minimum 5 chars, 1 capital, 1 small char, 1 number'
          render :update do |page|
          		page.replace_html  "change_password",:partial=>"change_password"
	        end
        elsif @user.update_attributes(params[:user])        
          @user.update_attributes(:last_pwd_modified => Time.current, :last_pwd=>User.encrypt_password(params[:user][:password]))
					@password_updated = true
					my_profile
		  else
          flash[:error] = 'Password was not updated.'
          render :update do |page|
          		page.replace_html  "change_password",:partial=>"change_password"
	        end
        end
      else
         flash[:error] = 'Password Mismatch'
         render :update do |page|
          		page.replace_html  "change_password",:partial=>"change_password"
	        end
      end
	end
 
	def edit_user_image
		
	end

	def update_user_image
		if params[:id] && params[:user_image][:uploaded_data]
			@user = User.find_by_id(params[:id])
			
			#@user_image = PortfolioImage.find_by_attachable_id_and_attachable_type(params[:id],'User')
			@user_image =	params[:logo_image] ?  @user.logo_image : PortfolioImage.find(:first, :conditions=>["attachable_id= ? and attachable_type=? and filename != 'logo_image'", params[:id],'User']) 
			@user_image = PortfolioImage.new if @user_image.nil?
			@user_image.uploaded_data = params[:user_image][:uploaded_data]
			@user_image.filename = 'login_logo' if params[:logo_image]
			@user_image.attachable_id =  params[:id]
			@user_image.attachable_type = "User"
			@user_image.save
			#@user.portfolio_image = @user_image
			
			@user.updated_at = Time.now
			@user.save
			respond_to_parent do 
				render :update do |page|
					page.call 'close_control_model'
					page.replace_html 'profile_last_changed',"Last updated: #{@user.updated_at.strftime("%b %d, %Y")}"
					page << "jQuery('#user_image').attr({src :'#{user_profile_image(@user.id)}'});"
					page << "jQuery('#logo_img').attr('src','#{@user.logo_image.public_filename}?');" if !@user.logo_image.nil?					
					page.call "flash_completer"
					page.call "flash_writter" , "Picture updated successfully"
				end
			end
		end
	end
	
	

	

end
