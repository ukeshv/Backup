class DispositionsController < ApplicationController
	before_filter :login_required, :find_asset_manager
	include ApplicationHelper
	layout 'user',:except=>['show_comments','add_new_property_dispositions']
	
	def index
		@status = params[:status] ? params[:status] : 3
		state_id = []
    @reset_selected_item= "yes"
		if params[:status].nil?
			@notes = Property.find(:all, :conditions => ["state_id is NOT NULL and user_id = ? and is_granted = ?",current_user.id,false], :order=> "created_at desc")
		elsif params[:status] == "1"
			state_id << 1 << 2 << 3
			@notes = Property.find(:all, :conditions => ["state_id in (?) and user_id = ? and is_granted = ?",state_id,current_user.id,false], :order=> "created_at desc")
		elsif params[:status] == "2"
			state_id <<4 << 5
			@notes = Property.find(:all, :conditions => ["state_id in (?) and user_id = ? and is_granted = ?",state_id,current_user.id,false], :order=> "created_at desc")
		elsif params[:status] == "3"
			@notes = Property.find(:all, :conditions => ["state_id is NOT NULL and user_id = ? and is_granted = ?",current_user.id,false], :order=> "created_at desc")
		else
			@notes = Property.find(:all, :conditions => ["state_id = ? and user_id = ? and is_granted = ?",0,current_user.id,false], :order=> "created_at desc")
		end		
		@note=Property.find(:first, :conditions=>["id = ? && user_id = ? && is_granted = ? && id in (?)", params[:note_id], current_user.id, false, @notes.collect{|x|x.id}]) if !params[:note_id].nil? && !@notes.empty?

		if @note.nil?
			@note = (!@notes.nil? && !@notes.empty?) ? @notes.first : nil
		end

		@portfolio = @note.portfolio if !@note.nil?
		@annual_noi = ( !@note.nil? && !@note.annualized_noi.nil? && (@note.annualized_noi != 0.0)) ? @note.annualized_noi : (!@note.nil?) ? annualized_noi(@note) : nil
		@note.update_attributes(:annualized_noi => @annual_noi) if !@annual_noi.nil?
		@buyer_list = Buyer.find(:all, :conditions=>["user_id = ? and resource_id = ? && resource_type = ?",current_user.id,@note.id, 'Property']) if !@note.nil?
		if @note.nil? || (@note.sale_price == 0 and @note.cap_rate == 0)
			@sale_price = @annual_noi / 5  if !@annual_noi.nil?
			@cap_rate = 5
		else
			@sale_price = @note.sale_price
			@cap_rate = @note.cap_rate
		end

    if request.xhr?
			render :update do |page|
				#page.replace_html "wrapouter", :partial => "filtered_properties"
				page.replace_html "overview", :partial => "listing_info"
				#~ page.replace_html "buyer", :partial => "add_buyer"
			end
		end
	end

	def move_to_marketplace
		@note = Property.find(params[:id])
		@note.update_attributes(:state_id => 2)
		@portfolio = @note.portfolio if !@note.nil?
		@annual_noi = ( !@note.nil? && !@note.annualized_noi.nil? && (@note.annualized_noi != 0.0)) ? @note.annualized_noi : (!@note.nil?) ? annualized_noi(@note) : nil #Actual.find(:first, :conditions => ["user_id = ? and property_id = ?",current_user.id,@note.id]) if !@note.nil?
		if @note.sale_price == 0 and @note.cap_rate == 0
			@sale_price = @annual_noi / 5 if @annual_noi
			@cap_rate = 5
		else
			@sale_price = @note.sale_price
			@cap_rate = @note.cap_rate
		end
		PropertyStateLog.create(:user_id => current_user.id,:action_done_by =>current_user.id,:property_id=>params[:id],:state_id=>2,:show_hide_flag=>1)
		render :update do |page|
			#page.replace_html "overview", :partial => "listing_info"
			page.replace_html "move_to_marketplace", :partial => "add_buyer"
		end
	end

		
  def add_buyer
		@invalid_email="Invalid emails : "
    @buyers=params[:buyer]
		count=0
    @unsaved_buyers=[]
    @saved_buyers=[]
		@buyers.each do |x,y|
			user_id=current_user.id
			property_id=params[:note_id]
			buyer_name=y["company_representative"] && !y["company_representative"].blank? ? y["company_representative"] : "Sir"
			buyer=Buyer.new
			buyer.company=y["company"]
			buyer.contact_email=y["contact_email"]
			buyer.company_representative=y["company_representative"]
			buyer.user_id=user_id
			buyer.resource_id=property_id
			buyer.resource_type="Property"
			if buyer.valid?
				#buyer.save
        @saved_buyers << buyer if buyer.contact_email?
				UserMailer.deliver_invite_buyers(current_user,y["contact_email"],property_id,buyer_name)  rescue ''
			else
        @unsaved_buyers << buyer if buyer.contact_email?
				count=count+1          
			end
		end
    @notes = Property.find(:all, :conditions => ["state_id is NOT NULL and user_id = ? and is_granted = ?",current_user.id,false], :order=> "created_at desc")
    if params[:note_id]
      @note=Property.find(params[:note_id])
    else
      @note = @notes.first
    end
    @portfolio = @note.portfolio if @note
    @annual_noi = ( !@note.nil? && !@note.annualized_noi.nil? && (@note.annualized_noi != 0.0)) ? @note.annualized_noi : (!@note.nil?) ? annualized_noi(@note) : nil #Actual.find(:first, :conditions => ["user_id = ? and property_id = ?",current_user.id,@note.id]) if !@note.nil?
        
    if count == 0
      @saved_buyers.each { |item| item.save }
    else
      str_unsaved = @unsaved_buyers.collect{|x|x.contact_email}.join(',')
    end
    @buyer_list = Buyer.find(:all, :conditions=>["user_id = ? and resource_id = ? && resource_type = ?",current_user.id,@note.id, 'Property']) if !@note.nil?
    if request.xhr?
      render :update do |page|
        if count>0
          #		 page.replace_html "add_buyer", :partial => "add_buyer"
          page.call 'assign_item', 1
          page.call 'load_completer'
          #		 page.call "flash_writter", "Please check the emails provided #{@unsaved_buyers.collect{|x|x.contact_email}.join(',')}"
          page['err_buyers'].innerHTML = "Please check the emails you have given [ #{str_unsaved.empty? ? 'Email cant be blank' : str_unsaved } ]"
        else
          page.replace_html "add_buyer", :partial => "add_buyer"
          page.call 'assign_item', 1
          page.call "flash_writter", "Email sent successfully"
        end
				   
      end
    end
	end

	def change_view_file
		@note = Property.find(params[:id])
		@portfolio = @note.portfolio
    #		@requested_properties = PropertyStateLog.find(:all,:conditions =>['properties.user_id = ? and property_state_logs.property_id = ? and (property_state_logs.state_id = ? || property_state_logs.state_id = ?)',current_user.id,@note.id, 4, 6], :include=>['property'])
    #		@requested_property = (@requested_properties.nil? || @requested_properties.empty?) ? nil : (@requested_properties.collect{|x|x.state_id}.include?(6) ? nil : @requested_properties.last)
		find_req = "select * from property_state_logs where property_id = #{@note.id} and state_id IN(4,6) order by created_at desc limit 0,1"
    req_or_deny  = PropertyStateLog.find_by_sql(find_req)
    @requested_property = (!req_or_deny.nil? && !req_or_deny.empty? && req_or_deny.first.state_id == 4) ? req_or_deny.first : nil
    @buyer_list = Buyer.find(:all, :conditions=>["user_id = ? and resource_id = ? and resource_type = ?",current_user.id,@note.id, 'Property']) if !@note.nil?
    confirm_sharing if params[:confirm_sharing] == "true"
		render :update do |page|				
			if params[:view_file] == "request_due_diligence"
				#page.replace_html 'headings',:partial=>'headings' // THIS IS ADDED FROM JS enable_tab_with_img
				page.replace_html 'overview',:partial=>'requests_due_diligence'
				if params[:confirm_sharing] == "true"
          page.call "flash_writter", "Information has been shared"
          #					page[:select_one].innerHTML = "Information has been shared"
          #					page.visual_effect(:highlight,'select_one', :duration => 2.5,:startcolor=>"#E5FDD0")
          #					page.visual_effect :fade,'select_one',:duration => 2.5
        end
			else
				@annual_noi = ( !@note.nil? && !@note.annualized_noi.nil? && (@note.annualized_noi != 0.0)) ? @note.annualized_noi : (!@note.nil?) ? annualized_noi(@note) : nil #Actual.find(:first, :conditions => ["user_id = ? and property_id = ?",current_user.id,@note.id]) if !@note.nil?
        if @note.sale_price == 0 and @note.cap_rate == 0
          @sale_price = @annual_noi / 5 if @annual_noi
          @cap_rate = 5
        else
          @sale_price = @note.sale_price
          @cap_rate = @note.cap_rate
        end
				#page.replace_html 'headings',:partial=>'headings' // THIS IS ADDED FROM JS enable_tab_with_img
				page.replace_html 'overview',:partial=>'listing_info'
			end
		end	
	end	
	

	def show_comments
		@note = Property.find(params[:id])
		render :template=>'/dispositions/show_comments'
	end

	def deny_request 		
		@note = Property.find(params[:id])
		@portfolio = @note.portfolio
		@note.update_attributes(:state_id => 2 )
		@requested_property = PropertyStateLog.find(:last,:conditions =>['state_id = ? and property_id = ?',4,@note.id])
		p = PropertyStateLog.new
		p.user_id = @requested_property.user_id
		p.action_done_by = current_user.id
		p.property_id = @note.id
		p.state_id = 6
		p.comments = params[:denial_comment]
		p.save
		@requested_property = PropertyStateLog.find(:last,:conditions =>['state_id = ? and property_id = ?',6,@note.id])
		responds_to_parent do
			render :update do |page|				
				page['show_comments_form1'].reset
        page.hide 'modal_container'
        page.hide 'modal_overlay'
				page.replace_html 'overview','<h3 style="color: #1EA784; margin-left: 150px;">No buyer has requested for this property</h3>'
        page.call "flash_writter", "Request has been denied"
        #				page[:select_one].innerHTML = "Request has been denied"
        #				page.visual_effect(:highlight,'select_one', :duration => 2.5,:startcolor=>"#E5FDD0")
        #				page.visual_effect :fade,'select_one',:duration => 2.5
			end
		end
	end	
	
	def update_cap_rate_saleprice
		@note = Property.find(params[:note_id])
		@note.update_attributes(:sale_price => params[:sale_price],:cap_rate=>params[:cap_rate])
		render :nothing => true, :layout => true
	end
  
	def confirm_sharing
		@note = Property.find(params[:id])
		@note.update_attributes(:state_id =>5)
		property_state_log = PropertyStateLog.create(:user_id=>@requested_property.user_id,:state_id =>5,:property_id => @note.id,:action_done_by=>current_user.id)
	end
	
	def dwl_doc
		proof_doc = ProofDocument.find(params[:id])
		send_file RAILS_ROOT+'/public/'+ proof_doc.public_filename if proof_doc
	end

  def delete_buyer
    @note=Property.find(params[:note_id])
    Buyer.delete(params[:id])
    @buyer_list = Buyer.find(:all, :conditions=>["user_id = ? and resource_id = ? and resource_type = ?",current_user.id,@note.id, 'Property']) if !@note.nil?
    if request.xhr?
      render :update do |page|
        page.replace_html "add_buyer", :partial => "add_buyer"
        page.call "flash_writter", "Buyer deleted successfully"
      end
    end
  end

	def add_new_property_dispositions

	end

end