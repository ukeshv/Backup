require 'dotiw'
include ActionView::Helpers::DateHelper
class EventsController < ApplicationController
	include ApplicationHelper
	before_filter :user_required
	layout 'users'
  @@option_page = 30  # ADD the limit of the events to be displayed.
	
	def index
		if current_user.has_role?('Asset Manager') && session[:role] == 'Asset Manager'
			@events = Event.find(:all, :conditions => ["user_id = ?",current_user.id], :order => "created_at desc")
      shared_user = Event.find(:all,:conditions => ["user_id = ? and shared_user_id IS NOT NULL",current_user.id],:order => "created_at desc").map(&:shared_user_id).uniq
      @shared_users=[]
      if !shared_user.blank?
        shared_user.each do |x|
					if User.exists?(x)
						user=User.find(x)
						@shared_users << user if user
					end
        end
      end
		end
	end
	
	def folder_display
		if params[:id]
      @folder = Folder.find(params[:id])
      if @folder
        params[:exec_tab] = ""
        params[:data_hub_tab] = "data_hub"
        redirect_to show_folder_files_asset_path(:pid => @folder.portfolio_id,:folder_id => @folder.id) if !@folder.real_estate_property_id?
        redirect_to show_folder_files_property_path(:pid => @folder.portfolio_id,:folder_id => @folder.id, :exec_tab=>params[:exec_tab], :partial_disp=>params[:data_hub_tab]) if @folder.real_estate_property_id?
      end
		end	
	end

  def filter_events
		action_type = ["create","upload","new_version","delete","download","rename","shared","moved","copied","commented","restored","unshared","del_comment","rep_comment","up_comment","create_task","update_task","mapped_secondary_file","create_secondary_file","collaborators","task_commented","task_del_commented","task_up_commented","task_rep_commented","de_collaborators"]
		documents = Document.find(:all,:conditions=>["folder_id = ?",params[:folder_id]],:select=>'id').collect{|id| id.id} # Added - select id instead of all fields
		document_name = DocumentName.find(:all,:conditions=>["folder_id = ?",params[:folder_id]],:select=>'id').collect{|id| id.id} # Added - select id instead of all fields
		folders = EventResource.find(:all, :conditions=>["resource_id = ? or resource_id in (?) or resource_id in (?)",params[:folder_id],documents,document_name],:select=>'event_id').collect{|event_id| event_id.event_id} # Added - select event_id instead of all fields
		shared_user = Event.find(:all,:conditions => ["user_id = ? and shared_user_id IS NOT NULL and (id in (?)  and action_type in (?))",current_user.id,folders,action_type],:order => "created_at desc").map(&:shared_user_id).uniq
    @shared_users=[]
    if !shared_user.blank?
      shared_user.each do |x|
				if User.exists?(x)
					user=User.find(x)
					@shared_users << user if user
      end
      end
    end
		if params[:shared_user_id]=='All Users'
			#@events = Event.find_all_by_user_id(current_user.id,:order => "created_at desc")
			view_events_folder_for_all_users
		else
			#@events = Event.find(:all,:conditions => ["user_id = ? and shared_user_id=?",current_user.id,params[:shared_user_id]],:order => "created_at desc")
			view_events_folder_for_filter_events
		end
		if request.xhr?
      render :update do |page|
        page.replace 'listing_events', :partial => '/partials/event_list'
      end
    end
  end
		
  def view_events_folder_for_all_users
		a = []
		a = params[:folder_id].split(",")
		action_type = ["create","upload","new_version","delete","download","rename","shared","moved","copied","commented","restored","unshared","del_comment","rep_comment","up_comment","create_task","update_task","mapped_secondary_file","create_secondary_file","collaborators","task_commented","task_del_commented","task_up_commented","task_rep_commented","de_collaborators"]
		@events = Event.find(:all, :conditions=>["id IN (?) and action_type in (?)",a,action_type], :order=>'created_at desc')
		#shared_users = @events.collect{|x|x.shared_user_id}.uniq
		shared_users = @events.collect{|x| [x.shared_user_id,x.user_id]}.uniq.flatten
		@events = @events.paginate :per_page => @@option_page ,:page=> params[:page]
		@shared_users = User.find(:all, :conditions => ["id in (?)",shared_users], :select=> "email,id")		
		
  end
		
  def view_events_folder_for_filter_events
		a = []
		a = params[:folder_id].split(",")
		action_type = ["create","upload","new_version","delete","download","rename","shared","moved","copied","commented","restored","unshared","del_comment","rep_comment","up_comment","create_task","update_task","mapped_secondary_file","create_secondary_file","collaborators","task_commented","task_del_commented","task_up_commented","task_rep_commented","de_collaborators"]
		#@events = Event.find(:all, :conditions=>["id IN (?) and (user_id = ? or shared_user_id = ?)  and action_type in (?)",event_ids,params[:shared_user_id],params[:shared_user_id],action_type], :order=>'created_at desc')
		@events = Event.find(:all, :conditions=>["id IN (?) and (user_id = ? or shared_user_id = ?)  and action_type in (?)",a,params[:shared_user_id],params[:shared_user_id],action_type], :order=>'created_at desc')
		#shared_users = @events.collect{|x|x.shared_user_id}.uniq
		shared_users = @events.collect{|x| [x.shared_user_id,x.user_id]}.uniq.flatten
		@events = @events.paginate :per_page => @@option_page ,:page=> params[:page]
		@shared_users = User.find(:all, :conditions => ["id in (?)",shared_users], :select=> "email,id")
  end
		
		
	def view_events_folder
		shared_folder_collab_hub = []
		shared_doc_collab_hub = []
		shared_task_collab_hub = []
		events_conditions = []
		@event_ids = []
		@all_folders_ids = []
		@all_documents_ids = []
		@all_document_names_ids = []
		@tasks_ids = []
		@task_file_ids = []
		action_type = ["create","upload","new_version","delete","download","rename","shared","moved","copied","commented","restored","unshared","del_comment","rep_comment","up_comment","create_task","update_task","mapped_secondary_file","create_secondary_file","collaborators","task_commented","task_del_commented","task_up_commented","task_rep_commented","de_collaborators"]
		@folder = Folder.find(params[:folder_id])
		@portfolio = @folder.portfolio
		find_all_folders_n_subfolders(params[:folder_id])				
		
 		shared_folder_collab_hub  = params[:shared_folders].split(",") if !(params[:shared_folders].nil? || params[:shared_folders].blank?)
		shared_doc_collab_hub  = params[:shared_docs].split(",") if !(params[:shared_docs].nil? || params[:shared_docs].blank?)
		shared_task_collab_hub  = params[:shared_tasks].split(",") if !(params[:shared_tasks].nil? || params[:shared_tasks].blank?)
		owned_and_shared_properties  = params[:owned_and_shared_properties].split(",") if !(params[:owned_and_shared_properties].nil? || params[:owned_and_shared_properties].blank?)
		
		owned_and_shared_properties_collection = Folder.find(:all, :conditions => ["real_estate_property_id in (?) and parent_id = 0 and is_master = 0",owned_and_shared_properties], :select => "id")
		
		shared_folder_collab_hub.each do |i|
			find_all_folders_n_subfolders(i)
		end
		
		owned_and_shared_properties_collection.each do |j|
			find_all_folders_n_subfolders(j)
		end
		
		events_conditions = "(resource_id IN (#{@all_folders_ids.collect{|x| x.id}.join(',')}) and resource_type = 'Folder')" if !(@all_folders_ids.nil? || @all_folders_ids.blank?)
		
		events_conditions << " #{check_events_condition(events_conditions)} (resource_id IN (#{shared_folder_collab_hub.join(',')}) and resource_type = 'Folder')" if !(shared_folder_collab_hub.nil? || shared_folder_collab_hub.blank?)
		
		events_conditions << " #{check_events_condition(events_conditions)} (resource_id IN (#{@all_documents_ids.collect{|x| x.id}.join(',')}) and resource_type = 'Document')" if !(@all_documents_ids.nil? || @all_documents_ids.blank?)
		
		events_conditions << " #{check_events_condition(events_conditions)} (resource_id IN (#{shared_doc_collab_hub.join(',')}) and resource_type = 'Document')" if !(shared_doc_collab_hub.nil? || shared_doc_collab_hub.blank?)
		
		events_conditions << " #{check_events_condition(events_conditions)} (resource_id IN (#{@tasks_ids.collect{|x| x.id}.join(',')}) and resource_type = 'Task')" if !(@tasks_ids.nil? || @tasks_ids.blank?)
		
		events_conditions << " #{check_events_condition(events_conditions)} (resource_id IN (#{shared_task_collab_hub.join(',')}) and resource_type = 'Task')" if !(shared_task_collab_hub.nil? || shared_task_collab_hub.blank?)
		
		events_conditions << " #{check_events_condition(events_conditions)} (resource_id IN (#{@tasks_ids.collect{|x| x.id}.join(',')}) and resource_type = 'TaskFile')" if !(@tasks_ids.nil? || @tasks_ids.blank?)
				
		# Added to restrict nil condition
		events_conditions = ("resource_id in (null)") if events_conditions.blank?
		
		#@task = docu.task if !doc.task.nil?
		#folder_events = EventResource.find(:all, :conditions=>["resource_id IN (?) and resource_type = ?",@all_folders_ids,'Folder'],:select=>'event_id') # - Selected only event_id field
		
		#shared_folder_events = EventResource.find(:all, :conditions=>["resource_id IN (?) and resource_type = ?",shared_folder_collab_hub,'Folder'],:select=>'event_id') if !shared_folder_collab_hub.nil?
		
		#doc_events = EventResource.find(:all, :conditions=>["resource_id IN (?) and resource_type = ?",@all_documents_ids,'Document'],:select=>'event_id') # - Selected only event_id field
		
		#shared_doc_events = EventResource.find(:all, :conditions=>["resource_id IN (?) and resource_type = ?",shared_doc_collab_hub,'Document'],:select=>'event_id') if !shared_doc_collab_hub.nil?
		
		#doc_name_events = EventResource.find(:all, :conditions=>["resource_id IN (?) and resource_type = ?",@all_document_names_ids,'DocumentName'],:select=>'event_id') # - Selected only event_id field
		
		#task_events = EventResource.find(:all, :conditions=>["resource_id IN (?) and resource_type = ?",@tasks_ids,'Task'],:select=>'event_id') 
		
		#shared_task_events = EventResource.find(:all, :conditions=>["resource_id IN (?) and resource_type = ?",shared_task_collab_hub,'Task'],:select=>'event_id') if !shared_task_collab_hub.nil?
		
		#task_file_events = EventResource.find(:all, :conditions=>["resource_id IN (?) and resource_type = ?",@tasks_ids,'TaskFile'],:select=>'event_id') 
		
		events_conditions = ("resource_id in (null)") if events_conditions.blank?
		val = EventResource.find(:all, :conditions => ["#{events_conditions}"], :select=>"event_id")
		@event_ids = val.collect{|x| x.event_id}
		#event_ids = (folder_events + doc_events + doc_name_events + task_events + task_file_events + shared_folder_events + shared_doc_events + shared_task_events).collect{|x|x.event_id}
		
		@events = Event.find(:all, :conditions=>["id IN (?) and action_type in (?)",@event_ids,action_type], :order=>'created_at desc')
		#shared_users = @events.collect{|x|x.shared_user_id}.uniq
		shared_users = @events.collect{|x| [x.shared_user_id,x.user_id]}.uniq.flatten
		@events = @events.paginate :per_page => @@option_page ,:page=> params[:page]
		#folders = EventResource.find(:all, :conditions=>["(resource_id in (?) and resource_type = 'Folder') or (resource_id in (?) and resource_type = 'Document') or (resource_id in (?) and resource_type = 'DocumentName') or (resource_id in (?) and resource_type = 'SharedFolder') or (resource_id in (?) and resource_type = 'SharedDocument') or (resource_id in (?) and resource_type = 'ShareDocumentName')",@all_folders_ids,@all_documents_ids,@all_document_names_ids,@all_folders_ids,@all_documents_ids,@all_document_names_ids],:select=>'event_id').collect{|event_id| event_id.event_id} 
		# - Added select event_id
    #shared_user = Event.find(:all,:conditions => ["user_id = ? and (shared_user_id IS NOT NULL and shared_user_id != 1) and (id in (?)) and action_type in (?)",current_user.id,event_ids,action_type],:order => "created_at desc").map(&:shared_user_id).uniq
		#shared_user = Event.find(:all,:conditions => ["shared_user_id IS NOT NULL and (id in (?))  and action_type in (?)",event_ids,action_type],:order => "created_at desc").map(&:shared_user_id).uniq
		
    #@shared_users=[]
		@shared_users = User.find(:all, :conditions => ["id in (?)",shared_users], :select=> "email,id")
    #~ if !shared_users.blank?
      #~ shared_user.each do |x|
				#~ if User.exists?(x)
					#~ user=User.find(x)
					#~ @shared_users << user if user
				#~ end
      #~ end
    #~ end
		render :update do |page|
			page.replace_html 'folder_title', :partial => '/partials/folder_title' if !@folder.real_estate_property_id?
			page.replace_html 'folder_title', :partial => '/properties/folder_title'  if @folder.real_estate_property_id?	
			page.replace_html 'head_for_del_icons', :partial => '/partials/head_for_del_icons_for_events' if !@folder.real_estate_property_id?
      page << "jQuery('#head_for_del_icons ').each(function(){if(jQuery(this).is(':visible'))new_docs_icons = this; });"
      page.replace_html "eval('back_replacer')", :partial => '/properties/head_for_del_icons_for_events' unless !@folder.real_estate_property_id?
      temp = page.instance_variable_get(:@lines) 
      temp[temp.size - 1] = temp.last.sub("\"eval('back_replacer')\"", 'new_docs_icons');
      page.instance_variable_set(:@lines, temp)# * wants to be checked.
      #      page.replace_html 'head_for_del_icons', :partial => '/properties/head_for_del_icons_for_events' unless @folder.real_estate_property_id.nil?
      page << "jQuery('#stored_assets_docs_display ').each(function(){if(jQuery(this).is(':visible'))new_docs_place = this; });"
      page.replace_html "eval('back_replacer')",:partial => '/partials/list_of_shared_users'
      temp = page.instance_variable_get(:@lines) # *
      temp[temp.size - 1] = temp.last.sub("\"eval('back_replacer')\"", 'new_docs_place');
      page.instance_variable_set(:@lines, temp)

      #      page.replace_html 'stored_assets_docs_display', :partial => '/partials/list_of_shared_users'
		end
	end
	
	def check_events_condition(str)
		or_flag = !str.empty? ? " or " : " "
	end

	def find_all_folders_n_subfolders(f)
		all_folders_ids,all_documents_ids,all_document_names_ids,tasks_ids,task_file_ids = find_all_events_of_folder(f,true)
		@all_folders_ids += all_folders_ids 
		@all_documents_ids += all_documents_ids
		@all_document_names_ids += all_document_names_ids
		@tasks_ids += tasks_ids
		@task_file_ids += task_file_ids
		#~ @all_folders_ids = @all_folders.collect{|x|x.id}
		#~ @all_documents_ids = @all_documents.collect{|x|x.id}
		#~ @all_document_names_ids = @all_document_names.collect{|x|x.id}
	end	
	
end