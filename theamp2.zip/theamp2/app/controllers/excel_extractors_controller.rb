#require 'spreadsheet'
require 'roo'

class ExcelExtractorsController < ApplicationController

  # THIS IS USED TO EXTRACT THE CAPITAL IMPROVEMENT EXCEL DOCUMENT
  # THIS INTRACTS - FOUR TABLES [ property_suite, property_capital_improvement, property_total_capital_improvement, property_financial_periods ]
  # info : carpets and drapes having values in title itself !!
  def extract_capital_improvement
    month_details = ['', 'january','february','march','april','may','june','july','august','september','october','november','december']
    categories = ['TENANT IMPROVEMENTS','BUILDING IMPROVEMENTS','LEASING COMMISSIONS','LEASE COSTS','NET LEASE COSTS','CARPET & DRAPES']
    restricted_categories = ['TOTAL CAPITAL EXPENDITURES','TOTAL TENANT IMPROVEMENTS']
    exec_str = "prop_cap_improve.year = year; prop_cap_improve.month = month; prop_cap_improve.save; prop_fin_period_A = prop_cap_improve.property_financial_periods.empty? ?  PropertyFinancialPeriod.new : prop_cap_improve.property_financial_periods.select{ |i| i.pcb_type == 'C' }.first; prop_fin_period_B = prop_cap_improve.property_financial_periods.empty? ?  PropertyFinancialPeriod.new : prop_cap_improve.property_financial_periods.select{ |i| i.pcb_type == 'B' }.first"
    prop_fin_period_A = prop_fin_period_B = Array.new # These are used to store the financial periods.
    cur_category = ''
    tenant_name = ''
    real_estate_property_id = 1; # store the property id here
    #book = Excel.new "#{RAILS_ROOT}/public/test_parse/2010_09_700_Capital_Improvement_Status_Report_93.xls"
    #book = Excel.new "/home/sasindran/Desktop/el/2010-09 741 Capital Improvement Status Report.xls"
    #book = Excel.new "/home/sasindran/Desktop/mbp/2010-09 740 Capital Improvement Status Report.xls"
    book = Excel.new "/home/sasindran/Desktop/2010 09 710 Capital Improvement Status Report.xls"
    book.default_sheet = book.sheets[0]
    roww = 7
    head = OpenStruct.new ; head.chk_category = nil
    budget_index = []
    actual_index = []
    1.upto book.last_column do |col|
      case book.cell(roww, col)
      when 'SUITE ID', 'SUITE'; head.suite = col
      when 'CATEGORY'; head.category = col
      when 'STATUS'; head.status = col
      when 'BUDGET'; head.annual_budget = col if book.cell( roww - 1, col )
      when 'ACTUAL'; head.chk_category = col if head.chk_category.nil?
      end
    end
    (head.status + 1).upto head.status+12 do |ind| actual_index << ind  end
    (actual_index.last + 2).upto actual_index.last+13 do |ind| budget_index.push(ind) end
    book.sheets.each do |sheet|
      book.default_sheet = sheet
      sheet_name =book.cell(3,1).nil? ?  book.cell(3,8).split(' ') : book.cell(3,1).split(' ')
      sheet_name.push(book.cell(2,1).split(' ').first) if sheet_name.count < 2
      year =  sheet_name[1].to_i 
      month = month_details.index sheet_name[0].downcase
      9.upto book.last_row do |row|
        category = book.cell(row, head.category)
        next if (category.nil? || category.empty?)
        categories.include?(category.strip) ? cur_category = category.strip : tenant_name = category.strip
        next if book.cell(row, head.chk_category).nil?
        mri = book.cell(row, 1)
        suite_no = ( book.cell(row, head.suite).class == Float ) ? book.cell(row, head.suite).to_i : book.cell(row, head.suite)
        property_suite= (suite_no.nil? || suite_no.to_s.empty?) ? {'id' => nil } : PropertySuite.find_or_create_by_real_estate_property_id_and_suite_number(real_estate_property_id, suite_no)
        prop_cap_improve = PropertyCapitalImprovement.new
        prop_cap_improve.tenant_name = tenant_name
        prop_cap_improve.property_suite_id = property_suite['id']
        prop_cap_improve.category = restricted_categories.include?(tenant_name) ? tenant_name : cur_category
        prop_cap_improve.real_estate_property_id = real_estate_property_id
        prop_cap_improve.annual_budget = book.cell(row, head.annual_budget) if book.cell(row, head.annual_budget).class == Float
        prop_cap_improve.project_status = book.cell(row, head.status)
        eval(exec_str)
        # property financial store for Actual values
        prop_fin_period_A.source_id = prop_cap_improve['id']
        prop_fin_period_A.source_type = prop_cap_improve.class.to_s
        prop_fin_period_A.year = year
        prop_fin_period_A.pcb_type = "C"
        prop_fin_period_A.january = book.cell(row, actual_index[0])
        prop_fin_period_A.february = book.cell(row, actual_index[1])
        prop_fin_period_A.march = book.cell(row, actual_index[2])
        prop_fin_period_A.april = book.cell(row, actual_index[3])
        prop_fin_period_A.may = book.cell(row, actual_index[4])
        prop_fin_period_A.june = book.cell(row, actual_index[5])
        prop_fin_period_A.july = book.cell(row, actual_index[6])
        prop_fin_period_A.august = book.cell(row, actual_index[7])
        prop_fin_period_A.september = book.cell(row, actual_index[8])
        prop_fin_period_A.october = book.cell(row, actual_index[9])
        prop_fin_period_A.november = book.cell(row, actual_index[10])
        prop_fin_period_A.december = book.cell(row, actual_index[11])
        prop_fin_period_A.save
        # Budget storing obj 
        prop_fin_period_B.source_id = prop_cap_improve['id']
        prop_fin_period_B.source_type = prop_cap_improve.class.to_s
        prop_fin_period_B.year = year
        prop_fin_period_B.pcb_type = "B"
        prop_fin_period_B.january = book.cell(row, budget_index[0])
        prop_fin_period_B.february = book.cell(row, budget_index[1])
        prop_fin_period_B.march = book.cell(row, budget_index[2])
        prop_fin_period_B.april = book.cell(row, budget_index[3])
        prop_fin_period_B.may = book.cell(row, budget_index[4])
        prop_fin_period_B.june = book.cell(row, budget_index[5])
        prop_fin_period_B.july = book.cell(row, budget_index[6])
        prop_fin_period_B.august = book.cell(row, budget_index[7])
        prop_fin_period_B.september = book.cell(row, budget_index[8])
        prop_fin_period_B.october = book.cell(row, budget_index[9])
        prop_fin_period_B.november = book.cell(row, budget_index[10])
        prop_fin_period_B.december = book.cell(row, budget_index[11])
        prop_fin_period_B.save
      end
    end
    render :text => "<center>Template Saved&nbsp;&nbsp;&nbsp;&nbsp;<a href='/'>Home</a><center>"
  end

  # THIS IS USED EXTRACT THE AGED RECIEVABLES
  # TABLES [ property suite and property_aged_recievables ]
  def extract_aged_receivables
    real_estate_property_id = 1 # params wants to loaded here
    book = Excel.new "#{RAILS_ROOT}/public/test_parse/2010_09_700_Aged_Delinquent_Report.xls"
    #book = Excel.new "/home/sasindran/Desktop/2010 09 710 Aged Delinquent Report 82.xls"
    #book = Excel.new "/home/sasindran/Desktop/el/2010-09 741 Aged Delinquent Report.xls"
    #book = Excel.new "/home/sasindran/Desktop/mbp/2010-09 740 Aged Delinquent Report.xls"
     
    head = OpenStruct.new
    book.default_sheet = book.sheets[0]
    1.upto book.last_row do |roww|
      if book.cell(roww, 1) == 'Bldg - Lease #'
        1.upto book.last_column do |coll|
          case book.cell(roww, coll)
          when 'Tenant'; head.tenant = coll
          when 'Current'; head.current = coll
          when '30 Days'; head.days_30 = coll
          when '60 Days'; head.days_60 = coll
          when '90 Days'; head.days_90 = coll
          when '120 Days'; head.days_120 = coll
          end
        end
        head.start = roww
        break;
      end
    end
    book.sheets.each do |sheet|
      book.default_sheet = sheet
      if !sheet.include?('TASK') # sheet title must contain 'AR' else not extracted
        sheet_date = book.cell(3,1).nil? ? OpenStruct.new({:year=>nil, :month=>nil}) : book.cell(3,1).split(' ').last.to_date # Finding the month and year from excel
        year = sheet_date.year
        month = sheet_date.month
        head.start.next.upto book.last_row do |row|
          next if book.cell(row, head.tenant).nil? || book.cell(row, head.tenant).empty?
          break if (book.cell(row, head.tenant) == "Grand Total:" || book.cell(row, head.tenant) == 'Grand Total') # exits when see the grand total in excel.
          suite_id = book.cell(row, 1).nil? ? nil : book.cell(row, 1).split(' ').last
          prop_suite = suite_id.nil? ?  {'id' => nil}  : PropertySuite.find_or_create_by_real_estate_property_id_and_suite_number(real_estate_property_id, suite_id)
          prop_aged_rec = PropertyAgedReceivable.new
          prop_aged_rec.property_suite_id = prop_suite['id']
          prop_aged_rec.tenant = book.cell(row,head.tenant)
          prop_aged_rec.paid_amount = book.cell(row, head.current)
          prop_aged_rec.over_30days = book.cell(row, head.days_30)
          prop_aged_rec.over_60days = book.cell(row, head.days_60)
          prop_aged_rec.over_90days = book.cell(row, head.days_90)
          prop_aged_rec.over_120days = book.cell(row, head.days_120)
          prop_aged_rec.month = month
          prop_aged_rec.year = year
          prop_aged_rec.save
        end
      end
    end
    render :text => "<center>Template Saved&nbsp;&nbsp;&nbsp;&nbsp;<a href='/'>Home</a><center>"
  end


  def extract_capital_headers
    month_details = ['', 'january','february','march','april','may','june','july','august','september','october','november','december']
    categories = ['TENANT IMPROVEMENTS','BUILDING IMPROVEMENTS','LEASING COMMISSIONS','LEASE COSTS','NET LEASE COSTS','CARPET & DRAPES']
    restricted_categories = ['TOTAL CAPITAL EXPENDITURES','TOTAL TENANT IMPROVEMENTS']
    exec_str = "prop_cap_improve.year = year; prop_cap_improve.month = month; prop_cap_improve.save; prop_fin_period_A = prop_cap_improve.property_financial_periods.empty? ?  PropertyFinancialPeriod.new : prop_cap_improve.property_financial_periods.select{ |i| i.pcb_type == 'C' }.first; prop_fin_period_B = prop_cap_improve.property_financial_periods.empty? ?  PropertyFinancialPeriod.new : prop_cap_improve.property_financial_periods.select{ |i| i.pcb_type == 'B' }.first"
    prop_fin_period_A = prop_fin_period_B = Array.new # These are used to store the financial periods.
    cur_category = ''
    tenant_name = ''
    real_estate_property_id = 1; # store the property id here
 
    #book = Excel.new "#{RAILS_ROOT}/public/test_parse/2010_09_700_Capital_Improvement_Status_Report_93.xls"
    book = Excel.new "/home/sasindran/Desktop/2010 09 700 Capital Improvement Status Report 93.xls" 
    #book = Excel.new "/home/sasindran/Desktop/el/2010-09 741 Capital Improvement Status Report.xls"
    #book = Excel.new "/home/sasindran/Desktop/mbp/2010-09 740 Capital Improvement Status Report.xls"
    #book = Excel.new "/home/sasindran/Desktop/2010 09 710 Capital Improvement Status Report.xls"
    book.default_sheet = book.sheets[0]
    row = 7
    head = OpenStruct.new ; head.chk_category = nil
    budget_index = []
    actual_index = []
    1.upto book.last_column do |col|
      case book.cell(row, col)
      when 'SUITE ID', 'SUITE'; head.suite = col
      when 'CATEGORY'; head.category = col
      when 'STATUS'; head.status = col
      when 'BUDGET'; head.annual_budget = col if book.cell( row - 1, col )
      when 'ACTUAL'; head.chk_category = col if head.chk_category.nil?
      end
      #eval(header_finder[book.cell(row,col).to_s])
    end
    (head.status + 1).upto head.status+12 do |ind| actual_index << ind  end
    (actual_index.last + 2).upto actual_index.last+13 do |ind| budget_index.push(ind) end
  end
end
