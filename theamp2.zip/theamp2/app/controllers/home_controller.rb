class HomeController < ApplicationController
	require 'roo'
	require 'ftools'
	require 'spreadsheet'	
  layout 'user_login'
    def new
	  @contact=Contact.new
		end
	
		def create
			@contact=Contact.new(params[:contact])
			if @contact.valid? && @contact.errors.empty?
				@contact.save
				UserMailer.deliver_contact_us(@contact)
				#flash[:notice]="Thank You.AMP will contact you shortly"
				redirect_to root_path
			else		
			render :action=>'new'
			end
		end
		
		
		def test_upload_data			
			oo = Excel.new(RAILS_ROOT+"/public/12 month budget - 369 Pine.xls")		
			oo.default_sheet = oo.sheets.first			
			@array_record = []			
			for row in 9..oo.last_row
				for col in 0..15						
					
					#~ if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and oo.cell(row,col).downcase.strip=="operating statement summary"
						#~ start_row_oss=row;start_col_oss=col
						#~ re=IncomeAndCashFlowDetail.create(:title=>oo.cell(row,col).downcase.strip,:parent_id=> nil)
						#~ @array_record << [re.title,re.id] if !re.nil?
						#~ parsing_operation_statement_summary(start_row_oss,start_col_oss,oo)
					#~ end
					
					if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and oo.cell(row,col).downcase.strip=="cash flow statement summary"
						start_row_oss=row;start_col_oss=col												
						create_new_income_and_cash_flow_details(oo.cell(row,col).downcase.strip)
						parsing_cash_flow_statement_summary(start_row_oss,start_col_oss,oo)
					end							
					
					#~ if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and oo.cell(row,col).downcase.strip=="income detail"		
						#~ @array_record = []
						#~ create_new_income_and_cash_flow_details("operating statement summary")						
						#~ start_row_oss=row;start_col_oss=col						
						#~ create_new_income_and_cash_flow_details(oo.cell(row,col).downcase.strip,@array_record.first)
						#~ parsing_operation_statement_summary(start_row_oss,start_col_oss,oo)
					#~ end
					
				end	
			end			

		#	calculate_sum_for_all_the_details
		calculate_sum_for_all_the_details_in_cash_flow_and_detail
		end	
		
		def calculate_sum_for_all_the_details_in_cash_flow_and_detail
			a = ["operating statement summary","cash flow statement summary","net cash flow","net operating income","net income"]
			for income_and_cash_flow in IncomeAndCashFlowDetail.all
		   # income_and_cash_flow = IncomeAndCashFlowDetail.find_by_title("income detail")
				if !a.include?(income_and_cash_flow.title)
					#~ @sum_jan=0;@sum_feb=0;@sum_mar=0;@sum_apr=0;@sum_may=0;@sum_june=0;@sum_july=0;@sum_aug=0;@sum_sep=0;@sum_oct=0;@sum_nov=0;@sum_dec=0					
					#~ children = IncomeAndCashFlowDetail.find_all_by_parent_id(income_and_cash_flow.id)
					#~ for child in children
						sum_for_each_item(income_and_cash_flow)
					#~ end						
 
					#~ if !children.empty?
					 #~ income_and_cash_flow.update_attributes(:january =>@sum_jan , :february  =>@sum_feb, :march =>@sum_mar, :april =>@sum_apr,:may =>@sum_may,:june=>@sum_june,:july =>@sum_july,:august =>@sum_aug,:september=>@sum_sep,:october=> @sum_oct,:november=>@sum_nov,:december=>@sum_dec)	
					#~ end
				end	
			end				
		end
		
		def sum_for_each_item(income_and_cash_flow)
			children = IncomeAndCashFlowDetail.find_all_by_parent_id(income_and_cash_flow.id)
			sum_jan=0;sum_feb=0;sum_mar=0;sum_apr=0;sum_may=0;sum_june=0;sum_july=0;sum_aug=0;sum_sep=0;sum_oct=0;sum_nov=0;sum_dec=0	
			for child in children
				sum_for_each_item(child)
				sum_jan = sum_jan +child.january       if !child.nil? and !child.january.nil?
				sum_feb = sum_feb +child.february     if !child.nil? and !child.february.nil?
				sum_mar = sum_mar +child.march      if !child.nil? and !child.march.nil?
				sum_apr = sum_apr +child.april           if !child.nil? and !child.april.nil?
				sum_may = sum_may +child.may       	if !child.nil? and !child.may.nil?
				sum_june = sum_june +child.june         if !child.nil? and !child.june.nil?
				sum_july = sum_july +child.july             if !child.nil? and !child.july.nil?
				sum_aug = sum_aug +child.august       if !child.nil? and !child.august.nil?
				sum_sep = sum_sep +child.september  if !child.nil? and !child.september.nil?
				sum_oct = sum_oct +child.october        if !child.nil? and !child.october.nil?
				sum_nov = sum_nov +child.november   if !child.nil? and !child.november.nil?
				sum_dec = sum_dec +child.december   if !child.nil? and !child.december.nil?				
			end
			if !children.empty?
				income_and_cash_flow.update_attributes(:january =>sum_jan , :february  =>sum_feb, :march =>sum_mar, :april =>sum_apr,:may =>sum_may,:june=>sum_june,:july =>sum_july,:august =>sum_aug,:september=>sum_sep,:october=>sum_oct,:november=>sum_nov,:december=>sum_dec)	
			end			 
		end	
		
		def calculate_sum_for_all_the_details
			a = ["operating statement summary","cash flow statement summary","net cash flow","net operating income","net income"]
	#		for income_and_cash_flow in IncomeAndCashFlowDetail.all
		    income_and_cash_flow = IncomeAndCashFlowDetail.find_by_title("income detail")
				if !a.include?(income_and_cash_flow.title)
					@sum_jan=0;@sum_feb=0;@sum_mar=0;@sum_apr=0;@sum_may=0;@sum_june=0;@sum_july=0;@sum_aug=0;@sum_sep=0;@sum_oct=0;@sum_nov=0;@sum_dec=0					
					children = IncomeAndCashFlowDetail.find_all_by_parent_id(income_and_cash_flow.id)
					for child in children
						calculate_sum_for_the_records(child)
					end									
					if !children.empty?
					#~ income_and_cash_flow.update_attributes(:january =>@sum_jan , :february  =>@sum_feb, :march =>@sum_mar, :april =>@sum_apr,:may =>@sum_may,:june=>@sum_june,:july =>@sum_july,:august =>@sum_aug,:september=>@sum_sep,:october=> @sum_oct,:november=>@sum_nov,:december=>@sum_dec)	
					end
				end	
		#	end	
		end
		
		def calculate_sum_for_the_records(income_and_cash_flow)
			children = IncomeAndCashFlowDetail.find_all_by_parent_id(income_and_cash_flow.id)
			for child in children
				calculate_sum_for_the_records(child)
			end	
			@sum_jan = @sum_jan +income_and_cash_flow.january if !income_and_cash_flow.nil? and !income_and_cash_flow.january.nil?
			@sum_feb = @sum_feb +income_and_cash_flow.february if !income_and_cash_flow.nil? and !income_and_cash_flow.february.nil?
			@sum_mar = @sum_mar +income_and_cash_flow.march if !income_and_cash_flow.nil? and !income_and_cash_flow.march.nil?
			@sum_apr = @sum_apr +income_and_cash_flow.april if !income_and_cash_flow.nil? and !income_and_cash_flow.april.nil?
			@sum_may = @sum_may +income_and_cash_flow.may	if !income_and_cash_flow.nil? and !income_and_cash_flow.may.nil?
			@sum_june = @sum_june +income_and_cash_flow.june if !income_and_cash_flow.nil? and !income_and_cash_flow.june.nil?
			@sum_july = @sum_july +income_and_cash_flow.july if !income_and_cash_flow.nil? and !income_and_cash_flow.july.nil?
			@sum_aug = @sum_aug +income_and_cash_flow.august if !income_and_cash_flow.nil? and !income_and_cash_flow.august.nil?
			@sum_sep = @sum_sep +income_and_cash_flow.september if !income_and_cash_flow.nil? and !income_and_cash_flow.september.nil?
			@sum_oct = @sum_oct +income_and_cash_flow.october if !income_and_cash_flow.nil? and !income_and_cash_flow.october.nil?
			@sum_nov = @sum_nov +income_and_cash_flow.november if !income_and_cash_flow.nil? and !income_and_cash_flow.november.nil?
			@sum_dec = @sum_dec +income_and_cash_flow.december if !income_and_cash_flow.nil? and !income_and_cash_flow.december.nil?
		end	
		
		def create_new_income_and_cash_flow_details(title,parent=nil)
			parent = [nil,nil,nil,nil] if parent.nil?
			re_p=IncomeAndCashFlowDetail.create(:title=>title,:parent_id=> parent[1] ,:pcb_type=>'p')
			re_c=IncomeAndCashFlowDetail.create(:title=>title,:parent_id=> parent[2] ,:pcb_type=>'c')
			re_b=IncomeAndCashFlowDetail.create(:title=>title,:parent_id=> parent[3] ,:pcb_type=>'b')
			
			@array_record << [title,re_p.id,re_c.id,re_b.id] #if !re.nil?
		end	
		
		def get_position_for_pcb(pcb)
			if pcb == 'p'
				1
			elsif pcb == 'c'	
				2
			elsif pcb == 'b'	
				3
			end	
		end	
		
    def parsing_cash_flow_statement_summary(start_row_oss,start_col_oss,oo)
        row=start_row_oss+1				
				while(!(!oo.cell(row,2).nil? and oo.cell(row,2).class.to_s=="String" and oo.cell(row,2).downcase.strip=="income detail")  ) do					
						if !oo.cell(row,1).nil? or  !oo.cell(row,2).nil? or !oo.cell(row,3).nil?												
								last_element1 = nil
								last_element = nil
							if !oo.cell(row,1).nil?
								if oo.cell(row,1).class.to_s == "String" and (oo.cell(row,1).downcase.strip=='p' or	oo.cell(row,1).downcase.strip=='c'	or oo.cell(row,1).downcase.strip=='b')							
                  position = get_position_for_pcb(oo.cell(row,1).downcase.strip)													
									last_element = @array_record.pop
									record = IncomeAndCashFlowDetail.find_by_id(last_element[position])
									if (record.title.match(/total/) or record.title.match(/net cash/)) and record.title!="net cash flow"
										record.destroy
										last_element1 = @array_record.pop
										record = IncomeAndCashFlowDetail.find_by_id(last_element1[position])
									end									
								  store_details(record,oo,row,oo.cell(row,1).downcase.strip)
									if position!=3
										@array_record << last_element1 if last_element1										
										@array_record << last_element if last_element
										
									end																		
								end									
							elsif  oo.cell(row,2).nil? or  (!oo.cell(row,2).nil? and  oo.cell(row,2).class.to_s=="String" and !(["database:","entity:","accrual","january"].include?(oo.cell(row,2).downcase.strip)))	
								if !oo.cell(row,2).nil? 									
                  if @array_record.length > 2
										last_re = @array_record.pop
										#~ record = IncomeAndCashFlowDetail.find_by_id(last_re[1])										
										#~ record.destroy if record
										
										#~ record = IncomeAndCashFlowDetail.find_by_id(last_re[2])										
										#~ record.destroy if record

										#~ record = IncomeAndCashFlowDetail.find_by_id(last_re[3])										
										#~ record.destroy if record
									end 																		
									#~ re=IncomeAndCashFlowDetail.create(:title=>oo.cell(row,2).downcase.strip,:parent_id=> @array_record.last[1])
									#~ @array_record << [re.title,re.id] if !re.nil?
									create_new_income_and_cash_flow_details(oo.cell(row,2).downcase.strip,@array_record.last)									
								end

                if !oo.cell(row,3).nil?
									#~ re=IncomeAndCashFlowDetail.create(:title=>oo.cell(row,3).downcase.strip,:parent_id=> @array_record.last[1])
									#~ @array_record << [re.title,re.id] if !re.nil?	
									create_new_income_and_cash_flow_details(oo.cell(row,3).downcase.strip,@array_record.last)									
								end	
							end	
						end	
						row=row+1
					end	
			end		
		
    def parsing_operation_statement_summary(start_row_oss,start_col_oss,oo)
        row=start_row_oss+1				
				while(row <=oo.last_row ) do
						if !oo.cell(row,1).nil? or  !oo.cell(row,2).nil? or !oo.cell(row,3).nil?														
								last_element1 = nil
								last_element = nil													
							if !oo.cell(row,1).nil?
								if oo.cell(row,1).class.to_s == "String"  and (oo.cell(row,1).downcase.strip=='p' or	oo.cell(row,1).downcase.strip=='c'	or oo.cell(row,1).downcase.strip=='b')						
									position = get_position_for_pcb(oo.cell(row,1).downcase.strip)														
									if @array_record.last[0]=="net operating income"
										last_element = @array_record.last
									else
										last_element = @array_record.pop
                  end										
									record = IncomeAndCashFlowDetail.find_by_id(last_element[position])
									if record.title.match(/total/)
										record.destroy
										last_element1 = @array_record.pop
										record = IncomeAndCashFlowDetail.find_by_id(last_element1[position])
									end	
									#record.update_attributes(:january => oo.cell(row,2) )	
									store_details(record,oo,row,oo.cell(row,1).downcase.strip)			
									if position!=3
										@array_record << last_element1 if last_element1										
										@array_record << last_element if last_element										
									end									
								end									
							elsif  oo.cell(row,2).nil? or  (!oo.cell(row,2).nil? and  oo.cell(row,2).class.to_s=="String" and !(["database:","entity:","accrual","january"].include?(oo.cell(row,2).downcase.strip)))	
								if !oo.cell(row,2).nil? 																		
									parent_id = (oo.cell(row,2).downcase.strip=="net income") ? @array_record.first : @array_record.last
									#~ re=IncomeAndCashFlowDetail.create(:title=>oo.cell(row,2).downcase.strip,:parent_id=> parent_id)
									#~ @array_record << [re.title,re.id] if !re.nil?
									create_new_income_and_cash_flow_details(oo.cell(row,2).downcase.strip,parent_id)					
								end

                if !oo.cell(row,3).nil?
										create_new_income_and_cash_flow_details(oo.cell(row,3).downcase.strip,@array_record.last)					
									#~ re=IncomeAndCashFlowDetail.create(:title=>oo.cell(row,3).downcase.strip,:parent_id=> @array_record.last[1])
									#~ @array_record << [re.title,re.id] if !re.nil?									
								end	
							end	
						end	
						row=row+1
					end								
			end	
						
			def store_details(record,oo,row,pcb_type)			
				record.update_attributes(:january =>oo.cell(row,2) , :february  =>oo.cell(row,3), :march =>oo.cell(row,4), :april =>oo.cell(row,5) ,:may => oo.cell(row,6),:june=> oo.cell(row,7),:july =>oo.cell(row,8),:august =>oo.cell(row,9),:september=> oo.cell(row,10),:october=> oo.cell(row,11),:november=>oo.cell(row,12) ,:december=>oo.cell(row,13),:pcb_type=>pcb_type)				
			end	
			
			def page_error
				render :layout=>false
			end	
			
end
