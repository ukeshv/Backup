class OccupanciesController < ApplicationController
  require 'roo'
	require 'ftools'
	require 'spreadsheet'
  include OccupanciesHelper
  
  #added to parse occupancy and leasing excel file
  def store_new_occupancy_leasing
    @document  = Document.find(params[:id]) if params[:id]
    unless @document.nil?
      filename = @document.filename
      @document.uploaded_data = params[:new_version_file][:uploaded_data] if params[:new_version_file][:uploaded_data]
      @document.save
      @document.update_attributes(:filename => filename)
      @prop_id=1
      file_path = "#{RAILS_ROOT}/public#{@document.public_filename}"
      oo =  Excel.new(file_path)
      oo.default_sheet = oo.sheets.first
      import_occupancy_and_leasing_details(oo) if oo
    end
  end
  
  #added to display parsed occupancy and leasing excel file
  def show_new_occupancy_leasing
    month,year=9,2010
    @prop_occup_summary=PropertyOccupancySummary.find(:all, :conditions=>['month = ? and year = ? and real_estate_property_id = ?', month, year, params[:id]]) if !params[:id].nil? && !month.nil? && !year.nil?
     unless @prop_occup_summary.blank?
      @prop_occup_summary = @prop_occup_summary.first
      change_occupancy_actual=@prop_occup_summary.new_leases_actual-@prop_occup_summary.expirations_actual 
      change_occupancy_budget=@prop_occup_summary.new_leases_budget-@prop_occup_summary.expirations_budget 
      current_occup_pecent_actual=((@prop_occup_summary.current_year_sf_occupied_actual/(@prop_occup_summary.current_year_sf_occupied_actual+@prop_occup_summary.current_year_sf_occupied_budget).to_f)*100).round
      current_occup_pecent_budget=((@prop_occup_summary.current_year_sf_occupied_budget/(@prop_occup_summary.current_year_sf_occupied_actual+@prop_occup_summary.current_year_sf_occupied_budget).to_f)*100).round
      current_vacant_pecent_actual=((@prop_occup_summary.current_year_sf_vacant_actual/(@prop_occup_summary.current_year_sf_vacant_actual+@prop_occup_summary.current_year_sf_vacant_budget).to_f)*100).round
      current_vacant_pecent_budget=((@prop_occup_summary.current_year_sf_vacant_budget/(@prop_occup_summary.current_year_sf_vacant_actual+@prop_occup_summary.current_year_sf_vacant_budget).to_f)*100).round
      @leases={:renewals=>{:actual=>@prop_occup_summary.renewals_actual,:budget=>@prop_occup_summary.renewals_budget},
        :new_leases=>{:actual=>@prop_occup_summary.new_leases_actual,:budget=>@prop_occup_summary.new_leases_budget},
        :expirations=>{:actual=>@prop_occup_summary.expirations_actual,:budget=>@prop_occup_summary.expirations_budget},
        :change_in_occupancy=>{:actual=>change_occupancy_actual,:budget=>change_occupancy_budget},
        :last_year_occupancy=>{:actual=>@prop_occup_summary.last_year_sf_occupied_actual,:budget=>@prop_occup_summary.last_year_sf_occupied_budget},
        :current_occupancy_percent=>{:actual=>current_occup_pecent_actual,:budget=>current_occup_pecent_budget},
        :current_vacant_percent=>{:actual=>current_vacant_pecent_actual,:budget=>current_vacant_pecent_budget}
      }
    end
  end
  
  #added to parse debt summary excel file
  def store_new_debt_summary
    @document = Document.find(params[:id]) if params[:id]
    unless @document.nil?
      filename = @document.filename
      @document.uploaded_data = params[:new_version_file][:uploaded_data] if params[:new_version_file][:uploaded_data]
      @document.save
      @document.update_attributes(:filename => filename)
      @prop_id=1
      file_path = "#{RAILS_ROOT}/public#{@document.public_filename}"
      oo =  Excel.new(file_path)
      oo.default_sheet = oo.sheets.first
      import_debt_summary(oo) if oo
    end
  end
	
	
	def wres_12_month_parsing
		@real_estate_property= RealEstateProperty.find 2
		@finanical_year = ''
		@template_year = Date.today
		@user = User.first
		
		@without_heading=["other months' rent","rental value - employee housing","month to month rent","security deposit forfeiture","late charges/nsf's","laundry commissions","utility income","insurance referral fees","miscellaneous income","furniture rental","recreation program receipts"]
		
		@array_record = []			
		@month_list_partial =[]		
		for mo in 1..12
			@month_list_partial << Date::MONTHNAMES[mo].slice(0,3)
		end						
 #   if @month_list_partial.include?(@document.folder.name)		
			@month_de = @month_list_partial[1]#.index(@document.folder.name)+1
#		end	
#		IncomeAndCashFlowDetail.delete_all(["year = ? and resource_id =?  and resource_type=?",@finanical_year, @real_estate_property.id, @real_estate_property.class.to_s])		

		file_path = "#{RAILS_ROOT}/public/12_Month_Budget.xls"
	#	file_path = "#{RAILS_ROOT}/public/Actual_Budget_Analysis_Report.xls"			
		oo =  Excel.new(file_path)
		oo.default_sheet = oo.sheets.first
		date = oo.cell(4,'C')
		@finanical_year = date.to_date.year if !date.nil?
				
		for row in 6..oo.last_row
			for col in 1..15																						
				if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and oo.cell(row,col).downcase.strip=="operating income"		
					@array_record = []
					wres_create_new_income_and_cash_flow_details("operating statement summary")						
					start_row_oss=row;start_col_oss=col						
					wres_create_new_income_and_cash_flow_details(oo.cell(row,col).downcase.strip,@array_record.first)
					wres_parsing_operation_statement_summary(start_row_oss,start_col_oss,oo,'b','c',3)	
				end					
			end	
		end		

		 wres_calculate_sum_for_all_the_details_in_cash_flow_and_detail('b')	
		 wres_net_value_calculation('b')
		 wres_store_variance_details(@real_estate_property.id,'actual_budget')		 
	end	
  
	def wres_actual_budget_analysis_parsing
		@real_estate_property= RealEstateProperty.find 2
		@finanical_year = ''
		@template_year = Date.today
		@user = User.first
		
		@without_heading=["other months' rent","rental value - employee housing","month to month rent","security deposit forfeiture","late charges/nsf's","laundry commissions","utility income","insurance referral fees","miscellaneous income","furniture rental","recreation program receipts"]
		
		@array_record = []			
		@month_list_partial =[]		
		for mo in 1..12
			@month_list_partial << Date::MONTHNAMES[mo].slice(0,3)
		end						
 #   if @month_list_partial.include?(@document.folder.name)		
			@month_de = @month_list_partial[1]#.index(@document.folder.name)+1
#		end	
#		IncomeAndCashFlowDetail.delete_all(["year = ? and resource_id =?  and resource_type=?",@finanical_year, @real_estate_property.id, @real_estate_property.class.to_s])		

	#	file_path = "#{RAILS_ROOT}/public/12_Month_Budget.xls"
		file_path = "#{RAILS_ROOT}/public/Actual_Budget_Analysis_Report.xls"		
		oo =  Excel.new(file_path)
		oo.default_sheet = oo.sheets.first
		date = oo.cell(4,'C')
		@finanical_year = date.to_date.year if !date.nil?			

		for row in 6..oo.last_row
			for col in 1..15																						
				if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and oo.cell(row,col).downcase.strip=="operating income"		
					@array_record = []
					wres_create_new_income_and_cash_flow_details("operating statement summary")						
					start_row_oss=row;start_col_oss=col						
					wres_create_new_income_and_cash_flow_details(oo.cell(row,col).downcase.strip,@array_record.first)
					wres_parsing_operation_statement_summary(start_row_oss,start_col_oss,oo,'c','b',2)	
				end					
			end	
		end	
		wres_calculate_sum_for_all_the_details_in_cash_flow_and_detail('c')		
		wres_net_value_calculation('c')		
		wres_store_variance_details(@real_estate_property.id,'actual_budget')			
	end
	
		 # created entries in the IncomeAndCashFlowDetail table for each title , also checking title already present are not.
	def wres_create_new_income_and_cash_flow_details(title,parent=nil)
		parent = [nil,nil] if parent.nil?
		if parent[1].nil?
				re_p=IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and parent_id IS NULL and resource_id=? and resource_type=? and year=?",title,@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
		else
				re_p=IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and parent_id =? and resource_id=? and resource_type=? and year=?",title,parent[1],@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
    end			
		re_p=IncomeAndCashFlowDetail.create(:title=>title,:parent_id=> parent[1],:resource_id => @real_estate_property.id,:resource_type=>@real_estate_property.class.to_s,:user_id => @user.id,:year =>@finanical_year,:template_date =>@template_year)  if re_p.nil?
		
		PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(re_p.id, 'c', re_p.class.to_s)
		PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(re_p.id, 'b', re_p.class.to_s)
		
		@array_record << [title,re_p.id] #if !re.nil?
	end

	def wres_parsing_operation_statement_summary(start_row_oss,start_col_oss,oo,pcb_type,another_pcb_type,column_start)
			row=start_row_oss+1				
			while(row <=oo.last_row ) do
					if !oo.cell(row,1).nil? 

							last_element1 = nil
							last_element = nil													
						if !oo.cell(row,1).nil? and !oo.cell(row,2).nil? and !oo.cell(row,2).blank? 							
							 if oo.cell(row,1).downcase.strip != "total variable operating exp"													 
                if @without_heading.include?(oo.cell(row,1).downcase.strip) and @array_record.length < 3
										parent_id = (oo.cell(row,1).downcase.strip=="net income") ? @array_record.first : @array_record.last							
										wres_create_new_income_and_cash_flow_details("other income",parent_id)	                  									
								end	
								
								parent_id = (oo.cell(row,1).downcase.strip=="net income") ? @array_record.first : @array_record.last							
								wres_create_new_income_and_cash_flow_details(oo.cell(row,1).downcase.strip,parent_id)	
								
								last_element = @array_record.pop								
								record = IncomeAndCashFlowDetail.find_by_id(last_element[1])								
								if record.title.match(/total/)																		
									record.destroy 
									last_element = @array_record.pop
									record = IncomeAndCashFlowDetail.find_by_id(last_element[1])									
								end	
								wres_store_details(record,oo,row,pcb_type,another_pcb_type,column_start)										
							end							
						elsif  !oo.cell(row,1).nil?  and !oo.cell(row,1).downcase.strip.match(/created on:/)
						
							if !oo.cell(row,1).nil? 										
                @array_record.pop		if @array_record.length > 2								
								parent_id = (oo.cell(row,1).downcase.strip=="net income") ? @array_record.first : @array_record.last
								wres_create_new_income_and_cash_flow_details(oo.cell(row,1).downcase.strip,parent_id)					
							end
						end	
					end	
					row=row+1
			end								
		end
		
	def wres_store_details(record,oo,row,pcb_type,another_pcb_type,column_start)		
			if !@month_de.nil?
				prop_financial= PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(record.id, pcb_type, record.class.to_s)
				h = Hash.new
				col=column_start
				for m in 1..12
					if !oo.cell(row,col).nil? #and oo.cell(row,col).to_i > 0
						h["#{Date::MONTHNAMES[m].downcase}"] = wres_store_value_for_income_and_cash_flow(oo.cell(row,col))
					elsif prop_financial["#{Date::MONTHNAMES[m].downcase}"].nil?
						h["#{Date::MONTHNAMES[m].downcase}"] = 0 
					end	
					col=col+1
				end
        if	pcb_type == 'b'		
					h["dollar_per_sqft"] = wres_store_value_for_income_and_cash_flow(oo.cell(row,col))
					h["dollar_per_unit"] = wres_store_value_for_income_and_cash_flow(oo.cell(row,col+1))
				end	
				prop_financial.update_attributes(h)
										
				prop_financial1 = PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(record.id, another_pcb_type, record.class.to_s)
				h = Hash.new
				col=3
				for m in 1..12
					if (prop_financial1["#{Date::MONTHNAMES[m].downcase}"].nil?)
						h["#{Date::MONTHNAMES[m].downcase}"] = 0 
					end	
					col=col+1
				end								
				prop_financial1.update_attributes(h)	if !h.empty?			

			end
	end	

  def wres_store_value_for_income_and_cash_flow(value)
		if value.class.to_s =="String"
			value = value.gsub(",","") 
			if value.count("-") > 0 or value.count("(") > 0 or value.count(")") > 0
				value = value.gsub("(","").gsub(")","").gsub("-","")
				 return "-#{value}"
			else
				return value			
			end	
	  else
			return value	
    end			
	end	
	
	def wres_calculate_sum_for_all_the_details_in_cash_flow_and_detail(pcb_type)
		a = ["operating statement summary","net operating income","net income before depreciation"]
		for income_and_cash_flow in IncomeAndCashFlowDetail.all
			if !a.include?(income_and_cash_flow.title)
					wres_sum_for_each_item(income_and_cash_flow,pcb_type)
			end	
		end				
	end

	def wres_sum_for_each_item(income_and_cash_flow,pcb_type)
		children = IncomeAndCashFlowDetail.find_all_by_parent_id(income_and_cash_flow.id)
		sum_jan=0;sum_feb=0;sum_mar=0;sum_apr=0;sum_may=0;sum_june=0;sum_july=0;sum_aug=0;sum_sep=0;sum_oct=0;sum_nov=0;sum_dec=0	
		for child_par in children
			wres_sum_for_each_item(child_par,pcb_type)
			
			child = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(child_par.id, pcb_type, child_par.class.to_s)
			
			sum_jan = sum_jan +child.january       if !child.nil? and !child.january.nil?
			sum_feb = sum_feb +child.february     if !child.nil? and !child.february.nil?
			sum_mar = sum_mar +child.march      if !child.nil? and !child.march.nil?
			sum_apr = sum_apr +child.april           if !child.nil? and !child.april.nil?
			sum_may = sum_may +child.may       	if !child.nil? and !child.may.nil?
			sum_june = sum_june +child.june         if !child.nil? and !child.june.nil?
			sum_july = sum_july +child.july             if !child.nil? and !child.july.nil?
			sum_aug = sum_aug +child.august       if !child.nil? and !child.august.nil?
			sum_sep = sum_sep +child.september  if !child.nil? and !child.september.nil?
			sum_oct = sum_oct +child.october        if !child.nil? and !child.october.nil?
			sum_nov = sum_nov +child.november   if !child.nil? and !child.november.nil?
			sum_dec = sum_dec +child.december   if !child.nil? and !child.december.nil?				
		end
		if !children.empty? 
			
			income_period = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(income_and_cash_flow.id, pcb_type, income_and_cash_flow.class.to_s)
			
			income_period.update_attributes(:january =>sum_jan , :february  =>sum_feb, :march =>sum_mar, :april =>sum_apr,:may =>sum_may,:june=>sum_june,:july =>sum_july,:august =>sum_aug,:september=>sum_sep,:october=>sum_oct,:november=>sum_nov,:december=>sum_dec)	if !income_period.nil?
		end			 
	end
	
	def wres_net_value_calculation(pcb_type)
		in_cash_income = IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and  resource_id=? and resource_type=? and year=?","operating income",@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])		
		re_p_income = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(in_cash_income.id, pcb_type, in_cash_income.class.to_s)
		
		in_cash_expense = IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and  resource_id=? and resource_type=? and year=?","operating expenses",@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])		
		re_p_expense = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(in_cash_expense.id, pcb_type, in_cash_expense.class.to_s)
		
		in_cash_npi = IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and  resource_id=? and resource_type=? and year=?","net operating income",@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
		re_p_npi = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(in_cash_npi.id, pcb_type, in_cash_npi.class.to_s)
		
		in_cash_other = IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and  resource_id=? and resource_type=? and year=?","other income and expense",@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])		
		re_p_other = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(in_cash_other.id, pcb_type, in_cash_other.class.to_s)
		
		in_cash_depre = IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and  resource_id=? and resource_type=? and year=?","net income before depreciation",@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
		re_p_depre = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(in_cash_depre.id, pcb_type, in_cash_depre.class.to_s)
		
		sum_jan=0;sum_feb=0;sum_mar=0;sum_apr=0;sum_may=0;sum_june=0;sum_july=0;sum_aug=0;sum_sep=0;sum_oct=0;sum_nov=0;sum_dec=0	
		
		if !re_p_income.nil?  and !re_p_expense.nil?
			sum_jan = re_p_income.january - re_p_expense.january       if !re_p_income.january.nil? and !re_p_expense.january.nil?
			sum_feb = re_p_income.february - re_p_expense.february    if !re_p_income.february.nil? and !re_p_expense.february.nil?
			sum_mar = re_p_income.march - re_p_expense.march      if !re_p_income.march.nil? and !re_p_expense.march.nil?
			sum_apr = re_p_income.april - re_p_expense.april           if !re_p_income.april.nil? and !re_p_expense.april.nil?
			sum_may = re_p_income.may - re_p_expense.may       	if !re_p_income.may.nil? and !re_p_expense.may.nil?
			sum_june = re_p_income.june - re_p_expense.june         if !re_p_income.june.nil? and !re_p_expense.june.nil?
			sum_july = re_p_income.july - re_p_expense.july            if !re_p_income.july.nil? and !re_p_expense.july.nil?
			sum_aug = re_p_income.august - re_p_expense.august       if !re_p_income.august.nil? and !re_p_expense.august.nil?
			sum_sep = re_p_income.september - re_p_expense.september  if !re_p_income.september.nil? and !re_p_expense.september.nil?
			sum_oct = re_p_income.october - re_p_expense.october        if !re_p_income.october.nil? and !re_p_expense.october.nil?
			sum_nov = re_p_income.november - re_p_expense.november   if !re_p_income.november.nil? and !re_p_expense.november.nil?
			sum_dec = re_p_income.december - re_p_expense.december   if !re_p_income.december.nil? and !re_p_expense.december.nil?
		end	

		if !re_p_npi.nil?
				re_p_npi.update_attributes(:january =>sum_jan , :february  =>sum_feb, :march =>sum_mar, :april =>sum_apr,:may =>sum_may,:june=>sum_june,:july =>sum_july,:august =>sum_aug,:september=>sum_sep,:october=>sum_oct,:november=>sum_nov,:december=>sum_dec)			
		end	

		sum_jan=0;sum_feb=0;sum_mar=0;sum_apr=0;sum_may=0;sum_june=0;sum_july=0;sum_aug=0;sum_sep=0;sum_oct=0;sum_nov=0;sum_dec=0	
		
		if !re_p_npi.nil?  and !re_p_other.nil?
			sum_jan = re_p_npi.january - re_p_other.january       if !re_p_npi.january.nil? and !re_p_other.january.nil?
			sum_feb = re_p_npi.february - re_p_other.february    if !re_p_npi.february.nil? and !re_p_other.february.nil?
			sum_mar = re_p_npi.march - re_p_other.march      if !re_p_npi.march.nil? and !re_p_other.march.nil?
			sum_apr = re_p_npi.april - re_p_other.april           if !re_p_npi.april.nil? and !re_p_other.april.nil?
			sum_may = re_p_npi.may - re_p_other.may       	if !re_p_npi.may.nil? and !re_p_other.may.nil?
			sum_june = re_p_npi.june - re_p_other.june         if !re_p_npi.june.nil? and !re_p_other.june.nil?
			sum_july = re_p_npi.july - re_p_other.july            if !re_p_npi.july.nil? and !re_p_other.july.nil?
			sum_aug = re_p_npi.august - re_p_other.august       if !re_p_npi.august.nil? and !re_p_other.august.nil?
			sum_sep = re_p_npi.september - re_p_other.september  if !re_p_npi.september.nil? and !re_p_other.september.nil?
			sum_oct = re_p_npi.october - re_p_other.october        if !re_p_npi.october.nil? and !re_p_other.october.nil?
			sum_nov = re_p_npi.november - re_p_other.november   if !re_p_npi.november.nil? and !re_p_other.november.nil?
			sum_dec = re_p_npi.december - re_p_other.december   if !re_p_npi.december.nil? and !re_p_other.december.nil?			
		end			
		if !re_p_depre.nil?
				re_p_depre.update_attributes(:january =>sum_jan , :february  =>sum_feb, :march =>sum_mar, :april =>sum_apr,:may =>sum_may,:june=>sum_june,:july =>sum_july,:august =>sum_aug,:september=>sum_sep,:october=>sum_oct,:november=>sum_nov,:december=>sum_dec)			
		end			
		
	end	
	
	
  def wres_store_variance_details(id, type)
		type1='RealEstateProperty'
    if type=="actual_budget"
      coll = IncomeAndCashFlowDetail.find_all_by_resource_id_and_resource_type(id, type1)
    else
      coll = PropertyCapitalImprovement.find_all_by_real_estate_property_id(id)
    end
    coll.each do |itr|
      pfs =  itr.property_financial_periods
      b_row = pfs.detect {|i| i.pcb_type == 'b'}
      a_row = pfs.detect {|i| i.pcb_type == 'c'}
      unless b_row.nil? && a_row.nil?
        b_arr = [b_row.january, b_row.february, b_row.march, b_row.april, b_row.may, b_row.june, b_row.july, b_row.august, b_row.september, b_row.october, b_row.november, b_row.december]
        b_arr.each_with_index { |i,j| b_arr[j] = 0 if i.nil? }
        a_arr = [a_row.january, a_row.february, a_row.march, a_row.april, a_row.may, a_row.june, a_row.july, a_row.august, a_row.september, a_row.october, a_row.november, a_row.december]
        a_arr.each_with_index { |i,j| a_arr[j] = 0 if i.nil? }
        var_arr = []
        per_arr = []
        0.upto(11) do |indx|
					if type=="actual_budget"
            var_arr[indx] = wres_find_income_or_expense(itr) ? (b_arr[indx].to_f - a_arr[indx].to_f) : (a_arr[indx].to_f -  b_arr[indx].to_f)
          else
            var_arr[indx] =  b_arr[indx].to_f - a_arr[indx].to_f
          end
          per_arr[indx] =  (var_arr[indx] * 100) / b_arr[indx].to_f
          if  b_arr[indx].to_f==0
            per_arr[indx] = ( a_arr[indx].to_f == 0 ? 0 : -100 )
          end
          per_arr[indx]= 0.0 if per_arr[indx].to_f.nan?
        end
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_amt')
        pf.january= var_arr[0];pf.february=var_arr[1];pf.march=var_arr[2];pf.april=var_arr[3];pf.may=var_arr[4];pf.june=var_arr[5];pf.july=var_arr[6];pf.august=var_arr[7];pf.september=var_arr[8];pf.october=var_arr[9];pf.november=var_arr[10];pf.december=var_arr[11];pf.save
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_per')
        pf.january= per_arr[0];pf.february=per_arr[1];pf.march=per_arr[2];pf.april=per_arr[3];pf.may=per_arr[4];pf.june=per_arr[5];pf.july=per_arr[6];pf.august=per_arr[7];pf.september=per_arr[8];pf.october=per_arr[9];pf.november=per_arr[10];pf.december=per_arr[11];pf.save
        #PropertyFinancialPeriod.create(:source_id => itr.id, :source_type=> itr.class.to_s, :pcb_type=>'var_per', :january=> per_arr[0], :february=>per_arr[1], :march=>per_arr[2], :april=>per_arr[3], :may=>per_arr[4], :june=>per_arr[5], :july=>per_arr[6], :august=>per_arr[7], :september=>per_arr[8], :october=>per_arr[9], :november=>per_arr[10], :december=>per_arr[11])
      end
    end
  end

  def wres_find_income_or_expense(rec)
    if rec.title.downcase.match(/capital expenditure/) or rec.title.downcase.match(/expenses/)
      true
    else
      unless rec.parent_id.nil?
        wres_find_income_or_expense( IncomeAndCashFlowDetail.find(rec.parent_id) )
      else
        false
      end
    end
  end	
	
	def wres_all_units_parsing
		@real_estate_property = RealEstateProperty.find 2
		@titles = []
		file_path = "#{RAILS_ROOT}/public/all_units.xls"
	#	file_path = "#{RAILS_ROOT}/public/Actual_Budget_Analysis_Report.xls"			
		oo =  Excel.new(file_path)
		oo.default_sheet = oo.sheets.first
		v = oo.cell(3,'B')
		v1 = v.split(" ")[0].split("/")		
		@property_occupancy_summary = PropertyOccupancySummary.find_or_create_by_real_estate_property_id_and_year_and_month(@real_estate_property.id,v1[2],v1[0])
		t =0 
		for row in 6..oo.last_row
			for col in 1..oo.last_column																						
				if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and oo.cell(row,col).downcase.strip=="bldg/unit"		and t == 0					
					start_row=row;start_col_oss=col						
          wres_start_lease_parsing(start_row,oo)
          t =1
				end	
       break if t==1				
		 end	
		  break if t==1				
		end		
	end

  def wres_start_lease_parsing(start_row,oo)
		wres_store_titles(start_row,oo)		
		row = start_row +1
		while(oo.cell(row,1).nil? or (!oo.cell(row,1).nil?  and oo.cell(row,1).downcase.strip != "physical\noccupancy") ) do
			if !oo.cell(row,1).nil? and !oo.cell(row,1).blank? and !oo.cell(row,1).downcase.strip.match(/total for/) and !["bldg/unit","parameters:","parameters"].include?(oo.cell(row,1).downcase.strip)

				
				suite_number = wres_find_value_for_each_column("bldg/unit",oo,row)
				floorplan = wres_find_value_for_each_column('floorplan',oo,row)
				sqft = wres_find_value_for_each_column('sqft',oo,row)				
				property_suite = PropertySuite.find_or_create_by_suite_number_and_floor_plan_and_rented_area_and_real_estate_property_id(suite_number,floorplan,sqft,@real_estate_property.id)
				
				h = {}
				h['base_rent'] = wres_find_value_for_each_column('market rent',oo,row)
				h['amt_per_sqft'] = wres_find_value_for_each_column('amt/sqft',oo,row)
				h['effective_rate'] = wres_find_value_for_each_column('leaserent',oo,row)
				h['actual_amt_per_sqft'] = wres_find_value_for_each_column('actualamt/sqft',oo,row)
				h['tenant'] = wres_find_value_for_each_column('name',oo,row)
				h['move_in'] = wres_find_value_for_each_column('move-in',oo,row)
				h['start_date'] = wres_find_value_for_each_column('leasestart',oo,row)
				h['end_date'] = wres_find_value_for_each_column('leaseend',oo,row)			
				h['other_deposits'] = wres_find_value_for_each_column('depositson hand',oo,row)				
				h['made_ready'] = wres_find_value_for_each_column('made ready',oo,row)				
				h['property_suite_id'] = property_suite.id  if !property_suite.nil?	
        h['month'] = @property_occupancy_summary.month
        h['year']	= @property_occupancy_summary.year			
				PropertyLease.create(h)				
			end
			row=row+1			
		end	
		@titles = []
		
		
		wres_physical_occupancy_details(oo,row)
		row = row + 1
		h ={}
		while(oo.cell(row,1).nil? or (!oo.cell(row,1).nil?  and oo.cell(row,1).downcase.strip != "exposure to vacancy") ) do
			
			if !oo.cell(row,1).nil?
				if !oo.cell(row,1).nil? and oo.cell(row,1).downcase.strip == 'sqft'
					h['current_year_sf_occupied_actual'] = wres_find_value_for_each_column('occupied',oo,row)
					h['current_year_sf_vacant_actual'] = wres_find_value_for_each_column('vacant',oo,row)
					h['total_building_rentable_s'] = wres_find_value_for_each_column('total',oo,row)
				elsif !oo.cell(row,1).nil? and oo.cell(row,1).downcase.strip == 'unit count'					
					h['current_year_units_occupied_actual'] = wres_find_value_for_each_column('occupied',oo,row)
					h['current_year_units_vacant_actual'] = wres_find_value_for_each_column('vacant',oo,row)
					h['current_year_units_total_actual'] = wres_find_value_for_each_column('total',oo,row)
				end	
			end	
			row=row+1				
		end	
		@property_occupancy_summary.update_attributes(h) if !h.empty?
		
		@titles = []
		wres_exposure_to_vacancy_details(oo,row)		
		row = row +1
		h={}
		
		while(oo.cell(row,1).nil? or (!oo.cell(row,1).nil?  and oo.cell(row,1).downcase.strip != "rental rates") ) do
			
			if !oo.cell(row,1).nil?
				if !oo.cell(row,1).nil? and oo.cell(row,1).downcase.strip == 'currently vacant units'
					h['currently_vacant_leases_number'] = wres_find_value_for_each_column('number',oo,row)
					h['currently_vacant_leases_percentage'] = ( h['currently_vacant_leases_number'] *100/ @property_occupancy_summary.current_year_units_total_actual ).abs.round(2)
					
				elsif !oo.cell(row,1).nil? and oo.cell(row,1).downcase.strip == 'less vacant leased'					
					h['vacant_leased_number'] = wres_find_value_for_each_column('number',oo,row)
					h['vacant_leased_percentage'] =( h['vacant_leased_number'] *100/ @property_occupancy_summary.current_year_units_total_actual ).abs.round(2)
					
				elsif !oo.cell(row,1).nil? and oo.cell(row,1).downcase.strip == 'plus occupied on notice'					
					h['occupied_on_notice_number'] = wres_find_value_for_each_column('number',oo,row)
					h['occupied_on_notice_percentage'] = ( h['occupied_on_notice_number'] *100/ @property_occupancy_summary.current_year_units_total_actual ).abs.round(2)
					
				elsif !oo.cell(row,1).nil? and oo.cell(row,1).downcase.strip == 'less occupied pre-leased'					
					h['occupied_preleased_number'] = wres_find_value_for_each_column('number',oo,row)
					h['occupied_preleased_percentage'] = ( h['occupied_preleased_number'] *100/ @property_occupancy_summary.current_year_units_total_actual ).abs.round(2)
					
				elsif !oo.cell(row,1).nil? and oo.cell(row,1).downcase.strip == 'net exposure to vacancy'					
					h['net_exposure_to_vacancy_number'] = wres_find_value_for_each_column('number',oo,row)
					h['net_exposure_to_vacancy_percentage'] =( h['net_exposure_to_vacancy_number'] *100/ @property_occupancy_summary.current_year_units_total_actual ).abs.round(2)			
				end	
			end	
			row=row+1				
		end	    
		@property_occupancy_summary.update_attributes(h) if !h.empty?		
		
	end	
	
	def wres_exposure_to_vacancy_details(oo,row)
		arr =["number","%"]
		for col in 1..oo.last_column
			  if !oo.cell(row,col).nil? and !oo.cell(row,col).blank?
						if arr.include?(oo.cell(row,col).downcase.strip)
							@titles << [oo.cell(row,col).downcase.strip, col] if @titles.length < 2
						end	
				end	
		end		
	end	
	
	def wres_physical_occupancy_details(oo,row)
		arr =["physical occupancy","occupied","vacant","total"]
		for col in 1..oo.last_column
			  if !oo.cell(row,col).nil? and !oo.cell(row,col).blank?
						if arr.include?(oo.cell(row,col).downcase.strip)
							@titles << [oo.cell(row,col).downcase.strip, col]
						end	
				end	
		end	
	end	
	
	def wres_find_value_for_each_column(heading,oo,row)
		for title in @titles
			att = title if title[0] == heading
		end	
		value=''
		if !att.nil?
		
			value = oo.cell(row,att[1]) if !oo.cell(row,att[1]).nil? and !oo.cell(row,att[1]).blank?
			value = oo.cell(row,att[1]-1) if !oo.cell(row,att[1]-1).nil? and !oo.cell(row,att[1]-1).blank?
			value = oo.cell(row,att[1]+1) if !oo.cell(row,att[1]+1).nil? and !oo.cell(row,att[1]+1).blank?
		end			
		return value
	end	
	
  def wres_store_titles(start_row,oo)	
		for col in 1..oo.last_column
				if !oo.cell(start_row,col).nil? and !oo.cell(start_row,col).blank?
					@titles << [oo.cell(start_row,col).downcase.strip.gsub("\n","") , col]
				end	
		end	
	end	
end
