class PasswordsController < ApplicationController
#	layout 'portfolio',:except=>
 	layout 'user_login'
  before_filter :login_required, :only=>'change_password'

  def new
    @password = Password.new
  end

  def create
    @password = Password.new(params[:password])
    @password.user = User.find_by_email(@password.email)
    if params[:password][:email] == ""
      flash.now[:error] = "Email address can't be blank."
      render :action => :new
    elsif @password.save
      begin
      PasswordMailer.deliver_forgot_password(@password)
      rescue
      end
      flash[:notice] = "A link to change your password has been sent to #{@password.email}."
      #redirect_back_or_default(root_path)
      redirect_to reset_message_path
    else
      flash.now[:error] = "No such email address exists."
      render :action => :new
    end
  end

  def reset
    begin
      @user = Password.find(:first, :conditions => ['reset_code = ? and expiration_date > ?', params[:reset_code], Time.now]).user
    rescue
      flash[:notice] = 'The change password URL you visited is either invalid or expired.'
      redirect_to new_password_path
    end    
  end

  def update_after_forgetting
      @user = Password.find_by_reset_code(params[:reset_code]).user
      if @user.has_role?('Shared User')
        @user.is_shared_user = true
      end
      if params[:user][:password] == params[:user][:password_confirmation]
        if params[:user][:password].match(/(?=.*\d)(?=.*([A-Z]))(?=.*([a-z]))/).nil?
          flash[:error] = 'Password should contain minimum 5 chars, 1 capital, 1 small char, 1 number'
          redirect_to :action => :reset, :reset_code => params[:reset_code]
        elsif @user.update_attributes(params[:user])        
          @user.update_attributes(:last_pwd_modified => Time.current, :last_pwd=>User.encrypt_password(params[:user][:password]))
          flash[:notice] = 'Password was successfully updated.'
          PasswordMailer.deliver_reset_password(@user)
          redirect_to login_path
        else
          flash[:error] = 'Password was not updated.'
          redirect_to :action => :reset, :reset_code => params[:reset_code]
        end
      else
        flash[:error] = 'Password Mismatch'
        redirect_to :action => :reset, :reset_code => params[:reset_code]
      end
  end
  
  def update
    @password = Password.find(params[:id])
    if @password.update_attributes(params[:password])
      @password.user.update_attributes(:last_pwd_modified => Time.current, :last_pwd=>User.encrypt_password(@password.password))
      flash[:notice] = 'Password was successfully updated.'
      redirect_to(@password)
    else
      render :action => :edit
    end
  end

  def message
  end
  
  def change_password
    flash.now[:notice] = "Please change your password as your password is expired"
    @user = current_user
  end
  
  def update_password
    @user = current_user
    @user.attributes = params[:user]
    if !params[:user][:password].nil? && !params[:user][:password].blank?
      if @user.save
        if @user.last_pwd != User.encrypt_password(params[:user][:password])
          @user.update_attributes(:last_pwd_modified => Time.current, :last_pwd=>User.encrypt_password(params[:user][:password]))
          logout_killing_session!
          flash[:notice] = "Please log in to continue"
          redirect_to login_path
        else
          flash[:error] = "Give a different password as this password is already given"
          render :action => "change_password"
        end
      else
        flash[:error] = @user.errors['password'].nil? ? "Password Confirmation #{@user.errors['password_confirmation'].class == String ? @user.errors['password_confirmation'] : @user.errors['password_confirmation'][0]}" : "Password #{@user.errors['password'].class == String ? @user.errors['password'] : @user.errors['password'][0]}"
        render :action=>'change_password'
      end
    else
      flash[:error] = "Password can't be blank"
      render :action => "change_password"
    end
  end
    
end