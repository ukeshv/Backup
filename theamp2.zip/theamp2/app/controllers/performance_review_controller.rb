class PerformanceReviewController < ApplicationController
	before_filter :login_required
	@@time = Time.now

	
	def for_notes
		@portfolio = Portfolio.find(params[:portfolio_id])
		@note = Property.find(params[:id])
		@notes = Property.find(:all, :conditions =>["portfolio_id = ?",@portfolio.id])
		@prop = PropertyStateLog.find_by_state_id_and_property_id(5,@note.id)
    #@performance_reviews = Actual.find(:all, :conditions => ["user_id = ? and	property_type_id = ? and property_id = ?",current_user.id,@portfolio.portfolio_type_id,params[:id]])
		#if request.env['HTTP_REFERER'] &&  request.env['HTTP_REFERER'].include?('acquisitions')
		if !params[:buyer_id].nil?
			@user_id_graph = @prop.action_done_by
		else
			@user_id_graph = current_user.id
		end
		      if params[:start] && params[:end]
             @actual=Actual.find(:first,:conditions=>["resource_id=? AND resource_type=? AND start_date=? AND end_date=?",@note, 'Property', params[:start],params[:end]])
             @budget=Budget.find(:first,:conditions=>["resource_id=? AND resource_type=? AND start_date=? AND end_date=?",@note, 'Property', params[:start],params[:end]])
						 @start_date = params[:start].to_date
						 @end_date = params[:end].to_date
          else
             #start_date=!@performance_reviews.empty? ? @performance_reviews[0].start_date.strftime("%Y%m%d") :Date.today.strftime("%Y%m%d")
             #end_date=!@performance_reviews.empty? ? @performance_reviews[0].end_date.strftime("%Y%m%d") : Date.today.strftime("%Y%m%d")
						 #@time_line = Actual.find(:all,:conditions=>["resource_id =? and resource_type=?",@note, 'Property'])
						 @time_line_actual = Actual.find(:all,:conditions=>["resource_id =? and resource_type=?",@note.id, 'Property'], :order => "month_and_year")
						 @time_line_rent_roll = RentRoll.find(:all,:conditions=>["resource_id =? and resource_type=?",@note, 'Property'], :order => "start_date")
						 if !(@time_line_actual.nil? || @time_line_actual.blank?)
							 @time_line_start_date = @time_line_actual.first.month_and_year
							 @time_line_end_date = @time_line_actual.last.month_and_year
						 elsif !(@time_line_rent_roll.nil? || @time_line_rent_roll.blank?)
								@time_line_start_date = @time_line_rent_roll.first.start_date
								@time_line_end_date = @time_line_rent_roll.last.end_date
						 end
						 @start_date = @@time.beginning_of_month.strftime("%Y-%m-%d")
						 @end_date = @@time.end_of_month.strftime("%Y-%m-%d")
						 @actual=Actual.find(:all,:conditions=>["resource_id =? and resource_type=? and month_and_year = ?",@note.id,'Property',@start_date])
						 @budget=Budget.find(:all,:conditions=>["resource_id =? and resource_type=? and month_and_year = ?",@note.id,'Property',@start_date])
					 end
					 if !(@actual.nil? or @budget.nil? or @actual.blank? or @budget.blank?)
			@actual_total_potential_gross_revenue = 0
			@actual_total_revenue_adjustments = 0 
			@actual_total_operating_expenses = 0
			@actual_total_debt_service = 0
			@actual_total_leasing_and_capital_costs = 0
			@actual_cash_flow_after_debt_service_before_tax = 0
			@budget_total_potential_gross_revenue = 0
			@budget_total_revenue_adjustments = 0 
			@budget_total_operating_expenses = 0
			@budget_total_debt_service = 0
			@budget_total_leasing_and_capital_costs = 0
			@budget_cash_flow_after_debt_service_before_tax = 0
			@actual.each do |act|
				@actual_total_potential_gross_revenue = act.total_potential_gross_revenue + @actual_total_potential_gross_revenue
				@actual_total_revenue_adjustments = act.total_revenue_adjustments + @actual_total_revenue_adjustments
				@actual_total_operating_expenses = act.total_operating_expenses + @actual_total_operating_expenses
				@actual_total_debt_service = act.total_debt_service + @actual_total_debt_service
				@actual_total_leasing_and_capital_costs = act.total_leasing_and_capital_costs + @actual_total_leasing_and_capital_costs
				@actual_cash_flow_after_debt_service_before_tax = act.cash_flow_after_debt_service_before_tax + @actual_cash_flow_after_debt_service_before_tax
			end
			@budget.each do |bud|
				@budget_total_potential_gross_revenue = bud.total_potential_gross_revenue + @budget_total_potential_gross_revenue
				@budget_total_revenue_adjustments = bud.total_revenue_adjustments + @budget_total_revenue_adjustments
				@budget_total_operating_expenses = bud.total_operating_expenses + @budget_total_operating_expenses
				@budget_total_debt_service = bud.total_debt_service + @budget_total_debt_service
				@budget_total_leasing_and_capital_costs = bud.total_leasing_and_capital_costs + @budget_total_leasing_and_capital_costs
				@budget_cash_flow_after_debt_service_before_tax = bud.cash_flow_after_debt_service_before_tax + @budget_cash_flow_after_debt_service_before_tax
			end
			@actual_hash = {"Gross Revenue" =>[@actual_total_potential_gross_revenue,@budget_total_potential_gross_revenue],"Revenue Adjustment" =>[@actual_total_revenue_adjustments,@budget_total_revenue_adjustments],"Operating Expenses" =>[@actual_total_operating_expenses,@budget_total_operating_expenses],"Debt Services" =>[@actual_total_debt_service,@budget_total_debt_service],"Leasing And Capital Costs" =>[@actual_total_leasing_and_capital_costs,@budget_total_leasing_and_capital_costs],"Cash Flow After Debt Service" =>[@actual_cash_flow_after_debt_service_before_tax,@budget_cash_flow_after_debt_service_before_tax]}					
		end
			@rent_roll = RentRoll.find(:all,:conditions=>["user_id = ? and resource_id =? and resource_type = ? and start_date <= ? and end_date >= ?",@user_id_graph,@note.id, 'Property',@@time.beginning_of_month.strftime("%Y-%m-%d"),@@time.end_of_month.strftime("%Y-%m-%d")])
				if !@rent_roll.nil? || !@rent_roll.blank?
			@rent_sum = 0
			@rent_area = 0
			@aged_recievables = 0
			@rent_details_count = 0
			@rent_roll.each do |i|
				@rent_details  = i.rent_details
				@rent_details_count = @rent_details.count + @rent_details_count
				@rent_details.each do |j|
					@rent_sum = j.monthly_rent + @rent_sum
					@rent_area = j.rented_area + @rent_area
					@aged_recievables = j.aged_receivables + @aged_recievables
				end
			end
					@rent_area = @rent_area/@rent_roll.count rescue ZeroDivisionError
					@rent_sum = @rent_sum/@rent_roll.count rescue ZeroDivisionError
					@aged_recievables = @aged_recievables/@rent_roll.count rescue ZeroDivisionError
		end
    render :update do |page|
			if request.env['HTTP_REFERER'] && request.env['HTTP_REFERER'].include?("acquisitions")
					page.replace_html "head_for_titles", :partial => "/acquisitions/titles/"					
					page.replace_html "overview", :partial => "/notes/portfolio_overview/"
			else
			if params[:partial_page] == "leases_and_occupancy"
				page.replace_html "head_for_titles", :partial => "/notes/head_for_titles/"
				page.replace_html "overview", :partial => "/notes/leases_and_occupancy/"
        page[:current_note].innerHTML = @note.note_id
			else
				page.replace_html "head_for_titles", :partial => "/notes/head_for_titles/"
				page.replace_html "overview", :partial => "/notes/portfolio_overview/"
				# this line is commented since above page is replaced 
				#~ if !@time_line.nil? && !@time_line.blank? 
					#~ page.replace_html "time_line_selector", :partial => "/notes/time_line_selector/" 
				#~ end
				page.call "active_title","performance_review"
        page[:current_note].innerHTML = @note.note_id
			end
			end
		end
	end
	
	def change_date
		@timeline_selector = params[:start_date].to_s
		@note = Property.find(params[:id])
		@prop = PropertyStateLog.find_by_state_id_and_property_id(5,@note.id)
		@portfolio = @note.portfolio
		@period = params[:period]
		@notes = Property.find(:all, :conditions =>["portfolio_id = ?",@portfolio.id])
		if request.env['HTTP_REFERER'] &&  request.env['HTTP_REFERER'].include?('acquisitions')
			document_id = Document.find(:first, :conditions=> ["user_id = ? and property_id = ?",@prop.action_done_by,@note.id])
			@user_id_graph = @prop.action_done_by
		else
			document_id = Document.find(:first, :conditions=> ["user_id = ? and property_id = ?",current_user.id,@note.id])
			@user_id_graph = current_user.id
		end
	  @time_line_actual = Actual.find(:all,:conditions=>["resource_id =? and resource_type=?",@note.id, 'Property'], :order => "month_and_year")
	  @time_line_rent_roll = RentRoll.find(:all,:conditions=>["resource_id =? and resource_type=?",@note.id, 'Property'], :order => "start_date")
		 if !(@time_line_actual.nil? || @time_line_actual.blank?)
			 @time_line_start_date = @time_line_actual.first.month_and_year
			 @time_line_end_date = @time_line_actual.last.month_and_year
		 elsif !(@time_line_rent_roll.nil? || @time_line_rent_roll.blank?)
				@time_line_start_date = @time_line_rent_roll.first.start_date
				@time_line_end_date = @time_line_rent_roll.last.end_date
		 end
		if params[:end_date].nil?
			@actual=Actual.find(:all,:conditions=>["resource_id =? and resource_type=? and month_and_year = ?",@note.id,params[:portfolio_type],params[:start_date]])
			@budget=Budget.find(:all,:conditions=>["resource_id =? and resource_type=? and month_and_year = ?",@note.id,params[:portfolio_type],params[:start_date]])
			@start_date = params[:start_date]
			@end_date = (params[:start_date].to_date.end_of_month).strftime("%Y-%m-%d")
		else
			@actual=Actual.find(:all,:conditions=>["resource_id =? and resource_type=? and month_and_year >= ? and month_and_year <= ?",@note.id,params[:portfolio_type],params[:start_date],params[:end_date]])
			@budget=Budget.find(:all,:conditions=>["resource_id =? and resource_type=? and month_and_year >= ? and month_and_year <= ?",@note.id,params[:portfolio_type],params[:start_date],params[:end_date]])
			@start_date = params[:start_date]
			@end_date = params[:end_date]
		end 
		if !(@actual.nil? or @budget.nil? or @actual.blank? or @budget.blank?)
			@actual_total_potential_gross_revenue = 0
			@actual_total_revenue_adjustments = 0 
			@actual_total_operating_expenses = 0
			@actual_total_debt_service = 0
			@actual_total_leasing_and_capital_costs = 0
			@actual_cash_flow_after_debt_service_before_tax = 0
			@budget_total_potential_gross_revenue = 0
			@budget_total_revenue_adjustments = 0 
			@budget_total_operating_expenses = 0
			@budget_total_debt_service = 0
			@budget_total_leasing_and_capital_costs = 0
			@budget_cash_flow_after_debt_service_before_tax = 0
			@actual.each do |act|
				@actual_total_potential_gross_revenue = act.total_potential_gross_revenue + @actual_total_potential_gross_revenue
				@actual_total_revenue_adjustments = act.total_revenue_adjustments + @actual_total_revenue_adjustments
				@actual_total_operating_expenses = act.total_operating_expenses + @actual_total_operating_expenses
				@actual_total_debt_service = act.total_debt_service + @actual_total_debt_service
				@actual_total_leasing_and_capital_costs = act.total_leasing_and_capital_costs + @actual_total_leasing_and_capital_costs
				@actual_cash_flow_after_debt_service_before_tax = act.cash_flow_after_debt_service_before_tax + @actual_cash_flow_after_debt_service_before_tax
			end
			@budget.each do |bud|
				@budget_total_potential_gross_revenue = bud.total_potential_gross_revenue + @budget_total_potential_gross_revenue
				@budget_total_revenue_adjustments = bud.total_revenue_adjustments + @budget_total_revenue_adjustments
				@budget_total_operating_expenses = bud.total_operating_expenses + @budget_total_operating_expenses
				@budget_total_debt_service = bud.total_debt_service + @budget_total_debt_service
				@budget_total_leasing_and_capital_costs = bud.total_leasing_and_capital_costs + @budget_total_leasing_and_capital_costs
				@budget_cash_flow_after_debt_service_before_tax = bud.cash_flow_after_debt_service_before_tax + @budget_cash_flow_after_debt_service_before_tax
			end
			@actual_hash = {"Gross Revenue" =>[@actual_total_potential_gross_revenue,@budget_total_potential_gross_revenue],"Revenue Adjustment" =>[@actual_total_revenue_adjustments,@budget_total_revenue_adjustments],"Operating Expenses" =>[@actual_total_operating_expenses,@budget_total_operating_expenses],"Debt Services" =>[@actual_total_debt_service,@budget_total_debt_service],"Leasing And Capital Costs" =>[@actual_total_leasing_and_capital_costs,@budget_total_leasing_and_capital_costs],"Cash Flow After Debt Service" =>[@actual_cash_flow_after_debt_service_before_tax,@budget_cash_flow_after_debt_service_before_tax]}					
		end
		render :update do |page|
			if request.env['HTTP_REFERER'] && request.env['HTTP_REFERER'].include?("acquisitions")
					#page.replace_html "overview", :partial => "/notes/portfolio_overview/"
					page.replace_html "portfolio_overview_graph", :partial => "/notes/portfolio_overview_graph/"
					#page.replace_html "time_line_selector", :partial => "/notes/time_line_selector/"
			else
			if params[:partial_page] == "leases_and_occupancy"
				page.replace_html "overview", :partial => "/notes/leases_and_occupancy/"
				page.replace_html "head_for_titles", :partial => "/notes/head_for_titles/"
				#page.replace_html "time_line_selector", :partial => "/notes/time_line_selector/"
			else
				#page.replace_html "overview", :partial => "/notes/portfolio_overview/"
				page.replace_html "portfolio_overview_graph", :partial => "/notes/portfolio_overview_graph/"
				page.replace_html "head_for_titles", :partial => "/notes/head_for_titles/"
				#page.replace_html "time_line_selector", :partial => "/notes/time_line_selector/"
			end
		end
			if !(@actual.nil? or @actual.blank?) 
				page.call "call_individual_graph", "#{params[:id]}", "graph_waterfall_chart","#{@start_date}","#{@end_date}","#{@user_id_graph}"
			end 
		end
	end
	
	
	def leases_and_occupancy
		@note = Property.find(params[:id])
		@portfolio = Portfolio.find(@note.portfolio_id)
		@notes = Property.find(:all, :conditions =>["portfolio_id = ?",@portfolio.id])
		@prop = PropertyStateLog.find_by_state_id_and_property_id(5,@note.id)
		#@rent_roll	 = RentRoll.find(:all, :conditions=>["user_id = ? and property_id = ? and property_type_id = ?",current_user.id,params[:id],@portfolio.portfolio_type_id], :group => "start_date")
		#if request.env['HTTP_REFERER'] &&  request.env['HTTP_REFERER'].include?('acquisitions')
		if !params[:buyer_id].nil?
			@user_id_graph = @prop.action_done_by
		else
			@user_id_graph = current_user.id
		end
		@rent_roll = RentRoll.find(:all,:conditions=>["user_id = ? and resource_id =? and resource_type = ? and start_date <= ? and end_date >= ?",@user_id_graph,@note.id, 'Property',@@time.beginning_of_month.strftime("%Y-%m-%d"),@@time.end_of_month.strftime("%Y-%m-%d")])
		@start_date = @@time.beginning_of_month.strftime("%Y-%m-%d")
		@end_date = @@time.end_of_month.strftime("%Y-%m-%d")
		now = Time.now.strftime('%Y%m%d')
		if !@rent_roll.nil? || !@rent_roll.blank?
			@rent_sum = 0
			@rent_area = 0
			@aged_recievables = 0
			@rent_details_count = 0
			@rent_roll.each do |i|
				@rent_details  = i.rent_details
				@rent_details_count = @rent_details.count + @rent_details_count
				@rent_details.each do |j|
					@rent_sum = j.monthly_rent + @rent_sum
					@rent_area = j.rented_area + @rent_area
					@aged_recievables = j.aged_receivables + @aged_recievables
				end
			end
					@rent_area = @rent_area/@rent_roll.count rescue ZeroDivisionError
					@rent_sum = @rent_sum/@rent_roll.count rescue ZeroDivisionError
					@aged_recievables = @aged_recievables/@rent_roll.count rescue ZeroDivisionError
		end
	  @time_line_actual = Actual.find(:all,:conditions=>["resource_id =? and resource_type=?",@note.id, 'Property'], :order => "month_and_year")
	  @time_line_rent_roll = RentRoll.find(:all,:conditions=>["resource_id =? and resource_type=?",@note.id, 'Property'], :order => "start_date")
		 if !(@time_line_actual.nil? || @time_line_actual.blank?)
			 @time_line_start_date = @time_line_actual.first.month_and_year
			 @time_line_end_date = @time_line_actual.last.month_and_year
		 elsif !(@time_line_rent_roll.nil? || @time_line_rent_roll.blank?)
				@time_line_start_date = @time_line_rent_roll.first.start_date
				@time_line_end_date = @time_line_rent_roll.last.end_date
		 end
    render :update do |page|
			if request.env['HTTP_REFERER'] && request.env['HTTP_REFERER'].include?("acquisitions")
					page.replace_html "overview", :partial => "/notes/leases_and_occupancy/"
			else
			page.replace_html "overview", :partial => "/notes/leases_and_occupancy/"
			page.replace_html "head_for_titles", :partial => "/notes/head_for_titles/"
			#page.call "call_individual_graph1","graph_occupancy_chart"
			end
		end
	end
	
	def change_chart_leases
		if params[:end_date].nil?
			params[:end_date] = (params[:start_date].to_date.end_of_month).strftime("%Y-%m-%d")
		end
		month_diff = ActiveRecord::Base.connection.select_one("SELECT TIMESTAMPDIFF(MONTH,'#{params[:start_date].to_date}','#{params[:end_date].to_date}')  as no_of_months") 
		@timeline_selector = params[:start_date].to_s
		days_diff = []
		#~ @bar1 = 0
		#~ @bar2 = 0
		#~ @bar3 = 0
		#~ @bar4 = 0
		#~ @bar5 = 0
		@note = Property.find(params[:id])
		@portfolio = @note.portfolio
		@period = params[:period]
		@notes = Property.find(:all, :conditions =>["portfolio_id = ?",@note.portfolio_id])
		@prop = PropertyStateLog.find_by_state_id_and_property_id(5,@note.id)
	  @time_line_actual = Actual.find(:all,:conditions=>["resource_id =? and resource_type=?",@note.id, 'Property'], :order => "month_and_year")
	  @time_line_rent_roll = RentRoll.find(:all,:conditions=>["resource_id =? and resource_type=?",@note.id, 'Property'], :order => "start_date")
		 if !(@time_line_actual.nil? || @time_line_actual.blank?)
			 @time_line_start_date = @time_line_actual.first.month_and_year
			 @time_line_end_date = @time_line_actual.last.month_and_year
		 elsif !(@time_line_rent_roll.nil? || @time_line_rent_roll.blank?)
				@time_line_start_date = @time_line_rent_roll.first.start_date
				@time_line_end_date = @time_line_rent_roll.last.end_date
		 end
		@start_date = params[:start_date]
		if request.env['HTTP_REFERER'] &&  request.env['HTTP_REFERER'].include?('acquisitions')
			@user_id_graph = @prop.action_done_by
		else
			@user_id_graph = current_user.id
		end
		if month_diff["no_of_months"].to_i == 0
			params[:end_date] = (params[:start_date].to_date.end_of_month).strftime("%Y-%m-%d")
			@rent_roll = RentRoll.find(:all,:conditions=>["user_id = ? and resource_id =? and resource_type = ? and start_date <= ? and end_date >= ? ",@user_id_graph,@note.id, 'Property',params[:start_date].to_date,params[:end_date].to_date])
		elsif month_diff["no_of_months"].to_i >= 1 && month_diff["no_of_months"].to_i <= 3
			
			#@rent_roll = RentRoll.find(:all,:conditions=>["user_id = ? and resource_id =? and resource_type = ? and start_date >= ? and end_date <= ? ",@user_id_graph,@note.id, 'Property',params[:start_date],params[:end_date]])
			
			@rent_roll = RentRoll.find(:all,:conditions=>["(user_id = ? and resource_id =? and resource_type = ? and ((start_date <= '#{params[:start_date].to_date}' and end_date >= '#{params[:end_date].to_date}' and TIMESTAMPDIFF(MONTH,start_date,end_date) > 3) or (start_date >= '#{params[:start_date].to_date}' and end_date <= '#{params[:end_date].to_date}' and TIMESTAMPDIFF(MONTH,start_date,end_date) < 3)) )",@user_id_graph,@note.id, 'Property'])		
			
			
		elsif month_diff["no_of_months"].to_i >= 4			
						changed_start_date = params[:start_date].to_date.strftime("%Y")
						changed_end_date = params[:end_date].to_date.strftime("%Y")
			@rent_roll = RentRoll.find(:all,:conditions=>["user_id = ? and resource_id =? and resource_type = ? and DATE_FORMAT(start_date,'%Y') <= ? and DATE_FORMAT(end_date,'%Y') >= ? ",@user_id_graph,@note.id, 'Property',changed_start_date,changed_end_date])
			#@rent_roll = RentRoll.find(:all,:conditions=>["user_id = ? and resource_id =? and resource_type = ? and start_date >= ? and end_date <= ? ",@user_id_graph,@note.id, 'Property',params[:start_date].to_date,params[:end_date].to_date])
		end
		now = Time.now.strftime('%Y%m%d')
		if !(@rent_roll.nil? || @rent_roll.blank?)
			@rent_sum = 0
			@rent_area = 0
			@aged_recievables = 0
			@rent_details_count = 0
			@rent_roll.each do |i|
				@rent_details  = i.rent_details
				@rent_details_count = @rent_details.count + @rent_details_count
				@rent_details.each do |j|
					@rent_sum = j.monthly_rent + @rent_sum
					@rent_area = j.rented_area + @rent_area
					@aged_recievables = j.aged_receivables + @aged_recievables
					#~ days_diff = ActiveRecord::Base.connection.select_one("SELECT DATEDIFF('#{j.lease_end_date }','#{now}')  as no_of_days") 
					#~ if  days_diff['no_of_days'].to_i  < 365
						#~ @bar1 = j.monthly_rent.to_i + @bar1
					#~ elsif  days_diff['no_of_days'].to_i  > 365 && days_diff['no_of_days'].to_i < 730
						#~ @bar2 = j.monthly_rent.to_i + @bar2
					#~ elsif days_diff['no_of_days'].to_i  > 730 && days_diff['no_of_days'].to_i < 1095
						#~ @bar3 = j.monthly_rent.to_i + @bar3
					#~ elsif days_diff['no_of_days'].to_i  > 1095 && days_diff['no_of_days'].to_i < 1460
						#~ @bar4 = j.monthly_rent.to_i + @bar4
					#~ else
						#~ @bar5 = j.monthly_rent.to_i + @bar5
					#~ end
				end
			end
		@rent_area = @rent_area/@rent_roll.count rescue ZeroDivisionError
		@rent_sum = @rent_sum/@rent_roll.count rescue ZeroDivisionError
		@aged_recievables = @aged_recievables/@rent_roll.count rescue ZeroDivisionError
		end
		render :update do |page|
				#page.replace_html "overview", :partial => "/notes/leases_and_occupancy/"
				page.replace_html "leases_and_occupancy_graph", :partial => "/notes/leases_and_occupancy_graph/"
				#page.replace_html "rent_roll_details", :partial => "/notes/rent_roll_details/"
				
				if !(@rent_roll.nil? or @rent_roll.blank?) 
				page.call "call_individual_graph_leases", "#{params[:id]}", "graph_leases_chart","#{params[:start_date]}","#{params[:end_date]}","#{@user_id_graph}"
				page.call "call_individual_graph_rent_distribution", "#{params[:id]}", "graph_rent_distribution_chart","#{params[:start_date]}","#{params[:end_date]}","#{@user_id_graph}"
				#page.call "call_individual_graph_leases_expiration", "#{params[:id]}", "graph_lease_expiration_chart","#{@bar1}","#{@bar2}","#{@bar3}","#{@bar4}","#{@bar5}","#{@user_id_graph}",params[:start_date],params[:end_date]
				page.call "call_individual_graph_leases_expiration", "#{params[:id]}", "graph_lease_expiration_chart","#{params[:start_date]}","#{params[:end_date]}","#{@user_id_graph}"
				end
			
		end
	end
	
end


