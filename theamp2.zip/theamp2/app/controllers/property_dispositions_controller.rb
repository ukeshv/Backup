class PropertyDispositionsController < ApplicationController
	before_filter :login_required, :find_asset_manager
	include ApplicationHelper
	include PropertiesHelper
	layout 'user',:except=>['show_comments']
	
	def index
		@status = params[:status] ? params[:status] : 3
		state_id = []
    @reset_selected_item= "yes"
		if params[:status].nil?
			@notes = RealEstateProperty.find(:all, :conditions => ["state_id is NOT NULL and user_id = ? and is_granted = ?",current_user.id,false], :order=> "created_at desc")
		elsif params[:status] == "1"
			state_id << 1 << 2 << 3
			@notes = RealEstateProperty.find(:all, :conditions => ["state_id in (?) and user_id = ? and is_granted = ?",state_id,current_user.id,false], :order=> "created_at desc")
		elsif params[:status] == "2"
			state_id << 4 << 5
			@notes = RealEstateProperty.find(:all, :conditions => ["state_id in (?) and user_id = ? and is_granted = ?",state_id,current_user.id,false], :order=> "created_at desc")
		elsif params[:status] == "3"
			@notes = RealEstateProperty.find(:all, :conditions => ["state_id is NOT NULL and user_id = ? and is_granted = ?",current_user.id,false], :order=> "created_at desc")
		else
			@notes = RealEstateProperty.find(:all, :conditions => ["state_id = ? and user_id = ? and is_granted = ?",0,current_user.id,false], :order=> "created_at desc")
		end		
		@note=RealEstateProperty.find(:first, :conditions=>["id = ? && user_id = ? && is_granted = ? && id in (?)", params[:note_id], current_user.id, false, @notes.collect{|x|x.id}]) if !params[:note_id].nil? && !@notes.empty?
		
		if @note.nil?
			@note = (!@notes.nil? && !@notes.empty?) ? @notes.first : nil
		end
		@portfolio = @note.portfolio if !@note.nil?
		@annual_noi = ( !@note.nil? && !@note.annualized_noi.nil? && (@note.annualized_noi != 0.0)) ? @note.annualized_noi : (!@note.nil?) ? annualized_noi(@note) : nil
		@note.update_attributes(:annualized_noi => @annual_noi) if !@annual_noi.nil?
		@buyer_list = Buyer.find(:all, :conditions=>["user_id = ? and resource_id = ? && resource_type = ?",current_user.id,@note.id, 'RealEstateProperty']) if !@note.nil?
		if @note.nil? || (@note.sale_price == 0 and @note.cap_rate == 0)
			@sale_price = @annual_noi / 5  if !@annual_noi.nil?
			@cap_rate = 5
		else
			@sale_price = @note.sale_price
			@cap_rate = @note.cap_rate
		end
    if request.xhr?
			render :update do |page|
				#page.replace_html "wrapouter", :partial => "filtered_properties"
				page.replace_html "overview", :partial => "listing_info"
				#~ page.replace_html "buyer", :partial => "add_buyer"
			end
		end
	end

	def move_to_marketplace
		@note = RealEstateProperty.find(params[:id])
		@note.state_id=2 if !@note.nil?
		@note.save(false)
		@portfolio = @note.portfolio if !@note.nil?
		@annual_noi = ( !@note.nil? && !@note.annualized_noi.nil? && (@note.annualized_noi != 0.0)) ? @note.annualized_noi : (!@note.nil?) ? annualized_noi(@note) : nil #Actual.find(:first, :conditions => ["user_id = ? and property_id = ?",current_user.id,@note.id]) if !@note.nil?
		if @note.sale_price == 0 and @note.cap_rate == 0
			@sale_price = @annual_noi / 5 if @annual_noi
			@cap_rate = 5
		else
			@sale_price = @note.sale_price
			@cap_rate = @note.cap_rate
		end
		RealEstatePropertyStateLog.create(:user_id => current_user.id,:action_done_by =>current_user.id,:real_estate_property_id=>params[:id],:state_id=>2,:show_hide_flag=>1)
		render :update do |page|
			#page.replace_html "overview", :partial => "listing_info"
			page.replace_html "move_to_marketplace", :partial => "add_buyer"
		end
	end

		
  def add_buyer
		@invalid_email="Invalid emails : "
    @buyers=params[:buyer]
		count=0
    @unsaved_buyers=[]
    @saved_buyers=[]
		@buyers.each do |x,y|
			user_id=current_user.id
			property_id=params[:note_id]
			buyer_name=y["company_representative"] && !y["company_representative"].blank? ? y["company_representative"] : "Sir"
			buyer=Buyer.new
			buyer.company=(y["company"]).gsub('+',' ')
			buyer.contact_email=y["contact_email"]
			buyer.company_representative=(y["company_representative"]).gsub('+',' ')
			buyer.user_id=user_id
			buyer.resource_id=property_id
			buyer.resource_type="RealEstateProperty"
			if buyer.valid?
				#buyer.save
        @saved_buyers << buyer if buyer.contact_email?
				note_info=RealEstateProperty.find(params[:note_id]) if !params[:note_id].nil?
				UserMailer.deliver_invite_buyers_property(current_user,y["contact_email"],property_id,buyer_name,note_info)  
      else
        @unsaved_buyers << buyer if buyer.contact_email?
				count=count+1          
			end
		end
    @notes = RealEstateProperty.find(:all, :conditions => ["state_id is NOT NULL and user_id = ? and is_granted = ?",current_user.id,false], :order=> "created_at desc")
    if params[:note_id]
      @note=RealEstateProperty.find(params[:note_id])
    else
      @note = @notes.first
    end
    @portfolio = @note.portfolio if @note
    @annual_noi = ( !@note.nil? && !@note.annualized_noi.nil? && (@note.annualized_noi != 0.0)) ? @note.annualized_noi : (!@note.nil?) ? annualized_noi(@note) : nil #Actual.find(:first, :conditions => ["user_id = ? and property_id = ?",current_user.id,@note.id]) if !@note.nil?
        
    if count == 0
      @saved_buyers.each { |item| item.save }
    else
      str_unsaved = @unsaved_buyers.collect{|x|x.contact_email}.join(',')
    end
    @buyer_list = Buyer.find(:all, :conditions=>["user_id = ? and resource_id = ? && resource_type = ?",current_user.id,@note.id, 'RealEstateProperty']) if !@note.nil?
    if request.xhr?
      render :update do |page|
        if count>0
          #		 page.replace_html "add_buyer", :partial => "add_buyer"
          page.call 'assign_item', 1
          page.call 'load_completer'
          #		 page.call "flash_writter", "Please check the emails provided #{@unsaved_buyers.collect{|x|x.contact_email}.join(',')}"
          page['err_buyers'].innerHTML = "Please check the emails you have given [ #{str_unsaved.empty? ? 'Email cant be blank' : str_unsaved } ]"
        else
          page.replace "add_buyer", :partial => "add_buyer"
          page.call 'assign_item', 1
          page.call "flash_writter", "Email sent successfully"
        end
				   
      end
    end
	end

	def change_view_file
		@note = RealEstateProperty.find(params[:id])
		@portfolio = @note.portfolio
    #		@requested_properties = PropertyStateLog.find(:all,:conditions =>['properties.user_id = ? and property_state_logs.property_id = ? and (property_state_logs.state_id = ? || property_state_logs.state_id = ?)',current_user.id,@note.id, 4, 6], :include=>['property'])
    #		@requested_property = (@requested_properties.nil? || @requested_properties.empty?) ? nil : (@requested_properties.collect{|x|x.state_id}.include?(6) ? nil : @requested_properties.last)
		#find_req = "select * from real_estate_property_state_logs where real_estate_property_id = #{@note.id} and state_id IN(4,6) order by created_at desc"
    #req_or_deny  = RealEstatePropertyStateLog.find_by_sql(find_req)
    req_or_deny  = RealEstatePropertyStateLog.find(:all,:conditions=>['real_estate_property_id =? && state_id IN(4)',@note.id], :order=>'created_at desc')
    @requested_properties = req_or_deny.paginate :per_page => 1 ,:page=> params[:page]
    @requested_properties = (!@requested_properties.nil? && !@requested_properties.empty? && (@requested_properties.first.state_id == 4 || @requested_properties.first.state_id == 6 ) ) ? @requested_properties : nil
    @requested_property = @requested_properties.first if !@requested_properties.nil?
    @buyer_list = Buyer.find(:all, :conditions=>["user_id = ? and resource_id = ? and resource_type = ?",current_user.id,@note.id, 'RealEstateProperty']) if !@note.nil?
    @requested_property = RealEstatePropertyStateLog.find(params[:sharing_prop]) if params[:sharing_prop]
    confirm_sharing @requested_property if params[:confirm_sharing] == "true"
    @shared_properties = RealEstatePropertyStateLog.find(:all,:conditions=>['real_estate_property_id =? && state_id IN(5)',@note.id], :order=>'created_at desc')
    @denied_properties = RealEstatePropertyStateLog.find(:all,:conditions=>['real_estate_property_id =? && state_id IN(6)',@note.id], :order=>'created_at desc')
		render :update do |page|				
			if params[:view_file] == "request_due_diligence"
				page.replace_html 'heading', :partial=>'headings'
				page.call 'enable_tab','dsp_mini2' 
				page.replace_html 'overview',:partial=>'requests_due_diligence'
				if params[:confirm_sharing] == "true"
          page.call "flash_writter", "Information has been shared"
          #					page[:select_one].innerHTML = "Information has been shared"
          #					page.visual_effect(:highlight,'select_one', :duration => 2.5,:startcolor=>"#E5FDD0")
          #					page.visual_effect :fade,'select_one',:duration => 2.5
        end
			else
				@annual_noi = ( !@note.nil? && !@note.annualized_noi.nil? && (@note.annualized_noi != 0.0)) ? @note.annualized_noi : (!@note.nil?) ? annualized_noi(@note) : nil #Actual.find(:first, :conditions => ["user_id = ? and property_id = ?",current_user.id,@note.id]) if !@note.nil?
        if @note.sale_price == 0 and @note.cap_rate == 0
          @sale_price = @annual_noi / 5 if @annual_noi
          @cap_rate = 5
        else
          @sale_price = @note.sale_price
          @cap_rate = @note.cap_rate
        end
				page.replace_html 'heading', :partial=>'headings'
				page.call 'enable_tab','dsp_mini1'
				page.replace_html 'overview',:partial=>'listing_info'
			end
		end	
	end	
	

	def show_comments
		@note = RealEstateProperty.find(params[:id])
		render :template=>'/property_dispositions/show_comments'
	end

	def deny_request 		
		@note = RealEstateProperty.find(params[:id])
		@portfolio = @note.portfolio
		# @note.update_attributes(:state_id => 2 ) this also restricted for handling multiple requests.
    @requested_property = RealEstatePropertyStateLog.find(params[:req_prop])
		#@requested_property = RealEstatePropertyStateLog.find(:last,:conditions =>['state_id = ? and real_estate_property_id = ?',4,@note.id])
		p = RealEstatePropertyStateLog.new
		p.user_id = @requested_property.user_id
		p.action_done_by = current_user.id
		p.real_estate_property_id = @note.id
		p.state_id = 6
		p.comments = params[:denial_comment]
		p.save
		#@requested_property = RealEstatePropertyStateLog.find(:last,:conditions =>['state_id = ? and real_estate_property_id = ?',6,@note.id])
		responds_to_parent do
			render :update do |page|				
				page['show_comments_form1'].reset
        page.hide 'modal_container'
        page.hide 'modal_overlay'
        page.replace_html 'denial_replacer' , "<div class=\"headerow\"><div class=\"dispositionbuttonwrapper2\" style=\"width:517px;\"><div class=\"contentrow\" style=\"color: #711739;\">Request has been denied for this buyer.</div>"
				#page.replace_html 'overview','<h3 style="color: #1EA784; margin-left: 150px;">The request from the buyer has been denied.</h3>'
        page.call "flash_writter", "Request has been denied"
        #				page[:select_one].innerHTML = "Request has been denied"
        #				page.visual_effect(:highlight,'select_one', :duration => 2.5,:startcolor=>"#E5FDD0")
        #				page.visual_effect :fade,'select_one',:duration => 2.5
			end
		end
	end	
	
	def update_cap_rate_saleprice
		@note = RealEstateProperty.find(params[:note_id])
		@note.update_attributes(:sale_price => params[:sale_price],:cap_rate=>params[:cap_rate])
		render :nothing => true, :layout => true
	end
  
	def confirm_sharing(requested_property)
		@requested_property=requested_property
		@note = RealEstateProperty.find(params[:id])
		  #@note.state_id =5  THIS is for multiple request handling [review]
    @note.save(false)
		property_state_log = RealEstatePropertyStateLog.create(:user_id=>@requested_property.user_id,:state_id =>5,:real_estate_property_id => @note.id,:action_done_by=>current_user.id)
	end
	
	def dwl_doc
		proof_doc = ProofDocument.find(params[:id])
		send_file RAILS_ROOT+'/public/'+ proof_doc.public_filename if proof_doc
	end

  def delete_buyer
    @note=RealEstateProperty.find(params[:note_id])
    Buyer.delete(params[:id])
    @buyer_list = Buyer.find(:all, :conditions=>["user_id = ? and resource_id = ? and resource_type = ?",current_user.id,@note.id, 'RealEstateProperty']) if !@note.nil?
    if request.xhr?
      render :update do |page|
        page.replace "add_buyer", :partial => "add_buyer"
        page.call "flash_writter", "Buyer deleted successfully"
      end
    end
  end
	
	def upload_flyer		
		@note=RealEstateProperty.find(params[:id]) if !params[:id].nil?
		if !@note.flyer.nil?
			@flyer=Flyer.find_by_attachable_id_and_attachable_type(@note.id,'RealEstateProperty') if !@note.nil?
			@flyer.attributes = params[:flyer] if !params[:flyer][:uploaded_data].nil?
			if @flyer.valid?
				#modified to update ipaper id & ipaper access key
				@flyer.ipaper_id = nil
				@flyer.ipaper_access_key = nil				
				#@flyer.update_attributes(:uploaded_data=>params[:flyer][:uploaded_data])if !params[:flyer][:uploaded_data].nil?
				@flyer.save
				@note.flyer=@flyer if !@flyer.nil?
				@note.save
			end
		else
			@flyer=Flyer.new(:uploaded_data=>params[:flyer][:uploaded_data]) if !params[:flyer][:uploaded_data].nil?
			@flyer.save  if !@flyer.nil?
			@note.flyer=@flyer if !@flyer.nil?
			@note.save
		end
		respond_to_parent do 
			render :update do |page|
				page.replace_html 'flyer_property',"<a href='#{download_flyer_property_disposition_path(@note.id)}'>#{@note.flyer.filename}</a>"
				page.call 'flash_writter', 'Flyer Uploaded Successfully'
			end
		end	
	end
	
	def download_flyer
		@note=RealEstateProperty.find(params[:id]) if !params[:id].nil?
		send_file RAILS_ROOT+'/public'+@note.flyer.public_filename if !@note.nil?
	end

  def inplace_store
    converte_values={'annualized_noi'=>'@template.display_currency(exact_val)','occupancy'=>'exact_val.to_s+\'%\'','property_size'=>'exact_val.to_s+\' SqFt\'','current_outstanding'=>'@template.display_currency(exact_val)', 'maturity_date'=>'nil','last_payment_date'=>'nil'}
    real_prop = RealEstateProperty.find(params[:id])
    real_prop = real_prop.real_estate_loan_details.first unless RealEstateProperty.column_names.include?("#{params[:key]}")
    unless params[:val].empty?
      #exec_str = ":#{params[:key]}=>#{params[:val].gsub(',','').to_f}"
      real_prop["#{params[:key]}"]=params[:val].gsub(',','')
      real_prop.save(false)
    end
    exact_val = real_prop["#{params[:key]}"]
    exact_val = eval(converte_values["#{params[:key]}"])
    unless exact_val.nil?
      render :update do |page|
        page.call "doChanges", "#{params[:key]}-#{params[:id]}", "#{exact_val}"
      end
    else
      render :nothing=> true
    end
  end

  def proceed_war_room
    #    elem = "<a href=\"#\" onclick=\"show_hide_asset_docs1_real_estate(\'#{params[:pid]}\',\'#{params[:folder_id]}\',\'#{params[:del_files]}\')\">Proceed with the war room.</a>"
    #    page << "jQuery('#place_proceed').html(\'#{elem}\');"
    render :update do |page|
      page.replace_html "place_proceed", "<a href=\"#\" onclick=\"show_hide_asset_docs_multi_req_real_estate('#{params[:pid]}','#{params[:folder_id]}','#{params[:del_files]}','#{params[:req_prop]}');return false;\">Proceed to War Room to share information with the Buyer.</a>"
    end
  end
	
end
