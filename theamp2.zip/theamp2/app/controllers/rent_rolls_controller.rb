class RentRollsController < ApplicationController
  before_filter :login_required
  
  def notes_rent_roll
		@portfolio = Portfolio.find(params[:portfolio_id])
    if @portfolio.portfolio_type_id == 2
  		@note = RealEstateProperty.find(params[:id])
      @notes = RealEstateProperty.find(:all, :conditions =>["portfolio_id = ?",@portfolio.id])
	  	@rent_roll= RentRoll.find(:last, :conditions=>['resource_id = ? and resource_type = ?', params[:id],'RealEstateProperty'])
    else
      @note = Property.find(params[:id])
      @notes = Property.find(:all, :conditions =>["portfolio_id = ?",@portfolio.id])
      @rent_roll= RentRoll.find(:last, :conditions=>['resource_id = ? and resource_type = ?', params[:id] ,'Property'])
    end
    if @rent_roll
    @rent_details=RentDetail.paginate(:all, :conditions=>['rent_roll_id=?', @rent_roll.id ], :page=>params[:page], :per_page=>10)
    end
    @message="Rent roll not available for selected property"
      if request.xhr?
        render :update do |page|
          if request.env['HTTP_REFERER'] &&  request.env['HTTP_REFERER'].include?("/acquisitions") 
            page.replace_html "head_for_titles", :partial => "/acquisitions/titles/"
            page.replace_html "overview", :partial => "rent_roll"
            page.call "active_title","rent_roll"
          elsif request.env['HTTP_REFERER'] &&  request.env['HTTP_REFERER'].include?("/property_acquisitions")
            page.replace_html "head_for_titles", :partial => "/property_acquisitions/titles/"
            page.replace_html "overview", :partial => "rent_roll"
            page.call "active_title","rent_roll"
          else
            page.replace_html "overview", :partial => "rent_roll"
            page.replace_html "head_for_titles", :partial => "/notes/head_for_titles/"  unless @portfolio.portfolio_type_id == 2
            page.replace_html "head_for_titles", :partial => "/properties/head_for_titles/" if @portfolio.portfolio_type_id == 2
            page.call "active_title","rent_roll"
            page[:current_note].innerHTML = @note.note_id    unless @portfolio.portfolio_type_id == 2
            page[:current_note].innerHTML = @note.property_name    if @portfolio.portfolio_type_id == 2
          end
        end
      end
  end
end
