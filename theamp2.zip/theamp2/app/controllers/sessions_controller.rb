# This controller handles the login/logout function of the site.  
class SessionsController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  include AuthenticatedSystem
  layout :change_layout

  # render new.erb.html
  def new
    if current_user && current_user.has_role?('Asset Manager') 
      redirect_to welcome_path
    elsif current_user && current_user.has_role?('Admin') 
      redirect_to admin_asset_managers_path
    elsif current_user && current_user.has_role?('Shared User') 
      redirect_to :controller=>"shared_users",:action=>"index"
    end
  end

  def create
    logout_keeping_session!
    user = User.authenticate(params[:email], params[:password])
    if user
      # Protects against session fixation attacks, causes request forgery
      # protection if user resubmits an earlier form using back
      # button. Uncomment if you understand the tradeoffs.
      # reset_session      
      new_cookie_flag = (params[:remember_me] == "1")
      handle_remember_cookie! new_cookie_flag      
      if user.has_role?('Admin')
        self.current_user = user        
        flash.now[:notice] = "Logged in successfully"
        redirect_back_or_default(admin_asset_managers_path)
			elsif user.has_role?('Asset Manager') && (user.approval_status == nil || user.approval_status == true)
        self.current_user = user
        session[:role] = 'Asset Manager'
        #~ if user.email == 'swig2011@gmail.com' || user.email == 'cmkumar2k@gmail.com' || user.email == 'jegans2020@gmail.com' || user.email == 'amplog@gmail.com' || user.email == 'adi@theamp.com' || user.email == 'jeganraj.siva@sedin.co.in'  || user.email == 'arrvind.balasubramanian@sedin.co.in' || user.email == 'theamp.swig@gmail.com'  ||  user.email == 'rftest@railsfactory.org' || user.email == 'kishore@railsfactory.org' 
        # Removed the hard coded values after adding client_type to user table
        if user.client_type == "swig"
          session[:wres_user] = false
        else
          session[:wres_user] = true
        end
        flash.now[:notice] = "Logged in successfully"
				redirect_back_or_default(welcome_path) #uncommented to activate the session return_to
        #redirect_to :controller=>"users",:action=>"welcome"#, :home_page=>"old" #comment this line and remove comment for above line when new home page is required
      elsif user && user.has_role?('Shared User')
        self.current_user = user
        session[:role] = 'Shared User'
        #Temporarily hard coded. This has to be changed soon. Emails can be appended with '||' condition.
       # if user.email == 'swig2011@gmail.com' || user.email == 'cmkumar2k@gmail.com' || user.email == 'jegans2020@gmail.com' || user.email == 'amplog@gmail.com' || user.email == 'adi@theamp.com' || user.email == 'jeganraj.siva@sedin.co.in'  || user.email == 'arrvind.balasubramanian@sedin.co.in' || user.email == 'theamp.swig@gmail.com'  ||  user.email == 'rftest@railsfactory.org' || user.email == 'kishore@railsfactory.org'
        if user.client_type == "swig"
          session[:wres_user] = false
        else
          session[:wres_user] = true
        end
        flash.now[:notice] = "Logged in successfully"
        #redirect_to :controller=>"shared_users",:action=>"index"
        redirect_back_or_default(shared_users_path)
      else
        note_failed_signin
        render :action => 'new' 
      end      
    else
      note_failed_signin
      @email       = params[:email]
      @remember_me = params[:remember_me]
      render :action => 'new'
    end
  end

  def destroy
    logout_killing_session!
    session[:role] = nil
    flash.now[:notice] = "You have been logged out."
    redirect_back_or_default('/')
  end
  
  def change_layout
    (action_name  == 'new' or action_name == 'create') ? 'user_login' : 'admin' 
  end

protected
  # Track failed login attempts
  def note_failed_signin
    flash.now[:error] = "Your email and/or password were incorrect. "
    logger.warn "Failed login for '#{params[:email]}' from #{request.remote_ip} at #{Time.now.utc}"
  end
end
