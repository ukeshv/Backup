class TasksController < ApplicationController
  def task_repeat
    #    render :layout => false
  end
  def delete_all_repeat_tasks
    Task.destroy_repeat_task(params[:task_id],params[:perform])
  end
  def delete_repeat_tasks
    Task.destroy_current_repeat_tasks(params[:task_id])
  end
  def task_completion
    @complete_task = Task.find_task(params[:task_id])
    @complete_task.update_attributes(:is_completed=>"true")
    Task.mail_task_completion(params[:task_type],params[:task_id])
  end
end
