class UsersController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  include AuthenticatedSystem
  
  # Protect these actions behind an admin login
  before_filter :login_required, :find_asset_manager, :only=>[:welcome]
  before_filter :find_user, :only => [:suspend, :unsuspend, :destroy, :purge]

  layout :change_layout
  #~ layout 'users', :except => [:welcome,:index,:new,:create, :dashboard]
  #~ layout 'user_login' , :only =>[:set_password, :verify_password]
  #~ layout 'user', :only=>[:welcome, :dashboard]
 # render new.rhtml
   
  def index
  end
  
  def new
    @user = User.new
    @user_profile_detail = UserProfileDetail.new
    @profile_errors={}
    @brochure=Brochure.new
    @user_profile_detail.is_new_user=true
    params[:interests]=[] if params[:interests]==nil
  end
 
  def create
    logout_keeping_session!
    params[:user]={} if params[:user]==nil 
    params[:interests]=[]  if params[:interests]==nil
    interests=params[:interests].join(',')
    @user = User.new(params[:user])
    @user.is_new_user=true
     p=@user.generate_password
    @user.password ,@user.password_confirmation,@user.login,@user.password_code,@user.approval_status= p,p,params[:user][:email],User.random_passwordcode,false
    @user.user_profile_detail=UserProfileDetail.new(params[:user_profile_detail])
    @user.user_profile_detail.is_new_user= true
    @user.user_profile_detail.interest=interests
    #~ @user.register! if @user && @user.valid?
    user_valid=@user.valid?
    user_profile_valid=@user.user_profile_detail.valid?
    if user_valid && user_profile_valid
	  role = Role.find_by_name('Asset Manager')
	  @user.roles << role
	  if params[:brochure]!=nil
	    @user.user_profile_detail.brochure=Brochure.new(params[:brochure])
    end 
          @user.save
        end
   @profile_errors = @user.user_profile_detail.errors if !@user.user_profile_detail.errors.nil?
    if @user.errors.empty? && @user.user_profile_detail.errors.empty?  
      redirect_back_or_default('/login')
      flash[:notice] = "Thanks for submitting your details, AMP Admin will approve you soon. You will be receiving mail shortly as soon as Admin approves you."
    else
      render :action => 'new'
    end
  end

  def activate
    logout_keeping_session!
    user = User.find_by_activation_code(params[:activation_code]) unless params[:activation_code].blank?
    case
    when (!params[:activation_code].blank?) && user && !user.active?
      user.activate!
      flash[:notice] = "Signup complete! Please sign in to continue."
      redirect_to '/login'
    when params[:activation_code].blank?
      flash[:error] = "The activation code was missing.  Please follow the URL from your email."
      redirect_back_or_default('/')
    else 
      flash[:error]  = "We couldn't find a user with that activation code -- check your email? Or maybe you've already activated -- try signing in."
      redirect_back_or_default('/')
    end
  end

  def suspend
    @user.suspend! 
    redirect_to users_path
  end

  def unsuspend
    @user.unsuspend! 
    redirect_to users_path
  end

  def destroy
    @user.delete!
    redirect_to users_path
  end

  def purge
    @user.destroy
    redirect_to users_path
  end
  
  def welcome
    session[:role] = 'Asset Manager'
    old_welcome_page if params[:home_page] == "old"
    @portfolio_real_estates= Portfolio.find(:all, :conditions=>['user_id = ?	and portfolio_type_id = 2 and name != "portfolio_created_by_system"', current_user], :order=>'created_at DESC', :limit=>5)
    shared_portfolios = Folder.find_by_sql("SELECT portfolio_id FROM folders WHERE id IN (SELECT folder_id FROM shared_folders WHERE is_property_folder =1 AND user_id = #{current_user.id })")
		@portfolio_real_estates += Portfolio.find(:all, :conditions => ["id in (?)",shared_portfolios.collect {|x| x.portfolio_id}], :limit=>5) if !(shared_portfolios.nil? || shared_portfolios.blank?)
    collect_task_coll_ids = TaskCollaborator.find(:all, :conditions => ["user_id = ? and is_completed != ?",current_user.id,true], :select=>"task_id")
    @assigned_to_me = Task.find_by_sql("SELECT * FROM `tasks` WHERE (id in (#{collect_task_coll_ids.collect{|i| i.task_id}.join(',')})  and  (is_completed is not true) and (document_id IS null or document_id is not null and document_id in (select id from documents where is_deleted = false and id in (tasks.document_id)))) order by due_by is null, due_by asc limit 4")  if !(collect_task_coll_ids.nil? || collect_task_coll_ids.blank?)
    @status_tracker = Task.find_by_sql("select *,tasks.id as tas_id from tasks where id in ( SELECT task_id FROM `task_collaborators` WHERE sharer_id = #{current_user.id} group by task_id) and ((tasks.is_completed is null or tasks.is_completed = 0) and tasks.temp_task = 0)  order by tasks.due_by is null,tasks.due_by asc limit 4")
    @real_estate_properties = RealEstateProperty.find(:all, :conditions => ["portfolio_id in (?) and user_id = ?",@portfolio_real_estates.collect{|r| r.id},current_user.id], :select=>"id")
    @real_estate_properties += RealEstateProperty.find_by_sql("SELECT id FROM real_estate_properties WHERE id in (SELECT real_estate_property_id FROM shared_folders WHERE is_property_folder = 1 AND user_id = #{current_user.id} )")
    user_owned_folders = Folder.find_by_sql("select id from folders where parent_id in (SELECT id FROM folders WHERE name = 'my_files' and parent_id = 0 and user_id = #{current_user.id})")
    user_owned_folders += Folder.find(:all, :conditions => ["name = 'my_files' and parent_id = 0 and user_id = ?",current_user.id], :select=>"id")
    user_owned_docs = Document.find(:all, :conditions => ["folder_id in (?)",user_owned_folders.collect{|x| x.id}])
    
    user_shared_tasks = TaskCollaborator.find(:all, :conditions=>["sharer_id = ? or user_id = ?",current_user.id,current_user.id], :select=>"task_id")
    
    user_owned_tasks = Task.find(:all, :conditions => ["folder_id in (?) or document_id in (?) or id in (?)",user_owned_folders.collect{|x| x.id},user_owned_docs.collect{|x| x.id},user_shared_tasks.collect{|x| x.task_id}], :select=>"id")
    
    @updated_properties = RealEstateProperty.find(:all, :conditions => ["id in (?) and real_estate_properties.property_name !='property_created_by_system'",@real_estate_properties.collect{|y| y.id}], :order => "last_updated desc, created_at desc", :limit=>"4")
    @updated_files = Document.find(:all, :conditions => ["user_id = ? && is_deleted = ? && is_master = ?",current_user.id,false,false], :order => "created_at desc", :limit=>"5")
    events_conditions = []
    events_real_estates= RealEstateProperty.find(:all, :conditions => ["id in (?) and real_estate_properties.property_name !='property_created_by_system'",@real_estate_properties.collect{|y| y.id}], :select=>"id")
    real_estate_properties_folders = Folder.find(:all, :conditions => ["real_estate_property_id in (?) and is_master = 0",events_real_estates.collect{|x| x.id}], :select => "id") if !(events_real_estates.nil? || events_real_estates.blank?)
    real_estate_properties_documents = Document.find(:all, :conditions => ["real_estate_property_id in (?)",events_real_estates.collect{|x| x.id}], :select => "id") if !(events_real_estates.nil? || events_real_estates.blank?)
    real_estate_properties_tasks = Task.find(:all, :conditions => ["real_estate_property_id in (?)",events_real_estates.collect{|x| x.id}], :select => "id") if !(events_real_estates.nil? || events_real_estates.blank?)
    events_conditions = "(resource_id IN (#{real_estate_properties_folders.collect{|x| x.id}.join(',')}) and resource_type = 'Folder')"   if !(real_estate_properties_folders.nil? || real_estate_properties_folders.blank?)
    events_conditions << "or (resource_id IN (#{real_estate_properties_documents.collect{|x| x.id}.join(',')}) and resource_type = 'Document')" if !(real_estate_properties_documents.nil? || real_estate_properties_documents.blank?)
    events_conditions << "or (resource_id IN (#{real_estate_properties_tasks.collect{|x| x.id}.join(',')}) and resource_type = 'Task')" if !(real_estate_properties_tasks.nil? || real_estate_properties_tasks.blank?)
      or_flag = !events_conditions.empty? ? " or " : " "
      events_conditions << "#{or_flag} (resource_id IN (#{user_owned_folders.collect{|x| x.id}.join(',')}))"  if !(user_owned_folders.nil? || user_owned_folders.blank?)
      events_conditions << " or (resource_id IN (#{user_owned_docs.collect{|x| x.id}.join(',')}))"  if !(user_owned_docs.nil? || user_owned_docs.blank?)
      events_conditions << " or (resource_id IN (#{user_owned_tasks.collect{|x| x.id}.join(',')}))"  if !(user_owned_tasks.nil? || user_owned_tasks.blank?)
    if !(events_conditions.nil? || events_conditions.blank?)
      folder_events = EventResource.find(:all, :conditions=>["#{events_conditions}"])
      action_type = ["create","upload","new_version","delete","permanent_delete","download","rename","restored","create_task","update_task"]  
      @events = Event.find(:all, :conditions=>["id IN (?) and action_type in (?)",folder_events.collect{|x| x.event_id},action_type], :order=>'created_at desc', :limit => "4")   if !(folder_events.nil? || folder_events.blank?)
    end  
    render :action=> 'dashboard' if params[:home_page] != "old"    
  end
  
  def new_portfolio
    @portfolio_type = PortfolioType.find(params[:id])
    render :layout => false
  end
  
  def set_password
    logout_keeping_session!
    if User.exists?(params[:id])
      @user = User.find_by_id(params[:id])
      if @user.password_code?
        if params[:user]
          @user.password = params[:user][:password]
          @user.password_confirmation = params[:user][:password_confirmation]
          @user.name = params[:user][:name]#added to set user name
          @user.is_set_password = true
          verify_password
        end
      else
        flash[:error] = "Password has been set already"
        redirect_to login_path         
      end
    else
      flash[:error] = "No such user exists."
      redirect_to login_path
    end 
  end
  
  def verify_password
    if  @user.save
      @user.password_code = nil  
      @user.save
      #flash[:notice] = "Password has been set successfully"
      flash[:notice] = "Your Password has been Set. Please re-enter your login credentials to Login to AMP."
      #redirect_to share_login_path the path is modified since even shared users will login via asset manager login
      redirect_to :controller=>"sessions",:action=>"new"
    else
      render :action => 'set_password'
    end
  end 
    
  def index
    if current_user && current_user.has_role?('Asset Manager') 
      redirect_to welcome_path
    elsif current_user && current_user.has_role?('Admin') 
      redirect_to admin_asset_managers_path
    elsif current_user && current_user.has_role?('Shared User') 
      redirect_to shared_users_path
    end    
  end
  
  def old_welcome_page
      @portfolio_notes = Portfolio.find(:all, :conditions=>['user_id = ?	and portfolio_type_id = 1 and name != "portfolio_created_by_system" ', current_user], :limit => "8", :order=>'created_at DESC') # portfolio checked with real_estate_properties    
      sql_finder = "SELECT  properties.*
                  FROM properties,property_collateral_details, rent_rolls
                  WHERE
                    properties.user_id <> #{current_user.id} AND
                    properties.state_id = 2 AND
                    properties.is_granted = 0   AND
                    properties.id NOT IN (select distinct property_id from property_state_logs where user_id = #{current_user.id} and property_id = properties.id and state_id  IN(3,6,4,5) ) AND
                    rent_rolls.resource_id = properties.id AND
                    rent_rolls.resource_type = 'Property' AND
                    property_collateral_details.property_id = properties.id
                    GROUP BY properties.id HAVING MAX(rent_rolls.updated_at)"
    @acquisition_searched_notes = Property.find_by_sql(sql_finder)
    sql_finder = "SELECT  properties.*
                  FROM properties,property_collateral_details, rent_rolls
                  WHERE
                    properties.user_id <> #{current_user.id} AND
                    ((properties.state_id = 2 and properties.id IN(select distinct property_id from property_state_logs where user_id = #{current_user.id} and property_id = properties.id and state_id  IN(3,4,6)) ) or ( properties.state_id= 4 and properties.id IN(select distinct property_id from property_state_logs where user_id = #{current_user.id} and property_id = properties.id and state_id  IN(4))  ) ) AND
                    properties.is_granted = 0   AND
                    rent_rolls.resource_id = properties.id AND
                    rent_rolls.resource_type = 'Property' AND
                    property_collateral_details.property_id = properties.id
                    GROUP BY properties.id HAVING MAX(rent_rolls.updated_at)"
    @acquisition_saved_notes = Property.find_by_sql(sql_finder)
    @acquisition_confirmed_notes = Property.find(:all,:conditions=>['property_state_logs.user_id = ? and property_state_logs.state_id = ?',current_user.id,5],:include=>['property_state_logs'], :order=> "properties.created_at desc") 
    @acquisitions = @acquisition_searched_notes + @acquisition_saved_notes + @acquisition_confirmed_notes
    @acquisitions.shuffle!
    #addded for real estate acquisition
     sql_finder = "SELECT  real_estate_properties.*
                  FROM real_estate_properties
                  WHERE
                    ( real_estate_properties.state_id = 2 or real_estate_properties.state_id = 4 ) AND
                    real_estate_properties.user_id <> #{current_user.id} AND
                    real_estate_properties.is_granted = 0   AND
                    real_estate_properties.id NOT IN (select distinct real_estate_property_id from real_estate_property_state_logs where user_id = #{current_user.id} and real_estate_property_id = real_estate_properties.id and state_id  IN(3,6,4,5) ) AND
                    real_estate_properties.occupancy IS NOT NULL and real_estate_properties.property_name !='property_created_by_system' "
    @property_acquisition_searched_notes = RealEstateProperty.find_by_sql(sql_finder)
    sql_finder = "SELECT distinct real_estate_properties.*
                  FROM real_estate_properties,rent_rolls
                  WHERE
                    real_estate_properties.user_id <> #{current_user.id} AND
                    ((real_estate_properties.state_id = 2 and real_estate_properties.id IN(select distinct real_estate_property_id from real_estate_property_state_logs where user_id = #{current_user.id} and real_estate_property_id = real_estate_properties.id and state_id  IN(3,4,6)) ) or ( real_estate_properties.state_id= 4 and real_estate_properties.id IN(select distinct real_estate_property_id from real_estate_property_state_logs where user_id = #{current_user.id} and real_estate_property_id = real_estate_properties.id and state_id  IN(3,4,6))  ) ) AND
                    real_estate_properties.id NOT IN(select distinct real_estate_property_id from real_estate_property_state_logs where user_id = #{current_user.id} and real_estate_property_id = real_estate_properties.id and state_id  IN(5)) AND
                    real_estate_properties.is_granted = 0 and real_estate_properties.property_name !='property_created_by_system' "
    @property_acquisition_saved_notes = RealEstateProperty.find_by_sql(sql_finder)
    @property_acquisition_confirmed_notes = RealEstateProperty.find(:all,:conditions=>['real_estate_property_state_logs.user_id = ? and real_estate_property_state_logs.state_id = ?',current_user.id,5],:include=>['real_estate_property_state_logs'], :order=> "real_estate_properties.created_at desc") 
    @property_acquisitions = @property_acquisition_searched_notes + @property_acquisition_saved_notes + @property_acquisition_confirmed_notes
    @property_acquisitions.shuffle!
    @dispositions = Property.find(:all, :conditions => ["state_id is NOT NULL and user_id = ? and is_granted = ?",current_user.id,false], :limit => "8")
    @property_dispositions = RealEstateProperty.find(:all, :conditions => ["state_id is NOT NULL and user_id = ? and is_granted = ? and property_name !='property_created_by_system'",current_user.id,false], :limit => "8")  
  end  

  # There's no page here to update or destroy a user.  If you add those, be
  # smart -- make sure you check that the visitor is authorized to do so, that they
  # supply their old password along with a new one to update it, etc.
  
  def change_layout
    if action_name == "welcome" || action_name == "dashboard"
      'user'
    elsif action_name == "set_password" || action_name == "verify_password"
      'user_login'
    elsif !( action_name =="welcome" || action_name == "index" || action_name =="new" || action_name == "create" || action_name == "dashboard" || action_name == "set_password" || action_name == "verify_password" || action_name =="new_real_portfolio")
      'users'
    end
  end 
  
  protected
    def find_user
      @user = User.find(params[:id])
    end
  end
