class WresPropertiesController < ApplicationController
	layout 'user'
  before_filter :user_required
  include ActionView::Helpers::NumberHelper
	include AssetsHelper
	include ApplicationHelper
	include PropertiesHelper
	include RealEstatesHelper
	include OccupanciesHelper
	include PerformanceReviewPropertyHelper
	
	def show
    @status=params[:status] ? params[:status] : 3
		@portfolio = Portfolio.find_by_id(params[:real_estate_id])
		@notes = RealEstateProperty.find(:all, :conditions=>['portfolio_id=?', @portfolio.id ], :order=> "created_at desc") if !@portfolio.nil?
		@note = RealEstateProperty.find_by_id_and_portfolio_id(params[:id], @portfolio.id) if !@portfolio.nil?
		@partial_file = "/properties/sample_pie"
		@swf_file = "Pie2D.swf"
		@xml_partial_file = "/properties/sample_pie"
		if @note
			if Date.today.month == 1
				@period = "5"
			else
				@period = "4"
			end
			@reset_selected_item=true
			for_notes_year_to_date
			#executive_overview_details_for_year
			if request.xhr?
				render :update do |page|
					page.replace_html "head_for_titles", :partial => "/properties/head_for_titles/"
					page.replace_html "overview", :partial => "/properties/portfolio_overview/"
				end
			end
		else
			render :text => "Properties does not exists"
		end
	end
	
	def summary
    render :update do |page|
      page.replace_html 'portfolio_overview_property_graph', '<div class="rhs"><div class="subheadwrapper"><div class="notesaleheadrow"><a href="#" onclick="performanceSubCalls(\'summary_sub_graph\', {example_id:123});return false;">Link for subgraph</a></div></div></div>'
    end
	end

	def financials
    render :update do |page|
      page.replace_html 'portfolio_overview_property_graph', '<div class="rhs"><div class="subheadwrapper"><div class="notesaleheadrow"><a href="#" onclick="performanceSubCalls(\'financials_sub_graph\', {temp_id:123});return false;">Link for subgraph</a></div></div></div>'
    end
	end
	
	def leases
    render :update do |page|
      page.replace_html 'portfolio_overview_property_graph', '<div class="rhs"><div class="subheadwrapper"><div class="notesaleheadrow"><a href="#" onclick="performanceSubCalls(\'leases_sub_graph\', {id:123});return false;">Link for subgraph</a></div></div></div>'
    end
	end
	
	def rent_roll
    render :update do |page|
      page.replace_html 'portfolio_overview_property_graph', '<div class="rhs"><div class="subheadwrapper"><div class="notesaleheadrow"><a href="#" onclick="performanceSubCalls(\'rent_roll_sub_graph\', {temp_id:123});return false;">Link for subgraph</a></div></div></div>'
    end
	end
	
	def capital_expenditure
    render :update do |page|
      page.replace_html 'portfolio_overview_property_graph', '<div class="rhs"><div class="subheadwrapper"><div class="notesaleheadrow"><a href="#" onclick="performanceSubCalls(\'capital_expenditure_sub_graph\', {temp_id:123});return false;">Link for subgraph</a></div></div></div>'
    end
	end
	
	def cash_and_receivables
    render :update do |page|
      page.replace_html 'portfolio_overview_property_graph', '<div class="rhs"><div class="subheadwrapper"><div class="notesaleheadrow"><a href="#" onclick="performanceSubCalls(\'cash_and_receivables_sub_graph\', {temp_id:123});return false;">Link for subgraph</a></div></div></div>'
    end
	end

  def summary_sub_graph
    render :update do |page|
     render :nothing=> true
    end
	end

	def financials_sub_graph
    render :update do |page|
     render :nothing=> true
    end
	end

	def leases_sub_graph
    render :update do |page|
     render :nothing=> true
    end
	end

	def rent_roll_sub_graph
    render :update do |page|
      render :nothing=> true
    end
	end

	def capital_expenditure_sub_graph
    render :update do |page|
     render :nothing=> true
    end
	end

	def cash_and_receivables_sub_graph
    render :update do |page|
      render :nothing=> true
    end
	end
	
end
