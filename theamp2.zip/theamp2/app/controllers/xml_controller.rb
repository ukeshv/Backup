class XmlController < ApplicationController
	before_filter :login_required
	
		def waterfall_chart
			respond_to do |format|
				format.xml{
				@sdr = []
				@values = []
				@color = ["92be0f","ab76df","f6c11d","b3daf8","f98ba6","8b98f9","eb8bf9","f9c48b","517701"]
					@note = Property.find(params[:id])
					#@actual = Actual.find_by_resource_id_and_resource_type(params[:id], 'Property')
					@prop = PropertyStateLog.find_by_state_id_and_property_id(5,@note.id)
					if request.env['HTTP_REFERER'] &&  request.env['HTTP_REFERER'].include?('acquisitions')
						user_id = @prop.action_done_by
					else
						user_id = current_user.id
					end
					#if params[:end_date].nil?
						#~ date1 = @actual.start_date.strftime("%Y%m%d") if !@actual.nil?
						#~ date2 = @actual.end_date.strftime("%Y%m%d") if !@actual.nil?
						#@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT abs(ROUND(sum(total_potential_gross_revenue))) AS total_revenue,abs(ROUND(sum(total_revenue_adjustments))) as vacancy_and_losses, abs(ROUND(sum(total_operating_expenses))) as operating_expenses,abs(ROUND(sum(net_operating_income))) as noi,abs(ROUND(sum(total_debt_service))) as debt_service, abs(ROUND(sum(total_leasing_and_capital_costs))) AS leasing_and_cap_cost, abs(ROUND(sum(cash_flow_after_debt_service_before_tax))) AS cash_flow_after_dbt_ser_bfr_cap_cost FROM actuals WHERE (user_id = #{params[:user_id_graph]} and resource_id = #{params[:id]}) and (month_and_year <= '#{params[:start_date]}') and (month_and_year >= '#{params[:end_date]}') and resource_type='Property'") : []
					#else
						#~ date1 = params[:start_date]
						#~ date2 = params[:end_date]
						@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT ABS(ROUND(sum(total_potential_gross_revenue))) AS total_revenue,abs(ROUND(sum(total_revenue_adjustments))) as vacancy_and_losses, abs(ROUND(sum(total_operating_expenses))) as operating_expenses,ABS(ROUND(sum(net_operating_income))) as noi,abs(ROUND(sum(total_debt_service))) as debt_service, abs(ROUND(sum(total_leasing_and_capital_costs))) AS leasing_and_cap_cost, abs(ROUND(sum(cash_flow_after_debt_service_before_tax))) AS cash_flow_after_dbt_ser_bfr_cap_cost FROM actuals WHERE (user_id = #{params[:user_id_graph]} and resource_id = #{params[:id]}) and (month_and_year >= '#{params[:start_date]}' and month_and_year <= '#{params[:end_date]}' and resource_type='Property') ") : []
					#end
					@values << @sdr.collect{|x| x.total_revenue.to_f}
					single_array = @values.flatten
					max_val = single_array.compact.max				
					@max_graph = (max_val.to_i * 1.25).to_i
				}
			end
		end
		
		def occupancy_chart
			month_diff = ActiveRecord::Base.connection.select_one("SELECT TIMESTAMPDIFF(MONTH,'#{params[:start_date].to_date}','#{params[:end_date].to_date}')  as no_of_months") 
			respond_to do |format|
				format.xml{
				@sdr = []
					@note = Property.find(params[:id])
					if month_diff["no_of_months"].to_i == 0
						date2 = (params[:start_date].to_date.end_of_month).strftime("%Y-%m-%d")
						@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT AVG(total_occupied) as occupied_area, AVG(total_available) as free_area FROM rent_rolls WHERE (user_id = #{params[:user_id_graph]} and resource_id = #{params[:id]}) and (DATE_FORMAT(start_date,'%Y-%m-%d') <= '#{params[:start_date]}') and (DATE_FORMAT(end_date,'%Y-%m-%d') >=  '#{date2}') and resource_type='Property'") : []
					elsif month_diff["no_of_months"].to_i >= 1 && month_diff["no_of_months"].to_i <= 3						
						
						@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT AVG(total_occupied) as occupied_area, AVG(total_available) as free_area FROM rent_rolls WHERE (user_id = #{params[:user_id_graph]} and resource_id = #{params[:id]} and resource_type = 'Property' and ((DATE_FORMAT(start_date,'%Y-%m-%d') <= '#{params[:start_date]}' and DATE_FORMAT(end_date,'%Y-%m-%d') >= '#{params[:end_date]}' and TIMESTAMPDIFF(MONTH,start_date,end_date) > 3) or (DATE_FORMAT(start_date,'%Y-%m-%d') >= '#{params[:start_date]}' and DATE_FORMAT(end_date,'%Y-%m-%d') <= '#{params[:end_date]}' and TIMESTAMPDIFF(MONTH,start_date,end_date) < 3)) )") : []						
						
						#@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT AVG(total_occupied) as occupied_area, AVG(total_available) as free_area FROM rent_rolls WHERE (user_id = #{params[:user_id_graph]} and resource_id = #{params[:id]}) and (DATE_FORMAT(start_date,'%Y-%m-%d') >= '#{params[:start_date]}') and (DATE_FORMAT(end_date,'%Y-%m-%d') <=  '#{params[:end_date]}') and resource_type='Property'") : []						
						
					elsif month_diff["no_of_months"].to_i >= 4
						#@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT AVG(total_occupied) as occupied_area, AVG(total_available) as free_area FROM rent_rolls WHERE (user_id = #{params[:user_id_graph]} and resource_id = #{params[:id]}) and (DATE_FORMAT(start_date,'%Y-%m-%d') >= '#{params[:start_date]}') and (DATE_FORMAT(end_date,'%Y-%m-%d') <=  '#{params[:end_date]}') and resource_type='Property'") : []
						params[:start_date] = params[:start_date].to_date.strftime("%Y")
						params[:end_date] = params[:end_date].to_date.strftime("%Y")
						@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT AVG(total_occupied) as occupied_area, AVG(total_available) as free_area FROM rent_rolls WHERE (user_id = #{params[:user_id_graph]} and resource_id = #{params[:id]}) and (DATE_FORMAT(start_date,'%Y') <= '#{params[:start_date]}') and (DATE_FORMAT(end_date,'%Y') >=  '#{params[:end_date]}') and resource_type='Property'") : []
					end
				}
			end
		end
		
		def rent_distribution_chart
			month_diff = ActiveRecord::Base.connection.select_one("SELECT TIMESTAMPDIFF(MONTH,'#{params[:start_date].to_date}','#{params[:end_date].to_date}')  as no_of_months") 
			respond_to do |format|
				format.xml{
				@sdr = []
					@note = Property.find(params[:id])
					if month_diff["no_of_months"].to_i == 0
						date2 = (params[:start_date].to_date.end_of_month).strftime("%Y-%m-%d")
						@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT rent_details.tenant_name, rent_details.monthly_rent, (rent_details.monthly_rent/rent_details.rented_area) as rent_sf FROM rent_details,rent_rolls WHERE (rent_rolls.id = rent_details.rent_roll_id and  rent_rolls.user_id = #{params[:user_id_graph]} and rent_rolls.resource_id = #{params[:id]}) and (DATE_FORMAT(rent_rolls.start_date,'%Y-%m-%d') <= '#{params[:start_date]}') and (DATE_FORMAT(rent_rolls.end_date,'%Y-%m-%d') >=  '#{date2}') and rent_rolls.resource_type='property' group by rent_details.tenant_name") : []
					elsif month_diff["no_of_months"].to_i >= 1 && month_diff["no_of_months"].to_i <= 3
						
						@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT rent_details.tenant_name, rent_details.monthly_rent, (rent_details.monthly_rent/rent_details.rented_area) as rent_sf FROM rent_details,rent_rolls WHERE (rent_rolls.user_id = #{params[:user_id_graph]} and rent_rolls.resource_id = #{params[:id]} and rent_rolls.resource_type = 'Property' and rent_rolls.id = rent_details.rent_roll_id and    ((DATE_FORMAT(rent_rolls.start_date,'%Y-%m-%d') <= '#{params[:start_date]}' and DATE_FORMAT(rent_rolls.end_date,'%Y-%m-%d') >= '#{params[:end_date]}' and TIMESTAMPDIFF(MONTH,start_date,end_date) > 3) or (DATE_FORMAT(rent_rolls.start_date,'%Y-%m-%d') >= '#{params[:start_date]}' and DATE_FORMAT(rent_rolls.end_date,'%Y-%m-%d') <= '#{params[:end_date]}' and TIMESTAMPDIFF(MONTH,start_date,end_date) < 3)) )  group by rent_details.tenant_name") : []					
						
						#@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT rent_details.tenant_name, rent_details.monthly_rent, (rent_details.monthly_rent/rent_details.rented_area) as rent_sf FROM rent_details,rent_rolls WHERE (rent_rolls.id = rent_details.rent_roll_id and  rent_rolls.user_id = #{params[:user_id_graph]} and rent_rolls.resource_id = #{params[:id]}) and (DATE_FORMAT(rent_rolls.start_date,'%Y-%m-%d') >= '#{params[:start_date]}') and (DATE_FORMAT(rent_rolls.end_date,'%Y-%m-%d') <=  '#{params[:end_date]}') and rent_rolls.resource_type='property'") : []
						
					elsif 
						#@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT rent_details.tenant_name, rent_details.monthly_rent, (rent_details.monthly_rent/rent_details.rented_area) as rent_sf FROM rent_details,rent_rolls WHERE (rent_rolls.id = rent_details.rent_roll_id and  rent_rolls.user_id = #{params[:user_id_graph]} and rent_rolls.resource_id = #{params[:id]}) and (DATE_FORMAT(rent_rolls.start_date,'%Y-%m-%d') >= '#{params[:start_date]}') and (DATE_FORMAT(rent_rolls.end_date,'%Y-%m-%d') <=  '#{params[:end_date]}') and rent_rolls.resource_type='property' group by rent_details.tenant_name") : []
						params[:start_date] = params[:start_date].to_date.strftime("%Y")
						params[:end_date] = params[:end_date].to_date.strftime("%Y")
						@sdr = (!params[:end_date].nil?) ? Property.find_by_sql("SELECT rent_details.tenant_name, rent_details.monthly_rent, (rent_details.monthly_rent/rent_details.rented_area) as rent_sf FROM rent_details,rent_rolls WHERE (rent_rolls.id = rent_details.rent_roll_id and  rent_rolls.user_id = #{params[:user_id_graph]} and rent_rolls.resource_id = #{params[:id]}) and (DATE_FORMAT(rent_rolls.start_date,'%Y') <= '#{params[:start_date]}') and (DATE_FORMAT(rent_rolls.end_date,'%Y') >=  '#{params[:end_date]}') and rent_rolls.resource_type='property' group by rent_details.tenant_name") : []
					end					
				}
			end
		end
		
		def lease_expiration_chart
			month_diff = ActiveRecord::Base.connection.select_one("SELECT TIMESTAMPDIFF(MONTH,'#{params[:start_date].to_date}','#{params[:end_date].to_date}')  as no_of_months") 
			respond_to do |format|
				format.xml{
				@values = []
				@sdr = []
				@note = Property.find(params[:id])
				now = Time.now.strftime('%Y%m%d')
				if month_diff["no_of_months"].to_i == 0
					#implement this query later
=begin
					@rent_roll1 = RentRoll.find_by_sql("SELECT x, sum( y ) FROM ( SELECT TIMESTAMPDIFF( YEAR, current_date( ) , lease_end_date ) AS x, `monthly_rent` y FROM rent_details,rent_rolls where (rent_rolls.user_id = #{params[:user_id_graph]} and rent_rolls.resource_id = #{params[:id]} and rent_rolls.resource_type = 'Property' and rent_rolls.id = rent_details.rent_roll_id and rent_rolls.start_date <= '#{params[:start_date].to_date}' and rent_rolls.end_date >= '#{params[:end_date].to_date}'))a GROUP BY x")					
=end
					@rent_roll = RentRoll.find(:all,:conditions=>["user_id = ? and resource_id =? and resource_type = ? and start_date <= ? and end_date >= ?",params[:user_id_graph],params[:id], 'Property',params[:start_date].to_date,params[:end_date].to_date])
					
				elsif month_diff["no_of_months"].to_i >= 1 && month_diff["no_of_months"].to_i <= 3
					
						#SELECT * FROM `rent_rolls` WHERE (user_id = 2 and resource_id =8 and resource_type = 'Property' and ((start_date <= '2010-10-01' and end_date >= '2010-12-31' and TIMESTAMPDIFF(MONTH,start_date,end_date) > 3) or (start_date >= '2010-10-01' and end_date <= '2010-12-31' and TIMESTAMPDIFF(MONTH,start_date,end_date) < 3)) )			

					@rent_roll = RentRoll.find(:all,:conditions=>["(user_id = ? and resource_id =? and resource_type = ? and ((start_date <= '#{params[:start_date].to_date}' and end_date >= '#{params[:end_date].to_date}' and TIMESTAMPDIFF(MONTH,start_date,end_date) > 3) or (start_date >= '#{params[:start_date].to_date}' and end_date <= '#{params[:end_date].to_date}' and TIMESTAMPDIFF(MONTH,start_date,end_date) < 3)) )",params[:user_id_graph],params[:id], 'Property'])		
											
					#@rent_roll = RentRoll.find(:all,:conditions=>["user_id = ? and resource_id =? and resource_type = ? and start_date >= ? and end_date <= ?",params[:user_id_graph],params[:id], 'Property',params[:start_date].to_date,params[:end_date].to_date])			
					
				elsif month_diff["no_of_months"].to_i >= 4
					#@rent_roll = RentRoll.find(:all,:conditions=>["user_id = ? and resource_id =? and resource_type = ? and start_date >= ? and end_date <= ?",params[:user_id_graph],params[:id], 'Property',params[:start_date].to_date,params[:end_date].to_date])
						changed_start_date = params[:start_date].to_date.strftime("%Y")
						changed_end_date = params[:end_date].to_date.strftime("%Y")
					@rent_roll = RentRoll.find(:all,:conditions=>["user_id = ? and resource_id =? and resource_type = ? and DATE_FORMAT(start_date,'%Y') <= ? and DATE_FORMAT(end_date,'%Y') >= ?",params[:user_id_graph],params[:id], 'Property',changed_start_date,changed_end_date])
				end
					if !@rent_roll.nil?
						@bar1 = 0
						@bar2 = 0
						@bar3 = 0
						@bar4 = 0
						@bar5 = 0
						@rent_sum = 0
						@rent_area = 0
						@aged_recievables = 0
						@rent_details_count = 0
						@rent_roll.each do |i|
							@rent_details  = i.rent_details
							@rent_details_count = @rent_details.count + @rent_details_count
							@rent_details.each do |j|
								@rent_sum = j.monthly_rent + @rent_sum
								@rent_area = j.rented_area + @rent_area
								@aged_recievables = j.aged_receivables + @aged_recievables
								days_diff = ActiveRecord::Base.connection.select_one("SELECT DATEDIFF('#{j.lease_end_date }','#{now}')  as no_of_days") 
								if  days_diff['no_of_days'].to_i  < 365
									@bar1 = j.monthly_rent.to_i + @bar1
								elsif  days_diff['no_of_days'].to_i  > 365 && days_diff['no_of_days'].to_i < 730
									@bar2 = j.monthly_rent.to_i + @bar2
								elsif days_diff['no_of_days'].to_i  > 730 && days_diff['no_of_days'].to_i < 1095
									@bar3 = j.monthly_rent.to_i + @bar3
								elsif days_diff['no_of_days'].to_i  > 1095 && days_diff['no_of_days'].to_i < 1460
									@bar4 = j.monthly_rent.to_i + @bar4
								else
									@bar5 = j.monthly_rent.to_i + @bar5
								end
							end
						end
					end
					@values << @bar1 << @bar2 << @bar3 << @bar4 << @bar5
				#else
				#	@values << params[:bar1].to_i << params[:bar2].to_i << params[:bar3].to_i << params[:bar4].to_i << params[:bar5].to_i
				#end				
				@sdr = @values 
				}
			end
		end
	
end


