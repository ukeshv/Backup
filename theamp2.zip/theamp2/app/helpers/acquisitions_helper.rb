module AcquisitionsHelper
  def generate_random_numbers(i)
    return Array.new(i){rand(i)}.join
  end
end
