# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  @@mails = []


  def truncate_extra_chars(name)
    return truncate(name, :omission => "...", :length => 20)
  end

  def truncate_extra_chars_for_expl(name,len)
    return truncate(name, :omission => "...", :length => len)
  end

  def display_date(date)
    (date.nil? || date.blank?) ? '-' : date.strftime('%m/%d/%Y')
  end

  def breadcrump_display(folder,fid)
		arr =[]
		while !folder.nil?
      arr << "<a href='#' onclick='show_folder_content(#{folder.parent_id},#{fid});return false;'>#{folder.name}</a>"
			#arr << folder.name
			folder =  MasterFolder.find_by_id(folder.parent_id)
		end
		return arr.reverse.join(" >> ")
	end

  #Called from Admin's panel to display the files count of a folder.Used in master_folders/_folders_view and master_folders/_folders_content
  def no_of_files_of_folder(folder_id, loop_starts)
    folders = MasterFolder.find(:all,:conditions=> ["parent_id = ?",folder_id])
    @folder_s = [ ] if (@folder_s.nil? || @folder_s.empty? || loop_starts)
    @doc_s = [ ] if (@doc_s.nil? || @doc_s.empty? || loop_starts)

    folders.each do |f|
      no_of_files_of_folder(f.id, false)
      @folder_s << f
    end

    documents = MasterFile.find(:all,:conditions=> ["master_folder_id = ?",folder_id])
    @doc_s += documents
    return @doc_s.length
  end

  def no_of_files_of_asset_folder(folder_id, loop_starts)
    folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id])
    @folder_s = [ ] if (@folder_s.nil? || @folder_s.empty? || loop_starts)
    @doc_s = [ ] if (@doc_s.nil? || @doc_s.empty? || loop_starts)

    folders.each do |f|
      no_of_files_of_asset_folder(f.id, false)
      @folder_s << f
    end

    documents = Document.find(:all,:conditions=> ["folder_id = ? and is_deleted=false",folder_id])
    documents.each do |d|
      sd = SharedDocument.find_by_document_id(d.id,:conditions=>["user_id = ? OR sharer_id = ?",current_user.id,current_user.id])
      @doc_s << sd if sd != nil
    end
    return @doc_s.length
  end

  #Called from Properties/_folders_row
  def shared_no_of_files_of_asset_folder(folder_id, loop_starts)
    folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id],:select=>'id')
    @folder_s = [ ] if (@folder_s.nil? || @folder_s.empty? || loop_starts)
    @doc_s = 0 if (@doc_s == 0 || loop_starts)
    #@doc_s = [ ] if (@doc_s.nil? || @doc_s.empty? || loop_starts)

    folders.each do |f|
      shared_no_of_files_of_asset_folder(f.id, false)
      @folder_s << f
    end
    documents = Document.find(:all,:conditions=> ["folder_id = ? and is_deleted=false",folder_id])
    documents.each do |d|
      sd = SharedDocument.find(:first,:conditions=>["document_id = ? and (user_id = ? OR sharer_id = ? AND user_id != sharer_id)",d.id,current_user.id,current_user.id]) #Earlier it was find_by
      owner = find_doc_owner(d.id)
      if current_user.email == owner
        if(d.folder.user == current_user || !is_folder_shared_to_current_user(d.folder_id).nil?)
          @doc_s += 1 if d.document_name == nil
        end  
      end
          @doc_s += 1 if sd != nil && current_user.email != owner && sd.document.document_name == nil
    end

    #~ documents = DocumentName.find(:all,:conditions=> ["folder_id = ? and is_deleted=false",folder_id],:select=>'id')
    #~ documents.each do |dn|
    #~ sdn = ShareDocumentName.find(:first,:conditions=>["document_name_id = ? and (user_id = ? OR sharer_id = ? AND user_id != sharer_id)",dn.id,current_user.id,current_user.id]) #Earlier it was find_by
    #~ owner = find_fn_owner(dn.id)
    #~ if current_user.email == owner
    #~ @doc_s += 1
    #~ end
    #~ @doc_s += 1 if sdn != nil && current_user.email != owner
    #~ end


    return @doc_s #.length
  end

  #Called from Properties/_folders_row
  def no_of_files_of_deleted_asset_folder(folder_id, loop_starts)
    folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=true",folder_id])
    @folder_s1 = [ ] if (@folder_s1.nil? || @folder_s1.empty? || loop_starts)
    @doc_s1 = 0 if (@doc_s1 == 0 || loop_starts)
    #@doc_s = [ ] if (@doc_s.nil? || @doc_s.empty? || loop_starts)

    folders.each do |f|
      no_of_files_of_deleted_asset_folder(f.id, false)
      @folder_s1 << f
    end

    documents = Document.count(:all,:conditions=> ["folder_id = ? and is_deleted=true",folder_id])
    @doc_s1 += documents
    return @doc_s1 #.length
  end

  def no_of_missing_files_of_asset_folder(folder_id, loop_starts)
    folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id])
    @folder_s = [ ] if (@folder_s.nil? || @folder_s.empty? || loop_starts)
    #@doc_s = [ ] if (@doc_s.nil? || @doc_s.empty? || loop_starts)
    @doc_s = [ ] if (@doc_s.nil? || loop_starts)

    folders.each do |f|
      no_of_missing_files_of_asset_folder(f.id, false)
      @folder_s << f
    end
    #a = DocumentName.find(:all,:conditions=>["document_id is NULL and is_deleted = ? and folder_id = ? and is_master = ? and property_id is not NULL and due_date is NOT NULL",false,folder_id,false])
    b = Document.find(:all,:conditions=>["is_deleted = ? and folder_id = ? and is_master = ? and property_id is not NULL and due_date is NOT NULL",false,folder_id,0])
    #@doc_s += a
    @doc_s += b
    return @doc_s.length
  end

  #Called from Properties/_folders_row
  def no_of_missing_files_of_asset_folder_real_estate(folder_id, loop_starts)
    folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id])
    @folder_s1 = [ ] if (@folder_s1.nil? || @folder_s1.empty? || loop_starts)
    #@doc_s = [ ] if (@doc_s.nil? || @doc_s.empty? || loop_starts)
    @doc_s1 = 0 if (@doc_s1 == 0 || loop_starts)
    folders.each do |f|
      no_of_missing_files_of_asset_folder_real_estate(f.id, false)
      @folder_s1 << f
    end
    # a = DocumentName.count(:all,:conditions=>["document_id is NULL and is_deleted = ? and folder_id = ? and is_master = ? and real_estate_property_id is not NULL and due_date is NOT NULL",false,folder_id,false]) # Changed find as count
    b = Document.count(:all,:conditions=>["is_deleted = ? and folder_id = ? and is_master = ? and real_estate_property_id is not NULL and due_date is NOT NULL",false,folder_id,0]) # Changed find as count
    #@doc_s1 += a
    @doc_s1 += b
    return @doc_s1 #.length - Removed length as count is mentioned in query
  end

  # To display corresponding document's image before filename in partials/docs_list
  def find_content_type(t,shared_or_unshared,is_deleted)
		excel_ext = ['xls','xlsx']
		image_ext = ['jpg','jpeg','png','gif','bmp']
		docs_ext = ['txt','doc','docx']
		ppt_ext = ['ppt','pps']
		pdf_ext = ['pdf']
    zip_ext = ['zip']
    split_filename = t.filename.split('.') if !t.filename.nil?
    ext = (split_filename.nil? || split_filename.last.nil?) ? '' :  split_filename.last.downcase
    if excel_ext.include?(ext) && shared_or_unshared  == 'shared'
      image = is_deleted == 'true' ? "asset_type_excel_shared_del.png" : "asset_type_excel_shared.png"
    elsif  excel_ext.include?(ext) && shared_or_unshared  == 'unshared'
      image = is_deleted == 'true' ? "asset_type_excel_del.png" : "asset_type_excel.png"
    elsif pdf_ext.include?(ext)  && shared_or_unshared  == 'shared'
      image = is_deleted == 'true' ? "asset_type_pdf_shared_del.png" : "asset_type_pdf_shared.png"
    elsif pdf_ext.include?(ext)  && shared_or_unshared  == 'unshared'
      image = is_deleted == 'true' ? "asset_type_pdf_del.png" : "asset_type_pdf.png"
    elsif image_ext.include?(ext)  && shared_or_unshared  == 'shared'
      image = is_deleted == 'true' ? "asset_type_image_shared_del.png" : "asset_type_image_shared.png"
    elsif image_ext.include?(ext)  && shared_or_unshared  == 'unshared'
      image = is_deleted == 'true' ? "asset_type_image_del.png" : "asset_type_image.png"
    elsif docs_ext.include?(ext) && shared_or_unshared  == 'shared'
      image = is_deleted == 'true' ? "asset_type_word_shared_del.png" : "asset_type_word_shared.png"
    elsif docs_ext.include?(ext) && shared_or_unshared  == 'unshared'
      image = is_deleted == 'true' ? "asset_type_word_del.png" : "asset_type_word.png"
    elsif ppt_ext.include?(ext) && shared_or_unshared  == 'shared'
      image = is_deleted == 'true' ? "asset_type_ppt_shared_del.png" : "asset_type_ppt_shared.png"
    elsif ppt_ext.include?(ext) && shared_or_unshared  == 'unshared'
      image = is_deleted == 'true' ? "asset_type_powerpoint_del.png" : "asset_type_powerpoint.png"
    else
      if shared_or_unshared  == 'shared'
        image = is_deleted == 'true' ? "asset_note_shared_delete.png" : "asset_note_shared.png"
      else
        image =  is_deleted == 'true' ? "asset_note_deleted.png" : "asset_note.png"
      end
    end
    return image
  end

	def breadcrump_display_asset_manager(folder)
		arr =[]
		i = 0
		while !folder.nil?
			tmp_name = "<div class='setupiconrow'><img border='0' width='16' height='16' src='/images/folder.png'></div><div class='setupheadactvelabel'><a href='' onclick=\"load_writter();new Ajax.Request('/assets/show_asset_files?folder_id=#{folder.id}&pid=#{folder.portfolio_id}');load_completer();return false;\">#{truncate_extra_chars(folder.name)}</a></div>"
			name = (i == 0) ? "<div class='setupiconrow'><img width='16' height='16' src='/images/folder.png'></div><div class='setupheadlabel'>#{truncate_extra_chars(folder.name)}</div>" :  "#{tmp_name}"
			arr << name
			folder =  Folder.find_by_id(folder.parent_id)
			i += 1
		end
		return arr.reverse.join("<div class='setupiconrow3'><img width='10' height='9' src='/images/eventsicon2.png'></div>")
	end

	def breadcrump_display_event_asset_manager(folder)
		arr =[]
		i = 0
		while !folder.nil?
			tmp_name = "<div class='setupiconrow'><img border='0' width='16' height='16' src='/images/folder.png'></div><div class='setupheadactvelabel'><a href='' onclick=\"load_writter();show_events('#{folder.id}');load_completer();return false;\">#{truncate_extra_chars(folder.name)}</a></div>"
			name = (i == 0) ? "<div class='setupiconrow'><img width='16' height='16' src='/images/folder.png'></div><div class='setupheadlabel'>#{truncate_extra_chars(folder.name)}</div>" :  "#{tmp_name}"
			arr << name
			folder =  Folder.find_by_id(folder.parent_id)
			i += 1
		end
		return arr.reverse.join("<div class='setupiconrow3'><img width='10' height='9' src='/images/eventsicon2.png'></div>")
	end

  def difference(a,b)
    over=b-a
    style=""
    if over<0
      style="color: black;  background-color: #f36668; width:250px ;float:left;overflow: visible"
    else
      percent=(b==0) ? 250 :(a/b)*250
      style="color: black;  background-color: #61cb61 ; width:#{percent}px;float:left;overflow: visible"
    end

    return style
  end

  def over(b)
    c=b.to_i
    a=c.round
    if a<0
      value="$#{-a}"
      #value="<font style='color:#CC6633'>$#{-a}left</font>"
    else
      value="$#{a}"
    end
    return value
  end

  def over_left(b)
    c=b.to_i
    a=c.round
    if a<0
      value="<font style='color:#CC6633'>$#{-a} </font>"

      #value="<font style='color:#CC6633'>$#{-a}left</font>"
    else
      value="$#{a}"
    end
    return value
  end

  def check_left(b)
    c=b.to_i
    a=c.round
    if a<0
      value=""

      #value="<font style='color:#CC6633'>$#{-a}left</font>"
    else
      value="left"
    end
    return value
  end

  def difference_fill(a,b)
    over=b-a
    percent=0
    if over>0
      diff=(b==0) ? 0 :(a/b)*250
      percent=250-diff
    end
    style="background-color: #ededed; width:#{percent}px;float:left"
  end

  def find_extension(d)
    image_extensions = ['jpg', 'jpeg', 'gif', 'png', 'bmp', 'tif','jpe', 'cgm', 'tiff','jfif','dib']
    split_filename = d.filename.split('.')
    ext = (split_filename.nil? || split_filename[1].nil?) ? '' :  split_filename[1].downcase
    #ext=d.filename.split('.')
    #is_image = image_extensions.include?(ext[1]) ? "yes" : "no"
    is_image = image_extensions.include?(ext) ? "yes" : "no"
    return is_image
  end

  def link_for_folder(resource,txt)
		if resource.class.name == "SharedFolder"
			return 	( resource.nil? ? '' : "<a href='/events/#{resource.folder.id}/folder_display'  title='#{txt}'>#{lengthy_word_simplification(txt)}</a>")
		elsif resource.class.name == "SharedDocument"
			return 	( resource.nil? ? '' : "<a href='/events/#{resource.folder.id}/folder_display'  title='#{txt}'>#{lengthy_word_simplification(txt)}</a>")
		elsif resource.class.name == "ShareDocumentName"
			return 	( resource.nil? ? '' : "<a href='/events/#{resource.folder.id}/folder_display'  title='#{txt}'>#{lengthy_word_simplification(txt)}</a>")
    elsif resource.class.name == "DocumentName"
			return 	( resource.nil? ? '' : "<a href='/events/#{resource.folder.id}/folder_display'  title='#{txt}'>#{lengthy_word_simplification(txt)}</a>")
		else
      #owner_id = Folder.find(resource.id).user.id
      #shared_folder = SharedFolder.find_by_user_id_and_sharer_id_and_folder_id(current_user.id,owner_id,resource.id)
      shared_folder = SharedFolder.find_by_user_id_and_folder_id(current_user.id,resource.id)
      if  current_user.has_role?("Shared User") && session[:role] == 'Shared User'
        if resource.real_estate_property_id.nil?
 			    return 	( resource.nil? ? '' : "<a style='cursor:pointer;'  onclick='check_download_link_for_notes(\"#{shared_folder}\",\"#{resource.portfolio_id}\",\"#{resource.id}\",\"hide_del\");' title='#{txt}'> #{lengthy_word_simplification(txt)}</a>")
        else
          if resource.portfolio.name.downcase.strip == "portfolio_created_by_system" || resource.real_estate_property.property_name.downcase.strip == "property_created_by_system"
            return 	( resource.nil? ? '' : "<a href='#'onclick='call_links_events(\"#{resource.portfolio_id}\",\"#{resource.parent_id}\");return false;' title='#{txt}'>#{lengthy_word_simplification(txt)}</a>")
          else
            return 	( resource.nil? ? '' : "<a style='cursor:pointer;' onclick='check_download_link(\"#{shared_folder}\",\"#{resource.portfolio_id}\",\"#{resource.id}\",\"hide_del\");' title='#{txt}'> #{lengthy_word_simplification(txt)}</a>")
          end
        end
      else
	  		#return 	( resource.nil? ? '' : "<a href='/events/#{resource.id}/folder_display' target='_blank' title='#{txt}'>#{lengthy_word_simplification(txt)}</a>")
        if resource.portfolio.name.downcase.strip == "portfolio_created_by_system" || resource.real_estate_property.property_name.downcase.strip == "property_created_by_system"
          if controller.controller_name == 'users' && controller.action_name == 'welcome'
            #if request.env["HTTP_REFERER"] && request.env["HTTP_REFERER"].include?('welcome')
            return ( resource.nil? ? '' : "<a href='/collaboration_hub?open_folder=#{resource.id}&pid=#{resource.portfolio.id}'>#{lengthy_word_simplification(txt)}</a>")
            #elsif request.env["HTTP_REFERER"] && request.env["HTTP_REFERER"].include?('collaboration_hub')
          elsif controller.controller_name == 'events' && controller.action_name == 'view_events_folder'
            return 	( resource.nil? ? '' : "<a href='#'onclick='call_links_events(\"#{resource.portfolio_id}\",\"#{resource.parent_id}\");return false;' title='#{txt}'>#{lengthy_word_simplification(txt)}</a>")
          end
        else
          return 	( resource.nil? ? '' : "<a href='#{real_estate_property_path(resource.portfolio.id,resource.real_estate_property.id,:open_folder => resource.id,:partial_disp=>'data_hub')}' title='#{txt}'>#{lengthy_word_simplification(txt)}</a>")
        end
      end
		end
	end

  #<%=real_estate_property_path(@portfolio.id,@note.id,:open_folder => @note.id)%> folder.real_estate_property

	def link_for_document(resource,txt)
=begin
    if  current_user.has_role?("Shared User") && session[:role] == 'Shared User'
      #owner_id = Document.find(resource.id).user.id
      #shared_doc = SharedDocument.find_by_user_id_and_sharer_id_and_document_id(current_user.id,owner_id,resource.id)
      shared_doc = SharedDocument.find_by_user_id_and_document_id(current_user.id,resource.id) if !resource.nil?
      return !shared_doc.nil? ? ( resource.nil? ? '' : "<a  style='cursor: pointer;' onclick='check_download_link_for_file(&#34;#{shared_doc}&#34;,&#34;#{resource.public_filename}&#34;);' title='#{txt}'>#{lengthy_word_simplification(txt, 10, 15)}</a>")  : ""
    else
      return 	( resource.nil? ? '' : "<a href='#{dwn_fl_path(resource.id)}' title='#{txt}'>#{lengthy_word_simplification(txt, 5, 10)}</a>")
    end
=end
  if resource
   if Document.find_by_id(resource.id).user_id == current_user.id || SharedDocument.find_by_document_id_and_user_id(resource.id,current_user.id)
    return ( resource.nil? ? '' : "<a href='#{dwn_fl_path(resource.id)}' title='#{txt}'>#{lengthy_word_simplification(txt, 5, 10)}</a>")
   else
     return	( resource.nil? ? '' : "<a href='#' onclick='flash_writter(\"Action restricted\");' title='#{txt}'>#{lengthy_word_simplification(txt, 5, 10)}</a>")
   end
  end

	end



	def event_link_formation(event)
		ev = []
		for res in event.event_resources
      if event.action_type == "rename"
        if res.resource_type == 'Document'
          ev << "#{link_for_document(res.resource,event.description2)}" if  res.resource
          ev << "#{link_for_document(res.resource,event.description)}" if  res.resource
        elsif res.resource_type == 'Task'
          ev << "#{link_for_document(res.resource.document,event.description2)}" if  res.resource
          ev << "#{link_for_document(res.resource.document,event.description)}" if  res.resource
          #ev << "#{event.description}" if  res.resource
        else
          #~ ev << "#{link_for_folder(res.resource,event.description2)}"  if  res.resource
          #~ ev << "#{link_for_folder(res.resource,event.description)}"  if  res.resource
          ev << event.description2  if  res.resource
          ev << event.description  if  res.resource
        end
      else
        if res.resource_type == 'Document'
          ev << "#{link_for_document(res.resource,event.description)}" if  res.resource
        elsif res.resource_type == 'Task'
          ev << "#{link_for_document(res.resource.document,event.description)}" if  res.resource

          #ev << "#{event.description}" if  res.resource
        else
          #ev << "#{link_for_folder(res.resource,event.description)}"  if  res.resource
          ev << lengthy_word_simplification(event.description, 5, 10)  if  res.resource
        end
      end
	  end
 		return ev
	end

  # below method is used for event time
	def display_event_time(event)
		if event and event.created_at
			dis = distance_of_time_in_words_hash(Time.now,event.created_at)
      if dis["days"]
        if dis["days"] == 1
          return "Yesterday #{event.created_at.strftime("%I:%S%p")}"
        else
          return "#{event.created_at.strftime("%m/%d/%y  %I:%S%p")}"
        end
      else

        return "#{dis['hours']} hours ago"  if dis['hours']
        return "#{dis['minutes']} minutes ago"  if dis['minutes']
        return "#{dis['seconds']} seconds ago"  if dis['seconds']
      end
		else
		  return ""
		end
	end

  def event_user_id(event)
    event_user_id = event.user_id
    return event_user_id
  end

  #below method is used to display user name
  def display_event_users(event)
    if event.user_id == current_user.id
      user_name =  "You"
      #ev = event_link_formation(event)
    else
      user = User.find_by_id(event.user_id)
      user_name = user.name? ? lengthy_word_simplification(user.name, 5, 10) :  lengthy_word_simplification(user.email, 5, 10)
      #ev =  check_event_link(event)
    end
    return user_name
  end

  #this is the new method to display all events
  def display_event(event)
    event_type = EventResource.find_by_event_id(event.id).resource_type
    val = event.action_type.downcase.strip if !event.nil?
    shared_user_exists = (val == "collaborators" || val == "de_collaborators" || val == "share" || val == "shared" || val == "unshare" ||  val == "unshared") ? !(User.find_by_id(event.shared_user_id).nil? || User.find_by_id(event.shared_user_id).blank?) : true
    if !event.nil? && !(User.find_by_id(event.user_id).nil? || User.find_by_id(event.user_id).blank?) && (shared_user_exists)
      #if event.action_type.downcase.strip == "create"
      case ( val )
      when "create":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          if event_type == "Folder"
            event_resource_id = EventResource.find_by_event_id(event.id).resource_id
            property_folder = Folder.find_by_id_and_parent_id_and_is_master(event_resource_id,0,0)
            if !(property_folder.nil? || property_folder.blank?)
              return "<img src='/images/added.png' > #{user} created the Property #{ev.join(',')}"
            else
              return "<img src='/images/added.png' > #{user} added the #{event_type} #{ev.join(',')}"
            end
          else
            return "<img src='/images/added.png' > #{user} added the #{event_type} #{ev.join(',')}"
          end
        else
          error_message(event,'deleted')
        end
        break;
      when "upload":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/uploaded.png' > #{user} uploaded the #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "new_version":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img class='sprite s_add' src='/images/icon_spacer.gif' > #{user} added a new version for the #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "delete":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/deleted.png' > #{user} deleted the #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "permanent_delete":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/permanently_deleted.png' > #{user} permanently deleted the #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "download":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          event_resource_id = EventResource.find_by_event_id(event.id).resource_id
          property_folder = Folder.find_by_id_and_parent_id_and_is_master(event_resource_id,0,0)
          if !(property_folder.nil? || property_folder.blank?)
            return "<img src='/images/download.png' > #{user} downloaded the Property #{ev.join(',')}"
          else
            return "<img src='/images/download.png' > #{user} downloaded the #{event_type} #{ev.join(',')}" 
          end  
        else
          error_message(event,'deleted')
        end
        break;
      when "rename":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/rename.png' > #{user} renamed the #{event_type} #{ev.join(' as ')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "shared":
          if !event.event_resources.empty?
          shared_user = User.find_by_id(event.shared_user_id)
          if event.user_id == current_user.id
            user = "You"
            sharer = shared_user.email if shared_user !=nil
          else
            user = User.find_by_id(event.user_id).email
            sharer = shared_user.email if shared_user !=nil
            if sharer == current_user.email
              sharer = "You"
            end
          end
          ev = event_link_formation(event)
          return "<img src='/images/shared.png' /> #{user} shared the #{event_type} #{ev.join(',')} with #{sharer}"
        else
          user = User.find_by_id(event.user_id).email
          sharer = shared_user.email if shared_user !=nil
        end
        break;
      when "moved":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/move.gif' > #{user} moved the #{event_type} #{ev.join(',')} #{event.description2}"
        else
          error_message(event,'deleted')
        end
        break;
      when "copied":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/copy.png' > #{user} copied the #{event_type} #{ev.join(',')} #{event.description2}"
        else
          error_message(event,'deleted')
        end
        break;
      when "commented":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/commented.png' >  #{user} added a comment for #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "task_commented":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/commented.png' >  #{user} added a comment for #{event.description} #{event_type}"
        else
          error_message(event,'deleted')
        end
        break;
      when "task_del_commented":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/comments_delete.png' >  #{user} deleted a comment for #{event_type} #{event.description}"
        else
          error_message(event,'deleted')
        end
        break;
      when "task_up_commented":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/commented_updated.png' >  #{user} updated a comment for #{event_type} #{event.description}"
        else
          error_message(event,'deleted')
        end
        break;
      when "task_rep_commented":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/commented_updated.png' >  #{user} replied a comment for #{event_type} #{event.description}"
        else
          error_message(event,'deleted')
        end
        break;
      when "del_comment":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/comments_delete.png' >  #{user} deleted a comment for #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "rep_comment":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/comment_reply.png' >  #{user} replied a comment for #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "up_comment":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/commented_updated.png' >  #{user} edited a comment for #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "restored":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/restored.png' > #{user} restored the #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "create_task":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/task_added.png' > #{user} added #{event.description2} #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "update_task":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/task_updated.png' > #{user} updated #{event.description2} #{event_type} #{ev.join(',')}"
        else
          error_message(event,'deleted')
        end
        break;
      when "mapped_secondary_file":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          return "<img src='/images/task_updated.png' > #{user} added / removed a secondary file #{event.description} for #{event_type} #{event.description2}"
        else
          error_message(event,'deleted')
        end
        break;
      when "create_secondary_file":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          #return "<img class='sprite s_page_white_go' src='/images/icon_spacer.gif' > #{user} added / removed #{event_type} #{event.description2}"
          return "<img src='/images/task_updated.png' > #{user} added / removed a secondary file #{event.description} for #{event_type} #{event.description2}"
        else
          error_message(event,'deleted')
        end
        break;
      when "collaborators":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          event.description2 = event.description2.include?("my_files") ? event.description2.gsub("my_files",'') : event.description2
          return "<img src='/images/shared.png' > #{user} added #{event.action_type.gsub('collaborators','collaborator(s)')} #{event.description} #{event.description2}"
        else
          error_message(event,'deleted')
        end
        break;
      when "de_collaborators":
          if !event.event_resources.empty?
          user = display_event_users(event)
          ev = event_link_formation(event)
          event.description2 = event.description2.include?("my_files") ? event.description2.gsub("my_files",'') : event.description2
          return "<img src='/images/shared.png' > #{user} removed #{event.action_type.gsub('de_collaborators','collaborator(s)')} #{event.description} #{event.description2}"
        else
          error_message(event,'deleted')
        end
        break;
      when "unshared":
          if !event.event_resources.empty?
          shared_user = User.find_by_id(event.shared_user_id)
          if event.user_id == current_user.id
            user = "You"
            sharer = shared_user.email
          else
            user = User.find_by_id(event.user_id).email
            sharer = shared_user.email
            if sharer == current_user.email
              sharer = "You"
            end
          end
          ev = event_link_formation(event)
          return "<img src='/images/unshared.png' /> #{user} unshared the #{event_type} #{ev.join(',')} with #{sharer}"
        else
          user = User.find_by_id(event.user_id).email
          sharer = shared_user.email
        end
        #this s from my profile
        #~ ev = event_link_formation(event)
        #~ return "<img class='sprite hotbutton-icon s_folder_user' src='/images/icon_spacer.gif' /> #{user} have unshared a #{event_type} #{ev.join(',')} with #{sharer}"
        #~ else
        #~ error_message(event,'deleted')
        #~ end
        break;
      else
        return ""
      end
      #elsif event.action_type.downcase.strip == "upload"
      #end
    end
  end

  def error_message(event,action,share_details="")
    if action == 'deleted'
      return "<img class='sprite s_cancel' src='/images/icon_spacer.gif' > You #{action} #{event.description} #{event_type} #{share_details}"
    elsif  action == 'moved'
      return "<img class='sprite s_page_white_go' src='/images/icon_spacer.gif' > You #{action} one file/folder #{share_details}"
    else
      return "<img class='sprite s_cancel' src='/images/icon_spacer.gif' > You #{action} one file/folder #{share_details}"
    end
  end

  def find_doc_owner(doc_id)
    return Document.find(doc_id).user.email
	end

  #Added newly - To find email of the document's owner by passing object
  def find_doc_owner_by_obj(doc)
    return doc.user.email
	end

  def is_doc_shared(doc_id)
    documents = SharedDocument.find(:all,:conditions=>["document_id = ?",doc_id])
    return documents
  end

  def is_filename_shared(fn)
    file_names = ShareDocumentName.find(:all,:conditions=>["document_name_id = ?",fn])
    return file_names
  end

  def is_filename_shared_to_the_user(fn,user_id)
    file_names = ShareDocumentName.find(:all,:conditions=>["document_name_id = ? and user_id = ?",fn,user_id])
    return file_names
  end

	def is_folder_shared(folder_id)
		folders = SharedFolder.find(:all,:conditions=>["folder_id = ?",folder_id])
		return folders
	end

	def find_folder_owner(folder_id)
		return Folder.find(folder_id).user.email
	end

  #Added newly - To find email of the folder's owner by passing object
	def find_folder_owner_by_obj(folder)
		return folder.user.email
	end

	def missing_files_count(folder_id)
		a = DocumentName.count(:all,:conditions=>["folder_id = ? and is_master = ? and property_id is not NULL and due_date < '#{Date.today}' and document_id is NULL",folder_id,0])
		b = Document.count(:all,:conditions=>["is_deleted = ? and folder_id = ? and is_master = ? and property_id is not NULL and due_date < '#{Date.today}'",false,folder_id,0])
		return a+b
	end

	def present_files_count(folder_id)
		a = DocumentName.count(:all,:conditions=>["folder_id = ? and is_master = ? and property_id is not NULL",folder_id,0])
		b = Document.count(:all,:conditions=>["is_deleted = ? and folder_id = ? and is_master = ? and property_id is not NULL",false,folder_id,0])
		return a+b
	end

	def find_document_members(doc)
    if doc.class.name == "SharedDocument"
      doc = doc.document
    end
		members  = SharedDocument.find(:all,:conditions=>["document_id = ? and  user_id !=?",doc.id,current_user.id]).collect{|sf| sf.user}
		#members  = SharedDocument.find(:all,:conditions=>["document_id = ? and  user_id !=?",doc.id,current_user.id],:joins=>"LEFT JOIN users ON shared_documents.user_id=users.id",:select=>"users.*") #Commented for now
    owner= User.find_by_email(find_doc_owner(doc))
    #fol_owner= User.find_by_email(find_folder_owner(doc.folder))
    members << owner if owner && owner != current_user
    #members << fol_owner if fol_owner && fol_owner != current_user

    if current_user.has_role?("Shared User") && session[:role] == 'Shared User'
      user = doc.user
      members << user if user != current_user
    end
    #~ if doc && doc.task &&  doc.task.task_collaborators
    #~ doc.task.task_collaborators.each do |task_collab|
    #~ members.delete_if{|member| member.email  == task_collab.user.email }
    #~ end
		#~ end
    #members = members.reject{|m| m.id == current_user.id}
    members = members.uniq
    return members
  end

  def find_document_name_member_list(fn)
		members  = ShareDocumentName.find(:all,:conditions=>["document_name_id = ? and  user_id !=?",fn,current_user.id]).collect{|sf| sf.user}
    #members  = ShareDocumentName.find(:all,:conditions=>["document_name_id = ? and  user_id !=?",fn,current_user.id],:joins=>"LEFT JOIN users ON share_document_names.user_id=users.id",:select=>"users.*") #Commented for now
    if current_user.has_role?("Shared User") && session[:role] == 'Shared User'
      user = fn.user
      members << user if user != current_user
    end
		return members
  end

  def find_shared_docs_count_in_portfolio(portfolio)
    shared_folders = SharedFolder.find(:all, :conditions => ["user_id = ? and is_property_folder =?",current_user.id,true])
    @document_count = 0
    @shared_docs  = []
    shared_folders = shared_folders.compact.collect{|s| s if s.folder.real_estate_property.portfolio_id == portfolio.id }
    shared_folders.compact.each do |sf|
      sf.folder.real_estate_property.documents.collect{|d|  @shared_docs << d.shared_documents if  d.real_estate_property.portfolio_id == portfolio.id && !d.shared_documents.empty?}
      @document_count =  @document_count  + @shared_docs.compact.count if !@shared_docs.empty?
    end
    return @document_count
  end


  #find collaboratorin hub realted queries
  def find_portfolio_fol_doc_task(port)
    @portfolio_document_count = 0
    @portfolio_doc = []
    @portfolio_prop = (port.user_id == current_user.id) ? port.real_estate_properties : SharedFolder.find(:all, :conditions => ["real_estate_property_id in (?) and is_property_folder = ? and user_id = ?",port.real_estate_properties.collect{|i| i.id},true,current_user.id])
    #@portfolio_doc = port.real_estate_properties[0].documents if !(port.real_estate_properties.nil? || port.real_estate_properties.blank?)

    #@portfolio_doc = (port.user_id == current_user.id) ? Portfolio.find_by_sql("select count('name') as c from documents d inner join real_estate_properties p on p.id = d.real_estate_property_id and p.portfolio_id=#{port.id} and d.is_deleted = #{false}")  : find_shared_docs_count_in_portfolio(port) if !(port.real_estate_properties.nil? || port.real_estate_properties.blank?)
    
    property_folders = Folder.find_all_by_portfolio_id_and_parent_id_and_is_master(port.id,0,0)
    property_folders.each do |property_folder| 
       @portfolio_document_count = @portfolio_document_count + shared_no_of_files_of_asset_folder(property_folder.id,true)
    end
    

    #@portfolio_task = port.real_estate_properties[0].tasks if !(port.real_estate_properties.nil? || port.real_estate_properties.blank?)

    task_wout_doc = Portfolio.find_by_sql("SELECT tasks.task_name,tasks.due_by as d FROM tasks INNER JOIN real_estate_properties ON real_estate_properties.id = tasks.real_estate_property_id inner join folders on folders.id = tasks.folder_id WHERE tasks.temp_task = false AND (tasks.is_completed IS NULL OR tasks.is_completed = false) AND real_estate_properties.portfolio_id = #{port.id} and folders.is_deleted = false")
    task_with_doc =  Portfolio.find_by_sql("SELECT tasks.task_name,tasks.due_by as d FROM tasks INNER JOIN real_estate_properties ON real_estate_properties.id = tasks.real_estate_property_id inner join documents on documents.id = tasks.document_id WHERE tasks.temp_task = false AND (tasks.is_completed IS NULL OR tasks.is_completed = false) AND real_estate_properties.portfolio_id = #{port.id} and documents.is_deleted = false")
    @portfolio_task = task_wout_doc + task_with_doc
    @dues = []
    @portfolio_task.each {|i| @dues << i["d"]}


    @portfolio_task_collaborator = port.real_estate_properties[0].tasks[0].collaborators if  !(port.real_estate_properties.nil? || port.real_estate_properties.blank?) && !(port.real_estate_properties[0].tasks.nil? || port.real_estate_properties[0].tasks.blank?)
    #@portfolio_task_comments = port.real_estate_properties[0].tasks[0].comments if !(port.real_estate_properties.nil? || port.real_estate_properties[0].tasks.nil? || port.real_estate_properties[0].tasks[0].comments.nil?)
    @portfolio_task_comments = port.real_estate_properties[0].tasks[0].comments if !(port.real_estate_properties.nil? || port.real_estate_properties.blank?) && !(port.real_estate_properties[0].tasks.nil? || port.real_estate_properties[0].tasks.blank?) && !(port.real_estate_properties[0].tasks[0].comments.nil? || port.real_estate_properties[0].tasks[0].comments.blank?)
    @portfolio_task_collaborator_mem = port.real_estate_properties[0].tasks[0].collaborators.collect{|i| i.email} if  !(port.real_estate_properties.nil? || port.real_estate_properties.blank?) && !(port.real_estate_properties[0].tasks.nil? || port.real_estate_properties[0].tasks.blank?) && !(port.real_estate_properties[0].tasks[0].collaborators.nil? || port.real_estate_properties[0].tasks[0].collaborators.blank?)
    portfolio_folder = Folder.find_by_parent_id_and_portfolio_id(-1,port.id)
    @portfolio_comment = portfolio_folder.comments if !(portfolio_folder.nil? || portfolio_folder.blank?)
    #@portfolio_task_collaborator_ids = port.real_estate_properties[0].tasks[0].collaborators.collect{|sf| sf.id} if  !(port.real_estate_properties.nil? || port.real_estate_properties.blank?) && !(port.real_estate_properties[0].tasks.nil? || port.real_estate_properties[0].tasks.blank?) && !(port.real_estate_properties[0].tasks[0].collaborators.nil? || port.real_estate_properties[0].tasks[0].collaborators.blank?)
    #@portfolio_task_collaborator_member = User.find(:all, :conditions => ["id in (?)",@portfolio_task_collaborator_ids])
    return @portfolio_prop,@portfolio_doc,@portfolio_task,@portfolio_task_collaborator,@portfolio_task_comments#@portfolio_task_collaborator_member
  end
  
  def find_portfolio_prop(port)
    @portfolio_prop = (port.user_id == current_user.id) ? port.real_estate_properties : SharedFolder.find(:all, :conditions => ["real_estate_property_id in (?) and is_property_folder = ? and user_id = ?",port.real_estate_properties.collect{|i| i.id},true,current_user.id])
    return @portfolio_prop
  end

	def find_folder_member(f)
    members  = SharedFolder.find(:all,:conditions=>["folder_id = ? and user_id !=?",f.id,current_user.id]).collect{|sf| sf.user}
    owner= User.find_by_email(find_folder_owner(f))
    #members  = SharedFolder.find(:all,:conditions=>["folder_id = ? and  user_id !=?",f.id,current_user.id],:joins => "LEFT JOIN users ON shared_folders.user_id=users.id",:select=>"users.*") # Commented for now
    members << owner if owner && owner != current_user
    if current_user.has_role?("Shared User") && session[:role] == 'Shared User'
      user = f.user
      members <<  user if user != current_user
    end
    members = members.uniq
		return members
	end

  def find_fol_tasks(fol, dues = [])
    folder = Folder.find_by_id(fol.id)
    if folder.parent_id == -1
      fols = Folder.find_all_by_portfolio_id_and_is_master_and_parent_id(fol.portfolio_id,false,false)
    else
      fols = Folder.find_all_by_parent_id(fol.id)
    end
    fol.documents.each { |i| dues << i.task.due_by if i.task and i.task.is_completed != true and i.task.document.is_deleted == false}
    fol.documents.each { |i| dues << i.variance_task.due_by if i.variance_task and i.variance_task.is_completed != true and i.variance_task.document.is_deleted == false}
    fol.tasks.each { |i| dues << i.due_by if i and i.is_completed != true and i.folder.is_deleted == false and i.temp_task == false}
    fols.each do |i|
      find_fol_tasks(i, dues)
    end
    dues
  end


  def find_document_tasks(doc)
    dues =[]
    #    dues << doc.task.due_by if doc.task and doc.task.is_completed != true and doc.is_deleted == false
    dues << doc.task.due_by if doc.task and doc.is_deleted == false
    return dues
  end

  def find_document_tasks_complete_status(doc)
    return doc.task.is_completed? if doc.task
  end



	def breadcrump_display_shared_user(folder)
		arr =[]
		i = 0
		f = folder.parent_id != 0 ?  Folder.find(folder.parent_id) : ""  if !folder.nil?
		while !folder.nil?
      if  !is_folder_shared_to_current_user(folder.id).nil?
  			if current_user.has_role?("Shared User") && session[:role] == 'Shared User' && f == 0
          tmp_name = "<div class='setupiconrow'><img border='0' width='16' height='16' src='/images/package.png'></div><div class='setupheadactvelabel'><a href='/shared_users?data_hub=asset_data_and_documents&pid=#{folder.portfolio_id}'>#{folder.name}</a></div>"
        else
          tmp_name = "<div class='setupiconrow'><img border='0' width='16' height='16' src='/images/package.png'></div><div class='setupheadactvelabel'><a href='' onclick=\"new Ajax.Request('/assets/show_asset_files?folder_id=#{folder.id}&pid=#{folder.portfolio_id}');return false;\">#{folder.name}</a></div>"
        end
      end
			name = (i == 0) ? "<div class='setupiconrow'><img width='16' height='16' src='/images/folder.png'></div><div class='setupheadlabel'>#{folder.name}</div>" :  "#{tmp_name}"
			arr << name if !is_folder_shared_to_current_user(folder.id).nil?
			folder =  Folder.find_by_id(folder.parent_id)
      i += 1
		end
		return arr.reverse.join("<div class='setupiconrow3'><img width='10' height='9' src='/images/eventsicon2.png'></div>")
	end

	def breadcrump_display_event_shared_user(folder)
		arr =[]
		i = 0
		f = folder.parent_id != 0 ?  Folder.find(folder.parent_id) : ""  if !folder.nil?
		while !folder.nil?
      if  !is_folder_shared_to_current_user(folder.id).nil?
  			if current_user.has_role?("Shared User") && session[:role] == 'Shared User' && f == 0
          tmp_name = "<div class='setupiconrow'><img border='0' width='16' height='16' src='/images/package.png'></div><div class='setupheadactvelabel'><a href='/shared_users?data_hub=asset_data_and_documents&pid=#{folder.portfolio_id}'>#{folder.name}</a></div>"
        else
          tmp_name = "<div class='setupiconrow'><img border='0' width='16' height='16' src='/images/package.png'></div><div class='setupheadactvelabel'><a href='' onclick=\"load_writter();show_events('#{folder.id}');load_completer();return false;\">#{folder.name}</a></div>"
        end
      end
			name = (i == 0) ? "<div class='setupiconrow'><img width='16' height='16' src='/images/folder.png'></div><div class='setupheadlabel'>#{folder.name}</div>" :  "#{tmp_name}"
			arr << name if !is_folder_shared_to_current_user(folder.id).nil?
			folder =  Folder.find_by_id(folder.parent_id)
      i += 1
		end
		return arr.reverse.join("<div class='setupiconrow3'><img width='10' height='9' src='/images/eventsicon2.png'></div>")
	end

	def is_folder_shared_to_current_user(folder_id)
		folder = SharedFolder.find_by_folder_id(folder_id,:conditions=>["user_id = #{current_user.id}"])
    return folder
	end

def is_doc_shared_to_current_user(doc_id)
		doc = SharedDocument.find_by_document_id(doc_id,:conditions=>["user_id = #{current_user.id}"])
    return doc
end



  def find_past_shared_folders_docs
		s = SharedFolder.find(:all,:conditions=>["sharer_id = ? ",current_user.id]).collect{|sf| sf.folder_id}
		@folders = Folder.find(:all,:conditions=>["id in (?) and parent_id not in (?) and is_deleted = false",s,s])
    shared_docs_ids = @folders.empty? ? SharedDocument.find(:all,:conditions=>["sharer_id = ? ",current_user.id]).collect{|sd| sd.document_id}   : SharedDocument.find(:all,:conditions=>["sharer_id = ? and folder_id not in (?)",current_user.id,s]).collect{|sd| sd.document_id}
    documents = Document.find(:all,:conditions=>["id in (?) and is_deleted = false",shared_docs_ids])
		@documents = documents.reject{|d|  d.document_name !=nil }
		collection = @folders.empty? && @documents.empty? ? "empty" : "has_collection"
		return collection
  end

	def find_portfolio
		shared_folder = SharedFolder.find(:first,:conditions=>["user_id=?",current_user.id])
    shared_document = SharedDocument.find(:first,:conditions=>["user_id=?",current_user.id])
    #shared_document_name = ShareDocumentName.find(:first,:conditions=>["user_id=?",current_user.id])
    tasks= find_tasks_without_shared_parent_folder(current_user.id)
    task = tasks.first if tasks && !tasks.empty?
    pid = shared_folder.nil? ? (shared_document.nil? ? task.folder.portfolio_id : shared_document.folder.portfolio_id) : shared_folder.folder.portfolio_id
		return pid
	end


	def find_current_user(t)
    if t !=nil
      display = "yes"
      if current_user.has_role?("Shared User") && session[:role] == 'Shared User'
        display = (t.filename != "Rent_Roll_Template.xls" && t.filename != 'Cash_Flow_Template.xls') ? "yes" : "no"
      end
      return display
    end
	end
  def find_folder_by_folder_id(id)
    @sharer=SharedFolder.find(:all,:conditions => ["folder_id = ? and sharer_id = ?",id, current_user.id])
    folder_find_mail_shared(@sharer,@sharer)
    @mail=[]
    #@sharer.each do |sharer|
    #  id=@sharer.sharer_id
    #  @sharer=SharedFolder.find_by_sharer_id(:all,:conditions => ["folder_id = ? and sharer_id != ? and sharer_id = ?",id, @owner, current_user.id])
    # @mail<<User.find(id).email
    #end
    return @@mails
  end

  def folder_find_mail_shared(sharers,current)
    if !current.empty?
      sharers.each do |sharer|
        id=sharer.user_id
        @@mails<<User.find(id).email
      end
      folder_find_sub_sharers(sharers)
    end
  end

  def  folder_find_sub_sharers(sharers)
    sub=[]
    @sub1=[]
    sharers.each do |sharer|
      id=sharer.user_id
      fid=sharer.folder_id
      sub = SharedFolder.find(:all,:conditions=>["sharer_id = ? and folder_id = ? and sharer_id != user_id",id,fid])
      @sub1=@sub1+sub
    end
    folder_find_mail_shared(@sub1,sub)
  end

  def find_doc_by_id(id)
    @sharer=SharedDocument.find(:all,:conditions => ["document_id = ? and sharer_id = ?",id, current_user.id])
    doc_find_mail(@sharer)
    return @@mails
  end

  def doc_find_mail(sharers)
    if !sharers.empty?
      sharers.each do |sharer|
        id=sharer.user_id
        @@mails<<User.find(id).email
      end
      doc_find_sub_sharers(sharers)
    end
  end

  def  doc_find_sub_sharers(sharers)
    sub=[]
    sharers.each do |sharer|
      id=sharer.user_id
      doc_id=sharer.document_id
      sub = SharedDocument.find(:all,:conditions => ["document_id = ? and sharer_id = ? and sharer_id != user_id",doc_id, id])
      doc_find_mail(sub)
    end
  end

  def find_doc_name_by_id(id)
    @sharer=ShareDocumentName.find(:all,:conditions => ["document_name_id = ? and sharer_id = ?",id, current_user.id])
    doc_name_find_mail(@sharer)
    return @@mails
  end

  def doc_name_find_mail(sharers)
    if !sharers.empty?
      sharers.each do |sharer|
        id=sharer.user_id
        @@mails<<User.find(id).email
      end
      doc_name_find_sub_sharers(sharers)
    end
  end

  def  doc_name_find_sub_sharers(sharers)
    sub=[]
    sharers.each do |sharer|
      id=sharer.user_id
      doc_id=sharer.document_name_id
      sub = ShareDocumentName.find(:all,:conditions => ["document_name_id = ? and sharer_id = ? and sharer_id != user_id",doc_id, id])
      doc_name_find_mail(sub)
    end
  end

  def find_doc_sharer(t)
    sd =  SharedDocument.find_by_id(t.id)
    if sd !=nil
      sharer = sd.sharer_id
      return User.find(sharer).email
    else
      return ""
    end
  end

  def find_folder_sharer(f)
    sharer =  SharedFolder.find(f.id).sharer_id
    return User.find(sharer).email
  end

  def  find_fn_owner(fn)
    d = DocumentName.find(:first,:conditions=>['id = ?',fn])
    return d.user.email
	end

  #Added newly - To find email of the Folder's owner by passing object
  def find_fn_owner_by_obj(fn)
    return fn.user.email
  end

  def find_fn_sharer(fn)
    sd = ShareDocumentName.find_by_document_name_id(fn,:conditions=>["user_id=?",current_user.id])
    if sd!=nil
      email = User.find(sd.sharer_id).email
    else
      email=""
    end
    return email
  end

  def find_first_late(properties,chk)
    prp =  properties.detect do  |itr|
      if chk
        ( itr.late_payments_amount_due.nil? || itr.late_payments_amount_due == 0 )
      else
        itr.late_payments_amount_due != 0
      end
    end
    return prp.id
  end

  def prop_occupancy(prop)
    #(!prop.rent_rolls.nil? && !prop.rent_rolls.empty? && !prop.rent_rolls.last.nil?) ? (prop.rent_rolls.last.total_occupied.nil? || prop.rent_rolls.last.total_available.nil?) ? 0 : (((prop.rent_rolls.last.total_occupied) / (prop.rent_rolls.last.total_occupied + prop.rent_rolls.last.total_available)) * 100).round(2) : 0
    prop.occupancy.nil? ? 0 : prop.occupancy.round(2)
  end


	def breadcrump_display_acquisitions(folder,id)
		arr =[]
		i = 0
		while !folder.nil?
			tmp_name = "<div class='setupiconrow'><img border='0' width='16' height='16' src='/images/package.png'></div><div class='setupheadactvelabel'><a href='#' onclick=\"new Ajax.Request('/acquisitions/show_asset_files?id=#{folder.property_id}&folder_id=#{folder.id}&data_hub=true&pid=#{folder.portfolio_id}');return false;\">#{folder.name}</a></div>"
			name = (i == 0) ? "<div class='setupiconrow'><img width='16' height='16' src='/images/folder.png'></div><div class='setupheadlabel'>#{folder.name}</div>" :  "#{tmp_name}"
			arr << name
			folder =  Folder.find_by_id(folder.parent_id)
			i += 1
		end
		return arr.reverse.join("<div class='setupiconrow3'><img width='10' height='9' src='/images/eventsicon2.png'></div>")
	end

  def breadcrump_display_property_acquisitions(folder,id)
		arr =[]
		i = 0
		while !folder.nil?
			tmp_name = "<div class='setupiconrow'><img border='0' width='16' height='16' src='/images/package.png'></div><div class='setupheadactvelabel'><a href='#' onclick=\"new Ajax.Request('/property_acquisitions/show_asset_files?id=#{folder.property_id}&folder_id=#{folder.id}&data_hub=true&pid=#{folder.portfolio_id}');return false;\">#{folder.name}</a></div>"
			name = (i == 0) ? "<div class='setupiconrow'><img width='16' height='16' src='/images/folder.png'></div><div class='setupheadlabel'>#{folder.name}</div>" :  "#{tmp_name}"
			arr << name
			folder =  Folder.find_by_id(folder.parent_id)
			i += 1
		end
		return arr.reverse.join("<div class='setupiconrow3'><img width='10' height='9' src='/images/eventsicon2.png'></div>")
	end

  def fetch_missing_actuals(note_id)
    p = Property.find(note_id)
    f = Folder.find_by_property_id_and_portfolio_id(p.id,p.portfolio_id)
    fetch_folder_of_cashflow(f.id,true)
    @folder_s = @folder_s.blank? ? f.id : @folder_s
    return @folder_s
  end


  def fetch_folder_of_cashflow(folder_id,loop_starts)
    folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id])
    @folder_s = '' if (@folder_s.nil? || @folder_s.blank? || loop_starts)

    document_names = ''
    required_fid = ''

    folders.each do |f|
      document_names = f.documents.all(:conditions=>['is_deleted = ?',false]).collect{|x| x.filename}
      if !document_names.empty?  && document_names.include?('Cash_Flow_Template.xls')
        @folder_s = f.parent_id
      else
        fetch_folder_of_cashflow(f.id,false)
      end
    end
    return @folder_s
  end

  def fetch_folder_of_excels(folder_id,loop_starts)
    #folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id]) - Selected only id,name and parent_id fields instead of all as other fields are not used
    folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id],:select=>'id,name,parent_id')
    @folder_s = '' if (@folder_s.nil? || @folder_s.blank? || loop_starts)
    folders.each do |f|
      if !f.name.empty?  && f.name == '2010'
        @folder_s = f.parent_id
      else
        fetch_folder_of_excels(f.id,false)
      end
    end
    return @folder_s
  end


  def fetch_missing_rentroll_folder(note_id,ptype_id)
    if ptype_id == 1
      p = Property.find(note_id)
      f = Folder.find_by_property_id_and_portfolio_id(p.id,p.portfolio_id)
    else
      p = RealEstateProperty.find(note_id)
      f = Folder.find_by_real_estate_property_id_and_portfolio_id(p.id,p.portfolio_id)
    end
    fetch_folder_of_rentroll(f.id,true)
    @folder_s = @folder_s.blank? ? f.id : @folder_s
    return @folder_s
  end

  def fetch_folder_of_rentroll(folder_id,loop_starts)
    folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id])
    @folder_s = '' if (@folder_s.nil? || @folder_s.blank? || loop_starts)

    document_names = ''
    required_fid = ''

    folders.each do |f|
      document_names = f.documents.all(:conditions=>['is_deleted = ?',false]).collect{|x| x.filename}
      if !document_names.empty?  && document_names.include?('Rent_Roll_Template.xls')
        @folder_s = f.parent_id
      else
        fetch_folder_of_rentroll(f.id,false)
      end
    end
    return @folder_s
  end


  def contains_deleted_files(folder)
    folders,documents = find_manage_real_estate_shared_folders('true')
    final_folder_collection = []
    final_doc_collection = []
    if folder != nil
      folders1 = Folder.find(:all,:conditions=>["parent_id = ? and is_deleted = ?",folder.id,true])
      documents1 = Document.find(:all,:conditions=>["folder_id = ? and is_deleted = ?",folder.id,true])
      folders1.each do |f|
        final_folder_collection << f if f.user_id == current_user.id || is_folder_shared_to_current_user(f.id)
        end  
      documents1.each do |d|
        final_doc_collection <<  d if d.user_id == current_user.id || is_doc_shared_to_current_user(d.id)
      end  
      folders = folders + final_folder_collection
      documents = documents + final_doc_collection
      display =  (folders.empty? && documents.empty?) ? false : true
      return display
    end
  end

  def note_denied(note_id)
    denied_note = PropertyStateLog.find(:last, :conditions=>["user_id = ? && property_id = ? && state_id = ?", current_user, note_id, 6])  #State 6 for note denied
    return denied_note.nil? ? false : denied_note.id
  end

  def resend_request(note_id)
    all_states = PropertyStateLog.find(:all, :conditions=>["user_id = ? && property_id = ?", current_user, note_id]).collect{|x|x.state_id}  #State 4 for requested
    if (!all_states.include?(5) && !all_states.include?(6))
      already_requested = PropertyStateLog.find(:last, :conditions=>["user_id = ? && property_id = ? && state_id = ? && (state_id != ? || state_id != ?)", current_user, note_id, 4, 5, 6])  #State 4 for requested
      return already_requested.nil? ? false : already_requested.id
    else
      return false
    end
  end

  def new_request(note_id)
    all_states = PropertyStateLog.find(:all, :conditions=>["user_id = ? && property_id = ?", current_user, note_id]).collect{|x|x.state_id}  #State 3 for saved, 4 for requested, 5 for confirmed & 6 for denied
    if (!all_states.include?(4) && !all_states.include?(5) && !all_states.include?(6))
      saved_note = PropertyStateLog.find(:last, :conditions=>["user_id = ? && property_id = ? && state_id = ? && state_id != ?", current_user, note_id, 3, 4])  #State 3 for saved note, State 4 for requested
      return saved_note.nil? ? false : saved_note.id
    else
      return false
    end
  end

  def real_estate_denied(note_id)
    denied_note = RealEstatePropertyStateLog.find(:last, :conditions=>["user_id = ? && real_estate_property_id = ? && state_id = ?", current_user, note_id, 6])  #State 6 for note denied
    return denied_note.nil? ? false : denied_note.id
  end

  def resend_request_real_estate(note_id)
    all_states = RealEstatePropertyStateLog.find(:all, :conditions=>["user_id = ? && real_estate_property_id = ?", current_user, note_id]).collect{|x|x.state_id}  #State 4 for requested
    if (!all_states.include?(5) && !all_states.include?(6))
      already_requested = RealEstatePropertyStateLog.find(:last, :conditions=>["user_id = ? && real_estate_property_id = ? && state_id = ? && (state_id != ? || state_id != ?)", current_user, note_id, 4, 5, 6])  #State 4 for requested
      return already_requested.nil? ? false : already_requested.id
    else
      return false
    end
  end

  def new_request_real_estate(note_id)
    all_states = RealEstatePropertyStateLog.find(:all, :conditions=>["user_id = ? && real_estate_property_id = ?", current_user, note_id]).collect{|x|x.state_id}  #State 3 for saved, 4 for requested, 5 for confirmed & 6 for denied
    if (!all_states.include?(4) && !all_states.include?(5) && !all_states.include?(6))
      saved_note = RealEstatePropertyStateLog.find(:last, :conditions=>["user_id = ? && real_estate_property_id = ? && state_id = ? && state_id != ?", current_user, note_id, 3, 4])  #State 3 for saved note, State 4 for requested
      return saved_note.nil? ? false : saved_note.id
    else
      return false
    end
  end

  def is_doc_name_document_shared(t)
    sd = SharedDocument.find_by_document_id(t.document.id,:conditions=>["user_id = ?",current_user.id])
    if sd.nil?
      return false
    else
      return true
    end
  end

  def find_doc_name_doc_sharer(d)
    sharer = SharedDocument.find_by_document_id(d.id,:conditions=>["user_id = ?",current_user.id]).sharer_id
    return User.find(sharer).email
  end

  #Calculating annual NOI to be used to calculate sale price when the note is pushed to sale
  def annualized_noi(note)
    #Yearly calculations
    #~ actuals = Actual.find(:all, :conditions=>["resource_id = ? && resource_type = ? && user_id = ? && DATE_FORMAT(start_date, '%Y-%m-%d') >= ? && DATE_FORMAT(end_date, '%Y-%m-%d') <= ? and (DATE_FORMAT(end_date, '%Y-%m-%d') - DATE_FORMAT(start_date, '%Y-%m-%d') > 150)",note.id, 'Property', current_user.id, Date.today.change(:day=>1,:year=>Date.today.year-1,:month=>1), Date.today.change(:day=>31,:year=>Date.today.year)], :order=>"start_date DESC")
    #~ if actuals.empty?
    #~ #Quarterly calculations
    #~ start_qua  = Date.today.beginning_of_quarter
    #~ last_qua = start_qua -1
    #~ 4.times do
    #~ start_qua  = start_qua -1
    #~ start_qua  = start_qua.beginning_of_quarter
    #~ end
    #~ actuals = Actual.find(:all, :conditions=>["resource_id = ? && resource_type = ? && user_id = ? && DATE_FORMAT(start_date, '%Y-%m-%d') >= '#{start_qua}' && DATE_FORMAT(end_date, '%Y-%m-%d') <= '#{last_qua}' and (DATE_FORMAT(end_date, '%Y-%m-%d') - DATE_FORMAT(start_date, '%Y-%m-%d') > 35)",note.id, 'Property', current_user.id], :order=>"start_date DESC")
    #~ end
    #~ if actuals.empty?
    #Monthly calculations
    actuals = Actual.find(:all, :conditions=>["resource_id = ? && resource_type = ? && user_id = ? && (DATE_FORMAT(month_and_year, '%Y-%m-%d') >= ? || DATE_FORMAT(month_and_year, '%Y-%m-%d') <= ?)",note.id, "#{note.class}",current_user.id, Date.today.change(:day=>1).advance(:months=>-13), Date.today.change(:day=>1).advance(:months=>-1)], :order=>"month_and_year DESC")
    #end
    noi =  (actuals.nil? || actuals.empty?) ? nil : (actuals.sum(&:net_operating_income))
  end

  #To use to display truncated characters
  def display_truncated_chars(name, len, omission_required)
    if name.nil? || name.blank?
      return ''
    else
      return truncate(name, :omission => "#{omission_required ? '...' : ''}", :length => len)
    end
  end

  #To use to display user friendly dates
  def display_rent_roll_date(date)
    (date.nil? || date.blank?) ? '-' : date.strftime('%b %d, %Y')
  end

  #To use to display currency
  #~ def display_currency(value, precision_count=2)
  #~ (value.nil? || value.blank?) ? '0' : "$" + number_with_delimiter(number_with_precision(value, :precision=>precision_count))
  #~ end

  def display_currency(value, precision_count=2)
    #(value.nil? || value.blank? || value = 0) ? "<font style='color:#CC6633'>$0.00</font>" : "$" + number_with_delimiter(number_with_precision(value, :precision=>precision_count))
    if value.nil? || value.blank? || value == 0
      "$0.00"
    elsif value < 0
      value = value.abs
      "<font style='color:#CC6633'>-$#{number_with_delimiter(number_with_precision(value, :precision=>precision_count))}</font>"
    else
      "$#{number_with_delimiter(number_with_precision(value, :precision=>precision_count))}"
    end
  end

  def parent_folder_name(folder)
    (!folder.nil? && !folder.parent_id.nil?) ? Folder.find_by_id(folder.parent_id) : nil
  end

  def cash_flow_document(folder)
    (!folder.nil? && !folder.documents.empty?) ? folder.documents.first(:conditions=>["filename = ? && is_deleted = ?", 'Cash_Flow_Template.xls', false]) : nil
  end

	def cal_budget_percentage(a,b)
    c = b - a
    res = ((c/b)*100).to_i rescue ZeroDivisionError
    return  (res <100) ? res : 100
	end

  def display_collaborators(members,obj,obj_id,j)
    z_ind = 24900-(j*200)
    len = members.uniq.length
    if len == 1
      if members.first !=nil
        owner_email = find_folder_doc_doc_name_owner(obj_id,obj)
        sharer_email = find_folder_doc_doc_name_sharer(obj_id,obj)
        r =  sharer_email == current_user.email ? "#{members.first.email}" : "<font style='color:#006600;'>#{sharer_email}</font>" if sharer_email != nil
        r =  owner_email == current_user.email ? "#{members.first.email}" : "<font style='color:#006600;'>#{members.first.email}</font>" if sharer_email == nil
      end
      return r
    elsif len == 2
      if members.first !=nil && members[1] !=nil
        owner_email = find_folder_doc_doc_name_owner(obj_id,obj)
        sharer_email = find_folder_doc_doc_name_sharer(obj_id,obj)
        second_mail =  sharer_email == members.first.email ? members[1].email : members.first.email
        r =  sharer_email == current_user.email ? "#{members.first.email} and #{members[1].email}" :   "<font style='color:#006600;'>#{sharer_email}</font> and #{second_mail}" if sharer_email != nil
        r =  owner_email == current_user.email ? "#{members.first.email} and #{members[1].email}" :   "<font style='color:#006600;'>#{members.first.email}</font> and #{members[1].email}" if sharer_email == nil
      end
      return r
    elsif len > 2
      others = members.collect{|x|x.email if x !=nil}
      if members.first !=nil
        owner_email = find_folder_doc_doc_name_owner(obj_id,obj)
        sharer_email = find_folder_doc_doc_name_sharer(obj_id,obj)
        if sharer_email != nil
          others =  members.collect{|x|x.email} - (sharer_email).to_a
          others = others.uniq.join('<br>')
        end
        if owner_email == current_user.email
          others =  members.collect{|x|x.email} - (members.first.email).to_a if members.first.email !=nil
          others = others.uniq.join('<br>')
        end

        r =  sharer_email == current_user.email ?   "#{members.first.email} and <span class='tooltip' id='tooltip_#{obj}_#{obj_id}' style='display: none;z-index:#{z_ind};'>#{others}</span><a href='#' onmouseout=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','none');\" onmouseover=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','block');\">#{len-1} others</a>" : "<font style='color:#006600;'>#{sharer_email}</font> and <span class='tooltip' id='tooltip_#{obj}_#{obj_id}' style='display: none;z-index:#{z_ind};'>#{others}</span><a href='#' onmouseout=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','none');\" onmouseover=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','block');\">#{len-1} others</a>" if sharer_email != nil
        r =  owner_email == current_user.email ?   "#{members.first.email} and <span class='tooltip' id='tooltip_#{obj}_#{obj_id}' style='display: none;z-index:#{z_ind};'>#{others}</span><a href='#' onmouseout=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','none');\" onmouseover=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','block');\">#{len-1} others</a>" : "<font style='color:#006600;'>#{members.first.email}</font> and <span class='tooltip' id='tooltip_#{obj}_#{obj_id}' style='display: none;z-index:#{z_ind};'>#{others}</span><a href='#' onmouseout=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','none');\" onmouseover=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','block');\">#{len-1} others</a>" if sharer_email == nil
      end
      return r
    else
    end
  end

  def find_folder_doc_doc_name_owner(obj_id,obj)
    if obj == "folder"
      owner =  find_folder_owner(obj_id)
    elsif obj == "doc"
      owner =  find_doc_owner(obj_id)
    elsif obj == "doc_name"
      owner=  find_fn_owner(obj_id)
    end
    return owner
  end

  def find_folder_doc_doc_name_sharer(obj_id,obj)
    if obj == "folder"
      sf = SharedFolder.find_by_folder_id(obj_id,:conditions=>["user_id = ?",current_user.id])
      sharer = User.find(sf.sharer_id) if sf != nil
    elsif obj == "doc"
      sd = SharedDocument.find_by_document_id(obj_id,:conditions=>["user_id = ?",current_user.id])
      sharer = User.find(sd.sharer_id) if sd != nil
    elsif obj == "doc_name"
      sdn = ShareDocumentName.find_by_document_name_id(obj_id,:conditions=>["user_id = ?", current_user.id])
      sharer = User.find(sdn.sharer_id) if sdn != nil
    end
    return sharer.email if sharer !=nil
  end

  def breadcrump_display_upload_file_asset_manager(f_id)
    folder = Folder.find(f_id)
		arr =[]
		i = 0
		while !folder.nil?
			tmp_name = "<font color='#1F75CC'>#{folder.name}</font>"
			name = (i == 0) ? "<font color='#222222'><img alt='' class='sprite s_folder link-img' src='/images/icon_spacer.gif'> #{folder.name}</font>" :  "#{tmp_name}"
			arr << name
			folder =  Folder.find_by_id(folder.parent_id)
			i += 1
		end
		return arr.reverse.join(" <img src='/images/right_arrow.gif' /> ")
	end

  def get_analytics_code
		s = Setting.find_by_name('analytics_code')
    if current_user
      user_defined_code = Setting.find_by_name('user_defined_analytics_code')
      return (s.nil? || s.value.nil? || s.value.empty?) ? "" : s.value + "<script>if (typeof(_gat) == 'object') { try { var pageTrackernew = _gat._getTracker('#{user_defined_code}'); pageTrackernew._trackPageview(); pageTrackernew._setVar('customers_#{ current_user.id}_#{current_user.email}'); } catch(err) {} }</script>"
    else
      return (s.nil? || s.value.nil? || s.value.empty?) ? "" : s.value
    end
	end

  def asset_name(fid)
    f = Folder.find(fid)
    if !f.property.nil?
      return f.property.note_id
    else
      return "Template"
    end
  end

  def display_graph_values(val)
    val = val.to_i
    if val >= 1000 and val <= 999999
      n = (val/1000).to_i
      return "$"+n.to_s+"K"
    elsif val >= 1000000 and val <= 999999999
      n = (val/1000000).to_i
      return "$"+n.to_s+"M"
    elsif val >= 1000000000 and val <= 9999999999
      n = (val/10000000).to_i
      return "$"+n.to_s+"B"
    else
      return "$"+val.to_s
    end
  end





  #To check if a folder is shared to any
	def check_is_folder_shared(f)
		sf = SharedFolder.find_by_folder_id(f.id,:conditions=>["user_id = ? or sharer_id =?",current_user.id,current_user.id],:select=>'id')
		if sf.nil? && f.user_id != current_user.id
			return "false"
		else
			return "true"
		end
	end


  def fetch_missing_actuals_real_estate(note_id)
    p = RealEstateProperty.find(note_id)
    f = Folder.find_by_real_estate_property_id_and_portfolio_id(p.id,p.portfolio_id)
    fetch_folder_of_cashflow(f.id,true)
    @folder_s = @folder_s.blank? ? f.id : @folder_s
    return @folder_s
  end

  def fetch_excels_folder(note_id)
    p = RealEstateProperty.find(note_id)
    #f = Folder.find_by_real_estate_property_id_and_portfolio_id(p.id,p.portfolio_id) - Selected only id as other fields are not used
    f = Folder.find(:first,:conditions=>['real_estate_property_id =? and portfolio_id = ?',p.id,p.portfolio_id],:select=>'id')
    fetch_folder_of_excels(f.id,true)
    @folder_s = @folder_s.blank? ? f.id : @folder_s
    return @folder_s
  end

  def fetch_accounts_excels_folder(note_id)
    p = RealEstateProperty.find(note_id)
    f = Folder.find(:first,:conditions=>['real_estate_property_id =? and portfolio_id = ? and name = ?',p.id,p.portfolio_id,'Accounts'])
    a = f.nil? ? p.id : f.id
    return a
  end

  def fetch_leases_excels_folder(note_id)
    p = RealEstateProperty.find(note_id)
    f = Folder.find(:first,:conditions=>['real_estate_property_id =? and portfolio_id = ? and name = ?',p.id,p.portfolio_id,'Leases'])
    a = f.nil? ? p.id : f.id
    return a
  end

  def select_time_period(period,note_id,partial_page,start_date,timeline_start,timeline_end)
		if params[:start_date] != 0
			@timeline = params[:start_date]
		end
    if (!(request.env['HTTP_REFERER'].nil?) && request.env['HTTP_REFERER'].include?("real_estate") || controller.controller_name == 'real_estates') || (controller.controller_name == 'properties') || (controller.controller_name == "property_acquisitions") || (controller.controller_name == 'performance_review_property')
      @note = RealEstateProperty.find(note_id)
    else
      @note = Property.find(note_id)
    end
		@period = period.to_s
		@time = Time.now
		@date_array = []
		@date_element = []
    sd = -6
    ed = 6
    timeline_start_date = ActiveRecord::Base.connection.select_one("SELECT TIMESTAMPDIFF(MONTH,'#{@time.to_date}','#{timeline_start.to_date}')  as no_of_months")
    timeline_end_date = ActiveRecord::Base.connection.select_one("SELECT TIMESTAMPDIFF(MONTH,'#{timeline_start.to_date}','#{timeline_end.to_date}')  as no_of_months")
    if timeline_start_date["no_of_months"].to_i < sd
      sd = timeline_start_date["no_of_months"].to_i
    end
    if timeline_end_date["no_of_months"].to_i > ed
      ed = timeline_end_date["no_of_months"].to_i
    end
		if @period == "1"	or 	@period == "4" or @period == "5"	or @period=="6"
      #~ Below for loop is commented since collect data periodically is removed
			#~ for j in sd .. -1
      #~ @date_array << (@time.advance(:months => j).to_date).strftime("%b")+" - "+(@time.advance(:months => j).to_date).strftime("%Y")
      #~ @date_element << (@time.advance(:months => j).to_date).beginning_of_month.strftime("%Y-%m-%d")
			#~ end
			#~ @date_array << @time.strftime("%b")+" - "+@time.strftime("%Y")
			#~ @date_element << @time.beginning_of_month.strftime("%Y-%m-%d")
			#~ for k in 1 .. ed
      #~ @date_array << (@time.advance(:months => k).to_date).strftime("%b")+" - "+(@time.advance(:months => k).to_date).strftime("%Y")
      #~ @date_element << (@time.advance(:months => k).to_date).beginning_of_month.strftime("%Y-%m-%d")
			#~ end
      for j in 0 .. timeline_end_date["no_of_months"].to_i
				@date_array << (timeline_start.advance(:months => j).to_date).strftime("%b")+" - "+(timeline_start.advance(:months => j).to_date).strftime("%Y")
				@date_element << (timeline_start.advance(:months => j).to_date).beginning_of_month.strftime("%Y-%m-%d")
      end
		elsif @period == "2"
      @quarter_time = @time.beginning_of_year.advance(:years=>-1)
      i = 1
      (0 .. 36).step(3){ |j|
        @date_array << "Q#{i}"+" - "+(@quarter_time.advance(:months => j).to_date).strftime("%Y")
        @date_element << @quarter_time.advance(:months => j).beginning_of_quarter.strftime("%Y-%m-%d")+" - "+@quarter_time.advance(:months => j).end_of_quarter.strftime("%Y-%m-%d")
        i = i + 1
        i > 4 ? i=1 : i=i
      }
		elsif @period ==  "3"
      @time = @time.beginning_of_year
			for j in -6 .. -1
        @date_array << @time.advance(:years=>j).strftime("%Y")+"  "
				#@date_array << (@time.advance(:years => j).to_date).beginning_of_month.strftime("%Y-%b")+" - "+(@time.advance(:years => j).to_date).end_of_month.strftime("%Y-%b")
				@date_element << (@time.advance(:years => j).to_date).beginning_of_year.strftime("%Y-%m-%d")+" - "+(@time.advance(:years => j).to_date).end_of_year.strftime("%Y-%m-%d")
			end
			#@date_array << @time.strftime("%Y-%b")+" - "+@time.strftime("%Y-%b")
      @date_array << @time.strftime("%Y")+"  "
			@date_element << @time.strftime("%Y-%m-%d")+" - "+@time.end_of_year.strftime("%Y-%m-%d")
			for k in 1 .. 6
				#@date_array << (@time.advance(:years => k).to_date).beginning_of_month.strftime("%Y-%b")+" - "+(@time.advance(:years => k).to_date).end_of_month.strftime("%Y-%b")
        @date_array << @time.advance(:years=>k).strftime("%Y")+"  "
				@date_element << (@time.advance(:years => k).to_date).beginning_of_year.strftime("%Y-%m-%d")+" - "+(@time.advance(:years => k).to_date).end_of_year.strftime("%Y-%m-%d")
			end
		else
			@date = "Select Period"
		end
	end

  def lengthy_word_simplification(word, begin_num=15, end_num=10, sep_char=".",sep_char_repeat=3)
    if word !=nil
      if (begin_num + end_num + sep_char_repeat + 2) < word.length
        return word.slice(0,begin_num).to_s+(sep_char * sep_char_repeat)+word.slice(word.length-end_num,end_num)
      else
        return word
      end
    end
  end

  def find_all_events_of_folder(folder_id, loop_starts)
    #folders = Folder.find(:all,:conditions=> ["parent_id = ?",folder_id])
    folders = Folder.find(:all,:conditions=> ["parent_id = ?",folder_id],:select=>'id') # - Selected only id field
    @folder_s = [ ] if (@folder_s.nil? || @folder_s.empty? || loop_starts)
    @doc_s = [ ] if (@doc_s.nil? || @doc_s.empty? || loop_starts)
    @doc_names = [ ] if (@doc_names.nil? || @doc_names.empty? || loop_starts)
    @tasks = [ ] if (@tasks.nil? || @tasks.empty? || loop_starts)
    @task_file = [ ] if (@task_file.nil? || @task_file.empty? || loop_starts)

    folders.each do |f|
      find_all_events_of_folder(f.id, false)
      @folder_s << f
    end

    #documents = Document.find(:all,:conditions=> ["folder_id = ?",folder_id])
    documents = Document.find(:all,:conditions=> ["folder_id = ?",folder_id],:select=>'id') # - Selected only id field
    @doc_s += documents

    #document_names = DocumentName.find(:all,:conditions=> ["folder_id = ?",folder_id])
    document_names = DocumentName.find(:all,:conditions=> ["folder_id = ?",folder_id],:select=>'id') # - Selected only id field
    @doc_names += document_names

    tasks_with_file = Task.find(:all, :conditions => ["document_id in (?)",@doc_s],:select=>'id') if !(@doc_s.nil? || @doc_s.blank?)
    tasks_without_file = Task.find(:all, :conditions => ["folder_id in (?)",folder_id],:select=>'id')
    @tasks += tasks_with_file if !(tasks_with_file.nil? || tasks_with_file.blank?)
    @tasks += tasks_without_file if !(tasks_without_file.nil? || tasks_without_file.blank?)

    task_file = TaskFile.find(:all, :conditions => ["task_id in (?)",@tasks],:select=>'id') if !(@tasks.nil? || @tasks.blank?)
    @task_file += task_file if !(task_file.nil? || task_file.blank?)

    return @folder_s,@doc_s,@doc_names,@tasks,@task_file
  end

  def find_comment(id,type)
    if type == "folder"
      sf = SharedFolder.find(id)
      comment = sf.nil? ? " " : sf.comments
      return comment
    elsif type == "document"
      sf = SharedDocument.find(id)
      comment = sf.nil? ? " " : sf.comments
      return comment
    end
  end

  def find_comment_document_name(id,type)
    shared_document_name = ShareDocumentName.find_by_document_name_id(id,:conditions=>["user_id = ? ",current_user.id])
    return shared_document_name.comments if shared_document_name != nil

  end

  def shared_doc_name_doc_comment(id)
    sd = SharedDocument.find_by_document_id(id,:conditions=>["user_id = ? ",current_user.id])
    return sd
  end

  def display_currency_real_estate_overview(value, precision_count=2)
    #(value.nil? || value.blank? || value = 0) ? "<font style='color:#CC6633'>$0.00</font>" : "$" + number_with_delimiter(number_with_precision(value, :precision=>precision_count))
    if value.nil? || value.blank? || value == 0
      "$0"
    elsif value < 0
      #value = value.abs
      "-$#{number_with_delimiter(value.round.abs)}"
    else
      "$#{number_with_delimiter(value.round.abs)}"
    end
  end

  def display_currency_real_estate_variance(value, precision_count=2)
    #(value.nil? || value.blank? || value = 0) ? "<font style='color:#CC6633'>$0.00</font>" : "$" + number_with_delimiter(number_with_precision(value, :precision=>precision_count))
    if value.nil? || value.blank? || value == 0
      "$0"
    elsif value < 0
      # value = value.abs
      "$#{number_with_delimiter(value.round.abs)}"
    else
      "$#{number_with_delimiter(value.round)}"
    end
  end


  def display_currency_real_estate_overview_for_percent_for_exp(value, precision_count=2)
    #(value.nil? || value.blank? || value = 0) ? "<font style='color:#CC6633'>$0.00</font>" : "$" + number_with_delimiter(number_with_precision(value, :precision=>precision_count))
    if value.nil? || value.blank? || value == 0
      "0"
    elsif value < 0
      value = value.abs
      "#{(value.round.abs)}"
    else
      "#{(value.round)}"
    end
  end
  
  def display_currency_real_estate_variance_for_exp(value, precision_count=2)
    #(value.nil? || value.blank? || value = 0) ? "<font style='color:#CC6633'>$0.00</font>" : "$" + number_with_delimiter(number_with_precision(value, :precision=>precision_count))
    if value.nil? || value.blank? || value == 0
      "0"
    elsif value < 0
      # value = value.abs
      "#{(value.round.abs)}"
    else
      "#{(value.round)}"
    end
  end

  def display_currency_real_estate_overview_for_percent(value, precision_count=2)
    # If any error comes change the data type condition
    if value.class == Float && (value.infinite? || value.nan?)
       "0%"
    #(value.nil? || value.blank? || value = 0) ? "<font style='color:#CC6633'>$0.00</font>" : "$" + number_with_delimiter(number_with_precision(value, :precision=>precision_count))
    elsif value.nil? || value.blank? || value == 0 #|| value.infinite? || value.nan?
      "0%"
    elsif value < 0
      value = value.abs
      "#{number_with_delimiter(value.round.abs)}%"
    else
      "#{number_with_delimiter(value.round)}%"
    end
  end

  def display_sqrt_real_estate_overview(value, precision_count=2)
    #(value.nil? || value.blank? || value = 0) ? "<font style='color:#CC6633'>$0.00</font>" : "$" + number_with_delimiter(number_with_precision(value, :precision=>precision_count))
    if value.nil? || value.blank? || value == 0
      "0"
    elsif value < 0
      value = value.abs
      "#{number_with_delimiter(value.round.abs)} Sqft"
    else
      "#{number_with_delimiter(value.round)} Sqft"
    end
  end
  
  def display_units(value)
    if value.blank? || value == 0
      "0 Units"
    elsif value == 1
      "1 Unit"
    else
      value < 0  ? "#{number_with_delimiter(value.abs)} Units" : "#{number_with_delimiter(value)} Units"
    end
  end 

  def sort_link_helper(text, parameter, options)
    update = options.delete(:update)
    action = options.delete(:action)
    controller = options.delete(:controller)
    page = options.delete(:page)
    per_page = options.delete(:per_page)
    sel_category = options.delete(:sel_category)
    search_txt = options.delete(:search_txt)
    categories = options.delete(:categories)
    is_primary = options.delete(:is_primary)
    id = options.delete(:id)
    tl_period =  options.delete(:tl_period)
    tl_month =  options.delete(:tl_month)
    tl_year =  options.delete(:tl_year)
    period = options.delete(:period)
    start_date = options.delete(:start_date)
    partial_page = options.delete(:partial_page)
    occupancy_type = options.delete(:occupancy_type) #added for lease sort
    key = parameter
    key += " DESC" if params[:sort] == parameter
    key += " ASC" if params[:sort] == "nil"
    options = {
      :url => {:controller=>controller,:action => action,:id => id, :sort => key, :page => page ,:per_page => per_page,:sel_category => sel_category,:search_txt => search_txt,:categories => categories,:is_primary=>is_primary,:method=>:get,:start_date =>start_date,:partial_page=> partial_page,:period => period,:tl_period => tl_period,:tl_month => tl_month,:tl_year => tl_year,  :occupancy_type => occupancy_type },
      :update => update,
      :loading =>"load_writter();",
      :complete => "load_completer();"
    }
    link_to_remote(text, options)
  end

  #To display total value of actuals column in capital improvements in performance review page
  def total_cap_ex_actual(capex)
    p = capex.tenant_imp_actual.nil? ? 0 : capex.tenant_imp_actual
    q = capex.leasing_comm_actual.nil? ? 0 : capex.leasing_comm_actual
    r = capex.building_imp_actual.nil? ? 0 : capex.building_imp_actual
    s = capex.lease_cost_actual.nil? ? 0 : capex.lease_cost_actual
    return p.to_f+q.to_f+r.to_f+s.to_f
  end

  #To display total value of budget column in capital improvements in performance review page
  def total_cap_ex_budget(capex)
    p = capex.tenant_imp_budget.nil? ? 0 : capex.tenant_imp_budget
    q = capex.leasing_comm_budget.nil? ? 0 : capex.leasing_comm_budget
    r = capex.building_imp_budget.nil? ? 0 : capex.building_imp_budget
    s = capex.lease_cost_budget.nil? ? 0 : capex.lease_cost_budget
    return p.to_f+q.to_f+r.to_f+s.to_f
  end

  def find_sorting_image(params,column)
    if params[:sort] && params[:sort].downcase.include?("desc") && params[:sort].downcase.include?(column)
      img = "<img src='/images/bulletarrowdown.png' width='7' height='5' />"
    elsif  params[:sort] && params[:sort].split(" ")[1] == nil && params[:sort].downcase.include?(column)
      img = "<img src='/images/bulletarrowup.png' width='7' height='5' />"
		else
      img = "<img src='/images/bulletarrowdown.png' width='7' height='5' />"
    end
  end

  #To display variance value of building improvements for capital improvements in performance review page
  def variance_for_cap_ex_building_improvement(capex)
    b = capex.building_imp_budget.nil? ? 0 : capex.building_imp_budget.to_f
    a = capex.building_imp_actual.nil? ? 0 : capex.building_imp_actual.to_f
    diff = b - a
    return diff != 0 ? (diff * 100/b).to_i : 0
  end

  #To display variance value of tenant improvements for capital improvements in performance review page
  def variance_for_cap_ex_tenant_improvement(capex)
    b = capex.tenant_imp_budget.nil? ? 0 : capex.tenant_imp_budget.to_f
    a = capex.tenant_imp_actual.nil? ? 0 : capex.tenant_imp_actual.to_f
    diff = b - a
    return diff != 0 ? (diff * 100/b).to_i : 0
  end

  #To display variance value of leasing commissions for capital improvements in performance review page
  def variance_for_cap_ex_leasing_comm(capex)
    b = capex.leasing_comm_budget.nil? ? 0 : capex.leasing_comm_budget.to_f
    a = capex.leasing_comm_actual.nil? ? 0 : capex.leasing_comm_actual.to_f
    diff = b - a
    return diff != 0 ? (diff * 100/b).to_i : 0
  end

  #To display variance value of lease costs for capital improvements in performance review page
  def variance_for_cap_ex_lease_cost(capex)
    b = capex.lease_cost_budget.nil? ? 0 : capex.lease_cost_budget.to_f
    a = capex.lease_cost_actual.nil? ? 0 : capex.lease_cost_actual.to_f
    diff = b - a
    return diff != 0 ? (diff * 100/b).to_i : 0
  end

  def form_hash_of_data_for_capex(capex)
    @capex_variance = {}

    @capex_variance[:b_variant] = capex.building_imp_budget.to_f - capex.building_imp_actual.to_f
    @capex_variance[:t_variant] = capex.tenant_imp_budget.to_f - capex.tenant_imp_actual.to_f
    @capex_variance[:l_com_variant] = capex.leasing_comm_budget.to_f - capex.leasing_comm_actual.to_f
    @capex_variance[:l_cos_variant] = capex.lease_cost_budget.to_f - capex.lease_cost_actual.to_f

    @capex_variance[:b_status] = @capex_variance[:b_variant] < 0 ? false : true
    @capex_variance[:t_status] = @capex_variance[:t_variant] < 0 ? false : true
    @capex_variance[:l_com_status] = @capex_variance[:l_com_variant] < 0 ? false : true
    @capex_variance[:l_cos_status] = @capex_variance[:l_cos_variant] < 0 ? false : true

    @capex_variance[:b_percent_bar] = (capex.building_imp_actual.to_f * 100/ capex.building_imp_budget.to_f.abs) rescue ZeroDivisionError
    @capex_variance[:t_percent_bar] = (capex.tenant_imp_actual.to_f * 100/ capex.tenant_imp_budget.to_f.abs) rescue ZeroDivisionError
    @capex_variance[:l_com_percent_bar] = (capex.leasing_comm_actual.to_f * 100/ capex.leasing_comm_budget.to_f.abs) rescue ZeroDivisionError
    @capex_variance[:l_cos_percent_bar] = (capex.lease_cost_actual.to_f * 100/ capex.lease_cost_budget.to_f.abs) rescue ZeroDivisionError
    @capex_variance[:l_tot_percent_bar] = ((total_cap_ex_actual(@cap_exp) * 100 ) / total_cap_ex_budget(@cap_exp)) rescue ZeroDivisionError

    @capex_variance[:b_percent] = @capex_variance[:b_variant] * 100/ capex.building_imp_budget.to_f.abs rescue ZeroDivisionError
    if  capex.building_imp_budget.to_f==0
      @capex_variance[:b_percent] = ( capex.building_imp_actual.to_f == 0 ? 0 : -100 )
    end
    @capex_variance[:b_percent] = 0.0 if @capex_variance[:b_percent].to_f.nan?

    @capex_variance[:t_percent] = @capex_variance[:t_variant] * 100/ capex.tenant_imp_budget.to_f.abs rescue ZeroDivisionError
    if  capex.tenant_imp_budget.to_f==0
      @capex_variance[:t_percent] = ( capex.tenant_imp_actual.to_f == 0 ? 0 : -100 )
    end
    @capex_variance[:t_percent] = 0.0 if @capex_variance[:t_percent].to_f.nan?

    @capex_variance[:l_com_percent] = @capex_variance[:l_com_variant] * 100/ capex.leasing_comm_budget.to_f.abs rescue ZeroDivisionError

    if  capex.leasing_comm_budget.to_f==0
      @capex_variance[:l_com_percent] = ( capex.leasing_comm_actual.to_f == 0 ? 0 : -100 )
    end
    @capex_variance[:l_com_percent] = 0.0 if @capex_variance[:l_com_percent].to_f.nan?

    @capex_variance[:l_cos_percent] = @capex_variance[:l_cos_variant] * 100/ capex.lease_cost_budget.to_f.abs rescue ZeroDivisionError
    if  capex.lease_cost_budget.to_f==0
      @capex_variance[:l_cos_percent] = ( capex.lease_cost_actual.to_f == 0 ? 0 : -100 )
    end
    @capex_variance[:l_cos_percent] = 0.0 if @capex_variance[:l_cos_percent].to_f.nan?

    @capex_variance[:b_percent_bar]  = @capex_variance[:b_percent_bar] > 100 ? 100 : @capex_variance[:b_percent_bar]
    @capex_variance[:t_percent_bar]  = @capex_variance[:t_percent_bar] > 100 ? 100 : @capex_variance[:t_percent_bar]
    @capex_variance[:l_com_percent_bar]  = @capex_variance[:l_com_percent_bar] > 100 ? 100 : @capex_variance[:l_com_percent_bar]
    @capex_variance[:l_cos_percent_bar]  = @capex_variance[:l_cos_percent_bar] > 100 ? 100 : @capex_variance[:l_cos_percent_bar]
    @capex_variance[:l_tot_percent_bar]  = @capex_variance[:l_tot_percent_bar] > 100 ? 100 : @capex_variance[:l_tot_percent_bar]

		@capex_variance[:cap_ex_total_variant] = @capex_variance[:b_variant] + @capex_variance[:t_variant] + @capex_variance[:l_com_variant] + @capex_variance[:l_cos_variant]
    @capex_variance[:cap_ex_total_percent] =  (total_cap_ex_budget(@cap_exp) == 0.0) ? 0 : ( @capex_variance[:cap_ex_total_variant] * 100 ) / total_cap_ex_budget(@cap_exp)# @capex_variance[:b_percent] + @capex_variance[:t_percent] + @capex_variance[:l_com_percent] + @capex_variance[:l_cos_percent]

    @capex_variance[:cap_ex_total_status] = @capex_variance[:cap_ex_total_variant] <= 0 ? false : true

    return @capex_variance
	end

  def display_time
    if (!params[:tl_month].nil? and !params[:tl_month].blank?)
      c = params[:tl_month].to_i
      a =  Date.new(Date.today.year,c)
      a.strftime("%b-%Y")
    elsif (!params[:tl_period].nil? && params[:tl_period] == "4") or (!params[:period].nil? and params[:period] == "4" and params[:start_date].nil?)
      "Year To Date"
    elsif !params[:start_date].nil?
      @start_date.to_date.strftime("%b-%Y")
    else
      @start_date.to_date.ago(1.month).strftime("%b-%Y")
    end
  end


  def sort_link_helper_portfolio_overview(text, parameter, options)
    update = options.delete(:update)
    action = options.delete(:action)
    controller = options.delete(:controller)
    page = options.delete(:page)
    per_page = options.delete(:per_page)
    is_primary = options.delete(:is_primary)
    portfolio_id = options.delete(:portfolio_id)
    id = options.delete(:id)
    period = options.delete(:period)
    key = parameter
    key += " DESC" if params[:sort] == parameter
    key += " ASC" if params[:sort] == "nil"
    options = {
      :url => {:controller=>controller,:action =>action,:sort => key, :page => page ,:per_page => per_page,:portfolio_id => portfolio_id,:period => period},
      :update => update,
      :loading =>"load_writter();",
      :complete => "load_completer();"

    }
    link_to_remote(text, options)

	end

  def sort_link_helper_for_rent_roll(text, parameter, options)
    update = options.delete(:update)
    action = options.delete(:action)
    controller = options.delete(:controller)
    page = options.delete(:page)
    per_page = options.delete(:per_page)
    is_primary = options.delete(:is_primary)
    portfolio_id = options.delete(:portfolio_id)
    id = options.delete(:id)
    tl_year = options.delete(:tl_year)
    tl_month = options.delete(:tl_month)
    tl_period = options.delete(:tl_period)
    key = parameter
    key += " DESC" if params[:sort] == parameter
    key += " ASC" if params[:sort] == "nil"
    options = {
      :url => {:controller=>controller,:action =>action,:sort => key, :page => page ,:per_page => per_page,:portfolio_id => portfolio_id,:id => id, :tl_year=>tl_year,:tl_month=>tl_month,:tl_period=>tl_period},
      :update => update,
      :loading =>"load_writter();",
      :complete => "load_completer();"

    }
    link_to_remote(text, options)

  end

  def sort_link_properties_files(text, parameter, options)
    update = options.delete(:update)
    action = options.delete(:action)
    controller = options.delete(:controller)
    page = options.delete(:page)
    per_page = options.delete(:per_page)
    partial_page = options.delete(:partial_page)
    is_primary = options.delete(:is_primary)
    portfolio_id = options.delete(:portfolio_id)
    pid = portfolio_id
    data_hub="asset_data_and_documents"
    id = "asset_docs"
    period = options.delete(:period)
    key = parameter
    key += " DESC" if params[:sort] == parameter
    key += " ASC" if params[:sort] == "nil"
    order = " DESC" if params[:sort] == parameter
    order = " ASC" if params[:sort] == "nil"
    options = {
      :url => {:controller=>controller,:action =>action,:sort => key, :page => page ,:per_page => per_page,:portfolio_id => portfolio_id,:period => period, :order => order, :partial_page=>partial_page,:pid => pid,:data_hub=>data_hub,:id=>id},
      :update => update,
      :loading =>"load_writter();",
      :complete => "load_completer();"

    }
    link_to_remote(text, options)
  end

  #<a onclick="show_datahub_image_real_estate(current_id,'asset_data_and_documents','asset_docs');return false;" href="#"><img border="0" width="27" height="28" src="/images/setup_icon.png"></a>
  #new Ajax.Request("/properties/show_asset_docs/?pid="+pid+"&data_hub="+data_hub+"&id="+id+"&parent_delete="+parent_delete,{

  def sort_link(text, parameter, options)
    update = options.delete(:update)
    action = options.delete(:action)
    controller = options.delete(:controller)
    page = options.delete(:page)
    per_page = options.delete(:per_page)
    partial_page = options.delete(:partial_page)
    is_primary = options.delete(:is_primary)
    portfolio_id = options.delete(:portfolio_id)
    id = options.delete(:id)
    period = options.delete(:period)
    key = parameter
    key += " DESC" if params[:sort] == parameter
    key += " ASC" if params[:sort] == "nil"
    order = " DESC" if params[:sort] == parameter
    order = " ASC" if params[:sort] == "nil"
    options = {
      :url => {:controller=>controller,:action =>action,:sort => key, :page => page ,:per_page => per_page,:portfolio_id => portfolio_id,:period => period, :order => order, :partial_page=>partial_page},
      :update => update,
      :loading =>"load_writter();",
      :complete => "load_completer();"

    }
    link_to_remote(text, options)
  end

  #To display texts next to the count in performance review tabs.Count of the collection and the text to be displayed are passed as arguments
  def display_text_for_counts(val,txt)
    if val == 1
      return txt
    elsif val > 1
      return txt.pluralize
    else
      return ""
    end
  end

  #To display tenants name without any special characters in the start and end
  def display_tenant_name(tnt)
    res = tnt.match(/^[^a-zA-Z\d]+/)
    if !res.nil?
      tnt_name = tnt[1..-1]
      return tnt_name
    else
      return tnt
    end
  end

	def get_google_key
    return Setting.find_by_name("google_key").value
	end

  def remove_sharing_for_sub_folders_and_docs(folder_id, loop_starts)
    folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id])
    @folder_s = [ ] if (@folder_s.nil? || @folder_s.empty? || loop_starts)
    @doc_s = [ ] if (@doc_s.nil? || @doc_s.empty? || loop_starts)
    @doc_names = [ ] if (@doc_names.nil? || @doc_names.empty? || loop_starts)

    folders.each do |f|
      f.tasks.each do |folder_task|
        folder_task.task_collaborators.destroy_all
      end unless f.tasks.empty?
      remove_sharing_for_sub_folders_and_docs(f.id, false)
      shared_folders = f.shared_folders.collect{|s| s if s.user_id != current_user.id}
      unless shared_folders.empty? || shared_folders == [nil]
        f.shared_folders.collect{|sf| sf.destroy if sf != nil}
      end
      # f.shared_folders.destroy_all
      @folder_s << f
    end
    documents = Document.find(:all,:conditions=> ["folder_id = ? and is_deleted=false",folder_id])
    documents.each do |d|
      sd = d.shared_documents.destroy_all
      remove_task_collaborators_move_to_copy_to(d)
      @doc_s << sd if sd != nil
    end

    document_names = DocumentName.find(:all,:conditions=> ["folder_id = ?",folder_id])
    document_names.each do |dn|
      sdn = dn.share_document_names.destroy_all
      @doc_names << sdn if sdn != nil
    end
  end

  def bread_crum_cash(targ, result = [])
    data = IncomeAndCashFlowDetail.find(targ)
    unless data.nil?
      result << "#{data.id}----#{data.title}"
      bread_crum_cash(data.parent_id,result) if !data.parent_id.nil?
    end
    result
  end

  def wres_bread_crum_cash(targ, result = [])
    data = PropertyCashFlowForecast.find(targ)
    unless data.nil?
      result << "#{data.id}----#{data.title}"
      wres_bread_crum_cash(data.parent_id,result) if !data.parent_id.nil?
    end
    result
  end

  def is_move_to_copy_to_link_display(folder_id)
    @folder = Folder.find_by_id(folder_id)
    @real_estate_property_id = @folder.real_estate_property_id
    @real_estate_property = RealEstateProperty.find_by_id(@real_estate_property_id)
    portfolios = Portfolio.find_by_sql("SELECT p.id FROM shared_folders sf INNER JOIN folders ft ON sf.folder_id = ft.id INNER JOIN real_estate_properties pt ON ft.real_estate_property_id = pt.id INNER JOIN portfolios p ON pt.portfolio_id = p.id and p.portfolio_type_id = 2 and (sf.user_id = #{current_user.id})")
    pids = portfolios.collect{|p| p.id}.uniq unless portfolios.empty?
    portfolio_list = Portfolio.find(:all,:conditions => ["id in (?)",pids]) if pids && !pids.empty?
    @shared_folders_in_portfolios = []
    if portfolio_list && !portfolio_list.empty?
      for portfolio in portfolio_list
        if !portfolio.real_estate_properties.empty?
          for property in portfolio.real_estate_properties
            parent_folder = Folder.find_by_real_estate_property_id_and_parent_id(property.id,0)
            recursive_function_to_check_move_copy_link_display(parent_folder) if !parent_folder.nil?
          end
        end
      end
    end
    if @shared_folders_in_portfolios.length == 1 || @shared_folders_in_portfolios.empty?
      return false
    else
      return true
    end
  end


  def recursive_function_to_check_move_copy_link_display(parent_folder)
    if @folder.id != parent_folder.id
      children = Folder.find_all_by_parent_id_and_is_deleted(parent_folder.id,false)
      if (!children.nil? && !children.empty?)
        if (!children.nil? && !children.empty?)
          for child in children
            recursive_function_to_check_move_copy_link_display(child) if check_is_folder_shared(child) == "true"
            @shared_folders_in_portfolios << child if check_is_folder_shared(child) == "true"
          end
        end
      end
    end
  end

  def display_collaborators_new(members,obj,obj_id,j)
    z_ind = 24900-(j*200)
    len = members.uniq.length
    if len == 1
      if members.first !=nil
        owner = find_folder_doc_doc_name_owner_name(obj_id,obj)
        sharer = find_folder_doc_doc_name_sharer_name(obj_id,obj)
        members_first_display = members.first.name.nil? ||  members.first.name.blank? ? members.first.email : members.first.name
        sharer_display = sharer.name.nil?  ||  sharer.name.blank? ? sharer.email : sharer.name if sharer != nil
        r =  sharer.email == current_user.email ? members_first_display : sharer_display if sharer != nil
        r =  owner.email == current_user.email ? members_first_display : members_first_display if sharer == nil
        r = "<span class='tooltip' id='tooltip_#{obj}_#{obj_id}' style='display: none;z-index:#{z_ind};'>#{r}</span><span onmouseout=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','none');\" onmouseover=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','block');\">#{display_truncated_chars(r,20,true)}</span>"        
      end
      return r
    elsif len == 2
      if members.first !=nil && members[1] !=nil
        owner = find_folder_doc_doc_name_owner_name(obj_id,obj)
        sharer = find_folder_doc_doc_name_sharer_name(obj_id,obj)
        members_first_display = members.first.name.nil?  || members.first.name.blank? ? members.first.email : members.first.name
        members_second_display = members[1].name.nil? || members[1].name.blank? ? members[1].email : members[1].name
        second_mail =  sharer.email == members.first.email ? members_second_display : members_first_display if sharer != nil
        sharer_email = (sharer.name.nil? || sharer.name.blank?) ? sharer.email : sharer.name if !sharer.nil?
        r =  sharer == current_user.name ? "#{members_first_display} & #{members_second_display}" :   "#{sharer_email} & #{second_mail}" if sharer != nil
        r =  owner == current_user.name ? "#{members_first_display} & #{members_second_display}" :   "#{members_first_display} & #{members_second_display}" if sharer == nil
        name_display = r.split("&")
        full_name_display = name_display[0] +"<br>" + name_display[1]
        r = "<span class='tooltip' id='tooltip_#{obj}_#{obj_id}' style='display: none;z-index:#{z_ind};'>#{full_name_display}</span><span onmouseout=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','none');\" onmouseover=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','block');\">#{display_truncated_chars(r,20,true)}</span>"        
      end
      return r
    elsif len > 2
      others = members.collect{|x|x.name if x !=nil}
      if members.first !=nil
        owner = find_folder_doc_doc_name_owner_name(obj_id,obj)
        sharer = find_folder_doc_doc_name_sharer_name(obj_id,obj)
        if sharer != nil
          others =  members.reject{|m| m == sharer}
          others = others.compact.collect{|u| (u.name.nil? || u.name.blank?) ? u.email : u.name}
          others = others.uniq.join('<br>')
        end
        if owner == current_user
          others =  members.reject{|m| m == members.first} if members.first !=nil
          others = others.compact.collect{|u| (u.name.nil? || u.name.blank?) ? u.email : u.name}
          others = others.uniq.join('<br>')
        end
        members_first_display = members.first.name.nil?  || members.first.name.blank? ? members.first.email : members.first.name
        members_first_display_with_out_truncation = members_first_display
        members_first_display =  display_truncated_chars(members_first_display,13,true)
        if sharer != nil
          sharer_display = sharer.name.nil?  || sharer.name.blank? ? sharer.email : sharer.name
          sharer_display_with_out_truncation = sharer_display
          sharer_display =  display_truncated_chars(sharer_display,13,true)
        end
        if sharer != nil
          if sharer.email == current_user.email 
            others = "#{members_first_display_with_out_truncation}<br>" + others
          else
            others = "#{sharer_display_with_out_truncation}<br>" + others
          end 
        else
          others = "#{members_first_display_with_out_truncation}<br>" + others
        end
         
        r =  sharer.email == current_user.email ?   "<span class='tooltip' id='tooltip_#{obj}_#{obj_id}' style='display: none;z-index:#{z_ind};'>#{others}</span><span onmouseout=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','none');\" onmouseover=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','block');\">#{members_first_display} & #{len-1} others</span>" : "<span class='tooltip' id='tooltip_#{obj}_#{obj_id}' style='display: none;z-index:#{z_ind};'>#{others}</span><span  onmouseout=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','none');\" onmouseover=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','block');\">#{sharer_display} & #{len-1} others</span>" if sharer != nil
        
        r =  owner.email == current_user.email ?   "<span class='tooltip' id='tooltip_#{obj}_#{obj_id}' style='display: none;z-index:#{z_ind};'>#{others}</span><span onmouseout=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','none');\" onmouseover=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','block');\">#{members_first_display} & #{len-1} others</span>" : "<span class='tooltip' id='tooltip_#{obj}_#{obj_id}' style='display: none;z-index:#{z_ind};'>#{others}</span><span  onmouseout=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','none');\" onmouseover=\"jQuery('#tooltip_#{obj}_#{obj_id}').css('display','block');\">#{members_first_display} & #{len-1} others</span>" if sharer == nil
      end
      return r
    else
    end
  end

  def find_folder_doc_doc_name_sharer_name(obj_id,obj)
    if obj == "folder"
      sf = SharedFolder.find_by_folder_id(obj_id,:conditions=>["user_id = ? and sharer_id != ?",current_user.id,current_user.id])
      sharer = User.find(sf.sharer_id) if sf != nil && User.exists?(sf.sharer_id)
    elsif obj == "doc"
      sd = SharedDocument.find_by_document_id(obj_id,:conditions=>["user_id = ? and sharer_id != ?",current_user.id,current_user.id])
      sharer = User.find(sd.sharer_id) if sd != nil && User.exists?(sd.sharer_id)
    elsif obj == "task"
      sdn = TaskCollaborator.find_by_task_id(obj_id,:conditions=>["user_id = ?", current_user.id])
      sharer = User.find(sdn.sharer_id) if sdn != nil && User.exists?(sdn.sharer_id)
    end
    return sharer
  end

  def find_folder_doc_doc_name_owner_name(obj_id,obj)
    if obj == "folder"
      owner =  find_folder_owner_name(obj_id)
    elsif obj == "doc"
      owner =  find_doc_owner_name(obj_id)
    elsif obj == "task"
      owner=  find_task_owner(obj_id)
    end
    return owner
  end

  def find_task_owner(obj_id)
    Task.find_by_id(obj_id).user
  end


	def find_folder_owner_name(folder_id)
    user = Folder.find(folder_id).user
		return user
	end

  def find_doc_owner_name(doc_id)
    user = Document.find(doc_id).user
    return user
	end

  def display_tasks(t)
    due_date = !t.due_by.nil?  ? "#{t.due_by.strftime("%b %d")}" : " "
    unless t.is_completed?
      return  "<div class='action_label1' title='#{t.task_type.task_name.split(" ")[0]}'>#{t.task_type.task_name.split(" ")[0].slice(0,7)}</div><div class='action_label1'><img src='/images/timer_small_icon.png' width='16' height='16' border='0'/></div><div class='action_label2'> #{due_date} </div>"
    else
      return "Task Completed"
    end
    # return  "<div class='action_label1'><a href='#{shared_users_path(:task_id =>t.id)}'>#{t.task_type.task_name.split(" ")[0]}</a></div><div class='action_label1'><img src='/images/timer_small_icon.png' width='16' height='16' border='0'/></div><div class='action_label2'> #{due_date} </div>"
  end

  def user_profile_image(user_id)
		image = PortfolioImage.find(:first,:conditions=>['attachable_id = ? and attachable_type = ? and filename !="login_logo"',user_id,"User"])
		return image.nil? ? '/images/user.jpeg' : image.public_filename
  end

  def collect_properties(portfolio)
    properties = []
    real_estate_properties =  portfolio.real_estate_properties.find(:all,:order=>"id desc",:limit=>5)
    real_estate_properties.each do |property|
      sf = SharedFolder.find_by_real_estate_property_id_and_is_property_folder_and_user_id(property.id,true,current_user.id)
      if !sf.nil? || property.user_id == current_user.id
        property_name = property.property_name
        address = property.address != nil  && property.address.city != "" ? ", #{property.address.city} | " : " | "
        l = property_name + address
        properties << l
      end

    end
    properties = properties.empty? ? properties : properties.to_s.chop
    properties = properties.empty? ? properties :   portfolio.real_estate_properties && portfolio.real_estate_properties.length > 5 ? "#{properties.to_s}...." : properties
    return properties
  end


  def find_access_given_by(user)
    #if user.roles[0].id == 2
    a =  "AMP Administrator <br/> <a href='mailto:admin@theamp.com'>admin@theamp.com</a><br/>on #{user.created_at.strftime("%b%d, %Y.")}"
    return a
    #else

    #end
  end

  def goto_asset_view_path(user)
    portfolio_type=PortfolioType.find_by_name('Real Estate')
    portfolios = Portfolio.find(:all, :conditions=>['user_id = ? and portfolio_type_id = ? and name !="portfolio_created_by_system" ', user,portfolio_type.id])
    property = RealEstateProperty.find(:first, :conditions=>["portfolio_id IN (?) and property_name !='property_created_by_system' ", portfolios.collect{|x|x.id}], :order=>"portfolio_id desc") if !portfolios.nil? && !portfolios.empty?
    shared_folders = Folder.find_by_sql("SELECT * FROM folders WHERE id IN (SELECT folder_id FROM shared_folders WHERE is_property_folder =1 AND user_id = #{current_user.id })")
    shared_portfolios = Portfolio.find(:all, :conditions => ["id in (?)",shared_folders.collect {|x| x.portfolio_id}]) if !(shared_folders.nil? || shared_folders.blank?)
    #    shared_property = RealEstateProperty.find(:first, :conditions=>['portfolio_id=?', shared_portfolios.first.id ], :order=> "created_at desc") if !(shared_portfolios.nil? || shared_portfolios.blank?)
    shared=  SharedFolder.find(:first,:conditions=>['is_property_folder = ? and user_id=?',true,current_user.id]) if !(shared_portfolios.nil? || shared_portfolios.blank?)
    shared_property = shared.folder.real_estate_property unless shared.nil? || shared.blank?
    if controller.controller_name != "real_estates"
      if !(property.nil?)
        return real_estate_property_path(property.portfolio_id,property.id)
      elsif !(shared_property.nil?)
        return real_estate_property_path(shared_property.portfolio_id,shared_property.id,:prop_folder=>true)
      else
        flash.now[:error] = 'Add a property to go to Asset View'
        return "/real_estates?from_view=true"
      end
    else
      if @portfolios.first.real_estate_properties.blank?
        flash.now[:error] = 'Add a property to go to Asset View'
        return "/real_estates?from_view=true"
      else
        return real_estate_property_path(@portfolios.first.id,@portfolios.first.real_estate_properties.first.id)
      end
    end
  end

  def explanation_finder(id, doc, month, status)
    IncomeCashFlowExplanation.find(:first, :conditions=>['income_and_cash_flow_detail_id = ? and month= ? and ytd= ?', id, month, status])
  end

  def cap_explanation_finder(id, doc, month, status)
    CapitalExpenditureExplanation.find(:first, :conditions=>['property_capital_improvement_id = ? and month= ? and ytd= ?', id, month, status])
  end

  def show_portfolios
		@user = current_user
		@portfolios = current_user.portfolios.find(:all,:order=>"id desc")
    @shared_folders = Folder.find_by_sql("SELECT * FROM folders WHERE id IN (SELECT folder_id FROM shared_folders WHERE is_property_folder =1 AND user_id = #{current_user.id })")
		@portfolios +=  Portfolio.find(:all, :conditions => ["id in (?)",@shared_folders.collect {|x| x.portfolio_id}]) if !(@shared_folders.nil? || @shared_folders.blank?)
		render :update do |page|
      page.replace_html  "show_assets_list",:partial=>"/collaboration_hub/collaboration_overview"
    end
  end

	def display_image_for_user(user_id)
		image = PortfolioImage.find_by_attachable_id_and_attachable_type(user_id,'User')
		return !image.nil? ? image.public_filename : "/images/user.jpeg"
	end

  def display_image_for_user_add_collab(user_id)
		image = PortfolioImage.find_by_attachable_id_and_attachable_type(user_id,'User')
		return !image.nil? ? image.public_filename : "/images/adduserx_collab_dummy.jpg"
  end


  def count_var_explained_by_user(doc, month, user_id)
    ice = IncomeCashFlowExplanation.find(:last, :conditions=>['document_id = ? and month = ? and user_id = ?', doc, month, user_id])
    @explained_on = ice.updated_at.strftime("%b %d").downcase if ice
    IncomeCashFlowExplanation.count(:all, :conditions=>['document_id = ? and month = ? and user_id = ?', doc, month, user_id])
  end

  def count_var_expenditure_explained_by_user(doc, month, user_id)
    cec = CapitalExpenditureExplanation.find(:last, :conditions=>['document_id = ? and month = ? and user_id = ?', doc, month, user_id])
    @explained_on = cec.updated_at.strftime("%b %d").downcase if cec
    CapitalExpenditureExplanation.count(:all, :conditions=>['document_id = ? and month = ? and user_id = ?', doc, month, user_id])
  end

  def find_bar_color(use_color,act,bud)
    c = act == 0 && bud == 0 ? '' : use_color
    return c
  end

  def find_property_folder(folder)
    prop_folder = SharedFolder.find_by_folder_id_and_is_property_folder_and_user_id(folder.id,true,current_user.id)
    return prop_folder
  end

  def find_property_shared(note)
    prop_folder = SharedFolder.find_by_real_estate_property_id_and_is_property_folder_and_user_id(note.id,true,current_user.id)
    return prop_folder
  end
  
  def find_property_sharer(note)
    prop_folder = SharedFolder.find_by_real_estate_property_id_and_is_property_folder_and_sharer_id(note.id,true,current_user.id)
    return prop_folder
  end

  def check_user_own_portfolio
    user_own_portfolio = Portfolio.find(:all, :conditions=>["user_id = ?	and portfolio_type_id = 2 and name != 'portfolio_created_by_system'", current_user], :order=>'created_at DESC')
    return user_own_portfolio
  end
  
  def check_user_owned_for_portfolio(id)
    user_owned_portfolio = Portfolio.find_by_id_and_user_id(id,current_user.id)
    return user_owned_portfolio
  end

  def property_count(value)
    if value > 1
      return "#{value} Properties"
    else
      return "#{value == 0 ? 'No' : value } Property"
    end
  end

  #called from properties/folder_row
  def file_count(value)
    value = value.to_i if value.class == String
    if value == 1
      "#{value} File"
    #elsif value == 0
      #"No Files"
    else
      "#{value} Files"
    end
  end
  def finding_shared_folders_portfolios
    @shared_folders = Folder.find_by_sql("SELECT * FROM folders WHERE id IN (SELECT folder_id FROM shared_folders WHERE is_property_folder =1 AND user_id = #{current_user.id })")
    @ids = @shared_folders.collect {|x| x.portfolio_id}
    @portfolios+= Portfolio.find(:all, :conditions => ["id in (?) and name != 'portfolio_created_by_system'",@ids]) if !(@shared_folders.nil? || @shared_folders.blank?)
  end

  def my_files_find(id)
    folder = Folder.find(id)
    if folder.parent_id == 0 and folder.name == "my_files"
      return true
    elsif folder.parent_id == 0
      return false
    else
      my_files_find(id)
    end
  end

  def show_asset_docs_folder_needed(id)
    folder = Folder.find(id)
    shared_folder = SharedFolder.find(:all, :conditions=>["folder_id = ? and user_id = ? and sharer_id = ?",folder.id,current_user.id,folder.user_id])
    if (folder.parent_id == 0 and folder.name == "my_files") or !(shared_folder.nil?)
      return false
    else
      return true
    end
  end

  def task_originial_user(id)
    task = Task.find(id)
    task.user_id == current_user.id ? true : false
  end

  def task_with_or_without_doc(id)
    @task = Task.find(id)
    @fold = !@task.folder.nil? ? @task.folder : nil
    @docu = !@task.document.nil? ? @task.document : nil
  end


  #To find shared folders,docs,tasks
  def find_manage_real_estate_shared_folders(find_deleted_folders)
	  @show_deleted = (params[:del_files] == 'true') ? true : false
		conditions =  @show_deleted == true ?   "" : "and is_deleted = false"
    conditions = find_deleted_folders == 'true' ? "and is_deleted = true" : conditions
    #.............................shared folders collection .........................
    s = SharedFolder.find(:all,:conditions=>["user_id = ? ",current_user.id]).collect{|sf| sf.folder_id}
    fs = Folder.find(:all,:conditions=>["id in (?) and parent_id not in (?) #{conditions} and (real_estate_property_id is NOT NULL or parent_id = -1 )",s,s]).collect{|f| f.id}
    @shared_folders_real_estate = SharedFolder.find(:all,:conditions=>["user_id = ? and folder_id in (?) and (is_property_folder != 1 || is_property_folder is null)",current_user.id,fs])
    shared_docs_ids = s.empty? ? SharedDocument.find(:all,:conditions=>["user_id = ? ",current_user.id]).collect{|sd| sd.document_id}   : SharedDocument.find(:all,:conditions=>["user_id = ? and folder_id not in (?)",current_user.id,s]).collect{|sd| sd.document_id}
    @shared_folders_real_estate = @shared_folders_real_estate.collect{|sf| sf.folder if sf.folder.real_estate_property.user_id != current_user.id && sf.folder.portfolio.user_id != current_user.id}.compact
    #.............................shared docs collection .........................
    documents_ids = Document.find(:all,:conditions=>["id in (?) #{conditions} and real_estate_property_id is NOT NULL ",shared_docs_ids]).collect{|d| d.id}
    shared_docs = shared_docs_ids.empty? ? SharedDocument.find(:all,:conditions=>["user_id = ? and document_id in (?)",current_user.id,documents_ids]) :  s.empty? ? SharedDocument.find(:all,:conditions=>["user_id = ? and document_id in (?)",current_user.id,documents_ids]) : SharedDocument.find(:all,:conditions=>["user_id = ? and folder_id not in (?) and document_id in (?)",current_user.id,s,documents_ids])
    @shared_docs_real_estate = shared_docs.reject{|sd|  sd.document.document_name !=nil && !is_filename_shared_to_the_user(sd.document.document_name.id,sd.user_id).empty?}
   	@shared_docs_real_estate = @shared_docs_real_estate.collect{|sd| sd.document if sd.folder && sd.folder.real_estate_property.user_id != current_user.id && sd.folder.portfolio.user_id != current_user.id}.compact
    #.............................shared tasks collection .........................
    shared_task_ids = TaskCollaborator.find(:all,:conditions=>["user_id = ? ",current_user.id]).collect{|t| t.task.id}
    shared_tasks = Task.find(:all,:conditions=>["folder_id not in (?) and (temp_task != 1) and id in (?)",s,shared_task_ids])  if !s.empty?
    shared_tasks = Task.find(:all,:conditions=>["(temp_task != 1) and id in (?)",shared_task_ids])  if s.empty?
    @shared_tasks_real_estate = shared_tasks.nil? ? [] : shared_tasks.collect{|t| t if t.folder && t.folder.real_estate_property.user_id != current_user.id && t.folder.portfolio.user_id != current_user.id}.compact.uniq
		return   @shared_folders_real_estate,@shared_docs_real_estate,@shared_tasks_real_estate
	end

  #to find past shared folders
  def find_past_shared_folders(find_deleted_folders)
    params[:asset_id] =@folder.id
 		conditions = find_deleted_folders == 'true' ?   "" : "and is_deleted = false"
    find_manage_real_estate_shared_folders('false')  if @folder.name == 'my_files' && @folder.parent_id == 0
    #to find folders,tasks,files shared to user ,then user shares that to some others
    folder_ids = (@shared_folders_real_estate && !@shared_folders_real_estate.empty?) ? @shared_folders_real_estate.collect{|f| f.id} :  []
    doc_ids = (@shared_docs_real_estate && !@shared_docs_real_estate.empty?) ? @shared_docs_real_estate.collect{|f| f.id} :  []
    task_ids =  (@shared_tasks_real_estate && !@shared_tasks_real_estate.empty?) ? @shared_tasks_real_estate.collect{|f| f.id} :  []
    #To find shared folders
    fids_in_cur_folder = Folder.find(:all,:conditions=>["(parent_id = ? or id in (?)) #{conditions}",params[:asset_id],folder_ids]).collect{|f| f.id}
    @folders = SharedFolder.find(:all,:conditions=>["sharer_id = ? and folder_id in (?) and user_id != sharer_id",current_user.id,fids_in_cur_folder]).collect{|sf| sf.folder}.uniq
    #To find shared documents
    docids_in_cur_folder = Document.find(:all,:conditions=>["(folder_id = ? or id in (?)) #{conditions}",params[:asset_id],doc_ids]).collect{|d| d.id}
    @documents  = SharedDocument.find(:all,:conditions=>["sharer_id = ? and document_id in (?) and user_id != sharer_id",current_user.id,docids_in_cur_folder]).collect{|sd| sd.document}.uniq
    #To find shared tasks
    tasks_in_cur_folder = Task.find(:all,:conditions=>["(folder_id = ? or id in (?)) and (temp_task != 1)",params[:asset_id],task_ids]).collect{|d| d.id}
    @tasks  = TaskCollaborator.find(:all,:conditions=>["sharer_id = ? and task_id in (?) and user_id != sharer_id",current_user.id,tasks_in_cur_folder]).collect{|st| st.task}.uniq
    return @folders,@documents,@tasks
  end




  #....................................To display breadcrumb ....................................................................................................................
  def breadcrump_display_asset_manager_real_estate(folder,event)
    @from_event = event == 'true' ? 'true' : 'false'
    portfolio_folder = Folder.find_by_portfolio_id_and_parent_id(folder.portfolio_id,-1) if folder
    pid = params[:portfolio_id] ? params[:portfolio_id]  :  params[:pid]
    portfolio_folder = Folder.find_by_portfolio_id_and_parent_id(pid,-1) if (params[:portfolio_id] || params[:pid] )
    if folder && portfolio_folder.nil?
      breadcrump_display_my_files_asset_manager_real_estate(folder)
    else
      arr =[]
      i = 0
      #--------------------------------------------loop to find shared/own folders start----------------------------------------------------------------
      while !folder.nil?  && params[:parent_delete] != "true"
        property_folder  = Folder.find_by_real_estate_property_id_and_parent_id_and_is_master(folder.real_estate_property_id,0,0)
        img = folder == property_folder ? "" :  "<div class='setupiconrow'><img border='0' width='16' height='16' src='/images/folder.png'></div>"
        #------------------------------------------to find path folder strucure/shared items------------------------------------------------------------
        find_path_for_breadcrumb(folder)
        #--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if (request.env['HTTP_REFERER'] &&  request.env['HTTP_REFERER'].include?('properties') && request.env['HTTP_REFERER'].include?('real_estate'))
          tmp_name = "#{img}<div class='setupheadactvelabel'>#{@path}</div>"
          name = (i == 0) ? "#{img}<div class='setupheadlabel'>#{truncate_extra_chars(folder.name)}</div>" :  "#{tmp_name}"
          arr << name
        elsif portfolio_folder
          if folder.name != portfolio_folder.name
            tmp_name = "#{img}<div class='setupheadactvelabel'>#{@path}</div>"
            name = (i == 0) ? "#{img}<div class='setupheadlabel'>#{truncate_extra_chars(folder.name)}</div>" :  "#{tmp_name}"
            arr << name     if  !is_folder_shared_to_current_user(folder.id).nil?  || folder.user_id == current_user.id
          end
        end
        folder = Folder.find(:first,:conditions=> ["id = ?",folder.parent_id])
        i += 1
      end
      #-------------------------------------------loop ends-------------------------------------------------------------------------------------------------------------
      #............................................To display portfolios/my files&tasks in breadcrumb-------------------------------------------

      if !(request.env['HTTP_REFERER'] &&  request.env['HTTP_REFERER'].include?('properties') && request.env['HTTP_REFERER'].include?('real_estate')) || params[:parent_delete] == "true"
        prop_link = @folder && @folder.parent_id == -1 || (@folder.nil?) ? "<font color='#222222'>#{portfolio_folder.name}</font>" : "<a href='' onclick=\"load_writter();new Ajax.Request('/properties/show_asset_files?folder_id=#{portfolio_folder.id}&pid=#{portfolio_folder.portfolio.id}');load_completer();return false;\">#{portfolio_folder.name}</a>"  if portfolio_folder
        #..................................to find shared property folders ......................................
        shared_property_folders = []
        portfolio_folder.portfolio.real_estate_properties.each do |p|
          p_folder  = Folder.find_by_real_estate_property_id_and_parent_id(p.id,0)
          if @folder && @folder.parent_id != -1
            shared_property_folders << SharedFolder.find_by_folder_id_and_user_id_and_real_estate_property_id(p_folder.id,current_user.id,@folder.real_estate_property_id) if p_folder
          else
            shared_property_folders << SharedFolder.find_by_folder_id_and_user_id(p_folder.id,current_user.id) if p_folder
          end
        end
        #...................................................................................................................................
        if portfolio_folder  && (portfolio_folder.user_id != current_user.id)  && shared_property_folders.compact.empty?
          arr << "<div class='setupheadactvelabel'><a href='' onclick=\"show_collaboration_overview();change_color('overview_tab');return false;\">My Files & Tasks</a></div>"
        end
        if (portfolio_folder && !shared_property_folders.compact.empty?) ||  portfolio_folder.user_id == current_user.id
          arr << "<div class='setupheadactvelabel'><a href='' onclick=\"show_collaboration_overview();change_color('overview_tab');return false;\">My Files & Tasks</a>
      <img width='10' height='9' style='margin-top: -3px;' src='/images/eventsicon2.png'>&nbsp;#{prop_link}
</div>"
        end
      end
      #.............................................................................................................................................................................
      return arr.reverse.join("<div class='setupiconrow3' style='margin-right:0px;'><img width='10' height='9' src='/images/eventsicon2.png' style='margin-top:-3px;'></div>")
    end
	end


  #............................................To find path of the breadcrumb......................................
  def  find_path_for_breadcrumb(folder)
    @path = params[:show_past_shared] == 'true' ? "<a href='' onclick=\"load_writter();show_shared_items('#{folder.id}','#{folder.portfolio_id}');load_completer();return false;\">#{truncate_extra_chars(folder.name)}</a>" : @from_event == 'true' ?  "<a href='' onclick=\"load_writter();show_events('#{folder.id}');load_completer();return false;\">#{truncate_extra_chars(folder.name)}</a>" :        "<a href='' onclick=\"load_writter();new Ajax.Request('/properties/show_asset_files?folder_id=#{folder.id}&pid=#{folder.portfolio_id}');load_completer();return false;\">#{truncate_extra_chars(folder.name)}</a>"
    return @path
  end


  #............................................To display breadcrump for my files ..........................................................................
  def breadcrump_display_my_files_asset_manager_real_estate(folder)
    arr =[]
		i = 0
		while !folder.nil?
      #................................................To find path ..............................................................
      find_path_for_breadcrumb(folder)
      #..................................................................................................................................
      if folder.name == "my_files" && folder.parent_id == 0 && find_manage_real_estate_shared_folders('false').flatten.index(folder) == 'nil'
        name2 =  ""
        tmp_name = "<div class='setupheadactvelabel'><a href='' onclick=\"load_writter();show_collaboration_overview();change_color('overview_tab');return false;load_completer();return false;\">#{name2}</a></div>"
      else
        if folder.name == "my_files" && folder.parent_id == 0
          tmp_name = "<div class='setupheadactvelabel'><a href='' onclick=\"load_writter();show_collaboration_overview();change_color('overview_tab');return false;load_completer();return false;\">My Files & Tasks</a></div>"
        else
          tmp_name = "<div class='setupiconrow'><img border='0' width='16' height='16' src='/images/folder.png'></div><div class='setupheadactvelabel'>#{@path}</div>"
        end
      end
      name = (i == 0) ? "#{(params[:action] != 'view_events_folder' && params[:show_past_shared] != 'true') ? "<div class='setupiconrow'><img width='16' height='16' src='/images/folder.png'></div>" : ""}<div class='setupheadlabel'>#{truncate_extra_chars(folder.name == "my_files" && folder.parent_id == 0 ? 'My Files & Tasks' : folder.name)}</div>" :  "#{tmp_name}"
      # name = (i == 0) ? "<div class='setupheadlabel'>#{truncate_extra_chars(folder.name == "my_files" && folder.parent_id == 0 ? 'My Files & Tasks' : folder.name)}</div>" :  "#{tmp_name}"
      arr << name if check_is_folder_shared(folder) == 'true' || folder.user_id == current_user.id  ||  (name2 && name2 == 'My Files & Tasks' )
      if find_manage_real_estate_shared_folders('false').flatten.index(folder) && (folder.name != "my_files" &&  folder.parent_id != 0)
        tmp_name = "<div class='setupheadactvelabel'><a href='' onclick=\"load_writter();show_collaboration_overview();change_color('overview_tab');return false;load_completer();return false;\">My Files & Tasks</a></div>"
        arr 	<<   "<div class='setupheadlabel'>#{tmp_name}</div>"
      end
			folder = Folder.find(:first,:conditions=> ["id = ?",folder.parent_id])
			i += 1
		end
		return arr.reverse.join("<div class='setupiconrow3' style='margin-top: 3px;'><img width='10' height='9' src='/images/eventsicon2.png' ></div>")
  end
  def find_by_parent_id_and_name(folder_id, templates)
    return Folder.find_by_parent_id_and_name(folder_id, templates)
  end
  
  def find_user_name(id)
    user = User.find_by_id(id)
    user_name = user.name? ? lengthy_word_simplification(user.name, 5, 10) :  lengthy_word_simplification(user.email, 5, 10)
    return user_name
  end

  def find_user_name_without_lengthy_word(id)
    user = User.find_by_id(id)
    user_name = user.name? ? lengthy_word_simplification(user.name, 10,20) :  lengthy_word_simplification(user.email,10,20)
    return user_name
  end


  def display_owner_or_co_owner(obj)
    if obj.user_id == current_user.id && ((@past_shared_folders && @past_shared_folders.index(obj)) || (@past_shared_docs && @past_shared_docs.index(obj)) || (@past_shared_tasks && @past_shared_tasks.index(obj)))
      "<span><img src='/images/owner.png' border='0' /></span>"
    elsif  obj.user_id != current_user.id
      "<span><img src='/images/co_owner.png' border='0' /></span>"
    end 
  end  
  
  def check_if_doc_variance_task(doc_id)
    doc = Document.find_by_id(doc_id)
    return doc.variance_task if !doc.nil?
  end
  
  def find_document_id(id)
    return Document.find_by_id(id)
  end
  
  def find_first_property(port)
    if port.user_id == current_user.id
      property = RealEstateProperty.find(:first, :conditions=>["portfolio_id = ? and property_name !='property_created_by_system' ",port.id], :order=>"portfolio_id desc")    
      return property
    else
      if port.user_id != current_user.id
        shared_folders = SharedFolder.find(:all, :conditions => ["real_estate_property_id in (?) and is_property_folder = ? and user_id = ?",port.real_estate_properties.collect{|i| i.id},true,current_user.id])
        properties = shared_folders.collect{|sf| sf.folder.real_estate_property}
        if properties
          return properties.first
        end
      end
    end
  end


  def find_by_user_id_and_name(id,my_files)
    return Folder.find_by_user_id_and_name(current_user.id,my_files)
  end
  
  
  def find_portfolios_to_display_in_collabhub
  	@portfolios = []
    @real_estate_properties = []
		@user = current_user
		@updated_properties = RealEstateProperty.find(:all, :conditions => ["user_id = ?",current_user.id], :order => "created_at desc, last_updated desc", :limit=>"4")
		@real_estate_properties = RealEstateProperty.find(:all, :conditions => ["user_id = ?",current_user.id], :select => "portfolio_id,id", :order => "created_at desc, last_updated desc")
		#@portfolios = Portfolio.find(:all, :conditions => ["id in (?)",@real_estate_properties.collect {|x| x.portfolio_id}]).reverse if !(@real_estate_properties.nil? || @real_estate_properties.blank?) this line is commented since portfolio is displayed as user perspective not with property
		@portfolios = Portfolio.find(:all, :conditions => ["user_id = ? and portfolio_type_id = 2",current_user.id])
		#@portfolios = current_user.portfolios.find(:all, :conditions => ["id in (?)",@real_estate_properties.collect {|x| x.portfolio_id}],:limit=>5) if !(@real_estate_properties.nil? || @real_estate_properties.blank?)
		@shared_folders = Folder.find_by_sql("SELECT * FROM folders WHERE id IN (SELECT folder_id FROM shared_folders WHERE is_property_folder =1 AND user_id = #{current_user.id })")
		@portfolios += Portfolio.find(:all, :conditions => ["id in (?)",@shared_folders.collect {|x| x.portfolio_id}]) if !(@shared_folders.nil? || @shared_folders.blank?)
    @real_estate_properties += RealEstateProperty.find(:all, :conditions => ["id in (?)",@shared_folders.collect {|x| x.real_estate_property_id}], :select => "portfolio_id,id") if !(@shared_folders.nil? || @shared_folders.blank?)
  end
  
  
	#To find the subfolders and documents inside a folder and to permanently delete the same
	def delete_files_and_docs_of_folder(folder_id, loop_starts)
		folders = Folder.find(:all,:conditions=> ["parent_id = ?",folder_id])
		parent_folder = Folder.find_by_id(folder_id)
		if parent_folder !=nil && parent_folder.property != nil
      if parent_folder.parent_id == 0 && !parent_folder.is_master
        parent_folder.property.destroy
      end
		end 
		@folder_s = [ ] if (@folder_s.nil? || @folder_s.empty? || loop_starts)
		@doc_s = [ ] if (@doc_s.nil? || @doc_s.empty? || loop_starts)
		folders.each do |f|							       
			delete_files_and_docs_of_folder(f.id, false)	
			@folder_s << f
			f.destroy
			f.documents.destroy_all
		end
	end
  
  def find_shared_property_folders
    shared_property_folders = []
    portfolio_folder.portfolio.real_estate_properties.each do |p|
      p_folder  = Folder.find_by_real_estate_property_id_and_parent_id(p.id,0)
      if @folder && @folder.parent_id != -1
        shared_property_folders << SharedFolder.find_by_folder_id_and_user_id_and_real_estate_property_id(p_folder.id,current_user.id,@folder.real_estate_property_id)
      else
        shared_property_folders << SharedFolder.find_by_folder_id_and_user_id(p_folder.id,current_user.id)
      end
    end
  end
     
  def find_user_has_properties
    @real_estate_properties = RealEstateProperty.find(:all, :conditions => ["user_id = ? and property_name != 'property_created_by_system'",current_user.id])
    @real_estate_properties += RealEstateProperty.find_by_sql("SELECT * FROM real_estate_properties WHERE id in (SELECT real_estate_property_id FROM shared_folders WHERE is_property_folder = 1 AND user_id = #{current_user.id} )")
  end
  
  
  def display_due_date(t,recent_date)
		date = "#{recent_date.class != Date ? '' : recent_date.strftime('%b %d')}"
    return  "<div class='action_label1' title='#{t.task.task_type.task_name.split(" ")[0]}'>#{t.task.task_type.task_name.split(" ")[0].slice(0,7)}</div><div class='action_label1'><img src='/images/timer_small_icon.png' width='16' height='16' border='0'/></div><div class='action_label2'> #{date} </div>"
  end

  def fetch_req_physical_property_folder(note_id)
    p = RealEstateProperty.find(note_id)
    f = Folder.find(:first,:conditions=>['real_estate_property_id =? and portfolio_id = ? and name = ?',p.id,p.portfolio_id,'Property Pictures'])
    a = f.nil? ? p.id : f.id
    return a
  end

  def display_task_collaborators(t)
    task_collabs = [ ]  
    t.task_collaborators.each do |c|
      if !c.user.nil?
        task_collabs << (!c.user.name.blank? ? c.user.name : c.user.email)
      end
    end
    return task_collabs.uniq.join(",")
  end 

  def display_task_collaborators_files_n_tasks(t)
    len = t.task_collaborators.count
    if len > 1
      if !t.task_collaborators.first.user.nil?
        task_collabs_txt = (!t.task_collaborators.first.user.name.blank? ? t.task_collaborators.first.user.name : t.task_collaborators.first.user.email)
        task_collabs_txt += " & #{len-1} others"
      end
    else
      task_collabs_txt = ""
    end
    return task_collabs_txt
  end  


  def modify_folder_name(folder)
    if folder.name == 'my_files' && folder.parent_id == 0
      "My Files & Tasks"
    else
      folder.name
    end
  end
 
  def financial_occupancy_claculation(v1,v2,v3)
    return v1.abs - v2.abs - v3.abs
  end

  def financial_vacancy_calculation(v1,v2)
    return v1 + v2
  end
  
  #Financial occupancy percentage calculations
  def financial_occupancy_percentage_calculation(v1,v2,v3)
    return ((v1.to_f.abs - v2.to_f.abs - v3.to_f.abs)/v1.to_f.abs).nan? ? 0 : ((v1.to_f.abs - v2.to_f.abs - v3.to_f.abs)/v1.to_f.abs)
  end
  
  #Financial vacancy percentage calculations
  def financial_vacancy_percentage_calculation(v1,v2,v3)
    return 100 - financial_occupancy_percentage_calculation(v1,v2,v3)
  end

  def find_property_folder_by_property_id(property)
    property_folder  = Folder.find_by_real_estate_property_id_and_parent_id_and_is_master(property.id,0,0)
  end
  
  def  find_summary_comments(commentable_id,commentable_type,is_reply)
    Comment.find(:all, :conditions=> ["commentable_id = ? and commentable_type = ? and is_reply = ?", commentable_id,commentable_type, is_reply])
  end
  
  def find_added_scondary_files
    @folder = Folder.find_by_id(params[:folder_id]) if params[:folder_id]
    @property_folder  = Folder.find_by_real_estate_property_id_and_parent_id_and_is_master(@folder.real_estate_property_id,0,0)
    @monthly_report_folder = Folder.find_by_name("Report Docs",:conditions=>["real_estate_property_id = #{@folder.real_estate_property.id} and parent_id = #{@property_folder.id} and is_master = 1"])
    @added_secondary_files = Document.find_all_by_folder_id(@monthly_report_folder.id,:order=>["created_at desc"]) if @monthly_report_folder
  end
    
  def  find_task_collaborators(t)
    members = t.collaborators.collect{|c| c if c != current_user}
    owner= User.find_by_email(t.user.email)
    members << owner if owner && owner != current_user
    if current_user.has_role?("Shared User") && session[:role] == 'Shared User'
      user = t.user
      members <<  user if user != current_user
    end
    return members.compact
  end
    
	def check_is_task_shared(d)
		sd = TaskCollaborator.find_by_task_id(d.id,:conditions=>["user_id = ? or sharer_id =?",current_user.id,current_user.id],:select=>'id')
		if sd.nil? && d.user_id != current_user.id
			return "false"
		else
			return "true"
		end
	end	
    
end
