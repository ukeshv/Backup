module AssetsHelper

	# To find all folders to be listed - called from assign_initial_options
	def listing_folders(f_options)
    @folders = Folder.find(:all,f_options)
    @document_names = [ ]
    @documents = [ ]
  end
	
	# To find all folders,documents and document names of a folder to be listed - called from assign_options with is_deleted,portfolio_id
	def listing_sub_folders(f_options,d_options,dn_options)
    if current_user.has_role?("Shared User") && session[:role] == 'Shared User'
		  f_options = "user_id = #{current_user.id} and folder_id = #{params[:folder_id]}"
			d_options = "user_id = #{current_user.id} and folder_id = #{params[:folder_id]}"
		  @folders = SharedFolder.find(:all,f_options).collect {|sf| sf.folder}
		  @documents = SharedDocument.find(:all,d_options).collect {|sd| sd.document}
		else 
  	  @folders = Folder.find(:all,f_options)
	  	documents = Document.find(:all,d_options)
			@documents = documents.reject{|d|  d.document_name !=nil }
		end
		@document_names = DocumentName.find(:all,dn_options)		
		return @folders,@document_names,@documents
 	end

	#To find the subfolders and documents inside a folder and to update the is_deleted field based on Delete/Undelete
 	def files_and_docs_of_folder(folder_id, loop_starts,fn)
		folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted = ?",folder_id,!fn])
		@folder_s = [ ] if (@folder_s.nil? || @folder_s.empty? || loop_starts)
		@doc_s = [ ] if (@doc_s.nil? || @doc_s.empty? || loop_starts)		
		folders.each do |f|
      @sub_shared_folders << SharedFolder.find(:all,:conditions=>['folder_id = ?',f.id]).flatten
			@sub_shared_docs << SharedDocument.find_all_by_folder_id(f.id).flatten
			@sub_shared_docs.flatten.each do |sub_shared_doc|
  				is_folder_shared = SharedFolder.find_by_folder_id(sub_shared_doc.folder_id,:conditions=>["user_id = ?",sub_shared_doc.user_id])
	  			@sub_shared_docs_collection << sub_shared_doc if is_folder_shared.nil?
			end	
			@sub_shared_folders.flatten.each do |sub_shared_folder|
  				is_parent_folder_shared = SharedFolder.find_by_folder_id(sub_shared_folder.folder.parent_id,:conditions=>["user_id = ?",sub_shared_folder.user_id])
	  			@sub_shared_folders_collection << sub_shared_folder if is_parent_folder_shared.nil?
				end	
  		files_and_docs_of_folder(f.id, false,fn)	
			@folder_s << f
			f.update_attributes(:is_deleted=>fn)
			f.documents.update_all(:is_deleted=>fn)
		end
	end
 	

	
	#To check if missing files are present for a folder or not - Called from partials/assets_list
	def check_missing_files(fid)
    docname_files= DocumentName.find(:all,:conditions=>["is_deleted = ? and folder_id = ? and is_master = ? and property_id is not NULL and due_date is not NULL and document_id is NULL",false,fid,0])
		doc_files = Document.find(:all,:conditions=>["is_deleted = ? and folder_id = ? and is_master = ? and property_id is not NULL and due_date is NOT NULL",false,fid,0])				
		missing_files = docname_files + doc_files
    is_missing_files = missing_files.empty? ? "no" : "yes"
		return is_missing_files
  end
	
	#To download the all files and sub files and sub folders of a folder as zip file
  def dwn_fld(folder_id,zipfile)
		@folder = Folder.find_by_id(folder_id,true)
		zipfile.mkdir("#{@folder.name}")
		recursive_function(folder_id,zipfile,"#{@folder.name}")
	end

	#To find the all files and sub files and sub folders of a folder
	def recursive_function(folder_id,zipfile,location)
		if @nav && @nav == 'edit'
			folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id])
			documents = Document.find(:all,:conditions=> ["folder_id = ? and is_deleted=false",folder_id])
		else
			folders = Folder.find(:all,:conditions=> ["parent_id = ? and is_deleted=false",folder_id])
			documents = Document.find(:all,:conditions=> ["folder_id = ? and is_deleted=false",folder_id])
    end
		folders.each do |f|
			zipfile.mkdir("#{location}/#{f.name}")
			recursive_function(f.id,zipfile,"#{location}/#{f.name}")
		end
		documents.each do |f|
			zipfile.add("#{location}/#{f.filename}","#{RAILS_ROOT}/public#{f.public_filename}")
		end
	end

	#To check if a folder is shared to any
	def check_is_folder_shared(f)
		sf = SharedFolder.find_by_folder_id(f.id,:conditions=>["user_id = ? or sharer_id =?",current_user.id,current_user.id],:select=>'id')  
		if sf.nil? && f.user_id != current_user.id
			return "false"
		else
			return "true"
		end
	end
 
 #To check if a document is shared to any
	def check_is_doc_shared(d)
		sd = SharedDocument.find_by_document_id(d.id,:conditions=>["user_id = ? or sharer_id =?",current_user.id,current_user.id],:select=>'id')
		if sd.nil? && d.user_id != current_user.id
			return "false"
		else
			return "true"
		end
	end	

	#To check if a document name is shared to any
	def check_is_doc_name_shared(d)
   sdn = ShareDocumentName.find_by_document_name_id(d.id,:conditions=>["user_id = ? or sharer_id =?",current_user.id,current_user.id],:select=>'id')
	   if sdn.nil? && d.user_id != current_user.id
			 return "false"
		else
			return "true"
   end
	end	


def is_show_deleted(t)
	if  t.is_deleted == true && params[:del_files] == "true"
	     return true		
	elsif t.is_deleted == true && params[:del_files] != "true"
		return false
	else
     return true		
	end	
end

def find_manage_notes_shared_folders
	  @show_deleted = (params[:del_files] == 'true') ? true : false	
		conditions =  @show_deleted == true ?   "" : "and is_deleted = false"
     s = SharedFolder.find(:all,:conditions=>["user_id = ? ",current_user.id]).collect{|sf| sf.folder_id}
     fs = Folder.find(:all,:conditions=>["id in (?) and parent_id not in (?) #{conditions} and property_id is NOT NULL",s,s]).collect{|f| f.id}
     s_folders = SharedFolder.find(:all,:conditions=>["user_id = ? and folder_id in (?) ",current_user.id,fs])
		 folders = s_folders.collect {|sf| sf.folder}.uniq
		return   folders
	end
	
	
end