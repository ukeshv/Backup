module CollaborationHubHelper

	def task_display(task)
		@due_days = []
		task.each do |i|
			if !(i.due_by.nil? || i.due_by.blank?)
				@due_days << i.due_by.to_date
			end
		end
		return @due_days.min
	end
	
	def task_color(task)
		@due_days = []
		task.each do |i|
			if !(i.due_by.nil? || i.due_by.blank?)
				@due_days << i.due_by.to_date
			end
		end
		if @due_days.min < Date.today
			return "red"
		else
			return "green"
		end
	end
	
	def find_my_folders_files_tasks
		@portfolio = Portfolio.find_by_name_and_user_id("portfolio_created_by_system",current_user.id)
		@folder = Folder.find_by_name_and_parent_id_and_user_id('my_files',0,current_user.id)
		if params[:del_files] == "true"	
		@folders= Folder.find_all_by_parent_id(@folder.id)
		@documents = Document.find_all_by_folder_id(@folder.id)
  	else
  	@folders= Folder.find_all_by_parent_id_and_is_deleted(@folder.id,false)
		@documents = Document.find_all_by_folder_id_and_is_deleted(@folder.id,false)
	end
   @tasks = Task.find_all_by_folder_id_and_temp_task(@folder.id,false)
	 if params[:show_past_shared] == "true"
		if !params[:folder_id] || params[:document_id]
		  params[:asset_id] =@folder.id
		else
      params[:asset_id] =@folder.parent_id
    end
     find_past_shared_folders('false')
	 end
	end

  def find_by_user_id_and_name(id,my_files)
    return Folder.find_by_user_id_and_name(current_user.id,my_files)
  end
		 
		
end
