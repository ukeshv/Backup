module DispositionsHelper
	def proof_doc(user, note)
		proof_document = ProofDocument.find(:last, :conditions=>["user_id = ? && resource_id = ? && resource_type = ?", user.id, note.id, 'Property'])
	end
end
