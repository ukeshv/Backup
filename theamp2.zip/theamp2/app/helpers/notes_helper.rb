module NotesHelper
	def note_image(note_id)
		image = Document.find(:first,:conditions =>  ["is_deleted = ? and property_id=? and (content_type LIKE LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?))", false,"#{note_id}",  "%%image/%%", "%%.jpg%%", "%%.gif%%", "%%.png%%", "%%.bmp%%", "%%.jpeg%%"])
		return image.nil? ? '/images/property.jpg' : image.public_filename
	end
 
 	def find_note_images(note_id)
		@images = Document.find(:all,:conditions =>  ["is_deleted = ? and property_id=? and (content_type LIKE LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?))", false,"#{note_id}",  "%%image/%%", "%%.jpg%%", "%%.gif%%", "%%.png%%", "%%.bmp%%", "%%.jpeg%%"])
		return @images.nil? ? '/images/property.jpg' : @images
	end
 
 
	def get_folder_of_notes(note_id,portfolio_id)
		return Folder.find(:first,:conditions=>['parent_id = ? and portfolio_id = ? and property_id = ? and user_id = ?',0,portfolio_id,note_id,current_user.id]).id		
	end 
 
end
