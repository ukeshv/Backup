module OccupanciesHelper

  #added to parse occupancy and leasing excel file
  def import_occupancy_and_leasing_details(oo)
    month,year=oo.cell(1,1).month,oo.cell(1,1).year if !oo.cell(1,1).nil? && oo.cell(1,1).class == Date
    row,head_row,column=9,7,1
    title_and_column={}
    title=["unit","sf","tenant","spacetype","termstart","termend","baserate","effectiverate","ti's","lc's","options/comments"]
    while column <= oo.last_column
      if  !oo.cell(head_row,column).nil? && !oo.cell(head_row,column).downcase.match(/(months)/)
        if oo.cell(head_row,column).downcase.gsub(' ','')=="dateexecuted" or oo.cell(head_row,column).downcase.gsub(' ','')=="leasedate" 
          title_and_column.store("dateexecuted",column)
        elsif title.include?(oo.cell(head_row,column).downcase.gsub(' ',''))
          title_and_column.store(oo.cell(head_row,column).downcase.gsub(' ','').gsub("'s","s").gsub('/',''),column)
        end
      end
      column=column+1
    end
    suites = PropertySuite.find_all_by_real_estate_property_id(@prop_id).map(&:id)
    PropertyLease.delete_all(['month = ? and year = ? and property_suite_id IN (?) ', month, year, suites] ) if !suites.nil? and !suites.empty?
    PropertyOccupancySummary.delete_all(['real_estate_property_id = ? and month = ? and year = ?',@prop_id, month, year])
    while(row <=oo.last_row) do
      if !oo.cell(row,1).nil? and oo.cell(row,1).class == String and !(["total expiry","total new","total renewal","total future commencements","occupancy statistics"].include?(oo.cell(row,1).downcase.strip))
        occupancy_type,property_id,row=oo.cell(row,1).downcase.strip,@prop_id,row+1
        while(row <=oo.last_row) do
          if !oo.cell(row,3).nil?
            prop_suite = PropertySuite.find(:all, :conditions=>['real_estate_property_id = ? and suite_number = ? and space_type = ?', @prop_id,oo.cell(row,title_and_column["unit"]).to_s.gsub('.0', ''),oo.cell(row,title_and_column["spacetype"]).downcase])
            prop_suite=prop_suite[0] unless prop_suite.blank?
            prop_suite=PropertySuite.create(:real_estate_property_id=>@prop_id,:suite_number=>oo.cell(row,title_and_column["unit"]).to_s.gsub('.0', ''),:rented_area=>oo.cell(row,title_and_column["sf"]),:space_type=>oo.cell(row,title_and_column["spacetype"]).downcase) if prop_suite.blank?
            prop_lease=PropertyLease.create(:property_suite_id=>prop_suite.id,:tenant=>oo.cell(row,title_and_column["tenant"]),:start_date=>oo.cell(row,title_and_column["termstart"]),:end_date=>oo.cell(row,title_and_column["termend"]),:base_rent=>oo.cell(row,title_and_column["baserate"]),:effective_rate=>oo.cell(row,title_and_column["effectiverate"]),:tenant_improvements=>oo.cell(row,title_and_column["tis"]),:leasing_commisions=>oo.cell(row,title_and_column["lcs"]),:comments=>oo.cell(row,title_and_column["optionscomments"]),:date_executed=>oo.cell(row,title_and_column["dateexecuted"]),:occupancy_type=>occupancy_type, :month=>month, :year=>year) if prop_suite
          end
          break if oo.cell(row,1).class == String && oo.cell(row,2).nil?
          row=row+1
        end
      elsif !oo.cell(row,1).nil? && oo.cell(row,1).class == String && oo.cell(row,1).downcase.strip=="occupancy statistics"
        for new_row in row..oo.last_row
          for col in 1..2
            if !oo.cell(new_row,col).nil? && oo.cell(new_row,col).class == String
              if oo.cell(new_row, col).downcase.match(/building rentable square feet/)
                up_col = find_column_for_sum_value(new_row,col+1,oo)
                prop_occup_summary=PropertyOccupancySummary.create(:month=>month,:year=>year,:total_building_rentable_s=>oo.cell(new_row,up_col),:real_estate_property_id=>@prop_id)
              elsif oo.cell(new_row, col).downcase.match(/sf occupied as of/)
                if oo.cell(new_row+1, col).nil?
                  up_col = find_column_for_sum_value(new_row,col+1,oo)
                  prop_occup_summary.update_attributes(:last_year_sf_occupied_actual=>oo.cell(new_row,up_col),:last_year_sf_occupied_budget=>oo.cell(new_row,up_col+1))
                elsif  oo.cell(new_row+1, col).downcase.match(/occupancy/)
                  up_col = find_column_for_sum_value(new_row,col+1,oo)
                  prop_occup_summary.update_attributes(:current_year_sf_occupied_actual=>oo.cell(new_row,up_col),:current_year_sf_occupied_budget=>oo.cell(new_row,up_col+1))
                end 
              elsif  oo.cell(new_row, col).downcase.match(/sf occupied/)
                if oo.cell(new_row+1, col).downcase.match(/occupancy/)
                  up_col = find_column_for_sum_value(new_row,col+1,oo)
                  prop_occup_summary.update_attributes(:current_year_sf_occupied_actual=>oo.cell(new_row,up_col),:current_year_sf_occupied_budget=>oo.cell(new_row,up_col+1))  
                end  
              elsif oo.cell(new_row, col).downcase.match(/sf vacant/)
                up_col = find_column_for_sum_value(new_row,col+1,oo)
                prop_occup_summary.update_attributes(:current_year_sf_vacant_actual=>oo.cell(new_row,up_col),:current_year_sf_vacant_budget=>oo.cell(new_row,up_col+1))
              elsif oo.cell(new_row,col).downcase.match(/new leases/)
                up_col = find_column_for_sum_value(new_row,col+1,oo)
                prop_occup_summary.update_attributes(:new_leases_actual=>oo.cell(new_row,up_col),:new_leases_budget=>oo.cell(new_row,up_col+1))
              elsif oo.cell(new_row,col).downcase.match(/renewals/)
                up_col = find_column_for_sum_value(new_row,col+1,oo)
                prop_occup_summary.update_attributes(:renewals_actual=>oo.cell(new_row,up_col),:renewals_budget=>oo.cell(new_row,up_col+1))
              elsif oo.cell(new_row,col).downcase.match(/expirations/)
                up_col = find_column_for_sum_value(new_row,col+1,oo)
                prop_occup_summary.update_attributes(:expirations_actual=>oo.cell(new_row,up_col),:expirations_budget=>oo.cell(new_row,up_col+1))
              end
            end
          end
          row=new_row
        end
      end
      row=row+1
    end
    update_expiration_new_renewal(month,year)
	end
  
  def  find_column_for_sum_value(new_row,col,oo)
    while(oo.cell(new_row,col).nil?)
      col =col +1
    end 
    return col
  end 
  
  #added to parse occupancy and leasing excel file
  def update_expiration_new_renewal(month,year)
    total_new=PropertySuite.find_by_sql("SELECT sum(property_suites.rented_area) as total_new FROM `property_suites`, property_leases WHERE property_leases.month=#{month} and property_leases.year=#{year} and property_leases.occupancy_type='new' and property_leases.property_suite_id=property_suites.id and property_suites.real_estate_property_id=#{@prop_id};")
    total_expiration=PropertySuite.find_by_sql("SELECT sum(property_suites.rented_area) as total_expiration FROM `property_suites`, property_leases WHERE property_leases.month=#{month} and property_leases.year=#{year} and property_leases.occupancy_type='expirations' and property_leases.property_suite_id=property_suites.id and property_suites.real_estate_property_id=#{@prop_id};")
    total_renewal=PropertySuite.find_by_sql("SELECT sum(property_suites.rented_area) as total_renewal FROM `property_suites`, property_leases WHERE property_leases.month=#{month} and property_leases.year=#{year} and property_leases.occupancy_type='renewal' and property_leases.property_suite_id=property_suites.id and property_suites.real_estate_property_id=#{@prop_id}")
    prop_occup_summary=PropertyOccupancySummary.find_by_real_estate_property_id(@prop_id)
    prop_occup_summary.update_attributes(:new_leases_actual=>total_new[0].total_new,:renewals_actual=>total_renewal[0].total_renewal,:expirations_actual=>total_expiration[0].total_expiration) if prop_occup_summary
  end
  
  #added to parse debt summary excel file
  def import_debt_summary(oo)
    date = oo.cell(7,1).split(" ") if !oo.cell(7,1).nil? && oo.cell(7,1).class == String
    month,year = Date::MONTHNAMES.index(date[0].capitalize), date[1].to_i unless date.blank?
    if month.nil? and year.nil?
      time=Time.now
      month,year=time.month,time.year
    end
    row,start_title=1,["category", "description"]
    PropertyDebtSummary.delete_all(['real_estate_property_id = ? and month = ? and year = ? ', @prop_id, month, year])
    while row <= oo.last_row
      unless oo.cell(row,1).nil?
        if oo.cell(row,1).class == String && oo.cell(row,2).class == String && start_title.include?(oo.cell(row,1).downcase.strip) && start_title.include?(oo.cell(row,2).downcase.strip)
          new_row=row+1
          while !oo.cell(new_row,1).nil?
            if oo.cell(new_row,1).delete(":").downcase != "borrower"
             PropertyDebtSummary.create(:real_estate_property_id=>@prop_id, :category=>oo.cell(new_row,1).delete(":"), :description=>oo.cell(new_row,2), :month=>month, :year=>year)
            end
            new_row=new_row+1
          end
          flag="completed"
        end
      end
      row=row+1
      break if flag=="completed"
    end
  end
end
