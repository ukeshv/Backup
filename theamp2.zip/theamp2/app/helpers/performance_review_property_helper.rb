module PerformanceReviewPropertyHelper

  # Hash formation in listing details in Performance review lease page
	def lease_details(month=nil, year=nil)	
		@month = month
		@year = year
		@explanation = true
		if !month.nil? 
			month,year = month.to_i,year.to_i 
			@prop_occup_summary=PropertyOccupancySummary.find(:all, :conditions=>['month = ? and year = ? and real_estate_property_id = ?', month, year, @note.id]) if !@note.nil? && !month.nil? && !year.nil?
			@comments = LeasesExplanation.find(:all, :conditions =>["month = ? and year = ? and real_estate_property_id = ?",month, year, @note.id]).collect{|s| [s.occupancy_type,s.explanation,s.id,s.user_id]} if !@note.nil? && !month.nil? && !year.nil?
		else
      year = Date.today.year if year.nil?
      os= PropertyOccupancySummary.find(:all,:conditions => ["year=? and real_estate_property_id=? and month <= ?",year,@note.id,Date.today.last_month.month],:order => "month desc",:limit =>1)
      @prop_occup_summary = os if !os.nil? and !os.empty?
    end
		@time_line_actual  = IncomeAndCashFlowDetail.find(:all,:conditions => ["resource_id =? and resource_type=? ",@note.id, 'RealEstateProperty'])		
		@actual = @time_line_actual 
		unless @prop_occup_summary.blank? 
			@prop_occup_summary = @prop_occup_summary.first 
      change_occupancy_actual=@prop_occup_summary.new_leases_actual.to_f - @prop_occup_summary.expirations_actual.to_f
      change_occupancy_budget=@prop_occup_summary.new_leases_budget.to_f - @prop_occup_summary.expirations_budget.to_f
      current_occup_pecent_actual=((@prop_occup_summary.current_year_sf_occupied_actual.to_f/(@prop_occup_summary.current_year_sf_occupied_actual.to_f+@prop_occup_summary.current_year_sf_vacant_actual).to_f)*100).round
      current_occup_pecent_budget=((@prop_occup_summary.current_year_sf_occupied_budget.to_f/(@prop_occup_summary.current_year_sf_vacant_budget.to_f+@prop_occup_summary.current_year_sf_occupied_budget).to_f)*100).round
      current_vacant_pecent_actual=((@prop_occup_summary.current_year_sf_vacant_actual.to_f/(@prop_occup_summary.current_year_sf_occupied_actual.to_f+@prop_occup_summary.current_year_sf_vacant_actual).to_f)*100).round
      current_vacant_pecent_budget=((@prop_occup_summary.current_year_sf_vacant_budget.to_f/(@prop_occup_summary.current_year_sf_vacant_budget.to_f+@prop_occup_summary.current_year_sf_occupied_budget).to_f)*100).round
      @leases={:renewals=>{:actual=>@prop_occup_summary.renewals_actual,:budget=>@prop_occup_summary.renewals_budget},
        :new_leases=>{:actual=>@prop_occup_summary.new_leases_actual,:budget=>@prop_occup_summary.new_leases_budget},
        :expirations=>{:actual=>@prop_occup_summary.expirations_actual,:budget=>@prop_occup_summary.expirations_budget},
        :change_in_occupancy=>{:actual=>change_occupancy_actual,:budget=>change_occupancy_budget},
        :last_year_occupancy=>{:actual=>@prop_occup_summary.last_year_sf_occupied_actual,:budget=>@prop_occup_summary.last_year_sf_occupied_budget},
        :current_occupancy_percent=>{:actual=>current_occup_pecent_actual,:budget=>current_occup_pecent_budget},
        :current_vacant_percent=>{:actual=>current_vacant_pecent_actual,:budget=>current_vacant_pecent_budget},
        :current_occupancy=>{:actual=>@prop_occup_summary.current_year_sf_occupied_actual, :budget=>@prop_occup_summary.current_year_sf_occupied_budget},
        :current_vacant=>{:actual=>@prop_occup_summary.current_year_sf_vacant_actual, :budget=>@prop_occup_summary.current_year_sf_vacant_budget}}
    end
  end
			
	#lease details for wres
	def wres_lease_details(month=nil,year=nil)
		@month = month
		@year = year
		@explanation = true
		if !month.nil? 
			month,year = month.to_i,year.to_i 
			@prop_occup_summary=PropertyOccupancySummary.find(:all, :conditions=>['month = ? and year = ? and real_estate_property_id = ?', month, year, @note.id]) if !@note.nil? && !month.nil? && !year.nil?
			@comments = LeasesExplanation.find(:all, :conditions =>["month = ? and year = ? and real_estate_property_id = ?",month, year, @note.id]).collect{|s| [s.occupancy_type,s.explanation]} if !@note.nil? && !month.nil? && !year.nil?
		else
			year = Date.today.year if year.nil? 
			os= PropertyOccupancySummary.find(:all,:conditions => ["year=? and real_estate_property_id=? and month <= ?",year,@note.id,Date.today.last_month.month],:order => "month desc",:limit =>1)	
			@prop_occup_summary = os if !os.nil? and !os.empty?			
		end	
		@time_line_actual  = IncomeAndCashFlowDetail.find(:all,:conditions => ["resource_id =? and resource_type=? ",@note.id, 'RealEstateProperty'])		
		@actual = @time_line_actual 
		unless @prop_occup_summary.blank? 
			@prop_occup_summary = @prop_occup_summary.first
			@wres_leases = {
        :current_vacancy=>{:units=>@prop_occup_summary.currently_vacant_leases_number.abs,
          :sqft=>((@prop_occup_summary.total_building_rentable_s * @prop_occup_summary.currently_vacant_leases_percentage)/100).round,
          :percent=>@prop_occup_summary.currently_vacant_leases_percentage },
        :vacant_leased=>{:units=>@prop_occup_summary.vacant_leased_number.abs,
          :sqft=>((@prop_occup_summary.total_building_rentable_s * @prop_occup_summary.vacant_leased_percentage)/100).round,
          :percent=>@prop_occup_summary.vacant_leased_percentage },
        :occupied_on_notice=>{:units=>@prop_occup_summary.occupied_on_notice_number.abs,
          :sqft=>((@prop_occup_summary.total_building_rentable_s * @prop_occup_summary.occupied_on_notice_percentage)/100).round,
          :percent=>@prop_occup_summary.occupied_on_notice_percentage },
        :occupied_preleased=>{:units=>@prop_occup_summary.	occupied_preleased_number.abs,
          :sqft=>((@prop_occup_summary.total_building_rentable_s * @prop_occup_summary.occupied_preleased_percentage)/100).round,
          :percent=>@prop_occup_summary.occupied_preleased_percentage },
        :net_exposure_to_vacancy=>{:units=>@prop_occup_summary.net_exposure_to_vacancy_number.abs,
          :sqft=>((@prop_occup_summary.total_building_rentable_s * @prop_occup_summary.net_exposure_to_vacancy_percentage)/100).round,
          :percent=>@prop_occup_summary.net_exposure_to_vacancy_percentage }
			}
			titles = [:current_vacancy, :vacant_leased, :occupied_on_notice, :occupied_preleased, :net_exposure_to_vacancy]
			titles.each { |title| (@wres_leases[title][:percent] == 0.0 ) ? @wres_leases[title][:percent] = 0 : ''}
		end
	end
	# Hash formation in listing details in Performance review lease sub page	
	def lease_sub_details(month, year, occupancy_type)
		term_cdn = ""
		sort = " "
		if params[:sort]
			if params[:sort].match(/time_diff/) 
				term_cdn = " if( pl.end_date - CURDATE() < 0,0,pl.end_date - CURDATE()) as time_diff, "
				sort = "ORDER BY "+params[:sort]+","+"pl.tenant asc"
			else
				sort = !params[:sort].nil? ? "ORDER BY "+params[:sort] : ""
			end
    end
		if !month.nil?
			@sub_leases = PropertyLease.find_by_sql("SELECT ps.rented_area as rented_area,ps.suite_number as suite_number,pl.tenant,#{term_cdn} pl.effective_rate,pl.end_date,pl.tenant_improvements, pl.leasing_commisions FROM `property_leases` pl INNER JOIN property_suites ps ON pl.property_suite_id = ps.id WHERE (	pl.month = #{month} AND pl.year = #{year} AND pl.occupancy_type = '#{occupancy_type}'  AND ps.real_estate_property_id = #{@note.id}) #{sort};")	if !month.nil? && !year.nil? && !occupancy_type.nil?
		else
			@suites = PropertySuite.find(:all, :conditions=>['real_estate_property_id = ?', @note.id]).map(&:id) if !@note.nil?
			month = PropertyLease.find(:all, :conditions=>['property_suite_id IN (?) and year=? ',@suites,year], :select=>"month").map(&:month).max if !@suites.blank?
			@sub_leases = PropertyLease.find_by_sql("SELECT ps.rented_area as rented_area,ps.suite_number as suite_number,pl.tenant,#{term_cdn} pl.effective_rate,pl.end_date,pl.tenant_improvements, pl.leasing_commisions FROM `property_leases` pl INNER JOIN property_suites ps ON pl.property_suite_id = ps.id WHERE (	pl.month = #{month} AND pl.year = #{year} AND pl.occupancy_type = '#{occupancy_type}'  AND ps.real_estate_property_id = #{@note.id}) #{sort};") if !month.nil? && !year.nil? && !occupancy_type.nil?
		end
		@sub_leases = @sub_leases.paginate :page => params[:page], :per_page => 10 if !@sub_leases.blank?
	end

  # Method to calculate the total area 
	def get_total_area(lease_areas)
		total_area = 0
		lease_areas.each do |lease_area|
			total_area =total_area+lease_area.to_i if lease_area
		end
		return total_area 
	end
	
	# Method to get the remaining term details
	def get_term_remaining(end_date)
		team_remaining = ((end_date - Date.today)/30).round if !end_date.nil?
		if !team_remaining.nil? && team_remaining > 0
			team_remaining.to_s+" Months"
		elsif !team_remaining.nil? && team_remaining == 0
      (end_date - Date.today).to_i > 0 ? "1 Month" : "-"
		else
			"-"
		end
	end
	
	# Weighted average calculation for the lease sub page
	def get_weighted_data(data1,data2)
		total = 0
		if data1.length == data2.length
			for i in 0..data1.length
				total = total + data1[i].to_f * data2[i].to_f if !data1[i].nil? && !data2[i].nil? 
			end
			return (total/get_total_area(data1)).to_f
		end
	end
	
	# Hash formation for the calculation in the occupancy
  def form_hash_of_data_for_occupancy(actuals,budget)
    val ={:actuals =>actuals,:budget =>budget}
    variant = val[:budget].to_f.abs-val[:actuals].to_f.abs
    percent = variant*100/val[:budget].to_f.abs rescue ZeroDivisionError
    if  val[:budget].to_f==0
      percent = ( val[:actuals].to_f == 0 ? 0 : -100 )
    end
    percent=0.0 if percent.to_f.nan?
    val[:percent] = percent
    val[:variant] =  variant
    val[:status] = true
    return val
	end
	
	#This method is used to calculate debt service for a particular month
	def debt_service_for_month
		@explanation = true
		@debt_services = PropertyDebtSummary.find(:all,:conditions => ["real_estate_property_id =? and month =? and year =? and (LOWER(category) = ? or LOWER(category) =? or LOWER(category =?))",@note.id, @tl_month, @tl_year, 'maturity', 'loan amount', 'loan balance'], :select=>['category, description,id'],:group=>'category')	
	end
	
	#This method is used to calculate debt service for Year To Date
	def debt_service_for_ytd
		@debt_services = []
	  last_month = PropertyDebtSummary.find(:first,:conditions =>["real_estate_property_id =? and year =?",@note.id,@tl_year], :order=> "month desc")
		if last_month
			@debt_services << PropertyDebtSummary.find(:first,:conditions => ["real_estate_property_id =? and month =? and year =? and (LOWER(category) = ?)",@note.id, last_month.month, @tl_year, 'maturity'], :select=>['category,description,id'])	
			@debt_services << PropertyDebtSummary.find(:first,:conditions => ["real_estate_property_id =? and month =? and year =? and (LOWER(category) = ? )",@note.id, last_month.month, @tl_year, 'loan amount'], :select=>['category,description,id'])	
			@debt_services << PropertyDebtSummary.find(:first,:conditions => ["real_estate_property_id =? and month =? and year =? and (LOWER(category) = ? )",@note.id, last_month.month, @tl_year,'loan balance'], :select=>['category,description,id'])	
		end
	end	
	
	#This method is used to calculate debt service for Last Year
	def debt_service_for_last_year
		year_de = Date.today.last_year.year
	  last_month = PropertyDebtSummary.find(:first,:conditions =>["real_estate_property_id =? and year =?",@note.id,year_de], :order=> "month desc")
		if last_month
			@debt_services = PropertyDebtSummary.find(:all,:conditions => ["real_estate_property_id =? and month =? and year =? and (LOWER(category) = ? or LOWER(category) =? or LOWER(category =?))",@note.id, last_month.month, year_de, 'maturity', 'loan amount', 'loan balance'], :select=>['category, description,id'])	
		end
	end		
	
	# Capital expenditure calculation for the month in performance review page
	def capital_expenditure_month(month=nil,year=nil)
		if params["start_date"]#=>"2010-09-01"
      sd = params["start_date"].split('-')
      tl_month,tl_year = sd[1].to_i,sd[0].to_i
		else	
      tl_month = params[:tl_month].nil? ? Date.today.month : params[:tl_month].to_i
      tl_year = params[:tl_year].nil? ? Date.today.year : params[:tl_year].to_i
      @explanation = true
		end	
		month_qry=1
		pci = PropertyCapitalImprovement.find(:first,:conditions => ["year=? and real_estate_property_id=?",tl_year,params[:id]],:order => "month desc")
		month_qry = pci.month if !pci.nil?
		@record_list_de = pci
		
		month_details = ['', 'january','february','march','april','may','june','july','august','september','october','november','december']
    qry_tenant_act = "SELECT SUM(pf.#{month_details[tl_month]}) AS value, ci.id as id
                FROM property_suites AS ps, property_capital_improvements AS ci, property_financial_periods AS pf
                WHERE
                  ps.real_estate_property_id = #{params[:id]} AND
	                ps.id = ci.property_suite_id AND
	                ci.month = #{month_qry} AND
                  ci.year = #{tl_year} AND
	                ci.category ='TENANT IMPROVEMENTS' AND
	                pf.source_id = ci.id  AND
	                pf.pcb_type = 'c' AND
	                pf.source_type = 'PropertyCapitalImprovement' group by ci.year;"
    qry_tenant_bud = qry_tenant_act.sub('\'c\'','\'b\'')
    qry_leasing_act = qry_tenant_act.sub('\'TENANT IMPROVEMENTS\'', '\'LEASING COMMISSIONS\'')
    qry_leasing_bud = qry_leasing_act.sub('\'c\'','\'b\'')

    qry_building_act = "SELECT SUM(pf.#{month_details[tl_month]}) AS value, tci.id as id
                          FROM property_capital_improvements AS tci, property_financial_periods AS pf
                          WHERE tci.real_estate_property_id = #{params[:id]} AND
                          tci.year= #{tl_year} AND
                          tci.month = #{month_qry} AND
                          tci.category = 'BUILDING IMPROVEMENTS' AND
                          tci.id = pf.source_id AND
                          pf.source_type = 'PropertyCapitalImprovement' AND
                          pf.pcb_type = 'c' group by tci.year;"
    qry_building_bud = qry_building_act.sub('\'c\'','\'b\'')
    qry_lease_act = qry_building_act.sub('\'BUILDING IMPROVEMENTS\'', '\'LEASE COSTS\'')
    qry_lease_bud = qry_lease_act.sub('\'c\'','\'b\'')
    @cap_exp = OpenStruct.new
    @cap_exp.tenant_imp_actual = PropertyCapitalImprovement.find_by_sql(qry_tenant_act).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_tenant_act).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_tenant_act).first.blank?)
		if !(PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.blank?)
			@cap_exp.tenant_imp_budget = PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.value 
			@cap_exp.tenant_imp_id = PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.id
		end
		if !(PropertyCapitalImprovement.find_by_sql(qry_leasing_act).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_leasing_act).first.blank?)
			@cap_exp.leasing_comm_actual = PropertyCapitalImprovement.find_by_sql(qry_leasing_act).first.value
			@cap_exp.leasing_comm_id = PropertyCapitalImprovement.find_by_sql(qry_leasing_act).first.id
		end		
    @cap_exp.leasing_comm_budget = PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).first.blank?)
		if !(PropertyCapitalImprovement.find_by_sql(qry_building_act).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_building_act).first.blank?)
      @cap_exp.building_imp_actual = PropertyCapitalImprovement.find_by_sql(qry_building_act).first.value
      @cap_exp.building_imp_id = PropertyCapitalImprovement.find_by_sql(qry_building_act).first.id
		end
    @cap_exp.building_imp_budget = PropertyCapitalImprovement.find_by_sql(qry_building_bud).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_building_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_building_bud).first.blank?)
		if !(PropertyCapitalImprovement.find_by_sql(qry_lease_act).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_lease_act).first.blank?)
      @cap_exp.lease_cost_actual = PropertyCapitalImprovement.find_by_sql(qry_lease_act).first.value
      @cap_exp.lease_cost_id = PropertyCapitalImprovement.find_by_sql(qry_lease_act).first.id
		end
    @cap_exp.lease_cost_budget = PropertyCapitalImprovement.find_by_sql(qry_lease_bud).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_lease_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_lease_bud).first.blank?)
		
		
		@cap_exp.month = tl_month
    @time_line_start_date = Date.new(2010,1,1) # time line test
		#@time_line_end_date = Date.new(2010,12,31) # time line test
		@time_line_end_date = Date.today.end_of_month
  end
	
	# Capital expenditure calculation for the year to date in performance review page
	def capital_expenditure_year
    id = !params[:id].nil? ? params[:id]  : @portfolio.id 
		if params["start_date"]#=>"2010-09-01"
      sd = params["start_date"].split('-')
      tl_month,tl_year = sd[1].to_i,sd[0].to_i
		else	
      tl_month = params[:tl_month].nil? ? Date.today.month : params[:tl_month].to_i
      tl_year =  Date.today.year #params[:tl_year].nil? ? Date.today.year : params[:tl_year].to_i
			@explanation = true
		end	
		month_details = ['', 'january','february','march','april','may','june','july','august','september','october','november','december']
		last_month = Date.today.last_month.month
		arr = []
		for m in 1..last_month
			arr << "IFNULL(pf.#{month_details[m]},0)"
		end			
		val = arr.join("+")
		month_qry=1
		pci = PropertyCapitalImprovement.find(:first,:conditions => ["year=? and real_estate_property_id=?",tl_year,id],:order => "month desc")
		month_qry = pci.month if !pci.nil?
		

		@record_list_de = pci
    qry_tenant_act = "SELECT SUM(#{val}) AS value, ci.id as id
                FROM property_suites AS ps, property_capital_improvements AS ci, property_financial_periods AS pf
                WHERE
                  ps.real_estate_property_id = #{id} AND
	                ps.id = ci.property_suite_id AND
	                ci.month = #{month_qry} AND
                  ci.year = #{tl_year} AND
	                ci.category ='TENANT IMPROVEMENTS' AND
	                pf.source_id = ci.id  AND
	                pf.pcb_type = 'c' AND
	                pf.source_type = 'PropertyCapitalImprovement' group by ci.year;"
    qry_tenant_bud = qry_tenant_act.sub('\'c\'','\'b\'')
    qry_leasing_act = qry_tenant_act.sub('\'TENANT IMPROVEMENTS\'', '\'LEASING COMMISSIONS\'')
    qry_leasing_bud = qry_leasing_act.sub('\'c\'','\'b\'')

    qry_building_act = "SELECT SUM(#{val}) AS value, tci.id as id
                          FROM property_capital_improvements AS tci, property_financial_periods AS pf
                          WHERE tci.real_estate_property_id = #{id} AND
                          tci.year= #{tl_year} AND
                          tci.month = #{month_qry} AND
                          tci.category = 'BUILDING IMPROVEMENTS' AND
                          tci.id = pf.source_id AND
                          pf.source_type = 'PropertyCapitalImprovement' AND
                          pf.pcb_type = 'c' group by tci.year;"
    qry_building_bud = qry_building_act.sub('\'c\'','\'b\'')
    qry_lease_act = qry_building_act.sub('\'BUILDING IMPROVEMENTS\'', '\'LEASE COSTS\'')
    qry_lease_bud = qry_lease_act.sub('\'c\'','\'b\'')
    @cap_exp = OpenStruct.new		
		
    @cap_exp.tenant_imp_actual = PropertyCapitalImprovement.find_by_sql(qry_tenant_act).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_tenant_act).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_tenant_act).first.blank?)
    @cap_exp.tenant_imp_budget = PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.blank?)
		@cap_exp.tenant_imp_id = PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.id if !(PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.blank?)
		
    @cap_exp.leasing_comm_actual = PropertyCapitalImprovement.find_by_sql(qry_leasing_act).first.value if !( PropertyCapitalImprovement.find_by_sql(qry_leasing_act).first.nil? ||  PropertyCapitalImprovement.find_by_sql(qry_leasing_act).first.blank?)
    @cap_exp.leasing_comm_budget = PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).first.blank?)
		@cap_exp.leasing_comm_id = PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).first.id if !(PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).first.blank?)
		
    @cap_exp.building_imp_actual = PropertyCapitalImprovement.find_by_sql(qry_building_act).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_building_act).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_building_act).first.blank?)
    @cap_exp.building_imp_budget = PropertyCapitalImprovement.find_by_sql(qry_building_bud).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_building_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_building_bud).first.blank?)
		@cap_exp.building_imp_id = PropertyCapitalImprovement.find_by_sql(qry_building_bud).first.id if !(PropertyCapitalImprovement.find_by_sql(qry_building_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_building_bud).first.blank?)
		
    @cap_exp.lease_cost_actual = PropertyCapitalImprovement.find_by_sql(qry_lease_act).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_lease_act).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_lease_act).first.blank?)
    @cap_exp.lease_cost_budget = PropertyCapitalImprovement.find_by_sql(qry_lease_bud).first.value if !(PropertyCapitalImprovement.find_by_sql(qry_lease_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_lease_bud).first.blank?)
		@cap_exp.lease_cost_id = PropertyCapitalImprovement.find_by_sql(qry_lease_bud).first.id if !(PropertyCapitalImprovement.find_by_sql(qry_lease_bud).first.nil? || PropertyCapitalImprovement.find_by_sql(qry_lease_bud).first.blank?)
		
    @time_line_start_date = Date.new(2010,1,1) # time line test
		#@time_line_end_date = Date.new(2010,12,31) # time line test
		@time_line_end_date = Date.today.end_of_month
  end	
	
  # Capital expenditure calculation for the last year in performance review page
	def capital_expenditure_last_year
    id = !params[:id].nil? ? params[:id]  : @portfolio.id 
		if params["start_date"]#=>"2010-09-01"
      sd = params["start_date"].split('-')
      tl_month,tl_year = sd[1].to_i,sd[0].to_i
		else	
      tl_month = params[:tl_month].nil? ? Date.today.month : params[:tl_month].to_i
      tl_year =  Date.today.last_year.year #params[:tl_year].nil? ? Date.today.year : params[:tl_year].to_i
			@explanation = true
		end	
		month_details = ['', 'january','february','march','april','may','june','july','august','september','october','november','december']
		last_month = Date.today.last_month.month
		arr = []
		for m in 1..12
			arr << "IFNULL(pf.#{month_details[m]},0)"
		end			
		val = arr.join("+")
		month_qry=1
		pci = PropertyCapitalImprovement.find(:first,:conditions => ["year=? and real_estate_property_id=?",tl_year,id],:order => "month desc")
		month_qry = pci.month if !pci.nil?
		

		@record_list_de = pci
    qry_tenant_act = "SELECT SUM(#{val}) AS value
                FROM property_suites AS ps, property_capital_improvements AS ci, property_financial_periods AS pf
                WHERE
                  ps.real_estate_property_id = #{id} AND
	                ps.id = ci.property_suite_id AND
	                ci.month = #{month_qry} AND
                  ci.year = #{tl_year} AND
	                ci.category ='TENANT IMPROVEMENTS' AND
	                pf.source_id = ci.id  AND
	                pf.pcb_type = 'c' AND
	                pf.source_type = 'PropertyCapitalImprovement' group by ci.year;"
    qry_tenant_bud = qry_tenant_act.sub('\'c\'','\'b\'')
    qry_leasing_act = qry_tenant_act.sub('\'TENANT IMPROVEMENTS\'', '\'LEASING COMMISSIONS\'')
    qry_leasing_bud = qry_leasing_act.sub('\'c\'','\'b\'')

    qry_building_act = "SELECT SUM(#{val}) AS value
                          FROM property_capital_improvements AS tci, property_financial_periods AS pf
                          WHERE tci.real_estate_property_id = #{id} AND
                          tci.year= #{tl_year} AND
                          tci.month = #{month_qry} AND
                          tci.category = 'BUILDING IMPROVEMENTS' AND
                          tci.id = pf.source_id AND
                          pf.source_type = 'PropertyCapitalImprovement' AND
                          pf.pcb_type = 'c' group by tci.year;"
    qry_building_bud = qry_building_act.sub('\'c\'','\'b\'')
    qry_lease_act = qry_building_act.sub('\'BUILDING IMPROVEMENTS\'', '\'LEASE COSTS\'')
    qry_lease_bud = qry_lease_act.sub('\'c\'','\'b\'')
    @cap_exp = OpenStruct.new		
		
    @cap_exp.tenant_imp_actual = PropertyCapitalImprovement.find_by_sql(qry_tenant_act).first.value if !PropertyCapitalImprovement.find_by_sql(qry_tenant_act).empty?
    @cap_exp.tenant_imp_budget = PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).first.value if !PropertyCapitalImprovement.find_by_sql(qry_tenant_bud).empty?
    @cap_exp.leasing_comm_actual = PropertyCapitalImprovement.find_by_sql(qry_leasing_act).first.value if !PropertyCapitalImprovement.find_by_sql(qry_leasing_act).empty?
    @cap_exp.leasing_comm_budget = PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).first.value if !PropertyCapitalImprovement.find_by_sql(qry_leasing_bud).empty?
    @cap_exp.building_imp_actual = PropertyCapitalImprovement.find_by_sql(qry_building_act).first.value if !PropertyCapitalImprovement.find_by_sql(qry_building_act).empty?
    @cap_exp.building_imp_budget = PropertyCapitalImprovement.find_by_sql(qry_building_bud).first.value if !PropertyCapitalImprovement.find_by_sql(qry_building_bud).empty?
    @cap_exp.lease_cost_actual = PropertyCapitalImprovement.find_by_sql(qry_lease_act).first.value if !PropertyCapitalImprovement.find_by_sql(qry_lease_act).empty?
    @cap_exp.lease_cost_budget = PropertyCapitalImprovement.find_by_sql(qry_lease_bud).first.value if !PropertyCapitalImprovement.find_by_sql(qry_lease_bud).empty?
    @time_line_start_date = Date.new(2010,1,1) # time line test
		#@time_line_end_date = Date.new(2010,12,31) # time line test
		@time_line_end_date = Date.today.end_of_month
  end	
		
	# Performance review financial sub page Link formation for the Text in the display
	def subpages_in_financial_review(heading,rec_id = nil)
		title = heading
		a = {"Operating Revenue"  => "income detail" , "Op.Revenue" => "income detail","Op.Expenses"=>"Operating Expenses"}
		title_display = {"Op.Revenue" => "Operating Revenue","Op.Expenses"=>"Operating Expenses"}
		title = a[title] if !a[title].nil?
		if rec_id.nil?
      record = IncomeAndCashFlowDetail.find(:first,:conditions => ["title=? and resource_id=?",title,@note.id])
		else
      record = IncomeAndCashFlowDetail.find_by_id(rec_id)
    end 
		query = IncomeAndCashFlowDetail.find(:all,:conditions => ["parent_id =?",record.id],:select => "count(*) as childers") if record
		title = title.gsub("'","?")
		financial_subid = (record.nil?) ? '' :  record.id
    if (query and query.first.childers and query.first.childers.to_i > 0)
			return "<a  onclick=\"performanceReviewCalls('financial_subpage',{financial_sub:\'#{title}\', financial_subid: #{financial_subid} });return false;\" href=\"#\" title='#{title_display[heading].nil? ? heading.titlecase : title_display[heading]}'>#{display_truncated_chars(title_display[heading].nil? ? heading.titlecase : heading,30,true)} </a>"
		elsif heading == "Operating Expenses" || title == "Operating Expenses"
			return "<a  onclick=\"performanceReviewCalls('financial_subpage',{financial_sub:\'#{title}\'});return false;\" href=\"#\" title='#{title_display[heading].nil? ? heading.titlecase : title_display[heading]}'>#{display_truncated_chars(title_display[heading].nil? ? heading.titlecase : heading,30,true)} </a>"
		else
			return  "<span title='#{title_display[heading].nil? ? heading.titlecase : title_display[heading]}'>#{display_truncated_chars(title_display[heading].nil? ? heading.titlecase : heading,30,true)}</span>"
		end
	end	
	
	
	def wres_subpages_in_financial_expenses(heading,rec_id = nil)
		title = heading
		a = {"Operating Revenue"  => "income detail" }
		title = a[title] if !a[title].nil?
		if rec_id.nil?
      record = IncomeAndCashFlowDetail.find(:first,:conditions => ["title=? and resource_id=?",title,@note.id])
		else
      record = IncomeAndCashFlowDetail.find_by_id(rec_id)
    end 
		query = IncomeAndCashFlowDetail.find(:all,:conditions => ["parent_id =?",record.id],:select => "count(*) as childers") if record
		title = title.gsub("'","?")
		financial_subid = (record.nil?) ? '' :  record.id
		if (query and query.first.childers and query.first.childers.to_i > 0) 
			return "<a  onclick=\"performanceReviewCalls('financial_subpage',{financial_sub:\'#{title}\', financial_subid: #{financial_subid} });return false;\" href=\"#\" title='#{heading.capitalize}'>#{display_truncated_chars(heading.capitalize,30,true)} </a>" 
		elsif 	 heading == "Operating Expenses"
			return "<a  onclick=\"performanceReviewCalls('financial_subpage',{financial_sub:\'#{title}\'});return false;\" href=\"#\" title='#{heading.capitalize}'>#{display_truncated_chars(heading.capitalize,30,true)} </a>" 
		else
			return  "<span title='#{heading.capitalize}'>#{display_truncated_chars(heading.capitalize,30,true)}</span>"
		end	
  end
	
	
	
	# Performance review financial sub page for month calculation
	def calculate_the_financial_sub_graph_for_month(month,year)
		@month = month
		#year = (!params[:tl_year].nil?  and !params[:tl_year].blank?)  ? params[:tl_year].to_i : Date.today.last_month.month  
		@ytd= []
		@ytd << "IFNULL(f."+Date::MONTHNAMES[month.to_i].downcase+",0)"	
    params[:financial_sub] = params[:financial_sub].gsub("?","\'") if params[:financial_sub]
		if params[:financial_sub] and params[:financial_sub] == "Operating Expenses"
      qry = "select  Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(child_id) as Record_id from (SELECT  a.title as Title, f.pcb_type, #{@ytd.join("+")}  as actuals, 0 as budget,a.id as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'	UNION 	SELECT  a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")}  as budget,0 as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'		) xyz group by  Title"
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
		elsif params[:financial_subid]
      @using_sub_id = true
      qry = get_query_for_financial_sub_page(params[:financial_subid],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
		else	
      qry = get_query_for_financial_sub_page(params[:financial_sub],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
    end
    @explanation = true
	end	
	
	# Performance review financial sub page for year-to-date calculation
	def calculate_the_financial_sub_graph(year=nil)
		#year = (!params[:tl_year].nil?  and !params[:tl_year].blank?)  ? params[:tl_year].to_i : Date.today.last_month.month  
		year_to_date= Date.today.last_month.month
		@ytd= []
		for m in 1..year_to_date
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
		end		
    params[:financial_sub] = params[:financial_sub].gsub("?","\'") if params[:financial_sub]
		if params[:financial_sub] and params[:financial_sub] == "Operating Expenses"
      qry = "select  Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(child_id) as Record_id from (SELECT  a.title as Title, f.pcb_type, #{@ytd.join("+")}  as actuals, 0 as budget,a.id as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'	UNION 	SELECT  a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")}  as budget,0 as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'		) xyz group by  Title"
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
		elsif params[:financial_subid]
      @using_sub_id = true
      qry = get_query_for_financial_sub_page(params[:financial_subid],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
		else	
      qry = get_query_for_financial_sub_page(params[:financial_sub],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
    end		
		@explanation = true
	end	
	
	# Performance review financial sub page for last year calculation
	def calculate_the_financial_sub_graph_for_last_year(year=nil)	
		#year = (!params[:tl_year].nil?  and !params[:tl_year].blank?)  ? params[:tl_year].to_i : Date.today.last_month.month  
		year_to_date= Date.today.last_month.month
		@ytd= []
		for m in 1..12
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
		end		
    params[:financial_sub] = params[:financial_sub].gsub("?","\'") if params[:financial_sub]
		if params[:financial_sub] and params[:financial_sub] == "Operating Expenses"
      qry = "select  Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(child_id) as Record_id from (SELECT  a.title as Title, f.pcb_type, #{@ytd.join("+")}  as actuals, 0 as budget,a.id as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'	UNION 	SELECT  a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")}  as budget,0 as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'		) xyz group by  Title"
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
		elsif params[:financial_subid]
      @using_sub_id = true
      qry = get_query_for_financial_sub_page(params[:financial_subid],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
		else	
      qry = get_query_for_financial_sub_page(params[:financial_sub],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
    end		
		@explanation = true
	end		
	
	#Performance review financial subpage query for the calculation
	def get_query_for_financial_sub_page(parent,year)
		if  @using_sub_id
			"select  Title, sum(actuals) as Actuals, sum(budget) as Budget, sum(child_id) as Record_id from (SELECT  a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget, a.id as child_id FROM `income_and_cash_flow_details` a   inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.parent_id =#{parent} AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT  a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget, 0 as child_id FROM `income_and_cash_flow_details` a    inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.parent_id =#{parent} AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Title"
		else	
      "select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget, sum(child_id) as Record_id from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget, a.id as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN (\"#{parent}\") AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget, 0 as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN (\"#{parent}\") AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title"	
		end	
	end
  
	# Breadcrumb link display for the performance review financial subgraph
	def breadcrumb_in_financial(title,ids)		 		
		arr = []
		a = {"income detail" => "Operating Revenue"}
		arr_heading = ["income details","net operating income","capital expenditures"]
		if ids.nil?
			base = "<div class=\"executivesubheadcol\"><span class=\"executiveiconcol\"><img src=\"/images/executivehead_icon.png\" width=\"14\" height=\"16\" /></span><a href=\"#\" onclick=\"performanceReviewCalls(\\'financial\\',{});return false;\">Financials</a><img width=\"10\" height=\"9\" src=\"/images/eventsicon2.png\">&nbsp;</div><div class=\"executivesubheadcol\"><span class=\"executiveiconcol\"><img src=\"/images/executivehead_icon.png\" width=\"14\" height=\"16\" /></span>Operating Expenses &nbsp;</div>"		
		else
			income=IncomeAndCashFlowDetail.find_by_id(ids)
			while(income and  !income.parent_id.nil?)
				arr << [income.title,income.id]
				income = IncomeAndCashFlowDetail.find_by_id(income.parent_id)				
			end	
			if income
        arr << [income.title,income.id] if arr.empty?
			else
				arr = []
      end				
			base = "<div class=\"executivesubheadcol\"><span class=\"executiveiconcol\"><img src=\"/images/executivehead_icon.png\" width=\"14\" height=\"16\" /></span><a href=\"#\" onclick=\"performanceReviewCalls(\\'financial\\',{});return false;\">Financials</a><img width=\"10\" height=\"9\" src=\"/images/eventsicon2.png\">&nbsp;</div>"
      if !arr.empty?
				for ar2 in arr.reverse					
					if ar2[0] == "non-recoverable expenses detail" or  ar2[0] == "recoverable expenses detail"						
            base =  base + "<div class=\"executivesubheadcol\"><span class=\"executiveiconcol\"><img src=\"/images/executivehead_icon.png\" width=\"14\" height=\"16\" /></span><a href=\"#\" onclick=\"performanceReviewCalls(\\'financial_subpage\\',{financial_sub:\\'Operating Expenses\\'});return false;\">Operating Expenses</a><img width=\"10\" height=\"9\" src=\"/images/eventsicon2.png\">&nbsp;</div>"
					end								
				end				
			  for ar1 in arr.reverse					
					last_element = arr.first							
         	heading = 	a[ar1[0]] ? a[ar1[0]] : ar1[0]
					if ar1[1] == last_element[1]
            base =  base +"<div class=\"executivesubheadcol\"><span class=\"executiveiconcol\"><img src=\"/images/executivehead_icon.png\" width=\"14\" height=\"16\" /></span>#{heading.gsub("'","").capitalize}&nbsp;</div>"
					else
            base =  base + "<div class=\"executivesubheadcol\"><span class=\"executiveiconcol\"><img src=\"/images/executivehead_icon.png\" width=\"14\" height=\"16\" /></span><a href=\"#\" onclick=\"performanceReviewCalls(\\'financial_subpage\\',{financial_sub:\\'#{ar1[0]}\\', financial_subid: #{ar1[1]} });return false;\">#{heading.gsub("'","").capitalize}</a><img width=\"10\" height=\"9\" src=\"/images/eventsicon2.png\">&nbsp;</div>"
					end				
				end	
			end		
    end					
		return base
	end

  # Heading link formation in the capital expenditure sub page
  def find_link_to(title, id)
    nodes = IncomeAndCashFlowDetail.count(:all , :conditions=>["parent_id=#{id}"])
    if nodes == 0
      return "<span title='#{title.gsub(/\b\w/){$&.upcase}.gsub(':','')}'>&nbsp;#{display_truncated_chars(title.gsub(/\b\w/){$&.upcase}.gsub(':',''),30,true)}</span>"
    else
      return "&nbsp;<a  href=\"\" onclick=\"update_level_bread_crum2(#{id},' #{title.capitalize}'#{@par});cashSubCalls(2,{cash_find_id:'#{id}'}); return false;\" title='#{title.gsub(/\b\w/){$&.upcase}.gsub(':','')}'>#{display_truncated_chars(title.gsub(/\b\w/){$&.upcase}.gsub(':',''),30,true)}</a>"
    end
  end
	
	def wres_rent_roll_details(month=nil, year=nil)	
		@note = RealEstateProperty.find(params[:note_id])
		@month = month
		@year = year
		if !(month.nil? || month.blank?)
			@rent_roll_wres = PropertyLease.find_by_sql("SELECT ps.suite_number,ps.floor_plan,pl.tenant,ps.rented_area,pl.base_rent,pl.actual_amt_per_sqft,pl.end_date,pl.other_deposits,pl.made_ready FROM `property_leases` pl INNER JOIN property_suites ps ON pl.property_suite_id = ps.id WHERE (	pl.month = #{month} AND pl.year = #{year} AND ps.real_estate_property_id = #{@note.id}) ;")	if (!month.nil? && !(year.nil? || year.blank?))
			@rent_roll_wres = @rent_roll_wres.paginate(:page=>params[:page],:per_page=>20 ) if !(@rent_roll_wres.nil? || @rent_roll_wres.blank?)
		else
			@suites = PropertySuite.find(:all, :conditions=>['real_estate_property_id = ?', @note.id]).map(&:id) if !@note.nil?
			month = PropertyLease.find(:all, :conditions=>['property_suite_id IN (?) and year=? and month <= ?',@suites,year.to_i,Date.today.last_month.month],:select=>"month").map(&:month).max if !@suites.blank?
			@rent_roll_wres = PropertyLease.find_by_sql("SELECT ps.suite_number,ps.floor_plan,pl.tenant,ps.rented_area,pl.base_rent,pl.actual_amt_per_sqft,pl.end_date,pl.other_deposits,pl.made_ready FROM `property_leases` pl INNER JOIN property_suites ps ON pl.property_suite_id = ps.id WHERE (	pl.month = #{month} AND pl.year = #{year.to_i} AND ps.real_estate_property_id = #{@note.id}) ;") if (!month.nil? && !(year.nil? || year.blank?))
			@rent_roll_wres = @rent_roll_wres.paginate(:page=>params[:page],:per_page=>20 ) if !(@rent_roll_wres.nil? || @rent_roll_wres.blank?)
		end
	end

  def wres_find_link_to(title, id)
    nodes = PropertyCashFlowForecast.count(:all , :conditions=>["parent_id=#{id}"])
    if nodes == 0
      return "<span title='#{title}'>&nbsp;#{display_truncated_chars(title,50,true)}</span>"
    else
      return "&nbsp;<a  href=\"\" onclick=\"cashSubCalls(2,{cash_find_id:'#{id}'}); return false;\" title='#{title}'>#{display_truncated_chars(title,50,true)}</a>"
    end
  end

  def wres_and_swig_path_for_items(id, path = '')
    item = IncomeAndCashFlowDetail.find_by_id(id) # => have to be changed if calling from assign new task
    if item.parent_id.nil?
      return nil if item.title == "cash flow statement summary" || path.include?('Amortization')
      path = "#{item.title.gsub("'","")}" + path unless (item.title == "operating statement summary" || item.title == "cash flow statement summary") # => check the cash flow condition
      return '' if path.blank?
      path = path[3, path.length]
      path_itms = path.split(' > ')
      replace = {'operating income'=> 'Total Operating Revenues', 'operating expenses'=> 'Total Expenses', 'income detail'=> 'Operating Revenue', 'net operating income'=> 'Net Operating Income', 'capital expenditures'=> 'Capital Expenditures'}
      if replace.keys.include?(path_itms[0].downcase)
        path_itms[0] = replace[path_itms[0].downcase]
      elsif path_itms[0] == "Recoverable Expenses Detail" || path_itms[0] == "Non Recoverable Expenses Detail"
        path_itms.unshift("Operating Expenses")
      else
        path_itms[0] = session[:wres_user] ? 'Other Income & Expenses' : 'Cash & Receivables'
      end
      path_itms = path_itms.join(' > ')
    else
      path = " > #{item.title.titlecase.gsub("'","")}" + path
      wres_and_swig_path_for_items(item.parent_id, path)
    end
  end
	
	
  def wres_variances
    variances_find_month
  end
	
	
  def variances
		variances_find_month
  end
	
	def variances_find_month
		@portfolio = Portfolio.find(params[:portfolio_id]) if params[:portfolio_id]
		property_id = params[:note_id] ? params[:note_id] : params[:id] 
		@note = RealEstateProperty.find(property_id)
		@notes = RealEstateProperty.find(:all, :conditions =>["portfolio_id = ?",@portfolio.id])
		@period = params[:period]  ? params[:period]  : params[:tl_period] 
		@partial = 'variances'
    @time_line_start_date = Date.new(2010,1,1)
    @time_line_end_date = Date.today.end_of_month
    @default_month_and_year= 45.days.ago
		#current time period calculation
		if !params[:tl_month].nil? and !params[:tl_month].blank? and  !params[:tl_year].nil? and !params[:tl_year].blank?
			@current_time_period=Date.new(params[:tl_year].to_i,params[:tl_month].to_i,1)
		elsif params[:period] == '5' || params[:tl_period] == '5'
      @current_time_period=Date.new(Date.today.last_month.year,Date.today.last_month.month,1)
    else
	  	@current_time_period=Date.new(@default_month_and_year.year,@default_month_and_year.month,1) 
		end	
		@month_list = []
		#to find year and month start
		if params[:start_date]
		  @dates= params[:start_date].split("-")					
			variances_display(@dates[1].to_i,@dates[0].to_i)
  	elsif !params[:tl_month].nil? and !params[:tl_month].blank? and  !params[:tl_year].nil? and !params[:tl_year].blank?
			variances_display(params[:tl_month].to_i, params[:tl_year].to_i)
	  elsif params[:period] == '4' || params[:tl_period] == '4'
      year_to_date= Date.today.last_month.month
      for m in 1..year_to_date
        @month_list <<  Date.new(Time.now.year,m,1).strftime("%Y-%m-%d")
      end
			variances_display(Date.today.last_month.month,Date.today.last_month.year)	
		elsif params[:period] == '5' || params[:tl_period] == '5'
			variances_display(Date.today.last_month.month,Date.today.last_month.year)
 		elsif params[:period] == '6' || params[:tl_period] == '6'
      last_year = Date.today.last_year.year
      for m in 1..12
        @month_list <<  Date.new(last_year,m,1).strftime("%Y-%m-%d")
      end
			variances_display(12,Date.today.last_year.year)
		end
  	#to find year and month end
    #render page 
		render :update do |page|
      page << "jQuery('#time_line_selector').show();"
      page << "jQuery('.executiveheadcol_for_title').html('<div class=\"executivecol_subrow\"><span class=\"executiveiconcol\"><img width=\"14\" height=\"16\" src=\"/images/executivehead_icon.png\"></span>Variances</div>');"
      page << "jQuery('#id_for_variance_threshold').html('<ul class=inputcoll2 id=cssdropdown></ul>');"
      partial = session[:wres_user] ? "/properties/wres/variances" : "/properties/variances"
      page.replace_html "time_line_selector", :partial => "/properties/time_line_selector", :locals => {:period => @period, :note_id => @note.id, :partial_page =>partial, :start_date => 0, :timeline_start => @time_line_start_date, :timeline_end => @time_line_end_date } if params[:action] == "select_time_period" || params[:action] == "wres_select_time_period"
      page.replace_html "portfolio_overview_property_graph", :partial => "#{partial}",:locals => {:partial_page => "variances"}
      page << "jQuery('.executiveheadcol_for_title').html('<div class=\"executivecol_subrow\"><span class=\"executiveiconcol\"><img src=\"/images/executivehead_icon.png\" width=\"14\" height=\"16\" /></span>Variances</div>');"
		end		
	end	


  def variances_display(month_val=nil,year=nil)
    @month = month_val
    @year = year
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    property_folder =   Folder.find_by_real_estate_property_id_and_is_master_and_parent_id(@note.id,0,0)
    @accounts_folder =  Folder.find_by_real_estate_property_id_and_parent_id_and_name(@note.id,property_folder.id,'Accounts')
    @year_folder =  Folder.find_by_real_estate_property_id_and_parent_id_and_name(@note.id,@accounts_folder.id,year.to_s) if @accounts_folder
    excel_file_name = session[:wres_user] ? "actual_budget_analysis" : "month_budget"
    if @year_folder
      @month_folder = Folder.find_by_real_estate_property_id_and_parent_id_and_name(@note.id,@year_folder.id,months[month_val-1].to_s)
      if @month_folder && !@month_folder.documents.empty?
        @month_folder.documents.each do |d|
          if d.filename.downcase.include?(excel_file_name)  && d.is_deleted == false
            @excel_document = d
          end
        end
        if @excel_document
          @month_folder.documents.each do |d|
            if d.filename.downcase.include?(excel_file_name) && d.variance_task && d.is_deleted == false
              @variance_task_document = d
            end
          end
          if 	@variance_task_document.nil?
            @month_folder.documents.each do |d|
              if d.filename.downcase.include?(excel_file_name) && d.is_deleted == false
                @without_variance_task_document = d
              end
            end
					end		
        end
      end
    end
  end

  def swig_path_for_cap_exp_items(id)
    item = PropertyCapitalImprovement.find_by_id(id)
    "Capital Expenditure > #{item.category.titlecase.gsub("'","")} > #{item.tenant_name.titlecase.gsub("'","")}"
  end
end


