module PortfoliosHelper

	def set_validation_for_the_asset_creation
		
	end	

	def storing_function_call(data,table,property_id)		
    for ta in table
      if ta!="properties"
        model_constant =  ta.singularize.camelize.constantize
        dup_detail  = model_constant.find_by_property_id(property_id)
        if dup_detail.nil?
          d = data[table.index(ta)]
          d[:property_id]= property_id
          new_object = ta.singularize.camelize.constantize.new(d)
          new_object = save_or_update_the_record(new_object,ta,d)
        else
          dup_detail.attributes = data[table.index(ta)] #update_attributes(data[table.index(ta)])
          dup_detail = save_or_update_the_record(dup_detail,ta,data[table.index(ta)])
        end
      else
      end
    end
	end

  def save_or_update_the_record(record,table_name,attributes)
    record.valid?
    @errors_details[table_name] = record.errors.entries
    attributes= remove_invalidation_flag(table_name,attributes)
    record.attributes =attributes
    record.save
    return record
  end	
	
  def validate_for_models(table,data,property_info_id)
    e = []
		for ta in table
			record = ta.singularize.camelize.constantize.new( data[table.index(ta)])
      if !record.valid?
        record.errors.entries.each do | err|
          e << err[1]
        end
      end
		end	
    @errors[property_info_id] = e.flatten if !e.empty?
  end
	
	def heading_collection(oo)
    t = []
    for sn in 0..oo.sheets.length-1
      title=[]
      oo.default_sheet = oo.sheets[sn]
      for col in (1..oo.last_column)
        title << [oo.cell(7,col).gsub(':','').gsub("'",'').gsub("\n","").strip ,col]  if !oo.cell(7,col).nil? and !oo.cell(7,col).blank?
      end
      t << title
    end
    return t
	end	
	
  def date_value_calculation(value)
    if !value.nil? and !value.blank?
      if value.class.to_s == "Date" || value.class.to_s == "DateTime"
        value
      else
        Date.new(1899,12,30) +value.to_i
      end
    else
      ""
    end
  end
			 
	def remove_invalidation_flag(table_name,data_hash)
    validation_labels = {'properties' => ["check_note_id","check_original_note_amount","check_current_outstanding","check_late_payments_amount_due","check_current_interest_rate","check_first_payment_date","check_last_payment_date","check_maturity_date","check_comments"],
      'property_borrower_details' => ["check_company_name","check_contact_person","check_city","check_state","check_zip","check_phone_no","check_email_address","check_email_address"],
      'property_collateral_details' => ["check_property_size","check_gross_land_area","check_gross_rentable_area","check_no_of_units","check_year_built","check_property_name","check_city","check_state","check_zip","check_property_description","check_address","check_purchase_price"],
      'property_deliquency_details' => ["check_delinquency_history_30days","check_delinquency_history_60days","check_delinquency_history_90days","check_bankruptcy_status","check_foreclosure_status","check_bankruptcy_start_date","check_foreclosure_filling_date"],
      'property_details_note_informations' => ["check_amortization_term","check_amortization_term","check_rate_reset_frequency","check_amortization","check_baloon_flag","check_minimum_rate","check_maximum_rate","check_interest_rate_index","check_interest_rate_margin"]
    }
    values = validation_labels[table_name]
    for each_val in values

      data_hash[each_val]= 6
				
    end
    return data_hash
  end
		
	def portfolio_first_note(portfolio_id)
		Property.find(:first, :conditions=>['portfolio_id = ?', portfolio_id])
	end

	def sum_of_current_outstanding(p)
		sum = Property.sum('current_outstanding', :conditions=>['portfolio_id=?', p.id])
	end
	
	def sum_of_late_current_outstanding(p)
		sum = Property.sum('current_outstanding', :conditions=>['portfolio_id=? && (late_payments_amount_due IS NOT NULL && late_payments_amount_due != ?)', p, 0])
	end
	
	def sum_of_outstanding(p)
		sum = Property.sum('current_outstanding', :conditions=>['portfolio_id=? && (late_payments_amount_due IS NULL || late_payments_amount_due = ?)', p, 0])
	end
	
	def total_count(p)
		total_count = Property.count('id', :conditions=>['portfolio_id = ?', p])
	end
	
	def calc_current_percentage(p)
		total_count = total_count(p)
		current_count = Property.count('id', :conditions=>['portfolio_id = ? && (late_payments_amount_due IS NULL || late_payments_amount_due = ?)', p, 0])
		avg = (current_count.to_f / total_count.to_f) * 100
	end
	
	def calc_late_percentage(p)
		total_count = total_count(p)
		late_count = Property.count('id', :conditions=>['portfolio_id = ? && (late_payments_amount_due IS NOT NULL && late_payments_amount_due != ?)', p, 0])
		avg = (late_count.to_f / total_count.to_f) * 100
	end

  def share_file(document)
	  @folder = document.folder
  	@portfolio = Portfolio.find(params[:pid])
    su = User.find_by_email(params[:email])
    su_already = (!su.nil? ? true : false)
    	if su_already && su.roles[0].id == 2
			  	role = Role.find_by_name('Shared User')
					su.roles << role
				end	
    if su.nil?
      su = User.new(:email=>params[:email])
      p = su.generate_password
      su.password = p
      su.password_confirmation =p
      su.is_shared_user = true
      su.password_code = User.random_passwordcode
      su.save
      role = Role.find_by_name('Shared User')
      su.roles << role
    end
    sd = SharedDocument.find_or_create_by_document_id_and_user_id_and_sharer_id_and_property_id(document.id,su.id,current_user.id,@folder.property_id)
    sd.update_attributes(:folder_id=>document.folder_id,:sharer_id=>current_user.id)
    UserMailer.deliver_share_notification(su,sd,'doc',current_user,su_already)
    #Event.create_new_event("share",su.id,su.id,[sd.document],su.user_role(su.id),document.filename)
    Event.create_new_event("shared",su.id,su.id,[sd.document],su.user_role(su.id),document.filename,nil)
  end
end