module PropertiesHelper

	def listing_sub_folders(f_options,d_options,dn_options)
    @folders = Folder.find(:all,f_options)
    documents = Document.find(:all,d_options) if !@display_properties
    @documents = documents.reject{|d|  d.document_name !=nil } if !@display_properties
	  if @folder && @folder.parent_id != -1
      @document_names = DocumentName.find(:all,dn_options)
      @real_estate_property = RealEstateProperty.find_by_id(params[:nid])
      params[:folder_id] = Folder.find_by_real_estate_property_id_and_parent_id(@real_estate_property.id,0)   if params[:folder_id].nil? && params[:sfid].nil? && !@real_estate_property.nil?
      params[:folder_id] = f_options["folder_id"] if !f_options["folder_id"].nil?
      d=f_options[:conditions].split("and").collect{|c| c if c.include?("parent_id")}.compact if  f_options[:conditions] != nil
      params[:folder_id] = d[0].split('=')[1].strip if d && !d.empty?
      @tasks = !params[:folder_id].nil? ? Task.find_all_by_folder_id_and_temp_task(params[:folder_id],false) : 	Task.find_all_by_folder_id_and_temp_task(params[:sfid],false)
		end
		return @folders,@document_names,@documents
 	end

	def property_image(note_id)
		image = PortfolioImage.find(:first,:conditions=>['attachable_id = ? and attachable_type = ?',note_id,"RealEstateProperty"])
		if image.nil?
      image = Document.find(:first,:conditions =>  ["is_deleted = ? and real_estate_property_id=? and (content_type LIKE LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?))", false,"#{note_id}",  "%%image/%%", "%%.jpg%%", "%%.gif%%", "%%.png%%", "%%.bmp%%", "%%.jpeg%%"])
		end
		return image.nil? ? '/images/property.jpg' : image.public_filename
	end

	def real_estate_property_image(note_id)
		image = PortfolioImage.find(:first,:conditions=>['attachable_id = ? and attachable_type = ?',note_id,"RealEstateProperty"])
		if image.nil?
      image = Document.find(:first,:conditions =>  ["is_deleted = ? and real_estate_property_id=? and (content_type LIKE LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?))", false,"#{note_id}",  "%%image/%%", "%%.jpg%%", "%%.gif%%", "%%.png%%", "%%.bmp%%", "%%.jpeg%%"])
		end
		return image.nil? ? '/images/real_portfolio_img5.jpg' : image.public_filename
	end

	def total_gross_rentable_area(props)
		gra = 0
		props.each do |p|
			gra += p.gross_rentable_area
		end
		return gra
	end

 	def find_property_images(note_id)
		@images = Document.find(:all,:conditions =>  ["is_deleted = ? and real_estate_property_id=? and (content_type LIKE LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?) or filename like LOWER(?))", false,"#{note_id}",  "%%image/%%", "%%.jpg%%", "%%.gif%%", "%%.png%%", "%%.bmp%%", "%%.jpeg%%"])
		return @images.nil? ? '/images/property.jpg' : @images
	end

	def get_folder_of_notes_real_estate(note_id,portfolio_id)
		#return Folder.find(:first,:conditions=>['parent_id = ? and portfolio_id = ? and real_estate_property_id = ? and user_id = ?',0,portfolio_id,note_id,current_user.id]).id
		return Folder.find(:first,:conditions=>['parent_id = ? and portfolio_id = ? and real_estate_property_id = ?',0,portfolio_id,note_id]).id
	end

  #to find is there any missing file in a folder
	def check_missing_files_real_estate(fid)
    docname_files= DocumentName.find(:all,:conditions=>["is_deleted = ? and folder_id = ? and is_master = ? and real_estate_property_id is not NULL and due_date is not NULL and document_id is NULL",false,fid,0])
		doc_files = Document.find(:all,:conditions=>["is_deleted = ? and folder_id = ? and is_master = ? and real_estate_property_id is not NULL and due_date is NOT NULL",false,fid,0])
		missing_files = docname_files + doc_files
    is_missing_files = missing_files.empty? ? "no" : "yes"
		return is_missing_files
  end

	#To find shared folders
	def find_manage_real_estates_shared_folders
	  @show_deleted = (params[:del_files] == 'true') ? true : false
		conditions =  @show_deleted == true ?   "" : "and is_deleted = false"
    s = SharedFolder.find(:all,:conditions=>["user_id = ? ",current_user.id]).collect{|sf| sf.folder_id}
    fs = Folder.find(:all,:conditions=>["id in (?) and parent_id not in (?) #{conditions} and real_estate_property_id is NOT NULL",s,s]).collect{|f| f.id}
    s_folders = SharedFolder.find(:all,:conditions=>["user_id = ? and folder_id in (?) ",current_user.id,fs])
    folders = s_folders.collect {|sf| sf.folder}.uniq
		return   folders
	end

	def for_notes_year_to_date
		#@portfolio = Portfolio.find(params[:portfolio_id])
		id_val = params[:note_id] ? params[:note_id] : (params[:id] ? params[:id] : 0)
		if @note == nil || params[:id].nil?
      @note = RealEstateProperty.find_by_id(id_val)
		end
		@notes = RealEstateProperty.find(:all, :conditions=>['portfolio_id=? and user_id = ?', @portfolio.id,current_user.id ], :order=> "created_at desc") if !@portfolio.nil?
		#if params[:prop_folder]
    @shared_folders = Folder.find_by_sql("SELECT * FROM folders WHERE id IN (SELECT folder_id FROM shared_folders WHERE is_property_folder =1 AND user_id = #{current_user.id })")
    @notes += RealEstateProperty.find(:all, :conditions=>['portfolio_id=? and id in (?)', @portfolio.id,@shared_folders.collect {|x| x.real_estate_property_id}], :order=> "created_at desc") if !(@portfolio.nil? || @portfolio.blank? || @shared_folders.nil? || @shared_folders.blank?)
    @note = RealEstateProperty.find_by_id_and_portfolio_id(params[:id], @portfolio.id) if !@portfolio.nil? && !params[:id].nil?
    #@note = @notes.first if !@note.nil?
		#end
		@prop = RealEstatePropertyStateLog.find_by_state_id_and_real_estate_property_id(5,@note.id) if @note.nil?
		@time_line_actual  = IncomeAndCashFlowDetail.find(:all,:conditions => ["resource_id =? and resource_type=? ",@note.id, 'RealEstateProperty'])
    @time_line_start_date = Date.new(2010,1,1)
    #@time_line_end_date = Date.new(2010,12,31)
    @time_line_end_date = Date.today.end_of_month

		@actual = @time_line_actual
		year_to_date= Date.today.last_month.month
		@ytd= []
		for m in 1..year_to_date
			@ytd << Date::MONTHNAMES[m].downcase
		end
		@ytd_cal_flag = "false"
    if Date.today.month == 1
			@ytd_cal_flag = "true"
			#store_income_and_cash_flow_statement_for_month(Date.today.last_month.month.to_i,Date.today.last_month.year.to_i)
			executive_overview_details(Date.today.last_month.month,Date.today.last_month.year)
    else
			executive_overview_details_for_year
		end
    #	calculate_operating_statement(@note.id, 11,2009)
    #	calculate_cash_flow_statement(@note.id, 11,2009)
	end

  def store_income_and_cash_flow_statement_for_last_year
		@operating_statement={}
		@cash_flow_statement={}
		year_to_date= Date.today.last_month.month
		year = Date.today.last_year.year
		@ytd= []
		@month_list = []
		for m in 1..12
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
			@month_list <<  Date.new(year,m,1).strftime("%Y-%m-%d")
		end

		#asset_details = IncomeAndCashFlowDetail.find_by_sql("select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('p') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title")

		if @portfolio_summary == true
		  qry = get_query_for_portfolio_summary(year)
		else
		  qry = get_query_for_each_summary(year)
		end

		if qry != nil
      asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
      @operating_statement['expenses']={:budget =>0 ,:actuals =>0}
      for cash_row in asset_details
        val ={}
        if cash_row.Parent == "cash flow statement summary"
          @cash_flow_statement[cash_row.Title] = form_hash_of_data(cash_row)
        else
          data = form_hash_of_data(cash_row)
          @operating_statement[cash_row.Title] = data
          @cash_flow_statement[cash_row.Title] = data	if cash_row.Title == "depreciation & amortization detail" or cash_row.Title =="net income"
          if cash_row.Title=="recoverable expenses detail" or cash_row.Title=="non-recoverable expenses detail"
            @operating_statement['expenses'][:budget]=  @operating_statement['expenses'][:budget].to_f + cash_row.Budget.to_f
            @operating_statement['expenses'][:actuals]=  @operating_statement['expenses'][:actuals].to_f + cash_row.Actuals.to_f
            @operating_statement['expenses'][:record_id]=  cash_row.Record_id if @financial
          end
        end
      end

      variant = @operating_statement['expenses'][:budget].to_f-@operating_statement['expenses'][:actuals].to_f
      percent = variant*100/@operating_statement['expenses'][:budget].to_f.abs rescue ZeroDivisionError
      if  @operating_statement['expenses'][:budget].to_f==0
        percent = ( @operating_statement['expenses'][:actuals].to_f == 0 ? 0 : -100 )
      end
      @operating_statement['expenses'][:percent] = percent
      @operating_statement['expenses'][:variant] = variant
      @operating_statement['expenses'][:status] = true

      net_income_operation_summary_report
    end
    @portfolio_summary = false
		@explanation = true
	end

	def store_income_and_cash_flow_statement
		@operating_statement={}
		@cash_flow_statement={}
		year_to_date= Date.today.last_month.month
		year = Date.today.year
		@ytd= []
		@month_list = []
    @explanation = true
		for m in 1..year_to_date
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
			@month_list <<  Date.new(Time.now.year,m,1).strftime("%Y-%m-%d")
		end

		#asset_details = IncomeAndCashFlowDetail.find_by_sql("select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('p') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title")

		if @portfolio_summary == true
		  qry = get_query_for_portfolio_summary(year)
		else
		  qry = get_query_for_each_summary(year)
		end

		if qry != nil
      asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
      @operating_statement['expenses']={:budget =>0 ,:actuals =>0}
      for cash_row in asset_details
        val ={}
        if cash_row.Parent == "cash flow statement summary"
          @cash_flow_statement[cash_row.Title] = form_hash_of_data(cash_row)
        else
          data = form_hash_of_data(cash_row)
          @operating_statement[cash_row.Title] = data
          @cash_flow_statement[cash_row.Title] = data	if cash_row.Title == "depreciation & amortization detail" or cash_row.Title =="net income"
          if cash_row.Title=="recoverable expenses detail" or cash_row.Title=="non-recoverable expenses detail"
            @operating_statement['expenses'][:budget]=  @operating_statement['expenses'][:budget].to_f + cash_row.Budget.to_f
            @operating_statement['expenses'][:actuals]=  @operating_statement['expenses'][:actuals].to_f + cash_row.Actuals.to_f
            @operating_statement['expenses'][:record_id]=  cash_row.Record_id if @financial
          end
        end
      end

      variant = @operating_statement['expenses'][:budget].to_f-@operating_statement['expenses'][:actuals].to_f
      percent = variant*100/@operating_statement['expenses'][:budget].to_f.abs rescue ZeroDivisionError
      if  @operating_statement['expenses'][:budget].to_f==0
        percent = ( @operating_statement['expenses'][:actuals].to_f == 0 ? 0 : -100 )
      end
      @operating_statement['expenses'][:percent] = percent
      @operating_statement['expenses'][:variant] = variant
      @operating_statement['expenses'][:status] = true

      net_income_operation_summary_report
    end
    @portfolio_summary = false
	end

  def form_hash_of_data(cash_row)
		if @financial
      if !cash_row[:Record_id].nil?
        val ={:actuals => cash_row.Actuals.to_f,:budget => cash_row.Budget.to_f,:record_id=>cash_row.Record_id}
      else
        val ={:actuals => cash_row.Actuals.to_f,:budget => cash_row.Budget.to_f,:record_id=>0}
      end  
		else
      if !cash_row[:Record_id].nil?
        val ={:actuals => cash_row.Actuals.to_f,:budget => cash_row.Budget.to_f,:record_id=>cash_row.Record_id}
      else
        val ={:actuals => cash_row.Actuals.to_f,:budget => cash_row.Budget.to_f,:record_id=>0}
      end
		end
    variant = val[:budget].to_f-val[:actuals].to_f
    percent = variant*100/val[:budget].to_f.abs rescue ZeroDivisionError
    if  val[:budget].to_f==0
      percent = ( val[:actuals].to_f == 0 ? 0 : -100 )
    end
    percent=0.0 if percent.to_f.nan?
    val[:percent] = percent
    val[:variant] =  variant
    val[:status] = true
    return val
	end

	def get_query_for_each_summary(year)
		if @financial
      "select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(child_id) as Record_id from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget , a.id as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('cash flow statement summary', 'operating statement summary','net operating income','cash flow from operating activities') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget,0 as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('cash flow statement summary', 'operating statement summary','net operating income','cash flow from operating activities') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title"
		else
      "select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title"
		end
	end

	# Income & cash flow details calculation for the month
	def store_income_and_cash_flow_statement_for_month(month_val=nil,year=nil)
		@operating_statement={}
		@cash_flow_statement={}
		year_to_date= !month_val.nil? ? month_val : Date.today.last_month.month
		year = Date.today.year  if year.nil?
		@current_time_period=Date.new(year,year_to_date,1)
		@ytd= []

		@ytd << "IFNULL(f."+Date::MONTHNAMES[year_to_date].downcase+",0)"
		@explanation = true
		if @portfolio_summary == true
		  qry = get_query_for_portfolio_summary(year)
		else
		  qry = get_query_for_each_summary(year)
		end

		if qry != nil
      asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)

      @operating_statement['expenses']={:budget =>0.0 ,:actuals =>0.0}
      for cash_row in asset_details
        val ={}
        if cash_row.Parent == "cash flow statement summary"
          @cash_flow_statement[cash_row.Title] = form_hash_of_data(cash_row)
        else
          data = form_hash_of_data(cash_row)
          @operating_statement[cash_row.Title] = data
          @cash_flow_statement[cash_row.Title] = data	if cash_row.Title == "depreciation & amortization detail" or cash_row.Title =="net income"
          if cash_row.Title=="recoverable expenses detail" or cash_row.Title=="non-recoverable expenses detail"
            @operating_statement['expenses'][:budget]=  @operating_statement['expenses'][:budget].to_f + cash_row.Budget.to_f
            @operating_statement['expenses'][:actuals]=  @operating_statement['expenses'][:actuals].to_f + cash_row.Actuals.to_f
            @operating_statement['expenses'][:record_id]=  cash_row.Record_id if @financial
          end
        end

      end

      variant = @operating_statement['expenses'][:budget].to_f-@operating_statement['expenses'][:actuals].to_f
      percent = variant*100/@operating_statement['expenses'][:budget].to_f.abs rescue ZeroDivisionError
      if  @operating_statement['expenses'][:budget].to_f==0
        percent = ( @operating_statement['expenses'][:actuals].to_f == 0 ? 0 : -100 )
      end
      @operating_statement['expenses'][:percent] = percent
      @operating_statement['expenses'][:variant] = variant
      @operating_statement['expenses'][:status] = true
      net_income_operation_summary_report
    end
    @portfolio_summary = false
	end

  # Net operating income details display in exceutive summary
  def net_income_operation_summary_report
    @divide = 1
		if (@operating_statement.length > 1 and @operating_statement['net operating income'])			
			@divide = (@operating_statement['expenses'][:actuals].abs > @operating_statement['income detail'][:actuals].abs) ? @operating_statement['expenses'][:actuals].abs : @operating_statement['income detail'][:actuals].abs
			@net_income_de={}
			@net_income_de['diff'] = (@operating_statement['net operating income'][:budget] - @operating_statement['net operating income'][:actuals]).abs
      percent =  ((@net_income_de['diff']*100) / @operating_statement['net operating income'][:budget]).abs rescue ZeroDivisionError
      if   @operating_statement['net operating income'][:budget].to_f==0
        percent = ( @operating_statement['net operating income'][:actuals].to_f == 0 ? 0 : -100 )
      end
			@net_income_de['diff_per'] = percent  #((@net_income_de['diff']*100) / @operating_statement['net operating income'][:budget]).abs
			@net_income_de['diff_word'] = (@operating_statement['net operating income'][:budget] > @operating_statement['net operating income'][:actuals]) ? 'below' : 'above'
			@net_income_de['diff_style'] =  (@net_income_de['diff_word'] == 'above') ? 'greenrow' : 'redrow'
		end
	end

	# Executive summary for monthly details
	def executive_overview_details(month_val=nil,year=nil)
		store_income_and_cash_flow_statement_for_month(month_val,year)
		occupancy_percent_for_month(month_val,year)
		capital_expenditure_for_month(month_val,year)
	end

	# Executive summary for year-to-date funcationalcity
	def executive_overview_details_for_year
		@ytd_t=true
		store_income_and_cash_flow_statement
		occupancy_percent_for_month(Date.today.last_month.month,Date.today.last_month.year)	 #if params[:partial] != 'capital_expenditure' && session[:wres_user] != true	#Fix for other inc & exp last month error
		capital_expenditure_for_month
	end

	def executive_overview_details_for_last_year
		@ytd_t=true
		store_income_and_cash_flow_statement_for_last_year
		occupancy_percent_for_month(Date.today.last_year.end_of_year.month,Date.today.last_year.end_of_year.year)
		capital_expenditure_for_month(Date.today.last_year.end_of_year.month,Date.today.last_year.end_of_year.year)
	end

	# Occupancy details diaplay for month
	def occupancy_percent_for_month(month_val=nil,year=nil)
		month= !month_val.nil? ? month_val : Date.today.last_month.month
		year = Date.today.year  if year.nil?
		@current_time_period=Date.new(year,month,1)
		if @ytd_t
      os= PropertyOccupancySummary.find(:all,:conditions => ["year=? and real_estate_property_id=?",year,@note.id],:order => "month desc",:limit =>1)
      @occupancy_summary = os[0] if !os.nil? and !os.empty?
		else
      @occupancy_summary = PropertyOccupancySummary.find(:first,:conditions => ["year=? and month=? and real_estate_property_id=?",year,month,@note.id])
    end
		@occupancy_graph ={}
		if @occupancy_summary
      #Occupancy
      act_total = @occupancy_summary.current_year_sf_vacant_actual + @occupancy_summary.current_year_sf_occupied_actual
      diff = @occupancy_summary.current_year_sf_occupied_actual - @occupancy_summary.current_year_sf_occupied_budget
      @occupancy_graph[:occupied] = {:value => @occupancy_summary.current_year_sf_occupied_actual,:val_percent => (@occupancy_summary.current_year_sf_occupied_actual*100)/act_total.to_f ,:diff => diff.abs,:diff_percent =>  (diff.abs*100)/@occupancy_summary.current_year_sf_occupied_budget.to_f.abs ,:style => (diff > 0 ?  "greenrow" : "redrow3" ) ,:diff_word => (diff > 0 ?  "above" : "below" ) }

      #Vacant
      act_total = @occupancy_summary.current_year_sf_vacant_actual + @occupancy_summary.current_year_sf_occupied_actual
      diff = @occupancy_summary.current_year_sf_vacant_actual - @occupancy_summary.current_year_sf_vacant_budget
      @occupancy_graph[:vacant] = {:value => @occupancy_summary.current_year_sf_vacant_actual,:val_percent => (@occupancy_summary.current_year_sf_vacant_actual*100)/act_total.to_f ,:diff => diff.abs,:diff_percent =>  (diff.abs*100)/@occupancy_summary.current_year_sf_vacant_budget.to_f.abs ,:style => (diff > 0 ?  "greenrow" : "redrow2" )  ,:diff_word => (diff > 0 ?  "above" : "below" )}

      @leasing_activity ={:new_leave => @occupancy_summary.new_leases_actual.to_f,:expire => @occupancy_summary.expirations_actual.to_f }


      diff_a =  @occupancy_summary.new_leases_actual.to_f - @occupancy_summary.expirations_actual.to_f
      diff_b =  @occupancy_summary.new_leases_budget.to_f - @occupancy_summary.expirations_budget.to_f
      diff_d = diff_a - diff_b
      diff_percent = diff_b == 0 ? 100 : ((diff_d*100)/diff_b).abs
      @leasing_activity[:change_in_occu] = { :diff_act =>diff_a,:diff_both => diff_d,:diff_percent => diff_percent,:style =>  (diff_a > diff_b) ? "greedrow" : "redrow"}

      diff_renewal = @occupancy_summary.renewals_actual.to_f - @occupancy_summary.renewals_budget.to_f
      @leasing_activity[:renewal] = {:actual => @occupancy_summary.renewals_actual.to_f,:diff_renew =>  (diff_renewal.to_f.abs*100)/@occupancy_summary.renewals_budget.to_f ,:style => (@occupancy_summary.renewals_actual.to_f > @occupancy_summary.renewals_budget.to_f ) ? "greenrow" : "redrow" ,:diff_word =>  (@occupancy_summary.renewals_actual.to_f > @occupancy_summary.renewals_budget.to_f ) ? "above" : "below" }
      @leasing_activity[:renewal][:diff_percent] = (@leasing_activity[:renewal][:diff_renew].to_f * 100)/ @occupancy_summary.renewals_budget.to_f

      @percent_average = {}

      high_value = @occupancy_summary.new_leases_actual.to_f > @occupancy_summary.expirations_actual.to_f ? ( ( @occupancy_summary.new_leases_actual.to_f > @occupancy_summary.renewals_actual.to_f) ?  @occupancy_summary.new_leases_actual.to_f :  @occupancy_summary.renewals_actual.to_f )  :  ( ( @occupancy_summary.expirations_actual.to_f > @occupancy_summary.renewals_actual.to_f ) ?  @occupancy_summary.expirations_actual.to_f :  @occupancy_summary.renewals_actual.to_f )

      @percent_average = { :renewal => (@occupancy_summary.renewals_actual.to_f  * 100)/high_value ,:new_l_percent => (@occupancy_summary.new_leases_actual.to_f * 100)/high_value ,:expiration => (@occupancy_summary.expirations_actual.to_f * 100)/high_value,:change_percent => (@leasing_activity[:change_in_occu][:diff_act].to_f  * 100)/ high_value }

    end
    @mtyd = @ytd.nil? ? "0" : "1"
    @graph_month = month
    @gra_year = year
    if !(@occupancy_graph.nil? || @occupancy_graph.blank?)
      @partial_file = "/properties/sample_pie"
      @swf_file = "Pie2D.swf"
      @xml_partial_file = "/properties/sample_pie"
      #@vaccant  		=  @property_occupancy_summary.current_year_sf_vacant_actual
      @vaccant  		=  @occupancy_graph[:vacant][:value].to_i
      #@occupied 	=   @property_occupancy_summary.current_year_sf_occupied_actual
      @occupied 	=   @occupancy_graph[:occupied][:value].to_i
      @vaccant_percent = (@vaccant  * 100 / (@occupancy_graph[:vacant][:value].to_f + @occupancy_graph[:occupied][:value].to_f)).abs.round
      @occupied_percent = (@occupied  * 100 / (@occupancy_graph[:vacant][:value].to_f + @occupancy_graph[:occupied][:value].to_f)).abs.round
				
      @start_angle = 0
      if !(@vaccant.nil? || @vaccant.blank? || @vaccant == 0 || @occupied.nil? || @occupied.blank? || @occupied == 0)
        if @vaccant <= @occupied
          @start_angle = (180 - (1.8 * ((@vaccant * 100)/(@vaccant+@occupied)  rescue ZeroDivisionError)))
        else
          @start_angle = (1.8 * ((@vaccant * 100)/(@vaccant+@occupied)  rescue ZeroDivisionError))
        end
      end
    end
	end

  # Captial Expenditure calculation for the month in executive summary
	def capital_expenditure_for_month(month_val=nil,year=nil)
		month= !month_val.nil? ? month_val : Date.today.last_month.month
		year = Date.today.last_month.year  if year.nil?
		month=1
		pci = PropertyCapitalImprovement.find(:first,:conditions => ["year=? and real_estate_property_id=?",year,@note.id],:select=>'month',:order => "month desc")
		#pci = PropertyCapitalImprovement.find(:first,:conditions => ["year=? and real_estate_property_id=?",year,@note.id],:order => "month desc") - selected only month field
		month = pci.month if !pci.nil?
		query = get_query_for_capital_improvement_executive(month,year)
		asset_details = PropertyCapitalImprovement.find_by_sql(query)
		if !asset_details.empty?
      @capital_improvement = {}
      @capital_percent = {}
      tot_a = 0
      tot_b = 0
      for asset in asset_details
        if !asset.Cate.nil? and ["tenant improvements","leasing commissions","building improvements","lease costs"].include?(asset.Cate.downcase.strip)
          @capital_improvement[asset.Cate.downcase.strip] = asset.act.to_f
          tot_a = tot_a + asset.act.to_f if !asset.act.nil?
          tot_b = tot_b + asset.bud.to_f if !asset.bud.nil?
        end
      end
      for asset in asset_details
        if !asset.Cate.nil? and ["tenant improvements","leasing commissions","building improvements","lease costs"].include?(asset.Cate.downcase.strip)
          @capital_percent[asset.Cate.downcase.strip] = ( @capital_improvement[asset.Cate.downcase.strip]  * 100)/tot_a
        end
      end
      diff = tot_b - tot_a
      diff_per = tot_b !=  0.0 ? (diff * 100)/tot_b : 0
			if diff_per == 0
				diff_per = 0
			elsif diff_per.nan?
				diff_per = 0
			end
      @captial_diff={:diff => diff,:diff_percent => diff_per,:style => (tot_b > tot_a ) ?  "greenrow" : "redrow",:tot_actual => tot_a,:diff_word => (tot_b > tot_a ) ? "below" : "above"}
    end
	end

	# Query for Captical improvement functionality
	def get_query_for_capital_improvement_executive(month,year)
		#	"select Cate ,sum(actual) as act, sum(budget) as bud from (SELECT #{@ytd.join("+")} as actual , 0 AS budget,ci.category as Cate ,f.pcb_type FROM  property_capital_improvements AS ci, property_financial_periods AS f WHERE ci.real_estate_property_id = #{@note.id} AND ci.month = #{month} AND ci.year = #{year} AND  ci.category IN ('TENANT IMPROVEMENTS','LEASING COMMISSIONS','BUILDING IMPROVEMENTS','LEASE COSTS')  AND f.source_id = ci.id  AND  f.pcb_type ='c'  AND   f.source_type = 'PropertyCapitalImprovement' UNION SELECT  0 as actual , #{@ytd.join("+")} AS budget,ci.category  as Cate,f.pcb_type FROM  property_capital_improvements AS ci, property_financial_periods AS f WHERE ci.real_estate_property_id = #{@note.id} AND ci.month = #{month} AND ci.year = #{year} AND  ci.category IN ('TENANT IMPROVEMENTS','LEASING COMMISSIONS','BUILDING IMPROVEMENTS','LEASE COSTS','BUILDING IMPROVEMENTS','LEASE COSTS')  AND f.source_id = ci.id  AND  f.pcb_type ='b'  AND   f.source_type = 'PropertyCapitalImprovement')  xyz group by Cate"
    "select sum(actual) as act, sum(budget) as bud, Cate from ( SELECT  sum(#{@ytd.join("+")}) as actual , 0 AS budget, ci.category as Cate , f.pcb_type  FROM   property_capital_improvements AS ci   ,      	property_financial_periods AS f  WHERE  ci.real_estate_property_id = #{@note.id} AND  ci.month = #{month} AND  ci.year = #{year} AND  ci.category IN ('TENANT IMPROVEMENTS','LEASING COMMISSIONS','BUILDING IMPROVEMENTS','LEASE COSTS') AND   f.source_id = ci.id AND   f.pcb_type ='c' AND   f.source_type = 'PropertyCapitalImprovement'  GROUP BY  ci.category UNION  SELECT  0 as actual, sum(#{@ytd.join("+")}) AS budget,  ci.category as Cate,f.pcb_type   FROM property_capital_improvements AS ci,  property_financial_periods AS f WHERE  ci.real_estate_property_id = #{@note.id} AND ci.month = #{month} AND ci.year = #{year} AND ci.category IN ('TENANT IMPROVEMENTS','LEASING COMMISSIONS','BUILDING IMPROVEMENTS','LEASE COSTS','BUILDING IMPROVEMENTS','LEASE COSTS') AND f.source_id = ci.id AND  f.pcb_type ='b' AND f.source_type = 'PropertyCapitalImprovement' GROUP BY  ci.category ) xyz group by Cate"
	end

  def extract_capital_improvement(doc)
    month_details = ['', 'january','february','march','april','may','june','july','august','september','october','november','december']
    categories = ['TENANT IMPROVEMENTS','BUILDING IMPROVEMENTS','LEASING COMMISSIONS','LOAN COSTS','LEASE COSTS','NET LEASE COSTS','CARPET & DRAPES']
    restricted_categories = ['TOTAL CAPITAL EXPENDITURES','TOTAL TENANT IMPROVEMENTS']
    exec_str = "prop_cap_improve.year = year; prop_cap_improve.month = month; prop_cap_improve.save; prop_fin_period_A = prop_cap_improve.property_financial_periods.empty? ?  PropertyFinancialPeriod.new : prop_cap_improve.property_financial_periods.select{ |i| i.pcb_type == 'c' }.first; prop_fin_period_B = prop_cap_improve.property_financial_periods.empty? ?  PropertyFinancialPeriod.new : prop_cap_improve.property_financial_periods.select{ |i| i.pcb_type == 'b' }.first"
    prop_fin_period_A = Array.new # These are used to store the financial periods.
    prop_fin_period_B = Array.new
    cur_category = ''
    tenant_name = ''
    processed = false
    real_estate_property_id = doc.real_estate_property_id; # store the property id here
    #ActiveRecord::Base.connection.execute("delete t1, t2 from property_capital_improvements as t1, property_financial_periods as t2 where t1.real_estate_property_id = #{real_estate_property_id} and t2.source_id = t1.id and t2.source_type ='PropertyCapitalImprovement';")
    book = Excel.new "#{RAILS_ROOT}/public#{doc.public_filename}"
    book.default_sheet = book.sheets[0]
    roww = 7
    head = OpenStruct.new ; head.chk_category = nil
    budget_index = []
    actual_index = [] # below code skips TASK sheets and iterates over for headers.
    budget_index_category = Array.new(12,0)
    actual_index_category = Array.new(12,0)
    book.sheets.each do |rip|
      unless rip.include?("TASK")
        book.default_sheet = rip
        1.upto book.last_column do |col|
          case book.cell(roww, col)
          when 'SUITE ID', 'SUITE'; head.suite = col
          when 'CATEGORY'; head.category = col
          when 'STATUS'; head.status = col
          when 'BUDGET'; head.annual_budget = col if book.cell( roww - 1, col )
          when 'ACTUAL'; head.chk_category = col if head.chk_category.nil?
          end
        end
        break
      end
    end
    (head.status + 1).upto head.status+12 do |ind| actual_index << ind  end
    (actual_index.last + 2).upto actual_index.last+13 do |ind| budget_index.push(ind) end
    book.sheets.each do |sheet|
      last_category = 'TENANT IMPROVEMENTS'
      last_tenant_name_flush = false;
      contd_flag = true
      book.default_sheet = sheet
      sheet_name =book.cell(3,1).nil? ?  book.cell(3,8).split(' ') : book.cell(3,1).split(' ')
      sheet_name.push(book.cell(2,1).split(' ').first) if sheet_name.count < 2
      year = sheet_name[1].to_i
      month = month_details.index sheet_name[0].downcase
      next if (month.nil? || !PropertyCapitalImprovement.find_all_by_real_estate_property_id_and_month_and_year(real_estate_property_id, month, year).empty?)
      9.upto book.last_row do |row|
        processed = true
        category = book.cell(row, head.category)
        next if (category.nil? || category.empty?)
        categories.include?(category.strip) ? cur_category = category.strip : tenant_name = category.strip
        next if book.cell(row, head.chk_category).nil?
        suite_no = ( book.cell(row, head.suite).class == Float ) ? book.cell(row, head.suite).to_i : book.cell(row, head.suite)
        property_suite= (suite_no.nil? || suite_no.to_s.empty?) ? {'id' => nil } : PropertySuite.find_or_create_by_real_estate_property_id_and_suite_number(real_estate_property_id, suite_no)
        if cur_category != last_category && ['LEASING COMMISSIONS','LEASE COSTS','NET LEASE COSTS','CARPET & DRAPES','LOAN COSTS'].include?(cur_category) && contd_flag
          prop_cap_improve = PropertyCapitalImprovement.find_or_initialize_by_tenant_name_and_month_and_year_and_real_estate_property_id("TOTAL "+last_category, month, year, real_estate_property_id)
          #prop_cap_improve.tenant_name = "TOTAL "+last_category // code under review.
          #prop_cap_improve.property_suite_id = property_suite['id']
          prop_cap_improve.category = "TOTAL "+last_category
          #prop_cap_improve.real_estate_property_id = real_estate_property_id
          eval(exec_str)
          prop_fin_period_A.source_id = prop_cap_improve['id']
          prop_fin_period_A.source_type = prop_cap_improve.class.to_s
          prop_fin_period_A.year = year
          prop_fin_period_A.pcb_type = "c"
          prop_fin_period_A.january =actual_index_category[0]
          prop_fin_period_A.february = actual_index_category[1]
          prop_fin_period_A.march = actual_index_category[2]
          prop_fin_period_A.april = actual_index_category[3]
          prop_fin_period_A.may = actual_index_category[4]
          prop_fin_period_A.june = actual_index_category[5]
          prop_fin_period_A.july = actual_index_category[6]
          prop_fin_period_A.august = actual_index_category[7]
          prop_fin_period_A.september = actual_index_category[8]
          prop_fin_period_A.october = actual_index_category[9]
          prop_fin_period_A.november = actual_index_category[10]
          prop_fin_period_A.december = actual_index_category[11]
          prop_fin_period_A.save;

          prop_fin_period_B.source_id = prop_cap_improve['id'];
          prop_fin_period_B.source_type = prop_cap_improve.class.to_s;
          prop_fin_period_B.year = year;
          prop_fin_period_B.pcb_type = "b";
          prop_fin_period_B.january = budget_index_category[0]
          prop_fin_period_B.february = budget_index_category[1]
          prop_fin_period_B.march = budget_index_category[2]
          prop_fin_period_B.april = budget_index_category[3]
          prop_fin_period_B.may = budget_index_category[4]
          prop_fin_period_B.june = budget_index_category[5]
          prop_fin_period_B.july = budget_index_category[6]
          prop_fin_period_B.august = budget_index_category[7]
          prop_fin_period_B.september =budget_index_category[8]
          prop_fin_period_B.october = budget_index_category[9]
          prop_fin_period_B.november = budget_index_category[10]
          prop_fin_period_B.december = budget_index_category[11]
          prop_fin_period_B.save
          budget_index_category = Array.new(12,0)
          actual_index_category = Array.new(12,0)
          last_category = cur_category
          contd_flag = false if ['CARPET & DRAPES'].include?(cur_category)
        elsif last_tenant_name_flush
          budget_index_category = Array.new(12,0)
          actual_index_category = Array.new(12,0)
          last_tenant_name_flush = false
          last_category = cur_category
        end
        prop_cap_improve = PropertyCapitalImprovement.new
        prop_cap_improve.tenant_name = tenant_name
        prop_cap_improve.property_suite_id = property_suite['id']
        prop_cap_improve.category = restricted_categories.include?(tenant_name) ? tenant_name : cur_category
        prop_cap_improve.real_estate_property_id = real_estate_property_id
        prop_cap_improve.annual_budget = book.cell(row, head.annual_budget) if book.cell(row, head.annual_budget).class == Float
        prop_cap_improve.project_status = book.cell(row, head.status)
        eval(exec_str)
        # property financial store for Actual values
        prop_fin_period_A.source_id = prop_cap_improve['id']
        prop_fin_period_A.source_type = prop_cap_improve.class.to_s
        prop_fin_period_A.year = year
        prop_fin_period_A.pcb_type = "c"
        prop_fin_period_A.january = book.cell(row, actual_index[0]);actual_index_category[0] +=book.cell(row, actual_index[0]) unless book.cell(row, actual_index[0]).nil?
        prop_fin_period_A.february = book.cell(row, actual_index[1]);actual_index_category[1] += book.cell(row, actual_index[1]) unless book.cell(row, actual_index[1]).nil?
        prop_fin_period_A.march = book.cell(row, actual_index[2]);actual_index_category[2] += book.cell(row, actual_index[2]) unless book.cell(row, actual_index[2]).nil?
        prop_fin_period_A.april = book.cell(row, actual_index[3]);actual_index_category[3] += book.cell(row, actual_index[3]) unless book.cell(row, actual_index[3]).nil?
        prop_fin_period_A.may = book.cell(row, actual_index[4]);actual_index_category[4] += book.cell(row, actual_index[4]) unless book.cell(row, actual_index[4]).nil?
        prop_fin_period_A.june = book.cell(row, actual_index[5]);actual_index_category[5] += book.cell(row, actual_index[5]) unless book.cell(row, actual_index[5]).nil?
        prop_fin_period_A.july = book.cell(row, actual_index[6]);actual_index_category[6] += book.cell(row, actual_index[6]) unless book.cell(row, actual_index[6]).nil?
        prop_fin_period_A.august = book.cell(row, actual_index[7]);actual_index_category[7] += book.cell(row, actual_index[7]) unless book.cell(row, actual_index[7]).nil?
        prop_fin_period_A.september = book.cell(row, actual_index[8]);actual_index_category[8] += book.cell(row, actual_index[8]) unless book.cell(row, actual_index[8]).nil?
        prop_fin_period_A.october = book.cell(row, actual_index[9]);actual_index_category[9] += book.cell(row, actual_index[9]) unless book.cell(row, actual_index[9]).nil?
        prop_fin_period_A.november = book.cell(row, actual_index[10]);actual_index_category[10] += book.cell(row, actual_index[10]) unless book.cell(row, actual_index[10]).nil?
        prop_fin_period_A.december = book.cell(row, actual_index[11]);actual_index_category[11] += book.cell(row, actual_index[11]) unless book.cell(row, actual_index[11]).nil?
        prop_fin_period_A.save;
        # Budget storing obj
        prop_fin_period_B.source_id = prop_cap_improve['id'];
        prop_fin_period_B.source_type = prop_cap_improve.class.to_s;
        prop_fin_period_B.year = year;
        prop_fin_period_B.pcb_type = "b";
        prop_fin_period_B.january = book.cell(row, budget_index[0]);budget_index_category[0] += book.cell(row, budget_index[0]) unless book.cell(row, budget_index[0]).nil?
        prop_fin_period_B.february = book.cell(row, budget_index[1]);budget_index_category[1] += book.cell(row, budget_index[1]) unless book.cell(row, budget_index[1]).nil?
        prop_fin_period_B.march = book.cell(row, budget_index[2]);budget_index_category[2] += book.cell(row, budget_index[2]) unless book.cell(row, budget_index[2]).nil?
        prop_fin_period_B.april = book.cell(row, budget_index[3]);budget_index_category[3] += book.cell(row, budget_index[3]) unless book.cell(row, budget_index[3]).nil?
        prop_fin_period_B.may = book.cell(row, budget_index[4]);budget_index_category[4] += book.cell(row, budget_index[4]) unless book.cell(row, budget_index[4]).nil?
        prop_fin_period_B.june = book.cell(row, budget_index[5]);budget_index_category[5] += book.cell(row, budget_index[5]) unless book.cell(row, budget_index[5]).nil?
        prop_fin_period_B.july = book.cell(row, budget_index[6]);budget_index_category[6] += book.cell(row, budget_index[6]) unless book.cell(row, budget_index[6]).nil?
        prop_fin_period_B.august = book.cell(row, budget_index[7]);budget_index_category[7] += book.cell(row, budget_index[7]) unless book.cell(row, budget_index[7]).nil?
        prop_fin_period_B.september = book.cell(row, budget_index[8]);budget_index_category[8] += book.cell(row, budget_index[8]) unless book.cell(row, budget_index[8]).nil?
        prop_fin_period_B.october = book.cell(row, budget_index[9]);budget_index_category[9] += book.cell(row, budget_index[9]) unless book.cell(row, budget_index[9]).nil?
        prop_fin_period_B.november = book.cell(row, budget_index[10]);budget_index_category[10] += book.cell(row, budget_index[10]) unless book.cell(row, budget_index[10]).nil?
        prop_fin_period_B.december = book.cell(row, budget_index[11]);budget_index_category[11] += book.cell(row, budget_index[11]) unless book.cell(row, budget_index[11]).nil?
        prop_fin_period_B.save
        last_tenant_name_flush = true if tenant_name == 'TOTAL TENANT IMPROVEMENTS'
        sql = ActiveRecord::Base.connection();
        sql.execute("INSERT INTO property_capital_improvements (year, month, real_estate_property_id, category, tenant_name, annual_budget, created_at, updated_at) (SELECT year, month, real_estate_property_id, category, category, 0, now(), now()  FROM `property_capital_improvements`  WHERE real_estate_property_id= #{real_estate_property_id} AND year=#{year} AND month =#{month} group by year, month, real_estate_property_id, category)")
        sql.execute("DELETE property_capital_improvements FROM property_capital_improvements, (SELECT MAX(id) AS dupid, COUNT(id) AS dupcnt FROM property_capital_improvements GROUP BY year, month, real_estate_property_id, category HAVING dupcnt > 1) AS dups WHERE property_capital_improvements.id = dups.dupid")
      end
    end
    processed
  end

  def extract_aged_receivables(doc)
    real_estate_property_id = doc.real_estate_property_id # params wants to loaded here
    ActiveRecord::Base.connection.execute("delete t1 from property_suites as t0, property_aged_receivables as t1 where t0.real_estate_property_id = #{real_estate_property_id} and t1.property_suite_id = t0.id;")
    book = Excel.new "#{RAILS_ROOT}/public#{doc.public_filename}"
    head = OpenStruct.new
    book.sheets.each do |rip|
      unless rip.include?("TASK")
        book.default_sheet = rip
        1.upto book.last_row do |roww|
          if book.cell(roww, 1) == 'Bldg - Lease #'
            1.upto book.last_column do |coll|
              case book.cell(roww, coll)
              when 'Tenant'; head.tenant = coll
              when 'Current'; head.current = coll
              when '30 Days'; head.days_30 = coll
              when '60 Days'; head.days_60 = coll
              when '90 Days'; head.days_90 = coll
              when '120 Days'; head.days_120 = coll
              end
            end
            head.start = roww
            break;
          end
        end
        break;
      end
    end
    book.sheets.each do |sheet|
      book.default_sheet = sheet
      if !sheet.include?('TASK') # sheet title must contain 'AR' else not extracted
        sheet_date = book.cell(3,1).nil? ? OpenStruct.new({:year=>nil, :month=>nil}) : book.cell(3,1).split(' ').last.to_date # Finding the month and year from excel
        year = sheet_date.year
        month = sheet_date.month
        head.start.next.upto book.last_row do |row|
          next if book.cell(row, head.tenant).nil? || book.cell(row, head.tenant).empty?
          break if (book.cell(row, head.tenant) == "Grand Total:" || book.cell(row, head.tenant) == 'Grand Total') # exits when see the grand total in excel.
          suite_id = book.cell(row, 1).nil? ? nil : book.cell(row, 1).split(' ').last
          prop_suite = suite_id.nil? ?  {'id' => nil}  : PropertySuite.find_or_create_by_real_estate_property_id_and_suite_number(real_estate_property_id, suite_id)
          prop_aged_rec = PropertyAgedReceivable.new
          prop_aged_rec.property_suite_id = prop_suite['id']
          prop_aged_rec.tenant = book.cell(row,head.tenant)
          prop_aged_rec.paid_amount = book.cell(row, head.current)
          prop_aged_rec.over_30days = book.cell(row, head.days_30)
          prop_aged_rec.over_60days = book.cell(row, head.days_60)
          prop_aged_rec.over_90days = book.cell(row, head.days_90)
          prop_aged_rec.over_120days = book.cell(row, head.days_120)
          prop_aged_rec.month = month
          prop_aged_rec.year = year
          prop_aged_rec.save
        end
      end
    end
  end

	#to calculate pending amount
	def find_amount_pending(aging)
		aging_30_days = aging.over_30days.nil? ? 0 : aging.over_30days
		aging_60_days = aging.over_60days.nil? ? 0 : aging.over_60days
		aging_90_days = aging.over_90days.nil? ? 0 : aging.over_90days
		aging_120_days = aging.over_120days.nil? ? 0 : aging.over_120days
		amount = aging_30_days + aging_60_days + aging_90_days + aging_120_days
		return amount
	end

	#to calulate cash and receivables and displayed in performance review page
  def cash_and_receivables
    property_suite_ids = PropertySuite.find(:all,:conditions=>["real_estate_property_id = ?",@note.id],:select=>'id') #.collect{|s| s.id} - Instead of all fields,only ids are selected
    month = (params[:tl_month].nil? || params[:tl_month].empty?) ? Date.today.last_month.month.to_i  : params[:tl_month]
    year =	params[:tl_year].nil? ? Date.today.year.to_i : params[:tl_year]
    if Date.today.month == 1
      year = Date.today.last_month.year
		end
	  @time_line_start_date = Date.new(2010,1,1)
    @time_line_end_date = Date.today.end_of_month
    @default_month_and_year= 45.days.ago
		@current_time_period=Date.new(@default_month_and_year.year,@default_month_and_year.month,1) 

		
    @financial = true
  	@period = params[:period] if params[:period]
		@period = "5" if @period.nil?
		#~ if !(month.nil? && year.nil?)
    #~ store_income_and_cash_flow_statement if @period == "4" || params[:tl_period] == "4"
    #~ store_income_and_cash_flow_statement_for_month(month.to_i,year.to_i) if (params[:tl_period] == "5") || (!params[:tl_month].nil? && !params[:tl_month].empty?)
		#~ else
    #~ store_income_and_cash_flow_statement_for_month if @period != "4" && params[:tl_period] != "4"
    #~ store_income_and_cash_flow_statement if @period == "4" || params[:tl_period] == "4"
    #~ end
		if (!params[:tl_month].nil? and !params[:tl_month].blank?) or (!params[:start_date].nil?)
			store_income_and_cash_flow_statement_for_month(month.to_i,year.to_i)
		else
      if !params[:tl_period].nil? && params[:tl_period] == '4'
				@period = "4" 
				store_income_and_cash_flow_statement
      elsif !params[:tl_period].nil? && params[:tl_period] == '5'
				@period = "5" 
				dt = Date.today.months_ago(1)
				store_income_and_cash_flow_statement_for_month(dt.month, dt.year) if !params[:tl_period].nil?
      elsif !params[:tl_period].nil? && params[:tl_period] == '6'
				@period = "6" 
				store_income_and_cash_flow_statement_for_last_year
      end
		end
		if (@period == "4" || params[:tl_period] == "4") && (params[:tl_month].nil? || params[:tl_month] == "" )
      year_to_date= Date.today.last_month.strftime("%m").to_i
      @months = []
      if @month_list && !@month_list.empty?
        @month_list.each do |m|
          @months << m.split("-")[1]
        end
      end
      @account_receivables_aging = PropertyAgedReceivable.paginate(:all,:conditions=>["property_suite_id in (?) and month in (?) and year = ? AND !(round(over_30days) = 0 AND   round(over_60days) = 0 AND round(over_90days) = 0 AND round(over_120days) = 0)", property_suite_ids,@months,year],:page=>params[:page],:per_page=>10,:order=>params[:sort],:include=>["property_suite"]) if @months
 		else
      @account_receivables_aging = PropertyAgedReceivable.paginate(:all,:conditions=>["property_suite_id in (?) and month = ? and year = ? AND !(round(over_30days) = 0 AND   round(over_60days) = 0 AND round(over_90days) = 0 AND round(over_120days) = 0)", property_suite_ids,month,year],:page=>params[:page],:per_page=>10,:order=>params[:sort],:include=>["property_suite"])
    end
    render :update do |page|
 			if params[:from_performance_review] == "true"
        page << "jQuery('#time_line_selector').show();"
        page << "jQuery('.subheaderwarpper').show();"
		  elsif params[:from_performance_review] != "true"
        page << "jQuery('#time_line_selector').show();"
        page << "jQuery('.executiveheadcol_for_title').html('<div class=\"executivecol_subrow\"><span class=\"executiveiconcol\"><img width=\"14\" height=\"16\" src=\"/images/executivehead_icon.png\"></span>Cash & Receivables</div>');"
				page << "jQuery('#id_for_variance_threshold').html('<ul class=inputcoll2 id=cssdropdown></ul>');"
				#page << "jQuery('#id_for_modify_threshold').html('<div class=morebutton_label><a id=modify_threshold_#{@note.id} href=#{new_threshold_property_path(@note.id)}>Variance Thresholds</a></div><span></span>');"
        #page << "new Control.Modal($('modify_threshold_#{@note.id}'), {beforeOpen: function(){load_writter();},afterOpen: function(){load_completer();},className:'modal_container', method:'post'});"
			end
      page.replace_html "time_line_selector", :partial => "/properties/time_line_selector", :locals => {:period => @period, :note_id => @note.id, :partial_page => "cash_and_receivables", :start_date => 0, :timeline_start => @time_line_start_date, :timeline_end => @time_line_end_date } if !params[:start_date] && params[:tl_month].blank?
      page.replace_html "portfolio_overview_property_graph", :partial => "/properties/cash_and_receivables/"
    end
  end

	#To calculate NOI in portfolio overview page
	def property_performance_noi_calculation(property_id,period)
		@note = RealEstateProperty.find_by_id(property_id)
		@period = period
		if @period == "4"
      store_income_and_cash_flow_statement
		elsif @period == "5"
      store_income_and_cash_flow_statement_for_month
		else
      store_income_and_cash_flow_statement
    end
  end

  #calculates noi of all properties in particular portfolio
  def find_net_operating_income_summary_portfolio(portfolio_id,period)
   	property_ids = RealEstateProperty.find(:all,:conditions => ["portfolio_id = ? and user_id =?",portfolio_id, current_user.id])
  	property_ids += RealEstateProperty.find_by_sql("SELECT * FROM real_estate_properties WHERE portfolio_id = #{portfolio_id} and id in (SELECT real_estate_property_id FROM shared_folders WHERE is_property_folder = 1 AND user_id = #{current_user.id} )")
    
		@property_ids = property_ids.collect{|x|x.id}.split(',').join(',')

		@portfolio_summary = true
		@time_line_actual  = IncomeAndCashFlowDetail.find(:all,:conditions => ["resource_id IN (?) and resource_type=? ",@property_ids, 'RealEstateProperty'])
		if period == "4"
      year = Date.today.year  if year.nil?
		else
      year = Date.today.last_month.year  if year.nil?
    end
		((period == "4") ? store_income_and_cash_flow_statement  : store_income_and_cash_flow_statement_for_month(nil,year)) #if (!@time_line_actual.empty?)
  end

	#calulates noi of all properties in particular portfolio for WRES properties
  def wres_find_net_operating_income_summary_portfolio(portfolio_id,period)
   	property_ids = RealEstateProperty.find(:all,:conditions => ["portfolio_id = ? and user_id =?",portfolio_id, current_user.id])
  	property_ids += RealEstateProperty.find_by_sql("SELECT * FROM real_estate_properties WHERE portfolio_id = #{portfolio_id} and id in (SELECT real_estate_property_id FROM shared_folders WHERE is_property_folder = 1 AND user_id = #{current_user.id} )")
    
		@property_ids = property_ids.collect{|x|x.id}.split(',').join(',')

		@portfolio_summary = true
		@financial = false
		@time_line_actual  = IncomeAndCashFlowDetail.find(:all,:conditions => ["resource_id IN (?) and resource_type=? ",@property_ids, 'RealEstateProperty'])
		if period == "4"
      year = Date.today.year  if year.nil?
		else
      year = Date.today.last_month.year  if year.nil?
    end
		((period == "4") ? wres_store_income_and_cash_flow_statement  : wres_store_income_and_cash_flow_statement_for_month(nil,year)) #if (!@time_line_actual.empty?)
  end

  # query to find noi of all properties in portfolio overview
  def get_query_for_portfolio_summary(year)
    if !@property_ids.empty?
      qry = "select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget from (SELECT k.title as Parent, a.title as Title, f.pcb_type,sum(#{@ytd.join("+")}) as actuals, 0 as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id in (#{@property_ids}) AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' group by Title UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals,sum(#{@ytd.join("+")}) as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id in (#{@property_ids}) AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' group by Title) xyz group by Parent, Title"
    end
  end

  # query to find noi of all properties in portfolio overview
  def wres_get_query_for_portfolio_summary(year)
    if !@property_ids.empty?
      qry = "select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget , sum(variance) as Variance from (SELECT k.title as Parent, a.title as Title, f.pcb_type,sum(#{@ytd.join("+")}) as actuals, 0 as budget , 0 as variance FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id in (#{@property_ids}) AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' group by Title UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals,sum(#{@ytd.join("+")}) as budget,0 as variance FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id in (#{@property_ids}) AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' group by Title UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals,0 as budget, sum(#{@ytd.join("+")}) as variance  FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id in (#{@property_ids}) AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('var_amt') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' group by Title) xyz group by Parent, Title"
    end
  end

	# To check whether 12 month budget exists for a particular property
	def income_and_budget_exists(property_id)
		income_budget = IncomeAndCashFlowDetail.find(:all,:conditions => ["resource_id =? and resource_type=? ",property_id, 'RealEstateProperty'])
		!income_budget.empty? ? true : false
	end

	# To check whether lease exists for a particular property
	def lease_exists(property_id)
		lease = PropertySuite.find(:first,:conditions => ["real_estate_property_id=? ",property_id])
		occupancy = PropertyOccupancySummary.find(:first,:conditions => ["real_estate_property_id=? ",property_id])
		(!lease.nil? && !occupancy.nil?) ? true : false
	end

	#To find direction of arrow icon should be displayed
	def up_or_down(actual, budget)
		(actual >= budget) ? 'up' : 'down'
	end

	#To find color to display good or bad based on budget and actual values for expense
	def expense_color(actual, budget)
		(actual > budget) ? 'red' : 'green'
	end

	#To find color to display good or bad based on budget and actual values for income
	def income_color(actual, budget)
		(actual >= budget) ? 'green' : 'red'
	end

	#to display noi ,capexp,occupancy in performance review page
	def portfolio_overview_noi_capital_exp_occupancy(id)
		if  @period == "4"
      year_to_date= Date.today.last_month.month
      year = Date.today.year
      @ytd= []
      @month_list = []
      for m in 1..year_to_date
        @ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
        @month_list <<  Date.new(Time.now.year,m,1).strftime("%Y-%m-%d")
      end
    elsif @period =="5"
      year_to_date=  Date.today.last_month.month
      year = Date.today.last_month.year  if year.nil?
      @current_time_period=Date.new(year,year_to_date,1)
      @ytd= []
      @ytd << "IFNULL(f."+Date::MONTHNAMES[year_to_date].downcase+",0)"
    end
		connection = ActiveRecord::Base.connection();
    connection.execute("DROP TABLE  IF EXISTS tmp_table")
    connection.execute("CREATE TABLE tmp_table (id INT,portfolio_id INT,property_name VARCHAR(100),city VARCHAR(100),province VARCHAR(100),noi_c double,bud double,var double,
				 act_c double,bud_c double,var_c double,current_year_sf_occupied_actual  double,current_year_sf_occupied_budget  double,occupancy_percentage  double,act_m double,bud_m double,var_m double,current_year_units_occupied_actual  double,current_year_units_vacant_actual  double)")

    #noi_qry = "SELECT r.id, r.portfolio_id, r.property_name,sum(V.actual) act, sum(V.budget) bud, sum(actual-budget) as var FROM real_estate_properties r LEFT JOIN ( SELECT k.resource_id, IF(f.pcb_type='c',#{@ytd.join("+")},0) as actual, IF(f.pcb_type='b',#{@ytd.join("+")},0) as budget FROM property_financial_periods f , income_and_cash_flow_details k WHERE f.source_id IN ( SELECT i.id FROM income_and_cash_flow_details i WHERE i.resource_id IN (SELECT r.id FROM real_estate_properties r WHERE r.portfolio_id = #{id} ) AND i.title='net operating income' AND i.year=#{year}) AND f.source_type = 'IncomeAndCashFlowDetail' AND f.pcb_type IN ('c','b') AND k.id=f.source_id ) V ON r.id = V.resource_id WHERE  r.portfolio_id = #{id} GROUP BY r.id, r.portfolio_id, r.property_name"

		real_estate_properties_id = RealEstateProperty.find(:all, :conditions => ["portfolio_id in (?) and user_id = ?",id,current_user.id], :select=> "id")

		real_estate_properties_id += RealEstateProperty.find_by_sql("SELECT id FROM real_estate_properties WHERE id in (SELECT real_estate_property_id FROM shared_folders WHERE is_property_folder = 1 AND user_id = #{current_user.id} )")


		noi_qry = "SELECT r.id, r.portfolio_id, r.property_name,sum(V.actual) noi_c, sum(V.budget) bud, sum(actual-budget) as var FROM real_estate_properties r LEFT JOIN ( SELECT k.resource_id, IF(f.pcb_type='c',#{@ytd.join("+")},0) as actual, IF(f.pcb_type='b',#{@ytd.join("+")},0) as budget FROM property_financial_periods f , income_and_cash_flow_details k WHERE f.source_id IN ( SELECT i.id FROM income_and_cash_flow_details i WHERE i.resource_id IN (SELECT r.id FROM real_estate_properties r WHERE r.portfolio_id = #{id} ) AND i.title='net operating income' AND i.year=#{year}) AND f.source_type = 'IncomeAndCashFlowDetail' AND f.pcb_type IN ('c','b') AND k.id=f.source_id ) V ON r.id = V.resource_id WHERE r.id in (#{real_estate_properties_id.collect{|x| x.id}.join(',')}) GROUP BY r.id, r.portfolio_id, r.property_name"


		if session[:wres_user]
			maintenance_qry = "SELECT r.id, r.portfolio_id, r.property_name,sum(V.actual) noi_c, sum(V.budget) bud, sum(actual-budget) as var FROM real_estate_properties r LEFT JOIN
( SELECT k.resource_id, IF(f.pcb_type='c',#{@ytd.join("+")},0) as actual, IF(f.pcb_type='b',#{@ytd.join("+")},0) as budget FROM property_financial_periods f , income_and_cash_flow_details k WHERE f.source_id IN ( SELECT i.id FROM income_and_cash_flow_details i WHERE i.resource_id IN (#{real_estate_properties_id.collect{|x| x.id}.join(',')}) AND i.title='maintenance projects' AND i.year=#{year}) AND f.source_type = 'IncomeAndCashFlowDetail' AND f.pcb_type IN ('c','b') AND k.id=f.source_id ) V
ON r.id = V.resource_id WHERE  r.portfolio_id = #{id} GROUP BY r.id, r.portfolio_id, r.property_name"
		end

    max_month_qry = connection.execute("SELECT max(ci.month) FROM property_capital_improvements ci WHERE ci.category IN ('TENANT IMPROVEMENTS','LEASING COMMISSIONS','BUILDING IMPROVEMENTS', 'LEASE COSTS') AND ci.real_estate_property_id IN (SELECT r.id FROM real_estate_properties r WHERE r.id IN (#{real_estate_properties_id.collect{|x| x.id}.join(',')})) AND ci.year=#{year} HAVING max(ci.month)")
    last_month = []
    max_month_qry.each do |m|
      last_month << m
    end

    last_month = [Date.today.last_month.month]  if(@period == "5")

    if last_month[0] != nil
      cap_exp_qry = "SELECT r.id, r.portfolio_id, r.property_name,sum(V.actual) noi_c, sum(V.budget) bud, sum(actual-budget) as var
FROM real_estate_properties r LEFT JOIN  (SELECT k.real_estate_property_id,f.source_type, f.pcb_type,
     IF(f.pcb_type='c',(#{@ytd.join("+")}),0) as actual,
     IF(f.pcb_type='b',(#{@ytd.join("+")}),0) as budget
     FROM property_financial_periods f, property_capital_improvements k
     WHERE f.source_id IN (SELECT ci.id FROM property_capital_improvements ci WHERE ci.category IN ('TENANT IMPROVEMENTS','LEASING COMMISSIONS','BUILDING IMPROVEMENTS', 'LEASE COSTS') AND ci.real_estate_property_id IN (SELECT r.id FROM real_estate_properties r WHERE r.portfolio_id = #{id}) AND ci.year=#{year} AND ci.month = #{last_month[0]}) AND f.`source_type`='PropertyCapitalImprovement' AND k.id=f.source_id ) V ON r.id = V.real_estate_property_id WHERE r.portfolio_id = #{id} GROUP BY r.id, r.portfolio_id, r.property_name"
    end
    #occupancy_max_month = PropertyOccupancySummary.find_by_sql("SELECT max(`month`) as month FROM property_occupancy_summaries WHERE month <= #{Date.today.last_month.month} and real_estate_property_id = #{@note.id}")

    occupancy_max_month = PropertyOccupancySummary.find_by_sql("SELECT max(`month`) as month FROM property_occupancy_summaries o INNER JOIN real_estate_properties r on o.real_estate_property_id = r.id and r.portfolio_id =#{@portfolio.id} and r.id in (#{real_estate_properties_id.collect{|x|x.id}.split(',').join(',')}) and o.month <= #{Date.today.last_month.month}")


    max_month =  (@period == "5") ? "#{Date.today.last_month.month}" : occupancy_max_month[0].month

    if occupancy_max_month[0].month.nil?
      occupancy_qry = ""
    else
      occupancy_qry = "SELECT a.*, b.current_year_sf_occupied_actual, b.current_year_sf_occupied_budget, b.id,b.current_year_units_occupied_actual, b.current_year_units_vacant_actual FROM property_occupancy_summaries b RIGHT JOIN ( SELECT #{max_month} as month, real_estate_property_id FROM property_occupancy_summaries WHERE real_estate_property_id IN (#{real_estate_properties_id.collect{|x|x.id}.split(',').join(',')})
AND year = #{year} group by real_estate_property_id having #{max_month}) a ON a.month=b.month and b.year = #{year} AND a.real_estate_property_id=b.real_estate_property_id"
    end



    noi_details = connection.execute(noi_qry)
    cap_exp_details = connection.execute(cap_exp_qry) if last_month[0] != nil
    occupancy_details = connection.execute(occupancy_qry) if occupancy_qry != ""
		maintenance_details = connection.execute(maintenance_qry) if session[:wres_user]
    for cash_row in noi_details
      #~ address = RealEstateProperty.find_by_id(cash_row[0]).address
      #~ city = address.nil? ? "" : address.city
      #~ province = address.nil? ? "" : address.province
      cty_prov = RealEstateProperty.find_by_sql("SELECT  a.city as cty,a.province as prov FROM real_estate_properties r, addresses a WHERE r.address_id = a.id and r.id = #{cash_row[0]}")
      city = cty_prov.empty? ? "" : cty_prov[0].cty
      province = cty_prov.empty? ? "" : cty_prov[0].prov
      cash_row[2] = CGI::escape(cash_row[2]) unless cash_row[2].nil? || cash_row[2] ==""
      cash_row[3] = CGI::escape(cash_row[3]) unless cash_row[3].nil? || cash_row[3] ==""
      cash_row[4] = CGI::escape(cash_row[4]) unless cash_row[4].nil? || cash_row[4] ==""
      cash_row[5] = CGI::escape(cash_row[5]) unless cash_row[5].nil? || cash_row[5] ==""
      city = CGI::escape(city) unless city ==""
      province = CGI::escape(province) unless province ==""
      insert_qry = connection.execute("INSERT INTO tmp_table(id,portfolio_id,property_name,city,province,noi_c,bud,var)  VALUES(#{cash_row[0]},#{cash_row[1]},'#{cash_row[2]}','#{city}','#{province}','#{cash_row[3]}','#{cash_row[4]}','#{cash_row[5]}')")
    end

    if last_month[0] != nil
      for cap_row in cap_exp_details
        if !(cap_row[3] == nil && cap_row[4] == nil && cap_row[5] == nil)
          insert_qry = connection.execute("update tmp_table set act_c ='#{cap_row[3]}',bud_c ='#{cap_row[4]}',var_c ='#{cap_row[5]}' where (id =#{cap_row[0]} and portfolio_id = #{cap_row[1]}) ")
        end
      end
    end

    if session[:wres_user]
      for main_row in maintenance_details
        if !(main_row[3] == nil && main_row[4] == nil && main_row[5] == nil)
          insert_qry = connection.execute("update tmp_table set act_m ='#{main_row[3]}',bud_m ='#{main_row[4]}',var_m ='#{main_row[5]}' where (id =#{main_row[0]} and portfolio_id = #{main_row[1]}) ")
        end
      end
    end

    if occupancy_details
      for occ_row in occupancy_details
        occ_row_2 = occ_row[2].nil? ? 'NULL' : "'#{occ_row[2]}'"
        occ_row_3 = occ_row[3].nil? ? 'NULL' : "'#{occ_row[3]}'"
        occ_row_4 = occ_row[4].nil? ? 'NULL' : "'#{occ_row[4]}'"
        occ_row_5 = occ_row[5].nil? ? 'NULL' : "'#{occ_row[5]}'"
        occ_row_6 = occ_row[6].nil? ? 'NULL' : "'#{occ_row[6]}'"
        insert_qry = connection.execute("update tmp_table set current_year_sf_occupied_actual=#{occ_row_2},current_year_sf_occupied_budget=#{occ_row_3},occupancy_percentage=#{occ_row_4},current_year_units_occupied_actual=#{occ_row_5},current_year_units_vacant_actual=#{occ_row_6} where id=#{occ_row[1]}")
      end
    end
    sort = params[:sort] ?  params[:sort] : "id"

    properties_not_updated = RealEstateProperty.find(:all, :conditions=>['portfolio_id=?',id])
    properties_not_updated.each do |p|
      is_property_exists = connection.execute("select id from tmp_table where id = #{p.id}")
      if is_property_exists == []
        connection.execute("INSERT INTO tmp_table(id,portfolio_id,property_name,city,province)  VALUES(#{p.id},#{p.portfolio_id},'#{p.portfolio_name}','#{p.city}','#{p.province}')")
      end
    end
    real_properties = connection.execute("select * from tmp_table where portfolio_id = #{id} order by #{sort}");
    real_estate_properties = []

    real_properties.each do |r|
      real_estate_properties << r
    end
    @real_properties = real_estate_properties.paginate(:page =>params[:page],:per_page => 10)
    return @real_properties
  end

	def get_address(property)
		if property.nil?
			return '-'
		else
			address = ''
			address = address + property.desc.to_s if  property.desc != ''
			if property.city != ''
				address == '' ? address = address+property.city.to_s  :  address = address + ', '+property.city.to_s
			end
			if property.province != ''
				address == '' ? address = address+property.province.to_s : address = address + ', '+property.province.to_s
			end
			if property.zip != ''
				address == '' ?  address  : address = address+', '+property.zip.to_i.to_s
			end
			address == '' ?  '-' :  address
		end
	end

	#to find period in overview
  def find_time_period(params)
    if params[:period].nil? || params[:period].empty?
      if Date.today.month == 1
        params[:period]  = "5"
      else
        params[:period]  = "4"
      end
    end
    @period = params[:period]
  end

  def get_location_slider(property)
		if property.city == '' && property.province == ''
			''
		elsif property.city != '' && property.province == ''
			display_truncated_chars(property.city.to_s, 18, true)
		elsif property.city == '' && property.province != ''
			property.province.slice(0,2)
		else
			display_truncated_chars(property.city.to_s, 15, true) +', '+property.province.slice(0,2)
		end
	end

	def check_collaborators(user_id,collaborator_list)
		return (collaborator_list.split(",").include?(user_id.to_s)) ? true : false
	end

	def re_portfolio_property_types(pid)
		prop_names = RealEstateProperty.find_by_sql("SELECT p.name ,r.id,r.user_id FROM real_estate_properties r, property_types p WHERE r.property_type_id = p.id and r.portfolio_id = #{pid}").collect{|x| x.name if check_property_shared_or_owned(x.id,x.user_id)}
		return prop_names.compact.uniq.join(', ')
	end

	def  check_property_shared_or_owned(property_id,user_id)
    if(user_id != current_user.id)
      property_folder  = Folder.find_by_real_estate_property_id_and_parent_id_and_is_master(property_id,0,0)
      shared_property_folder = SharedFolder.find_by_folder_id_and_user_id(property_folder.id,current_user.id,:conditions=>["is_property_folder is not null and is_property_folder = true"]) if property_folder && property_folder.parent_id != -1
      is_shared = shared_property_folder.nil? ? false : true
      return is_shared
    else
      return true
    end
  end

	def check_box_for_repeat_task(task)
		return (task and task.repeat_task and (task.repeat_task.task_created_count < task.repeat_task.repeat_count) ? true : false)
	end

	def find_tasks_without_shared_parent_folder(user_id)
		sh_folders = SharedFolder.find_all_by_user_id(user_id).map(&:folder_id)
		#~ tasks_wo_folders = Task.find(:all,:select => "tasks.*",:from => "tasks",:conditions => ["tasks.document_id IS NULL and tasks.folder_id NOT IN (?) and task_collaborators.user_id=?",sh_folders,user_id],:joins => "inner join task_collaborators on task_collaborators.task_id = tasks.id")
    tasks_wo_folders = Task.find_by_sql("select tasks.* from tasks,task_collaborators where tasks.id = task_collaborators.task_id and tasks.document_id is null and task_collaborators.user_id = #{user_id} #{sh_folders.blank? ? '' : 'and folder_id NOT IN ('+sh_folders.join(',')+')'};")
		return tasks_wo_folders unless tasks_wo_folders.blank?
	end


	def find_tasks_without_shared_inside_folder(user_id)
		sh_folders = SharedFolder.find_all_by_user_id(user_id).map(&:folder_id)
		tasks_wo_folders = Task.find(:all,:select => "tasks.*",:from => "tasks",:conditions => ["tasks.document_id IS NULL and task_collaborators.user_id=? and tasks.folder_id = ?",user_id,params[:folder_id]],:joins => "inner join task_collaborators on task_collaborators.task_id = tasks.id")
		return tasks_wo_folders if !tasks_wo_folders.blank?
	end

	def create_subfolders_files_for_property(property_folder,property)
		month = 1 #Date.today.month
		accounts_folder = Folder.create(:name =>"Accounts",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id,:is_master =>1)
		acc_year_folder = Folder.create(:name =>"#{Date.today.year}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>accounts_folder.id,:is_master =>1 )
		for mo in month..12
			Folder.create(:name =>"#{Date::MONTHNAMES[mo].slice(0,3)}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>acc_year_folder.id,:is_master =>1 )
		end
		acc_excel_folder = Folder.create(:name =>"Excel Data Templates",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>accounts_folder.id,:is_master =>1 )
		store_excel_template(['12_month_budget.xls','capital_improvement_status_report.xls','aged_delinquencies.xls'],acc_excel_folder)

		leases_folder = Folder.create(:name =>"Leases",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id,:is_master =>1)
		lease_year_folder = Folder.create(:name =>"#{Date.today.year}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>leases_folder.id,:is_master =>1 )
		for mo in month..12
			Folder.create(:name =>"#{Date::MONTHNAMES[mo].slice(0,3)}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>lease_year_folder.id,:is_master =>1)
		end
		lease_excel_folder = Folder.create(:name =>"Excel Data Templates",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>leases_folder.id,:is_master =>1)
		store_excel_template(['occupancy_leasing_report.xls','rent_roll.xls'],lease_excel_folder)

		loan_doc_folder = Folder.create(:name =>"Loan Docs",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id,:is_master =>1)
		loan_year_folder = Folder.create(:name =>"#{Date.today.year}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>loan_doc_folder.id,:is_master =>1)
		for mo in month..12
			Folder.create(:name =>"#{Date::MONTHNAMES[mo].slice(0,3)}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>loan_year_folder.id,:is_master =>1)
		end
		loan_excel_folder = Folder.create(:name =>"Excel Data Templates",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>loan_doc_folder.id,:is_master =>1)
		store_excel_template(['debt_summary.xls'],loan_excel_folder)
		
		physical_folder = Folder.create(:name =>"Property Pictures",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id,:is_master =>1)				
		
    monthly_report_folder = Folder.create(:name =>"Report Docs",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id ,:is_master =>1)

	end	

	def wres_create_subfolders_files_for_property_for(property_folder,property)
		month = 1 #Date.today.month
		accounts_folder = Folder.create(:name =>"Accounts",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id,:is_master =>1 )
		acc_year_folder = Folder.create(:name =>"#{Date.today.year}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>accounts_folder.id ,:is_master =>1)
		for mo in month..12
			Folder.create(:name =>"#{Date::MONTHNAMES[mo].slice(0,3)}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>acc_year_folder.id,:is_master =>1 )
		end
		acc_excel_folder = Folder.create(:name =>"Excel Data Templates",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>accounts_folder.id,:is_master =>1 )
		store_excel_template(['12_Month_Budget.xls','Actual_Budget_Analysis_Report.xls','Cash_Flow_Forecast.xls'],acc_excel_folder)

		leases_folder = Folder.create(:name =>"Leases",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id,:is_master =>1 )
		lease_year_folder = Folder.create(:name =>"#{Date.today.year}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>leases_folder.id,:is_master =>1)
		for mo in month..12
			Folder.create(:name =>"#{Date::MONTHNAMES[mo].slice(0,3)}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>lease_year_folder.id,:is_master =>1 )
		end
		lease_excel_folder = Folder.create(:name =>"Excel Data Templates",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>leases_folder.id,:is_master =>1 )
		store_excel_template(['all_units.xls','boxscore.xls'],lease_excel_folder)

		loan_doc_folder = Folder.create(:name =>"Loan Docs",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id ,:is_master =>1)
    # Commented temporarily as mentioned in UAT Defect Log list
=begin
		loan_year_folder = Folder.create(:name =>"#{Date.today.year}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>loan_doc_folder.id,:is_master =>1 )
		for mo in month..12
			Folder.create(:name =>"#{Date::MONTHNAMES[mo].slice(0,3)}",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>loan_year_folder.id ,:is_master =>1)
		end
		loan_excel_folder = Folder.create(:name =>"Excel Data Templates",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>loan_doc_folder.id,:is_master =>1 )
=end
		physical_folder = Folder.create(:name =>"Property Pictures",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id ,:is_master =>1)
		monthly_report_folder = Folder.create(:name =>"Report Docs",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id ,:is_master =>1)
	end

	def store_excel_template(arr,folder)
		arr.each do |fl|
			path ="#{RAILS_ROOT}/public/template/"+fl.to_s
      ActionController::UploadedTempfile.open(fl) do |temp|
        temp.write(File.open(path).read)
        temp.original_path = path
        #temp.content_type = fl.content_type
        d= Document.new
        d.uploaded_data = temp
        #   d.state_flag = fl.state_flag if !fl.state_flag.nil?
        d.folder_id = folder.id
        d.user_id = current_user.id
				d.is_master = 1
				d.real_estate_property_id = folder.real_estate_property_id
        #d.due_date = fl.due_date if !fl.due_date.nil?
        d.save
      end
		end
	end

	def check_document_functionality(document)
		parent_folder = Folder.find_by_id(document.folder_id)
		gr_parent_folder = Folder.find_by_id(parent_folder.parent_id) if !parent_folder.nil?
		if !gr_parent_folder.nil? and ["Accounts","Leases","Loan Docs"].include?(gr_parent_folder.name) and !parent_folder.nil? and parent_folder.name == "Excel Data Templates"
			return false
    else
			return true
		end
	end


	def check_folder_functionality(folder_id)
		parent_folder = Folder.find_by_id(folder_id)
		gr_parent_folder = Folder.find_by_id(parent_folder.parent_id) if !parent_folder.nil?
		if !gr_parent_folder.nil? and ["Accounts","Leases","Loan Docs"].include?(gr_parent_folder.name) and !parent_folder.nil? and parent_folder.name == "Excel Data Templates"
			return false
    else
			return true
		end
	end

	def call_parsing_functions_for_excel(tmp_doc)
   
    parent_folder = Folder.find_by_id(tmp_doc.folder_id)
    gr_parent_folder = Folder.find_by_id(parent_folder.parent_id) if !parent_folder.nil?
    gr_gr_parent_folder = Folder.find_by_id(gr_parent_folder.parent_id) if !gr_parent_folder.nil?
    sql = ActiveRecord::Base.connection();
    if !gr_gr_parent_folder.nil?
      if gr_gr_parent_folder.name == "Accounts"
        if tmp_doc.filename.downcase == "financials.xls" || (tmp_doc.filename.downcase.include?("month") && tmp_doc.filename.downcase.include?("budget"))
          store_new_income_and_cash_flow_version(tmp_doc)
          store_variance_details(tmp_doc.real_estate_property_id, "RealEstateProperty")
          sql.execute("UPDATE real_estate_properties SET last_updated = NOW( ) WHERE id = ( SELECT real_estate_property_id FROM folders WHERE id = #{parent_folder.id} )")
        elsif  tmp_doc.filename.downcase.include?("capital")
          processed = extract_capital_improvement(tmp_doc)
          store_variance_details(tmp_doc.real_estate_property_id) if processed
          sql.execute("UPDATE real_estate_properties SET last_updated = NOW( ) WHERE id = ( SELECT real_estate_property_id FROM folders WHERE id = #{parent_folder.id} )")	if processed
        elsif  tmp_doc.filename.downcase.include?("aged")
          extract_aged_receivables(tmp_doc)
          sql.execute("UPDATE real_estate_properties SET last_updated = NOW( ) WHERE id = ( SELECT real_estate_property_id FROM folders WHERE id = #{parent_folder.id} )")
        end
      elsif gr_gr_parent_folder.name == "Leases"
        if  tmp_doc.filename.downcase.include?("occupancy")
          store_new_occupancy_leasing(tmp_doc)
          sql.execute("UPDATE real_estate_properties SET last_updated = NOW( ) WHERE id = ( SELECT real_estate_property_id FROM folders WHERE id = #{parent_folder.id} )")
        elsif tmp_doc.filename.downcase.include?("rent_roll")
        end
      elsif gr_gr_parent_folder.name == "Loan Docs"
        if tmp_doc.filename.downcase.include?("debt_summary")
          store_new_debt_summary(tmp_doc)
        end
      end
    end
   
	end

	def wres_call_parsing_functions_for_excel(tmp_doc)
		begin
			parent_folder = Folder.find_by_id(tmp_doc.folder_id)
			gr_parent_folder = Folder.find_by_id(parent_folder.parent_id) if !parent_folder.nil?
			gr_gr_parent_folder = Folder.find_by_id(gr_parent_folder.parent_id) if !gr_parent_folder.nil?
			sql = ActiveRecord::Base.connection();
			if !gr_gr_parent_folder.nil?
				if gr_gr_parent_folder.name == "Accounts"
          #        if  (tmp_doc.filename.downcase.include?("forecast"))
          #          wres_parsing_cash_flow_forecast(tmp_doc) DO NOT CHANGE THE ORDER..
          #          wres_store_variance_details_forecast(tmp_doc.real_estate_property_id, "RealEstateProperty")
					if  tmp_doc.filename.downcase.include?("actual")
						wres_actual_budget_analysis_parsing(tmp_doc)
						sql.execute("UPDATE real_estate_properties SET last_updated = NOW( ) WHERE id = ( SELECT real_estate_property_id FROM folders WHERE id = #{parent_folder.id} )")
					elsif tmp_doc.filename.downcase.include?("budget")
						wres_12_month_parsing(tmp_doc)
						sql.execute("UPDATE real_estate_properties SET last_updated = NOW( ) WHERE id = ( SELECT real_estate_property_id FROM folders WHERE id = #{parent_folder.id} )")
					end
				elsif gr_gr_parent_folder.name == "Leases"
					if  tmp_doc.filename.downcase.include?("units")
						wres_all_units_parsing(tmp_doc)
						sql.execute("UPDATE real_estate_properties SET last_updated = NOW( ) WHERE id = ( SELECT real_estate_property_id FROM folders WHERE id = #{parent_folder.id} )")
					end
				end
			end
		rescue
			#@error_file =true;
      tmp_doc.update_attribute :parsing_done, false
		end
	end

	def cap_exp_explanation(id,month,ytd_check)
		txt = CapitalExpenditureExplanation.find_by_property_capital_improvement_id_and_month_and_ytd(id,month,ytd_check)
		return txt.explanation if !(txt.nil? || txt.blank?)
	end
	
	def cap_exp_explanation_doc(id,month,ytd_check)
		txt = CapitalExpenditureExplanation.find_by_property_capital_improvement_id_and_month_and_ytd(id,month,ytd_check)
		return txt.document_id if !(txt.nil? || txt.blank?)
	end
	
	def cap_exp_explanation_user_id(id,month,ytd_check)
		txt = CapitalExpenditureExplanation.find_by_property_capital_improvement_id_and_month_and_ytd(id,month,ytd_check)
		return txt.user_id if !(txt.nil? || txt.blank?)
	end
	
	def cap_exp_explanation_updated_at(id,month,ytd_check)
		txt = CapitalExpenditureExplanation.find_by_property_capital_improvement_id_and_month_and_ytd(id,month,ytd_check)
		return txt.updated_at if !(txt.nil? || txt.blank?)
	end

	def financial_explanation(id,month,ytd_check)
		#txt = IncomeCashFlowExplanation.find_by_income_and_cash_flow_detail_id(id)
		txt = IncomeCashFlowExplanation.find(:first, :conditions => ["income_and_cash_flow_detail_id = ? and month = ? and ytd = ?",id,month,ytd_check])
		# for retrieve explaination user_id not required
		return txt.explanation if !(txt.nil? || txt.blank?)
	end
	
	def financial_explanation_doc(id,month,ytd_check)
		txt = IncomeCashFlowExplanation.find(:first, :conditions => ["income_and_cash_flow_detail_id = ? and month = ? and ytd = ?",id,month,ytd_check])
		return txt.document_id  if !(txt.nil? || txt.blank?)
	end

	def financial_explanation_user_id(id,month,ytd_check)
		txt = IncomeCashFlowExplanation.find(:first, :conditions => ["income_and_cash_flow_detail_id = ? and month = ? and ytd = ?",id,month,ytd_check])
		return txt.user_id  if !(txt.nil? || txt.blank?)
	end
	
	def financial_explanation_updated_at(id,month,ytd_check)
		txt = IncomeCashFlowExplanation.find(:first, :conditions => ["income_and_cash_flow_detail_id = ? and month = ? and ytd = ?",id,month,ytd_check])
		return txt.updated_at  if !(txt.nil? || txt.blank?)
	end

	def cash_receivable_explanation(id,month)
		txt = PropertyCashFlowForecastExplanation.find(:first, :conditions => ["property_cash_flow_forecast_id = ? and month = ?",id,month])
		return txt.explanation if !(txt.nil? || txt.blank?)
	end

	def lease_explanation(id,month,year,type)
		#txt = IncomeCashFlowExplanation.find_by_income_and_cash_flow_detail_id(id)
	  txt = LeasesExplanation.find(:first, :conditions =>["month = ? and year = ? and real_estate_property_id = ? and occupancy_type=?",month, year,id,type])
		# for retrieve explaination user_id not required
		return txt.explanation if !(txt.nil? || txt.blank?)
	end

	def leases_explanation_updated_at(id,month,ytd_check)
		txt = LeasesExplanation.find_by_id_and_month(id,month)
		return txt.updated_at if !(txt.nil? || txt.blank?)
	end

	def get_remainig_days(task)
		unless task.nil?
			if !task.due_by.nil?
				days = ( task.due_by - Date.today ).to_i
				if days > 0
					return "#{days} day(s) left"
				elsif days < 0
					return "#{days.abs} day(s) elapsed"
				elsif days == 0
					return "Today is last date"
				end
			end
		end
	end

  def wres_store_variance_details_forecast(id, type)
    coll = PropertyCashFlowForecast.find_all_by_resource_id_and_resource_type(id, type)
    coll.each do |itr|
      next if ['BEGINNING CASH','TOTAL CASH INCREASE (DECREASE)','ENDING CASH'].any?{|i|itr.title.include?(i)}
      pfs =  itr.property_financial_periods
      b_row = pfs.detect {|i| i.pcb_type == 'b'}
      a_row = pfs.detect {|i| i.pcb_type == 'c'}
      unless b_row.nil? && a_row.nil?
        b_arr = [b_row.january, b_row.february, b_row.march, b_row.april, b_row.may, b_row.june, b_row.july, b_row.august, b_row.september, b_row.october, b_row.november, b_row.december]
        #b_arr.each_with_index { |i,j| b_arr[j] = 0 if i.nil? }
        a_arr = [a_row.january, a_row.february, a_row.march, a_row.april, a_row.may, a_row.june, a_row.july, a_row.august, a_row.september, a_row.october, a_row.november, a_row.december]
        #a_arr.each_with_index { |i,j| a_arr[j] = 0 if i.nil? }
        var_arr = []
        per_arr = []
        0.upto(11) do |indx|
          if b_arr[indx].nil? or a_arr[indx].nil?
            var_arr[indx] = nil
            per_arr[indx] = nil
          else
            var_arr[indx] = wres_find_income_or_expense(itr) ? (b_arr[indx].to_f - a_arr[indx].to_f) : (a_arr[indx].to_f -  b_arr[indx].to_f)
            per_arr[indx] =  (var_arr[indx] * 100) / b_arr[indx].to_f
            if  b_arr[indx].to_f==0
              per_arr[indx] = ( a_arr[indx].to_f == 0 ? 0 : -100 )
            end
            per_arr[indx]= 0.0 if per_arr[indx].to_f.nan?
          end
        end
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_amt')
        pf.january= var_arr[0];pf.february=var_arr[1];pf.march=var_arr[2];pf.april=var_arr[3];pf.may=var_arr[4];pf.june=var_arr[5];pf.july=var_arr[6];pf.august=var_arr[7];pf.september=var_arr[8];pf.october=var_arr[9];pf.november=var_arr[10];pf.december=var_arr[11];pf.save
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_per')
        pf.january= per_arr[0];pf.february=per_arr[1];pf.march=per_arr[2];pf.april=per_arr[3];pf.may=per_arr[4];pf.june=per_arr[5];pf.july=per_arr[6];pf.august=per_arr[7];pf.september=per_arr[8];pf.october=per_arr[9];pf.november=per_arr[10];pf.december=per_arr[11];pf.save
        #PropertyFinancialPeriod.create(:source_id => itr.id, :source_type=> itr.class.to_s, :pcb_type=>'var_per', :january=> per_arr[0], :february=>per_arr[1], :march=>per_arr[2], :april=>per_arr[3], :may=>per_arr[4], :june=>per_arr[5], :july=>per_arr[6], :august=>per_arr[7], :september=>per_arr[8], :october=>per_arr[9], :november=>per_arr[10], :december=>per_arr[11])
      end
    end
  end


  def store_variance_details(id, type = [])
    unless type.empty?
      coll = IncomeAndCashFlowDetail.find_all_by_resource_id_and_resource_type(id, type)
    else
      coll = PropertyCapitalImprovement.find_all_by_real_estate_property_id(id)
    end
    coll.each do |itr|
      pfs =  itr.property_financial_periods
      b_row = pfs.detect {|i| i.pcb_type == 'b'}
      a_row = pfs.detect {|i| i.pcb_type == 'c'}
      unless b_row.nil? && a_row.nil?
        b_arr = [b_row.january, b_row.february, b_row.march, b_row.april, b_row.may, b_row.june, b_row.july, b_row.august, b_row.september, b_row.october, b_row.november, b_row.december]
        b_arr.each_with_index { |i,j| b_arr[j] = 0 if i.nil? }
        a_arr = [a_row.january, a_row.february, a_row.march, a_row.april, a_row.may, a_row.june, a_row.july, a_row.august, a_row.september, a_row.october, a_row.november, a_row.december]
        a_arr.each_with_index { |i,j| a_arr[j] = 0 if i.nil? }
        b_ytd_arr = Array.new(12,0)
        a_ytd_arr = Array.new(12,0)
        0.upto(11) do |ind|
          0.upto(ind) do |sub|
            b_ytd_arr[ind] += b_arr[sub]
            a_ytd_arr[ind] += a_arr[sub]
          end unless ind == 0
        end
        var_arr = []
        per_arr = []
        var_ytd_arr = []
        per_ytd_arr = []
        0.upto(11) do |indx|
          unless type.empty?
            var_arr[indx] = find_income_or_expense(itr) ? (b_arr[indx].to_f - a_arr[indx].to_f) : (a_arr[indx].to_f -  b_arr[indx].to_f)
            var_ytd_arr[indx] = find_income_or_expense(itr) ? (b_ytd_arr[indx].to_f - a_ytd_arr[indx].to_f) : (a_ytd_arr[indx].to_f -  b_ytd_arr[indx].to_f)
          else
            var_arr[indx] =  b_arr[indx].to_f - a_arr[indx].to_f
            var_ytd_arr[indx] =  b_ytd_arr[indx].to_f - a_ytd_arr[indx].to_f
          end
          per_arr[indx] =  (var_arr[indx] * 100) / b_arr[indx].to_f
          per_ytd_arr[indx] =  (var_ytd_arr[indx] * 100) / b_ytd_arr[indx].to_f
          if  b_arr[indx].to_f==0
            per_arr[indx] = ( a_arr[indx].to_f == 0 ? 0 : -100 )
          end
          if  b_ytd_arr[indx].to_f==0
            per_ytd_arr[indx] = ( a_ytd_arr[indx].to_f == 0 ? 0 : -100 )
          end
          per_arr[indx]= 0.0 if per_arr[indx].to_f.nan?
          per_ytd_arr[indx]= 0.0 if per_ytd_arr[indx].to_f.nan?
        end
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_amt')
        pf.january= var_arr[0];pf.february=var_arr[1];pf.march=var_arr[2];pf.april=var_arr[3];pf.may=var_arr[4];pf.june=var_arr[5];pf.july=var_arr[6];pf.august=var_arr[7];pf.september=var_arr[8];pf.october=var_arr[9];pf.november=var_arr[10];pf.december=var_arr[11];pf.save
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_per')
        pf.january= per_arr[0];pf.february=per_arr[1];pf.march=per_arr[2];pf.april=per_arr[3];pf.may=per_arr[4];pf.june=per_arr[5];pf.july=per_arr[6];pf.august=per_arr[7];pf.september=per_arr[8];pf.october=per_arr[9];pf.november=per_arr[10];pf.december=per_arr[11];pf.save

        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'b_ytd')
        pf.january= b_ytd_arr[0];pf.february=b_ytd_arr[1];pf.march=b_ytd_arr[2];pf.april=b_ytd_arr[3];pf.may=b_ytd_arr[4];pf.june=b_ytd_arr[5];pf.july=b_ytd_arr[6];pf.august=b_ytd_arr[7];pf.september=b_ytd_arr[8];pf.october=b_ytd_arr[9];pf.november=b_ytd_arr[10];pf.december=b_ytd_arr[11];pf.save
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'c_ytd')
        pf.january= a_ytd_arr[0];pf.february=a_ytd_arr[1];pf.march=a_ytd_arr[2];pf.april=a_ytd_arr[3];pf.may=a_ytd_arr[4];pf.june=a_ytd_arr[5];pf.july=a_ytd_arr[6];pf.august=a_ytd_arr[7];pf.september=a_ytd_arr[8];pf.october=a_ytd_arr[9];pf.november=a_ytd_arr[10];pf.december=a_ytd_arr[11];pf.save

        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_amt_ytd')
        pf.january= var_ytd_arr[0];pf.february=var_ytd_arr[1];pf.march=var_ytd_arr[2];pf.april=var_ytd_arr[3];pf.may=var_ytd_arr[4];pf.june=var_ytd_arr[5];pf.july=var_ytd_arr[6];pf.august=var_ytd_arr[7];pf.september=var_ytd_arr[8];pf.october=var_ytd_arr[9];pf.november=var_ytd_arr[10];pf.december=var_ytd_arr[11];pf.save
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_per_ytd')
        pf.january= per_ytd_arr[0];pf.february=per_ytd_arr[1];pf.march=per_ytd_arr[2];pf.april=per_ytd_arr[3];pf.may=per_ytd_arr[4];pf.june=per_ytd_arr[5];pf.july=per_ytd_arr[6];pf.august=per_ytd_arr[7];pf.september=per_ytd_arr[8];pf.october=per_ytd_arr[9];pf.november=per_ytd_arr[10];pf.december=per_ytd_arr[11];pf.save
        #PropertyFinancialPeriod.create(:source_id => itr.id, :source_type=> itr.class.to_s, :pcb_type=>'var_per', :january=> per_arr[0], :february=>per_arr[1], :march=>per_arr[2], :april=>per_arr[3], :may=>per_arr[4], :june=>per_arr[5], :july=>per_arr[6], :august=>per_arr[7], :september=>per_arr[8], :october=>per_arr[9], :november=>per_arr[10], :december=>per_arr[11])
      end
    end
  end

  def wres_find_income_or_expense(rec)
    if rec.title.downcase.match(/capital expenditure/) or rec.title.downcase.match(/expense/) or rec.title.downcase.match(/others/)
      true
    else
      unless rec.parent_id.nil?
        find_income_or_expense( IncomeAndCashFlowDetail.find(rec.parent_id) )
      else
        false
      end
    end
  end

  def find_income_or_expense(rec)
    if rec.title.downcase.match(/capital expenditure/) or rec.title.downcase.match(/expenses/)
      true
    else
      unless rec.parent_id.nil?
        find_income_or_expense( IncomeAndCashFlowDetail.find(rec.parent_id) )
      else
        false
      end
    end
  end

  def explanation_required_property(real_estate_property, month_det = nil, year_det = nil)
    constr = real_estate_property.variance_threshold.nil? ?  real_estate_property.portfolio.portfolio_type : real_estate_property.variance_threshold
    if constr.and_or == "and"
      qry = "SELECT ic.* FROM (
	              SELECT pf.source_id psid
	              FROM
            		 property_financial_periods pf
	              WHERE
	             	  pf.source_id IN (SELECT ic.id FROM income_and_cash_flow_details ic WHERE ic.year = #{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id= #{real_estate_property.id} ) AND
		              ((pf.pcb_type = 'var_amt' AND (pf.#{month_det}< -#{constr.variance_amount.nil? ? 0 : constr.variance_amount} or pf.#{month_det} > #{constr.variance_amount.nil? ? 0 : constr.variance_amount})) OR (pf.pcb_type = 'var_per' AND (pf.#{month_det}< -#{constr.variance_percentage.nil? ? 0 : constr.variance_percentage} or pf.#{month_det} > #{constr.variance_percentage.nil? ? 0 : constr.variance_percentage})))
	                GROUP BY pf.source_id
		              HAVING COUNT(pf.source_id) >= 2
                  ) kk
             LEFT JOIN income_and_cash_flow_details ic
             ON ic.id = kk.psid WHERE ic.year = #{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id=#{real_estate_property.id};"
    elsif constr.and_or == "or"
      qry = "SELECT ic.* FROM ( SELECT DISTINCT pf.source_id psid  FROM  property_financial_periods pf WHERE pf.source_id IN (SELECT ic.id FROM income_and_cash_flow_details ic WHERE ic.year = #{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id=#{real_estate_property.id} ) AND ((pf.pcb_type = 'var_amt' AND pf.#{month_det} < -#{constr.variance_amount}) OR (pf.pcb_type = 'var_per' AND pf.#{month_det} < -#{constr.variance_percentage})) ) kk  LEFT JOIN income_and_cash_flow_details ic  ON ic.id = kk.psid WHERE ic.year=#{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id=#{real_estate_property.id};"
    end
    expl_required = IncomeAndCashFlowDetail.find_by_sql(qry)
    expl_required.select{|i| i.tool_tip = wres_and_swig_path_for_items(i.id) if !wres_and_swig_path_for_items(i.id).nil? }
  end

  def explanation_required_property_ytd(real_estate_property, month_det = nil, year_det = nil)
    constr = real_estate_property.variance_threshold.nil? ?  real_estate_property.portfolio.portfolio_type : real_estate_property.variance_threshold
    if constr.and_or_ytd == "and"
      qry = "SELECT ic.* FROM (
	              SELECT pf.source_id psid
	              FROM
            		 property_financial_periods pf
	              WHERE
	             	  pf.source_id IN (SELECT ic.id FROM income_and_cash_flow_details ic WHERE ic.year = #{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id= #{real_estate_property.id} ) AND
		              ((pf.pcb_type = 'var_amt_ytd' AND (pf.#{month_det}< -#{constr.variance_amount_ytd.nil? ? 0 : constr.variance_amount_ytd} or pf.#{month_det} > #{constr.variance_amount_ytd.nil? ? 0 : constr.variance_amount_ytd})) OR (pf.pcb_type = 'var_per_ytd' AND (pf.#{month_det}< -#{constr.variance_percentage_ytd.nil? ? 0 : constr.variance_percentage_ytd} or pf.#{month_det} > #{constr.variance_percentage_ytd.nil? ? 0 : constr.variance_percentage_ytd})))
	                GROUP BY pf.source_id
		              HAVING COUNT(pf.source_id) >= 2
                  ) kk
             LEFT JOIN income_and_cash_flow_details ic
             ON ic.id = kk.psid WHERE ic.year = #{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id=#{real_estate_property.id};"
    elsif constr.and_or_ytd == "or"
      qry = "SELECT ic.* FROM ( SELECT DISTINCT pf.source_id psid  FROM  property_financial_periods pf WHERE pf.source_id IN (SELECT ic.id FROM income_and_cash_flow_details ic WHERE ic.year = #{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id=#{real_estate_property.id} ) AND ((pf.pcb_type = 'var_amt_ytd' AND (pf.#{month_det} < -#{constr.variance_amount_ytd} or pf.#{month_det} > #{constr.variance_amount_ytd})) OR (pf.pcb_type = 'var_per_ytd' AND (pf.#{month_det} < -#{constr.variance_percentage_ytd} or pf.#{month_det} > #{constr.variance_percentage_ytd} ))) ) kk  LEFT JOIN income_and_cash_flow_details ic  ON ic.id = kk.psid WHERE ic.year=#{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id=#{real_estate_property.id};"
    end
    expl_required = IncomeAndCashFlowDetail.find_by_sql(qry)
    expl_required.select{|i| i.tool_tip = wres_and_swig_path_for_items(i.id) if !wres_and_swig_path_for_items(i.id).nil? }
  end

  def explanation_required_expenditures(real_estate_property, month_det = nil, year_det = nil)
    month_row = ['','january','february','march','april','may','june','july','august','september','october','november','december']
    constr = real_estate_property.variance_threshold.nil? ?  real_estate_property.portfolio.portfolio_type : real_estate_property.variance_threshold
    qry = "select ci.* from property_capital_improvements ci, property_financial_periods pi  
           where ci.real_estate_property_id = #{real_estate_property.id}
           and ci.year= #{year_det} and ci.month = #{month_det}
           and pi.source_id = ci.id and pi.source_type = 'PropertyCapitalImprovement'
           and pi.pcb_type = 'var_amt'
           and pi.#{month_row[month_det]} and ci.tenant_name in ('TOTAL TENANT IMPROVEMENTS','TOTAL BUILDING IMPROVEMENTS','TOTAL LEASING COMMISSIONS','TOTAL LEASE COSTS','TOTAL NET LEASE COSTS','TOTAL CAPITAL EXPENDITURES')
               and (pi.#{month_row[month_det]} < - #{constr.cap_exp_variance.nil? ? 0 : constr.cap_exp_variance } or pi.#{month_row[month_det]} > #{constr.cap_exp_variance.nil? ? 0 : constr.cap_exp_variance });"
    PropertyCapitalImprovement.find_by_sql(qry)
  end

  def explanation_required_expenditures_ytd(real_estate_property, month_det = nil, year_det = nil)
    month_row = ['','january','february','march','april','may','june','july','august','september','october','november','december']
    constr = real_estate_property.variance_threshold.nil? ?  real_estate_property.portfolio.portfolio_type : real_estate_property.variance_threshold
    qry = "select ci.* from property_capital_improvements ci, property_financial_periods pi
           where ci.real_estate_property_id = #{real_estate_property.id} and ci.year= #{year_det}
           and ci.month = #{month_det} and pi.source_id = ci.id and pi.source_type = 'PropertyCapitalImprovement'
           and pi.pcb_type = 'var_amt_ytd' and ci.tenant_name in ('TOTAL TENANT IMPROVEMENTS','TOTAL BUILDING IMPROVEMENTS','TOTAL LEASING COMMISSIONS','TOTAL LEASE COSTS','TOTAL NET LEASE COSTS','TOTAL CAPITAL EXPENDITURES')
            and (pi.#{month_row[month_det]} < - #{constr.cap_exp_variance_ytd.nil? ? 0 : constr.cap_exp_variance_ytd } or pi.#{month_row[month_det]} > #{constr.cap_exp_variance_ytd.nil? ? 0 : constr.cap_exp_variance_ytd });"
    PropertyCapitalImprovement.find_by_sql(qry)
  end

  def find_name_of_the_parents_parent(id)
    fol = Folder.find_by_id(id)
    fol.nil? ? '' : fol.name
  end

  def wres_parsing_cash_flow_forecast(doc)
    actual_end = nil
    real_estate_property_id = doc.real_estate_property_id
    year = ''
    act_row  = Array.new(12,nil)
    bud_row  = Array.new(12,nil)
    title_definer = []
    parent_definer = []
    blockers = ['SUBTOTAL RENT','TOTAL OPERATING INCOME','TOTAL OPERATING EXPENSES','TOTAL CASH ADJUSTMENTS']
    book = Excel.new "#{RAILS_ROOT}/public#{doc.public_filename}"
    book.default_sheet = book.sheets[0]
    xl_name = book.cell(1,1)
    if xl_name.downcase.gsub(/[^a-z]/,'').include?("reportcashflowforecast")
      year = book.cell(4,2).to_s.split('/').last.to_i
      3.upto(65) do |row|
        next if book.cell(row,1).nil? && book.cell(row,2).nil?
        unless (book.cell(row,1).nil? || book.cell(row,1).blank?) && (book.cell(row,2).nil? || book.cell(row,2).blank? )
          if (book.cell(row,1).nil? || book.cell(row,1).blank?) && book.cell(row,2) == 'Actual'
            3.upto(13) do |col|
              actual_end = col - 1 if book.cell(row,col).include?('Forecast')
            end
            next
          end
          if ((!book.cell(row,1).nil? || !book.cell(row,1).blank?) && (book.cell(row,2).nil? || book.cell(row,2).blank? ))
            title_definer.push(book.cell(row,1))
            parent_definer.push(store_values_for_cash_flow_forcast(nil, real_estate_property_id, title_definer.last, year, act_row, bud_row))
            next
          end
          if ['TOTAL CASH INCREASE (DECREASE)','BEGINNING CASH','ENDING CASH'].any?{|i|book.cell(row,1).to_s.include?(i)}
            (2..actual_end).each_with_index do |col,ind|
              act_row[ind] =  book.celltype(row,col) == :string ? get_correct_value(book.cell(row, col)) : book.cell(row, col)
            end
            ((actual_end + 1)..13).each do |col|
              bud_row[col-2] = (book.celltype(row,col) == :string) ? get_correct_value(book.cell(row, col)) : book.cell(row, col)
            end
            store_values_for_cash_flow_forcast(nil, real_estate_property_id, book.cell(row,1), year, act_row, bud_row)
            eval("act_row  = Array.new(12,nil);bud_row = Array.new(12,nil)")
            #PropertyCashFlowForecast.create(:title=>)

          elsif blockers.any?{|i|book.cell(row,1).to_s.include?(i)}
            update_for = parent_definer.last
            parent_definer.pop; title_definer.pop
            store_values_for_cash_flow_forcast(parent_definer.last, real_estate_property_id, book.cell(row,1), year, act_row, bud_row, update_for)
            eval("act_row  = Array.new(12,nil);bud_row = Array.new(12,nil)");

          elsif (!book.cell(row,1).nil? || !book.cell(row,1).blank?)
            if (book.cell(row,1).include?('Contingency') || book.cell(row,1).include?('Maintenance Projects'))
              set_title = book.cell(row,1).include?('Contingency') ? "OTHER EXPENSES" :"OTHERS"
              title_definer.push(set_title)
              parent_definer.push(store_values_for_cash_flow_forcast(nil, real_estate_property_id, title_definer.last, year, act_row, bud_row))
            end
            (2..actual_end).each_with_index do |col,ind|
              act_row[ind] =  book.celltype(row,col) == :string ? get_correct_value(book.cell(row, col)) : book.cell(row, col)
            end
            ((actual_end + 1)..13).each do |col|
              bud_row[col-2] = (book.celltype(row,col) == :string) ? get_correct_value(book.cell(row, col)) : book.cell(row, col)
            end
            store_values_for_cash_flow_forcast(parent_definer.last, real_estate_property_id, book.cell(row,1), year, act_row, bud_row)
            eval("act_row  = Array.new(12,nil);bud_row = Array.new(12,nil)")
            if (book.cell(row,1).include?('Real Estate Taxes')||(book.cell(row,1).include?('Interest Expense - 1st')))
              update_for = parent_definer.last
              parent_definer.pop; title_definer.pop
              store_values_for_cash_flow_forcast(parent_definer.last, real_estate_property_id, book.cell(row,1), year, act_row, bud_row, update_for)
            end
          end
        end
      end
    end
  end

  def get_correct_value(val)
    if ['-','(',')'].any?{|i| val.include?(i)}
      ("-" + val.gsub("(",'').gsub(")","").gsub("-","").gsub(',','')).to_d
    else
      val.to_d
    end
  end

  def store_values_for_cash_flow_forcast(parent_id, rid, title, year, act, bud, for_parent = 0)
    unless for_parent.zero?
      forecast = PropertyCashFlowForecast.find(for_parent);
      qry = "select sum(january) a, sum(february) b, sum(march) c, sum(april) d,sum(may) e,sum(june) f,sum(july) g,sum(august) h,sum(september) i,sum(october) jth,sum(november) k,sum(december) l from property_financial_periods where source_id IN(select id from property_cash_flow_forecasts where parent_id = #{for_parent}) and source_type = 'PropertyCashFlowForecast' and pcb_type = 'b';"
      val = PropertyFinancialPeriod.find_by_sql(qry).first
      bud = [val.a, val.b, val.c ,val.d ,val.e ,val.f ,val.g ,val.h ,val.i ,val.jth ,val.k, val.l]
      qry.gsub!('\'b\'','\'c\'')
      val = PropertyFinancialPeriod.find_by_sql(qry).first
      act = [val.a, val.b, val.c ,val.d ,val.e ,val.f ,val.g ,val.h ,val.i ,val.jth ,val.k, val.l]
    else
      forecast = PropertyCashFlowForecast.find_or_initialize_by_resource_id_and_resource_type_and_title_and_year(rid, 'RealEstateProperty', title, year);
    end
    forecast.parent_id = parent_id
    forecast.user_id = params[:user_id] ? params[:user_id] : current_user.id
    forecast.save

    budget = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(forecast.id, forecast.class.to_s, 'b')
    budget.january = bud[0] if budget.january.nil? ; budget.february = bud[1] if budget.february.nil? ; budget.march = bud[2] if budget.march.nil?
    budget.april = bud[3] if budget.april.nil? ; budget.may = bud[4] if budget.may.nil? ; budget.june = bud[5] if budget.june.nil?
    budget.july = bud[6] if budget.july.nil? ; budget.august = bud[7] if budget.august.nil? ; budget.september = bud[8] if budget.september.nil?
    budget.october = bud[9] if budget.october.nil? ; budget.november = bud[10] if budget.november.nil? ; budget.december = bud[11] if budget.december.nil?
    budget.save
    actual = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(forecast.id, forecast.class.to_s, 'c')
    actual.january = act[0] if actual.january.nil? ; actual.february = act[1] if actual.february.nil? ; actual.march = act[2] if actual.march.nil?
    actual.april = act[3] if actual.april.nil? ; actual.may = act[4] if actual.may.nil? ; actual.june = act[5] if actual.june.nil?
    actual.july = act[6] if actual.july.nil? ; actual.august = act[7] if actual.august.nil? ; actual.september = act[8] if actual.september.nil?
    actual.october = act[9] if actual.october.nil? ; actual.november = act[10] if actual.november.nil? ; actual.december = act[11] if actual.december.nil?
    actual.save
    return forecast.id
  end

  def calculate_var_values(record)
    val = 0
    ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"].each do |i|
      val = val + record.send(:"#{i}") unless record.send(:"#{i}").nil?
    end
    val.zero? ? nil : val
  end

  def wres_explanation_required_property(real_estate_property, month_det = nil, year_det = nil)
    constr = real_estate_property.variance_threshold.nil? ?  real_estate_property.portfolio.portfolio_type : real_estate_property.variance_threshold
    if constr.and_or == "and"
      qry = "SELECT ic.* FROM (
	              SELECT pf.source_id psid
	              FROM
            		 property_financial_periods pf
	              WHERE
	             	  pf.source_id IN (SELECT ic.id FROM property_cash_flow_forecasts ic WHERE ic.year = #{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id= #{real_estate_property.id} ) AND
		              ((pf.pcb_type = 'var_amt' AND pf.#{month_det}< -#{constr.variance_amount.nil? ? 0 : constr.variance_amount}) OR (pf.pcb_type = 'var_per' AND pf.#{month_det}< -#{constr.variance_percentage.nil? ? 0 : constr.variance_percentage}))
	                GROUP BY pf.source_id
		              HAVING COUNT(pf.source_id) >= 2
                  ) kk
             LEFT JOIN property_cash_flow_forecasts ic
             ON ic.id = kk.psid WHERE ic.year = #{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id=#{real_estate_property.id};"
    elsif constr.and_or == "or"
      qry = "SELECT ic.* FROM ( SELECT DISTINCT pf.source_id psid  FROM  property_financial_periods pf WHERE pf.source_id IN (SELECT ic.id FROM property_cash_flow_forecasts ic WHERE ic.year = #{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id=#{real_estate_property.id} ) AND ((pf.pcb_type = 'var_amt' AND pf.#{month_det} < -#{constr.variance_amount}) OR (pf.pcb_type = 'var_per' AND pf.#{month_det} < -#{constr.variance_percentage})) ) kk  LEFT JOIN property_cash_flow_forecasts ic  ON ic.id = kk.psid WHERE ic.year=#{year_det} AND ic.resource_type = 'RealEstateProperty' AND ic.resource_id=#{real_estate_property.id};"
    end
    expl_required = PropertyCashFlowForecast.find_by_sql(qry)
  end

	def lengthy_word_simplification(word, begin_num=15, end_num=10, sep_char=".",sep_char_repeat=3)
    if word !=nil
      if (begin_num + end_num + sep_char_repeat + 2) < word.length
        return word.slice(0,begin_num).to_s+(sep_char * sep_char_repeat)+word.slice(word.length-end_num,end_num)
      else
        return word
      end
    end
  end

  def  update_partials(page)
    if current_user.has_role?("Shared User") && session[:role] == 'Shared User'
      if params[:folder_id]
        @folder = Folder.find_by_id(params[:folder_id])
      end
    end
		if @go_to_collab_hub
      #      page.redirect_to "/collaboration_hub"
      page.replace_html "show_assets_list",:partial=>'/collaboration_hub/my_files_assets_list'

    elsif params[:call_from_prop_files] == "true"
      page.replace_html 'show_assets_list',:partial=>"properties_and_files"
      #elsif params[:list] == "shared_list"
      #page.replace_html "show_assets_list2",:partial=>'/properties/shared_folders_docs'
      #elsif params[:shared_file] == "true"
      # page.replace_html "show_assets_list2",:partial=>'assets_list'
      #page << 'jQuery("#show_assets_list").hide();'
      #page << 'jQuery("#show_assets_list_my_files").hide();'
      #page << 'jQuery("#show_assets_list2").attr("id","show_assets_list")'
    else
      parent_n = Folder.find_by_id(@folder.parent_id) if @folder
      if parent_n && parent_n.name == "my_files" && !params[:folder_id]
        page.replace_html "show_assets_list",:partial=>'/collaboration_hub/my_files_assets_list'
        #page << 'jQuery("#show_assets_list2").hide();'
        #page << 'jQuery("#show_assets_list").hide();'
        #page << 'jQuery("#show_assets_list_my_files").attr("id","show_assets_list")'
      else
        shared_property_folder = SharedFolder.find_by_folder_id_and_user_id(@folder.id,current_user.id,:conditions=>["is_property_folder is not null and is_property_folder = true"]) if @folder && @folder.parent_id != -1
        d = SharedFolder.find_by_folder_id_and_user_id(@folder.id,current_user.id) if @folder
        if parent_n && parent_n.name == "my_files" && params[:del_files] != "true" && parent_n.parent_id == 0 || find_manage_real_estate_shared_folders('false').flatten.index(@folder)
          # page << "if(document.getElementById('show_assets_list_my_files')== null || document.getElementById('show_assets_list_my_files').style.display == 'none'){ back_replacer = 'show_assets_list' }else{ back_replacer = 'show_assets_list_my_files';}"
	        page.replace_html "show_assets_list",:partial=>'assets_list'

          #  page.replace_html "eval('back_replacer')",:partial=>'assets_list'
          #temp = page.instance_variable_get(:@lines)
          #temp[temp.size - 1] = temp.last.gsub("\"eval('back_replacer')\"", 'back_replacer');
          # page.instance_variable_set(:@lines, temp)
          #page << 'if(back_replacer == "show_assets_list_my_files"){ jQuery("#show_assets_list2").hide(); jQuery("#show_assets_list").hide(); jQuery("#show_assets_list_my_files").attr("id","show_assets_list"); jQuery("#show_assets_list ").last().remove();}'
        else
          if (params[:from_collab_task] == "true" || params[:from_task] == "true" || params[:call_for_task]) && @folder.name == "my_files" && @folder.parent_id == 0 || (@folder && @folder.parent_id != -1 &&  @folder && shared_property_folder.nil? && @folder.user_id != current_user.id && !d)
            #if current_user.has_role?("Shared User") && session[:role] == 'Shared User'
            #page.redirect_to "/shared_users"
            #else
            #page.redirect_to "/collaboration_hub"
            #end
            page.replace_html "show_assets_list",:partial=>'/collaboration_hub/my_files_assets_list'

          else
            if @folder && @folder.name == "my_files"  && @folder.parent_id == 0 && params['list'] != 'shared_list'
              # page << "if(document.getElementById('show_assets_list_my_files')== null || document.getElementById('show_assets_list_my_files').style.display == 'none'){ back_replacer = 'show_assets_list' }else{ back_replacer = 'show_assets_list_my_files';}"
              #page.replace_html "eval('back_replacer')",:partial=>'/collaboration_hub/my_files_assets_list'
              #temp = page.instance_variable_get(:@lines)
              #temp[temp.size - 1] = temp.last.gsub("\"eval('back_replacer')\"", 'back_replacer');
              #page.instance_variable_set(:@lines, temp)
			        page.replace_html "show_assets_list",:partial=>'/collaboration_hub/my_files_assets_list'
						elsif params[:list] == "shared_list"
              page.replace_html "show_assets_list2",:partial=>'assets_list'
            else
              #page << 'jQuery("#show_assets_list").show();'
              page.replace_html "show_assets_list",:partial=>'assets_list'
              #page << 'jQuery("#show_assets_list2").hide();' if @folder.parent_id == -1
              # page << 'jQuery("#show_assets_list_my_files").hide();' if @folder.parent_id == -1
              # page << 'if(jQuery("#show_assets_list ")[1]){jQuery("#show_assets_list ")[1].remove();}'
            end
          end
        end
      end
    end
  end


  def find_past_shared_folders_documents_tasks(find_deleted_folders)
    params[:asset_id] =@folder.id
 		conditions = find_deleted_folders == 'true' ?   "" : "and is_deleted = false"
    find_manage_real_estate_shared_folders('false')  if @folder.name == 'my_files' && @folder.parent_id == 0
    #to find folders,tasks,files shared to user ,then user shares that to some others
    folder_ids = (@shared_folders_real_estate && !@shared_folders_real_estate.empty?) ? @shared_folders_real_estate.collect{|f| f.id} :  []
    doc_ids = (@shared_docs_real_estate && !@shared_docs_real_estate.empty?) ? @shared_docs_real_estate.collect{|f| f.id} :  []
    task_ids =  (@shared_tasks_real_estate && !@shared_tasks_real_estate.empty?) ? @shared_tasks_real_estate.collect{|f| f.id} :  []
    #To find shared folders
    fids_in_cur_folder = Folder.find(:all,:conditions=>["(parent_id = ? or id in (?)) #{conditions}",params[:asset_id],folder_ids]).collect{|f| f.id}
    @past_shared_folders = SharedFolder.find(:all,:conditions=>["sharer_id = ? and folder_id in (?) and user_id != sharer_id",current_user.id,fids_in_cur_folder]).collect{|sf| sf.folder}.uniq
    #To find shared documents
    docids_in_cur_folder = Document.find(:all,:conditions=>["(folder_id = ? or id in (?)) #{conditions}",params[:asset_id],doc_ids]).collect{|d| d.id}
    @past_shared_docs  = SharedDocument.find(:all,:conditions=>["sharer_id = ? and document_id in (?) and user_id != sharer_id",current_user.id,docids_in_cur_folder]).collect{|sd| sd.document}.uniq
    #To find shared tasks
    tasks_in_cur_folder = Task.find(:all,:conditions=>["(folder_id = ? or id in (?)) and (temp_task != 1)",params[:asset_id],task_ids]).collect{|d| d.id}
    @past_shared_tasks = TaskCollaborator.find(:all,:conditions=>["sharer_id = ? and task_id in (?) and user_id != sharer_id",current_user.id,tasks_in_cur_folder]).collect{|st| st.task}.uniq
  end

  #Displays task status to task collaborators
	def get_task_status(collaborator, task)
		unless task.blank? && collaborator.blank?
			if task.task_type.task_name == "Review File"
				if !task.document.nil? && !task.document.comments.blank?
					comments= task.document.comments.find(:first, :conditions=>['user_id = ? and commentable_id = ?', collaborator.id, task.document.id], :order=>'created_at desc')
					if !comments.blank?
						commented_on = comments.created_at.strftime("%b %d").downcase
						return "<div class='commentbox2'>Commented on #{commented_on}</div>"
					else
						if collaborator.id == current_user.id
							return "<div class='commentbox'><a href='#' onclick=\"jQuery('#{ task.document_id.nil? ? '#text_puretask_'+task.id.to_s : '#text_task_'+task.id.to_s}').focus();return false;\">+ Add Review Comments</a></div>"
						else
							return "<div class='commentbox'>Yet to Comment/Add File</div>"
						end
					end
				else
          if collaborator.id == current_user.id
            return "<div class='commentbox'><a href='#' onclick=\"jQuery('#{ task.document_id.nil? ? '#text_puretask_'+task.id.to_s : '#text_task_'+task.id.to_s}').focus();return false;\">+ Add Review Comments</a></div>"
          else
            return "<div class='commentbox'>Yet to Comment/Add File</div>"
          end
				end
			elsif task.task_type.task_name == "Update File" || task.task_type.task_name == "Upload File"
				task_file = task.task_files.find_by_user_id_and_task_id_and_doer_file(collaborator.id, task.id, true)
				if !task_file.blank?
					updated_or_uploaded_on = task_file.updated_at.strftime("%b %d")
					if collaborator.id == current_user.id
            unless task.is_completed?
              return "<div class='commentbox2'>#{task.task_type.task_name=="Update File" ? 'Updated on '+updated_or_uploaded_on : 'Uploaded on '+updated_or_uploaded_on}</div><input type='file' name='attachment[uploaded_data]' size='15' style='margin-top: 15px;' id='doer_upload_update_file' onchange='newVal=this.value.split(/akepath/).last();if(this.value.indexOf(\"akepath\")!=-1){newVal=newVal.substring(1);};jQuery(\"#uploaded_or_updated_file\").html((newVal).length > 25 ? (newVal).substring(0,15).concat(\"...\"+(newVal).substring((newVal).length-10,(newVal).length)) : newVal );'/>
						   <a id='uploaded_or_updated_file'>#{ task_file.filename.length > 25 ? lengthy_word_simplification(task_file.filename,10,10) : task_file.filename }</a>"
            else
              return "<div class='commentbox2'>#{task.task_type.task_name=="Update File" ? 'Updated '+task_file.filename+' on '+updated_or_uploaded_on : 'Uploaded '+task_file.filename+' on '+updated_or_uploaded_on}</div><a id='uploaded_or_updated_file'  style='float: left;position: relative;padding-left: 10px;margin-top: 15px;padding-right: 10px;'>#{ task_file.filename.length > 25 ? lengthy_word_simplification(task_file.filename,10,10) : task_file.filename }</a>"
            end
					else
						return "<div class='commentbox2'>#{task.task_type.task_name=="Update File" ? 'Updated '+task_file.filename+' on '+updated_or_uploaded_on : 'Uploaded '+task_file.filename+' on '+updated_or_uploaded_on}</div>"
					end
				else
					if collaborator.id == current_user.id
            unless task.is_completed?
						  return "<div class='commentbox'>#{task.task_type.task_name=="Update File" ? 'Update File' : 'Upload File'}</div><input type='file' name='attachment[uploaded_data]' size='15' style='margin-top: 15px;' id='doer_upload_update_file' onchange='newVal=this.value.split(/akepath/).last();if(this.value.indexOf(\"akepath\")!=-1){newVal=newVal.substring(1);};jQuery(\"#uploaded_or_updated_file\").html((newVal).length > 25 ? (newVal).substring(0,15).concat(\"...\"+(newVal).substring((newVal).length-10,(newVal).length)) : newVal );'/><a id='uploaded_or_updated_file'></a>"
            else
              #return "<div class='commentbox'>#{task.task_type.task_name=="Update File" ? 'Update File' : 'Upload File'}</div><a id='uploaded_or_updated_file'></a>"
              return "<div class='commentbox'></div>"
            end
					else
            unless task.is_completed?
						return "<div class='commentbox'>#{task.task_type.task_name=="Update File" ? 'yet to update' : 'yet to upload'}</div>"
            else
            return "<div class='commentbox'></div>"
            end
					end
				end
			elsif task.task_type.task_name == "General" || task.task_type.task_name == "Discussion"
        get_general_discussion_task_status(task,collaborator.id)
      elsif task.task_type_id == 5
        explained_on = get_explanation_date(@document.id,params[:month],collaborator.id)
        if explained_on
          "<div class='commentbox2'>Explained on #{explained_on}</div>"
        else
          if collaborator.id == current_user.id
            "<div class='commentbox'>Explain the variances below</div>"
          else
            "<div class='commentbox'>Explanations Pending</div>"
          end
        end
			end
		end
	end
  
  def get_explanation_date(document_id,month,collaborator_id)
    if params[:from_assign_task] == 'cap_exp'
      cec = CapitalExpenditureExplanation.find(:last, :conditions=>['document_id = ? and month = ? and user_id = ?', document_id, month, collaborator_id])
      explained_on = cec.updated_at.strftime("%b %d").downcase if cec
    else
      ice = IncomeCashFlowExplanation.find(:last, :conditions=>['document_id = ? and month = ? and user_id = ?', document_id, month, collaborator_id])
      explained_on = ice.updated_at.strftime("%b %d").downcase if ice
    end
  end

	#Displays task status to task owner
  def get_task_status_owner(collaborator_id,task_id)
		task = Task.find_by_id(task_id)
		unless task.blank?
			if task.task_type.task_name == "Review File"
				if !task.document.nil? && !task.document.comments.blank?
					comments= task.document.comments.find(:first, :conditions=>['user_id = ? and commentable_id = ?', collaborator_id, task.document.id], :order=>'created_at desc')
					if !comments.blank?
						commented_on = comments.created_at.strftime("%b %d").downcase
						"<div class='commentbox2'>Commented on #{commented_on}</div>"
					else
						"<div class='commentbox'>Yet to Comment</div>"
					end
				else
					"<div class='commentbox'>Yet to Comment</div>"
				end
			elsif task.task_type.task_name == "Update File" || task.task_type.task_name == "Upload File"
				task_file = task.task_files.find_by_user_id_and_task_id_and_doer_file(collaborator_id, task.id, true)
				if !task_file.blank?
					updated_or_uploaded_on = task_file.updated_at.strftime("%b %d")
					"<div class='commentbox2'>#{task.task_type.task_name=="Update File" ? 'Updated on '+updated_or_uploaded_on : 'Uploaded file on '+updated_or_uploaded_on}<br/><a href='#{dwn_fl_path(task_file.id, :type=>task_file.class)}' style='margin-top:3px;'>#{lengthy_word_simplification(task_file.filename,10,10)}</a></div>"
				elsif TaskCollaborator.finding_coll_by_user_id_and_task_id(collaborator_id,task_id)
            "<div class='commentbox2'>Completion Requested on #{get_completion_requested_status(task_id)}</div>" if TaskCollaborator.finding_coll_by_user_id_and_task_id(collaborator_id,task_id).is_completion_requested?
        else
          unless task.is_completed?
					"<div class='commentbox'>#{task.task_type.task_name=="Update File" ? 'yet to update' : 'yet to upload'}</div>"
          else
          "<div class='commentbox'></div>"
          end
				end
			elsif task.task_type.task_name == "General" || task.task_type.task_name == "Discussion"
        get_general_discussion_task_status(task,collaborator_id)
			elsif task.task_type_id == 5
        explained_on = get_explanation_date(@document.id,params[:month],collaborator_id)
        if explained_on
          "<div class='commentbox2'>Explained on #{explained_on}</div>"
        else
          if collaborator_id == current_user.id
            "<div class='commentbox'>Explain the variances below</div>"
          else
            "<div class='commentbox'>Explanations Pending</div>"
          end
        end
			end
		end
  end
  
  def get_general_discussion_task_status(task,collaborator_id)
    if !task.comments.blank? || (!task.document.nil? && !task.document.comments.blank?)
      if task.document.nil?
        comments= task.comments.find(:first, :conditions=>['user_id = ? and commentable_id = ?', collaborator_id, task.id], :order=>'created_at desc')
      else
        comments= task.document.comments.find(:first, :conditions=>['user_id = ? and commentable_id = ?', collaborator_id, task.document.id], :order=>'created_at desc')
      end
      if !comments.blank?
        commented_on = comments.created_at.strftime("%b %d").downcase
        "<div class='commentbox2'>Commented on #{commented_on}</div>"
      else
        unless task.is_completed?
        "<div class='commentbox'>Yet to Comment/Add File</div>"
        else
          "<div class='commentbox'></div>"
        end
      end
    elsif task.task_files.count > 0
      task_file = task.task_files.find(:first, :conditions=>['user_id=?',collaborator_id], :order=>'created_at desc')
      if task_file 
        added_on =task_file.created_at.strftime("%b %d").downcase
        "<div class='commentbox2'>File(s) added on #{added_on}</div>"
      else
        "<div class='commentbox'>Yet to Comment/Add File</div>"
      end
    elsif task.task_documents.count > 0
      task_document = task.task_documents.find(:first, :conditions=>['user_id =?',collaborator_id],:order=>'created_at desc')
      if task_document
        added_on = task_document.created_at.strftime("%b %d").downcase
        "<div class='commentbox2'>File(s) added on #{added_on}</div>"
      else
        "<div class='commentbox'>Yet to Comment/Add File</div>"
      end
    else
      unless task.is_completed?
        if TaskCollaborator.finding_coll_by_user_id_and_task_id(collaborator_id,task.id)
            "<div class='commentbox2'>Completion Requested on #{get_completion_requested_status(task.id)}</div>" if TaskCollaborator.finding_coll_by_user_id_and_task_id(collaborator_id,task.id).is_completion_requested?
        else
        "<div class='commentbox'>Yet to Comment/Add File</div>"
        end
      else
        "<div class='commentbox'></div>"
      end
    end
  end

  def comment_display(task,task_files,task_documents)
    if !task_files.empty?
      added_on = task_files.find(:first).created_at.strftime("%b %d").downcase
    elsif !task_documents.empty?
      added_on = task_documents.find(:first).created_at.strftime("%b %d").downcase
    end
    unless !(task_files.empty? && task_documents.empty?)
      return "<div class='commentbox'><a href='#' onclick=\"jQuery('#{ task.document_id.nil? ? '#text_puretask_'+task.id.to_s : '#text_task_'+task.id.to_s}').focus();return false;\">Add Comment / File</a></div>"
    else
      return "<div class='commentbox2'>File uploaded on #{added_on}</div>"
    end
  end

  def get_completion_requested_status(task_id)
		TaskCollaborator.find_by_task_id(task_id).created_at.strftime("%b %d")#.downcase
  end
  def get_completion_requested_file_upload(collaborator_id,task_id)
    task = Task.find_by_id(task_id)
		unless task.blank?
      if task.task_type.task_name == "Update File" || task.task_type.task_name == "Upload File"
				task_file = task.task_files.find_by_user_id_and_task_id_and_doer_file(collaborator_id, task.id, true)
				if !task_file.blank?
					updated_or_uploaded_on = task_file.updated_at.strftime("%b %d")
					"<br/><br/><a href='#{dwn_fl_path(task_file.id, :type=>task_file.class)}' style='margin-top:3px; color:#025B8D'>#{lengthy_word_simplification(task_file.filename,10,10)}</a>"
				end
      end
    end
  end

  def find_by_parent_id_and_portfolio_id(id)
    return Folder.find_by_parent_id_and_portfolio_id(-1,id)
  end

  def find_by_id(parent_id)
    return Folder.find_by_id(parent_id)
  end

  def find_folder(id)
    return Folder.find(id)
  end

  def find_document(id)
    return DocumentName.find(id)
  end

  def find_task_type(task_type_id)
    return TaskType.find(task_type_id)
  end

  def find_all_task_type()
    return TaskType.find(:all, :conditions => ["task_name != 'Explain Variances'"])
  end
  def find_all_task_types_not_in_variance()
    return TaskType.find(:all, :conditions => ["task_name NOT IN('Explain Variances','Review File','Update File')"])
  end

  def find_income_and_cash_flow_detail(note,year)
    return IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and resource_id=? and year=?",'operating income',note,year])
  end

	def is_swig_to_wres_share
		@wres_users = []
		unless @member_emails.blank?
			@member_emails.each do |email|
				user = User.find_by_email(email)
				if  !user.blank? && user.client_type == "wres"
					@wres_users << email
				end
			end
		end
		if @wres_users.count > 0
			true
		elsif @wres_users.count == 0
			false
		end
	end

  def is_wres_to_swig_share
		@swig_users = []
		unless @member_emails.blank?
			@member_emails.each do |email|
				user = User.find_by_email(email)
				if  !user.blank? && user.client_type == "swig"
					@swig_users << email
				end
			end
		end
		if @swig_users.count > 0
			true
		elsif @swig_users.count == 0
			false
		end
	end


  #forms a hash for loan details in add a property
  def form_hash_for_loan_details
    #max_month_year = PropertyDebtSummary.find(:all,:conditions =>["real_estate_property_id = #{@property.id}"],:select=>"max(month) as month,max(year) as year")[0]
		if params[:from_debt_summary] == 'true' && params[:property_id]
			@property = RealEstateProperty.find_by_id(params[:property_id]) if @property.nil?
		end
    debtsummary = PropertyDebtSummary.find(:all,:conditions =>["real_estate_property_id = ?",@property.id])
    @loan_hash = []
    if @add_loan_details == true || @edit_loan_details == true
      for i in 0..2
        if check_if_loan_value_exists(params,i)
          @loan_hash[i] ={'Lender' =>params[:Lender]["#{i}"],'Guarantors' =>params[:Guarantors]["#{i}"],'Loan Amount' =>params[:Loan_Amount]["#{i}"],'Loan Balance' =>params[:Loan_Balance]["#{i}"],'Term' =>params[:Term]["#{i}"] , 'Date of Promissory Note' => params[:Date_of_Promissory_Note]["#{i}"],'Maturity' => params[:Maturity]["#{i}"],'Interest Rate' => params[:Interest_Rate]["#{i}"],'Payments' => params[:Payments]["#{i}"],'Tax Escrow Payments'=>params[:Tax_Escrow_Payments]["#{i}"],'Replacement Reserve'=> params[:Replacement_Reserve]["#{i}"],'Tenant Improvements and Leasing Commission Reserve'=>params[:Tenant_Improvements_and_Leasing_Commission_Reserve]["#{i}"],'Prepayment'=>params[:Prepayment]["#{i}"]}
        end
      end
    elsif !debtsummary.empty?
      i=0
      summary_array =  debtsummary.each_slice(13).to_a
      summary_array.each do |s|
        @loan_hash[i] = {}
        s.each do |d|
          @loan_hash[i]["#{d.category}"] = d.description
        end
        i += 1
      end
      @edit_loan_details = true
    else
      @loan_hash[0] ={'Lender' =>"",'Guarantors' =>"",'Loan Amount' => "",'Loan Balance' => "",'Term' => "", 'Date of Promissory Note' => "",'Maturity' => "",'Interest Rate' => "",'Payments' => "",'Tax Escrow Payments'=>"",'Replacement Reserve'=> "",'Tenant Improvements and Leasing Commission Reserve'=>"",'Prepayment'=>""}
      @add_loan_details = true
    end
  end



  def check_if_loan_value_exists(params,loan_number)
    loan_number = loan_number.to_s
    if (params[:Lender][loan_number] != nil && params[:Lender][loan_number].strip != "") ||  (params[:Guarantors][loan_number] != nil && params[:Guarantors][loan_number].strip != "") || (params[:Loan_Amount][loan_number]   != nil  && params[:Loan_Amount][loan_number].strip   != "" ) || (params[:Loan_Balance][loan_number] != nil && params[:Loan_Balance][loan_number].strip != "") || (params[:Term][loan_number]  != nil && params[:Term][loan_number].strip  != "" ) || (params[:Date_of_Promissory_Note][loan_number]  != nil && params[:Date_of_Promissory_Note][loan_number].strip  != "") || (params[:Maturity][loan_number]  != nil && params[:Maturity][loan_number].strip  != "") || (params[:Interest_Rate][loan_number]  != nil && params[:Interest_Rate][loan_number].strip  != "" ) || (params[:Payments][loan_number]  != nil && params[:Payments][loan_number].strip  != "" ) || (params[:Tax_Escrow_Payments][loan_number]  != nil && params[:Tax_Escrow_Payments][loan_number].strip != "") || (params[:Replacement_Reserve][loan_number] != nil && params[:Replacement_Reserve][loan_number].strip   != "") || (params[:Tenant_Improvements_and_Leasing_Commission_Reserve][loan_number]  != nil && params[:Tenant_Improvements_and_Leasing_Commission_Reserve][loan_number].strip  != "" ) || (params[:Prepayment][loan_number] != nil && params[:Prepayment][loan_number].strip != "" )
      return true
    else
      return false
    end
  end

  def update_page_after_adding_physical_details(page,view,active_title)
		page.hide 'modal_container'
		page.hide 'modal_overlay'
		page.replace_html "head_for_titles", :partial => "/properties/head_for_titles/"
		page.call "active_title","#{active_title}"
		page.replace_html "overview", :partial => "#{view}"
		page.call 'load_completer'
  end


	def lease_exp(note_id,month,year,type)
		@exp=LeasesExplanation.find(:first, :conditions=>['month = ? and year = ? and real_estate_property_id = ? and occupancy_type = ?', month, year,note_id,type], :select => "explanation,user_id,id")
	end

  def check_repeat_task(task)
    ((task.repeat_task.task_created_count < task.repeat_task.repeat_count ) ? true : false) if task.repeat_task
  end
  def document_row_image_link(t)
    if !t.is_deleted
      if t.user_id != current_user.id || (@past_shared_docs && @past_shared_docs.index(t))
        "<img src='/images/#{find_content_type(t,'shared','false')}' width='38' height='37' onclick='make_downloads(#{t.id})' style='cursor: pointer;' />"
      else
        "<img src='/images/#{find_content_type(t,'unshared','false')}' width='38' height='37' onclick='make_downloads(#{t.id})' style='cursor: pointer;'/>"
      end
    else
      if t.user_id != current_user.id || (@past_shared_docs && @past_shared_docs.index(t))
        "<img src='/images/#{find_content_type(t,'shared','true')}' width='38' height='37' />"
      else
        "<img src='/images/#{find_content_type(t,'unshared','true')}' width='38' height='37' />"
      end
    end
  end
  def task_row_image_link(t)
    if (t.user_id != current_user.id) ||  (t.user_id == current_user.id && @past_shared_tasks && @past_shared_tasks.index(t))
      u_id = t.user_id == current_user.id ? (!t.task_collaborators.empty? ? t.task_collaborators.first.user_id : t.user_id) : t.user_id
			usr_img = PortfolioImage.find(:first,:conditions=>['attachable_id = ? and attachable_type = ?',u_id,"User"])
      task_img = !usr_img.nil? ? usr_img.public_filename : (t.is_completed? ? '/images/task_no_file_icon.png' :  (!t.task_collaborators.empty? ? '/images/adduserx_collab_dummy.jpg' :  '/images/task_no_file_icon.png'))
      link_to_remote(
        image_tag("#{task_img}", :width=>"38",:height=>"37", :border=>"0"),
        :url => edit_task_properties_path(:id=>t.id,:portfolio_id=>@portfolio.id,:folder_id=>t.folder_id,:del_files=>params[:del_files],:show_past_shared=>params[:show_past_shared],:revoke_fn=>"true",:show_missing_file=>params[:show_missing_file],:edit_task_for_folder => true),
        :class=>"bluecolor",:id=>"add_task#{t.id}",
        :title=> "#{(!t.task_name.nil? and !t.task_name.blank?) ? t.task_type.task_name : t.task_name}",
        :loading=>"load_writter()", :complete=>"load_completer()")
    else
      u_id = t.user_id == current_user.id ? (!t.task_collaborators.empty? ? t.task_collaborators.first.user_id : t.user_id) : t.user_id
			usr_img = PortfolioImage.find(:first,:conditions=>['attachable_id = ? and attachable_type = ?',u_id,"User"])
      task_img = !usr_img.nil? ? usr_img.public_filename : (t.is_completed? ? '/images/task_no_file_icon.png' : (!t.task_collaborators.empty? ? '/images/adduserx_collab_dummy.jpg' :  '/images/task_no_file_icon.png'))
      link_to_remote(
        image_tag("#{task_img}", :width=>"38",:height=>"37", :border=>"0"),
        :url => edit_task_properties_path(:id=>t.id,:portfolio_id=>@portfolio.id,:folder_id=>t.folder_id,:del_files=>params[:del_files],:show_past_shared=>params[:show_past_shared],:revoke_fn=>"true",:show_missing_file=>params[:show_missing_file],:edit_task_for_folder => true),
        :class=>"bluecolor",:id=>"add_task#{t.id}",
        :title=> "#{(!t.task_name.nil? and !t.task_name.blank?) ? t.task_type.task_name : t.task_name}",
        :loading=>"load_writter()", :complete=>"load_completer()")
    end
  end
  def prop_cal(i)
    @act_prop = i.property_financial_periods.detect { |itr| itr.pcb_type == 'c'}
    @bud_prop = i.property_financial_periods.detect { |itr| itr.pcb_type == 'b'}

    @amt_prop  = i.property_financial_periods.detect { |itr| itr.pcb_type == 'var_amt'}
    @per_prop  = i.property_financial_periods.detect { |itr| itr.pcb_type == 'var_per'}

    @var_actual = eval("@act_prop.#{@month_option}.nil? ? 0 : @act_prop.#{@month_option}")
    @var_budget = eval("@bud_prop.#{@month_option}.nil? ? 0 : @bud_prop.#{@month_option}")
    @var_amt = eval("@amt_prop.#{@month_option}.nil? ? 0 : @amt_prop.#{@month_option}").abs
    @var_per = eval("@per_prop.#{@month_option}.nil? ? 0 : @per_prop.#{@month_option}")
  end
  def prop_ytd_cal(i)
    @act_prop_ytd = i.property_financial_periods.detect { |itr| itr.pcb_type == 'c_ytd'}
    @bud_prop_ytd = i.property_financial_periods.detect { |itr| itr.pcb_type == 'b_ytd'}
    @amt_prop_ytd = i.property_financial_periods.detect { |itr| itr.pcb_type == 'var_amt_ytd'}
    @per_prop_ytd = i.property_financial_periods.detect { |itr| itr.pcb_type == 'var_per_ytd'}
    @var_actual_ytd = eval("@act_prop_ytd.#{@month_option}.nil? ? 0 : @act_prop_ytd.#{@month_option}")
    @var_budget_ytd = eval("@bud_prop_ytd.#{@month_option}.nil? ? 0 : @bud_prop_ytd.#{@month_option}")
    @var_amt_ytd = eval("@amt_prop_ytd.#{@month_option}.nil? ? 0 : @amt_prop_ytd.#{@month_option}").abs
    @var_per_ytd = eval("@per_prop_ytd.#{@month_option}.nil? ? 0 : @per_prop_ytd.#{@month_option}")
  end
  def current_user_type(i)
    if current_user.client_type.downcase == "wres"
      @is_expense = wres_find_income_or_expense(i)
    elsif current_user.client_type.downcase == "swig"
      @is_expense = find_income_or_expense(i)
    end
  end

end
