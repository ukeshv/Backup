module PropertyDispositionsHelper
	def proof_doc(user, note)
		proof_document = ProofDocument.find(:last, :conditions=>["user_id = ? && resource_id = ? && resource_type = ?", user.id, note.id, 'RealEstateProperty'])
	end
	def get_portfolio_id(note_id)
		@prop=RealEstateProperty.find(note_id);
		return @prop.portfolio_id if @prop
	end
end
