module RealEstatesHelper

	def real_estate_heading_collection(oo)
    t = []
    for sn in 0..oo.sheets.length-1
      title=[]
      oo.default_sheet = oo.sheets[sn]
      for col in (1..oo.last_column)
        title << [oo.cell(4,col).gsub(':','').gsub("'",'').gsub("\n","").strip ,col]  if !oo.cell(4,col).nil? and !oo.cell(4,col).blank?
      end
      t << title
    end
    return t
	end	

  def real_estate_date_value_calculation(value)
    if !value.nil? and !value.blank?
      if value.class.to_s == "Date" || value.class.to_s == "DateTime"
        value
      else
        Date.new(1899,12,30) +value.to_i
      end
    else
      ""
    end
  end


  def real_estate_validate_for_models(table,data,property_info_id)
    e = []
		for ta in table
			record = ta.singularize.camelize.constantize.new(data[table.index(ta)])
      if !record.valid?
        record.errors.entries.each do | err|
          e << err[1]
        end
      end
		end	
    @errors[property_info_id] = e.flatten if !e.empty?
  end


  def real_estate_save_or_update_the_record(record,table_name,attributes)
    record.valid?
    @errors_details[table_name] = record.errors.entries
    attributes= remove_invalidation_flag_real_estate(table_name,attributes)
    record.attributes =attributes
    record.save
    return record
	end	
	
	
	def real_estate_storing_function_call(data,table,property_id,oo)		
    for ta in table
      if ta!="real_estate_properties"
        model_constant =  ta.singularize.camelize.constantize
        dup_detail  = model_constant.find_by_real_estate_property_id(property_id)
        if dup_detail.nil?
  				for i in 1..oo.sheets.length-1
            d = data[i]
            d[:real_estate_property_id]= property_id
            new_object = ta.singularize.camelize.constantize.new(d)
            new_object = real_estate_save_or_update_the_record(new_object,ta,d)
          end
        else
          dup_detail.attributes = data[table.index(ta)] #update_attributes(data[table.index(ta)])
          dup_detail = real_estate_save_or_update_the_record(dup_detail,ta,data[table.index(ta)])
        end
      else
      end
    end
	end
	
  def date_value_calculation(value)
    if !value.nil? and !value.blank?
      if value.class.to_s == "Date" || value.class.to_s == "DateTime"
        value
      else
        Date.new(1899,12,30) +value.to_i
      end
    else
      ""
    end
  end


  def remove_invalidation_flag_real_estate(table_name,data_hash)
    validation_labels = {'real_estate_properties' => ["check_property_size","check_gross_land_area","check_gross_rentable_area","check_no_of_units","check_year_built","check_property_name","check_city","check_state","check_zip","check_property_description","check_address","check_purchase_price"],
      'real_estate_loan_details' => ["check_original_note_amount","check_current_outstanding","check_late_payments_amount_due","check_current_interest_rate","check_first_payment_date","check_last_payment_date","check_maturity_date","check_comments"],
    }
    values = validation_labels[table_name]
    for each_val in values
      data_hash[each_val]= 6
    end
    return data_hash
  end
	def calculate_current_debt_individual(property_id)
		loan_details = RealEstateLoanDetail.find_by_sql("select sum(current_outstanding) As current_outstand from real_estate_loan_details where real_estate_property_id = #{property_id}")
		@current_debt =  loan_details.collect{|x|  x.current_outstand}
	end
	def find_number_of_not_updated_properties(portfolio)
    start_date = Date.today.last_month.beginning_of_month.strftime("%Y-%m-%d")
		@portfolio = portfolio
    @portfolio = @portfolios.first     if @portfolio.nil?
  	@properties =[]
    unless @portfolio.real_estate_properties.empty?
      @portfolio.real_estate_properties.each do |property|
        rent_roll = RentRoll.find_by_sql("SELECT * from `rent_rolls`  WHERE (`start_date` >= #{start_date} AND #{start_date} < `end_date` ) AND `resource_type`='RealEstateProperty' AND user_id = #{current_user.id} and resource_id = #{property.id};")
        @properties << property if  rent_roll.empty?
      end
      start_date = Date.today.last_month.beginning_of_month.strftime("%Y-%m")
      @portfolio.real_estate_properties.each do |property|
        actuals  = Actual.find_by_sql("SELECT * FROM  `actuals`  WHERE (`month_and_year` LIKE '%#{start_date}%') AND `resource_type`='RealEstateProperty' AND user_id = #{current_user.id} and resource_id = #{property.id};")
				@properties << property if actuals.empty?
      end
      @properties  =  @properties.uniq
    end
  end
	def find_data_updated(portfolio)
		start_date = Date.today.last_month.beginning_of_month.strftime("%Y-%m-%d")
		@portfolio = portfolio
		@updated_properties  = []
		@portfolio.real_estate_properties.each do |property|
      rent_roll = RentRoll.find_by_sql("SELECT * from `rent_rolls`  WHERE (`start_date` >= #{start_date} AND #{start_date} < `end_date` ) AND `resource_type`='RealEstateProperty' AND user_id = #{current_user.id} and resource_id = #{property.id};")
      @updated_properties  << property if  !rent_roll.empty?
    end
  	start_date = Date.today.last_month.beginning_of_month.strftime("%Y-%m")
    @portfolio.real_estate_properties.each do |property|
  		actuals  = Actual.find_by_sql("SELECT * FROM  `actuals`  WHERE (`month_and_year` LIKE '%#{start_date}%') AND `resource_type`='RealEstateProperty' AND user_id = #{current_user.id} and resource_id = #{property.id};")
      @updated_properties  << property if !actuals.empty?
    end
    find_number_of_not_updated_properties(portfolio)
    properties = @properties.collect {|i| i.id}
    @updated_properties =  @updated_properties.reject {|r| properties.include?(r.id) }
    @updated_properties  = @updated_properties
    d = @updated_properties.empty? ?  false : true
    return d
	end
  def calculate_occupancy_individual(id,portfolio)
   	total_occupied=0
		total_available=0
		rent_roll_details=[]
		start_date = Date.today.last_month.beginning_of_month.strftime("%Y-%m-%d")
		end_date =  Date.today.last_month.end_of_month.strftime("%Y-%m-%d")
		#~ start_date = Date.today.beginning_of_month.strftime("%Y-%m-%d")
		#~ end_date =  Date.today.end_of_month.strftime("%Y-%m-%d")
		@rent_rolls= RentRoll.find_by_sql("SELECT * FROM `rent_rolls`  WHERE (start_date <= '#{start_date}' AND end_date >= '#{end_date}' ) AND `resource_type`='RealEstateProperty' AND user_id = #{current_user.id} and resource_id = #{id};")
		data_updated = find_data_updated(portfolio)
    data_updated_ids = @updated_properties.collect{|i| i.id}
    if !@rent_rolls.empty?
      @rent_rolls.each do |rent_roll|
        rent_roll_details << rent_roll if RealEstateProperty.find(rent_roll.resource_id).portfolio_id  == portfolio.id && data_updated_ids.include?(rent_roll.resource_id)
      end
      rent_roll_details.each do |rent_roll_detail|
        total_occupied=rent_roll_detail.total_occupied+total_occupied
        total_available=rent_roll_detail.total_available+total_available
      end
      @occupancy_percent=(total_occupied/(total_occupied+total_available).to_f*100).round
    else
      return 0
    end
  end
  def calculate_noi_individual(p,portfolio)
    start_date = Date.today.last_month.beginning_of_month.strftime("%Y-%m")
    actuals  = Actual.find_by_sql("SELECT * FROM  `actuals`  WHERE (`month_and_year` LIKE '%#{start_date}%') AND `resource_type`='RealEstateProperty' AND user_id = #{current_user.id} and resource_id = #{p};")
    noi = " "
    noi= actuals[0].net_operating_income if !actuals[0].nil?
    return noi
	end
	
	def calculate_noi_per_sqft_individual(p,portfolio,occupancy_percent)
		start_date = Date.today.last_month.beginning_of_month.strftime("%Y-%m")
		end_date =  Date.today.last_month.end_of_month.strftime("%Y-%m")
		if occupancy_percent != 0
      noi  = Actual.find_by_sql("SELECT net_operating_income FROM  `actuals`  WHERE (`month_and_year` LIKE '%#{start_date}%') AND `resource_type`='RealEstateProperty' AND user_id = #{current_user.id} and resource_id = #{p};")
      start_date = Date.today.last_month.beginning_of_month.strftime("%Y-%m-%d")
			end_date =  Date.today.last_month.end_of_month.strftime("%Y-%m-%d")
			rent_roll = RentRoll.find_by_sql("SELECT * from `rent_rolls`  WHERE (start_date <= '#{start_date}' AND end_date >= '#{end_date}' ) AND `resource_type`='RealEstateProperty' AND user_id = #{current_user.id} and resource_id = #{p};")
			if rent_roll[0] !=nil
				noi = 	noi.collect{|i| (i.net_operating_income)/((rent_roll[0].total_occupied+rent_roll[0].total_available) * occupancy_percent) }
			end
			return noi[0]
		else
			return 0
		end
	end
	def template_heading_collection(oo)
    t = []
    title=[]
    oo.default_sheet = oo.sheets[0]
    for col in (1..oo.last_column)
      title << [oo.cell(13,col).gsub(':','').gsub("'",'').gsub("\n","").strip ,col]  if !oo.cell(13,col).nil? and !oo.cell(13,col).blank?
    end
    return title
	end
	def read_income_val(oo)
		tot_rows = oo.last_row - oo.first_row
		vals = {}
		for row in 13..36
			check_next = {}
			for c in 1..oo.last_column
				if c == 1
					check_next.store(c,oo.cell(row,c))
				elsif c == 2
					check_next.store(c,oo.cell(row,c))
				elsif c == 3
					check_next.store(c,oo.cell(row,c))
				else
					check_next = {}
					vals.store(oo.cell(row,c),c)
				end
				if check_next.values.first.nil? && !check_next.values.second.nil? && check_next.values.last.nil?
					if @headings.include?(check_next.values.second.downcase)
						fetch_income(oo,row,2,check_next.values.second.downcase)
					end
				end			
			end		
		end
	end
	def fetch_income(oo,row,c,cur_row_text)
		@income_text = {}
		h = {}
		next_row = row+1
		next_col = c + 1
		heading1 = oo.cell(next_row,next_col)
		#~ @income_text.store(next_col,oo.cell(next_row,next_col))
		if oo.cell(next_row+1,1) != nil && oo.cell(next_row+1,1).downcase == 'p'
			p_row = next_row+1
		elsif oo.cell(next_row+2,1) != nil && oo.cell(next_row+2,1).downcase == 'p'
			p_row = next_row+2
		end
		h.store(heading1,oo.cell(p_row,2))
		#@income_text[heading1]=h
		@income_text[cur_row_text] = h
	end	
	# started parsing the whole excel template for 12-month budget
	def import_income_and_cash_flow_details(oo)
		@array_record = []
		@month_list_partial =[]
		for mo in 1..12
			@month_list_partial << Date::MONTHNAMES[mo].slice(0,3)
		end
    if @month_list_partial.include?(@document.folder.name)
			@month_de = @month_list_partial.index(@document.folder.name)+1
		end
    #		IncomeAndCashFlowDetail.delete_all(["year = ? and resource_id =?  and resource_type=?",@finanical_year, @real_estate_property.id, @real_estate_property.class.to_s])
		for row in 9..oo.last_row
			for col in 0..15					
				if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and convert_title_val(oo.cell(row,col)) =="cash flow statement summary"
					start_row_oss=row;start_col_oss=col
					create_new_income_and_cash_flow_details(convert_title_val(oo.cell(row,col)))
					parsing_cash_flow_statement_summary(start_row_oss,start_col_oss,oo)
				end
				if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and convert_title_val(oo.cell(row,col)) =="income detail"
					@array_record = []
					create_new_income_and_cash_flow_details("operating statement summary")
					start_row_oss=row;start_col_oss=col
					create_new_income_and_cash_flow_details(convert_title_val(oo.cell(row,col)),@array_record.first)
					parsing_operation_statement_summary(start_row_oss,start_col_oss,oo)
				end
			end
		end				
		calculate_sum_for_all_the_details_in_cash_flow_and_detail
	end
  # created entries in the IncomeAndCashFlowDetail table for each title , also checking title already present are not.
	def create_new_income_and_cash_flow_details(title,parent=nil)
		parent = [nil,nil] if parent.nil?
		if parent[1].nil?
      re_p=IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and parent_id IS NULL and resource_id=? and resource_type=? and year=?",title,@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
		else
      re_p=IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and parent_id =? and resource_id=? and resource_type=? and year=?",title,parent[1],@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
    end
		re_p=IncomeAndCashFlowDetail.create(:title=>title,:parent_id=> parent[1],:resource_id => @real_estate_property.id,:resource_type=>@real_estate_property.class.to_s,:user_id => @user.id,:year =>@finanical_year,:template_date =>@template_year)  if re_p.nil?
		PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(re_p.id, 'p', re_p.class.to_s)
		PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(re_p.id, 'c', re_p.class.to_s)
		PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(re_p.id, 'b', re_p.class.to_s)		
		#~ re_c=IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and parent_id =? and pcb_type=?",title,parent[2],'c'])
		#~ re_c=IncomeAndCashFlowDetail.create(:title=>title,:parent_id=> parent[2] ,:pcb_type=>'c',:resource_id => @real_estate_property.id,:resource_type=>@real_estate_property.class.to_s,:user_id => current_user.id,:year =>@finanical_year,:template_date =>@template_year)  if re_c.nil?
		#~ re_b=IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and parent_id =? and pcb_type=?",title,parent[3],'b'])
		#~ re_b=IncomeAndCashFlowDetail.create(:title=>title,:parent_id=> parent[3] ,:pcb_type=>'b',:resource_id => @real_estate_property.id,:resource_type=>@real_estate_property.class.to_s,:user_id => current_user.id,:year =>@finanical_year,:template_date =>@template_year) if re_b.nil?
		@array_record << [title,re_p.id] #if !re.nil?
	end	
	# Finding pcb type position for the destroy functionality
	def get_position_for_pcb(pcb)
		if pcb == 'p'
			1
		elsif pcb == 'c'
			2
		elsif pcb == 'b'	
			3
		end
	end	
	# It is used to parse the cash flow statement summary details
	# it starts the 'cash flow statement summary' title & end when reach 'income detail'
	def parsing_cash_flow_statement_summary(start_row_oss,start_col_oss,oo)
    row=start_row_oss+1
    while(!(!oo.cell(row,2).nil? and oo.cell(row,2).class.to_s=="String" and convert_title_val(oo.cell(row,2))=="income detail")  ) do
      if !oo.cell(row,1).nil? or  !oo.cell(row,2).nil? or !oo.cell(row,3).nil?
        last_element1 = nil
        last_element = nil
        if !oo.cell(row,1).nil?
          if oo.cell(row,1).class.to_s == "String" and (convert_title_val(oo.cell(row,1))=='p' or	convert_title_val(oo.cell(row,1))=='c'	or convert_title_val(oo.cell(row,1))=='b')
            position = get_position_for_pcb(convert_title_val(oo.cell(row,1)))
            last_element = @array_record.pop
            record = IncomeAndCashFlowDetail.find_by_id(last_element[1])
            if (record.title.match(/total/) or record.title.match(/net cash/)) and record.title!="net cash flow"
              record.destroy if position==3
              last_element1 = @array_record.pop
              record = IncomeAndCashFlowDetail.find_by_id(last_element1[1])
            end
            store_details(record,oo,row,convert_title_val(oo.cell(row,1)))
            if position!=3
              @array_record << last_element1 if last_element1
              @array_record << last_element if last_element
            end
          end
        elsif  oo.cell(row,2).nil? or  (!oo.cell(row,2).nil? and  oo.cell(row,2).class.to_s=="String" and !(["database:","entity:","accrual","january"].include?(convert_title_val(oo.cell(row,2)))))
          if !oo.cell(row,2).nil?
            if @array_record.length > 2
              last_re = @array_record.pop
            end
            create_new_income_and_cash_flow_details(convert_title_val(oo.cell(row,2)),@array_record.last)
          end
          if !oo.cell(row,3).nil?
            create_new_income_and_cash_flow_details(convert_title_val(oo.cell(row,3)),@array_record.last)
          end
        end
      end
      row=row+1
    end
	end	
	# It is used to parse the operting statement summary details
	# it starts the 'income details' title & end at last row
	def parsing_operation_statement_summary(start_row_oss,start_col_oss,oo)
    row=start_row_oss+1
    while(row <=oo.last_row ) do
      if !oo.cell(row,1).nil? or  !oo.cell(row,2).nil? or !oo.cell(row,3).nil?
        last_element1 = nil
        last_element = nil
        if !oo.cell(row,1).nil?
          if oo.cell(row,1).class.to_s == "String"  and (convert_title_val(oo.cell(row,1))=='p' or	convert_title_val(oo.cell(row,1))=='c'	or convert_title_val(oo.cell(row,1))=='b')
            position = get_position_for_pcb(convert_title_val(oo.cell(row,1)))
            if @array_record.last[0]=="net operating income"
              last_element = @array_record.last
            else
              last_element = @array_record.pop
            end
            record = IncomeAndCashFlowDetail.find_by_id(last_element[1])
            if record.title.match(/total/)
              record.destroy if position==3
              last_element1 = @array_record.pop
              record = IncomeAndCashFlowDetail.find_by_id(last_element1[1])
            end
            store_details(record,oo,row,convert_title_val(oo.cell(row,1)))
            if position!=3
              @array_record << last_element1 if last_element1
              @array_record << last_element if last_element
            end
          end
        elsif  oo.cell(row,2).nil? or  (!oo.cell(row,2).nil? and  oo.cell(row,2).class.to_s=="String" and !(["database:","entity:","accrual","january"].include?(convert_title_val(oo.cell(row,2)))))
          if !oo.cell(row,2).nil?
            parent_id = (convert_title_val(oo.cell(row,2))=="net income") ? @array_record.first : @array_record.last
            create_new_income_and_cash_flow_details(convert_title_val(oo.cell(row,2)),parent_id)
          end
          if !oo.cell(row,3).nil?
            create_new_income_and_cash_flow_details(convert_title_val(oo.cell(row,3)),@array_record.last)
          end
        end
      end
      row=row+1
    end
	end

	# It is used to store the property_financial_period for each income and cash flow statement
	def store_details(record,oo,row,pcb_type)
		if !@month_de.nil?
      prop_financial= PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(record.id, pcb_type, record.class.to_s)
			h = Hash.new
			col=2
      #the range restricted for future month actual parsing
      parse_range = pcb_type == 'c' && @financial_year.to_i >= Date.today.year ? 1...Date.today.month : 1..12
			for m in parse_range
				if !oo.cell(row,col).nil? and oo.cell(row,col).to_i > 0
					h["#{Date::MONTHNAMES[m].downcase}"] = oo.cell(row,col)
				elsif prop_financial["#{Date::MONTHNAMES[m].downcase}"].nil?
					h["#{Date::MONTHNAMES[m].downcase}"] = 0
				end
				col=col+1
			end		
			prop_financial.update_attributes(h)
			#prop_financial.update_attributes(:january =>oo.cell(row,2) , :february  =>oo.cell(row,3), :march =>oo.cell(row,4), :april =>oo.cell(row,5) ,:may => oo.cell(row,6),:june=> oo.cell(row,7),:july =>oo.cell(row,8),:august =>oo.cell(row,9),:september=> oo.cell(row,10),:october=> oo.cell(row,11),:november=>oo.cell(row,12) ,:december=>oo.cell(row,13))
		end
  end
  
	# It is used to calculate the sum for the all the records in the income & cash table
	def calculate_sum_for_all_the_details_in_cash_flow_and_detail
		a = ["operating statement summary","cash flow statement summary","net cash flow","net operating income","net income"]
		for income_and_cash_flow in IncomeAndCashFlowDetail.all
			if !a.include?(income_and_cash_flow.title)
        sum_for_each_item(income_and_cash_flow,'p')
        sum_for_each_item(income_and_cash_flow,'c')
        sum_for_each_item(income_and_cash_flow,'b')
			end
		end			
	end	
	def portfolio_sqft_diff(graph_period,is_year_to_date,portfolio_id)
		graph_year = graph_period.split('-')[0]
		graph_month = graph_period.split('-')[1]
		property_ids = RealEstateProperty.find(:all,:conditions => ["portfolio_id = ? and user_id =?",portfolio_id, current_user.id])
  	property_ids += RealEstateProperty.find_by_sql("SELECT * FROM real_estate_properties WHERE portfolio_id = #{portfolio_id} and id in (SELECT real_estate_property_id FROM shared_folders WHERE is_property_folder = 1 AND user_id = #{current_user.id} )")
		if is_year_to_date == true
			occupancy_max_month = PropertyOccupancySummary.find_by_sql("SELECT max(`month`) as month FROM property_occupancy_summaries o INNER JOIN real_estate_properties r on o.real_estate_property_id = r.id and r.portfolio_id =#{@portfolio.id} and r.id in (#{property_ids.collect{|x|x.id}.split(',').join(',')}) and o.month <= #{Date.today.last_month.month}")
			#@portfolio_occupancy = PropertyOccupancySummary.find(:all,:conditions => ["year=? and real_estate_property_id IN (SELECT id FROM real_estate_properties WHERE portfolio_id = ?)",graph_year,portfolio_id],:order => "month desc", :select => "sum( current_year_sf_occupied_budget ) as budget, sum( current_year_sf_occupied_actual ) as actual ")
			@portfolio_occupancy = PropertyOccupancySummary.find_by_sql("select sum(c.budget) as budget,sum(c.actual ) as actual from (SELECT a . * ,b.current_year_sf_occupied_budget as budget, b.current_year_sf_occupied_actual as actual, b.id FROM  property_occupancy_summaries b RIGHT JOIN (SELECT #{occupancy_max_month[0].month} AS MONTH , real_estate_property_id FROM property_occupancy_summaries WHERE real_estate_property_id IN (#{property_ids.collect{|x|x.id}.split(',').join(',')}) AND year = #{graph_year} GROUP BY real_estate_property_id HAVING #{occupancy_max_month[0].month})a ON a.month = b.month AND a.real_estate_property_id = b.real_estate_property_id)c")
		else
			@portfolio_occupancy = PropertyOccupancySummary.find(:all,:conditions => ["year=? and month = ? and real_estate_property_id IN (?)",graph_year,graph_month,property_ids.collect{|x|x.id}], :select => "sum( current_year_sf_occupied_budget ) as budget, sum( current_year_sf_occupied_actual ) as actual ")
		end
	end	
	def hash_formation_for_portfolio_occupancy(graph_period,is_year_to_date,portfolio_id)
		graph_year = graph_period.split('-')[0]
		graph_month = graph_period.split('-')[1]
		property_ids = RealEstateProperty.find(:all,:conditions => ["portfolio_id = ? and user_id =?",portfolio_id, current_user.id])
  	property_ids += RealEstateProperty.find_by_sql("SELECT * FROM real_estate_properties WHERE portfolio_id = #{portfolio_id} and id in (SELECT real_estate_property_id FROM shared_folders WHERE is_property_folder = 1 AND user_id = #{current_user.id} )")
    if is_year_to_date == true
      #	       occupancy_max_month = PropertyOccupancySummary.find_by_sql("SELECT max(`month`) as month FROM property_occupancy_summaries WHERE month != Month(CURRENT_TIMESTAMP) and real_estate_property_id = #{@note.id}")
			unless property_ids.empty?
			 occupancy_max_month = PropertyOccupancySummary.find_by_sql("SELECT max(`month`) as month FROM property_occupancy_summaries o INNER JOIN real_estate_properties r on o.real_estate_property_id = r.id and r.portfolio_id =#{@portfolio.id} and r.id in (#{property_ids.collect{|x|x.id}.split(',').join(',')}) and o.month <= #{Date.today.last_month.month}")
			 else
         occupancy_max_month = PropertyOccupancySummary.find_by_sql("SELECT max(`month`) as month FROM property_occupancy_summaries o INNER JOIN real_estate_properties r on o.real_estate_property_id = r.id and r.portfolio_id =#{@portfolio.id}")
			 end
			 

			#@portfolio_occupancy = PropertyOccupancySummary.find(:all,:conditions => ["year=? and real_estate_property_id IN (SELECT id FROM real_estate_properties WHERE portfolio_id = ?)",graph_year,portfolio_id],:order => "month desc", :select => "sum( current_year_sf_occupied_actual ) as occupied, sum( current_year_sf_vacant_actual ) as vaccant ")
			if occupancy_max_month[0].month.nil?
				@portfolio_occupancy = []
			else	
        @portfolio_occupancy = PropertyOccupancySummary.find_by_sql("select sum(c.occupied) as occupied,sum(c.vaccant ) as vaccant from (SELECT a . * ,b.current_year_sf_occupied_actual as occupied, b.current_year_sf_vacant_actual as vaccant, b.id FROM  property_occupancy_summaries b RIGHT JOIN (SELECT #{occupancy_max_month[0].month} AS MONTH , real_estate_property_id FROM property_occupancy_summaries WHERE real_estate_property_id IN (#{property_ids.collect{|x|x.id}.split(',').join(',')}) AND year = #{graph_year} GROUP BY real_estate_property_id HAVING #{occupancy_max_month[0].month})a ON a.month = b.month AND a.real_estate_property_id = b.real_estate_property_id)c")
      end
		else
			@portfolio_occupancy = PropertyOccupancySummary.find(:all,:conditions => ["year=? and month = ? and real_estate_property_id IN (?)",graph_year,graph_month,property_ids.collect{|x|x.id}], :select => "sum( current_year_sf_occupied_actual ) as occupied, sum( current_year_sf_vacant_actual ) as vaccant ")
			#@portfolio_occupancy = PropertyOccupancySummary.find_by_sql("SELECT sum( current_year_sf_occupied_actual ) as occupied, sum( current_year_sf_vacant_actual ) as vaccant FROM property_occupancy_summaries WHERE year = #{graph_year} AND MONTH >= #{st_month} AND MONTH <= #{graph_month} AND real_estate_property_id IN (SELECT id FROM real_estate_properties WHERE portfolio_id = #{portfolio_id})")
		end		
		return @portfolio_occupancy
  end
	def wres_hash_formation_for_portfolio_occupancy(graph_period,is_year_to_date,portfolio_id)
		graph_year = graph_period.split('-')[0]
		graph_month = graph_period.split('-')[1]
		property_ids = RealEstateProperty.find(:all,:conditions => ["portfolio_id = ? and user_id =?",portfolio_id, current_user.id])
  	property_ids += RealEstateProperty.find_by_sql("SELECT * FROM real_estate_properties WHERE portfolio_id = #{portfolio_id} and id in (SELECT real_estate_property_id FROM shared_folders WHERE is_property_folder = 1 AND user_id = #{current_user.id} )")

    if is_year_to_date == true
			if property_ids && !property_ids.empty?
				occupancy_max_month = PropertyOccupancySummary.find_by_sql("SELECT max(`month`) as month FROM property_occupancy_summaries o INNER JOIN real_estate_properties r on o.real_estate_property_id = r.id and r.portfolio_id =#{@portfolio.id} and r.id in (#{property_ids.collect{|x|x.id}.split(',').join(',')}) and o.month <= #{Date.today.last_month.month}")
      else
				occupancy_max_month = PropertyOccupancySummary.find_by_sql("SELECT max(`month`) as month FROM property_occupancy_summaries o INNER JOIN real_estate_properties r on o.real_estate_property_id = r.id and r.portfolio_id =#{@portfolio.id} and o.month <= #{Date.today.last_month.month}")
			end	
			#@portfolio_occupancy = PropertyOccupancySummary.find(:all,:conditions => ["year=? and real_estate_property_id IN (SELECT id FROM real_estate_properties WHERE portfolio_id = ?)",graph_year,portfolio_id],:order => "month desc", :select => "sum( current_year_sf_occupied_actual ) as occupied, sum( current_year_sf_vacant_actual ) as vaccant ")
			if occupancy_max_month[0].month.nil?
				@portfolio_occupancy = []
			else	
        @portfolio_occupancy = PropertyOccupancySummary.find_by_sql("select sum(c.occupied) as occupied,sum(c.vaccant ) as vaccant, sum(c.occupied_units) as occupied_units, sum(c.vaccant_units) as vaccant_units from (SELECT a . * ,b.current_year_sf_occupied_actual as occupied, b.current_year_sf_vacant_actual as vaccant,b.current_year_units_occupied_actual as occupied_units, b.current_year_units_vacant_actual as vaccant_units, b.id FROM  property_occupancy_summaries b RIGHT JOIN (SELECT     #{occupancy_max_month[0].month}  AS MONTH , real_estate_property_id FROM property_occupancy_summaries WHERE real_estate_property_id IN ( #{property_ids.collect{|x|x.id}.split(',').join(',')}) AND year = #{graph_year} GROUP BY real_estate_property_id HAVING #{occupancy_max_month[0].month})a ON a.month = b.month and b.year = #{graph_year} AND a.real_estate_property_id = b.real_estate_property_id)c")
      end
		else
			@portfolio_occupancy = PropertyOccupancySummary.find(:all,:conditions => ["year=? and month = ? and real_estate_property_id IN (?)",graph_year,graph_month,property_ids.collect{|x|x.id}], :select => "sum( current_year_sf_occupied_actual ) as occupied, sum( current_year_sf_vacant_actual ) as vaccant,sum( current_year_units_occupied_actual ) as occupied_units, sum( current_year_units_vacant_actual ) as vaccant_units ")
			#@portfolio_occupancy = PropertyOccupancySummary.find_by_sql("SELECT sum( current_year_sf_occupied_actual ) as occupied, sum( current_year_sf_vacant_actual ) as vaccant FROM property_occupancy_summaries WHERE year = #{graph_year} AND MONTH >= #{st_month} AND MONTH <= #{graph_month} AND real_estate_property_id IN (SELECT id FROM real_estate_properties WHERE portfolio_id = #{portfolio_id})")
		end	
    return @portfolio_occupancy
  end	
	# Recursive function used to calculate the sum for each element by adding the its each child records
	def sum_for_each_item(income_and_cash_flow,pcb_type)
		children = IncomeAndCashFlowDetail.find_all_by_parent_id(income_and_cash_flow.id)
		sum_jan=0;sum_feb=0;sum_mar=0;sum_apr=0;sum_may=0;sum_june=0;sum_july=0;sum_aug=0;sum_sep=0;sum_oct=0;sum_nov=0;sum_dec=0
		for child_par in children
			sum_for_each_item(child_par,pcb_type)			
			child = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(child_par.id, pcb_type, child_par.class.to_s)			
			sum_jan = sum_jan +child.january       if !child.nil? and !child.january.nil?
			sum_feb = sum_feb +child.february     if !child.nil? and !child.february.nil?
			sum_mar = sum_mar +child.march      if !child.nil? and !child.march.nil?
			sum_apr = sum_apr +child.april           if !child.nil? and !child.april.nil?
			sum_may = sum_may +child.may       	if !child.nil? and !child.may.nil?
			sum_june = sum_june +child.june         if !child.nil? and !child.june.nil?
			sum_july = sum_july +child.july             if !child.nil? and !child.july.nil?
			sum_aug = sum_aug +child.august       if !child.nil? and !child.august.nil?
			sum_sep = sum_sep +child.september  if !child.nil? and !child.september.nil?
			sum_oct = sum_oct +child.october        if !child.nil? and !child.october.nil?
			sum_nov = sum_nov +child.november   if !child.nil? and !child.november.nil?
			sum_dec = sum_dec +child.december   if !child.nil? and !child.december.nil?
		end
		if !children.empty?			
			income_period = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(income_and_cash_flow.id, pcb_type, income_and_cash_flow.class.to_s)			
			income_period.update_attributes(:january =>sum_jan , :february  =>sum_feb, :march =>sum_mar, :april =>sum_apr,:may =>sum_may,:june=>sum_june,:july =>sum_july,:august =>sum_aug,:september=>sum_sep,:october=>sum_oct,:november=>sum_nov,:december=>sum_dec)	if !income_period.nil?
		end
	end	
	def get_location(city,province)
		if ( city == ''|| city.blank? ) && (province == '' || province.blank? )
			''
		elsif ( city != '' || !city.blank? ) && ( province == '' || province.blank? )
			city
		elsif ( city == '' || city.blank? ) && ( province != '' || !province.blank? )
			province
		else
			city.to_s+', '+province.to_s
		end
	end
  def wres_12_month_parsing(doc)
		@real_estate_property= doc.real_estate_property
		@finanical_year = ''
		@template_year = Date.today
		@without_heading=["other months' rent","rental value - employee housing","month to month rent","security deposit forfeiture","late charges/nsf's","laundry commissions","utility income","insurance referral fees","miscellaneous income","furniture rental","recreation program receipts"]
		@array_record = []
		@month_list_partial =[]
		for mo in 1..12
			@month_list_partial << Date::MONTHNAMES[mo].slice(0,3)
		end
    #   if @month_list_partial.include?(@document.folder.name)
    @month_de = @month_list_partial[1]#.index(@document.folder.name)+1
    #		end
    #		IncomeAndCashFlowDetail.delete_all(["year = ? and resource_id =?  and resource_type=?",@finanical_year, @real_estate_property.id, @real_estate_property.class.to_s])
		#file_path = "#{RAILS_ROOT}/public/12_Month_Budget.xls"
    #	file_path = "#{RAILS_ROOT}/public/Actual_Budget_Analysis_Report.xls"
		oo =  Excel.new "#{RAILS_ROOT}/public#{doc.public_filename}"
		oo.default_sheet = oo.sheets.first
		date = (oo.cell(4,'C') != nil && (oo.celltype(4,'C') == :date) ? oo.cell(4,'C') : oo.cell(4,'C') != nil && !(["budget","","actual"].include?(oo.cell(4,'C').downcase))) ? oo.cell(4,'C') : oo.cell(3,'C') != nil ? oo.cell(3,'C') : ''
		@finanical_year = (date == :date) ? date.year : date.to_date.year if !date.nil?
		for row in 0..oo.last_row
			for col in 1..15
				if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and convert_title_val(oo.cell(row,col))=="operating income"
					@array_record = []
					wres_create_new_income_and_cash_flow_details("operating statement summary")
					start_row_oss=row;start_col_oss=col
					wres_create_new_income_and_cash_flow_details(convert_title_val(oo.cell(row,col)),@array_record.first)
					wres_parsing_operation_statement_summary(start_row_oss,start_col_oss,oo,'b','c',3)
				end
			end
		end
    wres_calculate_sum_for_all_the_details_in_cash_flow_and_detail('b')
    wres_net_value_calculation('b')
    wres_store_variance_details(@real_estate_property.id,'actual_budget')
	end
  
	def wres_actual_budget_analysis_parsing(doc)
		@real_estate_property= doc.real_estate_property
		@finanical_year = ''
		@template_year = Date.today
		@without_heading=["other months' rent","rental value - employee housing","month to month rent","security deposit forfeiture","late charges/nsf's","laundry commissions","utility income","insurance referral fees","miscellaneous income","furniture rental","recreation program receipts"]
		@array_record = []
		@month_list_partial =[]
		for mo in 1..12
			@month_list_partial << Date::MONTHNAMES[mo].slice(0,3)
		end
    #   if @month_list_partial.include?(@document.folder.name)
    @month_de = @month_list_partial[1]#.index(@document.folder.name)+1
    #		end
    #		IncomeAndCashFlowDetail.delete_all(["year = ? and resource_id =?  and resource_type=?",@finanical_year, @real_estate_property.id, @real_estate_property.class.to_s])
    #	file_path = "#{RAILS_ROOT}/public/12_Month_Budget.xls"
		#file_path = "#{RAILS_ROOT}/public/Actual_Budget_Analysis_Report.xls"
		oo =  Excel.new "#{RAILS_ROOT}/public#{doc.public_filename}"
		oo.default_sheet = oo.sheets.first
		date = (oo.cell(4,'C') != nil && (oo.celltype(4,'C') == :date) ? oo.cell(4,'C') : oo.cell(4,'C') != nil && !(["budget","","actual"].include?(oo.cell(4,'C').downcase))) ? oo.cell(4,'C') : oo.cell(3,'C') != nil ? oo.cell(3,'C') : ''
		@finanical_year = (date == :date) ? date.year : date.to_date.year if !date.nil?
		for row in 0..oo.last_row
			for col in 1..15
				if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and convert_title_val(oo.cell(row,col))=="operating income"
					@array_record = []
					wres_create_new_income_and_cash_flow_details("operating statement summary")
					start_row_oss=row;start_col_oss=col
					wres_create_new_income_and_cash_flow_details(convert_title_val(oo.cell(row,col)),@array_record.first)
					wres_parsing_operation_statement_summary(start_row_oss,start_col_oss,oo,'c','b',2)
				end
			end
		end
		wres_calculate_sum_for_all_the_details_in_cash_flow_and_detail('c')
		wres_net_value_calculation('c')
		wres_store_variance_details(@real_estate_property.id,'actual_budget')
	end
	# created entries in the IncomeAndCashFlowDetail table for each title , also checking title already present are not.
	def wres_create_new_income_and_cash_flow_details(title,parent=nil)
		parent = [nil,nil] if parent.nil?
		if parent[1].nil?
      re_p=IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and parent_id IS NULL and resource_id=? and resource_type=? and year=?",title,@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
		else
      re_p=IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and parent_id =? and resource_id=? and resource_type=? and year=?",title,parent[1],@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
    end
		re_p=IncomeAndCashFlowDetail.create(:title=>title,:parent_id=> parent[1],:resource_id => @real_estate_property.id,:resource_type=>@real_estate_property.class.to_s,:user_id => @user.id,:year =>@finanical_year,:template_date =>@template_year)  if re_p.nil?
		PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(re_p.id, 'c', re_p.class.to_s)
		PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(re_p.id, 'b', re_p.class.to_s)
		@array_record << [title,re_p.id] #if !re.nil?
	end
	def wres_parsing_operation_statement_summary(start_row_oss,start_col_oss,oo,pcb_type,another_pcb_type,column_start)
    row=start_row_oss+1
    while(row <=oo.last_row ) do
      if !oo.cell(row,1).nil?
        last_element1 = nil
        last_element = nil
        if !oo.cell(row,1).nil? and !oo.cell(row,2).nil? and !oo.cell(row,2).blank?
          if convert_title_val(oo.cell(row,1)) != "total variable operating exp"
            if @without_heading.include?(convert_title_val(oo.cell(row,1))) and @array_record.length < 3
              parent_id = (convert_title_val(oo.cell(row,1))=="net income") ? @array_record.first : @array_record.last
              wres_create_new_income_and_cash_flow_details("other income",parent_id)
            end
            parent_id = (convert_title_val(oo.cell(row,1))=="net income") ? @array_record.first : @array_record.last
            if pcb_type == 'c' and (convert_title_val(oo.cell(row,1)) == "total operating income" or convert_title_val(oo.cell(row,1)) == "total operating revenues")
              le = @array_record.last
              @array_record.pop	if !le.nil? and !le[0].nil? and le[0] == "other income"
            end
            wres_create_new_income_and_cash_flow_details(convert_title_val(oo.cell(row,1)),parent_id)
            last_element = @array_record.pop
            record = IncomeAndCashFlowDetail.find_by_id(last_element[1])
            if record.title.match(/total/)
              record.destroy
              last_element = @array_record.pop
              record = IncomeAndCashFlowDetail.find_by_id(last_element[1])
            end
            wres_store_details(record,oo,row,pcb_type,another_pcb_type,column_start)
          end
        elsif  !oo.cell(row,1).nil?  and !convert_title_val(oo.cell(row,1)).match(/created on:/)
          if !oo.cell(row,1).nil?
            @array_record.pop		if @array_record.length > 2
            parent_id = (convert_title_val(oo.cell(row,1))=="net income") ? @array_record.first : @array_record.last
            wres_create_new_income_and_cash_flow_details(convert_title_val(oo.cell(row,1)),parent_id)
          end
        end
      end
      row=row+1
    end
  end

  def wres_store_details(record,oo,row,pcb_type,another_pcb_type,column_start)
    if !@month_de.nil?
      prop_financial= PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(record.id, pcb_type, record.class.to_s)
      h = Hash.new
      col=column_start
      # this is to restrict the parsing for future month actual values
      for m in 1...Date.today.month
        if !oo.cell(row,col).nil? #and oo.cell(row,col).to_i > 0
          h["#{Date::MONTHNAMES[m].downcase}"] = wres_store_value_for_income_and_cash_flow(oo.cell(row,col))
        elsif prop_financial["#{Date::MONTHNAMES[m].downcase}"].nil?
          h["#{Date::MONTHNAMES[m].downcase}"] = 0
        end
        col=col+1
      end
      if	pcb_type == 'b'
        h["dollar_per_sqft"] = wres_store_value_for_income_and_cash_flow(oo.cell(row,col))
        h["dollar_per_unit"] = wres_store_value_for_income_and_cash_flow(oo.cell(row,col+1))
      end
      prop_financial.update_attributes(h)
      prop_financial1 = PropertyFinancialPeriod.find_or_create_by_source_id_and_pcb_type_and_source_type(record.id, another_pcb_type, record.class.to_s)
      h = Hash.new
      col=3
      for m in 1..12
        if (prop_financial1["#{Date::MONTHNAMES[m].downcase}"].nil?)
          h["#{Date::MONTHNAMES[m].downcase}"] = 0
        end
        col=col+1
      end
      prop_financial1.update_attributes(h)	if !h.empty?
    end
	end

  def wres_store_value_for_income_and_cash_flow(value)
		if value.class.to_s =="String"
			value = value.gsub(",","")
			if value.count("-") > 0 or value.count("(") > 0 or value.count(")") > 0
				value = value.gsub("(","").gsub(")","").gsub("-","")
        return "-#{value}"
			else
				return value
			end
	  else
			return value
    end
	end
	def wres_calculate_sum_for_all_the_details_in_cash_flow_and_detail(pcb_type)
		a = ["operating statement summary","net operating income","net income before depreciation"]
		for income_and_cash_flow in IncomeAndCashFlowDetail.all
			if !a.include?(income_and_cash_flow.title)
        wres_sum_for_each_item(income_and_cash_flow,pcb_type)
			end
		end
	end
	def wres_sum_for_each_item(income_and_cash_flow,pcb_type)
		children = IncomeAndCashFlowDetail.find_all_by_parent_id(income_and_cash_flow.id)
		sum_jan=0;sum_feb=0;sum_mar=0;sum_apr=0;sum_may=0;sum_june=0;sum_july=0;sum_aug=0;sum_sep=0;sum_oct=0;sum_nov=0;sum_dec=0
		for child_par in children
			wres_sum_for_each_item(child_par,pcb_type)
			child = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(child_par.id, pcb_type, child_par.class.to_s)
			sum_jan = sum_jan +child.january       if !child.nil? and !child.january.nil?
			sum_feb = sum_feb +child.february     if !child.nil? and !child.february.nil?
			sum_mar = sum_mar +child.march      if !child.nil? and !child.march.nil?
			sum_apr = sum_apr +child.april           if !child.nil? and !child.april.nil?
			sum_may = sum_may +child.may       	if !child.nil? and !child.may.nil?
			sum_june = sum_june +child.june         if !child.nil? and !child.june.nil?
			sum_july = sum_july +child.july             if !child.nil? and !child.july.nil?
			sum_aug = sum_aug +child.august       if !child.nil? and !child.august.nil?
			sum_sep = sum_sep +child.september  if !child.nil? and !child.september.nil?
			sum_oct = sum_oct +child.october        if !child.nil? and !child.october.nil?
			sum_nov = sum_nov +child.november   if !child.nil? and !child.november.nil?
			sum_dec = sum_dec +child.december   if !child.nil? and !child.december.nil?
		end
		if !children.empty?
			income_period = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(income_and_cash_flow.id, pcb_type, income_and_cash_flow.class.to_s)
			income_period.update_attributes(:january =>sum_jan , :february  =>sum_feb, :march =>sum_mar, :april =>sum_apr,:may =>sum_may,:june=>sum_june,:july =>sum_july,:august =>sum_aug,:september=>sum_sep,:october=>sum_oct,:november=>sum_nov,:december=>sum_dec)	if !income_period.nil?
		end
	end
	def wres_net_value_calculation(pcb_type)
		in_cash_income = IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and  resource_id=? and resource_type=? and year=?","operating income",@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
		re_p_income = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(in_cash_income.id, pcb_type, in_cash_income.class.to_s)
		in_cash_expense = IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and  resource_id=? and resource_type=? and year=?","operating expenses",@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
		re_p_expense = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(in_cash_expense.id, pcb_type, in_cash_expense.class.to_s)
		in_cash_npi = IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and  resource_id=? and resource_type=? and year=?","net operating income",@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
		re_p_npi = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(in_cash_npi.id, pcb_type, in_cash_npi.class.to_s)
		in_cash_other = IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and  resource_id=? and resource_type=? and year=?","other income and expense",@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
		re_p_other = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(in_cash_other.id, pcb_type, in_cash_other.class.to_s)
		in_cash_depre = IncomeAndCashFlowDetail.find(:first,:conditions=> ["title=? and  resource_id=? and resource_type=? and year=?","net income before depreciation",@real_estate_property.id,@real_estate_property.class.to_s,@finanical_year])
		re_p_depre = PropertyFinancialPeriod.find_by_source_id_and_pcb_type_and_source_type(in_cash_depre.id, pcb_type, in_cash_depre.class.to_s)
		sum_jan=0;sum_feb=0;sum_mar=0;sum_apr=0;sum_may=0;sum_june=0;sum_july=0;sum_aug=0;sum_sep=0;sum_oct=0;sum_nov=0;sum_dec=0
		if !re_p_income.nil?  and !re_p_expense.nil?
			sum_jan = re_p_income.january - re_p_expense.january       if !re_p_income.january.nil? and !re_p_expense.january.nil?
			sum_feb = re_p_income.february - re_p_expense.february    if !re_p_income.february.nil? and !re_p_expense.february.nil?
			sum_mar = re_p_income.march - re_p_expense.march      if !re_p_income.march.nil? and !re_p_expense.march.nil?
			sum_apr = re_p_income.april - re_p_expense.april           if !re_p_income.april.nil? and !re_p_expense.april.nil?
			sum_may = re_p_income.may - re_p_expense.may       	if !re_p_income.may.nil? and !re_p_expense.may.nil?
			sum_june = re_p_income.june - re_p_expense.june         if !re_p_income.june.nil? and !re_p_expense.june.nil?
			sum_july = re_p_income.july - re_p_expense.july            if !re_p_income.july.nil? and !re_p_expense.july.nil?
			sum_aug = re_p_income.august - re_p_expense.august       if !re_p_income.august.nil? and !re_p_expense.august.nil?
			sum_sep = re_p_income.september - re_p_expense.september  if !re_p_income.september.nil? and !re_p_expense.september.nil?
			sum_oct = re_p_income.october - re_p_expense.october        if !re_p_income.october.nil? and !re_p_expense.october.nil?
			sum_nov = re_p_income.november - re_p_expense.november   if !re_p_income.november.nil? and !re_p_expense.november.nil?
			sum_dec = re_p_income.december - re_p_expense.december   if !re_p_income.december.nil? and !re_p_expense.december.nil?
		end
		if !re_p_npi.nil?
      re_p_npi.update_attributes(:january =>sum_jan , :february  =>sum_feb, :march =>sum_mar, :april =>sum_apr,:may =>sum_may,:june=>sum_june,:july =>sum_july,:august =>sum_aug,:september=>sum_sep,:october=>sum_oct,:november=>sum_nov,:december=>sum_dec)
		end
		sum_jan=0;sum_feb=0;sum_mar=0;sum_apr=0;sum_may=0;sum_june=0;sum_july=0;sum_aug=0;sum_sep=0;sum_oct=0;sum_nov=0;sum_dec=0
		if !re_p_npi.nil?  and !re_p_other.nil?
			sum_jan = re_p_npi.january - re_p_other.january       if !re_p_npi.january.nil? and !re_p_other.january.nil?
			sum_feb = re_p_npi.february - re_p_other.february    if !re_p_npi.february.nil? and !re_p_other.february.nil?
			sum_mar = re_p_npi.march - re_p_other.march      if !re_p_npi.march.nil? and !re_p_other.march.nil?
			sum_apr = re_p_npi.april - re_p_other.april           if !re_p_npi.april.nil? and !re_p_other.april.nil?
			sum_may = re_p_npi.may - re_p_other.may       	if !re_p_npi.may.nil? and !re_p_other.may.nil?
			sum_june = re_p_npi.june - re_p_other.june         if !re_p_npi.june.nil? and !re_p_other.june.nil?
			sum_july = re_p_npi.july - re_p_other.july            if !re_p_npi.july.nil? and !re_p_other.july.nil?
			sum_aug = re_p_npi.august - re_p_other.august       if !re_p_npi.august.nil? and !re_p_other.august.nil?
			sum_sep = re_p_npi.september - re_p_other.september  if !re_p_npi.september.nil? and !re_p_other.september.nil?
			sum_oct = re_p_npi.october - re_p_other.october        if !re_p_npi.october.nil? and !re_p_other.october.nil?
			sum_nov = re_p_npi.november - re_p_other.november   if !re_p_npi.november.nil? and !re_p_other.november.nil?
			sum_dec = re_p_npi.december - re_p_other.december   if !re_p_npi.december.nil? and !re_p_other.december.nil?
		end
		if !re_p_depre.nil?
      re_p_depre.update_attributes(:january =>sum_jan , :february  =>sum_feb, :march =>sum_mar, :april =>sum_apr,:may =>sum_may,:june=>sum_june,:july =>sum_july,:august =>sum_aug,:september=>sum_sep,:october=>sum_oct,:november=>sum_nov,:december=>sum_dec)
		end
	end
  
  def wres_store_variance_details(id, type)
		type1='RealEstateProperty'
    if type=="actual_budget"
      coll = IncomeAndCashFlowDetail.find_all_by_resource_id_and_resource_type(id, type1)
    else
      coll = PropertyCapitalImprovement.find_all_by_real_estate_property_id(id)
    end
    coll.each do |itr|
      pfs =  itr.property_financial_periods
      b_row = pfs.detect {|i| i.pcb_type == 'b'}
      a_row = pfs.detect {|i| i.pcb_type == 'c'}
      unless b_row.nil? && a_row.nil?
        b_arr = [b_row.january, b_row.february, b_row.march, b_row.april, b_row.may, b_row.june, b_row.july, b_row.august, b_row.september, b_row.october, b_row.november, b_row.december]
        b_arr.each_with_index { |i,j| b_arr[j] = 0 if i.nil? }
        a_arr = [a_row.january, a_row.february, a_row.march, a_row.april, a_row.may, a_row.june, a_row.july, a_row.august, a_row.september, a_row.october, a_row.november, a_row.december]
        a_arr.each_with_index { |i,j| a_arr[j] = 0 if i.nil? }
        b_ytd_arr = Array.new(12,0)
        a_ytd_arr = Array.new(12,0)
        0.upto(11) do |ind|
         0.upto(ind) do |sub|
          b_ytd_arr[ind] += b_arr[sub]
          a_ytd_arr[ind] += a_arr[sub]
         end unless ind == 0
        end
        var_arr = []
        per_arr = []
        var_ytd_arr = []
        per_ytd_arr = []
        0.upto(11) do |indx|
					if type=="actual_budget"
            var_arr[indx] = wres_find_income_or_expense(itr) ? (b_arr[indx].to_f - a_arr[indx].to_f) : (a_arr[indx].to_f -  b_arr[indx].to_f)
            var_ytd_arr[indx] = wres_find_income_or_expense(itr) ? (b_ytd_arr[indx].to_f - a_ytd_arr[indx].to_f) : (a_ytd_arr[indx].to_f -  b_ytd_arr[indx].to_f)
          else
            var_arr[indx] =  b_arr[indx].to_f - a_arr[indx].to_f
            var_ytd_arr[indx] =  b_ytd_arr[indx].to_f - a_ytd_arr[indx].to_f
          end
          per_arr[indx] =  (var_arr[indx] * 100) / b_arr[indx].to_f
          per_ytd_arr[indx] =  (var_ytd_arr[indx] * 100) / b_ytd_arr[indx].to_f
          if b_arr[indx].to_f==0
            per_arr[indx] = ( a_arr[indx].to_f == 0 ? 0 : wres_find_income_or_expense(itr) ? -100 : 100 )
          end
          if b_ytd_arr[indx].to_f==0
            per_ytd_arr[indx] = ( a_ytd_arr[indx].to_f == 0 ? 0 : wres_find_income_or_expense(itr) ? -100 : 100 )
          end
          per_arr[indx]= 0.0 if per_arr[indx].to_f.nan?
          per_ytd_arr[indx]= 0.0 if per_ytd_arr[indx].to_f.nan?
        end
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_amt')
        pf.january= var_arr[0];pf.february=var_arr[1];pf.march=var_arr[2];pf.april=var_arr[3];pf.may=var_arr[4];pf.june=var_arr[5];pf.july=var_arr[6];pf.august=var_arr[7];pf.september=var_arr[8];pf.october=var_arr[9];pf.november=var_arr[10];pf.december=var_arr[11];pf.save
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_per')
        pf.january= per_arr[0];pf.february=per_arr[1];pf.march=per_arr[2];pf.april=per_arr[3];pf.may=per_arr[4];pf.june=per_arr[5];pf.july=per_arr[6];pf.august=per_arr[7];pf.september=per_arr[8];pf.october=per_arr[9];pf.november=per_arr[10];pf.december=per_arr[11];pf.save

        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'b_ytd')
        pf.january= b_ytd_arr[0];pf.february=b_ytd_arr[1];pf.march=b_ytd_arr[2];pf.april=b_ytd_arr[3];pf.may=b_ytd_arr[4];pf.june=b_ytd_arr[5];pf.july=b_ytd_arr[6];pf.august=b_ytd_arr[7];pf.september=b_ytd_arr[8];pf.october=b_ytd_arr[9];pf.november=b_ytd_arr[10];pf.december=b_ytd_arr[11];pf.save
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'c_ytd')
        pf.january= a_ytd_arr[0];pf.february=a_ytd_arr[1];pf.march=a_ytd_arr[2];pf.april=a_ytd_arr[3];pf.may=a_ytd_arr[4];pf.june=a_ytd_arr[5];pf.july=a_ytd_arr[6];pf.august=a_ytd_arr[7];pf.september=a_ytd_arr[8];pf.october=a_ytd_arr[9];pf.november=a_ytd_arr[10];pf.december=a_ytd_arr[11];pf.save

        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_amt_ytd')
        pf.january= var_ytd_arr[0];pf.february=var_ytd_arr[1];pf.march=var_ytd_arr[2];pf.april=var_ytd_arr[3];pf.may=var_ytd_arr[4];pf.june=var_ytd_arr[5];pf.july=var_ytd_arr[6];pf.august=var_ytd_arr[7];pf.september=var_ytd_arr[8];pf.october=var_ytd_arr[9];pf.november=var_ytd_arr[10];pf.december=var_ytd_arr[11];pf.save
        pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_per_ytd')
        pf.january= per_ytd_arr[0];pf.february=per_ytd_arr[1];pf.march=per_ytd_arr[2];pf.april=per_ytd_arr[3];pf.may=per_ytd_arr[4];pf.june=per_ytd_arr[5];pf.july=per_ytd_arr[6];pf.august=per_ytd_arr[7];pf.september=per_ytd_arr[8];pf.october=per_ytd_arr[9];pf.november=per_ytd_arr[10];pf.december=per_ytd_arr[11];pf.save
        #PropertyFinancialPeriod.create(:source_id => itr.id, :source_type=> itr.class.to_s, :pcb_type=>'var_per', :january=> per_arr[0], :february=>per_arr[1], :march=>per_arr[2], :april=>per_arr[3], :may=>per_arr[4], :june=>per_arr[5], :july=>per_arr[6], :august=>per_arr[7], :september=>per_arr[8], :october=>per_arr[9], :november=>per_arr[10], :december=>per_arr[11])
      end
    end
  end
  
  def wres_find_income_or_expense(rec)
    if rec.title.downcase.match(/capital expenditure/) or rec.title.downcase.match(/expense/)
      true
    else
      unless rec.parent_id.nil?
        wres_find_income_or_expense( IncomeAndCashFlowDetail.find(rec.parent_id) )
      else
        false
      end
    end
  end

	def wres_all_units_parsing(doc)
		@real_estate_property = doc.real_estate_property
		@titles = []
		#file_path = Excel.new "#{RAILS_ROOT}/public#{doc.public_filename}"
    #	file_path = "#{RAILS_ROOT}/public/Actual_Budget_Analysis_Report.xls"
		oo =   Excel.new "#{RAILS_ROOT}/public#{doc.public_filename}"
		oo.default_sheet = oo.sheets.first
		v = oo.cell(3,'B')
		v1 = v.split(" ")[0].split("/")
		@property_occupancy_summary = PropertyOccupancySummary.find_or_create_by_real_estate_property_id_and_year_and_month(@real_estate_property.id,v1[2],v1[0])
		t =0
		for row in 6..oo.last_row
			for col in 1..oo.last_column
				if !oo.cell(row,col).nil? and oo.cell(row,col).class.to_s=="String" and convert_title_val(oo.cell(row,col))=="bldg/unit"		and t == 0
					start_row=row;start_col_oss=col
          wres_start_lease_parsing(start_row,oo)
          t =1
				end
        break if t==1
      end
		  break if t==1
		end
	end
  def wres_start_lease_parsing(start_row,oo)
		wres_store_titles(start_row,oo)
		row = start_row +1
		while(oo.cell(row,1).nil? or (!oo.cell(row,1).nil?  and convert_title_val(oo.cell(row,1)) != "physical\noccupancy") ) do
			if !oo.cell(row,1).nil? and !oo.cell(row,1).blank? and !convert_title_val(oo.cell(row,1)).match(/total for/) and !["bldg/unit","parameters:","parameters"].include?(convert_title_val(oo.cell(row,1)))
				suite_number = wres_find_value_for_each_column("bldg/unit",oo,row)
				floorplan = wres_find_value_for_each_column('floorplan',oo,row)
				sqft = wres_find_value_for_each_column('sqft',oo,row)
				property_suite = PropertySuite.find_or_create_by_suite_number_and_floor_plan_and_rented_area_and_real_estate_property_id(suite_number,floorplan,sqft,@real_estate_property.id)
				h = {}
				h['base_rent'] = wres_find_value_for_each_column('market rent',oo,row)
				h['amt_per_sqft'] = wres_find_value_for_each_column('amt/sqft',oo,row)
				h['effective_rate'] = wres_find_value_for_each_column('leaserent',oo,row)
				h['actual_amt_per_sqft'] = wres_find_value_for_each_column('actualamt/sqft',oo,row)
				h['tenant'] = wres_find_value_for_each_column('name',oo,row)
				h['move_in'] = wres_find_value_for_each_column('move-in',oo,row)
				h['start_date'] = wres_find_value_for_each_column('leasestart',oo,row)
				h['end_date'] = wres_find_value_for_each_column('leaseend',oo,row)
				h['other_deposits'] = wres_find_value_for_each_column('depositson hand',oo,row)
				h['made_ready'] = (wres_find_value_for_each_column('made ready',oo,row) == 'N') ? 0 : 1
				h['property_suite_id'] = property_suite.id  if !property_suite.nil?
        h['month'] = @property_occupancy_summary.month
        h['year']	= @property_occupancy_summary.year
				PropertyLease.create(h)
			end
			row=row+1
		end
		@titles = []
		wres_physical_occupancy_details(oo,row)
		row = row + 1
		h ={}
		while(oo.cell(row,1).nil? or (!oo.cell(row,1).nil?  and convert_title_val(oo.cell(row,1)) != "exposure to vacancy") ) do
			if !oo.cell(row,1).nil?
				if !oo.cell(row,1).nil? and convert_title_val(oo.cell(row,1)) == 'sqft'
					h['current_year_sf_occupied_actual'] = wres_find_value_for_each_column('occupied',oo,row)
					h['current_year_sf_vacant_actual'] = wres_find_value_for_each_column('vacant',oo,row)
					h['total_building_rentable_s'] = wres_find_value_for_each_column('total',oo,row)
				elsif !oo.cell(row,1).nil? and convert_title_val(oo.cell(row,1)) == 'unit count'
					h['current_year_units_occupied_actual'] = wres_find_value_for_each_column('occupied',oo,row)
					h['current_year_units_vacant_actual'] = wres_find_value_for_each_column('vacant',oo,row)
					h['current_year_units_total_actual'] = wres_find_value_for_each_column('total',oo,row)
				end
			end
			row=row+1
		end
		@property_occupancy_summary.update_attributes(h) if !h.empty?
		@titles = []
		wres_exposure_to_vacancy_details(oo,row)
		row = row +1
		h={}
		while(oo.cell(row,1).nil? or (!oo.cell(row,1).nil?  and convert_title_val(oo.cell(row,1)) != "rental rates") ) do
			if !oo.cell(row,1).nil?
				if !oo.cell(row,1).nil? and convert_title_val(oo.cell(row,1)) == 'currently vacant units'
					h['currently_vacant_leases_number'] = wres_find_value_for_each_column('number',oo,row)
					h['currently_vacant_leases_percentage'] = ( h['currently_vacant_leases_number'] *100/ @property_occupancy_summary.current_year_units_total_actual ).abs.round(2)
				elsif !oo.cell(row,1).nil? and convert_title_val(oo.cell(row,1)) == 'less vacant leased'
					h['vacant_leased_number'] = wres_find_value_for_each_column('number',oo,row)
					h['vacant_leased_percentage'] =( h['vacant_leased_number'] *100/ @property_occupancy_summary.current_year_units_total_actual ).abs.round(2)
				elsif !oo.cell(row,1).nil? and convert_title_val(oo.cell(row,1)) == 'plus occupied on notice'
					h['occupied_on_notice_number'] = wres_find_value_for_each_column('number',oo,row)
					h['occupied_on_notice_percentage'] = ( h['occupied_on_notice_number'] *100/ @property_occupancy_summary.current_year_units_total_actual ).abs.round(2)
				elsif !oo.cell(row,1).nil? and convert_title_val(oo.cell(row,1)) == 'less occupied pre-leased'
					h['occupied_preleased_number'] = wres_find_value_for_each_column('number',oo,row)
					h['occupied_preleased_percentage'] = ( h['occupied_preleased_number'] *100/ @property_occupancy_summary.current_year_units_total_actual ).abs.round(2)
				elsif !oo.cell(row,1).nil? and convert_title_val(oo.cell(row,1)) == 'net exposure to vacancy'
					h['net_exposure_to_vacancy_number'] = wres_find_value_for_each_column('number',oo,row)
					h['net_exposure_to_vacancy_percentage'] =( h['net_exposure_to_vacancy_number'] *100/ @property_occupancy_summary.current_year_units_total_actual ).abs.round(2)
				end
			end
			row=row+1
		end
		@property_occupancy_summary.update_attributes(h) if !h.empty?
	end
	def wres_exposure_to_vacancy_details(oo,row)
		arr =["number","%"]
		for col in 1..oo.last_column
      if !oo.cell(row,col).nil? and !oo.cell(row,col).blank?
        if arr.include?(convert_title_val(oo.cell(row,col)))
          @titles << [convert_title_val(oo.cell(row,col)), col] if @titles.length < 2
        end
      end
		end
	end
	def wres_physical_occupancy_details(oo,row)
		arr =["physical occupancy","occupied","vacant","total"]
		for col in 1..oo.last_column
      if !oo.cell(row,col).nil? and !oo.cell(row,col).blank?
        if arr.include?(convert_title_val(oo.cell(row,col)))
          @titles << [convert_title_val(oo.cell(row,col)), col]
        end
      end
		end
	end
	def wres_find_value_for_each_column(heading,oo,row)
		for title in @titles
			att = title if title[0] == heading
		end
		value=''
		if !att.nil?
			value = oo.cell(row,att[1]) if !oo.cell(row,att[1]).nil? and !oo.cell(row,att[1]).blank?
			value = oo.cell(row,att[1]-1) if !oo.cell(row,att[1]-1).nil? and !oo.cell(row,att[1]-1).blank?
			value = oo.cell(row,att[1]+1) if !oo.cell(row,att[1]+1).nil? and !oo.cell(row,att[1]+1).blank?
		end
		return value
	end
  def wres_store_titles(start_row,oo)
		for col in 1..oo.last_column
      if !oo.cell(start_row,col).nil? and !oo.cell(start_row,col).blank?
        @titles << [convert_title_val(oo.cell(start_row,col)).gsub("\n","") , col]
      end
		end
  end
	def convert_title_val(val)
		val = val.delete 194.chr+160.chr
		val = val.downcase.strip
	end
	def remove_task_collaborators(doc)
		if !doc.task.nil? || !doc.variance_task.nil?
			if !doc.task.nil?
				task = Task.find_by_document_id(doc.id,:conditions=>["(is_completed is null or is_completed = 0) and task_type_id != 5"])
				task_collaborator = TaskCollaborator.find_by_task_id_and_user_id(task.id,params[:mem_id]) if !task.nil?
				task_collaborator.destroy if task_collaborator !=nil
      end
      if !doc.variance_task.nil?
				task = Task.find_by_document_id(doc.id,:conditions=>["(is_completed is null or is_completed = 0) and task_type_id = 5"])
				task_collaborator = TaskCollaborator.find_by_task_id_and_user_id(task.id,params[:mem_id]) if !task.nil?
				task_collaborator.destroy if task_collaborator !=nil
      end
	  end
	end
	
		def remove_task_collaborators_move_to_copy_to(doc)
		if !doc.task.nil? || !doc.variance_task.nil?
			if !doc.task.nil?
				task = Task.find_by_document_id(doc.id,:conditions=>["(is_completed is null or is_completed = 0) and task_type_id != 5"])
				task.task_collaborators.destroy_all if task !=nil && !task.task_collaborators.empty?
      end
      if !doc.variance_task.nil?
				task = Task.find_by_document_id(doc.id,:conditions=>["(is_completed is null or is_completed = 0) and task_type_id = 5"])
				task.task_collaborators.destroy_all if task !=nil && !task.task_collaborators.empty?
      end
	  end
	end
	
	
	
	def property_folder(folder)
		fol = Folder.find(:first, :conditions=>["real_estate_property_id = ? and parent_id =? and is_master =?", folder, 0, 0])
		fol ? fol.id : 0
	end
	def find_property_debt_summary(property_id)
		return PropertyDebtSummary.find(:all,:conditions =>["real_estate_property_id = ? ",property_id])
	end
	def find_property_occupancy(note,month_occ,year_occ)
		return PropertyOccupancySummary.find(:first, :conditions => ["real_estate_property_id = ? and month = ? and year = ?",note,month_occ,year_occ])
	end
	def find_property_occupancy_summary(note,year_occ)
		return PropertyOccupancySummary.find(:first, :conditions => ["real_estate_property_id = ? and year = ?",note,year_occ], :order => "month desc")
	end
	def find_property_type()
		return PropertyType.find(:all)
	end
	def find_by_real_estate_property_id(property_id)
		return Folder.find_by_real_estate_property_id(property_id,:conditions=>["parent_id = 0 and is_master = 0"])
	end
	def find_portfolio_type_for_realestate()
		return PortfolioType.find_portfolio_type('Real Estate')
	end
end