module WresPerformanceReviewHelper

	def wres_for_notes_year_to_date
		#@portfolio = Portfolio.find(params[:portfolio_id])
		id_val = params[:note_id] ? params[:note_id] : (params[:id] ? params[:id] : 0)
		if @note == nil
      @note = RealEstateProperty.find_by_id(id_val)
		end 
		@notes = RealEstateProperty.find(:all, :conditions =>["portfolio_id = ?",@portfolio.id])
		
	#if params[:prop_folder]
	   if @portfolio.user_id != current_user.id || params[:prop_folder]
			@shared_folders = Folder.find_by_sql("SELECT * FROM folders WHERE id IN (SELECT folder_id FROM shared_folders WHERE is_property_folder =1 AND user_id = #{current_user.id })")
			@notes = RealEstateProperty.find(:all, :conditions=>['portfolio_id=? and id in (?)', @portfolio.id,@shared_folders.collect {|x| x.real_estate_property_id}], :order=> "created_at desc") if !(@portfolio.nil? || @portfolio.blank? || @shared_folders.nil? || @shared_folders.blank?)
			@note = RealEstateProperty.find_by_id_and_portfolio_id(id_val, @portfolio.id) if !@portfolio.nil?
  	end
		
		@prop = RealEstatePropertyStateLog.find_by_state_id_and_real_estate_property_id(5,@note.id) if @note.nil?
		@time_line_actual  = IncomeAndCashFlowDetail.find(:all,:conditions => ["resource_id =? and resource_type=? ",@note.id, 'RealEstateProperty'])		
    @time_line_start_date = Date.new(2010,1,1)
    #@time_line_end_date = Date.new(2010,12,31)
    @time_line_end_date = Date.today.end_of_month

		@actual = @time_line_actual 
		year_to_date= Date.today.last_month.month
		@ytd= []
		for m in 1..year_to_date
			@ytd << Date::MONTHNAMES[m].downcase
		end	
		@ytd_cal_flag = "false"
		if @initial_val
			if Date.today.month == 1
				@ytd_cal_flag = "true"
				#store_income_and_cash_flow_statement_for_month(Date.today.last_month.month.to_i,Date.today.last_month.year.to_i)
				wres_executive_overview_details(Date.today.last_month.month,Date.today.last_month.year)
			else
				wres_executive_overview_details_for_year
			end
		end
    #	calculate_operating_statement(@note.id, 11,2009)
    #	calculate_cash_flow_statement(@note.id, 11,2009)
	end	
	
	def wres_executive_overview_details(month_val=nil,year=nil)				
		wres_store_income_and_cash_flow_statement_for_month(month_val,year)
		wres_other_income_and_expense_details_for_month(month_val,year)		
		@property_occupancy_summary =  PropertyOccupancySummary.find_by_real_estate_property_id_and_month_and_year(@note.id,month_val,year)
		wres_occupancy_data_calculation if !@property_occupancy_summary.nil?
	end		

	# Executive summary for year-to-date funcationalcity
	def wres_executive_overview_details_for_year
		@ytd_t=true
		wres_store_income_and_cash_flow_statement
		wres_other_income_and_expense_details		
		@property_occupancy_summary = PropertyOccupancySummary.find(:first,:conditions => ["real_estate_property_id=? and year=? and month < ?",@note.id,Date.today.year,Date.today.month],:order => "month desc")	
		wres_occupancy_data_calculation if !@property_occupancy_summary.nil?		
	end	
	
	def wres_executive_overview_details_for_last_year
		@ytd_t=true
		wres_store_income_and_cash_flow_statement_for_last_year
		wres_other_income_and_expense_details_for_last_year		
		@property_occupancy_summary = PropertyOccupancySummary.find(:first,:conditions => ["real_estate_property_id=? and year=? ",@note.id,Date.today.last_year.year],:order => "month desc")		
    wres_occupancy_data_calculation if !@property_occupancy_summary.nil?					
	end	
	
	# Income & cash flow details calulation for the month      		
	def wres_store_income_and_cash_flow_statement_for_month(month_val=nil,year=nil)		
		@operating_statement={}
		@cash_flow_statement={}
		year_to_date= !month_val.nil? ? month_val : Date.today.last_month.month 
		year = Date.today.year  if year.nil?
		@current_time_period=Date.new(year,year_to_date,1)
		@ytd= []

		@ytd << "IFNULL(f."+Date::MONTHNAMES[year_to_date].downcase+",0)"
		@explanation = true
		if @portfolio_summary == true
		  qry = wres_get_query_for_portfolio_summary(year)
		else	
		  qry = wres_get_query_for_each_summary(year)
		end
		
		@op_ex = IncomeAndCashFlowDetail.find(:first,:conditions => ["resource_id =? and resource_type=? and title=? and year=?",@note.id,'RealEstateProperty','operating expenses',year])
		@op_in  = IncomeAndCashFlowDetail.find(:first,:conditions => ["resource_id =? and resource_type=? and title=? and year=?",@note.id,'RealEstateProperty','operating income',year])	
			
		if qry != nil
      asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
		     
      for cash_row in asset_details
        val ={}
        if cash_row.Parent == "cash flow statement summary"
          @cash_flow_statement[cash_row.Title] = wres_form_hash_of_data(cash_row)
        else
          data = wres_form_hash_of_data(cash_row)
          @operating_statement[cash_row.Title] = data
          @cash_flow_statement[cash_row.Title] = data	if cash_row.Title == "depreciation & amortization detail" or cash_row.Title =="net income"
        end

      end
		
      #~ variant = @operating_statement['expenses'][:budget].to_f-@operating_statement['expenses'][:actuals].to_f
      #~ percent = variant*100/@operating_statement['expenses'][:budget].to_f.abs rescue ZeroDivisionError
      #~ if  @operating_statement['expenses'][:budget].to_f==0
        #~ percent = ( @operating_statement['expenses'][:actuals].to_f == 0 ? 0 : -100 )
      #~ end
      #~ @operating_statement['expenses'][:percent] = percent
      #~ @operating_statement['expenses'][:variant] = variant
      #~ @operating_statement['expenses'][:status] = true
      wres_net_income_operation_summary_report
    end
    @portfolio_summary = false
	end		
	
  # Net operating income details display in exceutive summary
  def wres_net_income_operation_summary_report
		@divide = 1
		if @operating_statement.length > 1 and @operating_statement['net operating income']		 
			@divide = 1
      if !@operating_statement['operating expenses'].nil?
        @divide = (@operating_statement['operating expenses'][:actuals].abs > @operating_statement['operating income'][:actuals].abs) ? @operating_statement['operating expenses'][:actuals].abs : @operating_statement['operating income'][:actuals].abs
      end
			@net_income_de={}				
			@net_income_de['diff'] = (@operating_statement['net operating income'][:budget] - @operating_statement['net operating income'][:actuals]).abs
      percent =  ((@net_income_de['diff']*100) / @operating_statement['net operating income'][:budget]).abs rescue ZeroDivisionError
      if   @operating_statement['net operating income'][:budget].to_f==0
        percent = ( @operating_statement['net operating income'][:actuals].to_f == 0 ? 0 : -100 )
      end
			@net_income_de['diff_per'] = percent  #((@net_income_de['diff']*100) / @operating_statement['net operating income'][:budget]).abs
			@net_income_de['diff_word'] = (@operating_statement['net operating income'][:budget] > @operating_statement['net operating income'][:actuals]) ? 'below' : 'above' 			
			@net_income_de['diff_style'] =  (@net_income_de['diff_word'] == 'above') ? 'greenrow' : 'redrow'
		end				
	end	
	
	
	def wres_get_query_for_each_summary(year)
		if @financial
      "select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(child_id) as Record_id from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget , a.id as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('cash flow statement summary', 'operating statement summary','net operating income','cash flow from operating activities','current rent') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget,0 as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('cash flow statement summary', 'operating statement summary','net operating income','cash flow from operating activities','current rent') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title"
		else
      "select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(variance) as Variance,sum(child_id) as Record_id from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget ,0 as variance, a.id as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary','current rent') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget, 0 as variance,0 as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary','current rent') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, 0 as budget ,#{@ytd.join("+")} as variance,0 as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary','current rent') AND f.pcb_type IN ('var_amt') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title"
			
		end	
	end	
	
	def wres_store_income_and_cash_flow_statement		
		@operating_statement={}
		@cash_flow_statement={}
		year_to_date= Date.today.last_month.month
		year = Date.today.year
		@ytd= []
		@month_list = []
		for m in 1..year_to_date
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
			@month_list <<  Date.new(Time.now.year,m,1).strftime("%Y-%m-%d")
		end	
				
		#asset_details = IncomeAndCashFlowDetail.find_by_sql("select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('p') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title")
		
		if @portfolio_summary == true
		  qry = wres_get_query_for_portfolio_summary(year)
		else	
		  qry = wres_get_query_for_each_summary(year)
		end
		
			@op_ex = IncomeAndCashFlowDetail.find(:first,:conditions => ["resource_id =? and resource_type=? and title=? and year=?",@note.id,'RealEstateProperty','operating expenses',year])
			@op_in  = IncomeAndCashFlowDetail.find(:first,:conditions => ["resource_id =? and resource_type=? and title=? and year=?",@note.id,'RealEstateProperty','operating income',year])		
		
		if qry != nil
      asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
     
      for cash_row in asset_details
        val ={}
        if cash_row.Parent == "cash flow statement summary"
          @cash_flow_statement[cash_row.Title] = wres_form_hash_of_data(cash_row)
        else
          data = wres_form_hash_of_data(cash_row)
          @operating_statement[cash_row.Title] = data
          @cash_flow_statement[cash_row.Title] = data	if cash_row.Title == "depreciation & amortization detail" or cash_row.Title =="net income"

        end
      end
		

		
      wres_net_income_operation_summary_report
    end
    @portfolio_summary = false
	end	
	
  def wres_store_income_and_cash_flow_statement_for_last_year
		@operating_statement={}
		@cash_flow_statement={}
		year_to_date= Date.today.last_month.month
		year = Date.today.last_year.year
		@ytd= []
		@month_list = []
		for m in 1..12
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
			@month_list <<  Date.new(year,m,1).strftime("%Y-%m-%d")
		end	
				
		#asset_details = IncomeAndCashFlowDetail.find_by_sql("select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('operating statement summary') AND f.pcb_type IN ('p') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title")
		
		if @portfolio_summary == true
		  qry = wres_get_query_for_portfolio_summary(year)
		else	
		  qry = wres_get_query_for_each_summary(year)
		end

			@op_ex = IncomeAndCashFlowDetail.find(:first,:conditions => ["resource_id =? and resource_type=? and title=? and year=?",@note.id,'RealEstateProperty','operating expenses',year])
			@op_in  = IncomeAndCashFlowDetail.find(:first,:conditions => ["resource_id =? and resource_type=? and title=? and year=?",@note.id,'RealEstateProperty','operating income',year])	
			
		if qry != nil
      asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)     
      for cash_row in asset_details
        val ={}
        if cash_row.Parent == "cash flow statement summary"
          @cash_flow_statement[cash_row.Title] = wres_form_hash_of_data(cash_row)
        else
          data = wres_form_hash_of_data(cash_row)
          @operating_statement[cash_row.Title] = data
          @cash_flow_statement[cash_row.Title] = data	if cash_row.Title == "depreciation & amortization detail" or cash_row.Title =="net income"
        end
      end
		      wres_net_income_operation_summary_report
    end
    @portfolio_summary = false
		@explanation = false
	end

  def wres_form_hash_of_data(cash_row)
		if !cash_row[:Record_id].nil?
			val ={:actuals => cash_row.Actuals.to_f,:budget => cash_row.Budget.to_f,:variant => cash_row.Variance.to_f,:record_id=>cash_row.Record_id}
		else
			val ={:actuals => cash_row.Actuals.to_f,:budget => cash_row.Budget.to_f,:variant => cash_row.Variance.to_f,:record_id=>0}	
		end	
    variant = val[:variant] #.to_f-val[:actuals].to_f
    percent = variant*100/val[:budget].to_f.abs rescue ZeroDivisionError
    if  val[:budget].to_f==0
      percent = ( val[:actuals].to_f == 0 ? 0 : -100 )
    end
    percent=0.0 if percent.to_f.nan?
    val[:percent] = percent
  #  val[:variant] =  variant
    val[:status] = true
    return val
	end
	
	def wres_other_income_and_expense_query(year)
				"select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(variance) as Variance,sum(child_id) as Record_id from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget ,0 as variance, a.id as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('other income and expense','other') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget, 0 as variance,0 as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('other income and expense','other') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, 0 as budget ,#{@ytd.join("+")} as variance,0 as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('other income and expense','other') AND f.pcb_type IN ('var_amt') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title"		
	end	
	
	def wres_other_income_and_expense_details_for_month(month_val=nil,year=nil)		
		year_to_date= !month_val.nil? ? month_val : Date.today.last_month.month 
		year = Date.today.year  if year.nil?
		@current_time_period=Date.new(year,year_to_date,1)
		@ytd= []
		@ytd << "IFNULL(f."+Date::MONTHNAMES[year_to_date].downcase+",0)"
		wres_other_details_display_calculation(year)		
	end	
	
	def wres_other_income_and_expense_details
		year_to_date= Date.today.last_month.month
		year = Date.today.year
		@ytd= []
		@month_list = []
		for m in 1..year_to_date
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
			@month_list <<  Date.new(Time.now.year,m,1).strftime("%Y-%m-%d")
		end			
		wres_other_details_display_calculation(year)		
	end

  def wres_other_income_and_expense_details_for_last_year
		year_to_date= Date.today.last_month.month
		year = Date.today.last_year.year
		@ytd= []
		@month_list = []
		for m in 1..12
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
			@month_list <<  Date.new(year,m,1).strftime("%Y-%m-%d")
		end
    wres_other_details_display_calculation(year)		
	end

  def wres_other_details_display_calculation(year)
		@other_income_and_expenses = {}
		 qry = wres_other_income_and_expense_query(year)
		 if qry != nil
			 other_details = IncomeAndCashFlowDetail.find_by_sql(qry) 
			 for cash_row in other_details	
           @other_income_and_expenses[cash_row.Title] = wres_form_hash_of_data(cash_row)
			 end	 			 
		 end	
		if @other_income_and_expenses['other'] and @other_income_and_expenses["gain (loss) on investments"] and @other_income_and_expenses["interest expense"]
			 @other_income_and_expenses['other'][:actuals] =  @other_income_and_expenses['other'][:actuals] - @other_income_and_expenses["gain (loss) on investments"][:actuals] - @other_income_and_expenses["interest expense"][:actuals]									 
		end	
		@other_bar={}
		if @operating_statement and  @operating_statement['other income and expense']
				@other_bar['other'] = @other_income_and_expenses['other'][:actuals]  *100 / @operating_statement['other income and expense'][:actuals]  if  @other_income_and_expenses['other'][:actuals] 
				@other_bar['gain (loss) on investments'] = @other_income_and_expenses['gain (loss) on investments'][:actuals]  *100 / @operating_statement['other income and expense'][:actuals]  if     @other_income_and_expenses['gain (loss) on investments'] and @other_income_and_expenses['gain (loss) on investments'][:actuals] 
				@other_bar['interest expense'] = @other_income_and_expenses['interest expense'][:actuals]  *100 / @operating_statement['other income and expense'][:actuals]  if  @other_income_and_expenses['interest expense'][:actuals] 
				@other_bar['maintenance projects'] = @other_income_and_expenses['maintenance projects'][:actuals]  *100 / @operating_statement['other income and expense'][:actuals]  if  @other_income_and_expenses['maintenance projects'][:actuals] 		
         tot_b =  @operating_statement['other income and expense'][:budget]   				
				 tot_a =  @operating_statement['other income and expense'][:actuals]   				
				@captial_diff={:diff => @operating_statement['other income and expense'][:variant] ,:diff_percent => @operating_statement['other income and expense'][:percent],:style => (tot_b > tot_a ) ?  "greenrow" : "redrow",:tot_actual => tot_a,:diff_word => (tot_b > tot_a ) ? "below" : "above"}			
		end					
	end	
	
	
	
	
	
	
	
	
	
def wres_other_income_and_expense_year
		@operating_statement={}
		@cash_flow_statement={}
		year_to_date= Date.today.last_month.month
		year = Date.today.year
		@ytd= []
		@month_list = []
		for m in 1..year_to_date
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
			@month_list <<  Date.new(Time.now.year,m,1).strftime("%Y-%m-%d")
		end	
	  qry = get_query_for_other_income_and_expense(year)
		if qry != nil
      asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
      @operating_statement['expenses']={:budget =>0 ,:actuals =>0}
      for cash_row in asset_details
        val ={}
        if cash_row.Parent == "cash flow statement summary"
          @cash_flow_statement[cash_row.Title] = form_hash_of_data(cash_row)
        else
          data = form_hash_of_data(cash_row)
          @operating_statement[cash_row.Title] = data
          @cash_flow_statement[cash_row.Title] = data	if cash_row.Title == "depreciation & amortization detail" or cash_row.Title =="net income"
          if cash_row.Title=="recoverable expenses detail" or cash_row.Title=="non-recoverable expenses detail"
            @operating_statement['expenses'][:budget]=  @operating_statement['expenses'][:budget].to_f + cash_row.Budget.to_f
            @operating_statement['expenses'][:actuals]=  @operating_statement['expenses'][:actuals].to_f + cash_row.Actuals.to_f
          end
        end
        @operating_statement['expenses'][:record_id]=  cash_row.Record_id if @financial
      end
      variant = @operating_statement['expenses'][:budget].to_f-@operating_statement['expenses'][:actuals].to_f
      percent = variant*100/@operating_statement['expenses'][:budget].to_f.abs rescue ZeroDivisionError
      if  @operating_statement['expenses'][:budget].to_f==0
        percent = ( @operating_statement['expenses'][:actuals].to_f == 0 ? 0 : -100 )
      end
      @operating_statement['expenses'][:percent] = percent
      @operating_statement['expenses'][:variant] = variant
      @operating_statement['expenses'][:status] = true
     #wres_net_income_operation_summary_report
	 end
	end
	
	
	 def wres_other_income_and_expense_last_year
		@operating_statement={}
		@cash_flow_statement={}
		year_to_date= Date.today.last_month.month
		year = Date.today.last_year.year
		@ytd= []
		@month_list = []
		for m in 1..12
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
			@month_list <<  Date.new(year,m,1).strftime("%Y-%m-%d")
		end	
	  qry = get_query_for_other_income_and_expense(year)
		if qry != nil
      asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)     
      for cash_row in asset_details
        val ={}
        if cash_row.Parent == "cash flow statement summary"
          @cash_flow_statement[cash_row.Title] = wres_form_hash_of_data(cash_row)
        else
          data = wres_form_hash_of_data(cash_row)
          @operating_statement[cash_row.Title] = data
          @cash_flow_statement[cash_row.Title] = data	if cash_row.Title == "depreciation & amortization detail" or cash_row.Title =="net income"
        end
      end
    end
    @portfolio_summary = false
		@explanation = false
	end
	
	
	

def get_query_for_other_income_and_expense(year)
"select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(variance) as Variance,sum(child_id) as Record_id from (SELECT k.title as Parent, a.title as Title, f.pcb_type,#{@ytd.join("+")} as actuals, 0 as budget ,0 as variance,a.id as child_id  FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('other income and expense','other','maintenance projects','operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals,#{@ytd.join("+")} as budget, 0 as variance,0 as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('other income and expense','other','maintenance projects','operating statement summary') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, 0 as budget,#{@ytd.join("+")} as variance,0 as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN ('other income and expense','other','maintenance projects','operating statement summary') AND f.pcb_type IN ('var_amt') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title"
end	

	
def find_other_income_and_expense_percentage(act,bud)
	@per = bud != 0 ?  (act * 100) / bud  : '100'
	@col = bud > act ? 'red' : 'green' 
	@per = @per.to_i > 100 ?  '100' : @per
	@per = (act == 0 &&  bud != 0) ? '100' : @per
	return @per,@col
end	
	
	
def wres_other_income_and_expense_month(month_val=nil,year=nil)
		@operating_statement={}
		@cash_flow_statement={}
		@financial = true
		year_to_date= !month_val.nil? ? month_val : Date.today.last_month.month 
		year = Date.today.year  if year.nil?
		@current_time_period=Date.new(year,year_to_date,1)
		@ytd= []
		@ytd << "IFNULL(f."+Date::MONTHNAMES[year_to_date].downcase+",0)"
		@explanation = true
		  qry = get_query_for_other_income_and_expense(year)
		if qry != nil
      asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
      @operating_statement['expenses']={:budget =>0.0 ,:actuals =>0.0}
      for cash_row in asset_details
        val ={}
        if cash_row.Parent == "cash flow statement summary"
          @cash_flow_statement[cash_row.Title] = form_hash_of_data(cash_row)
        else
          data = form_hash_of_data(cash_row)
          @operating_statement[cash_row.Title] = data
          @cash_flow_statement[cash_row.Title] = data	if cash_row.Title == "depreciation & amortization detail" or cash_row.Title =="net income"
          if cash_row.Title=="recoverable expenses detail" or cash_row.Title=="non-recoverable expenses detail"
            @operating_statement['expenses'][:budget]=  @operating_statement['expenses'][:budget].to_f + cash_row.Budget.to_f
            @operating_statement['expenses'][:actuals]=  @operating_statement['expenses'][:actuals].to_f + cash_row.Actuals.to_f
            @operating_statement['expenses'][:record_id]=  cash_row.Record_id if @financial
          end
        end
      end
      variant = @operating_statement['expenses'][:budget].to_f-@operating_statement['expenses'][:actuals].to_f
      percent = variant*100/@operating_statement['expenses'][:budget].to_f.abs rescue ZeroDivisionError
      if  @operating_statement['expenses'][:budget].to_f==0
        percent = ( @operating_statement['expenses'][:actuals].to_f == 0 ? 0 : -100 )
      end
      @operating_statement['expenses'][:percent] = percent
      @operating_statement['expenses'][:variant] = variant
      @operating_statement['expenses'][:status] = true
#      wres_net_income_operation_summary_report
    end
    @portfolio_summary = false
	end			
	
	
	
	def wres_occupancy_data_calculation
			if !@property_occupancy_summary.nil?
				@exposure_vacancy = {}
				@exposure_vacancy['net_exposure_to_vacancy'] ={}
				@exposure_vacancy['net_exposure_to_vacancy'][:sqft] = (@property_occupancy_summary.total_building_rentable_s * @property_occupancy_summary.net_exposure_to_vacancy_percentage) / 100
				@exposure_vacancy['net_exposure_to_vacancy'][:percent] = @property_occupancy_summary.net_exposure_to_vacancy_percentage
				@exposure_vacancy['net_exposure_to_vacancy'][:bar] =  (@exposure_vacancy['net_exposure_to_vacancy'][:sqft] and @exposure_vacancy['net_exposure_to_vacancy'][:sqft] > 0) ? 100 : 0
				@exposure_vacancy['net_exposure_to_vacancy'][:unit]  = @property_occupancy_summary.net_exposure_to_vacancy_number
				wres_form_hash_for_occupancy_exposure_vacancy('occupied_preleased',@property_occupancy_summary.occupied_preleased_percentage,@property_occupancy_summary.occupied_preleased_number )
				wres_form_hash_for_occupancy_exposure_vacancy('occupied_on_notice',@property_occupancy_summary.occupied_on_notice_percentage,@property_occupancy_summary.occupied_on_notice_number )
				wres_form_hash_for_occupancy_exposure_vacancy('vacant_leased',@property_occupancy_summary.vacant_leased_percentage,@property_occupancy_summary.vacant_leased_number )
				wres_form_hash_for_occupancy_exposure_vacancy('currently_vacant_leases',@property_occupancy_summary.currently_vacant_leases_percentage,@property_occupancy_summary.currently_vacant_leases_number)	

				@partial_file = "/properties/sample_pie"
				@swf_file = "Pie2D.swf"
				@xml_partial_file = "/properties/sample_pie"
				#@vaccant  		=  @property_occupancy_summary.current_year_sf_vacant_actual
				@vaccant  		=  @property_occupancy_summary.current_year_units_vacant_actual
				#@occupied 	=   @property_occupancy_summary.current_year_sf_occupied_actual
				@occupied 	=   @property_occupancy_summary.current_year_units_occupied_actual
				@vaccant_percent = (@vaccant  * 100 / @property_occupancy_summary.current_year_units_total_actual.to_f).abs.round
				@occupied_percent = (@occupied  * 100 / @property_occupancy_summary.current_year_units_total_actual.to_f).abs.round
				
        @start_angle = 0
				if !(@vaccant.nil? || @vaccant.blank? || @vaccant == 0 || @occupied.nil? || @occupied.blank? || @occupied == 0)
					if @vaccant <= @occupied
							@start_angle = (180 - (1.8 * ((@vaccant * 100)/(@vaccant+@occupied)  rescue ZeroDivisionError)))
					else 
							@start_angle = (1.8 * ((@vaccant * 100)/(@vaccant+@occupied)  rescue ZeroDivisionError))
					end
				end 				
			end	
	end	
		
	def wres_form_hash_for_occupancy_exposure_vacancy(title,percent_value,unit)	
				@exposure_vacancy[title] ={}
				@exposure_vacancy[title][:sqft] = (@property_occupancy_summary.total_building_rentable_s * percent_value) / 100
				@exposure_vacancy[title][:percent] = percent_value
				@exposure_vacancy[title][:bar] = @exposure_vacancy[title][:sqft]   *100 / @exposure_vacancy['net_exposure_to_vacancy'][:sqft] 	
				@exposure_vacancy[title][:unit] = unit
	end	
		
		
	# Performance review financial sub page for month calculation
	def wres_calculate_the_financial_sub_graph_for_month(month,year)
		@month = month
		#year = (!params[:tl_year].nil?  and !params[:tl_year].blank?)  ? params[:tl_year].to_i : Date.today.last_month.month  
		@ytd= []
		@ytd << "IFNULL(f."+Date::MONTHNAMES[month.to_i].downcase+",0)"	
    params[:financial_sub] = params[:financial_sub].gsub("?","\'") if params[:financial_sub]
		if params[:financial_sub] and params[:financial_sub] == "Operating Expenses"
      qry = "select  Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(child_id) as Record_id from (SELECT  a.title as Title, f.pcb_type, #{@ytd.join("+")}  as actuals, 0 as budget,a.id as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail','operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'	UNION 	SELECT  a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")}  as budget,0 as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail','operating statement summary') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'		) xyz group by  Title"
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
		elsif params[:financial_subid]
			e = IncomeAndCashFlowDetail.find_by_id(params[:financial_subid]) 
			if e && (e.title == "operating expenses" || e.title == "operating revenue")
      @using_sub_id = true
			a= []
			a << params[:financial_subid] 
			a << e.parent_id
      qry = wres_get_query_for_financial_sub_page(a.join(","),year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
			else
      @using_sub_id = true
      qry = wres_get_query_for_financial_sub_page(params[:financial_subid],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
      if params[:financial_sub] == "operating income"
         	wres_total_operating_revenue_sub_page(year)
  		end
			end
		else	
      qry = wres_get_query_for_financial_sub_page(params[:financial_sub],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
    end
    @explanation = true
	end	
	
	
def wres_total_operating_revenue_sub_page(year)
		@totals = []
		@b= []
		@totals = []
		@year =year
			@asset_details.each do |a|
				 @totals << a
			   @b <<  "string to separate #{a.Title}" 
         q1 = wres_get_query_for_financial_sub_page(a.Record_id,year)
         q2 = IncomeAndCashFlowDetail.find_by_sql(q1)
  		   @b << q2 << "added string" 
		  end
      @asset_details = []
 	  	 @b.each do |m|
		 	 m.each do |n|
			 	@asset_details << n
			end
  	  end 
		@v = @asset_details.split("added string")
		i =0 
		@v.each do |t|
       t << @totals[i] 		
			 i = i +1
		 end
	  @revenue_percentage = 0
 		 @revenue_var = 0
		 @revenue_act = 0
		 @revenue_bud = 0
		@totals.each do |t| 
		  @revenue_act = @revenue_act + t.Actuals.to_f
		  @revenue_bud = @revenue_bud + t.Budget.to_f
	  end 
		@revenue_percentage  = @revenue_bud != 0 ?  ( (@revenue_bud - @revenue_act)/@revenue_bud) * 100  : 0
    @revenue_var = @revenue_bud - @revenue_act 
 end
	
	
	
	
	def wres_get_query_for_financial_sub_page(parent,year)
		if  @using_sub_id
			"select  Title, sum(actuals) as Actuals, sum(budget) as Budget, sum(child_id) as Record_id from (SELECT  a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget, a.id as child_id FROM `income_and_cash_flow_details` a   inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.parent_id IN (#{parent}) AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT  a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget, 0 as child_id FROM `income_and_cash_flow_details` a    inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.parent_id IN (#{parent}) AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Title"
		else	
      "select Parent, Title, sum(actuals) as Actuals, sum(budget) as Budget, sum(child_id) as Record_id from (SELECT k.title as Parent, a.title as Title, f.pcb_type, #{@ytd.join("+")} as actuals, 0 as budget, a.id as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN (\"#{parent}\") AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail' UNION SELECT k.title as Parent, a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")} as budget, 0 as child_id FROM `income_and_cash_flow_details` a  LEFT JOIN income_and_cash_flow_details k ON k.id=a.parent_id  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND k.title IN (\"#{parent}\") AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail') xyz group by Parent, Title"	
		end	
	end
	
	
	
	# Performance review financial sub page for year-to-date calculation
	def wres_calculate_the_financial_sub_graph(year=nil)	
		#year = (!params[:tl_year].nil?  and !params[:tl_year].blank?)  ? params[:tl_year].to_i : Date.today.last_month.month  
		year_to_date= Date.today.last_month.month
		@ytd= []
		for m in 1..year_to_date
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
		end		
    params[:financial_sub] = params[:financial_sub].gsub("?","\'") if params[:financial_sub]
		if params[:financial_sub] and params[:financial_sub] == "Operating Expenses"
      qry = "select  Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(child_id) as Record_id from (SELECT  a.title as Title, f.pcb_type, #{@ytd.join("+")}  as actuals, 0 as budget,a.id as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail','operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'	UNION 	SELECT  a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")}  as budget,0 as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail','operating statement summary') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'		) xyz group by  Title"
			
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
		elsif params[:financial_subid]
      @using_sub_id = true
      qry = get_query_for_financial_sub_page(params[:financial_subid],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
      if params[:financial_sub] == "operating income"
       	wres_total_operating_revenue_sub_page(year)
  		end
		else	
      qry = get_query_for_financial_sub_page(params[:financial_sub],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
    end		
		@explanation = true
	end	
	
	# Performance review financial sub page for last year calculation
	def wres_calculate_the_financial_sub_graph_for_last_year(year=nil)	
		#year = (!params[:tl_year].nil?  and !params[:tl_year].blank?)  ? params[:tl_year].to_i : Date.today.last_month.month  
		year_to_date= Date.today.last_month.month
		@ytd= []
		for m in 1..12
			@ytd << "IFNULL(f."+Date::MONTHNAMES[m].downcase+",0)"
		end		
    params[:financial_sub] = params[:financial_sub].gsub("?","\'") if params[:financial_sub]
		if params[:financial_sub] and params[:financial_sub] == "Operating Expenses"
      qry = "select  Title, sum(actuals) as Actuals, sum(budget) as Budget,sum(child_id) as Record_id from (SELECT  a.title as Title, f.pcb_type, #{@ytd.join("+")}  as actuals, 0 as budget,a.id as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail','operating statement summary') AND f.pcb_type IN ('c') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'	UNION 	SELECT  a.title as Title, f.pcb_type, 0 as actuals, #{@ytd.join("+")}  as budget,0 as child_id FROM `income_and_cash_flow_details` a  inner join property_financial_periods f ON a.id = f.source_id WHERE a.resource_id=#{@note.id} AND a.resource_type = 'RealEstateProperty' AND a.title IN ('recoverable expenses detail','non-recoverable expenses detail','operating statement summary') AND f.pcb_type IN ('b') AND a.year=#{year} AND f.source_type='IncomeAndCashFlowDetail'		) xyz group by  Title"
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
		elsif params[:financial_subid]
      @using_sub_id = true
      qry = get_query_for_financial_sub_page(params[:financial_subid],year)
			@asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
      if params[:financial_sub] == "operating income"
         	wres_total_operating_revenue_sub_page(year)
  		end
		else	
      qry = get_query_for_financial_sub_page(params[:financial_sub],year)
      @asset_details = IncomeAndCashFlowDetail.find_by_sql(qry)
    end		
		@explanation = true
	end		
		



end
