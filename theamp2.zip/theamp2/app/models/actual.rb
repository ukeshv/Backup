class Actual < ActiveRecord::Base
	belongs_to :user
	belongs_to :resource, :polymorphic => true 	
	belongs_to :property_type
	belongs_to :cash_flow_detail
end
