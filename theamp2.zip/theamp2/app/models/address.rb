class Address < ActiveRecord::Base
	has_one :real_estate_property
  attr_accessor  :add_property_validity
	validates_presence_of :province ,:message => "Can't be blank"  ,:if => Proc.new { |address| (address.add_property_validity != "no") }
end
