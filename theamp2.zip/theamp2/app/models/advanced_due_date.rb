class AdvancedDueDate < ActiveRecord::Base
	
	#Associations
	belongs_to :template, :class_name=>"Document", :foreign_key=>"template_id"
	has_many :cash_flow_details, :dependent=>:destroy
	belongs_to :resource, :polymorphic => true 	
	
end
