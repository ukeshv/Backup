class Brochure < ActiveRecord::Base
	belongs_to :attachable, :polymorphic => true 	
	has_attachment :storage => :file_system, :size => 1.kilobytes..60.megabytes, :path_prefix => 'public/portfolio_images',:content_type => ['application/pdf', :image], :resize_to => 'x50'
	belongs_to :attachable, :polymorphic => true
	validates_as_attachment
end
