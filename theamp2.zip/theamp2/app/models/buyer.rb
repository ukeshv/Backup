class Buyer < ActiveRecord::Base
  belongs_to :user
  belongs_to :property
  validates_format_of :contact_email,    :with => Authentication.email_regex, :message => Authentication.bad_email_message
end
