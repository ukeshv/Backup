class CapitalExpenditureExplanation < ActiveRecord::Base
  belongs_to :user
  belongs_to :property_capital_improvement
  acts_as_commentable
  belongs_to :document
end
