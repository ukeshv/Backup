class CashFlowDetail < ActiveRecord::Base
	belongs_to :advanced_due_date
	has_many :budgets, :dependent=>:destroy
	has_many :actuals, :dependent=>:destroy
end
