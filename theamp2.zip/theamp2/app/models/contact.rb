class Contact < ActiveRecord::Base
	 validates_presence_of :name, :message=>"Name can't be blank"
	 validates_presence_of :email, :message=>"Email can't be blank"
	 validates_presence_of :phone_number, :message=>"Phone number can't be blank"
	 validates_presence_of :company_name, :message=>"Company name can't be blank"
	 validates_presence_of :comment, :message=>"Comments can't be blank"
	 validates_format_of :email,    :with => Authentication.email_regex, :message => Authentication.bad_email_message
	 validates_format_of :phone_number, :with => /^(\d{10}){1}?(\d)*$/, :message =>"Provide a valid Phone No", :allow_nil=>true, :allow_blank=>true
end
