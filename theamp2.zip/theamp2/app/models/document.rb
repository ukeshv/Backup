class Document < ActiveRecord::Base
  has_attachment :storage => :file_system, :size => 1.kilobytes..60.megabytes, :content_type => ['application/vnd.ms-excel'], :path_prefix => 'public/documents'		
  belongs_to :folder
	belongs_to :user	
	has_one :document_name
  has_many :shared_documents, :dependent=>:destroy
  has_many :advanced_due_dates, :foreign_key=>"template_id",  :dependent=>:destroy
	has_many :event_resources, :as=>:resource,:dependent=>:destroy
  belongs_to :real_estate_property
  belongs_to :property
	has_many :task_documents , :dependent=>:destroy
	has_one :task , :dependent=>:destroy, :conditions => "task_types.task_name != 'Explain Variances'",:include=>'task_type'
  has_one :variance_task ,:class_name=>'Task', :dependent=>:destroy, :conditions => "task_types.task_name = 'Explain Variances'", :include=>'task_type'
  has_one :variance_threshold
	before_save :check_file_name_already_exists
  has_many :income_cash_flow_explanations
  has_many :capital_expenditure_explanations
  has_many :task_files, :dependent => :destroy

	has_ipaper_and_uses 'AttachmentFu'
  acts_as_commentable
	
	def check_file_name_already_exists	
      folder_id = self.folder_id
      if self.id.nil?			
					document = Document.find_by_folder_id(self.folder_id,:conditions=>["filename = ? and real_estate_property_id is not NULL",self.filename.strip])
			else
				  document = Document.find_by_folder_id(self.folder_id,:conditions=>["filename = ? and real_estate_property_id is not NULL and id!=?",self.filename.strip,self.id])
      end				
			i =1
			d_name = self.filename
			while document !=nil				
				extension = self.filename.split(".").pop
				first_set =  self.filename.split(".")
				first_set.pop
				first_set= first_set.join('.')
				document_name = "#{first_set}_#{i}.#{extension}"				
				if self.id.nil?			
						document = Document.find_by_folder_id(self.folder_id,:conditions=>["filename = ? and real_estate_property_id is not NULL",document_name.strip])
				else
						document = Document.find_by_folder_id(self.folder_id,:conditions=>["filename = ? and real_estate_property_id is not NULL and id!=?",document_name.strip,self.id])
				end				
				i += 1
			end
			document_name =  document_name.nil? ? self.filename : document_name					
			self.filename = document_name  		
	end

  def self.find_document_by_id(id)
    Document.find_by_id(id)
  end
  def self.finding_document_id(i)
    Document.find(i.task.document_id)
  end
end