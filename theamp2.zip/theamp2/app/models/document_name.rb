class DocumentName < ActiveRecord::Base
	
	belongs_to :folder
	belongs_to :document
	belongs_to :user
	has_many :event_resources, :as=>:resource,:dependent=>:destroy
  belongs_to :real_estate_property
  belongs_to :property
	has_many :share_document_names, :dependent=>:destroy

  def self.find_id_model(id)
    DocumentName.find(id)
  end
	
end
