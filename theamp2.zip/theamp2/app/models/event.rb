class Event < ActiveRecord::Base
	has_many :event_resources,:dependent=>:destroy
	
  def self.create_new_event(action,user_id,shared_user_id,resources,person_type,folder_name,description2,other_info=nil)	
		if description2 != nil
			if description2.class == Array
				if action == "mapped_secondary_file"
					#~ a  = " attached with the #{description2[0]} <a href= '/real_estate/#{description2[3]}/properties/#{description2[4]}?task_id=#{description2[2]}' title='#{description2[1]}'>#{description2[1]}</a>"
					#~ folder_name = "<a href= '/real_estate/#{description2[3]}/properties/#{description2[4]}?task_id=#{description2[2]}' title='#{folder_name}'>#{folder_name}</a>"
					a  = " attached with the #{description2[0]} #{description2[1]}"
					folder_name = "#{folder_name}"
				elsif action == "create_secondary_file"
					#~ a  = " attached with the #{description2[0]} <a href= '/real_estate/#{description2[3]}/properties/#{description2[4]}?task_id=#{description2[2]}' title='#{description2[1]}'>#{description2[1]}</a>"
					#~ folder_name = "<a href= '/real_estate/#{description2[3]}/properties/#{description2[4]}?task_id=#{description2[2]}' title='#{folder_name}'>#{folder_name}</a>"
					a  = " attached with the #{description2[0]} #{description2[1]}"
					folder_name = "#{folder_name}"
				elsif action == "collaborators"
					#~ a  = " for the #{description2[0]} <a href= '/real_estate/#{description2[3]}/properties/#{description2[4]}?task_id=#{description2[2]}' title='#{description2[1]}'>#{description2[1]}</a>"
					a  = " for the #{description2[0]} #{description2[1]}"
				elsif action == "de_collaborators"
					#a  = " for the #{description2[0]} <a href= '/real_estate/#{description2[3]}/properties/#{description2[4]}?task_id=#{description2[2]}' title='#{description2[1]}'>#{description2[1]}</a>"
					a  = " for the #{description2[0]} #{description2[1]}"
				elsif action == "task_commented"
					#folder_name = "<a href= '/real_estate/#{description2[3]}/properties/#{description2[4]}?task_id=#{description2[2]}' title='#{folder_name}'>#{folder_name}</a>"
					folder_name = "#{folder_name}"
				elsif action == "task_del_commented"
					#folder_name = "<a href= '/real_estate/#{description2[3]}/properties/#{description2[4]}?task_id=#{description2[2]}' title='#{folder_name}'>#{folder_name}</a>"
					folder_name = "#{folder_name}"
				elsif action == "task_up_commented"
					#folder_name = "<a href= '/real_estate/#{description2[3]}/properties/#{description2[4]}?task_id=#{description2[2]}' title='#{folder_name}'>#{folder_name}</a>"
					folder_name = "#{folder_name}"
				elsif action == "task_rep_commented"
					#folder_name = "<a href= '/real_estate/#{description2[3]}/properties/#{description2[4]}?task_id=#{description2[2]}' title='#{folder_name}'>#{folder_name}</a>"
					folder_name = "#{folder_name}"
				else
					#a = "from <a href= '/events/#{description2[1]}/folder_display' title='#{description2[0]}'>#{description2[0]}</a> to <a href= '/events/#{description2[3]}/folder_display' title='#{description2[2]}'>#{description2[2]}</a>"
					a = "from #{description2[0]} to #{description2[2]}"
				end
			else
				a = description2
			end
		else
			a = nil
		end
		e = self.create(:user_id => user_id,:shared_user_id =>shared_user_id,:action_type => action,:description => folder_name,:performer => person_type,:description2=>a)
		for each_res in resources
			EventResource.create(:event_id => e.id ,:resource => each_res)
		end	
	end	
	
  def self.create_new_event_multiple(action,user_id,shared_user_id,resources,person_type,other_info=nil)	
		e = self.create(:user_id => user_id,:shared_user_id =>shared_user_id,:action_type => action,:description => other_info,:performer => person_type )
		for each_res in resources
			EventResource.create(:event_id => e.id ,:resource => each_res)
		end	
	end		

end

##/real_estate/486/properties/631?open_folder=16094