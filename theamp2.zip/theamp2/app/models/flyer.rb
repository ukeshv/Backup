class Flyer < ActiveRecord::Base
	belongs_to :real_estate_property
	belongs_to :attachable, :polymorphic=>true
	has_attachment :storage=>'file_system', :size=> 1.kilobytes..60.megabytes, :path_prefix=> '/public/flyers', :content_type=>['application/vnd.ms-excel']
	#validates_as_attachment
	has_ipaper_and_uses 'AttachmentFu'
end
