class Folder < ActiveRecord::Base
	
	#Validations
  has_many :documents,:dependent=>:destroy
  has_many :document_names,:dependent=>:destroy
	has_many :shared_folders,:dependent=>:destroy 
	has_many :shared_documents,:dependent=>:destroy 
	has_many :event_resources, :as=>:resource,:dependent=>:destroy
	has_many :tasks
	belongs_to :user
	belongs_to :portfolio
  belongs_to :property
  belongs_to :real_estate_property
  before_save :check_folder_name_already_exists
  
  acts_as_commentable
	def check_folder_name_already_exists
     folder_id = self.id
      if self.id.nil?
					folder = Folder.find_by_name(self.name,:conditions=>["parent_id = ? and real_estate_property_id =?",self.parent_id,self.real_estate_property_id])
			else
				folder = Folder.find_by_name(self.name,:conditions=>["parent_id = ? and real_estate_property_id = ? and id!=?",self.parent_id,self.real_estate_property_id,self.id])
      end
			i =1
			f_name = self.name
			while folder !=nil
				first_set =  self.name
				folder_name = "#{first_set}_#{i}"
				if self.id.nil?
						folder = Folder.find_by_name(folder_name.strip,:conditions=>["parent_id = ? and real_estate_property_id = ?",self.parent_id,self.real_estate_property_id])
				else
						folder = Folder.find_by_name(folder_name.strip,:conditions=>["parent_id = ? and real_estate_property_id = ? and id!=?",self.parent_id,self.real_estate_property_id,self.id])
				end
				i += 1
			end
			folder_name =  folder_name.nil? ? self.name : folder_name
			self.name = folder_name
  end


	def self.subfolders_docs(folder_id,loop)
		if loop == true
  		@folder_snew = [ ] 
	  	@doc_snew = [ ] 
		  @doc_namenew = [ ] 
    end
		
		
		folders = self.find(:all,:conditions=> ["parent_id = ?",folder_id])
		@folder_snew = [ ] if @folder_snew.nil? || @folder_snew.empty?
		@doc_snew = [ ] if @doc_snew.nil? || @doc_snew.empty?
		@doc_namenew = [ ] if @doc_namenew.nil? || @doc_namenew.empty?
		folders.each do |f|							       
			self.subfolders_docs(f.id,false)	
			@folder_snew << f
		end
		documents = Document.find(:all,:conditions=> ["folder_id = ?",folder_id])
		document_name = DocumentName.find(:all,:conditions=> ["folder_id = ?",folder_id])
		@doc_snew += documents
		@doc_namenew += document_name
		return @folder_snew,@doc_snew,@doc_namenew
	end	
	
  def self.find_mail_path_folder(fol)
		arr =[]
		i = 0			
		while !fol.nil?
			tmp_name = "#{fol.name}"
			name = (i == 0) ? "#{fol.name}" :  "#{tmp_name}"
			n = (fol.name == 'my_files' && fol.parent_id == 0) ? name.titlecase : name
			arr << n
			fol =  Folder.find_by_id(fol.parent_id)
			i += 1
		end		
		return arr.reverse.join(" > ")
  end

  def self.find_parent_id_and_real_estate_property_id(parent_id,document)
   Folder.find_by_parent_id_and_real_estate_property_id(parent_id,document.real_estate_property_id)
  end

  def self.find_by_id_model(id)
    Folder.find(id)
  end
  def self.find_id_model(id)
    Folder.find(id)
  end
end
