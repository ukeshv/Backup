class IncomeAndCashFlowDetail < ActiveRecord::Base
	belongs_to :user
  attr_accessor :tool_tip
	has_many :property_financial_periods, :as=>:source, :dependent=>:destroy
  has_one :income_cash_flow_explanation, :conditions=> "ytd=false", :dependent=>:destroy
  has_one :income_cash_flow_explanation_ytd,:class_name=>'IncomeCashFlowExplanation', :conditions=> "ytd=true", :dependent=>:destroy
end
