class IncomeCashFlowExplanation < ActiveRecord::Base
  belongs_to :user
  belongs_to :income_and_cash_flow_detail
  acts_as_commentable
  belongs_to :document
end
