class LeasesExplanation < ActiveRecord::Base
end
