class MasterFolder < ActiveRecord::Base
	has_many :master_files, :dependent=>:destroy
	belongs_to :portfolio_type

	
end
