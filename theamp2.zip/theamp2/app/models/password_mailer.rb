class PasswordMailer < ActionMailer::Base
  def forgot_password(password)
    setup_email(password.user)
    @subject << 'You have requested to change your password'
    @body[:url] = "#{APP_CONFIG[:site_url]}/change_password/#{password.reset_code}"
  end

  def reset_password(user)
    setup_email(user)
    @subject << 'Your password has been reset.'
    @url_login = "#{APP_CONFIG[:site_url]}/login"
  end

  protected
  
  def setup_email(user)
    @recipients = "#{user.email}"
    @name_or_email = user.name.blank? ? user.email : user.name
    @from = APP_CONFIG[:admin_email]
    @forgotmail = "#{APP_CONFIG[:site_url]}/contactus"
    @subject = "[#{APP_CONFIG[:site_name]}] "
    @sent_on = Time.now
    @content_type="text/html"
    @body[:user] = user
  end
end





