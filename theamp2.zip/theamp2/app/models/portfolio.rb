class Portfolio < ActiveRecord::Base
	has_many :properties, :dependent=>:destroy
  has_many :real_estate_properties, :dependent=>:destroy
	has_one :portfolio_image ,:as => :attachable
	has_one :excel_template, :dependent=>:destroy
	has_many :folders, :dependent=>:destroy
	belongs_to :portfolio_type
	belongs_to :user
	
	validates_presence_of :name ,:message => "Please provide portfolio name"
	validates_uniqueness_of :name , :message => "Portfolio already exists" ,:scope => [:user_id,:portfolio_type_id]
	#validates_presence_of :portfolio_image,:message => "Please upload the image"

  def self.find_portfolio(id)
    Portfolio.find_by_id(id)
  end
end
