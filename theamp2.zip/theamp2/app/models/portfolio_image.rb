class PortfolioImage < ActiveRecord::Base
	has_attachment :storage => :file_system, :size => 1.kilobytes..160.megabytes, :content_type => [:image], :path_prefix => 'public/portfolio_images'	
  belongs_to :attachable, :polymorphic => true
  belongs_to :real_estate_property
  belongs_to :user
	validates_as_attachment
end
