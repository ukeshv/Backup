class PortfolioLog < ActiveRecord::Base
end
