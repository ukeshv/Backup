class PortfolioType < ActiveRecord::Base
	has_many :master_folders, :dependent=>:destroy
	has_many :master_filenames, :dependent=>:destroy
	has_many :portfolios, :dependent=>:destroy
  validates_presence_of :name
  validates_length_of :name,:within => 3..40
  validates_uniqueness_of :name, :message =>"Portfolio type already exists"
	def self.find_portfolio_type(name)
		PortfolioType.find_by_name(name).id
	end
  def self.collect_all_name_and_id
    PortfolioType.all.collect {|p| [ p.name, p.id ] }
  end
end
