class ProofDocument < ActiveRecord::Base
	has_attachment :storage => :file_system, :size => 1.kilobytes..60.megabytes, :path_prefix => 'public/proof_documents'		
	belongs_to :user
	belongs_to :resource, :polymorphic => true
end
