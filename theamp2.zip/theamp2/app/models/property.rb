class Property < ActiveRecord::Base
	belongs_to :portfolio
  has_many :rent_rolls, :as=>:resource, :dependent=>:destroy
  has_one :property_borrower_detail, :dependent=>:destroy	
  has_one :property_collateral_detail, :dependent=>:destroy		
  has_one :property_deliquency_detail, :dependent=>:destroy	
  has_one :property_details_note_information, :dependent=>:destroy		
	has_many :actuals, :as=>:resource, :dependent=>:destroy
	has_many :budgets, :as=>:resource, :dependent=>:destroy
	has_many :advanced_due_dates, :as=>:resource, :dependent=>:destroy
	has_many :cash_flow_details, :as=>:resource, :dependent=>:destroy
  has_many :folders, :dependent=>:destroy
  has_many :documents, :dependent=>:destroy
  has_many :document_names, :dependent=>:destroy

  belongs_to :state
  belongs_to :user
  has_many :property_state_logs, :dependent=>:destroy
	has_many :buyers, :as=>:resource, :dependent=>:destroy
	has_many :proof_documents, :as=>:resource, :dependent=>:destroy
	
	attr_accessor  :check_note_id,:check_original_note_amount,:check_current_outstanding,:check_late_payments_amount_due,:check_current_interest_rate,:check_first_payment_date,:check_last_payment_date,:check_maturity_date,:check_comments,:property_coll_details,:property_borrow_details

	validates_presence_of :note_id ,:message => "Can't be blank"  #,:if => Proc.new { |property| (property.check_note_id == 1) }
	validates_uniqueness_of :note_id, :scope => :user_id ,:message => "Note Id already exists" #,:if => :uniqueness_note_id_user
	
	validates_presence_of :original_note_amount ,:message => "Original Note Amount Can't be blank"  #,:if => Proc.new { |property| property.check_original_note_amount == 1 }
	
	validates_presence_of :current_outstanding ,:message => "Current Outstanding Can't be blank" #,:if => Proc.new { |property| property.check_current_outstanding == 1 }
	
	validates_presence_of :late_payments_amount_due ,:message => "Late Payments Amount Due Can't be blank" #,:if => Proc.new { |property| property.check_late_payments_amount_due == 1 }
	
	validates_presence_of :current_interest_rate ,:message => "Current interest rate Can't be blank" #,:if => Proc.new { |property| property.check_current_interest_rate == 1 }
	
	validates_presence_of :first_payment_date ,:message => "First payment date Can't be blank" # ,:if => Proc.new { |property| property.check_first_payment_date == 1 }
	
	validates_presence_of :last_payment_date ,:message => "Last payment date Can't be blank" # ,:if => Proc.new { |property| property.check_last_payment_date == 1 }
	
	validates_presence_of :maturity_date ,:message => "Maturity Date Can't be blank" #,:if => Proc.new { |property| property.check_maturity_date == 1 }
	
	validates_presence_of :comments ,:message => "Comments Can't be blank" #,:if => Proc.new { |property| property.check_comments == 1 }


	def uniqueness_note_id_user
		pro = Property.find(:first ,:from => "properties, portfolios",:conditions => ["portfolios.user_id = ? and portfolios.id = properties.portfolio_id and properties.note_id = ?",self.portfolio.user_id,self.note_id])
		if !self.check_note_id.nil? and  self.check_note_id == 1
			val = pro.nil?	 ?	false  :  true	
			return val
		else
			return false
    end			

	end	
		 
	def save_permalink
	  companyname= (self.user.nil? or self.user.company_name.nil?) ?  "_" :  self.user.company_name.gsub(/[^a-z0-9]+/i, '-')
	  assetname= (self.property_collateral_detail.nil?) ? "_" : self.property_collateral_detail.property_name.gsub(/[^a-z0-9]+/i, '-')
	  prop_id=self.nil? ? "_" : self.id
	  self.permalink="/listing/#{companyname}/#{assetname}/#{prop_id}"
		self.save
   end

end

