class PropertyBorrowerDetail < ActiveRecord::Base
	belongs_to :property

	attr_accessor  :check_company_name,:check_contact_person,:check_city,:check_state,:check_zip,:check_phone_no,:check_email_address,:check_email_address

	validates_presence_of :company_name ,:message => "Company Name Can't be blank" #,:if => Proc.new { |property_borrower_detail| property_borrower_detail.check_company_name == 1 }
	
	validates_presence_of :contact_person ,:message => "Contact Person Can't be blank" # ,:if => Proc.new { |property_borrower_detail| property_borrower_detail.check_contact_person == 1 }
	
	validates_presence_of :city ,:message => "City Can't be blank" #,:if => Proc.new { |property_borrower_detail| property_borrower_detail.check_city == 1 }
	
	validates_presence_of :state ,:message => "State Can't be blank" #,:if => Proc.new { |property_borrower_detail| property_borrower_detail.check_state == 1 }
	
	validates_presence_of :zip ,:message => "Zip Can't be blank" #,:if => Proc.new { |property_borrower_detail| property_borrower_detail.check_zip == 1 }
	
	validates_presence_of :phone_no ,:message => "Phone No Can't be blank" #,:if => Proc.new { |property_borrower_detail| property_borrower_detail.check_phone_no == 1 }
	
	validates_presence_of :email_address ,:message => "Email Address Can't be blank" #,:if => Proc.new { |property_borrower_detail| property_borrower_detail.check_email_address == 1 }
	
	validates_presence_of :address ,:message => "Address Can't be blank" #,:if => Proc.new { |property_borrower_detail| property_borrower_detail.check_email_address == 1 }
	
end
