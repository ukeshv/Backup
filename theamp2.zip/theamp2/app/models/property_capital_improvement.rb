class PropertyCapitalImprovement < ActiveRecord::Base
  attr_accessor :tool_tip
  belongs_to :property_suite
  belongs_to :real_estate_property
  has_many :property_financial_periods , :as => :source
end
