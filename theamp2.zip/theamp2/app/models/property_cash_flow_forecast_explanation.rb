class PropertyCashFlowForecastExplanation < ActiveRecord::Base
  
end
