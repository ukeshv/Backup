class PropertyCollateralDetail < ActiveRecord::Base
  belongs_to :property
  belongs_to :property_type
		
  attr_accessor  :check_property_size,:check_gross_land_area,:check_gross_rentable_area,:check_no_of_units,:check_year_built,:check_property_name,:check_city,:check_state,:check_zip,:check_property_description,:check_address,:check_purchase_price
	
#	after_create :save_property_permalink
#	after_update :save_property_permalink
		
	validates_presence_of :property_size ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_property_size == 1 }
	
	validates_presence_of :gross_land_area ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_gross_land_area == 1 }
	
	validates_presence_of :gross_rentable_area ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_gross_rentable_area == 1 }
	
	validates_presence_of :no_of_units ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_no_of_units == 1 }
	
	validates_presence_of :year_built ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_year_built == 1 }
	
	validates_presence_of :property_name ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_property_name == 1 }
	
	validates_presence_of :city ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_city == 1 }
	
	validates_presence_of :state ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_state == 1 }
	
	validates_presence_of :zip ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_zip == 1 }
	
	validates_presence_of :property_description ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_property_description == 1 }
	
	validates_presence_of :address ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_address == 1 }
	
	validates_presence_of :purchase_price		 ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_purchase_price == 1 }
	
	def find_property_info		
    @property_info = Array.new
    @property_info << ['Property type', self.property_type.name] if !self.property_type.nil?
    @property_info << ['Building Name',self.property_name]
    #~ @property_info << ['Occupancy',property.occupancy]
    #~ @property_info << ['year last renovated',property.year_last_renovated]
    @property_info << ['Address',self.address]
    @property_info << ['City',self.city]
    @property_info << ['State',self.state]
    #~ @property_info << ['State', State.find_by_id(property.state_id).name]
    @property_info << ['Zip',self.zip.to_i]
    @property_info << ['Purchase price',self.purchase_price.to_i]
    @property_info << ['Size',self.property_size.to_i]
    @property_info << ['Gross land area',self.gross_land_area.to_i]
    @property_info << ['Gross rentable area',self.gross_rentable_area.to_i]
    @property_info << ['No of units',self.no_of_units.to_i]
    @property_info << ['Year built',self.year_built]
    #~ @property_info << ['Gross building area',property.gross_building_area_in_sf]
    #~ @property_info << ['Url',property.url]
  end
	
	def save_property_permalink
		self.property.save_permalink
	end
		
end
