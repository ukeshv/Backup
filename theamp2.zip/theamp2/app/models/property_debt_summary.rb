class PropertyDebtSummary < ActiveRecord::Base
	belongs_to :real_estate_property
end
