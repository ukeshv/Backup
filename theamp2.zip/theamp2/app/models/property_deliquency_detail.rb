class PropertyDeliquencyDetail < ActiveRecord::Base
		belongs_to :property
		
		attr_accessor :check_delinquency_history_30days,:check_delinquency_history_60days,:check_delinquency_history_90days,:check_bankruptcy_status,:check_foreclosure_status,:check_bankruptcy_start_date,:check_foreclosure_filling_date	


	validates_presence_of :delinquency_history_30days ,:message => "Can't be blank" #,:if => Proc.new { |property_deliquency_detail| property_deliquency_detail.check_delinquency_history_30days == 1 }
	
	validates_presence_of :delinquency_history_60days ,:message => "Can't be blank" #,:if => Proc.new { |property_deliquency_detail| property_deliquency_detail.check_delinquency_history_60days == 1 }
	
	validates_presence_of :delinquency_history_90days ,:message => "Can't be blank" #,:if => Proc.new { |property_deliquency_detail| property_deliquency_detail.check_delinquency_history_90days == 1 }
	
	validates_presence_of :bankruptcy_status ,:message => "Can't be blank" #,:if => Proc.new { |property_deliquency_detail| property_deliquency_detail.check_bankruptcy_status == 1 }
	
	validates_presence_of :foreclosure_status ,:message => "Can't be blank" #,:if => Proc.new { |property_deliquency_detail| property_deliquency_detail.check_foreclosure_status == 1 }
	
	validates_presence_of :bankruptcy_start_date ,:message => "Can't be blank" #,:if => Proc.new { |property_deliquency_detail| property_deliquency_detail.check_bankruptcy_start_date == 1 }
	
	validates_presence_of :foreclosure_filling_date ,:message => "Can't be blank" #,:if => Proc.new { |property_deliquency_detail| property_deliquency_detail.check_foreclosure_filling_date == 1 }
end
