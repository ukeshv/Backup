class PropertyDetailsNoteInformation < ActiveRecord::Base
		belongs_to :property
		
		attr_accessor :check_amortization_term,:check_amortization_term,:check_rate_reset_frequency,:check_amortization,:check_baloon_flag,:check_minimum_rate,:check_maximum_rate,:check_interest_rate_index,:check_interest_rate_margin		
		
	validates_presence_of :amortization_term ,:message => "Can't be blank" #,:if => Proc.new { |property_details_note_info| property_details_note_info.check_amortization_term == 1 }
	
	validates_presence_of :interest_only_period ,:message => "Can't be blank" #,:if => Proc.new { |property_details_note_info| property_details_note_info.check_amortization_term == 1 }
	
	validates_presence_of :rate_reset_frequency ,:message => "Can't be blank" #,:if => Proc.new { |property_details_note_info| property_details_note_info.check_rate_reset_frequency == 1 }
	
	validates_presence_of :amortization ,:message => "Can't be blank" #,:if => Proc.new { |property_details_note_info| property_details_note_info.check_amortization == 1 }
	
	validates_presence_of :baloon_flag ,:message => "Can't be blank" #,:if => Proc.new { |property_details_note_info| property_details_note_info.check_baloon_flag == 1 }
	
	validates_presence_of :minimum_rate ,:message => "Can't be blank" #,:if => Proc.new { |property_details_note_info| property_details_note_info.check_minimum_rate == 1 }
	
	validates_presence_of :maximum_rate ,:message => "Can't be blank" #,:if => Proc.new { |property_details_note_info| property_details_note_info.check_maximum_rate == 1 }
	
	validates_presence_of :interest_rate_index ,:message => "Can't be blank" #,:if => Proc.new { |property_details_note_info| property_details_note_info.check_interest_rate_index == 1 }
	
	validates_presence_of :interest_rate_margin ,:message => "Can't be blank" #,:if => Proc.new { |property_details_note_info| property_details_note_info.check_interest_rate_margin == 1 }

end
