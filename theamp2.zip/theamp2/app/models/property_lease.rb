class PropertyLease < ActiveRecord::Base
  belongs_to :property_suite
end
