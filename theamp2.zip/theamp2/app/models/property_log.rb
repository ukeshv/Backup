class PropertyLog < ActiveRecord::Base
end
