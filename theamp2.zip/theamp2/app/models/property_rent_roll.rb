class PropertyRentRoll < ActiveRecord::Base
end
