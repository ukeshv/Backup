class PropertyStateLog < ActiveRecord::Base
	
	#Relationships
	belongs_to :state
	belongs_to :user
	belongs_to :property
end
