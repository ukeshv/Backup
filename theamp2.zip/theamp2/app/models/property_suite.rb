class PropertySuite < ActiveRecord::Base
  has_many :property_leases
  has_one :property_capital_improvement, :dependent=>:destroy
  has_one :property_aged_receivable
  belongs_to :real_estate_property
end
