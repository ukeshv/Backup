class PropertyType < ActiveRecord::Base
	has_many :property_collateral_details, :dependent=>:destroy
  has_many :rent_roll, :dependent=>:destroy
	has_many :actuals, :dependent=>:destroy
	has_many :budgets, :dependent=>:destroy
	has_many :real_estate_properties

  def self.find_all_with_collect
    PropertyType.all.collect {|x| [x.name,x.id]}
  end
end
