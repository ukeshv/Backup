class PropertyVarianceAndExplanation < ActiveRecord::Base
end
