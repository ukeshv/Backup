class RealEstateLoanDetail < ActiveRecord::Base
	attr_accessor  :check_original_note_amount,:check_current_outstanding,:check_late_payments_amount_due,:check_current_interest_rate,:check_first_payment_date,:check_last_payment_date,:check_maturity_date,:check_comments,:property_coll_details,:property_borrow_details	
	belongs_to :real_estate_property
  validates_presence_of :original_note_amount ,:message => "Original Note Amount Can't be blank"  #,:if => Proc.new { |property| property.check_original_note_amount == 1 }
	validates_presence_of :current_outstanding ,:message => "Current Outstanding Can't be blank" #,:if => Proc.new { |property| property.check_current_outstanding == 1 }
	validates_presence_of :current_interest_rate ,:message => "Current interest rate Can't be blank" #,:if => Proc.new { |property| property.check_current_interest_rate == 1 }
	validates_presence_of :first_payment_date ,:message => "First payment date Can't be blank" # ,:if => Proc.new { |property| property.check_first_payment_date == 1 }
	validates_presence_of :last_payment_date ,:message => "Last payment date Can't be blank" # ,:if => Proc.new { |property| property.check_last_payment_date == 1 }
	validates_presence_of :maturity_date ,:message => "Maturity Date Can't be blank" #,:if => Proc.new { |property| property.check_maturity_date == 1 }
	validates_presence_of :comments ,:message => "Comments Can't be blank" #,:if => Proc.new { |property| property.check_comments == 1 }
	validates_presence_of :loan_type ,:message => "loan type Can't be blank" #,:if => Proc.new { |property| property.check_comments == 1 }
end
