class RealEstateProperty < ActiveRecord::Base
	attr_accessor  :check_property_name
	attr_accessor :add_property_validity
  attr_accessor :check_prop_name_validation
	attr_accessor  :check_property_size,:check_gross_land_area,:check_gross_rentable_area,:check_no_of_units,:check_year_built,:check_property_name,:check_city,:check_state,:check_zip,:check_property_description,:check_address,:check_purchase_price,:check_validation, :is_field_exists,:no_validation_needed

	#Relationships
	has_many :real_estate_loan_details,:dependent=>:destroy
	has_many :actuals, :as=>:resource, :dependent=>:destroy
	has_many :budgets, :as=>:resource, :dependent=>:destroy
	has_many :advanced_due_dates, :as=>:resource, :dependent=>:destroy
	has_many :cash_flow_details, :as=>:resource, :dependent=>:destroy
  has_many :folders, :dependent=>:destroy
  has_many :documents, :dependent=>:destroy
  has_many :document_names, :dependent=>:destroy
	has_many :buyers, :as=>:resource, :dependent=>:destroy
	has_many :proof_documents, :as=>:resource, :dependent=>:destroy
	has_many :real_estate_property_state_logs, :dependent=>:destroy
	has_many :rent_rolls, :as=>:resource, :dependent=>:destroy
	has_many :property_occupancy_summaries
	has_many :property_suites
	has_many :property_debt_summaries
  has_many :property_capital_improvements
	has_one :flyer, :as=> :attachable
	belongs_to :state
	belongs_to :user
	belongs_to :portfolio
	belongs_to :property_type
	has_one :portfolio_image, :as=> :attachable
  belongs_to :property_management_system 
	belongs_to :address
	has_many :tasks, :dependent=>:destroy
  has_one :variance_threshold

	before_save :modify_permalink
	after_create :create_permalink
	
	#Validations	
	validates_presence_of :property_name ,:message => "Can't be blank"  ,:if => Proc.new { |property| (property.check_prop_name_validation != false && property.no_validation_needed != 'true') }
  validates_uniqueness_of :property_name, :scope => [:user_id, :portfolio_id] ,:message => "Note Id already exists" ,:if => Proc.new { |property| (property.check_prop_name_validation != false && property.no_validation_needed != 'true') }
	validates_presence_of :occupancy ,:message => "Can't be blank" ,:if => Proc.new { |property| (property.check_validation == "no" && property.add_property_validity != "no"  && property.no_validation_needed != 'true' ) }  #,:if => Proc.new { |property| (property.check_note_id == 1) }
 validates_presence_of :annualized_noi ,:message => "Can't be blank" ,:if => Proc.new { |property| (property.check_validation == "no" && property.add_property_validity != "no"  && property.no_validation_needed != 'true') }

	validates_presence_of :property_size ,:message => "Can't be blank" ,:if => Proc.new { |property| (property.add_property_validity != "no"  && property.no_validation_needed != 'true') }#,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_property_size == 1 }
	validates_presence_of :gross_land_area ,:message => "Can't be blank",:if => Proc.new { |property| (property.check_validation != "no" && property.add_property_validity != "no"  && property.no_validation_needed != 'true') } #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_gross_land_area == 1 }
	validates_presence_of :gross_rentable_area ,:message => "Can't be blank" ,:if => Proc.new { |property| (property.check_validation != "no" && property.add_property_validity != "no"  && property.no_validation_needed != 'true') } #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_gross_rentable_area == 1 }
	validates_presence_of :no_of_units ,:message => "Can't be blank"  ,:if => Proc.new { |property| (property.check_validation != "no" && property.add_property_validity != "no"  && property.no_validation_needed != 'true' ) }#,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_no_of_units == 1 }
	validates_presence_of :year_built ,:message => "Can't be blank"  ,:if => Proc.new { |property| (property.check_validation != "no" && property.add_property_validity != "no"  && property.no_validation_needed != 'true') }#,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_year_built == 1 }
	#validates_presence_of :property_name ,:message => "Can't be blank" #,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_property_name == 1 }
	#validates_format_of :city, :with => /^[^\d]+$/ , :message => 'Please provide valid City name' ,:if => Proc.new { |property| (property.add_property_validity != "no") }
  #validates_format_of :province, :with => /^[^\d]+$/ , :message => 'Please provide valid state name',:if => Proc.new { |property| (property.add_property_validity != "no") }
#	validates_presence_of :zip ,:message => "Can't be blank" ,:if => Proc.new { |property| (property.check_validation != "no" && property.add_property_validity != "no" ) }#,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_zip == 1 }
	validates_presence_of :property_description ,:message => "Can't be blank" ,:if => Proc.new { |property| (property.check_validation != "no" && property.add_property_validity != "no"  && property.no_validation_needed != 'true') }#,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_property_description == 1 }
	#validates_presence_of :address ,:message => "Can't be blank" ,:if => Proc.new { |property| (property.check_validation != "no" && property.add_property_validity != "no" ) }#,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_address == 1 }
	validates_presence_of :purchase_price		 ,:message => "Can't be blank" ,:if => Proc.new { |property| (property.check_validation != "no" && property.add_property_validity != "no"  && property.no_validation_needed != 'true') }#,:if => Proc.new { |property_collateral_detail| property_collateral_detail.check_purchase_price == 1 }

def create_permalink
		save_permalink
		self.save
	end
	
	def modify_permalink
	  save_permalink
	end
	
	def save_permalink
		companyname= (self.user.nil? or self.user.company_name.nil?) ?  "-" :  self.user.company_name.gsub(/[^a-z0-9]+/i, '-')
	  assetname= (self.property_name.nil?) ? "-" : self.property_name.gsub(/[^a-z0-9]+/i, '-')
	  prop_id=self.nil? ? "-" : self.id
	  self.permalink="/listing/#{companyname}/#{assetname}/#{prop_id}"
	end
	
	#added to get real estate property's address from address table
	def city
		(self.is_field_exists) ? self[:city] : (self.address.nil? ? '' : self.address.city.nil? ? '' : self.address.city)
	end
	
	def province
		(self.is_field_exists) ? self[:province] : (self.address.nil?  ? '' : self.address.province.nil? ? '' : self.address.province)
	end
	
	def zip
		(self.is_field_exists) ? self[:zip] : (self.address.nil? ? '' : self.address.zip.nil? ? '' : self.address.zip)
	end
	
	def desc
		self.address.nil? ? '' : self.address.txt.nil? ? '' : self.address.txt
	end
	
	def self.note_find(id)
		RealEstateProperty.find_by_id(id)
	end
	
end

