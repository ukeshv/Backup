class RealEstatePropertyStateLog < ActiveRecord::Base
	#Relationships
	belongs_to :real_estate_property
	belongs_to :user
	belongs_to :state
end
