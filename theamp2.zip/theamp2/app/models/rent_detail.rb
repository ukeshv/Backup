class RentDetail < ActiveRecord::Base
	belongs_to :rent_roll
end
