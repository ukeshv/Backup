class RentRoll < ActiveRecord::Base
  belongs_to :user
 # belongs_to :property
  belongs_to :property_type
  has_many :rent_details, :dependent => :destroy
 	belongs_to :resource, :polymorphic => true 	
end
