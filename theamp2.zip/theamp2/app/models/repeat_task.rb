class RepeatTask < ActiveRecord::Base
	has_many :tasks
	
	def self.create_repeat_task		
		for repeat_task in RepeatTask.find(:all)
			target_date = Date.today
			task_created_co = repeat_task.task_created_count.nil? ? 0 : repeat_task.task_created_count
			date= repeat_task.repeat_start_date >> task_created_co + 1
			date=date-repeat_task.task_scheduling_days.days								
			if  repeat_task.repeat_count > repeat_task.task_created_count and target_date == date 						 				 
        repeat_task_for_document_task(repeat_task,date,target_date,task_created_co) if repeat_task.document_id?
        repeat_task_for_folder_task(repeat_task,date,target_date,task_created_co) if !repeat_task.folder_id?
			end	
		end	
		
		due_reminder = Setting.find_by_name('due_date_reminder')				
		due_date_reminder = (!due_reminder.nil? and due_reminder.value.to_i > 0) ?  due_reminder.value.to_i : 1		
		for task in Task.all									
			if task.due_by? and Date.today+due_date_reminder.days == task.due_by				
				UserMailer.deliver_due_date_reminder(task,task.user)				
				for coll in task.task_collaborators          
					UserMailer.deliver_due_date_reminder(task,coll.user)					
				end								
			end	
		end    
	end	
	
	def self.repeat_task_for_folder_task(repeat_task,date,target_date,task_created_co)		
    folder = Folder.find_by_id(repeat_task.folder_id)
    base_task = Task.find(:first,:conditions => ["repeat_task_id = ?",repeat_task.id],:order => "id asc")
    base_date = repeat_task.repeat_start_date
    task_type_name =  base_task.task_name+" #{date.strftime('%b %Y')}"
    store_folder_id = finding_folder_id_repeat_task(base_task,date)
    new_task = Task.new
    new_task.attributes = base_task.attributes
    new_task.folder_id = store_folder_id.id
    new_task.task_name = task_type_name
    new_task.due_by = base_task.due_by >> task_created_co + 1 if !base_task.due_by.nil?
    tc = []
    for task_col in base_task.task_collaborators
      t = TaskCollaborator.new
      t.user_id = task_col.user_id
      t.sharer_id = task_col.sharer_id
      t.is_completed = false
      tc << t
    end
    new_task.task_collaborators = tc
    new_task.save
    if new_task
      Event.create_new_event("create_task",new_task.user.id,nil,[new_task],"Asset Manager",new_task.folder.name,new_task.task_type.task_name)
      if new_task.task_collaborators and !new_task.task_collaborators.empty?
        task 	= []
        for task_collaborator in new_task.task_collaborators
          Event.create_new_event("Collaborators",new_task.user.id,nil,[task_collaborator.user],"Asset Manager",task_collaborator.user.email," added to the task "+new_task.folder.name+"-"+new_task.task_type.task_name)
        end
      end
    end
    UserMailer.deliver_cron_job_task_creation_notification(new_task)
    if new_task.task_collaborators and !new_task.task_collaborators.empty?
      for task_collaborator in new_task.task_collaborators
        is_already_set_pass = !task_collaborator.user.password_code? ? true : false
        UserMailer.deliver_task_assigned_user_notification_mail(new_task,task_collaborator.sharer,task_collaborator.user,is_already_set_pass,[],[],[])
      end
    end
    repeat_task.update_attributes(:task_created_count => repeat_task.task_created_count+1)
	end	
	
	def self.repeat_task_for_document_task(repeat_task,date,target_date,task_created_co)		
    document = Document.find_by_id(repeat_task.document_id)
    base_task = Task.find(:first,:conditions => ["repeat_task_id = ?",repeat_task.id],:order => "id desc")
    base_date = repeat_task.repeat_start_date
				
    f=  document.filename.split(".")
    ext = f.pop
    f = f.join(".")
				
    filename = f+"_#{date.strftime('%b_%Y')}."+ext
    path ="#{RAILS_ROOT}/public"+document.public_filename.to_s
    d= Document.new
    ActionController::UploadedTempfile.open(filename) do |temp|
      temp.write(File.open(path).read)
      temp.original_path = path
      temp.content_type = document.content_type
      d.attributes = document.attributes
      d.uploaded_data = temp
      sh = []
      store_folder_id = finding_folder_id_repeat_task(document,date)
      for task_col in base_task.task_collaborators
        h = {:user_id => base_task.user_id, :sharer_id => task_col.user_id,:folder_id => store_folder_id.id,:real_estate_property_id => document.real_estate_property_id}
        sh << SharedDocument.new(h)
      end
      d.shared_documents = sh
      d.filename = filename
      d.folder_id = store_folder_id.id
      d.save
      Event.create_new_event("create",d.user.id,nil,[d],"Asset Manager",d.filename,nil)
    end
    new_task = Task.new
    new_task.attributes = base_task.attributes
    new_task.document_id = d.id
    new_task.due_by = base_task.due_by >> task_created_co + 1 if !base_task.due_by.nil?
    tc = []
    for task_col in base_task.task_collaborators
      t = TaskCollaborator.new
      t.user_id = task_col.user_id
      t.sharer_id = task_col.sharer_id
      t.is_completed = false
      tc << t
    end
    new_task.task_collaborators = tc
    new_task.save
				
    if new_task
      Event.create_new_event("create_task",new_task.user.id,nil,[new_task],"Asset Manager",new_task.document.filename,new_task.task_type.task_name)
      if new_task.task_collaborators and !new_task.task_collaborators.empty?
        task 	= []
        for task_collaborator in new_task.task_collaborators
          Event.create_new_event("Collaborators",new_task.user.id,nil,[task_collaborator.user],"Asset Manager",task_collaborator.user.email," added to the task "+new_task.document.filename+"-"+new_task.task_type.task_name)
        end
      end
    end
    UserMailer.deliver_cron_job_task_creation_notification(new_task)
    if new_task.task_collaborators and !new_task.task_collaborators.empty?
      for task_collaborator in new_task.task_collaborators
        is_already_set_pass = !task_collaborator.user.password_code? ? true : false
        UserMailer.deliver_task_assigned_user_notification_mail(new_task,task_collaborator.sharer,task_collaborator.user,is_already_set_pass,[],[],[])
      end
    end
    repeat_task.update_attributes(:task_created_count => repeat_task.task_created_count+1)
	end	
	
	def self.finding_folder_id_repeat_task(document,date)
		a =[]		
		for mo in 1..12
			a << Date::MONTHNAMES[mo].slice(0,3)
		end			
		parent_folder = Folder.find_by_id(document.folder_id)				
		gr_parent_folder = Folder.find_by_id(parent_folder.parent_id) if !parent_folder.nil?		
		gr_gr_parent_folder = Folder.find_by_id(gr_parent_folder.parent_id) if !gr_parent_folder.nil?				
		if !gr_gr_parent_folder.nil? and ["Accounts","Leases","Loan Docs"].include?(gr_gr_parent_folder.name)		
      if !gr_parent_folder.nil? and !parent_folder.nil? and gr_parent_folder.name.to_i == date.year  and a.include?(parent_folder.name)
        next_folder = Folder.find_by_parent_id_and_name(gr_parent_folder.id,Date::MONTHNAMES[date.month].slice(0,3))
        next_folder = Folder.create(:name =>"#{Date::MONTHNAMES[date.month].slice(0,3)}",:portfolio_id => parent_folder.portfolio_id,:real_estate_property_id => parent_folder.real_estate_property_id,:user_id => parent_folder.user_id,:parent_id =>gr_parent_folder.id ) if next_folder.nil?
        return next_folder.nil? ? parent_folder : next_folder
      elsif !gr_parent_folder.nil? and !parent_folder.nil? and gr_parent_folder.name.to_i != date.year  and a.include?(parent_folder.name)
        find_year = Folder.find_by_parent_id_and_name(gr_gr_parent_folder.id,date.year)
        if find_year.nil?
          find_year = Folder.create(:name =>"#{date.year}",:portfolio_id => parent_folder.portfolio_id,:real_estate_property_id => parent_folder.real_estate_property_id,:user_id => parent_folder.user_id,:parent_id =>gr_gr_parent_folder.id )
          find_month = Folder.create(:name =>"#{Date::MONTHNAMES[date.month].slice(0,3)}",:portfolio_id => parent_folder.portfolio_id,:real_estate_property_id => parent_folder.real_estate_property_id,:user_id => parent_folder.user_id,:parent_id =>find_year.id )
        else
          find_month = Folder.find_by_parent_id_and_name(find_year.id,"#{Date::MONTHNAMES[date.month].slice(0,3)}")
          find_month = Folder.create(:name =>"#{Date::MONTHNAMES[date.month].slice(0,3)}",:portfolio_id => parent_folder.portfolio_id,:real_estate_property_id => parent_folder.real_estate_property_id,:user_id => parent_folder.user_id,:parent_id =>find_year.id )  if find_month.nil?
        end
        return find_month.nil? ? parent_folder : find_month
      else
        return parent_folder
      end
		else
      return parent_folder
		end	
	end	
	
end
