class Role < ActiveRecord::Base
	#Relationship
  has_and_belongs_to_many :users
end