class ShareDocumentName < ActiveRecord::Base
	belongs_to :user
  belongs_to :document_name
	belongs_to :folder
end
