class State < ActiveRecord::Base
	
	#Relationships
	has_many :properties, :dependent=>:destroy
	has_many :property_state_logs, :dependent=>:destroy
	has_many :real_estate_properties, :dependent=>:destroy
	has_many :real_estate_property_state_logs, :dependent=>:destroy
end
