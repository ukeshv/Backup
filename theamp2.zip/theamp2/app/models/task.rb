class Task < ActiveRecord::Base
	belongs_to :task_type
	has_many :task_files, :dependent=>:destroy
	has_many :collaborators,:through => :task_collaborators	,:source => :user
	has_many :task_collaborators , :dependent=>:destroy
	has_many :task_documents , :dependent=>:destroy
  belongs_to :document
  belongs_to :user
	belongs_to :folder
	belongs_to :repeat_task
	has_many :event_resources, :as=>:resource,:dependent=>:destroy
	belongs_to :real_estate_property
  acts_as_commentable

  def self.find_task(task_id)
    self.find_by_id(task_id)
  end
  def self.find_task_by_document(task_id)
    self.find_by_document_id(task_id)
  end
  # This method is used to destroy all types of tasks
  def self.task_destroy(task_type,task_id)
    task = task_type == 'doc' ?  Task.find_task_by_document(task_id) : Task.find_task(task_id)
		if task
      Task.mail_collaborators_task_deletion(task)
      task.destroy
    end
  end
	
	def self.mail_collaborators_task_deletion(task)
		task_collaborators = task.collaborators
		doc_name = task.document.nil? ? task.folder.name : task.document.filename
		owner_name = task.user.name? ?  task.user.name.capitalize : task.user.email
		mail_folder_path = task.document.nil? ? Folder.find_mail_path_folder(task.folder) : Folder.find_mail_path_folder(task.document.folder)
		file_or_folder = task.document.nil? ? 'Folder' : 'File'
		task_type = (task.task_type.task_name == 'Explain Variances') ? 'Variance Task' : 'Task'
		task_collaborators.each do |task_collaborator|
			task_collab_name = task_collaborator.name? ? task_collaborator.name.capitalize : task_collaborator.email
			TaskMailer.deliver_deleted_task_details(task_collaborator.email, task_collab_name, owner_name, task.user.email, doc_name, task_type, mail_folder_path, file_or_folder, task.instruction)
		end
	end

  def self.mail_task_completion(task_type,task_id)
    task = task_type == 'doc' ?  Task.find_task_by_document(task_id) : Task.find_task(task_id)
    task_collaborators = task.collaborators
		doc_name = task.document.nil? ? task.folder.name : task.document.filename
		owner_name = task.user.name? ? task.user.name : task.user.email
		mail_folder_path = task.document.nil? ? Folder.find_mail_path_folder(task.folder) : Folder.find_mail_path_folder(task.document.folder)
		file_or_folder = task.document.nil? ? 'Folder' : 'File'
		task_type = (task.task_type.task_name == 'Explain Variances') ? 'Variance Task' : 'Task'
		task_collaborators.each do |task_collaborator|
			task_collab_name = task_collaborator.name? ? task_collaborator.name : task_collaborator.email
			TaskMailer.deliver_task_completed(task_collaborator.email, task_collab_name, owner_name, task.user.email, doc_name, task_type, mail_folder_path, file_or_folder, task.instruction)
		end
  end
  def self.task_completion_mail_requested(task_type,task_id,user_id)
    task = task_type == 'doc' ?  Task.find_task_by_document(task_id) : Task.find_task(task_id)
    doc_name = task.document.nil? ? task.folder.name : task.document.filename
    task_collaborator = User.find_by_id(user_id)
    task_coll_name_or_mail = task_collaborator.name? ? task_collaborator.name.capitalize : task_collaborator.email
		task_owner_name_or_mail = task.user.name? ? task.user.name.capitalize : task.user.email
		mail_folder_path = task.document.nil? ? Folder.find_mail_path_folder(task.folder) : Folder.find_mail_path_folder(task.document.folder)
		file_or_folder = task.document.nil? ? 'Folder' : 'File'
		task_type = (task.task_type.task_name == 'Explain Variances') ? 'Variance Task' : 'Task'
    TaskMailer.deliver_task_complete_requested(task.user.email,task_owner_name_or_mail,task_coll_name_or_mail, doc_name, task_type, mail_folder_path, file_or_folder, task.instruction)
  end
  def self.destroy_repeat_task(task_id,perform)
    repeat_task = Task.find_by_id(task_id).repeat_task
    current_task = Task.find_by_id(task_id)
    tasks = Task.find_by_repeat_task_id(repeat_task.id)
    tasks.update_attributes(:repeat_task_id=>"false")
    current_task.destroy unless perform == "task_complete"
    repeat_task.destroy
  end
  def self.destroy_current_repeat_tasks(task_id)
    repeat_task_id = Task.find_by_id(task_id).repeat_task
    task_count = Task.find(:all, :conditions => ["repeat_task_id = ?",repeat_task_id.id]).count
    unless task_count > 1
      repeat_task = RepeatTask.find_by_id(repeat_task_id.id)
      target_date = Date.today.advance(:months=>repeat_task.repeat_count)
			task_created_co = repeat_task.task_created_count.nil? ? 0 : repeat_task.task_created_count
			date= repeat_task.repeat_start_date >> task_created_co + 1
			date=date-repeat_task.task_scheduling_days.days
      if  repeat_task.repeat_count > repeat_task.task_created_count
        RepeatTask.repeat_task_for_document_task(repeat_task,date,target_date,task_created_co) if repeat_task.document_id?
        RepeatTask.repeat_task_for_folder_task(repeat_task,date,target_date,task_created_co) if repeat_task.folder_id?
			end
      Task.find_by_id(task_id).destroy
    end
  end

end
