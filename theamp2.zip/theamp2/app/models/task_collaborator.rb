class TaskCollaborator < ActiveRecord::Base
	belongs_to :task
	belongs_to :user	
	belongs_to :sharer,:class_name => "User"

  def self.display_task_revoke_option(userid,current_id,task)
		f = task.document.nil? ? task.folder : task.document.folder
		if(task)
    tc = TaskCollaborator.find_by_user_id_and_task_id(userid,task.id)
    value =  (tc.nil? ?  true : false)
		else
			value = true
		end	
		if tc
      value = ((tc && tc.task.user_id == current_id) || (tc && tc.sharer_id == current_id)) ? true : false
		end
		if task && task.user_id == current_id 
			value = true 
		end	
		tcollab=TaskCollaborator.find_by_user_id_and_sharer_id(userid,current_id) 
		if tcollab && !self.is_task_parent_folder(f,userid)
			value = true
		else
       value =  false
	end
    return value
  end
	
	  def self.is_task_parent_folder(f,user)
  	task_parent_owner = Folder.find_by_id(f.id)
		if task_parent_owner.user_id  == user
	    return true
    else
      s = SharedFolder.find_by_folder_id(f.id,:conditions=>["user_id = ?",user],:select=>'id')
      if !s.nil?
        return true
      else
        return false
      end
    end
  end
	
	
	

  def self.find_collaborator_id(task_id)
    TaskCollaborator.find_by_task_id(task_id)
  end
  def self.finding_collaborators(task_id)
   if task_col_id = TaskCollaborator.find_by_task_id(task_id)
    task_col_id.is_completion_requested?
   else
     return false
   end
  end

  def self.finding_coll_by_user_id_and_task_id(user_id,task_id)
    TaskCollaborator.find_by_user_id_and_task_id_and_is_completion_requested(user_id,task_id,1)
  end

end
