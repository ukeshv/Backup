class TaskDocument < ActiveRecord::Base
	belongs_to :task
	belongs_to :document
  def self.find_all_by_primary_document_ids_and_task_ids(params_id,task_id)
    find_all_by_primary_document_id_and_task_id(params_id,task_id)
  end
end
