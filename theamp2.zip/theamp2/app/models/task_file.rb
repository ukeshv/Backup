class TaskFile < ActiveRecord::Base
	has_attachment :storage => :file_system, :size => 1.kilobytes..60.megabytes, :content_type => ['application/vnd.ms-excel'], :path_prefix => 'public/task_file'		
	belongs_to :task
	has_many :event_resources, :as=>:resource,:dependent=>:destroy
  belongs_to :document

  def self.find_all_document_ids_and_task_ids(id,task_id)
    find_all_by_document_id_and_task_id(id,task_id)
  end
  def self.find_all_task_id(task_id)
    find_all_by_task_id(task_id)
  end
end
