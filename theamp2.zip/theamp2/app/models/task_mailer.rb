class TaskMailer < ActionMailer::Base
	def deleted_task_details(task_collaborator_email, task_collab_name, owner_name, task_user_email, doc_name, task_type, folder_path, file_or_folder, instruction)
    @recipients  = "#{task_collaborator_email}"
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
	  @subject    = "AMP: #{task_type} for '#{doc_name=='my_files'? 'My Files':doc_name}' has been deleted by #{owner_name}"
		@body[:first_line] = "#{task_type} has been deleted by #{owner_name}."
		unless instruction.nil? && instruction == "Enter the instruction here..."
			@body[:instruction] = instruction
		end
		@body[:file_or_folder] = file_or_folder
    @body[:doc_name] = "#{doc_name=='my_files'? 'My Files':doc_name}"
		@body[:folder_path] = "#{folder_path = (folder_path=='my_files')? 'My Files':folder_path}"
		@body[:task_collab_name] = "#{task_collab_name}"
	end

  def task_completed(task_collaborator_email, task_collab_name, owner_name, task_user_email, doc_name, task_type, folder_path, file_or_folder, instruction)
    @recipients  = "#{task_collaborator_email}"
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
	  @subject    = "AMP: #{task_type} for #{doc_name=='my_files'? 'My Files':doc_name} has been completed by #{owner_name}"
		@body[:first_line] = "<b> #{task_type} </b> has been completed by #{owner_name}."
		unless instruction.blank? && instruction == "Enter the instruction here..."
			@body[:instruction] = "#{instruction}"
		end
		@body[:second_line] = "#{file_or_folder}: #{doc_name=='my_files'? 'My Files' : doc_name}"
		@body[:folder_path] = "#{folder_path = (folder_path=='my_files')? 'My Files':folder_path}"
		@body[:task_collab_name] = "#{task_collab_name}"

  end
  
  def task_complete_requested(task_owner_email,task_owner_name_or_mail,task_coll_name_r_mail, doc_name, task_type, folder_path, file_or_folder, instruction)
    @recipients  = "#{task_owner_email}"
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
	  @subject    = "AMP: #{task_type} for #{doc_name = (doc_name=='my_files')? 'My Files':doc_name} complete has been requested by #{task_coll_name_r_mail}"
		@body[:first_line] = "#{task_type} complete has been requested by #{task_coll_name_r_mail}."
		unless instruction.nil? && instruction == "Enter the instruction here..."
			@body[:instruction] = instruction
		end
    @body[:file_r_folder] = file_or_folder
    @body[:doc_name] = "#{doc_name=='my_files'? 'My Files':doc_name}"
		@body[:folder_path] = folder_path == 'my_files' ? 'My Files&amp;Tasks' : folder_path
		@body[:task_owner_name_or_mail] = "#{task_owner_name_or_mail}"
  end
end