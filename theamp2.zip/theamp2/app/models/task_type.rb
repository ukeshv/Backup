class TaskType < ActiveRecord::Base
	has_many :tasks, :dependent=>:destroy
  def self.finding_task_name(i)
    TaskType.find(i.task.task_type_id).task_name
  end
  def self.find_all_task_types
    TaskType.all
  end
end
