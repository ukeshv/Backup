require 'digest/sha1'

class User < ActiveRecord::Base
  include Authentication
  include Authentication::ByPassword
  include Authentication::ByCookieToken
  include Authorization::AasmRoles
  
  #Attr accessor
  attr_accessor :is_shared_user
  attr_accessor :is_new_user
  attr_accessor :is_set_password, :is_asset_edit 
    
  #Relationship
  has_and_belongs_to_many :roles
  has_many :comments, :dependent=>:destroy
  has_many :folders, :dependent=>:destroy
  has_many :actuals, :dependent=>:destroy
  has_many :budgets, :dependent=>:destroy
  has_many :document_names, :dependent=>:destroy  

  has_many :documents, :dependent=>:destroy
  has_many :rent_roll, :dependent=>:destroy
  has_many :shared_documents,:dependent=>:destroy
  has_many :shared_folders,:dependent=>:destroy
  has_many :property_state_logs, :dependent=>:destroy
  has_many :buyers, :dependent=>:destroy
  has_many :proof_documents, :dependent=>:destroy
  has_one :user_profile_detail, :dependent=>:destroy

  has_many :income_and_cash_flow_details, :dependent=>:destroy

  has_many :real_estate_properties, :dependent=>:destroy
	has_many :portfolios , :dependent=>:destroy
	
	has_many :task_collaborators , :dependent=>:destroy
	has_one :portfolio_image, :as=> :attachable , :dependent=>:destroy, :conditions=> "filename != 'login_logo'"
	has_one :logo_image, :as=> :attachable, :dependent=>:destroy, :conditions=> "filename = 'login_logo'", :class_name=> 'PortfolioImage'
	has_many :variance_thresholds, :dependent=>:destroy

  #has_many :users, :dependent=>:destroy
  #Validations

  validates_presence_of :login,:if => Proc.new { |user| !user.is_shared_user },:message=>"User name can't be blank"
  validates_length_of :login,:if => Proc.new { |user| !user.is_shared_user  },:within => 3..40,:message=>"User name must be between 3 to 40 characters"
  validates_uniqueness_of :login,:if => Proc.new { |user| !user.is_shared_user },:message=>"User name already taken"
  validates_format_of :login,:if => Proc.new { |user| !user.is_shared_user },:with => Authentication.login_regex, :message => "only letters, numbers, dots ,hyphen & underscore is allowed"
  validates_presence_of :name,:if => Proc.new { |user| !user.is_shared_user || user.is_set_password },:message=>"Name can't be blank"
  validates_format_of :name,:if => Proc.new { |user| !user.is_shared_user || user.is_set_password } ,:with => /^[\w]([\w]*[\s]*[\w]*)*[\w]$/ , :message => "Name only contain alphabets,digits,space & underscore"
  validates_length_of :name,:if => Proc.new { |user| !user.is_shared_user || user.is_set_password },:within=> 3..100,:too_long=>"Name should not contain more than 100 characters", :too_short=>"Must have at least 3 characters"
  validates_format_of :phone_number, :if => Proc.new {|user| !user.is_shared_user }, :with => /^(\d{10}){1}?(\d)*$/, :message =>"Provide a valid Phone No", :allow_nil=>true, :allow_blank=>true
  validates_presence_of :email,:message=>"Email can't be blank"
  validates_length_of :email,    :within => 6..100 ,:message=>"email must be between 6 to 100 characters"
  validates_uniqueness_of :email,:message=>"This email Id already taken"
  validates_format_of :email,    :with => Authentication.email_regex, :message => Authentication.bad_email_message
  validates_length_of :designation,:if => Proc.new { |user| !user.is_shared_user && !user.is_new_user },:within => 0..40,:message=>"Designation should be in less than 40 characters", :allow_nil=>true, :allow_blank=>true
  validates_presence_of :company_name,:if => Proc.new { |user| !user.is_shared_user && !user.is_set_password },:message=>"Company name can't be blank"
  validates_presence_of     :password,:message=>"Please enter a password", :if => :password_required? 
  validates_presence_of     :password_confirmation, :message=>"Please enter a confirmation password", :if => :password_required?
  validates_confirmation_of :password,   :message=>"Password do not match", :if => :password_required?
  validates_length_of       :password, :within => 6..40,:too_short=>"Must have at least 6 characters", :if => :password_required?
  validates_length_of       :password_confirmation, :within => 6..40,:too_short=>"Must have at least 6 characters", :if => :password_required?
  
  validates_presence_of :address,:if => Proc.new { |user| user.is_new_user },:message=>"Address can't be blank"
  validates_presence_of :phone_number,:if => Proc.new { |user| user.is_new_user },:message=>"Phone number can't be blank"
  
  
  # HACK HACK HACK -- how to do attr_accessible from here?
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  attr_accessible :login, :email, :name, :password, :password_confirmation,:company_name,:designation,:comment,:department,:phone_number,:address,:approval_status,:client_type

  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  #
  # uff.  this is really an authorization, not authentication routine.  
  # We really need a Dispatch Chain here or something.
  # This will also let us return a human error message.
  #
  def self.authenticate(email, password)
    return nil if email.blank? || password.blank?
    user = find :first, :conditions => (['(email = ? or login = ?)',email.downcase,email.downcase]) # need to get the salt
    user && user.authenticated?(password) ? user : nil
  end

  def login=(value)
    write_attribute :login, (value ? value.downcase : nil)
  end

  def email=(value)
    write_attribute :email, (value ? value.downcase : nil)
  end
  
  # has_role? simply needs to return true or false whether a user has a role or not.  
  # It may be a good idea to have "admin" roles return true always
  def has_role?(role_in_question)
    @_list ||= self.roles.collect(&:name)
    return true if @_list.include?("admin")
    (@_list.include?(role_in_question.to_s) )
  end
  
  def generate_password
    chars = ("a".."z").to_a + ("A".."Z").to_a + ("0".."9").to_a
    p = ""
    chars_small =  ("a".."z").to_a
    chars_caps = ("A".."Z").to_a
    chars_numbers =   ("0".."9").to_a
    small  = chars_small[rand(chars_small.size-1)]
    caps = chars_caps[rand(chars_caps.size-1)]
    number = chars_numbers[rand(chars_numbers.size-1)]
    p << small << caps << number
    1.upto(7) { |i| p << chars[rand(chars.size-1)] }
    return p
  end

  def self.encrypt_password(pwd)
    Base64.encode64(pwd).chop
	end   

  def self.email_authenticate(email, password)
    return nil if email.blank? || password.blank?
    u = find :first, :conditions => {:email => email} # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

 def user_role(id)
      user=User.find(id)
      userrole=user.roles[0].name
      return userrole
  end
  
  def self.random_passwordcode(size = 30)
    chars = (('a'..'z').to_a + ('0'..'9').to_a) - %w(i o 0 1 l 0)
    (1..size).collect{|a| chars[rand(chars.size)] }.join
  end

  def user_name
    unless (self.name.nil? || self.name.empty?)
      self.name #.capitalize
    else
      self.email.split('@').first.capitalize
    end
  end
 
 
 def after_save
  if self.login != "admin"
      portfolio = Portfolio.find_or_create_by_user_id_and_name_and_portfolio_type_id(self.id,'portfolio_created_by_system',2)
      property = RealEstateProperty.find_or_create_by_user_id_and_property_name_and_portfolio_id(self.id,'property_created_by_system',portfolio.id)
      property.no_validation_needed = 'true'
      property.save
      Folder.find_or_create_by_portfolio_id_and_real_estate_property_id_and_user_id_and_name(portfolio.id,property.id,self.id,'my_files')      
  end    
end

  # Overwrite password_required
  def password_required?
    unless is_asset_edit
     ((!password.blank? and !password.nil?) || (!password_confirmation.blank? and !password_confirmation.nil?)) || true
    else 
      false
    end
  end

  def self.find_collaborators(i)
    User.find(:first, :conditions => ["id IN (?)",i.task_collaborators.collect{|u| u.user_id}], :select => "email").email
  end
  
  protected
  def make_activation_code
    #self.deleted_at = nil
    #self.activation_code = self.class.make_token
  end
end
