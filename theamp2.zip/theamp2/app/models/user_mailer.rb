class UserMailer < ActionMailer::Base
  def signup_notification(user)
    setup_email(user)
    @subject    += 'Please activate your new account'
    @body[:url]  = "http://YOURSITE/activate/#{user.activation_code}"
  end

  def set_your_password(user,user_type)
    setup_email(user)
    @name=user.name
    @subject = "Login details for"+" "+"'#{@subject} Asset Management Platform'"
    @body[:url] = user.password_code? ? "#{APP_CONFIG[:site_url]}/#{user_type}/set_password/#{user.id}/#{user.password_code}" : "#{APP_CONFIG[:site_url]}/login"
    @body[:user] = user
  end
  
  def activation(user)
    setup_email(user)
    @subject    += 'Your account has been activated!'
    @body[:url]  = "http://YOURSITE/"
  end
  
  def share_notification(user,shared_obj,share_type,current_user,su_already)
    @recipients  = "#{user.email}"
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    shared_obj_name = share_type == 'file' ? shared_obj.document.filename : shared_obj.folder.name
    sharer_name_email = name_or_email(current_user)
    @subject = "AMP: #{sharer_name_email} #{current_user.company_name? ? 'from '+current_user.company_name : ''} has shared a #{share_type} '#{shared_obj_name}' with you."
    url = user.password_code? ? "#{APP_CONFIG[:site_url]}/shared_users/set_password/#{user.id}/#{user.password_code}" :  "#{APP_CONFIG[:site_url]}/collaboration_hub?open_folder=#{shared_obj.folder.id}&pid=#{shared_obj.folder.portfolio_id}"
    if user.password_code?
      @body[:first_line] = "You are invited to <a href='#{url}'><font color='#2a8ae4'>Join Amp</font></a> to view the file <a href='#{url}'><font color='#2a8ae4'>'#{shared_obj_name}'</font></a> shared by #{sharer_name_email}."
    else
      @body[:first_line] = "#{sharer_name_email} #{current_user.company_name? ? 'from '+current_user.company_name : ''} has shared a #{share_type} '#{shared_obj_name}' with you."
    end
    @body[:second_line] = "Click on the link <a href='#{url}'><font color='#2a8ae4'>#{shared_obj_name}</font></a> to update or download #{share_type}."
    @body[:comment]= shared_obj.comments
    @body[:coll_name_or_mail] = name_or_email(user)
    @body[:shared_obj_name] = shared_obj_name
    @body[:shared_obj_type] = share_type
    @sent_on     = Time.now
  end  
  
  def share_notification_for_prop(shared_user,shared_obj,sh,current_user,alrdy)
    @recipients  = "#{shared_user.email}"
    @from = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    @sharer_name_email = name_or_email(current_user)
    @property_name = shared_obj.folder.name
    @comment=shared_obj.comments if shared_obj
    @subject = "#{current_user.nil? ? 'Your friend/colleague' : @sharer_name_email} #{current_user.company_name.blank? ? '' : 'from ' + current_user.company_name} has shared a Property '#{@property_name}' with you"
    @body[:url] =  shared_user.password_code? ? "#{APP_CONFIG[:site_url]}/shared_users/set_password/#{shared_user.id}/#{shared_user.password_code}" : "#{APP_CONFIG[:site_url]}/collaboration_hub?open_folder=#{shared_obj.folder.id}&pid=#{shared_obj.folder.portfolio_id}"
    @body[:user] = shared_user
    @sent_on     = Time.now
  end  
   
  def account_detail_changed(user,username,email)
    setup_email(user)
    @subject    += 'Your account detail is changed!'
    @user=user
    @username=username
    @email=email
    @body[:url] = user.password_code? ? "#{APP_CONFIG[:site_url]}/users/set_password/#{user.id}/#{user.password_code}" : "#{APP_CONFIG[:site_url]}/login"
  end

  def invite_buyers(user,email,property_id,name)
    @recipients  = "#{email}"
    @from        = "#{user.email}"
    @subject     = "AMP: review this note for buying "
    @user=user
    @buyer_name=name
    @body[:url1] = "#{APP_CONFIG[:site_url]}/signup"
    @sent_on     = Time.now
  end
  
  def invite_buyers_property(user,email,property_id,name,note)
    @recipients  = "#{email}"
    @from        = "#{user.email}"
    @subject     = "AMP: review this property for buying "
    @user=user
    @note=note
    @buyer_name=name
    @body[:url1] = "#{APP_CONFIG[:site_url]}/signup"
    @sent_on     = Time.now
  end
    
  def send_request_due_diligence(user,seller,note)
    @recipients  = "#{seller.email}"
    @from        = "#{user.email}"
    @subject     = "AMP: Request Due Diligence of #{note.note_id}"
    @user=user
    @seller=seller
    @note  = note
    @body[:url] = "#{APP_CONFIG[:site_url]}/dispositions?note_id=#{note.id}&view_req=1"
    @sent_on     = Time.now
  end
        
  def send_request_due_diligence_property(user,seller,note)
    @recipients  = "#{seller.email}"
    @from        = "#{user.email}"
    @subject     = "AMP: Request Due Diligence of #{note.property_name}"
    @user=user
    @seller=seller
    @note  = note
    @body[:url] = "#{APP_CONFIG[:site_url]}/property_dispositions?note_id=#{note.id}&view_req=1"
    @sent_on     = Time.now
  end
  
  def contact_us(contact)
    @recipients  = "#{APP_CONFIG[:feedback_email]}"
    @from        = "#{contact.email}"
    @subject= "Message from Your Website"
    @name=contact.name
    @email=contact.email
    @phone_number=contact.phone_number
    @company_name=contact.company_name
    @comment=contact.comment
    @sent_on     = Time.now
  end

  def comments_notification(comment, detail, user, sender, fl_name)
    @recipients  = "#{user.email}"
    @from        = "#{sender.email}"
    @subject     = "AMP: comments "
    @body[:comment] = comment
    @body[:detail]  = detail
    @body[:user_name_or_email] = name_or_email(user)
    @body[:commented_user_name_or_email] = name_or_email(sender)
    @body[:fl_name]     = fl_name
    @body[:url] = "#{APP_CONFIG[:site_url]}/collaboration_hub"
    @sent_on     = Time.now.strftime("%b %e, %Y at %I:%M %p")
  end

  def explanation_comments_notification(comment_lines, user, sender, fl_name)
    @recipients  = "#{user}"
    @from        = "#{sender}"
    @subject     = "AMP: Explanation Comments"
    @sent_on     = Time.now.strftime("%a %b %d %T %Y")
    @comment_lines   = comment_lines
    @fl_name     = fl_name
  end
  	    
  def send_mail_to_admin(user,comment,software)
    @recipients  = "#{APP_CONFIG[:admin_email]}"
    @from        = "#{user}"
    @subject     = "AMP: Tool details"
    @user = user
    @comment= comment
    @software = software
    @sent_on     = Time.now
  end
	
  def task_assigned_user_notification_mail(task,user,collaborator, alrdy, addedSecFiles, removedSecFiles, comment_lines = [])
    @recipients  = "#{collaborator.email}"
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    @addedSecFiles = addedSecFiles
    @removedSecFiles = removedSecFiles
    @comment_lines = comment_lines
    @sharer_name_email = user.name.blank? ? user.email : user.name.capitalize
    file_name = task.document.nil? ? task.folder.name == 'my_files' && task.folder.parent_id == 0 ? "" : task.folder.name : task.document.filename
    ex = task.document.nil? ? (task.folder.is_master == false && task.folder.parent_id == 0 ? "Property" : "Folder") : "File"
    if task.document.nil?
      @subject = "AMP: #{@sharer_name_email} has assigned task to you"      
      s1 = (file_name == "" ? "" : " for the #{ex} '#{file_name}'")
      @subject += s1 #Append this text only if tasks are created inside any folders other than my_files
      @body[:first_line] ="<b>#{@sharer_name_email}</b> has assigned task to you"
      fl = (file_name == "" ? "" : " for the #{ex}")
      @body[:first_line] += fl #Append this text only if tasks are created inside any folders other than my_files
      @file_name_variance = "#{task.task_type.task_name}"
      @bread_crumb_path = get_object_path(task.folder)
      @task_typ = "Task : "
    else
      @subject = task.task_type.task_name == "General" ? "AMP: #{@sharer_name_email} has assigned task to you for the #{ex} '#{file_name}'" : "AMP: #{!user.name? ? user.email : user.name} wants you to #{task.task_type.task_name.split(" ").first} the #{task.document.nil? ? 'Folder' : 'File'} '#{file_name}'"    
      @body[:first_line] = task.task_type.task_name == "General" ? "<b>#{@sharer_name_email}</b> has assigned task to you for the #{ex}" : "<b>#{!user.name? ? user.email : user.name}</b> wants you to #{task.task_type.task_name.split(" ").first} the #{ex}"
      @file_name_variance = "#{task.document.filename}"
      @bread_crumb_path = get_object_path(task.document.folder)
      @task_typ = "File: "
    end
    @body[:task] =  task
    @body[:filename] = file_name
		@body[:collaborator] = collaborator
		@body[:url] =  collaborator.password_code? ? "#{APP_CONFIG[:site_url]}/shared_users/set_password/#{collaborator.id}/#{collaborator.password_code}" : "#{APP_CONFIG[:site_url]}#{ link_definer(collaborator, task) }"
    @sent_on     = Time.now
	end
  
  
  def task_assigned_user_notification_mail_variance_task(task,user,collaborator, alrdy, addedSecFiles, removedSecFiles, comment_lines = [])
    @recipients  = "#{collaborator.email}"
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    @addedSecFiles = addedSecFiles
    @removedSecFiles = removedSecFiles
    @file_name_variance = "#{task.document.filename}"
    @bread_crumb_path = get_object_path(task.document.folder)
    @subject = "AMP: #{!user.name? ? user.email : user.name} has assigned task to you for the File '#{@file_name_variance}'"
    @sharer_name_email = user.name.blank? ? user.email : user.name.capitalize
    @body[:first_line] = "<b>#{@sharer_name_email}</b> requests you to Explain Variances for '#{@file_name_variance}'"
    @comment_lines = comment_lines
    @task_typ = "File: "
    @body[:task] =  task
    @body[:collaborator] = collaborator
    @body[:url] =  collaborator.password_code? ? "#{APP_CONFIG[:site_url]}/shared_users/set_password/#{collaborator.id}/#{collaborator.password_code}" : "#{APP_CONFIG[:site_url]}#{link_definer(collaborator, task)}"
    @sent_on     = Time.now
    @body[:alrdy] = alrdy
  end

  def task_user_removed_mail(task,user,collaborator)
    @recipients  = "#{collaborator.email}"
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    file_name = task.document.nil? ? task.folder.name == 'my_files' && task.folder.parent_id == 0 ? "My Files" : task.folder.name : task.document.filename
    @subject = "AMP: #{!user.name? ? user.email : user.name} has removed you from the task for the #{task.document.nil? ? 'folder' : 'file'} '#{file_name}'"
    @body[:first_line] = "<b>#{!user.name? ? user.email : user.name}</b> has removed you from the task for the #{task.document.nil? ? 'folder' : 'file'}"
    @body[:task] =  task
    @body[:task_source] = file_name 
    @body[:collaborator] = collaborator 	
    object = task.document.nil? ? task.folder : task.document	
    @body[:path] = get_object_path(object)
    @body[:url] =  "#{APP_CONFIG[:site_url]}"+"/collaboration_hub"
    @sent_on     = Time.now				
  end
  
  
  def folder_file_user_revoke_notification(obj,user,shared_user)
    @recipients  = "#{shared_user.email}"
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    file_or_fol_name = obj.class.name == "Document" ? obj.filename : obj.name
    file_or_fol_obj = obj.class.name == "Document" ? 'file' : obj.class.name == "Folder" && obj.parent_id == 0 ? 'property' : 'folder'
    @subject     = "AMP: #{!user.name? ? user.email : user.name} has removed the collaboration access for you from the #{file_or_fol_obj} '#{file_or_fol_name}'"
    @body[:first_line] = "<b> #{!user.name? ? user.email : user.name}</b> has removed the collaboration access for you from the #{file_or_fol_obj} '#{file_or_fol_name}'"
 		@body[:collaborator] = shared_user
 		@body[:url] =  "#{APP_CONFIG[:site_url]}/collaboration_hub"
    @sharer_name_email = user.name? ? user.name : user.email
    @sent_on     = Time.now				
  end  
   
	
	def cron_job_task_creation_notification(task)		
    @recipients  = "#{task.user.email}"		
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    unless task.document_id?
      folder_name = task.folder.name == 'my_files' && task.folder.parent_id == 0 ? "My files" : task.folder.name
      @subject    = "AMP: New Task on folder '#{folder_name}' for Month:'#{task.created_at.strftime("%b-%Y")}' created as Per your 'Repeat Task' instructions."
      @body[:first_line] = "New Task on folder '#{folder_name}' for Month:'#{task.created_at.strftime("%b-%Y")}' created as Per your 'Repeat Task' instructions."
    else
      @subject    = "AMP: New Task on file '#{task.document.filename}' for Month:'#{task.document.created_at.strftime("%b-%Y")}' created as Per your 'Repeat Task' instructions."
      @body[:first_line] = "New Task on file '#{task.document.filename}' for Month:'#{task.document.created_at.strftime("%b-%Y")}' created as Per your 'Repeat Task' instructions."
    end 			
		@body[:name_or_email] = task.user.name? ? task.user.name.capitalize : task.user.email
    @sent_on     = Time.now		
	end

  def due_date_reminder(task,user)
    @recipients  = "#{user.email}"				
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    if task.document_id?
      @subject    = "AMP: Task on File:#{task.document.filename} due on #{task.due_by.strftime("%dth %b, %Y")}"
      @body[:first_line] = "'#{task.task_type.task_name}' task on file '#{task.document.filename}' is due on #{task.due_by.strftime("%dth %b, %Y")}."
    else
      @subject    = "AMP: Task on Folder:#{task.folder.name} due on #{task.due_by.strftime("%dth %b, %Y")}"
      @body[:first_line] = "'#{task.task_type.task_name}' task on folder '#{task.folder.name}' is due on #{task.due_by.strftime("%dth %b, %Y")}."
    end 		
		@body[:name_or_email] = user.name? ? user.name.capitalize : user.email
    @sent_on     = Time.now					
	end	
	
	def task_update_mail(task,user,msg,current_user,addedSecFiles,removedSecFiles, comment_lines=[],taskChanges=nil)
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    @recipients  = "#{user.email}"
    @addedSecFiles,@removedSecFiles = addedSecFiles,removedSecFiles
    @comment_lines = comment_lines
    taskChanges = taskChanges.nil? ? {} : taskChanges
    @taskChanges = taskChanges
    if !taskChanges.blank? && !taskChanges["task_type_id"].blank?
      @task_type_change = []
      taskChanges["task_type_id"].each { |task_type_id| @task_type_change << TaskType.find_by_id(task_type_id).task_name }
    end
    if !task.document_id?
      @file_name_variance = "#{task.task_type.task_name}"
      @bread_crumb_path = get_object_path(task.folder)
      @task_typ = "Task : "
    else
      @file_name_variance = "#{task.document.filename}"
      @bread_crumb_path = get_object_path(task.document.folder)
      @task_typ = "File: "
    end
    ex = !task.document_id? ? (task.folder.is_master == false && task.folder.parent_id == 0 && task.folder.name!= "my_files" ? "Task on Property" : "Task on folder '#{task.folder.name == 'my_files' && task.folder.parent_id == 0 ? "My Files" : task.folder.name}'") : "Task on file '#{task.document.filename}'"
    ex1 = !task.document_id? ? (task.folder.is_master == false && task.folder.parent_id == 0 && task.folder.name!= "my_files" ? "Property '#{task.folder.name}'" : "folder '#{task.folder.name == 'my_files' && task.folder.parent_id == 0 ? "My Files" : task.folder.name}'") : "file '#{task.document.filename}'"
    @updater_name_or_email = current_user.name.blank? ? current_user.email : current_user.name.capitalize
    @subject    = task.task_type_id == 5 ? "AMP: Variance Task for the property #{@bread_crumb_path.split(' > ').second} of #{@bread_crumb_path.split(' > ').first} has been updated by #{@updater_name_or_email}" : "AMP: #{ex} has been updated by #{@updater_name_or_email}"
    @body[:first_line] = "<b>#{@updater_name_or_email}</b> has updated the task for the #{ex1} on #{Time.now.strftime("%e %b, %Y, %I.%M %p")}"
    @var_task = task.task_type_id == 5 ? true : false
    @body[:msg] = msg
		@body[:task] =  task
		@body[:user] = user
    @body[:url] =  user.password_code? ? "#{APP_CONFIG[:site_url]}/shared_users/set_password/#{user.id}/#{user.password_code}" : "#{APP_CONFIG[:site_url]}#{ link_definer(user, task) }"
    @sent_on     = Time.now			
	end	
  
  def file_or_folder_update_mail(obj,user,msg,current_user)
    name = obj.class.name == "Folder" ? obj.name : obj.filename
    @recipients  = "#{user.email}"		
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
	  @subject    = "AMP: '#{name}' has been updated by #{current_user.email}"
    @body[:first_line] = "'#{name}' has been updated by #{current_user.email}."
    @body[:msg] = msg
		@body[:collaborator] = user
    @sent_on     = Time.now			
	end	
  
  def send_collab_folder_updates(action_done, current_user, shared_user,file_name, folder_name,type,object)
    @recipients  = "#{shared_user.email}"
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    sharer_name_or_email = current_user.name? ? current_user.name.capitalize : current_user.email
	  @subject    = "AMP: '#{file_name}' has been #{action_done} by #{sharer_name_or_email}"
		@body[:sharer_name_or_email] = sharer_name_or_email
		@body[:shared_user_name_or_email] = shared_user.name.blank? ? shared_user.email : shared_user.name.capitalize
    @body[:action_done] = action_done
    @body[:filename] = file_name
    @body[:foldername] = folder_name
    @body[:time_update] = Time.now.strftime("%I:%M %p on %b %d, %Y")
    time_update = Time.now.strftime("%I:%M %p on %b %d, %Y")
    if type == 'folder'
       @body[:first_line] = "#{action_done} a folder '#{folder_name}' on #{time_update}."
    else 
      @body[:first_line] = "#{action_done} a file '#{file_name}' on #{time_update}."
    end
    @body[:url] =  "#{APP_CONFIG[:site_url]}/real_estate/#{object.task.real_estate_property.portfolio.id}/properties/#{object.task.real_estate_property.id}?task_id=#{object.task.id}" if object.class == TaskFile
    @body[:file_path] = get_object_path(object)
    @sent_on     = Time.now			
  end
  
  def modify_variance_threshold(shared_asset_manager,threshold)
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    @subject     = "AMP: The variance threshold value for '#{threshold.real_estate_property.property_name}' has been updated"
    @sent_on     = Time.now
    @recipients  = "#{shared_asset_manager.email}"
    @name = shared_asset_manager.name? ? shared_asset_manager.name : shared_asset_manager.email
    @body[:threshold] = threshold
    @body[:updater_name] = threshold.user.name? ? threshold.user.name : threshold.user.email
  end  

  def name_or_email(user)
    user.name? ? user.name.capitalize : user.email
  end

  def get_object_path(object)
    if object.class == TaskFile
      path = object.task.document.nil? ?  Folder.find_mail_path_folder(object.task.folder)+"'s task attachment" : Folder.find_mail_path_folder(object.task.document.folder )+" > #{object.task.document.filename}'s task attachment"
      "#{object.task.real_estate_property.portfolio.name} > "+path
    elsif object.class == Document
      td = TaskDocument.find_by_document_id(object.id)
      if td
        path = td.task.document.nil? ? Folder.find_mail_path_folder(td.task.folder)+"'s task attachment" : Folder.find_mail_path_folder(td.task.document.folder )+" > #{td.task.document.filename}'s task attachment"
        "#{td.task.real_estate_property.portfolio.name} > "+path
      else
        path  = Folder.find_mail_path_folder(object.folder)
        "#{object.folder.portfolio.name} > "+path
      end
    elsif object.class == Folder
      path = Folder.find_mail_path_folder(object)
      "#{object.portfolio.name} > "+path
    end
  end
  
  
    
  
  def summary_comments_notification(comment, detail, user, sender, fl_name,portfolio_id,property_id)
    @recipients  = "#{user.email}"
    @from        = "#{sender.email}"
    @subject     = "AMP: comments "
    @body[:comment] = comment
    @body[:detail]  = detail
    @body[:user_name_or_email] = name_or_email(user)
    @body[:commented_user_name_or_email] = name_or_email(sender)
    @body[:fl_name]     = fl_name
    @body[:url] = "#{APP_CONFIG[:site_url]}/collaboration_hub/index/#{portfolio_id}?open_portfolio=true"
    @body[:view_comment_url] = "#{APP_CONFIG[:site_url]}/real_estate/#{portfolio_id}/properties/#{property_id}"
    @sent_on     = Time.now.strftime("%b %e, %Y at %I:%M %p")
  end
  
  
  
  protected
  
  def setup_email(user)
    @recipients  = "#{user.email}"
    @from        = "AMP Alert <#{APP_CONFIG[:noreply_email]}>"
    @subject     = "AMP:  "
    @sent_on     = Time.now
    @body[:user] = user
  end

  def link_definer(usr,task)
    if usr.roles.collect{|x| x.name}.include?("Asset Manager")
      if !task.document_id?
        "/collaboration_hub?open_folder=#{task.folder.id}&pid=#{task.real_estate_property.portfolio.id}&my_task_id=#{task.id}"
      else
        "/collaboration_hub?open_folder=#{task.document.folder.id}&pid=#{task.real_estate_property.portfolio.id}&my_task_id=#{task.id}"
      end
    else
      shared_users_path(:task_id =>task.id)
    end
  end
end

