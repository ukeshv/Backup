class UserProfileDetail < ActiveRecord::Base
	attr_accessor :is_new_user
	belongs_to :user
	has_one :brochure ,:as => :attachable
	#validations
#	validates_presence_of :business_name,:if => Proc.new { |user| user.is_new_user },:message=>"Business name can't be blank"
	validates_presence_of :city,:if => Proc.new { |user| user.is_new_user },:message=>"City can't be blank"
	validates_presence_of :state,:if => Proc.new { |user| user.is_new_user },:message=>"State can't be blank"
	validates_presence_of :zipcode,:if => Proc.new { |user| user.is_new_user },:message=>"Zipcode can't be blank"
	validates_format_of :zipcode, :if => Proc.new {|user| user.is_new_user}, :with => /\b[0-9a-z]{1,6}\b/, :message =>"Provide a valid Zipcode",:allow_nil=>true, :allow_blank=>true
	validates_presence_of :interest,:if => Proc.new { |user| user.is_new_user },:message=>"Select your interest(s)"
	attr_accessible :business_name, :city, :state, :zipcode, :title, :website, :interest, :user_id
end
