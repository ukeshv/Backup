APP_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/settings.yml")[RAILS_ENV].symbolize_keys
MAP_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/table_mapping.yml")
REAL_MAP_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/real_estate_table_mapping.yml")
TEMPLATE_MAP_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/template_mapping.yml")