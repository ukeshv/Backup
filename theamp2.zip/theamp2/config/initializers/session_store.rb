# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_theamp2_session',
  :secret      => 'efc6917c4e2e71076edc6daae42c1c8f9bd003846841297b6544530eb13fec1ed2871d633f7effc89e9e1ff604cee260b7b1e200d7cf1861500366be80d9ef44'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
