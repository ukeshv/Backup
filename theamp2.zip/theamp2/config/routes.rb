ActionController::Routing::Routes.draw do |map|
  map.logout '/logout', :controller => 'sessions', :action => 'destroy'
  map.login '/login', :controller => 'sessions', :action => 'new'
  map.register '/register', :controller => 'users', :action => 'create'
  map.signup '/signup', :controller => 'users', :action => 'new'
  map.forgot_password '/forgot_password', :controller => 'passwords', :action => 'new'
  map.reset_message '/reset_message', :controller => 'passwords', :action => 'message'
  map.change_password '/change_password/:reset_code', :controller => 'passwords', :action => 'reset'
  map.modify_password '/modify_password', :controller => 'passwords', :action => 'change_password'
  map.update_password '/update_password', :controller => 'passwords', :action => 'update_password'
  #routes to welcome page after asset manager logs in
  map.welcome '/welcome', :controller => 'users', :action => 'welcome'
  map.listing '/listing/:company_name/:asset_name/:id', :controller => 'property_acquisitions', :action=>'view'
  
  map.resources :users,:collection => {:set_password=>:get}
  map.resources :passwords

  map.resource :session
  
  map.page_error "page_error", :controller => "home", :action => "page_error"
  
  #Shared User Routes
  map.share_login 'shares/login',:controller=>'shared_users',:action=>'new'
  map.share_logout 'shares/logout',:controller=>'shared_users',:action=>'destroy'

  # The priority is based upon order of creation: first created -> highest priority.

  # Sample of regular route:
  #   map.connect 'products/:id', :controller => 'catalog', :action => 'view'
  # Keep in mind you can assign values other than :controller and :action

  # Sample of named route:
  #   map.purchase 'products/:id/purchase', :controller => 'catalog', :action => 'purchase'
  # This route can be invoked with purchase_url(:id => product.id)

  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   map.resources :products

  # Sample resource route with options:
  #   map.resources :products, :member => { :short => :get, :toggle => :post }, :collection => { :sold => :get }

  # Sample resource route with sub-resources:
  #   map.resources :products, :has_many => [ :comments, :sales ], :has_one => :seller
  
  # Sample resource route with more complex sub-resources
  #   map.resources :products do |products|
  #     products.resources :comments
  #     products.resources :sales, :collection => { :recent => :get }
  #   end

  # Sample resource route within a namespace:
  #   map.namespace :admin do |admin|
  #     # Directs /admin/products/* to Admin::ProductsController (app/controllers/admin/products_controller.rb)
  #     admin.resources :products
  #   end

  #Admin routes here
  map.namespace(:admin) do |admin|
    admin.resources :admins
    admin.resources :asset_managers, :member=>{:approve=>:get,:disapprove=>:get, :approve_sendmail=>:get,:add_variance=>:get}
    admin.resources :portfolio_types
    admin.resources :master_folders,:collection=>{:new_folder_creation =>:get, :show_folder_content => :put,:master_folder_dragndrop =>:get, :download_master_file=>:get, :folder_download=>:get}
    admin.resources :settings
    admin.resources :property_management_systems
  end
  

  #map.upassword '/admin/asset_managers/set_password/:id',:controller=>'admin/asset_managers',:action=>'set_password'
  map.download '/portfolios/download_xls/:id',:controller=>'portfolios',:action=>'download_xls'
  map.download_latest '/portfolios/download_latest_xls/:id',:controller=>'portfolios',:action=>'download_latest_xls'

	map.resources :portfolios, :member =>{:show_overview=>:get,:advanced_date=>:get,:new_version=>:get,:store_new_version=>:post,:new_rent_roll_version=>:get,:store_new_rent_roll_version=>:post, :date_settings=>:get},:collection => {:edit_assets => :get,:new_asset_create => :get, :cash_flow=>:get,:add_note=>:get}
  map.edit_portfolio_note_picture '/portfolio_note/edit_picture', :controller=>'portfolios', :action=>'edit_portfolio_note_picture'
  map.update_portfolio_note_picture '/portfolio_note/update_picture', :controller=>'portfolios', :action=>'update_portfolio_note_picture'
  map.resources :acquisitions, :collection =>{:search =>:get,:confirmed_notes =>:get, :saved_notes=>:get, :search_saved_notes =>:get, :nda_agreement=>:get}, :member=>{:acq_performance_review=>:post}
  map.resources :real_estates, :member=> {:show_real_overview=>:get,:index=>:get,:add_note=>:get, :date_settings=>:get,:new_version=>:get,:store_new_version=>:post, :new_rent_roll_version=>:get, :store_new_rent_roll_version=>:post,:store_new_income_and_cash_flow_version=>:post}, :collection=>{:data_not_updated=>:get,:portfolio_overview_index => :get}
  map.edit_portfolio_real_picture '/portfolio_real/edit_picture', :controller=>'real_estates', :action=>'edit_portfolio_real_picture'
  map.update_portfolio_real_picture '/portfolio_real/update_picture', :controller=>'real_estates', :action=>'update_portfolio_real_picture'
  map.resources :events,:member=>{:folder_display =>:get}, :collection=>{ :view_events_folder => :get, :filter_events => :get }
  
  map.resources :dispositions
  
  map.welcome_confirmed_notes '/acquisitions/confirmed_notes/:id', :controller => 'acquisitions', :action => 'confirmed_notes'
  
	map.userpassword '/users/set_password/:id/:code',:controller=>'users',:action=>'set_password'
 	map.shared_userpassword '/shared_users/set_password/:id/:code',:controller=>'shared_users',:action=>'set_password'
  
  map.resources :property_acquisitions, :collection =>{:search =>:get,:confirmed_notes =>:get, :saved_notes=>:get, :search_saved_notes =>:get, :nda_agreement=>:get}, :member=>{:acq_performance_review=>:post}
  map.resources :property_dispositions, :member=>{:upload_flyer=>:post, :download_flyer => :get}, :collection => {:add_new_asset_sale => :post}
  map.resources :collaboration_hub,:member=>{:edit_user_image=>:get, :update_user_image=>:post}

  
  map.resources(:portfolio) do |portfolio|
    portfolio.resources :notes
  end
   map.edit_note_picture '/note/edit_picture' , :controller=>'notes', :action=>'edit_note_picture'
   map.update_note_picture '/note/update_picture' , :controller=>'notes', :action=>'update_note_picture'
   map.resources(:real_estate) do |real_estate|
    real_estate.resources :properties
    real_estate.resources :wres_properties
  end
  map.edit_real_picture '/real/edit_picture', :controller=>'properties', :action=>'edit_real_picture'
  map.update_real_picture '/real/update_picture', :controller=>'properties', :action=>'update_real_picture'
  
map.notes_rent_roll '/portfolio/:portfolio_id/notes/:id/filter/:status' ,:controller=>'notes',:action=>'show'
map.notes_rent_roll '/portfolio/:portfolio_id/notes/:id/rent_rolls' ,:controller=>'rent_rolls',:action=>'notes_rent_roll'
map.notes_performance_review '/portfolio/:portfolio_id/notes/:id/performance_review' ,:controller=>'performance_review',:action=>'for_notes'
map.properties_performance_review '/real_estate/:portfolio_id/properties/:id/performance_review' ,:controller=>'performance_review_property',:action=>'for_notes'
map.datebased_notes_performance_review '/portfolio/:portfolio_id/notes/:id/performance_review/start_date/:start/end_date/:end' ,:controller=>'performance_review',:action=>'for_notes'
map.notes_term '/portfolio/:portfolio_id/notes/:id/term_details' ,:controller=>'notes',:action=>'term_details'
map.notes_property_view '/portfolio/:portfolio_id/notes/:id/property_view' ,:controller=>'notes',:action=>'property_view'
map.move_to_dispositions '/portfolio/:portfolio_id/notes/:id/move_to_dispositions' ,:controller=>'notes',:action=>'move_to_dispositions'
map.confirm_to_dispositions '/portfolio/:portfolio_id/notes/:id/confirm_to_dispositions' ,:controller=>'notes',:action=>'confirm_to_dispositions'
map.date_based_rent_roll '/notes/:id/rent_rolls/:sdate/end_date/:edate',:controller=>'rent_rolls',:action=>'notes_rent_roll'
map.event_filtering '/events/filter_events/:shared_user_id' ,:controller=>'events',:action=>'filter_events'
map.show_note_datahub '/assets/notes_data_hub' ,:controller=>'assets',:action=>'show_asset_files'
map.add_buyer '/dispositions/add_buyer/:note_id',:controller=>'dispositions',:action=>'add_buyer', :method=>'post'
map.change_view_file '/dispositions/change_view_file/:note_id',:controller=>'dispositions',:action=>'change_view_file', :method=>'post'
#~ map.change_property_view_file '/property_dispositions/change_view_file/:note_id',:controller=>'property_dispositions',:action=>'change_view_file', :method=>'post'
map.reset_disposition_index '/dispositions/index/:note_id',:controller=>'dispositions',:action=>'index'
map.show_folder '/show_folder/:id',:controller=>'events',:action=>'folder_display'
#map.add_note '/add_note/:id',:controller=>"portfolios",:action=>"add_note"
#map.new_version_rentroll '/document/:id/new_version' ,:controller=>"rent_rolls", :action=>"new_version"
#map.store_new_version_rentroll '/document/:id/store_new_version' ,:controller=>"rent_rolls", :action=>"store_new_version"
map.show_note_datahub '/properties/notes_data_hub' ,:controller=>'properties',:action=>'show_asset_files'
map.property_view_property '/real_estate/:portfolio_id/properties/:id/property_view' ,:controller=>'properties',:action=>'property_view'
map.property_rent_roll '/real_estate/:portfolio_id/properties/:id/rent_rolls' ,:controller=>'rent_rolls',:action=>'notes_rent_roll'
map.property_move_to_dispositions '/real_estate/:portfolio_id/properties/:id/move_to_dispositions' ,:controller=>'properties',:action=>'move_to_dispositions'
map.capital_expenditure '/real_estate/:id/capital_expenditure/:month/:year', :controller =>'performance_review_property', :action=>'capital_expenditure'
#graph related routes

map.waterfall_chart_property_xml '/waterfall_chart_property/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml_property',:action=>'waterfall_chart_property',:method=>:get
map.initial_waterfall_chart_property_xml '/waterfall_chart_property/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml_property',:action=>'waterfall_chart_property',:method=>:get

map.occupancy_chart_property_xml '/occupancy_chart_property/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml_property',:action=>'occupancy_chart_property',:method=>:get
map.initial_occupancy_chart_property_xml '/occupancy_chart_property/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml_property',:action=>'occupancy_chart_property',:method=>:get

map.initial_new_occupancy_chart_property_xml '/new_occupancy_chart_property/:id/:graph_month.:format',:controller=>'xml_property',:action=>'new_occupancy_chart_property',:method=>:get

map.initial_lease_expiration_chart_property_xml '/lease_expiration_chart_property/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml_property',:action=>'lease_expiration_chart_property',:method=>:get
#map.lease_expiration_chart_property_xml '/lease_expiration_chart_property/:id/:bar1/:bar2/:bar3/:bar4/:bar5/:user_id_graph/:start_date/:end_date.:format',:controller=>'xml_property',:action=>'lease_expiration_chart_property',:method=>:get
map.lease_expiration_chart_property_xml '/lease_expiration_chart_property/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml_property',:action=>'lease_expiration_chart_property',:method=>:get

map.rent_distribution_chart_property_xml '/rent_distribution_chart_property/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml_property',:action=>'rent_distribution_chart_property',:method=>:get
map.initial_rent_distribution_chart_property_xml '/rent_distribution_chart_property/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml_property',:action=>'rent_distribution_chart_property',:method=>:get

map.waterfall_chart_xml '/waterfall_chart/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml',:action=>'waterfall_chart',:method=>:get
map.initial_waterfall_chart_xml '/waterfall_chart/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml',:action=>'waterfall_chart',:method=>:get

map.occupancy_chart_xml '/occupancy_chart/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml',:action=>'occupancy_chart',:method=>:get
map.initial_occupancy_chart_xml '/occupancy_chart/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml',:action=>'occupancy_chart',:method=>:get

map.initial_lease_expiration_chart_xml '/lease_expiration_chart/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml',:action=>'lease_expiration_chart',:method=>:get
map.lease_expiration_chart_xml '/lease_expiration_chart/:id/:bar1/:bar2/:bar3/:bar4/:bar5/:user_id_graph/:start_date/:end_date.:format',:controller=>'xml',:action=>'lease_expiration_chart',:method=>:get

map.rent_distribution_chart_xml '/rent_distribution_chart/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml',:action=>'rent_distribution_chart',:method=>:get
map.initial_rent_distribution_chart_xml '/rent_distribution_chart/:id/:start_date/:end_date/:user_id_graph.:format',:controller=>'xml',:action=>'rent_distribution_chart',:method=>:get
map.dwn_fl '/dwn_fl/:id', :controller=>'assets', :action=>'dwn_fl'

	map.resources :shared_users,:member=>{:show_asset_files=>:get},:collection=>{:view_comment=>:get}
	map.resources :assets,:collection=>{:view_folder =>:get,:view_filename =>:get,:upload_asset_files=>:get,:scribd_view=>:get,:view_scribd_image=>:get,:download_folders_docs=>:get},:member=>{:folder_download=>:get,:view_share =>:get,:view_file =>:get,:show_folder_files => :get,:unshare=>:get, :update_page_after_close=>:get}

  map.resources :properties,:collection=>{:view_folder =>:get,:view_filename =>:get,:upload_asset_files=>:get,:scribd_view=>:get,:view_scribd_image=>:get,:download_folders_docs=>:get,:new_task => :get,:task_add_files => :get,:task_add_files_using_tree => :get ,:add_collaborators => :get,:edit_task =>:get, :view_task=>:get,:add_collaborators_with_profile =>:get, :check_variance_task=>:get},:member=>{:folder_download=>:get,:view_share =>:get,:view_file =>:get,:show_folder_files => :get,:unshare=>:get,:update_page_after_close=>:get, :new_threshold=>:post, :enter_explanations_now=>:get, :save_explanations_now=>:get}
  
 map.resources :wres_properties, :collection=>{:summary=>:get, :financials=>:get,:leases=>:get, :rent_roll=>:get, :capital_expenditure=>:get, :cash_and_receivables=>:get}#, :as=>'properties'

  map.resources :tasks,:collection=>{:task_repeat=>:get}
  map.destroy_portfolio 'destroy_portfolio/:id', :controller=>'portfolios', :action=>'destroy_portfolio'
	
	map.real_estate_financial_review_page '/real_estate/:portfolio_id/properties/:id/financial' ,:controller=>'performance_review_property',:action=>'financial',:method=>:get
                                                                
  
  # You can have the root of your site routed with map.root -- just remember to delete public/index.html.
  # map.root :controller => "welcome"
  map.root :controller=>"users", :action=>"index"

  # See how all your routes lay out with "rake routes"

  # Install the default routes as the lowest priority.
  # Note: These default routes make all actions in every controller accessible via GET requests. You should
  # consider removing or commenting them out if you're using named routes and resources.
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
 # map.connect '/add_note',:controller=>'portfolios',:action=>'add_note'
  #map.connect ':controller/:action/:id/:start_date/:end_date.:format'
  map.simple_captcha '/simple_captcha/:action', :controller => 'simple_captcha'
  map.contactus '/contactus',:controller=>'home',:action=>'new'
  map.connect '/real_estates/:portfolio_id/properties/:id/loan_details/', :controller=>'properties', :action=>'loan_details'
  map.connect '/shared_users/:p_type/index' ,:controller=>'shared_users',:action=>'index'
  map.connect '/properties/add_new_property_dispositions/:portfolio_id',:controller=>"properties",:action=>"add_new_property_dispositions"
  map.connect '/occupancies/store_new_occupancy_leasing', :controller=>'occupancies', :action=>'store_new_occupancy_leasing'
  map.connect '/occupancies/show_new_occupancy_leasing', :controller=>'occupancies', :action=>'show_new_occupancy_leasing'
 #map.connect '/admin/asset_managers/:id/add_variance',:controller=>"/admin/asset_managers",:action=>"add_variance"
  map.connect '/occupancies/store_new_debt_summary', :controller=>'occupancies', :action=>'store_new_debt_summary'
  map.connect '/collaboration_hub/index/:portfolio_id?open_portfolio=true', :controller=>'collaboration_hub', :action=>'index'

 #map.resources :occupancies
 # routes for deleting comments and explanation
 map.delete_exps_and_comments "/properties/delete_exps_and_comments",:controller => "properties",:action => "delete_exps_and_comments"
end
