class CreateProperties < ActiveRecord::Migration
  def self.up
    create_table :properties do |t|
			t.integer :portfolio_id
			t.string :note_id
			t.decimal :original_note_amount,:current_outstanding,:late_payments_amount_due, :precision => 26, :scale => 2, :default => 0
			t.float :current_interest_rate, :default => 0
			t.date :first_payment_date,:last_payment_date,:maturity_date
			t.text :comments,:error_message    
			t.boolean :is_valid
      t.timestamps
    end
  end

  def self.down
    drop_table :properties
  end
end
