class CreatePropertyCollateralDetails < ActiveRecord::Migration
  def self.up
    create_table :property_collateral_details do |t|
			t.integer :property_id,:property_size,:gross_land_area,:gross_rentable_area,:no_of_units,:year_built,:property_type_id
			t.string :property_name,:city,:state,:zip
			t.text :property_description,:address
			t.decimal :purchase_price, :precision => 26, :scale => 2, :default => 0
      t.timestamps
    end
  end

  def self.down
    drop_table :property_collateral_details
  end
end
