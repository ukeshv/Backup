class CreatePropertyBorrowerDetails < ActiveRecord::Migration
  def self.up
    create_table :property_borrower_details do |t|
			t.integer :property_id
			t.string :company_name,:contact_person,:city,:state,:zip,:phone_no,:email_address,:address
      t.timestamps
    end
  end

  def self.down
    drop_table :property_borrower_details
  end
end