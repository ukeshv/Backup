class CreatePropertyDetailsNoteInformations < ActiveRecord::Migration
  def self.up
    create_table :property_details_note_informations do |t|
			t.integer :property_id,:amortization_term,:interest_only_period,:rate_reset_frequency
			t.string :amortization,:baloon_flag
			t.float :minimum_rate,:maximum_rate, :default => 0
			t.string :interest_rate_index,:interest_rate_margin
      t.timestamps
    end
  end

  def self.down
    drop_table :property_details_note_informations
  end
end
