class CreatePropertyDeliquencyDetails < ActiveRecord::Migration
  def self.up
    create_table :property_deliquency_details do |t|
			t.integer :property_id,:delinquency_history_30days,:delinquency_history_60days,:delinquency_history_90days
			t.string :bankruptcy_status,:foreclosure_status
			t.date :bankruptcy_start_date,:foreclosure_filling_date
      t.timestamps
    end
  end

  def self.down
    drop_table :property_deliquency_details
  end
end
