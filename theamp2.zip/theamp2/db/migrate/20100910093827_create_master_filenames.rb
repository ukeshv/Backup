class CreateMasterFilenames < ActiveRecord::Migration
  def self.up
    create_table :master_filenames do |t|
			t.string :name, :limit => 40
			t.integer :master_folder_id, :limit => 10
      t.integer :due_days, :limit => 10
      t.integer :portfolio_type_id, :limit => 10
      t.timestamps
    end
  end

  def self.down
    drop_table :master_filenames
  end
end
