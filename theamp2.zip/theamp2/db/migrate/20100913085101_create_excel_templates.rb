class CreateExcelTemplates < ActiveRecord::Migration
  def self.up
    create_table :excel_templates do |t|
			t.string :filename,:content_type,:thumbnail
			t.integer :height,:width,:size,:parent_id,:portfolio_id
      t.timestamps
    end
  end

  def self.down
    drop_table :excel_templates
  end
end
