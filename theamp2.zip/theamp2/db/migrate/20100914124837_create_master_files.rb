class CreateMasterFiles < ActiveRecord::Migration
  def self.up
    create_table :master_files do |t|
			t.string :filename,:content_type,:thumbnail
			t.integer :height,:width,:size,:master_folder_id,:due_days
      t.timestamps
    end
  end

  def self.down
    drop_table :master_files
  end
end
