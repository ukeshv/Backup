class CreateFolders < ActiveRecord::Migration
  def self.up
    create_table :folders do |t|
      t.string :name
      t.integer :parent_id,:default=>0
      t.integer :portfolio_id,:user_id, :property_id
      t.boolean :is_master,:default=>false
      t.boolean :is_deleted,:default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :folders
  end
end
