class CreateDocuments < ActiveRecord::Migration
  def self.up
    create_table :documents do |t|
			t.string :filename,:content_type,:thumbnail
			t.integer :height,:width,:size,:folder_id,:user_id, :property_id
      t.datetime :due_date
      t.boolean :is_master,:default=>false
      t.boolean :is_deleted,:default=>false
      t.integer :ipaper_id
      t.string :ipaper_access_key
      t.integer :state_flag
      t.timestamps
    end
  end

  def self.down
    drop_table :documents
  end
end