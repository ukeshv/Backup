class CreateRentRolls < ActiveRecord::Migration
  def self.up
    create_table :rent_rolls do |t|
      t.integer :user_id,:property_id,:property_type_id
      t.float :total_occupied,:total_available, :default=>0
      t.string :year
      t.date   :start_date,:end_date
      t.timestamps
    end
  end

  def self.down
    drop_table :rent_rolls
  end
end
