class CreateDocumentNames < ActiveRecord::Migration
  def self.up
    create_table :document_names do |t|
      t.string :name, :limit => 40
			t.integer :folder_id, :limit => 10
      t.datetime :due_date
			t.boolean :is_master,:default=>false
			t.integer :document_id, :limit => 10
			t.integer :property_id
      t.timestamps
    end
  end

  def self.down
    drop_table :document_names
  end
end
