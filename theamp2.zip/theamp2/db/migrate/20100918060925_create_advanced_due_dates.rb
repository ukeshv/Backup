class CreateAdvancedDueDates < ActiveRecord::Migration
  def self.up
    create_table :advanced_due_dates do |t|
      t.integer :document_id
      t.date :start_date
      t.date :end_date
      t.string :year , :limit=>4
      t.boolean :is_future
      t.timestamps
    end
  end

  def self.down
    drop_table :advanced_due_dates
  end
end
