class CreateRentDetails < ActiveRecord::Migration
  def self.up
    create_table :rent_details do |t|
      t.integer :rent_roll_id
      t.string :tenant_name,:suite
      t.float  :rented_area,:default=>0
      t.decimal :monthly_rent,:deposit_paid,:abatements_made,:improvement_expenses_spent,:commission_expenses_spent,:capital_improvements,:aged_receivables,:leasing_commisions,:precision => 20, :scale => 2,:default=>0
      t.date :lease_start_date,:lease_end_date,:last_payment_date
      t.timestamps
    end
  end

  def self.down
    drop_table :rent_details
  end
end
