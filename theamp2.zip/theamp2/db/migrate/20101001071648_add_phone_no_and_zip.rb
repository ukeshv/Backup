class AddPhoneNoAndZip < ActiveRecord::Migration
  def self.up
    change_column :property_borrower_details,:zip,:integer
    change_column :property_borrower_details,:phone_no,:integer
  end

  def self.down
    change_column :property_borrower_details,:zip,:integer
    change_column :property_borrower_details,:phone_no,:integer
  end
end
