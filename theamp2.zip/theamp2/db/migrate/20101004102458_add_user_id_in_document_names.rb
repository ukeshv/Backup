class AddUserIdInDocumentNames < ActiveRecord::Migration
  def self.up
       add_column :document_names,:user_id,:integer
  end

  def self.down
       remove_column :document_names,:user_id,:integer
  end
end
