class AddIsDeletedInDocumentNames < ActiveRecord::Migration
  def self.up
    add_column :document_names,:is_deleted,:boolean,:default=>false

  end

  def self.down
   remove_column :document_names,:is_deleted,:boolean
  end
end
