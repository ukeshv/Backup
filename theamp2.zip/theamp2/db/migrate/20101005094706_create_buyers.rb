class CreateBuyers < ActiveRecord::Migration
  def self.up
    create_table :buyers do |t|
      t.integer :user_id, :property_id
      t.string :company, :company_representative, :contact_email
      t.timestamps
    end
  end

  def self.down
    drop_table :buyers
  end
end
