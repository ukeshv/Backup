class CreatePropertyStateLogs < ActiveRecord::Migration
  def self.up
    create_table :property_state_logs do |t|
      t.integer :user_id, :action_done_by, :property_id, :state_id
      t.boolean :show_hide_flag, :default=>1, :null=>false #(1 -> show, 0 -> hide)
      t.text :comments
      t.timestamps
    end
  end

  def self.down
    drop_table :property_state_logs
  end
end
