class CreateProofDocuments < ActiveRecord::Migration
  def self.up
    create_table :proof_documents do |t|
			t.string :filename,:content_type,:thumbnail
			t.integer :user_id, :property_id, :height,:width,:size,:folder_id
      t.timestamps
    end
  end

  def self.down
    drop_table :proof_documents
  end
end
