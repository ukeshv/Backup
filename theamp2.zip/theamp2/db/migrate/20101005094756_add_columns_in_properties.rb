class AddColumnsInProperties < ActiveRecord::Migration
  def self.up
    add_column :properties, :state_id,:integer
    add_column :properties, :user_id,:integer
    add_column :properties, :sale_price,:decimal, :precision => 26, :scale => 2, :default => 0
    add_column :properties, :cap_rate,:decimal, :precision => 26, :scale => 2, :default => 0
    add_column :properties, :annualized_noi,:decimal, :precision => 26, :scale => 2, :default => 0
    add_column :properties, :is_granted,:boolean, :default=>0
    add_column :documents, :is_deselected, :boolean, :default=>0
    add_column :folders, :is_deselected, :boolean, :default=>0
  end

  def self.down
    remove_column :properties, :sale_price
    remove_column :properties, :cap_rate
    remove_column :properties, :annualized_noi
    remove_column :documents, :is_deselected
    remove_column :folders, :is_deselected
  end
end
