class CreateTypeAsAFieldInAdvancedDueDate < ActiveRecord::Migration
  def self.up
    add_column :advanced_due_dates, :interval, :string
  end

  def self.down
    remove_column :advanced_due_dates, :interval
  end
end
