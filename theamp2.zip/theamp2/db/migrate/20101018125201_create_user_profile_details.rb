class CreateUserProfileDetails < ActiveRecord::Migration
  def self.up
    create_table :user_profile_details do |t|
      t.string :title
      t.string :business_name
      t.string :website
      t.string :city
      t.string :state
      t.string :zipcode, :limit=>20
      t.text :interest 
      t.integer :user_id
      t.timestamps
    end
  end

  def self.down
    drop_table :user_profile_details
  end
end
