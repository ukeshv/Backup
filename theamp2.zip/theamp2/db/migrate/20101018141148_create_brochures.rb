class CreateBrochures < ActiveRecord::Migration
  def self.up
    create_table :brochures do |t|
      t.string :filename,:content_type,:thumbnail,:attachable_type
      t.integer :height,:width,:size,:parent_id,:attachable_id
      t.timestamps
    end
  end

  def self.down
    drop_table :brochures
  end
end
