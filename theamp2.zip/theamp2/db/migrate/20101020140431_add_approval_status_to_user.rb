class AddApprovalStatusToUser < ActiveRecord::Migration
  def self.up
    add_column :users, :approval_status, :boolean
  end

  def self.down
    remove_column :users, :approval_status
  end
end
