class MasterFolderNameChange < ActiveRecord::Migration
  def self.up
    Folder.update_all("name = 'Required Files & Folders Template'", "name ='Master Template'")
  end

  def self.down
    Folder.update_all("name = 'Master Template'", "name ='Required Files & Folders Template'")
  end
end
