class Changelogin < ActiveRecord::Migration
 
  def self.up
    @users=User.find(:all,:conditions=>["email != 'admin@theamp.com'"])
    say_with_time("Login changed") do
      @users.each do |user|
        user.update_attributes(:login=>user.email)
      end
    end
  end
  def self.down
  end
end
