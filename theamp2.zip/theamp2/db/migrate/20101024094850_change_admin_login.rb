class ChangeAdminLogin < ActiveRecord::Migration
  def self.up
          @user=User.find(:first,:conditions=>["email = ?","#{APP_CONFIG[:admin_email]}"])
	  @user.update_attributes(:login=>"admin") if @user
  end

  def self.down
  end
end
