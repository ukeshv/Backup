class CreateRealEstateProperties < ActiveRecord::Migration
  def self.up
     create_table :real_estate_properties do |t|
 			t.integer :portfolio_id
			t.integer :property_size,:gross_land_area,:gross_rentable_area,:no_of_units,:year_built,:property_type_id
			t.string :property_name,:city,:state,:zip
			t.text :property_description,:address
			t.decimal :purchase_price, :precision => 26, :scale => 2, :default => 0
      t.integer :state_id,:user_id
      t.boolean :is_granted,:is_deselected,:is_valid,:default =>0
      t.decimal :sale_price,:cap_rate,:annualized_noi,:precision => 26, :scale => 2, :default => 0
      t.timestamps
    end
end

  def self.down
    drop_table :real_estate_properties
  end
end
