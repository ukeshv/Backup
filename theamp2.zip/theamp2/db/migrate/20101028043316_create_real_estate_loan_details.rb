class CreateRealEstateLoanDetails < ActiveRecord::Migration
  def self.up
   create_table :real_estate_loan_details do |t|
     	t.integer :portfolio_id
      t.integer :real_estate_property_id
			t.string :property_name
			t.decimal :original_note_amount,:current_outstanding,:late_payments_amount_due, :precision => 26, :scale => 2, :default => 0
			t.float :current_interest_rate, :default => 0
			t.date :first_payment_date,:last_payment_date,:maturity_date
			t.text :comments,:error_message 
      t.string :loan_type
      t.timestamps
  end      
  end

  def self.down
    drop_table :real_estate_loan_details
  end
end
