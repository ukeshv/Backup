class ChangeColumnsAdvancedDueDate < ActiveRecord::Migration
  def self.up
    adv_due_dates = AdvancedDueDate.find(:all)
    say_with_time("Change columns advanced due date") do
      adv_due_dates.each do |adv|
        doc = Document.find_by_id(adv.document_id)
        delete_file = doc.folder
        delete_files = delete_file.documents
        delete_files.each do |file|
          if !file.filename.scan(/(^cash_flow_future_.*$)/).empty? || !file.filename.scan(/(^rent_roll_.*$)/).empty? || !file.filename.scan(/(^cash_flow_actuals.*$)/).empty? || !file.filename.scan(/(^cash_flow_past_.*$)/).empty?
            file.shared_documents.delete_all
            file.event_resources.delete_all
            file.delete
          end
        end
      end
    end
    sql = ActiveRecord::Base.connection();
    sql.execute "truncate table advanced_due_dates"
    rename_column :advanced_due_dates, :document_id, :template_id
    add_column :advanced_due_dates, :repeat_period, :integer #This column is going to be used for 'FOR'
    add_column :advanced_due_dates, :resource_id, :integer
    add_column :advanced_due_dates, :resource_type, :string
    rename_column :advanced_due_dates, :is_future, :budgets_or_actuals #1 for budgets and 0 for actuals
  end

  def self.down
    rename_column :advanced_due_dates, :template_id, :document_id
    remove_column :advanced_due_dates, :repeat_period #This column is going to be used for 'FOR'
    remove_column :advanced_due_dates, :resource_id
    remove_column :advanced_due_dates, :resource_type
    rename_column :advanced_due_dates, :budgets_or_actuals, :is_future
  end
end