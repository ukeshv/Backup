class CreateCashFlowDetails < ActiveRecord::Migration
  def self.up
    create_table :cash_flow_details do |t|
      t.string :cash_flow_type #Will be 1 or 2. 1 for Actual & 2 for Budget
      t.integer :resource_id, :advanced_due_date_id, :document_id, :limit => 10
      t.string :resource_type #To use for Property/PropertyRealEstate
      t.boolean :is_archived
      
      #Same as actuals
 			t.integer :user_id, :limit => 10
			t.integer :property_type_id, :limit => 10
      t.datetime :start_date
      t.datetime :end_date
      t.text :potential_gross_revenue
			t.decimal :total_potential_gross_revenue, :scale=>2,:precision=>25   
      t.text :expense_reimbursement_revenue      
      t.decimal :total_reimbursement_revenue, :scale=>2,:precision=>25
      t.text :revenue_adjustments   
      t.decimal :total_revenue_adjustments, :scale=>2,:precision=>25
      t.decimal :effective_gross_revenue, :scale=>2,:precision=>25
      t.text :operating_expenses   
      t.decimal :total_operating_expenses, :scale=>2,:precision=>25
      t.decimal :net_operating_income, :scale=>2,:precision=>25
      t.text :debt_service   
      t.decimal :total_debt_service, :scale=>2,:precision=>25   
      t.text :leasing_and_capital_costs
      t.decimal :total_leasing_and_capital_costs,:scale=>2, :precision=>25
      t.decimal :cash_flow_after_debt_service_before_tax, :scale=>2,:precision=>25

      t.timestamps
    end
  end

  def self.down
    drop_table :cash_flow_details
  end
end
