class ChangesOfActualsAndBudgets < ActiveRecord::Migration
  def self.up
    sql = ActiveRecord::Base.connection();
    sql.execute "truncate table actuals"
    sql.execute "truncate table budgets"
    add_column :actuals, :cash_flow_detail_id, :integer
    add_column :budgets, :cash_flow_detail_id, :integer
    add_column :actuals, :resource_id, :integer
    add_column :actuals, :resource_type, :string #To use for Property/PropertyRealEstate
    add_column :budgets, :resource_id, :integer
    add_column :budgets, :resource_type, :string #To use for Property/PropertyRealEstate
    remove_column :actuals, :property_id
    remove_column :budgets, :property_id
    remove_column :actuals, :start_date
    remove_column :actuals, :end_date
    remove_column :budgets, :start_date
    remove_column :budgets, :end_date
    add_column :budgets, :month_and_year, :date
    add_column :actuals, :month_and_year, :date
  end

  def self.down
    remove_column :actuals, :cash_flow_detail_id
    remove_column :budgets, :cash_flow_detail_id
    remove_column :actuals, :resource_id
    remove_column :actuals, :resource_type #To use for Property/PropertyRealEstate
    remove_column :budgets, :resource_id
    remove_column :budgets, :resource_type #To use for Property/PropertyRealEstate
    add_column :actuals, :property_id, :integer
    add_column :budgets, :property_id, :integer
    add_column :actuals, :start_date, :date
    add_column :actuals, :end_date, :date
    add_column :budgets, :start_date, :date
    add_column :budgets, :end_date, :date
    remove_column :budgets, :month_and_year
    remove_column :actuals, :month_and_year
  end
end