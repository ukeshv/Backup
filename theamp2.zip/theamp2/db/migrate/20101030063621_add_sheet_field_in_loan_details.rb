class AddSheetFieldInLoanDetails < ActiveRecord::Migration
  def self.up
    add_column :real_estate_loan_details,:sheet,:integer
  end

  def self.down
    remove_column :real_estate_loan_details,:sheet
  end
end
