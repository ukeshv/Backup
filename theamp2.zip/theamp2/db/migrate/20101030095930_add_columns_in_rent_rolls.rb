class AddColumnsInRentRolls < ActiveRecord::Migration
 def self.up
    remove_column :rent_rolls,:property_id
    add_column :rent_rolls, :resource_id, :integer
    add_column :rent_rolls, :resource_type, :string
  end

  def self.down
    add_column :rent_rolls,:property_id,:integer
    remove_column :rent_rolls, :resource_id
    remove_column :rent_rolls, :resource_type
  end
end
