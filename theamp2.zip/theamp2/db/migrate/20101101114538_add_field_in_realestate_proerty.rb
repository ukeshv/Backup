class AddFieldInRealestateProerty < ActiveRecord::Migration
  def self.up
    add_column :real_estate_properties,:error_message,:string
  end

  def self.down
    remove_column :real_estate_properties,:error_message,:string
  end
end
