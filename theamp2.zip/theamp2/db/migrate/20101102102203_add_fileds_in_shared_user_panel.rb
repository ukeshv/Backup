class AddFiledsInSharedUserPanel < ActiveRecord::Migration
  def self.up
   add_column :share_document_names,:real_estate_property_id,:integer
   add_column :shared_documents,:real_estate_property_id,:integer
   add_column :shared_folders,:real_estate_property_id,:integer

  end

  def self.down
   remove_column :share_document_names,:real_estate_property_id,:integer
   remove_column :shared_documents,:real_estate_property_id,:integer
   remove_column :shared_folders,:real_estate_property_id,:integer
  end
end
