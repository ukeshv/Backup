class ChangeColumnRentRoll < ActiveRecord::Migration
  def self.up
    remove_column :rent_rolls, :total_occupied
    remove_column :rent_rolls, :total_available
    add_column :rent_rolls, :total_occupied, :decimal, :precision => 25, :scale => 2
    add_column :rent_rolls, :total_available,  :decimal, :precision => 25, :scale => 2
  end

  def self.down
    remove_column :rent_rolls, :total_occupied
    remove_column :rent_rolls, :total_available
    add_column :rent_rolls, :total_occupied, :decimal
    add_column :rent_rolls, :total_available,  :decimal
  end
end
