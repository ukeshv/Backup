class AddOccpancyFieldInProperties < ActiveRecord::Migration
  def self.up
    add_column :properties, :occupancy, :float
    add_column :real_estate_properties, :occupancy, :float
    qry = "SELECT a.* FROM rent_rolls as a, (SELECT resource_id, max(end_date) AS ed FROM rent_rolls where resource_type = 'Property' GROUP BY resource_id) as b WHERE a.resource_id=b.resource_id AND a.end_date = b.ed and a.resource_type = 'Property'"
    cng_properties = RentRoll.find_by_sql(qry)
    say_with_time("Select query based on property") do
      cng_properties.each do |rent_roll|
        occ = !rent_roll.total_occupied.nil? && !rent_roll.total_available.nil? ?  (rent_roll.total_occupied/(rent_roll.total_occupied + rent_roll.total_available)) * 100 : 0
        rent_roll.resource.occupancy = occ
        rent_roll.resource.save
      end
    end

    qry = "SELECT a.* FROM rent_rolls as a, (SELECT resource_id, max(end_date) AS ed FROM rent_rolls where resource_type = 'RealEstateProperty' GROUP BY resource_id) as b WHERE a.resource_id=b.resource_id AND a.end_date = b.ed and a.resource_type = 'RealEstateProperty'"
    cng_properties = RentRoll.find_by_sql(qry)
    say_with_time("Select query based on rela estate property") do
      cng_properties.each do |rent_roll|
        occ = !rent_roll.total_occupied.nil? && !rent_roll.total_available.nil? ?  (rent_roll.total_occupied/(rent_roll.total_occupied + rent_roll.total_available)) * 100 : 0
        rent_roll.resource.occupancy = occ
        rent_roll.resource.save
      end
    end
  end

  def self.down
    remove_column(:properties, :occupancy)
    remove_column(:real_estate_properties, :occupancy)
  end
end
