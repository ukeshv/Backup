class ModifyColsInBuyersAndProofDocs < ActiveRecord::Migration
  def self.up
    rename_column :buyers, :property_id, :resource_id
    add_column :buyers, :resource_type, :string, :limit=>50
    rename_column :proof_documents, :property_id, :resource_id
    add_column :proof_documents, :resource_type, :string, :limit=>50
  end

  def self.down
    rename_column :buyers, :resource_id, :property_id
    remove_column :buyers, :resource_type
    rename_column :proof_documents, :resource_id, :property_id
    remove_column :proof_documents, :resource_type
  end
end
