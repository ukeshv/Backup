class AddPermalinkInPropertyAndRealEstateProperty < ActiveRecord::Migration
  def self.up
    add_column :properties, :permalink, :string
    add_column :real_estate_properties, :permalink, :string
  end

  def self.down
    remove_column :properties, :permalink
    remove_column :real_estate_properties, :permalink
  end
end
