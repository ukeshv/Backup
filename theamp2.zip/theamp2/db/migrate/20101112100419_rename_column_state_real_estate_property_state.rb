class RenameColumnStateRealEstatePropertyState < ActiveRecord::Migration
  def self.up
    rename_column :real_estate_properties, :state, :province
  end

  def self.down
    rename_column :real_estate_properties, :province, :state
  end
end
