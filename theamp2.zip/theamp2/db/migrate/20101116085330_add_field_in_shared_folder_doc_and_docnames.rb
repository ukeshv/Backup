class AddFieldInSharedFolderDocAndDocnames < ActiveRecord::Migration
   def self.up
    add_column :shared_folders, :comments, :text
    add_column :shared_documents, :comments, :text
    add_column :share_document_names, :comments, :text
  end

  def self.down
    remove_column :shared_folders, :comments
    remove_column :shared_documents, :comments
    remove_column :share_document_names, :comments
  end
end
