class CreateIncomeAndCashFlowDetails < ActiveRecord::Migration
  def self.up
    create_table :income_and_cash_flow_details do |t|
			t.string :title
			t.integer :parent_id
      t.integer :resource_id
      t.string :resource_type
      t.integer :user_id		
			t.integer :year
      t.datetime :template_date
      t.timestamps
    end
  end

  def self.down
    drop_table :income_and_cash_flow_details
  end
end
