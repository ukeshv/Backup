class CreatePropertyCapitalImprovements < ActiveRecord::Migration
  def self.up
    create_table :property_capital_improvements do |t|
      t.integer :year
      t.integer :month
      t.string  :tenant_name
      t.integer :property_suite_id
      t.integer :real_estate_property_id
      t.column  :annual_budget,:double
      t.string  :project_status
      t.string  :category  #(TI,LC,total values)
      t.timestamps
    end
  end

  def self.down
    drop_table :property_capital_improvements
  end
end
