class CreatePropertyFinancialPeriods < ActiveRecord::Migration
  def self.up
    create_table :property_financial_periods do |t|
      t.integer  :source_id
      t.string   :source_type
      t.integer  :year
      t.string   :pcb_type
      t.column  :january,:double
      t.column  :february,:double
      t.column  :march,:double
      t.column  :april,:double
      t.column  :may,:double
      t.column  :june,:double
      t.column  :july,:double
      t.column  :august,:double
      t.column  :september,:double
      t.column  :october,:double
      t.column  :november,:double
      t.column  :december,:double
      t.timestamps
    end
  end

  def self.down
    drop_table :property_financial_periods
  end
end
