class CreatePropertySuites < ActiveRecord::Migration
  def self.up
    create_table :property_suites do |t|
      t.integer :real_estate_property_id
      t.string :suite_number
      t.integer :rented_area
      t.string :space_type
      t.timestamps
    end
  end

  def self.down
    drop_table :property_suites
  end
end
