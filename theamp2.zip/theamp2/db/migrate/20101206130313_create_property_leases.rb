class CreatePropertyLeases < ActiveRecord::Migration
  def self.up
    create_table :property_leases do |t|
      t.integer :property_suite_id
      t.string :tenant
      t.date :start_date
      t.date :end_date
      t.date :date_executed
      t.date :last_payment_date
      t.float :base_rent
      t.float :effective_rate
      t.float :tenant_improvements
      t.float :leasing_commisions
      t.string :comments
      t.string :occupancy_type
      t.timestamps
    end
  end

  def self.down
    drop_table :property_leases
  end
end
