class CreatePropertyOccupancySummaries < ActiveRecord::Migration
  def self.up
    create_table :property_occupancy_summaries do |t|
      t.column :total_building_rentable_s,:bigint
			t.column :last_year_sf_occupied_actual,:bigint
			t.column :last_year_sf_occupied_budget,:bigint
			t.column :current_year_sf_occupied_actual,:bigint
			t.column :current_year_sf_occupied_budget,:bigint
			t.column :current_year_sf_vacant_actual,:bigint
			t.column :current_year_sf_vacant_budget,:bigint
			t.column :new_leases_actual, :bigint
			t.column :new_leases_budget, :bigint
			t.column :renewals_actual, :bigint
			t.column :renewals_budget, :bigint
			t.column :expirations_actual, :bigint
			t.column :expirations_budget, :bigint
			t.integer :year
			t.integer :month
      t.integer :real_estate_property_id			
      t.timestamps
    end
  end

  def self.down
    drop_table :property_occupancy_summaries
  end
end
