class AddMonthToPropertyLease < ActiveRecord::Migration
  def self.up
    add_column :property_leases, :month, :integer
    add_column :property_leases, :year, :integer
  end

  def self.down
    remove_column :property_leases, :month
    remove_column :property_leases, :year
  end
end
