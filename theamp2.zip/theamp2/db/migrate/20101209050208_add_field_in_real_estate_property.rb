class AddFieldInRealEstateProperty < ActiveRecord::Migration
  def self.up
        add_column :real_estate_properties,:address_id,:integer
  end

  def self.down
        remove_column :real_estate_properties,:address_id
  end
end
