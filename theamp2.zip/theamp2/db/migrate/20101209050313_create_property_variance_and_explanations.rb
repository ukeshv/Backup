class CreatePropertyVarianceAndExplanations < ActiveRecord::Migration
  def self.up
    create_table :property_variance_and_explanations do |t|
      t.integer :property_cash_flow_detail_id
      t.text :explanation
      t.integer :year
      t.integer :month
      t.timestamps
    end
  end

  def self.down
    drop_table :property_variance_and_explanations
  end
end
