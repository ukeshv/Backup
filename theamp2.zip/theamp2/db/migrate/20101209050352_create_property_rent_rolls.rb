class CreatePropertyRentRolls < ActiveRecord::Migration
  def self.up
    create_table :property_rent_rolls do |t|
      t.integer :property_suite_id
      t.datetime :start_date
      t.datetime :end_date
      t.string :tenant 
      t.column :monthly_base_rent,:double
      t.column :annual_rate_per_sf,:double
      t.column :monthly_cost_recovery,:double
      t.column :expense_stop,:double
      t.column :monthly_other_income,:double
      t.column :security_deposit,:double
      t.timestamps
    end
  end

  def self.down
    drop_table :property_rent_rolls
  end
end
