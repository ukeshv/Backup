class CreatePropertyAgedReceivables < ActiveRecord::Migration
  def self.up
    create_table :property_aged_receivables do |t|
       t.integer :property_suite_id
       t.string :tenant
       t.column :paid_amount,:double
       t.column :over_30days,:double
       t.column :over_60days,:double
       t.column :over_90days,:double
       t.column :over_120days,:double
       t.text :explanation
       t.integer :month
       t.integer :year
       t.timestamps
    end
  end

  def self.down
    drop_table :property_aged_receivables
  end
end
