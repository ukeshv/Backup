class CreatePropertyDebtSummaries < ActiveRecord::Migration
  def self.up
    create_table :property_debt_summaries do |t|
      t.integer :real_estate_property_id
      t.string :category
      t.text :description
      t.integer :month
      t.integer :year
      t.timestamps
    end
  end

  def self.down
    drop_table :property_debt_summaries
  end
end
