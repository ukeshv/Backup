class AddFieldInPortfolioType < ActiveRecord::Migration
  def self.up
        add_column :portfolio_types,:variance_percentage,:float
        add_column :portfolio_types,:variance_amount,:double

  end

  def self.down
        remove_column :portfolio_types,:variance_percentage
        remove_column :portfolio_types,:variance_amount        
  end
end
