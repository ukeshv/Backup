class AddFieldsInRealEstateProperty < ActiveRecord::Migration
  def self.up
    add_column :real_estate_properties,:variance_percentage,:float
    add_column :real_estate_properties,:variance_amount,:double
  end

  def self.down
    remove_column :real_estate_properties,:variance_percentage
    remove_column :real_estate_properties,:variance_amount
  end
end
