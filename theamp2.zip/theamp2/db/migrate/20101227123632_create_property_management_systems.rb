class CreatePropertyManagementSystems < ActiveRecord::Migration
  def self.up
    create_table :property_management_systems do |t|
      t.string :name, :short_code 
      t.timestamps
    end
    PropertyManagementSystem.create(:name=>'None', :short_code=>'none')
  end

  def self.down
    drop_table :property_management_systems
  end
end
