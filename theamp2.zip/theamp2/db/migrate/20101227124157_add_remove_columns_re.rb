class AddRemoveColumnsRe < ActiveRecord::Migration
  def self.up
    add_column :real_estate_properties, :property_management_system_id, :integer
    rename_column :real_estate_properties, :address, :txt
    rename_column :addresses, :state, :province
    
    #added migration code to copy existing values of city,state,zip, address to address table
    real_estate_properties = RealEstateProperty.find(:all, :conditions=>['address_id IS NULL'])
    say_with_time("Add columns") do
      real_estate_properties.each do |re|
        re.is_field_exists = true
        address = Address.create(:city=>re.city, :province=>re.province, :zip=>re.zip, :txt=>re.txt)
        re.update_attributes(:address_id=>address.id)
      end
    end
    
    remove_column :real_estate_properties, :city
    remove_column :real_estate_properties, :province
    remove_column :real_estate_properties, :zip
    remove_column :real_estate_properties, :txt    
  end

  def self.down
    remove_column :real_estate_properties, :property_management_system_id
    
    add_column :real_estate_properties, :city, :string
    add_column :real_estate_properties, :province, :string
    add_column :real_estate_properties, :zip, :string
    add_column :real_estate_properties, :txt, :string
    rename_column :addresses, :province, :state
    
    #added migration code to copy existing values of city,state,zip, address from address table to re
    real_estate_properties = RealEstateProperty.find(:all, :conditions=>['address_id IS NOT NULL'])
    say_with_time("Remove columns") do
      real_estate_properties.each do |re|
        address_re = re.address
        re.update_attributes(:city=>address_re.city, :province=>address_re.state, :zip=>address_re.zip, :txt=>address_re.txt)
        address_re.destroy
        re.update_attributes(:address_id=>nil)
      end
    end
    
    rename_column :real_estate_properties, :txt, :address
  end
end