class CreateTaskFiles < ActiveRecord::Migration
  def self.up
    create_table :task_files do |t|      
			t.string :filename,:content_type,:thumbnail
			t.integer :height,:width,:size,:task_id,:user_id, :real_estate_property_id,:document_id
			t.boolean :is_deleted
			t.integer :ipaper_id
			t.string :ipaper_access_id			
      t.timestamps
    end
  end

  def self.down
    drop_table :task_files
  end
end
