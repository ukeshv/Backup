class CreateTaskDocuments < ActiveRecord::Migration
  def self.up
    create_table :task_documents do |t|
      t.integer :task_id,:document_id,:primary_document_id
      t.timestamps
    end
  end

  def self.down
    drop_table :task_documents
  end
end
