class AddIsCompletedInMigration < ActiveRecord::Migration
  def self.up
		add_column :task_collaborators ,:is_completed ,:boolean
		add_column :tasks,:repeat_task_id,:integer
  end

  def self.down
		remove_column :task_collaborators ,:is_completed
		remove_column :tasks,:repeat_task_id		
  end
end
