class CreateRepeatTasks < ActiveRecord::Migration
  def self.up
    create_table :repeat_tasks do |t|
      t.integer :document_id
			t.string :period
		  t.integer :repeat_count 
			t.date :repeat_start_date 
			t.integer :task_scheduling_days,:default => 10
			t.integer :task_created_count,:default => 0
      t.timestamps
    end
  end

  def self.down
    drop_table :repeat_tasks
  end
end
