class AddDoerFileToTaskFile < ActiveRecord::Migration
  def self.up
    add_column :task_files, :doer_file, :boolean,:default => false
  end

  def self.down
    remove_column :task_files, :doer_file
  end
end
