class AddSharerIdTaskCollaborators < ActiveRecord::Migration
  def self.up
		add_column(:task_collaborators ,:sharer_id,:integer)
  end

  def self.down
		remove_column(:task_collaborators ,:sharer_id)
  end
end
