class AddFolderIdTaskTable < ActiveRecord::Migration
  def self.up
		add_column(:tasks,:folder_id,:integer)
		add_column(:tasks,:temp_task,:boolean,:default => false)
		add_column(:repeat_tasks,:folder_id,:integer)
  end

  def self.down
		remove_column(:tasks,:folder_id)
		remove_column(:tasks,:temp_task)
		remove_column(:repeat_tasks,:folder_id)
  end
end
