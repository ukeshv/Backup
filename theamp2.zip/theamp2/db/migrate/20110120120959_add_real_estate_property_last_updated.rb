class AddRealEstatePropertyLastUpdated < ActiveRecord::Migration
  def self.up
    add_column(:real_estate_properties ,:last_updated, :datetime)
  end

  def self.down
    remove_column(:real_estate_properties ,:last_updated)
  end
end
