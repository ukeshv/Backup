class CreateIncomeCashFlowExplanations < ActiveRecord::Migration
  def self.up
    create_table :income_cash_flow_explanations do |t|
      t.integer :cash_flow_detail_id
      t.text :explanation
      t.timestamps
    end
  end

  def self.down
    drop_table :income_cash_flow_explanations
  end
end
