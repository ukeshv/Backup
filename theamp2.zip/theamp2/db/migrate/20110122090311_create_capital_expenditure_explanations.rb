class CreateCapitalExpenditureExplanations < ActiveRecord::Migration
  def self.up
    create_table :capital_expenditure_explanations do |t|
      t.integer :capital_expenditure_detail_id
      t.text :explanation
      t.timestamps
    end
  end

  def self.down
    drop_table :capital_expenditure_explanations
  end
end
