class GroupingPropertyCapitalImprovements < ActiveRecord::Migration
  def self.up
    sql = ActiveRecord::Base.connection();
    sql.execute "INSERT INTO property_capital_improvements (year, month, real_estate_property_id, category, tenant_name, annual_budget, created_at, updated_at) (SELECT year,month, real_estate_property_id, category, category, 0, now(), now()  FROM `property_capital_improvements` GROUP BY year, month, real_estate_property_id, category)"
    #sql.execute "DELETE property_capital_improvements FROM property_capital_improvements, (SELECT MAX(id) AS dupid, COUNT(id) AS dupcnt FROM property_capital_improvements GROUP BY year, month, real_estate_property_id, category HAVING dupcnt > 1) AS dups WHERE property_capital_improvements.id = dups.dupid"
    #SELECT max(id) AS dupid, COUNT(id) AS dupcnt FROM property_capital_improvements where tenant_name = category GROUP BY year, month, real_estate_property_id, category HAVING dupcnt > 1
    sql.execute "DELETE property_capital_improvements FROM property_capital_improvements, (SELECT max(id) AS dupid, COUNT(id) AS dupcnt FROM property_capital_improvements where tenant_name = category and annual_budget = 0 GROUP BY year, month, real_estate_property_id, category HAVING dupcnt > 1) AS dups WHERE property_capital_improvements.id = dups.dupid"
  end

  def self.down
    sql = ActiveRecord::Base.connection();
    sql.execute "DELETE FROM property_capital_improvements WHERE category = tenant_name AND annual_budget = 0"
  end
end
