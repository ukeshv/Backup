class CreateLeasesExplanations < ActiveRecord::Migration
  def self.up
    create_table :leases_explanations do |t|
      t.integer :real_estate_property_id
      t.text :explanation
      t.integer :month
      t.integer :year
      t.string :occupancy_type
      t.timestamps
    end
  end

  def self.down
    drop_table :leases_explanations
  end
end
