class DelExistingUnwantedEvents < ActiveRecord::Migration
  def self.up
    sql = ActiveRecord::Base.connection();
    sql.execute "DELETE FROM events WHERE action_type in ('mapped secondary file','rename','create secondary file','moved','copied','Collaborators','commented','shared','unshared','up_comment','rep_comment','del_comment')"
  end

  def self.down
  end
end
