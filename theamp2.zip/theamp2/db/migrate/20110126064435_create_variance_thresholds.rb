class CreateVarianceThresholds < ActiveRecord::Migration
  def self.up
    create_table :variance_thresholds do |t|
      t.integer :real_estate_property_id
      t.integer :document_id
      t.float :variance_percentage
      t.float :variance_amount
      t.float :cap_exp_variance
      t.string  :and_or, :default =>'and'
      t.integer :user_id 
      t.timestamps
    end
  end

  def self.down
    drop_table :variance_thresholds
  end
end
