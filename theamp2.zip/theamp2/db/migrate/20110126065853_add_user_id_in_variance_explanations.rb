class AddUserIdInVarianceExplanations < ActiveRecord::Migration
  def self.up
    add_column :capital_expenditure_explanations, :user_id, :integer
    add_column :income_cash_flow_explanations, :user_id, :integer
    rename_column(:income_cash_flow_explanations, :cash_flow_detail_id, :income_and_cash_flow_detail_id)
    rename_column(:capital_expenditure_explanations, :capital_expenditure_detail_id, :property_capital_improvement_id)
    add_column :income_cash_flow_explanations, :month, :integer
    add_column :capital_expenditure_explanations, :month, :integer
    add_column :leases_explanations, :user_id, :integer
  end

  def self.down
    remove_column :capital_expenditure_explanations, :user_id 
    remove_column :income_cash_flow_explanations , :user_id
    rename_column(:income_cash_flow_explanations, :income_and_cash_flow_detail_id, :cash_flow_detail_id)
    rename_column(:capital_expenditure_explanations, :property_capital_improvement_id, :capital_expenditure_detail_id)
    remove_column :income_cash_flow_explanations, :month
    remove_column :capital_expenditure_explanations, :month
    remove_column :leases_explanations, :user_id, :integer
  end
end
