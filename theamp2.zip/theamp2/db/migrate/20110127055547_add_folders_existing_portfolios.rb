class AddFoldersExistingPortfolios < ActiveRecord::Migration
  def self.up
    sql = ActiveRecord::Base.connection();
    sql.execute "Insert into folders (name,parent_id,portfolio_id,user_id,is_master,is_deleted,is_deselected,created_at,updated_at) select name,-1,id,user_id,0,0,0,now(),now() from portfolios where id not in(select portfolio_id from folders where parent_id = -1  group by `portfolio_id`)"
  end

  def self.down
    sql = ActiveRecord::Base.connection();
    sql.execute "delete from folders WHERE parent_id = -1"
  end
end
