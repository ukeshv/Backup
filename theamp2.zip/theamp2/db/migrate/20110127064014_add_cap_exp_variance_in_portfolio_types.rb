class AddCapExpVarianceInPortfolioTypes < ActiveRecord::Migration
  def self.up
    add_column :portfolio_types, :cap_exp_variance, :double
    add_column :portfolio_types, :and_or, :string, :default=>'and'
  end

  def self.down
    remove_column :portfolio_types, :cap_exp_variance
    remove_column :portfolio_types, :and_or
  end
end
