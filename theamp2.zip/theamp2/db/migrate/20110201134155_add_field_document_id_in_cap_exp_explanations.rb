class AddFieldDocumentIdInCapExpExplanations < ActiveRecord::Migration
  def self.up
    add_column :capital_expenditure_explanations, :document_id, :integer
  end

  def self.down
    remove_column(:capital_expenditure_explanations, :document_id)
  end
end
