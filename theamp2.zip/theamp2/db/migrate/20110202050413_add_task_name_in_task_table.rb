class AddTaskNameInTaskTable < ActiveRecord::Migration
  def self.up
		add_column(:tasks,:task_name,:string,:default => "")
  end

  def self.down
		remove_column(:tasks,:task_name)
  end
end
