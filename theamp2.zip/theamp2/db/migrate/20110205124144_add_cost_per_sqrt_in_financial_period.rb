class AddCostPerSqrtInFinancialPeriod < ActiveRecord::Migration
  def self.up
		add_column(:property_financial_periods,:dollar_per_sqft,:double,:default => 0)
		add_column(:property_financial_periods,:dollar_per_unit,:double,:default => 0)
  end

  def self.down
		remove_column(:property_financial_periods,:dollar_per_sqft)
		remove_column(:property_financial_periods,:dollar_per_unit)		
  end
end
