class WresLeasesAddColumns < ActiveRecord::Migration
  def self.up
    #To be stored in property suites from all_units.xls as this is common for a suite
    add_column :property_suites, :floor_plan, :string, :limit=>20
    
    #To be stored in property leases from all_units.xls as this is related to particular lease
    add_column :property_leases, :move_in, :date
    add_column :property_leases, :other_deposits, :float, :limit=>30, :default=>0
    add_column :property_leases, :made_ready, :boolean, :default=>true
    add_column :property_leases, :amt_per_sqft, :float, :limit=>30, :default=>0
    add_column :property_leases, :actual_amt_per_sqft, :float, :limit=>30, :default=>0
    
    #To be stored in property occupancy summaries from all_units.xls as this is a summary details
    add_column :property_occupancy_summaries, :currently_vacant_leases_number, :integer, :default=>0
    add_column :property_occupancy_summaries, :currently_vacant_leases_percentage, :float, :default=>0
    add_column :property_occupancy_summaries, :vacant_leased_number, :integer, :default=>0
    add_column :property_occupancy_summaries, :vacant_leased_percentage, :float, :default=>0
    add_column :property_occupancy_summaries, :occupied_on_notice_number, :integer, :default=>0
    add_column :property_occupancy_summaries, :occupied_on_notice_percentage, :float, :default=>0
    add_column :property_occupancy_summaries, :occupied_preleased_number, :integer, :default=>0
    add_column :property_occupancy_summaries, :occupied_preleased_percentage, :float, :default=>0    
    add_column :property_occupancy_summaries, :net_exposure_to_vacancy_number, :integer, :default=>0
    add_column :property_occupancy_summaries, :net_exposure_to_vacancy_percentage, :float, :default=>0    
    add_column :property_occupancy_summaries, :current_year_units_occupied_actual, :integer, :default=>0
    add_column :property_occupancy_summaries, :current_year_units_vacant_actual, :integer, :default=>0
    add_column :property_occupancy_summaries, :current_year_units_total_actual, :integer, :default=>0
  end

  def self.down
    #To be stored in property suites from all_units.xls as this is common for a suite
    remove_column :property_suites, :floor_plan
    
    #To be stored in property leases from all_units.xls as this is related to particular lease
    remove_column :property_leases, :move_in
    remove_column :property_leases, :other_deposits
    remove_column :property_leases, :made_ready
    remove_column :property_leases, :amt_per_sqft
    remove_column :property_leases, :actual_amt_per_sqft
    
    #To be stored in property occupancy summaries from all_units.xls as this is a summary details
    remove_column :property_occupancy_summaries, :currently_vacant_leases_number
    remove_column :property_occupancy_summaries, :currently_vacant_leases_percentage
    remove_column :property_occupancy_summaries, :vacant_leased_number
    remove_column :property_occupancy_summaries, :vacant_leased_percentage
    remove_column :property_occupancy_summaries, :occupied_on_notice_number
    remove_column :property_occupancy_summaries, :occupied_on_notice_percentage
    remove_column :property_occupancy_summaries, :occupied_preleased_number
    remove_column :property_occupancy_summaries, :occupied_preleased_percentage
    remove_column :property_occupancy_summaries, :net_exposure_to_vacancy_number
    remove_column :property_occupancy_summaries, :net_exposure_to_vacancy_percentage    
    remove_column :property_occupancy_summaries, :current_year_units_occupied_actual
    remove_column :property_occupancy_summaries, :current_year_units_vacant_actual
    remove_column :property_occupancy_summaries, :current_year_units_total_actual
  end
end
