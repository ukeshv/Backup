class CreatePropertyCashFlowForecasts < ActiveRecord::Migration
  def self.up
    create_table :property_cash_flow_forecasts do |t|
      t.string :title
			t.integer :parent_id
      t.integer :resource_id
      t.string :resource_type
      t.integer :user_id
			t.integer :year
      t.datetime :template_date
      t.timestamps
    end
  end

  def self.down
    drop_table :property_cash_flow_forecasts
  end
end
