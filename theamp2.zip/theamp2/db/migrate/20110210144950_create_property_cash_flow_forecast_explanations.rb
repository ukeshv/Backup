class CreatePropertyCashFlowForecastExplanations < ActiveRecord::Migration
  def self.up
    create_table :property_cash_flow_forecast_explanations do |t|
      t.integer :property_cash_flow_forecast_id
      t.string  :explanation
      t.integer :user_id
      t.integer :month
      t.integer :document_id
      t.timestamps
    end
  end

  def self.down
    drop_table :property_cash_flow_forecast_explanations
  end
end
