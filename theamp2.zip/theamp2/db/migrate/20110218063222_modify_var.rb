class ModifyVar < ActiveRecord::Migration
  def self.up
    coll = IncomeAndCashFlowDetail.find_all_by_title_and_resource_type('maintenance projects','RealEstateProperty')
    say_with_time("Modify var") do
      coll.each do |itr|
        coll1 = IncomeAndCashFlowDetail.find_all_by_parent_id(itr.id)
        coll1.each do |it|
          a=ModifyVar.new
          a.child(it)
        end
        pfs =  itr.property_financial_periods
        b_row = pfs.detect {|i| i.pcb_type == 'b'}
        a_row = pfs.detect {|i| i.pcb_type == 'c'}
        unless b_row.nil? && a_row.nil?
          b_arr = [b_row.january, b_row.february, b_row.march, b_row.april, b_row.may, b_row.june, b_row.july, b_row.august, b_row.september, b_row.october, b_row.november, b_row.december]
          b_arr.each_with_index { |i,j| b_arr[j] = 0 if i.nil? }
          a_arr = [a_row.january, a_row.february, a_row.march, a_row.april, a_row.may, a_row.june, a_row.july, a_row.august, a_row.september, a_row.october, a_row.november, a_row.december]
          a_arr.each_with_index { |i,j| a_arr[j] = 0 if i.nil? }
          var_arr = []
          per_arr = []
          0.upto(11) do |indx|
            var_arr[indx] =  b_arr[indx].to_f - a_arr[indx].to_f
            per_arr[indx] =  (var_arr[indx] * 100) / b_arr[indx].to_f
            if  b_arr[indx].to_f==0
              per_arr[indx] = ( a_arr[indx].to_f == 0 ? 0 : -100 )
            end
            per_arr[indx]= 0.0 if per_arr[indx].to_f.nan?
          end
          pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_amt')
          pf.january= var_arr[0];pf.february=var_arr[1];pf.march=var_arr[2];pf.april=var_arr[3];pf.may=var_arr[4];pf.june=var_arr[5];pf.july=var_arr[6];pf.august=var_arr[7];pf.september=var_arr[8];pf.october=var_arr[9];pf.november=var_arr[10];pf.december=var_arr[11];pf.save
          pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_per')
          pf.january= per_arr[0];pf.february=per_arr[1];pf.march=per_arr[2];pf.april=per_arr[3];pf.may=per_arr[4];pf.june=per_arr[5];pf.july=per_arr[6];pf.august=per_arr[7];pf.september=per_arr[8];pf.october=per_arr[9];pf.november=per_arr[10];pf.december=per_arr[11];pf.save
        end
      end
    end
  end

  def self.down
  end
  
  def child(itr)
    pfs =  itr.property_financial_periods
    b_row = pfs.detect {|i| i.pcb_type == 'b'}
    a_row = pfs.detect {|i| i.pcb_type == 'c'}
    unless b_row.nil? && a_row.nil?
      b_arr = [b_row.january, b_row.february, b_row.march, b_row.april, b_row.may, b_row.june, b_row.july, b_row.august, b_row.september, b_row.october, b_row.november, b_row.december]
      b_arr.each_with_index { |i,j| b_arr[j] = 0 if i.nil? }
      a_arr = [a_row.january, a_row.february, a_row.march, a_row.april, a_row.may, a_row.june, a_row.july, a_row.august, a_row.september, a_row.october, a_row.november, a_row.december]
      a_arr.each_with_index { |i,j| a_arr[j] = 0 if i.nil? }
      var_arr = []
      per_arr = []
      0.upto(11) do |indx|
        var_arr[indx] =  b_arr[indx].to_f - a_arr[indx].to_f
        per_arr[indx] =  (var_arr[indx] * 100) / b_arr[indx].to_f
        if  b_arr[indx].to_f==0
          per_arr[indx] = ( a_arr[indx].to_f == 0 ? 0 : -100 )
        end
        per_arr[indx]= 0.0 if per_arr[indx].to_f.nan?
      end
      pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_amt')
      pf.january= var_arr[0];pf.february=var_arr[1];pf.march=var_arr[2];pf.april=var_arr[3];pf.may=var_arr[4];pf.june=var_arr[5];pf.july=var_arr[6];pf.august=var_arr[7];pf.september=var_arr[8];pf.october=var_arr[9];pf.november=var_arr[10];pf.december=var_arr[11];pf.save
      pf = PropertyFinancialPeriod.find_or_initialize_by_source_id_and_source_type_and_pcb_type(itr.id, itr.class.to_s, 'var_per')
      pf.january= per_arr[0];pf.february=per_arr[1];pf.march=per_arr[2];pf.april=per_arr[3];pf.may=per_arr[4];pf.june=per_arr[5];pf.july=per_arr[6];pf.august=per_arr[7];pf.september=per_arr[8];pf.october=per_arr[9];pf.november=per_arr[10];pf.december=per_arr[11];pf.save
      #PropertyFinancialPeriod.create(:source_id => itr.id, :source_type=> itr.class.to_s, :pcb_type=>'var_per', :january=> per_arr[0], :february=>per_arr[1], :march=>per_arr[2], :april=>per_arr[3], :may=>per_arr[4], :june=>per_arr[5], :july=>per_arr[6], :august=>per_arr[7], :september=>per_arr[8], :october=>per_arr[9], :november=>per_arr[10], :december=>per_arr[11])
    end
    
  end  
  
end



