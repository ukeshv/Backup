class CreateFolderMyFiles < ActiveRecord::Migration
  def self.up
    users = User.find(:all, :conditions=>['login is null or login!=?','admin'])
    say_with_time("Create folder my files") do
      users.each do |user|
        portfolio = Portfolio.find_or_create_by_user_id_and_name_and_portfolio_type_id(user.id,'portfolio_created_by_system',2)
        property = RealEstateProperty.find_or_initialize_by_user_id_and_property_name_and_portfolio_id(user.id,'property_created_by_system',portfolio.id)
        property.save(false)
        Folder.find_or_create_by_portfolio_id_and_real_estate_property_id_and_user_id_and_name(portfolio.id,property.id,user.id,'my_files')
      end
    end
  end

  def self.down
  end
end
