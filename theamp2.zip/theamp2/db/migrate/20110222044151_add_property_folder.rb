class AddPropertyFolder < ActiveRecord::Migration
  def self.up
    add_column :shared_folders, :is_property_folder, :boolean, :default=>0
  end

  def self.down
    remove_column :shared_folders, :is_property_folder
  end
end
