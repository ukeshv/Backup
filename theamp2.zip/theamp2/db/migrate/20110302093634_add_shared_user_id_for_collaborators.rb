class AddSharedUserIdForCollaborators < ActiveRecord::Migration
  def self.up
    sql = ActiveRecord::Base.connection();
    a = Event.find_by_sql("SELECT * FROM `events` WHERE `action_type` = 'collaborators' and `shared_user_id` is null and description like '<a%'")
    say_with_time("Adding share user id for collaborators") do
      a.each do |i|
        user_id = User.find(:first, :conditions => ["email = ?",i.description.split('>')[1].gsub(/<.*/,'')], :select=>"id")
        sql.execute "UPDATE events SET shared_user_id=#{user_id.id.to_i} WHERE id = #{i.id}" if !(user_id.nil? || user_id.blank?)
      end
    end
  end

  def self.down
  end
end
