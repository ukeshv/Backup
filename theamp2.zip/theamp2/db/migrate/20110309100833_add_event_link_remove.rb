class AddEventLinkRemove < ActiveRecord::Migration
  def self.up
    sql = ActiveRecord::Base.connection();
    a = Event.find_by_sql("SELECT * FROM `events` WHERE description like '<a%' or description2 like '%<a%'")
    say_with_time("Event link removed") do
      a.each do |i|
        temp_desc1 = !i.description.nil? ? i.description.gsub(/<\/?[^>]*>/, "") : ""
        temp_desc2 = !i.description2.nil? ? i.description2.gsub(/<\/?[^>]*>/, "")  : ""
        sql.execute "UPDATE events SET description='#{temp_desc1}',description2='#{temp_desc2}' WHERE id = #{i.id}"
      end
    end
  end

  def self.down
  end
end