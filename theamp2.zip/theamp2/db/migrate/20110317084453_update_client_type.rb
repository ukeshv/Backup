class UpdateClientType < ActiveRecord::Migration
 def self.up
   users = User.find(:all,:conditions=>["email != ?","admin@theamp.com"])
   swig_users = ["swig2011@gmail.com","cmkumar2k@gmail.com","jegans2020@gmail.com","amplog@gmail.com","adi@theamp.com","jeganraj.siva@sedin.co.in","arrvind.balasubramanian@sedin.co.in","theamp.swig@gmail.com","rftest@railsfactory.org","kishore@railsfactory.org"]
    unless users.blank?
       users.each do |user|
       if swig_users.include?(user.email)
        user.client_type="swig"
        user.save(false)
       else
        user.client_type="wres"
        user.save(false)
       end
     end 
   end
 end

 def self.down
   users = User.find(:all,:conditions=>["email != ?","admin@theamp.com"])
   unless users.blank?
    users.each do |user|
     user.client_type=nil
     user.save(false)
    end 
   end
  end
  
end
