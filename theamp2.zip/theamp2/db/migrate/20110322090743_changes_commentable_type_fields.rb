class ChangesCommentableTypeFields < ActiveRecord::Migration
  def self.up
    change_column(:comments, :commentable_type, :string)
  end

  def self.down
  end
end
