class RenameColumnName < ActiveRecord::Migration
  def self.up
#    rename_column :task_collaborators, :is_completed, :is_request_completed
    add_column :task_collaborators,:is_completion_requested, :boolean , :default => false
  end

  def self.down
     remove_column :task_collaborators,:is_completion_requested
  end
end
