class AddParsingDoneFieldInDocumentTable < ActiveRecord::Migration
  def self.up
    add_column :documents, :parsing_done, :boolean, :default => true
  end

  def self.down
    remove_column :documents, :parsing_done
  end
end
