class CopyTheCreatedAtToTheUpdatedAtInCommentsTable < ActiveRecord::Migration
  def self.up
    ActiveRecord::Base.connection.execute("update comments set updated_at = created_at;")
  end

  def self.down
  end
end
