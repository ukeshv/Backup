class AddVarianceThresholdsValue < ActiveRecord::Migration
  def self.up
    change_column :variance_thresholds, :variance_percentage, :float, :default=>5.0, :null => false
    change_column :variance_thresholds, :variance_amount, :float, :default=>500.0, :null=> false
    change_column :variance_thresholds, :cap_exp_variance, :float, :default=>500.0, :null=> false
  end

  def self.down
    change_column :variance_thresholds, :variance_percentage, :float, :default =>nil
    change_column :variance_thresholds, :variance_amount, :float, :default=>nil
    change_column :variance_thresholds, :cap_exp_variance, :float, :default=>nil
  end
end