class ChangePropertyPhysicalFolderName < ActiveRecord::Migration
  def self.up
    say_with_time("Change property physical folder name to property pictures") do
      real_estate_properties = RealEstateProperty.find(:all, :conditions=>["property_name != ?", 'property_created_by_system'], :select=>'property_name')
      real_estate_properties.each do |real_estate_property|
        parent_folder = Folder.find_by_name_and_parent_id(real_estate_property.property_name, 0)
        folder = Folder.find_by_name_and_parent_id('Property - Physical', parent_folder.id) if !parent_folder.nil?
        folder.update_attributes(:name => 'Property Pictures') if !folder.nil?
      end
    end
  end

  def self.down
    say_with_time("Change property pictures folder name to property physical") do
      real_estate_properties = RealEstateProperty.find(:all, :conditions=>["property_name != ?", 'property_created_by_system'], :select=>'property_name')
      real_estate_properties.each do |real_estate_property|
        parent_folder = Folder.find_by_name_and_parent_id(real_estate_property.property_name, 0)
        folder = Folder.find_by_name_and_parent_id('Property Pictures', parent_folder.id) if !parent_folder.nil?
        folder.update_attributes(:name => 'Property - Physical') if !folder.nil?
      end
    end
  end
end
