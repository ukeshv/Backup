class AddFieldSubjectInTasks < ActiveRecord::Migration
  def self.up
    add_column :tasks, :subject, :string
  end

  def self.down
  end
end
