class ChangeFieldInTaskTypes < ActiveRecord::Migration
  def self.up
    ActiveRecord::Base.connection.execute("update task_types set task_name='General' where task_name='Custom Instruction'");
  end

  def self.down
    ActiveRecord::Base.connection.execute("update task_types set task_name='Custom Instruction' where task_name='General'");
  end
end
