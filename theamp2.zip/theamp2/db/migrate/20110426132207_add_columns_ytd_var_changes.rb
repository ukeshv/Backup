class AddColumnsYtdVarChanges < ActiveRecord::Migration
  def self.up
    #Changes for variance_thresholds table
    add_column :variance_thresholds, :variance_percentage_ytd, :float, :default=>5.0, :null => false
    add_column :variance_thresholds, :variance_amount_ytd, :float, :default=>500.0, :null=> false
    add_column :variance_thresholds, :cap_exp_variance_ytd, :float, :default=>500.0, :null=> false
    add_column :variance_thresholds, :and_or_ytd, :string, :default=>"and", :null=> false 
    change_column :variance_thresholds, :variance_percentage, :float, :default=>10.0, :null => false
    change_column :variance_thresholds, :variance_amount, :float, :default=>250.0, :null=> false
    change_column :variance_thresholds, :cap_exp_variance, :float, :default=>250.0, :null=> false
    
    #Changes for portfolio_types table
    add_column :portfolio_types, :variance_percentage_ytd, :float, :default=>5.0, :null => false
    add_column :portfolio_types, :variance_amount_ytd, :float, :default=>500.0, :null=> false
    add_column :portfolio_types, :cap_exp_variance_ytd, :float, :default=>500.0, :null=> false
    add_column :portfolio_types, :and_or_ytd, :string, :default=>"and", :null=> false 
    
    #Changes for income_cash_flow_explanations table
    add_column :income_cash_flow_explanations, :ytd, :boolean, :default=>false
    add_column :capital_expenditure_explanations, :ytd, :boolean, :default=>false
  end

  def self.down
    #Changes for variance_thresholds table
    remove_column :variance_thresholds, :variance_percentage_ytd
    remove_column :variance_thresholds, :variance_amount_ytd
    remove_column :variance_thresholds, :cap_exp_variance_ytd
    remove_column :variance_thresholds, :and_or_ytd
    change_column :variance_thresholds, :variance_percentage, :float, :default =>nil
    change_column :variance_thresholds, :variance_amount, :float, :default=>nil
    change_column :variance_thresholds, :cap_exp_variance, :float, :default=>nil
    
    #Changes for portfolio_types table
    remove_column :portfolio_types, :variance_percentage_ytd
    remove_column :portfolio_types, :variance_amount_ytd
    remove_column :portfolio_types, :cap_exp_variance_ytd
    remove_column :portfolio_types, :and_or_ytd    
    
    #Changes for income_cash_flow_explanations table
    remove_column :income_cash_flow_explanations, :ytd
    remove_column :capital_expenditure_explanations, :ytd
  end
end