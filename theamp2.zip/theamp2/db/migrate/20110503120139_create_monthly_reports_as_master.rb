class CreateMonthlyReportsAsMaster < ActiveRecord::Migration
  def self.up
    properties = RealEstateProperty.find(:all,:conditions=>["property_name != ?","property_created_by_system"])
    properties.each do |property|
        property_folder  = Folder.find_by_real_estate_property_id_and_parent_id_and_is_master(property.id,0,0)
    		monthly_report_folder = Folder.create(:name =>"Report Docs",:portfolio_id => property.portfolio_id,:real_estate_property_id => property.id,:user_id => property.user_id,:parent_id =>property_folder.id ,:is_master =>1)
   end
  end

  def self.down
  end
end
