# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20110412110915) do

  create_table "actuals", :force => true do |t|
    t.integer  "user_id"
    t.integer  "property_type_id"
    t.text     "potential_gross_revenue"
    t.decimal  "total_potential_gross_revenue",           :precision => 25, :scale => 2
    t.text     "expense_reimbursement_revenue"
    t.decimal  "total_reimbursement_revenue",             :precision => 25, :scale => 2
    t.text     "revenue_adjustments"
    t.decimal  "total_revenue_adjustments",               :precision => 25, :scale => 2
    t.decimal  "effective_gross_revenue",                 :precision => 25, :scale => 2
    t.text     "operating_expenses"
    t.decimal  "total_operating_expenses",                :precision => 25, :scale => 2
    t.decimal  "net_operating_income",                    :precision => 25, :scale => 2
    t.text     "debt_service"
    t.decimal  "total_debt_service",                      :precision => 25, :scale => 2
    t.text     "leasing_and_capital_costs"
    t.decimal  "total_leasing_and_capital_costs",         :precision => 25, :scale => 2
    t.decimal  "cash_flow_after_debt_service_before_tax", :precision => 25, :scale => 2
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "cash_flow_detail_id"
    t.integer  "resource_id"
    t.string   "resource_type"
    t.date     "month_and_year"
  end

  create_table "addresses", :force => true do |t|
    t.string   "txt"
    t.string   "city"
    t.string   "province"
    t.string   "zip"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "advanced_due_dates", :force => true do |t|
    t.integer  "template_id"
    t.date     "start_date"
    t.date     "end_date"
    t.string   "year",               :limit => 4
    t.boolean  "budgets_or_actuals"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "interval"
    t.integer  "repeat_period"
    t.integer  "resource_id"
    t.string   "resource_type"
  end

  create_table "brochures", :force => true do |t|
    t.string   "filename"
    t.string   "content_type"
    t.string   "thumbnail"
    t.string   "attachable_type"
    t.integer  "height"
    t.integer  "width"
    t.integer  "size"
    t.integer  "parent_id"
    t.integer  "attachable_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "budgets", :force => true do |t|
    t.integer  "user_id"
    t.integer  "property_type_id"
    t.text     "potential_gross_revenue"
    t.decimal  "total_potential_gross_revenue",           :precision => 25, :scale => 2
    t.text     "expense_reimbursement_revenue"
    t.decimal  "total_reimbursement_revenue",             :precision => 25, :scale => 2
    t.text     "revenue_adjustments"
    t.decimal  "total_revenue_adjustments",               :precision => 25, :scale => 2
    t.decimal  "effective_gross_revenue",                 :precision => 25, :scale => 2
    t.text     "operating_expenses"
    t.decimal  "total_operating_expenses",                :precision => 25, :scale => 2
    t.decimal  "net_operating_income",                    :precision => 25, :scale => 2
    t.text     "debt_service"
    t.decimal  "total_debt_service",                      :precision => 25, :scale => 2
    t.text     "leasing_and_capital_costs"
    t.decimal  "total_leasing_and_capital_costs",         :precision => 25, :scale => 2
    t.decimal  "cash_flow_after_debt_service_before_tax", :precision => 25, :scale => 2
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "cash_flow_detail_id"
    t.integer  "resource_id"
    t.string   "resource_type"
    t.date     "month_and_year"
  end

  create_table "buyers", :force => true do |t|
    t.integer  "user_id"
    t.integer  "resource_id"
    t.string   "company"
    t.string   "company_representative"
    t.string   "contact_email"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "resource_type",          :limit => 50
  end

  create_table "capital_expenditure_explanations", :force => true do |t|
    t.integer  "property_capital_improvement_id"
    t.text     "explanation"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "user_id"
    t.integer  "month"
    t.integer  "document_id"
  end

  create_table "cash_flow_details", :force => true do |t|
    t.string   "cash_flow_type"
    t.integer  "resource_id"
    t.integer  "advanced_due_date_id"
    t.integer  "document_id"
    t.string   "resource_type"
    t.boolean  "is_archived"
    t.integer  "user_id"
    t.integer  "property_type_id"
    t.datetime "start_date"
    t.datetime "end_date"
    t.text     "potential_gross_revenue"
    t.decimal  "total_potential_gross_revenue",           :precision => 25, :scale => 2
    t.text     "expense_reimbursement_revenue"
    t.decimal  "total_reimbursement_revenue",             :precision => 25, :scale => 2
    t.text     "revenue_adjustments"
    t.decimal  "total_revenue_adjustments",               :precision => 25, :scale => 2
    t.decimal  "effective_gross_revenue",                 :precision => 25, :scale => 2
    t.text     "operating_expenses"
    t.decimal  "total_operating_expenses",                :precision => 25, :scale => 2
    t.decimal  "net_operating_income",                    :precision => 25, :scale => 2
    t.text     "debt_service"
    t.decimal  "total_debt_service",                      :precision => 25, :scale => 2
    t.text     "leasing_and_capital_costs"
    t.decimal  "total_leasing_and_capital_costs",         :precision => 25, :scale => 2
    t.decimal  "cash_flow_after_debt_service_before_tax", :precision => 25, :scale => 2
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "comments", :force => true do |t|
    t.string   "title",            :limit => 50, :default => ""
    t.text     "comment"
    t.datetime "created_at",                                     :null => false
    t.integer  "commentable_id",                 :default => 0,  :null => false
    t.string   "commentable_type",               :default => "", :null => false
    t.integer  "user_id",                        :default => 0,  :null => false
    t.integer  "parent_id"
    t.boolean  "is_reply"
    t.datetime "updated_at"
  end

  add_index "comments", ["user_id"], :name => "file_comments"

  create_table "contacts", :force => true do |t|
    t.string   "name"
    t.string   "email"
    t.string   "phone_number"
    t.string   "company_name"
    t.text     "comment"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "document_names", :force => true do |t|
    t.string   "name",                    :limit => 40
    t.integer  "folder_id"
    t.datetime "due_date"
    t.boolean  "is_master",                             :default => false
    t.integer  "document_id"
    t.integer  "property_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "user_id"
    t.boolean  "is_deleted",                            :default => false
    t.integer  "real_estate_property_id"
  end

  create_table "documents", :force => true do |t|
    t.string   "filename"
    t.string   "content_type"
    t.string   "thumbnail"
    t.integer  "height"
    t.integer  "width"
    t.integer  "size"
    t.integer  "folder_id"
    t.integer  "user_id"
    t.integer  "property_id"
    t.datetime "due_date"
    t.boolean  "is_master",               :default => false
    t.boolean  "is_deleted",              :default => false
    t.integer  "ipaper_id"
    t.string   "ipaper_access_key"
    t.integer  "state_flag"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "is_deselected",           :default => false
    t.integer  "real_estate_property_id"
    t.boolean  "parsing_done",            :default => true
  end

  create_table "event_resources", :force => true do |t|
    t.integer  "event_id"
    t.integer  "resource_id"
    t.string   "resource_type"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "events", :force => true do |t|
    t.integer  "user_id"
    t.integer  "shared_user_id"
    t.string   "action_type"
    t.text     "description"
    t.string   "performer"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "description2"
  end

  create_table "excel_templates", :force => true do |t|
    t.string   "filename"
    t.string   "content_type"
    t.string   "thumbnail"
    t.integer  "height"
    t.integer  "width"
    t.integer  "size"
    t.integer  "parent_id"
    t.integer  "portfolio_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "flyers", :force => true do |t|
    t.string   "filename"
    t.string   "content_type"
    t.string   "thumbnail"
    t.string   "attachable_type"
    t.integer  "height"
    t.integer  "width"
    t.integer  "size"
    t.integer  "parent_id"
    t.integer  "attachable_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "ipaper_id"
    t.string   "ipaper_access_key"
  end

  create_table "folders", :force => true do |t|
    t.string   "name"
    t.integer  "parent_id",               :default => 0
    t.integer  "portfolio_id"
    t.integer  "user_id"
    t.integer  "property_id"
    t.boolean  "is_master",               :default => false
    t.boolean  "is_deleted",              :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "is_deselected",           :default => false
    t.integer  "real_estate_property_id"
  end

  create_table "income_and_cash_flow_details", :force => true do |t|
    t.string   "title"
    t.integer  "parent_id"
    t.integer  "resource_id"
    t.string   "resource_type"
    t.integer  "user_id"
    t.integer  "year"
    t.datetime "template_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "income_cash_flow_explanations", :force => true do |t|
    t.integer  "income_and_cash_flow_detail_id"
    t.text     "explanation"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "user_id"
    t.integer  "month"
    t.integer  "document_id"
  end

  create_table "leases_explanations", :force => true do |t|
    t.integer  "real_estate_property_id"
    t.text     "explanation"
    t.integer  "month"
    t.integer  "year"
    t.string   "occupancy_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "user_id"
  end

  create_table "master_filenames", :force => true do |t|
    t.string   "name",              :limit => 40
    t.integer  "master_folder_id"
    t.integer  "due_days"
    t.integer  "portfolio_type_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "master_files", :force => true do |t|
    t.string   "filename"
    t.string   "content_type"
    t.string   "thumbnail"
    t.integer  "height"
    t.integer  "width"
    t.integer  "size"
    t.integer  "master_folder_id"
    t.integer  "due_days"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "master_folders", :force => true do |t|
    t.string   "name",              :limit => 40
    t.integer  "parent_id"
    t.integer  "portfolio_type_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "passwords", :force => true do |t|
    t.integer  "user_id"
    t.string   "reset_code"
    t.datetime "expiration_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "portfolio_images", :force => true do |t|
    t.string   "filename"
    t.string   "content_type"
    t.string   "thumbnail"
    t.string   "attachable_type"
    t.integer  "height"
    t.integer  "width"
    t.integer  "size"
    t.integer  "parent_id"
    t.integer  "attachable_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "portfolio_logs", :force => true do |t|
    t.integer  "user_id"
    t.string   "action_type"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "portfolio_types", :force => true do |t|
    t.string   "name",                :limit => 40
    t.datetime "created_at"
    t.datetime "updated_at"
    t.float    "variance_percentage"
    t.float    "variance_amount"
    t.float    "cap_exp_variance"
    t.string   "and_or",                            :default => "and"
  end

  create_table "portfolios", :force => true do |t|
    t.string   "name"
    t.integer  "portfolio_type_id"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "proof_documents", :force => true do |t|
    t.string   "filename"
    t.string   "content_type"
    t.string   "thumbnail"
    t.integer  "user_id"
    t.integer  "resource_id"
    t.integer  "height"
    t.integer  "width"
    t.integer  "size"
    t.integer  "folder_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "resource_type", :limit => 50
  end

  create_table "properties", :force => true do |t|
    t.integer  "portfolio_id"
    t.string   "note_id"
    t.decimal  "original_note_amount",     :precision => 26, :scale => 2, :default => 0.0
    t.decimal  "current_outstanding",      :precision => 26, :scale => 2, :default => 0.0
    t.decimal  "late_payments_amount_due", :precision => 26, :scale => 2, :default => 0.0
    t.float    "current_interest_rate",                                   :default => 0.0
    t.date     "first_payment_date"
    t.date     "last_payment_date"
    t.date     "maturity_date"
    t.text     "comments"
    t.text     "error_message"
    t.boolean  "is_valid"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "state_id"
    t.integer  "user_id"
    t.decimal  "sale_price",               :precision => 26, :scale => 2, :default => 0.0
    t.decimal  "cap_rate",                 :precision => 26, :scale => 2, :default => 0.0
    t.decimal  "annualized_noi",           :precision => 26, :scale => 2, :default => 0.0
    t.boolean  "is_granted",                                              :default => false
    t.float    "occupancy"
    t.string   "permalink"
  end

  create_table "property_aged_receivables", :force => true do |t|
    t.integer  "property_suite_id"
    t.string   "tenant"
    t.float    "paid_amount"
    t.float    "over_30days"
    t.float    "over_60days"
    t.float    "over_90days"
    t.float    "over_120days"
    t.text     "explanation"
    t.integer  "month"
    t.integer  "year"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_borrower_details", :force => true do |t|
    t.integer  "property_id"
    t.string   "company_name"
    t.string   "contact_person"
    t.string   "city"
    t.string   "state"
    t.integer  "zip"
    t.integer  "phone_no"
    t.string   "email_address"
    t.string   "address"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_capital_improvements", :force => true do |t|
    t.integer  "year"
    t.integer  "month"
    t.string   "tenant_name"
    t.integer  "property_suite_id"
    t.integer  "real_estate_property_id"
    t.float    "annual_budget"
    t.string   "project_status"
    t.string   "category"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_cash_flow_forecast_explanations", :force => true do |t|
    t.integer  "property_cash_flow_forecast_id"
    t.string   "explanation"
    t.integer  "user_id"
    t.integer  "month"
    t.integer  "document_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_cash_flow_forecasts", :force => true do |t|
    t.string   "title"
    t.integer  "parent_id"
    t.integer  "resource_id"
    t.string   "resource_type"
    t.integer  "user_id"
    t.integer  "year"
    t.datetime "template_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_collateral_details", :force => true do |t|
    t.integer  "property_id"
    t.integer  "property_size"
    t.integer  "gross_land_area"
    t.integer  "gross_rentable_area"
    t.integer  "no_of_units"
    t.integer  "year_built"
    t.integer  "property_type_id"
    t.string   "property_name"
    t.string   "city"
    t.string   "state"
    t.string   "zip"
    t.text     "property_description"
    t.text     "address"
    t.decimal  "purchase_price",       :precision => 26, :scale => 2, :default => 0.0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_debt_summaries", :force => true do |t|
    t.integer  "real_estate_property_id"
    t.string   "category"
    t.text     "description"
    t.integer  "month"
    t.integer  "year"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_deliquency_details", :force => true do |t|
    t.integer  "property_id"
    t.integer  "delinquency_history_30days"
    t.integer  "delinquency_history_60days"
    t.integer  "delinquency_history_90days"
    t.string   "bankruptcy_status"
    t.string   "foreclosure_status"
    t.date     "bankruptcy_start_date"
    t.date     "foreclosure_filling_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_details_note_informations", :force => true do |t|
    t.integer  "property_id"
    t.integer  "amortization_term"
    t.integer  "interest_only_period"
    t.integer  "rate_reset_frequency"
    t.string   "amortization"
    t.string   "baloon_flag"
    t.float    "minimum_rate",         :default => 0.0
    t.float    "maximum_rate",         :default => 0.0
    t.string   "interest_rate_index"
    t.string   "interest_rate_margin"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_financial_periods", :force => true do |t|
    t.integer  "source_id"
    t.string   "source_type"
    t.integer  "year"
    t.string   "pcb_type"
    t.float    "january"
    t.float    "february"
    t.float    "march"
    t.float    "april"
    t.float    "may"
    t.float    "june"
    t.float    "july"
    t.float    "august"
    t.float    "september"
    t.float    "october"
    t.float    "november"
    t.float    "december"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.float    "dollar_per_sqft", :default => 0.0
    t.float    "dollar_per_unit", :default => 0.0
  end

  create_table "property_leases", :force => true do |t|
    t.integer  "property_suite_id"
    t.string   "tenant"
    t.date     "start_date"
    t.date     "end_date"
    t.date     "date_executed"
    t.date     "last_payment_date"
    t.float    "base_rent"
    t.float    "effective_rate"
    t.float    "tenant_improvements"
    t.float    "leasing_commisions"
    t.string   "comments"
    t.string   "occupancy_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "month"
    t.integer  "year"
    t.date     "move_in"
    t.float    "other_deposits",      :default => 0.0
    t.boolean  "made_ready",          :default => true
    t.float    "amt_per_sqft",        :default => 0.0
    t.float    "actual_amt_per_sqft", :default => 0.0
  end

  create_table "property_logs", :force => true do |t|
    t.string   "action_type"
    t.integer  "user_id"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_management_systems", :force => true do |t|
    t.string   "name"
    t.string   "short_code"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_occupancy_summaries", :force => true do |t|
    t.integer  "total_building_rentable_s",          :limit => 8
    t.integer  "last_year_sf_occupied_actual",       :limit => 8
    t.integer  "last_year_sf_occupied_budget",       :limit => 8
    t.integer  "current_year_sf_occupied_actual",    :limit => 8
    t.integer  "current_year_sf_occupied_budget",    :limit => 8
    t.integer  "current_year_sf_vacant_actual",      :limit => 8
    t.integer  "current_year_sf_vacant_budget",      :limit => 8
    t.integer  "new_leases_actual",                  :limit => 8
    t.integer  "new_leases_budget",                  :limit => 8
    t.integer  "renewals_actual",                    :limit => 8
    t.integer  "renewals_budget",                    :limit => 8
    t.integer  "expirations_actual",                 :limit => 8
    t.integer  "expirations_budget",                 :limit => 8
    t.integer  "year"
    t.integer  "month"
    t.integer  "real_estate_property_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "currently_vacant_leases_number",                  :default => 0
    t.float    "currently_vacant_leases_percentage",              :default => 0.0
    t.integer  "vacant_leased_number",                            :default => 0
    t.float    "vacant_leased_percentage",                        :default => 0.0
    t.integer  "occupied_on_notice_number",                       :default => 0
    t.float    "occupied_on_notice_percentage",                   :default => 0.0
    t.integer  "occupied_preleased_number",                       :default => 0
    t.float    "occupied_preleased_percentage",                   :default => 0.0
    t.integer  "net_exposure_to_vacancy_number",                  :default => 0
    t.float    "net_exposure_to_vacancy_percentage",              :default => 0.0
    t.integer  "current_year_units_occupied_actual",              :default => 0
    t.integer  "current_year_units_vacant_actual",                :default => 0
    t.integer  "current_year_units_total_actual",                 :default => 0
  end

  create_table "property_rent_rolls", :force => true do |t|
    t.integer  "property_suite_id"
    t.datetime "start_date"
    t.datetime "end_date"
    t.string   "tenant"
    t.float    "monthly_base_rent"
    t.float    "annual_rate_per_sf"
    t.float    "monthly_cost_recovery"
    t.float    "expense_stop"
    t.float    "monthly_other_income"
    t.float    "security_deposit"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_state_logs", :force => true do |t|
    t.integer  "user_id"
    t.integer  "action_done_by"
    t.integer  "property_id"
    t.integer  "state_id"
    t.boolean  "show_hide_flag", :default => true, :null => false
    t.text     "comments"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_suites", :force => true do |t|
    t.integer  "real_estate_property_id"
    t.string   "suite_number"
    t.integer  "rented_area"
    t.string   "space_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "floor_plan",              :limit => 20
  end

  create_table "property_types", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "property_variance_and_explanations", :force => true do |t|
    t.integer  "property_cash_flow_detail_id"
    t.text     "explanation"
    t.integer  "year"
    t.integer  "month"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "real_estate_loan_details", :force => true do |t|
    t.integer  "portfolio_id"
    t.integer  "real_estate_property_id"
    t.string   "property_name"
    t.decimal  "original_note_amount",     :precision => 26, :scale => 2, :default => 0.0
    t.decimal  "current_outstanding",      :precision => 26, :scale => 2, :default => 0.0
    t.decimal  "late_payments_amount_due", :precision => 26, :scale => 2, :default => 0.0
    t.float    "current_interest_rate",                                   :default => 0.0
    t.date     "first_payment_date"
    t.date     "last_payment_date"
    t.date     "maturity_date"
    t.text     "comments"
    t.text     "error_message"
    t.string   "loan_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "sheet"
  end

  create_table "real_estate_properties", :force => true do |t|
    t.integer  "portfolio_id"
    t.integer  "property_size"
    t.integer  "gross_land_area"
    t.integer  "gross_rentable_area"
    t.integer  "no_of_units"
    t.integer  "year_built"
    t.integer  "property_type_id"
    t.string   "property_name"
    t.text     "property_description"
    t.decimal  "purchase_price",                :precision => 26, :scale => 2, :default => 0.0
    t.integer  "state_id"
    t.integer  "user_id"
    t.boolean  "is_granted",                                                   :default => false
    t.boolean  "is_deselected",                                                :default => false
    t.boolean  "is_valid",                                                     :default => false
    t.decimal  "sale_price",                    :precision => 26, :scale => 2, :default => 0.0
    t.decimal  "cap_rate",                      :precision => 26, :scale => 2, :default => 0.0
    t.decimal  "annualized_noi",                :precision => 26, :scale => 2, :default => 0.0
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "error_message"
    t.float    "occupancy"
    t.string   "permalink"
    t.integer  "address_id"
    t.float    "variance_percentage"
    t.float    "variance_amount"
    t.integer  "property_management_system_id"
    t.datetime "last_updated"
  end

  create_table "real_estate_property_state_logs", :force => true do |t|
    t.integer  "user_id"
    t.integer  "action_done_by"
    t.integer  "real_estate_property_id"
    t.integer  "state_id"
    t.boolean  "show_hide_flag",          :default => true, :null => false
    t.text     "comments"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "rent_details", :force => true do |t|
    t.integer  "rent_roll_id"
    t.string   "tenant_name"
    t.string   "suite"
    t.float    "rented_area",                                               :default => 0.0
    t.decimal  "monthly_rent",               :precision => 20, :scale => 2, :default => 0.0
    t.decimal  "deposit_paid",               :precision => 20, :scale => 2, :default => 0.0
    t.decimal  "abatements_made",            :precision => 20, :scale => 2, :default => 0.0
    t.decimal  "improvement_expenses_spent", :precision => 20, :scale => 2, :default => 0.0
    t.decimal  "commission_expenses_spent",  :precision => 20, :scale => 2, :default => 0.0
    t.decimal  "capital_improvements",       :precision => 20, :scale => 2, :default => 0.0
    t.decimal  "aged_receivables",           :precision => 20, :scale => 2, :default => 0.0
    t.decimal  "leasing_commisions",         :precision => 20, :scale => 2, :default => 0.0
    t.date     "lease_start_date"
    t.date     "lease_end_date"
    t.date     "last_payment_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "rent_rolls", :force => true do |t|
    t.integer  "user_id"
    t.integer  "property_type_id"
    t.string   "year"
    t.date     "start_date"
    t.date     "end_date"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "resource_id"
    t.string   "resource_type"
    t.decimal  "total_occupied",   :precision => 25, :scale => 2
    t.decimal  "total_available",  :precision => 25, :scale => 2
  end

  create_table "repeat_tasks", :force => true do |t|
    t.integer  "document_id"
    t.string   "period"
    t.integer  "repeat_count"
    t.date     "repeat_start_date"
    t.integer  "task_scheduling_days", :default => 10
    t.integer  "task_created_count",   :default => 0
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "folder_id"
  end

  create_table "roles", :force => true do |t|
    t.string "name"
  end

  create_table "roles_users", :id => false, :force => true do |t|
    t.integer "role_id"
    t.integer "user_id"
  end

  add_index "roles_users", ["role_id"], :name => "index_roles_users_on_role_id"
  add_index "roles_users", ["user_id"], :name => "index_roles_users_on_user_id"

  create_table "settings", :force => true do |t|
    t.string   "name"
    t.text     "value"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "share_document_names", :force => true do |t|
    t.integer  "user_id"
    t.integer  "sharer_id"
    t.integer  "folder_id"
    t.integer  "document_name_id"
    t.integer  "property_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "real_estate_property_id"
    t.text     "comments"
  end

  create_table "shared_documents", :force => true do |t|
    t.integer  "user_id"
    t.integer  "sharer_id"
    t.integer  "folder_id"
    t.integer  "document_id"
    t.integer  "property_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "real_estate_property_id"
    t.text     "comments"
  end

  create_table "shared_folders", :force => true do |t|
    t.integer  "user_id"
    t.integer  "sharer_id"
    t.integer  "folder_id"
    t.integer  "property_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "real_estate_property_id"
    t.text     "comments"
    t.boolean  "is_property_folder",      :default => false
  end

  create_table "simple_captcha_data", :force => true do |t|
    t.string   "key",        :limit => 40
    t.string   "value",      :limit => 6
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "states", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "task_collaborators", :force => true do |t|
    t.integer  "task_id"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "is_completed"
    t.integer  "sharer_id"
    t.boolean  "is_completion_requested", :default => false
  end

  create_table "task_documents", :force => true do |t|
    t.integer  "task_id"
    t.integer  "document_id"
    t.integer  "primary_document_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "user_id"
  end

  create_table "task_files", :force => true do |t|
    t.string   "filename"
    t.string   "content_type"
    t.string   "thumbnail"
    t.integer  "height"
    t.integer  "width"
    t.integer  "size"
    t.integer  "task_id"
    t.integer  "user_id"
    t.integer  "real_estate_property_id"
    t.integer  "document_id"
    t.boolean  "is_deleted"
    t.integer  "ipaper_id"
    t.string   "ipaper_access_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "doer_file",               :default => false
  end

  create_table "task_types", :force => true do |t|
    t.string   "task_name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tasks", :force => true do |t|
    t.integer  "task_type_id"
    t.integer  "user_id"
    t.integer  "document_id"
    t.boolean  "is_completed"
    t.date     "due_by"
    t.integer  "real_estate_property_id"
    t.text     "instruction"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "repeat_task_id"
    t.integer  "folder_id"
    t.boolean  "temp_task",               :default => false
    t.string   "task_name",               :default => ""
    t.string   "subject"
  end

  create_table "user_profile_details", :force => true do |t|
    t.string   "title"
    t.string   "business_name"
    t.string   "website"
    t.string   "city"
    t.string   "state"
    t.string   "zipcode",       :limit => 20
    t.text     "interest"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.string   "login",                     :limit => 40
    t.string   "name",                      :limit => 100, :default => ""
    t.string   "email",                     :limit => 100
    t.string   "crypted_password",          :limit => 40
    t.string   "salt",                      :limit => 40
    t.string   "company_name",              :limit => 40
    t.string   "phone_number",              :limit => 15
    t.text     "address"
    t.text     "comment"
    t.string   "department",                :limit => 40
    t.string   "designation",               :limit => 40
    t.datetime "last_loggedin"
    t.string   "state",                                    :default => "passive"
    t.string   "remember_token",            :limit => 40
    t.datetime "remember_token_expires_at"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "password_code",             :limit => 100
    t.boolean  "approval_status"
    t.string   "client_type"
  end

  add_index "users", ["login"], :name => "index_users_on_login", :unique => true

  create_table "variance_thresholds", :force => true do |t|
    t.integer  "real_estate_property_id"
    t.integer  "document_id"
    t.float    "variance_percentage",     :default => 5.0,   :null => false
    t.float    "variance_amount",         :default => 500.0, :null => false
    t.float    "cap_exp_variance",        :default => 500.0, :null => false
    t.string   "and_or",                  :default => "and"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

end
