# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#   
#   cities = City.create([{ :name => 'Chicago' }, { :name => 'Copenhagen' }])
#   Major.create(:name => 'Daley', :city => cities.first)

	admin_role =  Role.find_or_create_by_name('Admin')
	Role.find_or_create_by_name('Asset Manager')
	Role.find_or_create_by_name('Shared User')
	
	a = User.find_by_login('admin')
	if a.nil?
		# Create default admin user
		user = User.create do |u|
			u.login = 'admin'
			u.name = 'Admin'
			u.password = u.password_confirmation = 'chester'
			u.email = APP_CONFIG[:admin_email]
			u.company_name="AMP"
		end

		# Activate user
		user.register!

		# Add admin role to admin user
		user.roles << admin_role
	end

	p1 = PropertyType.find_or_create_by_name('Multifamily')
	p1.update_attributes(:description =>'Properties for residential use by more than one family unit, or aggregations of single family properties, excluding properties specifically designed for senior or assisted living.')
	
	p2 = PropertyType.find_or_create_by_name('Office') 
	p2.update_attributes(:description =>'Property used primarily for support services such as administration, accounting, marketing, information processing and dissemination, consulting, human resources management, financial and insurance services, educational and medical services, and other professional services')
	
	p3 = PropertyType.find_or_create_by_name('Industrial') 
	p3.update_attributes(:description =>'Property used primarily for research, development, production, storage or distribution of goods')
	
	p4 = PropertyType.find_or_create_by_name('Retail')
	p4.update_attributes(:description =>'Property used primarily for the sale of goods and services to consumers')
	
	p5 = PropertyType.find_or_create_by_name('Shopping Center')
	p5.update_attributes(:description =>'Property used primarily for the sale of goods and services to consumers')
	
	p6 = PropertyType.find_or_create_by_name('Land') 
	p6.update_attributes(:description =>'Property without structural improvements, or with improvements which are intended to be removed, or are of insignificant value')
	
	p7 = PropertyType.find_or_create_by_name('Agricultural')
	p7.update_attributes(:description =>'Property without structural improvements, or with improvements which are intended to be removed, or are of insignificant value')
	
	p8 = PropertyType.find_or_create_by_name('Hotel and Motel') 
	p8.update_attributes(:description =>'Property designed primarily to serve temporary or short-term residential needs')
	
	p9 = PropertyType.find_or_create_by_name('Senior Housing')
	p9.update_attributes(:description =>'Properties for residential use by more than one family unit, with specially designed features, facilities and/or amenities to facilitate unusual care requirements of the residents')
	
	p10 = PropertyType.find_or_create_by_name('Health Care')
	p10.update_attributes(:description =>'Properties for residential use by more than one family unit, with specially designed features, facilities and/or amenities to facilitate unusual care requirements of the residents')
	
	p11 = PropertyType.find_or_create_by_name('Sport and Entertainment')
	p11.update_attributes(:description =>'Property for which there are limited uses due to configuration, special nature of improvements, zoning limitations or other criteria, not elsewhere classified')
	
	p12 = PropertyType.find_or_create_by_name('Special Purpose')
	p12.update_attributes(:description =>'Property for which there are limited uses due to configuration, special nature of improvements, zoning limitations or other criteria, not elsewhere classified')
	
	p13 = PropertyType.find_or_create_by_name('Residential Income')
	p13.update_attributes(:description =>'Property for which there are limited uses due to configuration, special nature of improvements, zoning limitations or other criteria, not elsewhere classified')	
	
	p14 = PropertyType.find_or_create_by_name('Singlefamily') 
	p14.update_attributes(:description =>'Single Family')
	
	portfolio_type1 = PortfolioType.find_or_create_by_name('Notes')
	portfolio_type2 = PortfolioType.find_or_create_by_name('Real Estate')
	
	State.find_or_create_by_name('Ready for Sale')
	State.find_or_create_by_name('Listed for Sale')
	State.find_or_create_by_name('Saved')
	State.find_or_create_by_name('Due Diligence Info Requested')
	State.find_or_create_by_name('Due Diligence Confirmed')
	State.find_or_create_by_name('Request Denied')

  s1 = Setting.find_or_create_by_name('Page count')
  s1.update_attributes(:name => 'Page count',:value => 10) 
	s1 = Setting.find_or_create_by_name('analytics_code')
  #s1.update_attributes(:name => 'analytics_code',:value =>"")
	s1 = Setting.find_or_create_by_name('google_key')
  #s1.update_attributes(:name => 'google_key',:value =>"")
	s1 = Setting.find_or_create_by_name('due_date_reminder')
	s1.update_attributes(:name => 'due_date_reminder',:value =>2)
	s1 = Setting.find_or_create_by_name('user_defined_analytics_code')
	s1.update_attributes(:value=>'UA-22682608-1') if s1.value.nil?
	
	if !portfolio_type1.nil?
		folder1 = MasterFolder.find_or_create_by_name_and_parent_id_and_portfolio_type_id('Business', 0, portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("management contracts", folder1.id,portfolio_type1.id)
		folder2 = MasterFolder.find_or_create_by_name_and_parent_id_and_portfolio_type_id('Income, Cash Flow & Rent Roll', 0, portfolio_type1.id)
			subfolder = MasterFolder.find_or_create_by_name_and_parent_id_and_portfolio_type_id('Templates', folder2.id, portfolio_type1.id)
		folder3 = MasterFolder.find_or_create_by_name_and_parent_id_and_portfolio_type_id('Loan Documents', 0, portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("loan doc", folder3.id,portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("title report", folder3.id,portfolio_type1.id)
		folder4 = MasterFolder.find_or_create_by_name_and_parent_id_and_portfolio_type_id('Property Pictures', 0, portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("building plans", folder4.id,portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("inspection reports", folder4.id,portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("lawsuits", folder4.id,portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("leases", folder4.id,portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("picture 1", folder4.id,portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("picture 2", folder4.id,portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("picture 3", folder4.id,portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("plans", folder4.id,portfolio_type1.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("vendor contracts", folder4.id,portfolio_type1.id)
	end

	if !portfolio_type2.nil?
		folder1 = MasterFolder.find_or_create_by_name_and_parent_id_and_portfolio_type_id('Business', 0, portfolio_type2.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("management contracts", folder1.id,portfolio_type2.id)
		folder2 = MasterFolder.find_or_create_by_name_and_parent_id_and_portfolio_type_id('Income, Cash, Leases', 0, portfolio_type2.id)
					MasterFolder.find_or_create_by_name_and_parent_id_and_portfolio_type_id(Date.today.strftime("%Y"), folder2.id,portfolio_type2.id)
		folder3 = MasterFolder.find_or_create_by_name_and_parent_id_and_portfolio_type_id('Loan Documents', 0, portfolio_type2.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("loan doc", folder3.id,portfolio_type2.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("title report", folder3.id,portfolio_type2.id)
		folder4 = MasterFolder.find_or_create_by_name_and_parent_id_and_portfolio_type_id('Property Pictures', 0, portfolio_type2.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("building plans", folder4.id,portfolio_type2.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("inspection reports", folder4.id,portfolio_type2.id)
			#MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("lawsuits", folder4.id,portfolio_type2.id)
			#~ MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("leases", folder4.id,portfolio_type2.id)
			#~ MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("picture 1", folder4.id,portfolio_type2.id)
			#~ MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("picture 2", folder4.id,portfolio_type2.id)
			#~ MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("picture 3", folder4.id,portfolio_type2.id)
			#~ MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("plans", folder4.id,portfolio_type2.id)
			#~ MasterFilename.find_or_create_by_name_and_master_folder_id_and_portfolio_type_id("vendor contracts", folder4.id,portfolio_type2.id)
		end
		
		PropertyManagementSystem.find_or_create_by_name_and_short_code('MRI','MRI')
		PropertyManagementSystem.find_or_create_by_name_and_short_code('Yardi','Yardi')
		PropertyManagementSystem.find_or_create_by_name_and_short_code('Timberline','Timberline')
		PropertyManagementSystem.find_or_create_by_name_and_short_code('Custom Excel Files','Custom Excel Files')
		PropertyManagementSystem.find_or_create_by_name_and_short_code('others','others')
		PropertyManagementSystem.find_or_create_by_name_and_short_code('none','none')
	 
	 TaskType.find_or_create_by_task_name('Review File')
	 TaskType.find_or_create_by_task_name('Update File')
	 TaskType.find_or_create_by_task_name('Upload File')
	 TaskType.find_or_create_by_task_name('General')
   TaskType.find_or_create_by_task_name('Explain Variances')
   TaskType.find_or_create_by_task_name('Discussion')
 

