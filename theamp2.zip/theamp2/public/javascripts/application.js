// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults

Array.prototype.diff = function(a) {
    return this.filter(function(i) {
        return !(a.indexOf(i) > -1);
    });
};


orig_portfolio_name = '';
orig_filename ='';
truncated_filename ='';
navigation_path = '';
folder_content = '';
all_selected = false // for deselect all if one delected in check all list
comment_curr = '' // for comment
last_edit_cont = '' // edit comment cancal loader
last_edit_comm = '' // to find the last editing comm
last_reply_comm = ''
detect_comment_call = false;
all_cmts = '';
comment_place = '';
AddedFiles = [];
tempFiles ="";
var map = null;
var geocoder = null;
var address = new Array();           
function initialize(school_address) { 
    document.getElementById("streetview").style.display="none";
    document.getElementById("map_canvas").style.display="block";
    document.getElementById('img_map_left').innerHTML=  '<img src="/images/but_avtive_lf.png"  width="9" height="30"/>';
    document.getElementById('img_map_right').innerHTML= '<img src="/images/butactivert.png"  width="7" height="30"/>';
    document.getElementById('active').className = 'detailedactbutmid';
    document.getElementById('img_street_left').innerHTML=   '<img src="/images/detailed_budget_dealf.png"  width="5" height="28"/>';
    document.getElementById('img_street_right').innerHTML=      '<img src="/images/detailed_budget_deactrt.png" width="6" height="28" />';
    document.getElementById('deactive').className = 'detaileddeactbutmid';
   
    document.getElementById('mvlink').className = '';
    document.getElementById('svlink').className = 'bluecolor';
    address = school_address.split(",");
    if (GBrowserIsCompatible()) {
        map = new GMap2(document.getElementById("map_canvas"));
        geocoder = new GClientGeocoder();
        map.addControl(new GLargeMapControl3D());
        map.addControl(new GScaleControl());
        map.addControl(new GMapTypeControl());
        showAddress(school_address,1);
    }
								
}

function blank_email_address() {
    if (document.getElementById('shared_email_ids').value == "") {
        alert('Please enter at least one email address..');
        return false;
    }
    else {
        return true;
    }
}
							 

function color_change_of_date(id,color1)
{
    document.getElementById("start-date-"+id).style.color=color1;
}

function replace_street_view(address)
{
    document.getElementById("streetview").style.display="block";
    document.getElementById("map_canvas").style.display="none";
    document.getElementById('img_map_left').innerHTML= '<img src="/images/detailed_budget_dealf.png"  width="5" height="28"/>';
    document.getElementById('img_map_right').innerHTML= '<img src="/images/detailed_budget_deactrt.png" width="6" height="28" />';
    document.getElementById('active').className = 'detaileddeactbutmid';
    document.getElementById('img_street_left').innerHTML= '<img src="/images/but_avtive_lf.png"  width="9" height="30"/>';
    document.getElementById('img_street_right').innerHTML= '<img src="/images/butactivert.png"  width="7" height="30"/>';
    document.getElementById('deactive').className = 'detailedactbutmid';
    

    document.getElementById('mvlink').className = 'bluecolor';
    document.getElementById('svlink').className = '';
    if (GBrowserIsCompatible()) {
        geocoder = new GClientGeocoder();
        if(geocoder)
        {
            var address =address;
            geocoder.getLatLng(address,function(point)
            {
                m= point.toString();
                var lat = m.split(",")[0].replace("(","");
                var lng =m.split(",")[1].replace(")","");
                var map = new GMap2(document.getElementById("map"));
                map.setCenter(new GLatLng(lat,lng), 15);
                var point = new GLatLng(lat,lng);
                panoramaOptions = {
                    latlng:point
                };
                pano = new GStreetviewPanorama(document.getElementById("streetview"), panoramaOptions);
                GEvent.addListener(pano);
            }
            );
        }
    }
							 
}							 
							 
							 
function createMarker(latlng, number, address) {
    var marker = new GMarker(latlng);
    var latlngbounds = new GLatLngBounds( );
    for ( var i = 0; i < latlng.length; i++ )
    {
        latlngbounds.extend( latlng[ i ] );
    }
					
    map.setCenter(latlng, 13 );
    marker.value = address;
    GEvent.addListener(marker,"click", function() {
    var modified_address = address.split(",")
     var structured_address = jQuery.grep(modified_address, function(n,i){
                            return n != '';
                        });
       new_address  = structured_address.join(",")
       var myHtml = "<b>" + new_address + "</b><br/>";
        map.openInfoWindowHtml(latlng, myHtml);
    });
    //this is the line to find the lat and lng of the address
    //alert(latlng)
    return marker;
}


function showAddress(address,j) {
						
    if (geocoder) {
        geocoder.getLatLng(address,function(point) {
            if (!point) {
            } else {
                map.setCenter(point, 13);
                map.addOverlay(createMarker(point, j, address));
            }
        }
        );
    }
//initHeatmap();
}


function loadGoogle(states)
{
    document.getElementById("streetview").style.display="none";
    document.getElementById("map_canvas").style.display="none";
										
    document.getElementById('mview').className = 'prodetailsmaptabdeactive';
    document.getElementById('sview').className = 'prodetailsmaptabdeactive';
    
    document.getElementById('mvlink').className = 'bluecolor';
    document.getElementById('svlink').className = 'bluecolor';
    var m = null;
    if (GBrowserIsCompatible())
    {
        map = new GMap2(document.getElementById("heat_map"));
        map.addControl(new GLargeMapControl());
        map.addControl(new GMapTypeControl());
        map.setCenter(new GLatLng(37.09024, -95.712891), 4);
        initHeatmap(states);
    }
    else
        alert('Your Internet browser is not compatible with this website.');
}

function trim(val) {
    var ret = val.replace(/^\s+/, '');
    ret = ret.replace(/\s+$/, '');
    return ret;
}

function blank_folder_name() {
    var length_of_folder = trim(document.getElementById('folder_name').value);
    if (document.getElementById('folder_name').value == "" || length_of_folder.length == 0) {
        //alert('Please enter folder name..');
        document.getElementById('emp_folder').style.display="block";
        return false;
    }
    else {
        document.getElementById('emp_folder').style.display="none";
        return true;
    }
}

function blank_file_name() {
    var length_of_folder = trim(document.getElementById('file_name').value);
    var length_of_due_days = trim(document.getElementById('due_days').value);
    if (document.getElementById('file_name').value == "" || length_of_folder.length == 0) {
        //alert('Please enter folder name..');
        document.getElementById('emp_file').style.display="block";
        return false;
    }
    else {
/*if (document.getElementById('due_days').value == "" || length_of_due_days.length == 0 || document.getElementById('due_days').value <  1)
      {
        document.getElementById('emp_file').style.display="none";
        document.getElementById('emp_due_date').style.display="block";
        return false;
      }
      else
      {
        document.getElementById('emp_due_date').style.display="none";
        document.getElementById('emp_file').style.display="none";
        return true;
      }*/
}
}

function show_datahub_image(pid,data_hub,id) {
    new Ajax.Request("/assets/show_asset_docs/?pid="+pid+"&data_hub="+data_hub+"&id="+id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    document.getElementById("over_tab").className = "deactivesubtab"
    document.getElementById("set_tab").className = "activesubtab"
    return false;
}
 
function  show_datahub_image_real_estate(pid,data_hub,id,parent_delete) {
    new Ajax.Request("/properties/show_asset_docs/?pid="+pid+"&data_hub="+data_hub+"&id="+id+"&parent_delete="+parent_delete,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    document.getElementById("over_tab").className = "deactivesubtab";
    document.getElementById("set_tab").className = "executivesubtab";
    document.getElementById("real_estates_properties_set_up").style.width="138px";
    return false;
}

function show_datahub(pid) {
    new Ajax.Request("/assets/show_asset_docs/?pid="+pid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}
  
function show_overview(pid) {
    new Ajax.Request("/portfolios/"+pid+"/show_overview",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    
    document.getElementById("over_tab").className = "activesubtab"
    document.getElementById("set_tab").className = "deactivesubtab"
    return false;
}
//added for real estate overview
function show_real_overview(pid,peri) {
    new Ajax.Request("/real_estates/"+pid+"/show_real_overview?period="+period,{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    document.getElementById("over_tab").className = "executivesubtab"
    document.getElementById("set_tab").className = "deactivesubtab"
    document.getElementById("real_estates_properties_set_up").style.width="110px";
    return false;
}
  
function show_folder_content(folder_id,portfolio_type_id)
{
    new Ajax.Request("/admin/master_folders/show_folder_content/?id="+folder_id+"&portfolio_type_id="+portfolio_type_id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function blank_portfolio_upload1()
{
    if ((jQuery('#portfolio_name').val()).length == 0) {
        jQuery('#emp_file').show();
        return false;
    }
    else{
        return true;
    }
}
    
function blank_file_upload()
{
    //alert("Work in progress")
    if (document.getElementById('attachment_uploaded_data').value == "") {
        alert('Please select a file to upload');
        return false;
    }
    else {
        load_writter();
        return true;
    }
    
    return true;
}

function edit_master_file_due_date(current,parent_id,portfolio_type_id){
    if (orig_filename == ''){
        orig_filename = current.innerHTML;
        crunch = current.id.split('_');
        id = crunch.pop();
        innerValue = jQuery(current).children().html();
        jQuery('#'+current.id).parent().html('<span><input type="text" value="'+orig_filename+'" size=3 selected=true><a style="cursor:pointer;" id="update_'+ id +'" onclick="master_due_date_update(this,'+parent_id+','+portfolio_type_id+');">Set Due Days</a> <span id="loader_info" style="display:none;"><img src="/images/upload_spinner.gif" /></span></span><span onclick="call_master_due_date_restore(this)" style="cursor:pointer" id="'+'c'+current.id+'">&nbsp;cancel</span>');
        jQuery('#c'+current.id).prev('span').children('input').select();
    }
}
	
function master_due_date_update(current,parent_id,portfolio_type_id)
{
    jQuery('#loader_info').show();
    crunch = current.id.split('_');
    var set_name = jQuery(current).prev().attr('value');
    var name = set_name;
    var place = crunch.pop();
    params = $H({
        id: place,
        value:name,
        parent_id:parent_id,
        portfolio_type_id:portfolio_type_id
    }).toQueryString();
    new Ajax.Request('/admin/master_folders/'+ navigation_path +'change_master_due_date', {
        asynchronous: true,
        evalScripts: true,
        parameters:params,
        method: 'POST',
        onComplete: function(res) {
            orig_filename = ''
        }
    });
}
	
function edit_due_date(current,parent_id,portfolio_type_id){
    if (orig_filename == ''){
        orig_filename = current.innerHTML;
        crunch = current.id.split('_');
        id = crunch.pop();
        innerValue = jQuery(current).children().html();
        jQuery('#'+current.id).parent().html('<span><input type="text" value="'+orig_filename+'" size=3 selected=true><a style="cursor:pointer;" id="update_'+ id +'" onclick="due_date_update(this,'+parent_id+','+portfolio_type_id+');">Set Due Days</a> <span id="loader_info" style="display:none;"><img src="/images/upload_spinner.gif" /></span></span><span onclick="call_due_date_restore(this)" style="cursor:pointer" id="'+'c'+current.id+'">&nbsp;cancel</span>');
        jQuery('#c'+current.id).prev('span').children('input').select();
    }
}
	
function due_date_update(current,parent_id,portfolio_type_id)
{
    jQuery('#loader_info').show();
    crunch = current.id.split('_');
    var set_name = jQuery(current).prev().attr('value');
    var name = set_name;
    var place = crunch.pop();
    params = $H({
        id: place,
        value:name,
        parent_id:parent_id,
        portfolio_type_id:portfolio_type_id
    }).toQueryString();
    new Ajax.Request('/admin/master_folders/'+ navigation_path +'change_due_date', {
        asynchronous: true,
        evalScripts: true,
        parameters:params,
        method: 'POST',
        onComplete: function(res) {
            orig_filename = ''
        }
    });
}
	
//<!-- For filename '1' is passed and for file '0' is passed -->
function edit_file_name(current,parent_id,portfolio_type_id, filetype){
    if (orig_filename == ''){
        orig_filename = current.innerHTML;
        crunch = current.id.split('_');
        id = crunch.pop();
        innerValue = jQuery(current).children().html();
        jQuery('#'+current.id).parent().html('<span><input type="text" value="'+orig_filename+'" selected=true><a style="cursor:pointer;" id="t_filename_'+ id +'" onclick="file_name_update(this,'+parent_id+','+portfolio_type_id+','+filetype+');">Rename</a> <span id="loader_info" style="display:none;"><img src="/images/upload_spinner.gif" /></span></span><span onclick="call_file_restore(this, '+filetype+')" style="cursor:pointer" id="'+'c'+current.id+'">&nbsp;cancel</span>');
        jQuery('#c'+current.id).prev('span').children('input').select();
    }
}

function file_name_update(current,parent_id,portfolio_type_id, filetype) {
    jQuery('#loader_info').show();
    crunch = current.id.split('_');
    var set_name = jQuery(current).prev().attr('value');
    var name = set_name;
    var place = crunch.pop();
    params = $H({
        id: place,
        value:name,
        parent_id:parent_id,
        portfolio_type_id:portfolio_type_id
    }).toQueryString();
    if(filetype == 1)
        new Ajax.Request('/admin/master_folders/'+ navigation_path +'change_file_name', {
            asynchronous: true,
            evalScripts: true,
            parameters:params,
            method: 'POST',
            onComplete: function(res) {
                orig_filename = ''
            }
        });
    else
        new Ajax.Request('/admin/master_folders/'+ navigation_path +'change_master_file_name', {
            asynchronous: true,
            evalScripts: true,
            parameters:params,
            method: 'POST',
            onComplete: function(res) {
                orig_filename = ''
            }
        });
}

function edit_folder_name(current,parent_id,portfolio_type_id){
    if (orig_filename == ''){
        orig_filename = current.innerHTML;
        crunch = current.id.split('_');
        id = crunch.pop();
        innerValue = jQuery(current).children().html();
        folder_content = innerValue.split('[').pop();
        innerValue = innerValue.split('[')[0].replace(/^\s\s*/, '').replace(/\s\s*$/, '');
        //orig_filename = innerValue;
        jQuery('#'+current.id).parent().html('<span><input type="text" value="'+innerValue+'" selected=true size="18" style="width: 100px;"><a style="cursor:pointer;" id="update_'+ id +'" onclick="folder_name_update(this,'+parent_id+','+portfolio_type_id+');">Rename</a></span><span onclick="call_folder_restore(this)" style="cursor:pointer" id="'+'c'+current.id+'">&nbsp;cancel</span>');
        jQuery('#c'+current.id).prev('span').children('input').select();
    }
}
	
function folder_name_update(current,parent_id,portfolio_type_id) {
    crunch = current.id.split('_');
    var set_name = jQuery(current).prev().attr('value');
    var name = set_name;
    var place = crunch.pop();
    params = $H({
        id: place,
        value:name,
        parent_id:parent_id,
        portfolio_type_id:portfolio_type_id
    }).toQueryString();
    if(portfolio_type_id == 0)
        new Ajax.Request('/assets/change_folder_name', {
            asynchronous: true,
            evalScripts: true,
            parameters:params,
            method: 'POST',
            onLoading: function(){
                load_writter();
            },
            onComplete: function(res) {
                orig_filename = '';
                load_completer();
            }
        });
    else
        new Ajax.Request('/admin/master_folders/'+ navigation_path +'change_folder_name', {
            asynchronous: true,
            evalScripts: true,
            parameters:params,
            method: 'POST',
            onComplete: function(res) {
                orig_filename = ''
            }
        });
}
	
function call_folder_restore(current){
    crunch = current.id.split('_');
    set_html = orig_filename;
    set_id = 't_foldername_'+crunch.pop();
    jQuery('#'+current.id).parent().html('<span id="'+ set_id +'">'+ set_html +'</span>');
    orig_filename = '';
    folder_content = '';
}
	
function call_file_restore(current, filetype){
    crunch = current.id.split('_');
    set_html = orig_filename;
    if(filetype == 1)
        set_id = 't_filename_'+crunch.pop();
    else
        set_id = 't_file_'+crunch.pop();
    jQuery('#'+current.id).parent().html('<span id="'+ set_id +'">'+ set_html +'</span>');
    orig_filename = '';
    folder_content = '';
}
	
function call_due_date_restore(current){
    crunch = current.id.split('_');
    set_html = orig_filename;
    set_id = 't_due_date_'+crunch.pop();
    jQuery('#'+current.id).parent().html('<span id="'+ set_id +'">'+ set_html +'</span>');
    orig_filename = '';
    folder_content = '';
}

function call_master_due_date_restore(current){
    crunch = current.id.split('_');
    set_html = orig_filename;
    set_id = 't_due_date_file_'+crunch.pop();
    jQuery('#'+current.id).parent().html('<span id="'+ set_id +'">'+ set_html +'</span>');
    orig_filename = '';
    folder_content = '';
}
	
function do_folder_update(place,res,dt,im) {
    if(res == '')
        res = orig_filename;
    else  {
        res_print = orig_filename.split('>');
        res = (typeof(update_for_user) !='undefined') ? res_print[0].gsub(/title.*/,'title="Click here to view files of '+res+'"')+'>'+ res + '</a>' : res_print[0]+'>'+ res+' ['+ folder_content +'</a>'
    }
    folder_content ='';
    abs_parent = jQuery('#update_'+place).parents('div.asset_folderow_label1');
    if (typeof(update_for_user) == 'undefined'){
        abs_parent = jQuery('#update_'+place).parents('div.fileheadtitlefilenamelink');
    }
    //jQuery(abs_parent).html('<span id="t_foldername_'+place +'">'+ res +'</span>'+' <span><img src="/images/'+im+'"></span>'); Owner & Co-owner image display is removed temp.
    jQuery(abs_parent).html('<span id="t_foldername_'+place +'">'+ res +'</span>');
     
}
	
function do_file_update(place,res,filetype) {
    res = res == '' ? orig_filename : res;
    //res_print = orig_filename.split('>');
    //res = res_print[0]+'>'+ res+' ['+ folder_content +'</a>';
    folder_content ='';
    abs_parent = jQuery('#t_filename_'+place).parents('div.fileheadtitlefilenamelink');
    if(filetype == 1){
        jQuery(abs_parent).html('<span id="t_filename_'+place +'">'+ res +'</span>');
    }
    else
        jQuery(abs_parent).html('<span id="t_file_'+place +'">'+ res +'</span>');
    document.getElementById('loader_info').style.display="none";

}
	
function do_date_update(place,res) {
    //res = res == '' ? orig_filename : res;
    //res_print = orig_filename.split('>');
    //res = res_print[0]+'>'+ res+' ['+ folder_content +'</a>';
    folder_content ='';
    abs_parent = jQuery('#update_'+place).parents('div.details-size');
    jQuery(abs_parent).html('<span id="t_due_date_'+place +'">'+ res +'</span>');
    document.getElementById('loader_info').style.display="none";
}
  
function do_master_date_update(place,res) {
    //res = res == '' ? orig_filename : res;
    //res_print = orig_filename.split('>');
    //res = res_print[0]+'>'+ res+' ['+ folder_content +'</a>';
    folder_content ='';
    abs_parent = jQuery('#update_'+place).parents('div.details-size');
    jQuery(abs_parent).html('<span id="t_due_date_file_'+place +'">'+ res +'</span>');
    document.getElementById('loader_info').style.display="none";
}
	
function show_rent_rolls(pid,nid,par) {
    new Ajax.Request("/portfolio/"+pid+"/notes/"+nid+"/rent_rolls",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}
  
function show_performance_review(pid,nid,par) {
    new Ajax.Request("/portfolio/"+pid+"/notes/"+nid+"/performance_review",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}

function show_terms(pid,nid,par) {
    new Ajax.Request("/portfolio/"+pid+"/notes/"+nid+"/term_details/",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}
    
function show_hide_asset_docs1(pid,folder_id,is_show_del,show_missing_file) {
    show_del_var = (is_show_del == 'show_del') ? 'true' : 'false'
    new Ajax.Request("/assets/show_asset_files/?pid="+pid+"&folder_id="+folder_id+"&del_files="+show_del_var+"&show_missing_file="+false,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}
  
function show_property_view(pid,nid,par) {
    new Ajax.Request("/portfolio/"+pid+"/notes/"+nid+"/property_view",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}

function move_to_dispositions(pid,nid,par) {
    new Ajax.Request("/portfolio/"+pid+"/notes/"+nid+"/move_to_dispositions",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}

function confirm_to_dispositions(pid,nid,par) {
    new Ajax.Request("/portfolio/"+pid+"/notes/"+nid+"/confirm_to_dispositions",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
}

/*function show_property_state_id(pid,nid,status) {
    window.location=  window.location.protocol+'//'+window.location.host+"/dispositions/";
}*/

function show_property_with_status(pid,nid,status) {
    window.location=  window.location.protocol+'//'+window.location.host+"/portfolio/"+pid+"/notes/"+nid+"/filter/"+status+"";
}
  
function blank_folder_name(obj) {
    var length_of_folder = trim(document.getElementById(obj).value);
    if (document.getElementById(obj).value == "" || length_of_folder.length == 0) {
        document.getElementById('success_error_msg').innerHTML="<font color='red'>The above textbox can't be blank</font>"
        return false;
    }
    else {
        /*var obj = document.getElementById('fol_button');
        getLabel = function(elem){
            if (elem.id && elem.id=="label") {
                elem.id = "disabledLabel";
            }
        };
        Dom.getElementsBy(getLabel ,'td', obj); */
        //jQuery('#fol_button').attr('disabled',true) This line gives error in chrome.So replaced with above codes
        load_writter();
        document.getElementById('success_error_msg').innerHTML=""
        return true;
    }
}
  
function delete_asset_doc_or_folder(p_id,obj_id,obj,fn,del_type,list,del_files,sps,smf,parent_delete){
    if(obj == 'folder')
    {
        is_del = (fn == 'del') ? 'true' : 'false'
        if(del_type == 'Delete'){
            load_writter();
            new Ajax.Request("/assets/del_or_revert_folder/?folder_id="+obj_id+"&pid="+p_id+"&fn="+is_del+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps,{
                asynchronous:true,
                evalScripts:true,
                insertion:Insertion.Top
            });
        }
        else{
            load_writter();
            new Ajax.Request("/assets/delete_folder/?folder_id="+obj_id+"&pid="+p_id+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&parent_delete="+parent_delete,{
                asynchronous:true,
                evalScripts:true,
                insertion:Insertion.Top
            });
        }
        return false;
    }
    else
    {
        is_del = (fn == 'del') ? 'true' : 'false' 
        if(del_type == 'Delete'){
            load_writter();
            new Ajax.Request("/assets/del_or_revert_doc/?doc_id="+obj_id+"&pid="+p_id+"&fn="+is_del+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&show_missing_file="+smf,{
                asynchronous:true,
                evalScripts:true,
                insertion:Insertion.Top
            });
        }
        else{
            load_writter();
            new Ajax.Request("/assets/delete_doc/?doc_id="+obj_id+"&pid="+p_id+"&fn="+is_del+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&show_missing_file="+smf,{
                asynchronous:true,
                evalScripts:true,
                insertion:Insertion.Top
            });
        }
        return false;
    }
}

function call_datebased_view(pid,nid,sdate,edate){
    new Ajax.Request("/portfolio/"+pid+"/notes/"+nid+"/performance_review/start_date/"+sdate+"/end_date/"+edate+"",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}  

function change_chart_leases_property(start_date,note_id,portfolio_type,period,partial_page)
{
    new Ajax.Request("/performance_review_property/change_chart_leases/?id="+note_id+"&start_date="+start_date+"&portfolio_type="+portfolio_type+"&period="+period+"&partial_page="+partial_page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function change_chart_leases(start_date,note_id,portfolio_type,period,partial_page)
{
    new Ajax.Request("/performance_review/change_chart_leases/?id="+note_id+"&start_date="+start_date+"&portfolio_type="+portfolio_type+"&period="+period+"&partial_page="+partial_page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}
    
function change_chart(start_date,note_id,portfolio_type,period,partial_page)
{
    new Ajax.Request("/performance_review/"+for_time_period_setting+"change_date/?id="+note_id+"&start_date="+start_date+"&portfolio_type="+portfolio_type+"&period="+period+"&partial_page="+partial_page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });    
    return false;
}

function change_chart_interval(start_date,end_date,note_id,portfolio_type,period,partial_page)
{
    new Ajax.Request("/performance_review/"+for_time_period_setting+"change_date/?id="+note_id+"&start_date="+start_date+"&end_date="+end_date+"&portfolio_type="+portfolio_type+"&period="+period+"&partial_page="+partial_page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function change_chart_interval_leases_property(start_date,end_date,note_id,portfolio_type,period,partial_page)
{
    new Ajax.Request("/performance_review_property/change_chart_leases/?id="+note_id+"&start_date="+start_date+"&end_date="+end_date+"&portfolio_type="+portfolio_type+"&period="+period+"&partial_page="+partial_page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function change_chart_interval_leases(start_date,end_date,note_id,portfolio_type,period,partial_page)
{
    new Ajax.Request("/performance_review/change_chart_leases/?id="+note_id+"&start_date="+start_date+"&end_date="+end_date+"&portfolio_type="+portfolio_type+"&period="+period+"&partial_page="+partial_page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function change_chart_property(start_date,note_id,portfolio_type,period)
{
    var partial = par_list[active_sub_call] // dont send the partial pages fron the time line selector
    var dt = start_date.split('-');
    active_sub_month = dt[1]
    if (month_arr[new Date().getMonth()] == parseInt(active_sub_month))
        active_period = 5;
    active_sub_year = dt[0]

    if (last_renderer == 'capital' || last_renderer == 'cash_sub_view') // this is to check the call from capital expenses sub graph or cash_and_receivable sub graph.
        (last_renderer == 'capital') ? capitalSubCalls(capital_sub_call, {}) : cashSubCalls(cash_sub_call,{
            cash_find_id:cash_find_id
        })
    else if(partial == 'cash_and_receivables'){
        performanceReviewCalls(active_sub_call, active_sub_params);
        return false;
    }
    else{
        new Ajax.Request("/performance_review_property/"+for_time_period_setting+"change_date/?id="+selected_item+"&start_date="+start_date+"&portfolio_type="+portfolio_type+"&period="+period+"&partial_page="+partial+"&financial_sub="+financial_sub+"&financial_subid="+financial_subid+"&occupancy_type="+occupancy_type,{
            asynchronous:true,
            evalScripts:true,
            onComplete:function(r){
                //call_individual_graph('graph_waterfall_chart')
                load_completer();
            },
            onLoading:function(request){
                load_writter();
            },
            insertion:Insertion.Top
        });
    }
    return false;
}

function change_chart_interval_property(start_date,end_date,note_id,portfolio_type,period,partial_page)
{
    new Ajax.Request("/performance_review_property/"+for_time_period_setting+"change_date/?id="+note_id+"&start_date="+start_date+"&end_date="+end_date+"&portfolio_type="+portfolio_type+"&period="+period+"&partial_page="+partial_page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

  
function leases_and_occupancy_acq(pid,nid,buyer_id)
{
    new Ajax.Request("/performance_review/leases_and_occupancy/?id="+nid+"&portfolio_id="+pid+"&buyer_id="+buyer_id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function leases_and_occupancy_acq_property(pid,nid,buyer_id)
{
    new Ajax.Request("/performance_review_property/leases_and_occupancy/?id="+nid+"&portfolio_id="+pid+"&buyer_id="+buyer_id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function leases_and_occupancy(pid,nid)
{
    new Ajax.Request("/performance_review/leases_and_occupancy/?id="+nid+"&portfolio_id="+pid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function leases_and_occupancy_property(pid,nid)
{
    new Ajax.Request("/performance_review_property/leases_and_occupancy/?id="+nid+"&portfolio_id="+pid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function performance_overview_acq(pid,nid,buyer_id)
{
    new Ajax.Request("/performance_review/for_notes/?id="+nid+"&portfolio_id="+pid+"&buyer_id="+buyer_id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}
 
function performance_overview_acq_property(pid,nid,buyer_id)
{
    new Ajax.Request("/performance_review_property/for_notes/?id="+nid+"&portfolio_id="+pid+"&buyer_id="+buyer_id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function performance_overview(pid,nid)
{
    new Ajax.Request("/performance_review/for_notes/?id="+nid+"&portfolio_id="+pid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function performance_overview_property(pid,nid)
{
    new Ajax.Request("/performance_review_property/for_notes/?id="+nid+"&portfolio_id="+pid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(r){
            //call_individual_graph('graph_waterfall_chart')
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function move_to_marketplace(nid)
{
    if (confirm("Are you sure you want to move to marketplace?")) {
    
    
        new Ajax.Request("/dispositions/move_to_marketplace/?id="+nid,{
            asynchronous:true,
            evalScripts:true,
            onComplete:function(r){
                load_completer();
            },
            onLoading:function(request){
                load_writter();
            },
            insertion:Insertion.Top
        });
        return false;
    }
}
  
function edit_portfolio_name(current,tit){
    orig_portfolio_name = ''
    if (current != null){
        orig_portfolio_name = current.innerHTML;
        crunch = current.id.split('_');
        id = crunch.pop();
        jQuery('#'+current.id).parent().html('<span><input id="edit_pname_' + id + '" style="width: 100px; border: 1px solid #CCCCCC;" type="text" value="'+tit +'" selected=true><a style="cursor:pointer;" id="update_'+ id +'" onclick="portfolio_name_update(this);">Rename</a> <span id="loader_info" style="display:none;"><img src="/images/upload_spinner.gif" /></span></span><span onclick="portfolio_call_restore(this)" style="cursor:pointer" id="'+'c'+current.id+'"><a>Cancel</a></span>');
        jQuery('#c'+current.id).prev('span').children('input').select();
    }
}
	
function portfolio_call_restore(current){
    crunch = current.id.split('_');
    n = crunch.pop()
    set_html = jQuery('#edit_name_'+n).html();
    set_id = 'portfolio_name_'+n;
    jQuery('#'+current.id).parent().html('<span id="'+ set_id +'">'+ set_html +'</span>');
    jQuery('#pname_err_msg').html('');
    //orig_portfolio_name = '';
}
	
function portfolio_name_update(current) {
    crunch = current.id.split('_');
    var set_name = jQuery(current).prev().attr('value');
    var name = set_name;
    var place = crunch.pop();
    params = $H({
        id: place,
        value:name
    }).toQueryString();
    new Ajax.Request('/portfolios/change_filename', {
        asynchronous: true,
        evalScripts: true,
        parameters:params,
        method: 'POST',
        onComplete: function(res) {
            orig_portfolio_name = ''
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
}

function portfolio_do_update(place,res,fullname) {
    res = res == '' ? orig_portfolio_name : res;
    abs_parent = jQuery('.edit_portfolio_name');
    jQuery(abs_parent).html('<span id="portfolio_name_'+place +'">'+res +'</span>');
    jQuery('#edit_name_'+place).html(res);
    id = "portfolio_" + place
    if(document.getElementById(id) == null)
    {
        //document.getElementById("portfolio_breadcrumb").innerHTML = res
        document.getElementById("edit_name_"+place).innerHTML = res
        document.getElementById("name_portfolio_"+place).innerHTML = res + '&nbsp;&nbsp;›'
        document.getElementById('pname_div_title').title = fullname
    }
    else
    {
        document.getElementById(id).innerHTML = res
        if(document.getElementById('edit_port_name') != null)
        {
            document.getElementById("edit_port_name").innerHTML = res
        }
    }
}
  
function toggle_select(v){
    all_selected = true;
    var check_boxes= document.getElementsByName('asset_docs[]');
    var check_boxes1= document.getElementsByName('asset_folders[]');
    var check_boxes2= document.getElementsByName('asset_docnames[]');
    arr = [ ];
    if((document.getElementById(v).checked) == true)
    {

        for(i=0;i<check_boxes.length;i++){
            check_boxes[i].checked=true;
            document.getElementById('asset_row_doc_'+check_boxes[i].value).style.backgroundColor = "#F4FAFF";
        }
        for(i=0;i<check_boxes1.length;i++){
            check_boxes1[i].checked=true;
            document.getElementById('asset_row_folder_'+check_boxes1[i].value).style.backgroundColor = "#F4FAFF";
        }
        for(i=0;i<check_boxes2.length;i++){
            check_boxes2[i].checked=true;
            document.getElementById('asset_row_docname_'+check_boxes2[i].value).style.backgroundColor = "#F4FAFF";
        }
    }
    else
    {
        for(i=0;i<check_boxes.length;i++){
            check_boxes[i].checked=false;
            document.getElementById('asset_row_doc_'+check_boxes[i].value).style.backgroundColor = "white";
        }
        for(i=0;i<check_boxes1.length;i++){
            check_boxes1[i].checked=false;
            document.getElementById('asset_row_folder_'+check_boxes1[i].value).style.backgroundColor = "white";
        }
        for(i=0;i<check_boxes2.length;i++){
            check_boxes2[i].checked=false;
            document.getElementById('asset_row_docname_'+check_boxes2[i].value).style.backgroundColor = "white";
        }
    }
}
    

function edit_asset_file_name(current){
    if (orig_filename == ''){
        orig_filename = current.title == '' ? current.innerHTML : current.title; //current.innerHTML;
        truncated_filename = current.innerHTML;
        crunch = current.id.split('_');
        id = crunch.pop();
        innerValue = jQuery(current).children().html();
        jQuery('#'+current.id).parent().html('<span><input type="text" value="'+orig_filename+'" selected=true size="16" style="width: 100px;"><a style="cursor:pointer;" id="update_'+ id +'" onclick="file_asset_name_update(this);">Rename</a></span><span onclick="call_asset_file_restore(this)" style="cursor:pointer" id="'+'c'+current.id+'">&nbsp;cancel</span>');
        jQuery('#c'+current.id).prev('span').children('input').select();
    }
}


function edit_asset_file_name_real_estate(current){
    if (orig_filename == ''){
        orig_filename = current.title == '' ? current.innerHTML : current.title; //current.innerHTML;
        truncated_filename = current.innerHTML;
        crunch = current.id.split('_');
        id = crunch.pop();
        innerValue = jQuery(current).children().html();
        jQuery('#'+current.id).parent().html('<span><input type="text" value="'+orig_filename+'" selected=true size="16" style="width: 100px;"><a style="cursor:pointer;" id="update_'+ id +'" onclick="file_asset_name_update_real_estate(this);">Rename</a></span><span onclick="call_asset_file_restore(this)" style="cursor:pointer" id="'+'c'+current.id+'">&nbsp;cancel</span>');
        jQuery('#c'+current.id).prev('span').children('input').select();
    }
}



 
function do_asset_file_update(place,res,full_filename,dt) {
    res = res == '' ? orig_filename : res;
    full_filename = full_filename == '' ? orig_filename : full_filename;
    abs_parent = jQuery('#update_'+place).parents('div.asset_folderow_label1');
    var col =  (orig_filename == ('Cash_Flow_Template.xls' || 'Rent_Roll_Template.xls') ) ? 'green' : '#025B8D'
    //    jQuery(abs_parent).html('<span title="'+full_filename+'" id="t_filename_'+place +'" onclick="make_downloads(\' '+ place +'\')" onmouseout="jQuery(this).css(\'textDecoration\',\'none\');" onmouseover="jQuery(this).css(\'textDecoration\',\'underline\');" style="cursor: pointer;color:'+ col +'">'+res +'</span>'+' <span><img src="/images/'+im+'"></span>');
    jQuery(abs_parent).html('<span title="'+full_filename+'" id="t_filename_'+place +'" onclick="make_downloads(\' '+ place +'\')" onmouseout="jQuery(this).css(\'textDecoration\',\'none\');" onmouseover="jQuery(this).css(\'textDecoration\',\'underline\');" style="cursor: pointer;color:'+ col +'">'+res +'</span>');
    //document.getElementById('loader_info').style.display="none";
    jQuery("#t_documentdate"+place).html("Modified "+dt);
}
	
function call_asset_file_restore(current){
    crunch = current.id.split('_');
    var col =  (orig_filename == ('Cash_Flow_Template.xls' || 'Rent_Roll_Template.xls') ) ? 'green' : '#025B8D'
    set_html = orig_filename;
    var c_id = crunch.pop();
    set_id = 't_filename_'+ c_id;
    jQuery('#'+current.id).parent().html('<span title="'+ set_html +'" onclick="make_downloads(\' '+ c_id +'\')" onmouseout="jQuery(this).css(\'textDecoration\',\'none\');" onmouseover="jQuery(this).css(\'textDecoration\',\'underline\');" style="cursor: pointer;color:'+ col +'" id="'+ set_id +'">'+ truncated_filename +'</span>');
    orig_filename = '';
    folder_content = '';
}

function file_asset_name_update(current,parent_id,portfolio_type_id) {
    load_writter();
    crunch = current.id.split('_');
    var set_name = jQuery(current).prev().attr('value');
    var name = set_name;
    var place = crunch.pop();
    params = $H({
        id: place,
        value:name
    }).toQueryString();
    new Ajax.Request('/assets/change_filename', {
        asynchronous: true,
        evalScripts: true,
        parameters:params,
        method: 'POST',
        onComplete: function(res) {
            orig_filename = '';
            load_completer();
        }
    });
}

function change_rowclass(cur_row,type_id,obj){
    if (all_selected == true){
        jQuery('#upload_file_check_box').attr('checked', false);
        all_selected = false;
    }
    if(obj == 'folder')
    {
        if(document.getElementById('asset_folder_'+cur_row).checked==true)
            document.getElementById(type_id+cur_row).style.backgroundColor = "#F4FAFF";
        else
            document.getElementById(type_id+cur_row).style.backgroundColor = "white";
    }
    else if(obj == 'doc_name')
    {
        if(document.getElementById('asset_docname_'+cur_row).checked==true)
            document.getElementById(type_id+cur_row).style.backgroundColor = "#F4FAFF";
        else
            document.getElementById(type_id+cur_row).style.backgroundColor = "white";
    }
    
    else
    {
        if(document.getElementById('asset_doc_'+cur_row).checked==true)
            document.getElementById(type_id+cur_row).style.backgroundColor = "#F4FAFF";
        else
            document.getElementById(type_id+cur_row).style.backgroundColor = "white";
    }
}

function delete_selected(folders,docs,doc_names,folder_id,pid,del_files){
    var check_boxes= document.getElementsByName(folders);
    var check_boxes1= document.getElementsByName(docs);
    var check_boxes2= document.getElementsByName(doc_names);
    
    arr = [ ];
    for(i=0;i<check_boxes.length;i++){
        if(check_boxes[i].checked==true)
            arr.push(check_boxes[i].value);
    }
    
    arr1 = [ ];
    for(i=0;i<check_boxes1.length;i++){
        if(check_boxes1[i].checked==true)
            arr1.push(check_boxes1[i].value);
    }
    arr2 = [];
    for(i=0;i<check_boxes2.length;i++){
        if(check_boxes2[i].checked==true)
            arr2.push(check_boxes2[i].value);
    }

    if (arr.length > 0 || arr1.length > 0 || arr2.length > 0){
        if(confirm("Are you sure you want to delete?")){
            new Ajax.Request("/assets/delete_folders_docs/?doc_ids="+arr1+"&folder_ids="+arr+"&folder_id="+folder_id+"&pid="+pid+"&del_files="+del_files+"&doc_name_ids="+arr2,{
                asynchronous:true,
                evalScripts:true,
                insertion:Insertion.Top
            });
            return false;
        }
    }
    else{
 
        $('select_one').innerHTML = "<font color='red'>Nothing has been selected</font>"
        $("select_one").show("slow");
        setTimeout(close_error, (1 * 1500) )
        return false;
    }
}

function refresh_page_after_close(pid,fid,hide_del,list)
{
    new Ajax.Request("/assets/update_page_after_close/?pid="+pid+"&data_hub=show_asset_docs&sfid="+fid+"&list="+list,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
}

function refresh_page_after_close_prop(pid,fid,hide_del,list,highlight,sps,from_debt_summary,from_property_details,property_id)
{
    new Ajax.Request("/properties/update_page_after_close/?pid="+pid+"&data_hub=show_asset_docs&sfid="+fid+"&list="+list+"&highlight="+highlight+'&show_past_shared='+sps+'&from_debt_summary='+from_debt_summary+"&from_property_details="+from_property_details+"&property_id="+property_id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            Control.Modal.close();
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
}

function refresh_page_after_close_from_files_and_prop(pid,fid,hide_del,list,highlight)
{
    new Ajax.Request("/properties/update_page_after_close/?pid="+pid+"&data_hub=show_asset_docs&sfid="+fid+"&list="+list+"&highlight="+highlight+"&call_from_prop_files=true",{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            Control.Modal.close();
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
}


function show_missing_files(folder_id,pid,show_missing_files)
{
    new Ajax.Request("/assets/show_missing_files/?folder_id="+folder_id+"&pid="+pid+"&show_missing_file="+show_missing_files,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });
    return false;
}

function delete_filename(del_type,id,portfolio_id,list,show_past_shared,del_files,smf){
    new Ajax.Request("/assets/delete_filename/?id="+id+"&portfolio_id="+portfolio_id+"&list="+list+"&show_past_shared="+show_past_shared+"&del_files="+del_files+"&del_type="+del_type+"&show_missing_file="+smf,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });
    return false;
}
 
    

function delete_doc_or_folder_admin(obj,ptype_id,obj_id){
    if(obj == 'filename')
        if(confirm('Are you sure to delete the filename?'))
            new Ajax.Request("/admin/master_folders/file_delete/?id="+obj_id+"&portfolio_type_id="+ptype_id,{
                asynchronous:true,
                evalScripts:true,
                insertion:Insertion.Top
            });
        else
            return false;
    else if(obj == 'folder')
        if(confirm('Are you sure to delete the folder?'))
            new Ajax.Request("/admin/master_folders/folder_delete/?id="+obj_id+"&portfolio_type_id="+ptype_id,{
                asynchronous:true,
                evalScripts:true,
                insertion:Insertion.Top
            });
        else
            return false;
    else
    if(confirm('Are you sure to delete the file?'))
        new Ajax.Request("/admin/master_folders/master_file_delete/?id="+obj_id+"&portfolio_type_id="+ptype_id,{
            asynchronous:true,
            evalScripts:true,
            insertion:Insertion.Top
        });
    else
        return false;
}


function download_selected(folders,docs,doc_names,folder_id,pid){
    var check_boxes= document.getElementsByName(folders);
    var check_boxes1= document.getElementsByName(docs);
    var check_boxes2= document.getElementsByName(doc_names);
    arr = [ ];
    for(i=0;i<check_boxes.length;i++){
        if(check_boxes[i].checked==true)
            arr.push(check_boxes[i].value);
    }
    arr1 = [ ];
    for(i=0;i<check_boxes1.length;i++){
        if(check_boxes1[i].checked==true)
            arr1.push(check_boxes1[i].value);
    }
    
    arr2 = [ ];
    for(i=0;i<check_boxes2.length;i++){
        if(check_boxes2[i].checked==true)
            arr2.push(check_boxes2[i].value);
    }
    
    if (arr.length > 0 || arr1.length > 0 || arr2.length > 0 ){
        loc = "/assets/download_folders_docs/?doc_ids="+arr1.join(',')+"&folder_ids="+arr.join(',')+"&folder_id="+folder_id+"&pid="+pid+"&doc_name_ids="+arr2.join(',')
        var frm = document.getElementById('download_trigger')
        frm.action = loc;
        frm.submit();
    }
    else{
        $('select_one').innerHTML = "<font color='red'>Nothing has been selected</font>";
        $("select_one").show("slow");
        setTimeout(close_error, (1 * 1500) )
    }
}


function close_error()
{
    $("select_one").hide("slow");
}

function close_error_msg()
{
    document.getElementById("errmsg").value =  " "
}




function show_new_portfolio(id) {
    new Ajax.Request("/portfolios/new/"+id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function show_new_real_portfolio(id) {
    new Ajax.Request("/real_estates/new/"+id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function show_upload(){
    Element.show("upload")
    return true;
}

function check_empty(){
    var att = document.getElementById('excel_template_uploaded_data').value;
    var flag=false;
    if(att.length>0){
        var extn = att.split('.').last();
        extn=extn.toLowerCase();
        if (extn != "xlsx" ) {
            alert('Please upload xlsx format file only.');
            return false;
        }
        else {
            return true;
        }
        flag=true;
    }
    else{
        alert("please select a file to upload")
    }
    return flag;
}

function new_version_check_empty(fileid){
    var att = document.getElementById(fileid).value;
    var flag=false;
    if(att.length>0){
        var extn = att.split('.').last();
        extn=extn.toLowerCase();
        if (extn != "xls" && extn != "xlsx" ) {
            alert('Please upload xls or xlsx format file only.');
            return false;
        }
        else {
            return true;
        }
        flag=true;
    }
    else{
        alert("please select a file to upload")
    }
    return flag;
}

function open_data_docs(pid) {
    new Ajax.Request("/assets/show_asset_docs/?data_hub=asset_data_and_documents&pid="+pid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
            toggle_highlight('asset_docs');
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;    
}


function hide_model_container()
{
    document.getElementById('modal_container').style.display='none';
    document.getElementById('modal_overlay').style.display='none';
}

function toggle_highlight(tabname) {
    if(tabname == 'asset_docs') {
        altname = 'basic_info'
    }
    else {
        altname = 'asset_docs'
    }
    
/*    document.getElementById(tabname).style.backgroundColor = '#133A5C';
    document.getElementById(tabname).style.color = '#fff';
    document.getElementById(altname).style.backgroundColor = '#fff';
    document.getElementById(altname).style.color = '#133A5C';*/
}


function revoke_document(did,mem_id,fid,pid,list,del_files,sps,smf) {
    new Ajax.Request("/assets/unshare/?id="+did+"&mem_id="+mem_id+"&revoke=document"+"&folder_id="+fid+"&portfolio_id="+pid+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&show_missing_file="+smf,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}


function revoke_folder(fid,mem_id,pid,list,del_files,sps,parent_delete) {
    new Ajax.Request("/assets/unshare/?id="+fid+"&mem_id="+mem_id+"&folder_revoke=true"+"&folder_id="+fid+"&portfolio_id="+pid+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&parent_delete="+parent_delete,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function call_datebased_rent_roll(nid,sdate,edate){
    new Ajax.Request("/notes/"+nid+"/rent_rolls/"+sdate+"/end_date/"+edate+"",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}

function make_downloads(id){
    document.location = '/dwn_fl/'+id
}

function show_data_hub_docs(pid,nid,is_show_del) {
    show_del_var = (is_show_del == 'show_del') ? 'true' : 'false'
    new Ajax.Request("/assets/notes_data_hub/?pid="+pid+"&nid="+nid+"&del_files="+show_del_var,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function show_data_hub_docs_real_estate(pid,nid,is_show_del) {
    show_del_var = (is_show_del == 'show_del') ? 'true' : 'false'
    new Ajax.Request("/properties/notes_data_hub/?pid="+pid+"&nid="+nid+"&del_files="+show_del_var,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function show_past_shared(pid,sps) {
    new Ajax.Request("/assets/show_asset_files/?pid="+pid+"&show_past_shared="+sps,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}
  
function show_more_actions()
{
   
    if(document.getElementById("listdrop").style.display == 'none')
    {
        document.getElementById("listdrop").style.display ='block';
    }
    else
    {
        document.getElementById("listdrop").style.display ='none';
    }
    return false;
}

function show_events(folder_id)
{
    new Ajax.Request("/events/view_events_folder/?folder_id="+folder_id,{
        asynchronous:true,
        evalScripts:true,
        method:'get',
        onComplete:function(request){
            load_completer();
            jQuery('#my_files_tasks').hide();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function show_events_for_collab_hub(folder_id,shared_folders,shared_docs,shared_tasks,owned_and_shared_properties)
{
    new Ajax.Request("/events/view_events_folder/?folder_id="+folder_id+"&shared_folders="+shared_folders+"&shared_docs="+shared_docs+"&shared_tasks="+shared_tasks+"&owned_and_shared_properties="+owned_and_shared_properties,{
        asynchronous:true,
        evalScripts:true,
        method:'get',
        onComplete:function(request){
            load_completer();
            jQuery('#my_files_tasks').hide();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    
    return false;
}

function show_shared_items(folder_id, portfolio_id)
{
    new Ajax.Request("/properties/show_asset_docs?asset_id="+folder_id+"&data_hub=asset_data_and_documents&pid="+portfolio_id+"&portfolio_id="+portfolio_id+"&show_past_shared=true", { 
        asynchronous:true, 
        evalScripts:true, 
        onComplete:function(request) {
            load_completer();
        },
        onLoading:function(request) {
            load_writter();
        },
        insertion:Insertion.Top
    }); 
    return false;
}

function change_overview(note_id,page,targ)
{
    enable_tab_with_img(targ) // enable_tab(targ) is replaced with 
    new Ajax.Request("/dispositions/change_view_file/?id="+note_id+"&view_file="+page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function call_filtering(folder_id)
{
    var par= document.getElementById('filter_option').value;
    if (par != ""){
        new Ajax.Request("/events/filter_events/?shared_user_id="+par+"&folder_id="+folder_id,
        {
            asynchronous:true,
            evalScripts:true,
            method:'get',
            onComplete:function(request){
                load_completer();
            },
            onLoading:function(request){
                load_writter();
            },
            insertion:Insertion.Top
        });
    }
}

function call_filtering_for_collab_hub(folder_id,shared_folders,shared_docs,shared_tasks,owned_and_shared_properties)
{
    var par= document.getElementById('filter_option').value;
    if (par != ""){
        new Ajax.Request("/events/filter_events/?shared_user_id="+par+"&folder_id="+folder_id+"&shared_folders="+shared_folders+"&shared_docs="+shared_docs+"&shared_tasks="+shared_tasks+"&owned_and_shared_properties="+owned_and_shared_properties,{
            asynchronous:true,
            evalScripts:true,
            method:'get',
            onComplete:function(request){
                load_completer();
            },
            onLoading:function(request){
                load_writter();
            },
            insertion:Insertion.Top
        });
    }
}


function revoke_filename(did,mem_id,fid,pid,list,del_files,sps,smf) {
    new Ajax.Request("/assets/unshare/?id="+did+"&mem_id="+mem_id+"&revoke_fn=true"+"&folder_id="+fid+"&portfolio_id="+pid+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&show_missing_file="+smf,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}


function revert_filename(fid,pid,fnid,revert,list,del_files){
    new Ajax.Request("/assets/revert_filename/?id="+fnid+"&folder_id="+fid+"&portfolio_id="+pid+"&list="+list+"&del_files="+del_files,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}



function acq_performance_review(nid) {
    new Ajax.Request("/acquisitions/acq_performance_review/"+nid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function acq_note_terms(nid) {
    new Ajax.Request("/acquisitions/note_terms/"+nid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function acq_rent_roll(nid) {
    new Ajax.Request("/acquisitions/acq_rent_roll/"+nid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function acq_property_view(nid) {
    new Ajax.Request("/acquisitions/acq_property_view/"+nid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function deselect(folders,docs,doc_names,folder_id,pid,del_files,select_type){
    var check_boxes= document.getElementsByName(folders);
    var check_boxes1= document.getElementsByName(docs);
    var check_boxes2= document.getElementsByName(doc_names);
    
    arr = [ ];
    for(i=0;i<check_boxes.length;i++){
        if(check_boxes[i].checked==true)
            arr.push(check_boxes[i].value);
    }
    
    arr1 = [ ];
    for(i=0;i<check_boxes1.length;i++){
        if(check_boxes1[i].checked==true)
            arr1.push(check_boxes1[i].value);
    }
    arr2 = [];
    for(i=0;i<check_boxes2.length;i++){
        if(check_boxes2[i].checked==true)
            arr2.push(check_boxes2[i].value);
    }

    if (arr.length > 0 || arr1.length > 0 || arr2.length > 0){        
        new Ajax.Request("/assets/deselect/?doc_ids="+arr1+"&folder_ids="+arr+"&folder_id="+folder_id+"&pid="+pid+"&del_files="+del_files+"&doc_name_ids="+arr2+"&select_type="+select_type,{
            asynchronous:true,
            evalScripts:true,
            insertion:Insertion.Top
        });
        return false;        
    }
    else{
        $('select_one').innerHTML = "<font color='red'>Select File(s) to De-select/Select</font>"
        return false
    }
}


function blank_deny_comment() {
    var length_of_folder = trim(document.getElementById('denial_comment').value);
    if (document.getElementById('denial_comment').value == "" || length_of_folder.length == 0) {
        document.getElementById('emp_comment').style.display="block";
        return false;
    }
    else {
        load_writter();
        document.getElementById('emp_comment').style.display="none";
        return true;
    }
}



function show_datahub_acquisition(id) {
    new Ajax.Request("/acquisitions/confirmed_notes/?id="+id+"&data_hub=true",{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function show_datahub_acquisition_property(id) {
    new Ajax.Request("/property_acquisitions/confirmed_notes/?id="+id+"&data_hub=true",{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

var items = 1;
function add_new_dates(pos){
    arr_name = pos.split('_').shift();
    jQuery('#'+pos).append('<div id="js_date" style="padding:5px 0 ;border-bottom:1px dashed black;"><span style="float: left;color:#73899E;"> Start date&nbsp;:&nbsp;&nbsp;&nbsp;</span><div class="inputcal adv_date_label"><input class="inputtext_for_datepicker date-pick dp-applied" style="border:none;width:94px;font-size:12px;color:black;"  id="start-date_js_'+items+'" name="set_dates[][start]" readonly  value="--not set--" /></div><span style="float: left;color:#73899E;"> End date&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;</span><div class="inputcal adv_date_label"><input class="inputtext_for_datepicker date-pick dp-applied" style="border:none;width:94px;font-size:12px;color:black;"  id="end-date_js'+ items +'" name="set_dates[][end]" readonly  value="--not set--" /></div></div><input type="hidden" name="set_dates[][state]" value="'+ arr_name +'"/><input type="hidden" name="set_dates[][id]" value=""/></div>');
    items++;
    yeild_calender();
}

function yeild_calender(){
    Date.firstDayOfWeek = 0;
    Date.format = 'dd mmm yyyy';
    //do_date_updates = true; // hey , its for enabling ajax update calls for date update.
    jQuery(function()
    {
        jQuery('.date-pick').datePicker()
        jQuery('#start-date').bind(
            'dpClosed',
            function(e, selectedDates)
            {
                var d = selectedDates[0];
                if ( d ) {
                    d = new Date(d);
                //jQuery('#end-date').dpSetStartDate(d.addDays(1).asString());
                }
            }
            );
    });
}
 
  
function show_hide_asset_docs_acquisition(id,folder_id,is_show_del) {
    show_del_var = (is_show_del == 'show_del') ? 'true' : 'false'
    new Ajax.Request("/acquisitions/confirmed_notes/?id="+id+"&folder_id="+folder_id+"&del_files="+show_del_var+"&data_hub=true"+"&list=sublist",{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}



function confirm_sharing(folder_id,id) {
    new Ajax.Request("/dispositions/change_view_file/?id="+id+"&folder_id="+folder_id+"&view_file=request_due_diligence"+"&confirm_sharing=true",{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });
}

function confirm_sharing_property(folder_id, id, req_prop) {
    new Ajax.Request("/property_dispositions/change_view_file/?id="+id+"&folder_id="+folder_id+"&view_file=request_due_diligence"+"&confirm_sharing=true"+"&sharing_prop="+req_prop,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });
}


function show_request_due_diligence(sel_item) {
    change_overview(sel_item,'request_due_diligence');
    return false;
}

function show_request_due_diligence_property(sel_item) {
    id='dsp_mini2'
    change_overview_property_disposition(sel_item,'request_due_diligence',id);
    return false;
}

function submit_note_form()
{
    new Ajax.Request("/assets/show_asset_docs?data_hub=asset_data_and_documents"+"&pid=1"+"&note_add_edit="+true,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });
}

function set_options(interval,place){
    if(interval == 'quarter'){
        jQuery(place+'#month_option').replaceWith(quarter_options);
        secEle= jQuery(place+'#month_option ').get(1);
        jQuery(secEle).replaceWith(quarter_options);
        if (place =='#past_div ')
            jQuery.extend(jQuery(place + '#month_option')[0], cl_past_summary);
        else
            jQuery.extend(jQuery(place + '#month_option')[0], cl_future_summary);
        jQuery(place.split('_')[0]+'_type_option').html('&nbsp;&nbsp;'+interval+'(s)');
    // place == '#past_div ' ? jQuery(place+'#to_options').children().get(0).selectedIndex = match_quarter[today.getMonth()] : jQuery(place+'#from_options').children().get(0).selectedIndex = match_quarter[today.getMonth()]
    }
    else {
        jQuery(place+'#month_option').replaceWith(month_options);
        secEle= jQuery(place+'#month_option ').get(1);
        jQuery(secEle).replaceWith(month_options);
        if (place =='#past_div ')
            jQuery.extend(jQuery(place + '#month_option')[0], cl_past_summary);
        else
            jQuery.extend(jQuery(place + '#month_option')[0], cl_future_summary);
        jQuery(place.split('_')[0]+'_type_option').html('&nbsp;&nbsp;'+interval+'(s)');
    // place == '#past_div ' ? jQuery(place+'#to_options').children().get(0).selectedIndex = today.getMonth() : jQuery(place+'#from_options').children().get(0).selectedIndex = today.getMonth()
    }
}

function write_summary(pos,val){
    var st_month = jQuery(pos+'_div #from_options #month_option :selected').text();
    var st_year =  jQuery(pos+'_div #from_options #year_option :selected').text();
    var type = jQuery(pos+'_type :selected').text();
    var tar_date = new Date();
    tar_date.setDate(1);
    tar_date.setMonth(month_finder[st_month]);
    tar_date.setFullYear(st_year);
    var flag = true
    if (type == 'Month')
        tar_date.setMonth(tar_date.getMonth()+parseInt(val) -1 );
    else if(type == 'Year'){
        tar_date.setFullYear(tar_date.getFullYear()+parseInt(val));
        tar_date.setMonth(tar_date.getMonth() -1 );
    }
    else if(type== 'Quarter')
        tar_date.setMonth(tar_date.getMonth()+(parseInt(val)*3) -1);
    else
        flag = false;
    detail_disp = (pos == '#future') ? 'Budgets' : 'Actuals & Rent Roll'
    flag == true ? jQuery(pos+'_summary').html('Collect '+ detail_disp + ' ' + type + 'ly'+ ' from '+st_month+' '+st_year+' to '+ month_list[tar_date.getMonth()] + ' ' + tar_date.getFullYear()) : jQuery(pos+'_summary').html('Please select the every option')
}

function submit_date_settings(){
    if (jQuery('#future_div #month_option').length){
        var st_month = jQuery('#future_div #from_options #month_option :selected').text();
        var st_year = jQuery('#future_div #from_options #year_option :selected').text();
        // var end_month = jQuery('#future_div #to_options #month_option :selected').text();
        // var end_year = jQuery('#future_div #to_options #year_option :selected').text();
        jQuery('#future_from').val("1_"+st_month + "_" + st_year);
        jQuery('#future_for').value;
    }
    if (jQuery('#past_div #month_option').length){
        st_month = jQuery('#past_div #from_options #month_option :selected').text();
        st_year = jQuery('#past_div #from_options #year_option :selected').text();
        //end_month = jQuery('#past_div #to_options #month_option :selected').text();
        //end_year = jQuery('#past_div #to_options #year_option :selected').text();
        jQuery('#past_from').val("1_"+st_month + "_" + st_year);
        jQuery('#past_for').value;
    }
    load_writter();
    return true;
}

function setup_over() {
    //jQuery('#submit_date').replaceWith('<input type="image" src="/images/btn_finish.gif" onclick="Control.Modal.close();return false;" id="submit_date" alt="save">')
    jQuery('#submit_date').remove();
}
  
function call_err_msg(){
    jQuery('#err_upload').html('file must contain data');
}
  
function blank_file_name_with_valid_days_count() {
    var length_of_folder = trim(document.getElementById('file_name').value);
    var due_days_val = trim(document.getElementById('due_days').value);
    var regexDigit = /[0-9]/;
    if (document.getElementById('file_name').value == "" || length_of_folder.length == 0) {
        document.getElementById('emp_file').style.display="block";
        document.getElementById('emp_due_date').style.display="none";
        return false;
    }
    else if(due_days_val != "" && !regexDigit.test(due_days_val)){
        document.getElementById('emp_file').style.display="none";
        document.getElementById('emp_due_date').style.display="block";
        return false;
    }
    else
    {
        document.getElementById('emp_due_date').style.display="none";
        document.getElementById('emp_file').style.display="none";
        return true;
    }
} 
    
function write_flash(msg_id){
    jQuery('#'+msg_id).css({
        'backgroundColor':'#E5FDD0',
        'fontSize':'13px',
        'color':'green',
        'padding':'4px'
    });
    jQuery('#'+msg_id).show();
    jQuery('#'+msg_id).fadeOut(5000);
}

function enable_tab(targ){
    ids = {
        'dsp_mini1': 'deactivelistitemrow',
        'dsp_mini2':'deactivelistitemrow',
        'dsp_mini3':'deactivelistitemrow'
    }
    ids[targ] = 'activelistitemrow'
    jQuery('#dsp_mini1').attr('className',ids.dsp_mini1)
    jQuery('#dsp_mini2').attr('className',ids.dsp_mini2)
    jQuery('#dsp_mini3').attr('className',ids.dsp_mini3)
}

function enable_tab_with_img(targ){
    ids = {
        'dsp_mini1': 'deactivelistitemrow',
        'dsp_mini2':'deactivelistitemrow',
        'dsp_mini3':'deactivelistitemrow'
    }
    imgs = {
        'dsp_mini1_img': 'images/acquisitions_icon2_deactive.png',
        'dsp_mini2_img':'images/acquisitions_icon3_deactive.png',
        'dsp_mini3_img':'images/acquisitions_icon2_deactive.png'
    }
    ids[targ] = 'activelistitemrow'
    var tmp_img = imgs[targ+'_img'].split('_')
    imgs[targ+'_img'] = tmp_img[0]+'_'+tmp_img[1]+'.png'
    jQuery('#dsp_mini1').attr('className',ids.dsp_mini1)
    jQuery('#dsp_mini2').attr('className',ids.dsp_mini2)
    jQuery('#dsp_mini3').attr('className',ids.dsp_mini3)
    jQuery('#dsp_mini1_img').attr('src',imgs.dsp_mini1_img)
    jQuery('#dsp_mini2_img').attr('src',imgs.dsp_mini2_img)
    jQuery('#dsp_mini3_img').attr('src',imgs.dsp_mini3_img)
}



function customize_startDate(place){
    Date.firstDayOfWeek = 0;
    Date.format = 'dd mmm yyyy';
    jQuery(function()
    {
        jQuery(place).datePicker({
            startDate:'01 jan 2000'
        });
        jQuery(place).bind(
            'dpClosed',
            function(e, selectedDates)
            {
                var d = selectedDates[0];
                if ( d ) {
                    d = new Date(d);
                }
            }
            );
    });
}

function customize_editDate(place){
    Date.firstDayOfWeek = 0;
    Date.format = 'mm/dd/yyyy';
    jQuery(function()
    {
        jQuery(place).datePicker({
            startDate:'jan 01 2000'
        });
        jQuery(place).bind(
            'dpClosed',
            function(e, selectedDates)
            {
                var d = selectedDates[0];
                if ( d ) {
                    d = new Date(d);
                }
            }
            );
    });
}

function change_tab_to_active_real_estate(number)
{
    if(number == 1)
    {
        document.getElementById("other_details").style.display = "none";
        document.getElementById("info_and_property").style.display = "block";
        document.getElementById("tab_active").className = "activenavcol"
        document.getElementById("tab_deactive").className = "deactivenavcol1"
        document.getElementById("tab_deactive2").className = "deactivenavcol1"
        document.getElementById("tab_deactive3").className = "deactivenavcol1"
        document.getElementById("errmsg").innerHTML = "   ";

    }
    if(number == 2)
    {
        document.getElementById("info_and_property").style.display = "none";
        document.getElementById("other_details").style.display = "block";
        document.getElementById("loan1").style.display = "block";
        document.getElementById("loan2").style.display = "none";
        document.getElementById("loan3").style.display = "none";
        document.getElementById("errmsg").innerHTML = "   ";
        document.getElementById("tab_active").className = "deactivenavcol"
        document.getElementById("tab_deactive").className = "activenavcol"
        document.getElementById("tab_deactive2").className = "deactivenavcol1"
        document.getElementById("tab_deactive3").className = "deactivenavcol1"
    }
    if(number == 3)
    {
        document.getElementById("info_and_property").style.display = "none";
        document.getElementById("other_details").style.display = "block";
        document.getElementById("loan2").style.display = "block";
        document.getElementById("loan1").style.display = "none";
        document.getElementById("loan3").style.display = "none";
        document.getElementById("errmsg").innerHTML = "   ";
        document.getElementById("tab_active").className = "deactivenavcol"
        document.getElementById("tab_deactive2").className = "activenavcol"
        document.getElementById("tab_deactive3").className = "deactivenavcol1"
        document.getElementById("tab_deactive").className = "deactivenavcol1"
    }

   
    if(number == 4)
    {
        document.getElementById("info_and_property").style.display = "none";
        document.getElementById("other_details").style.display = "block";
        document.getElementById("loan3").style.display = "block";
        document.getElementById("loan1").style.display = "none";
        document.getElementById("loan2").style.display = "none";
        document.getElementById("errmsg").innerHTML = "   ";
        document.getElementById("tab_active").className = "deactivenavcol"
        document.getElementById("tab_deactive3").className = "activenavcol1"
        document.getElementById("tab_deactive2").className = "deactivenavcol1"
        document.getElementById("tab_deactive").className = "deactivenavcol1"

    }

}

function change_tab_to_active(number)
{
    if(number == 1)
    {
        document.getElementById("modal_container").style.height = "750px";
        document.getElementById("other_details").style.display = "none";
        document.getElementById("info_and_property").style.display = "block";
        document.getElementById("tab_active").className = "activenavcol"
        document.getElementById("tab_deactive").className = "deactivenavcol"
        document.getElementById("errmsg").innerHTML = "   ";

    }
    if(number == 2)
    {
        document.getElementById("modal_container").style.height = "400px";
        document.getElementById("info_and_property").style.display = "none";
        document.getElementById("other_details").style.display = "block";
        document.getElementById("errmsg").innerHTML = "   ";
        document.getElementById("tab_active").className = "deactivenavcol"
        document.getElementById("tab_deactive").className = "activenavcol"
    }

}


function replace_info_with_others(property)
{
    document.getElementById("info_and_property").style.display = "none";
    document.getElementById("other_details").style.display = "block";
    document.getElementById("property_id").value = property;
    document.getElementById("errmsg").innerHTML = "   ";
    document.getElementById("tab_active").className = "deactivenavcol"
    document.getElementById("tab_deactive").className = "activenavcol"
}

/* WANT TO look anywhere this is used else want to be removed (below func)  */

function show_hide_asset_docs1_real_estate(pid,folder_id,is_show_del,show_missing_file) {
    show_del_var = (is_show_del == 'show_del') ? 'true' : 'false'
    new Ajax.Request("/properties/show_asset_files/?pid="+pid+"&folder_id="+folder_id+"&del_files="+show_del_var+"&show_missing_file="+false,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function show_hide_asset_docs1_collab(pid,folder_id,is_show_del,shared_file) {
    show_del_var = (is_show_del == 'show_del') ? 'true' : 'false'
    new Ajax.Request("/properties/show_asset_files/?pid="+pid+"&folder_id="+folder_id+"&del_files="+show_del_var+"&shared_file="+shared_file,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}



function show_hide_asset_docs_multi_req_real_estate(pid, folder_id, is_show_del, prop_req, show_missing_file) {
    show_del_var = (is_show_del == 'show_del') ? 'true' : 'false'
    new Ajax.Request("/properties/show_asset_files/?pid="+pid+"&folder_id="+folder_id+"&del_files="+show_del_var+"&sharing_prop="+ prop_req +"&show_missing_file="+false,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function show_hide_asset_docs1_real_estate_war_room(pid,folder_id,is_show_del,note_id) {
    show_del_var = (is_show_del == 'show_del') ? 'true' : 'false'
    new Ajax.Request("/properties/show_asset_files/?pid="+pid+"&folder_id="+folder_id+"&del_files="+show_del_var+"&war_room_cal=true&show_missing_file="+false+"&nid="+note_id+"&war_room_cal="+true,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}



function show_hide_asset_confirm_real_estate(pid,folder_id,is_show_del, req_prop, show_missing_file) {
    show_del_var = (is_show_del == 'show_del') ? 'true' : 'false'
    new Ajax.Request("/property_dispositions/proceed_war_room/?pid="+pid+"&folder_id="+folder_id+"&del_files="+show_del_var+"&req_prop="+req_prop+"&show_missing_file="+false,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}


function delete_asset_doc_or_folder_real_estate(p_id,obj_id,obj,fn,del_type,list,del_files,sps,smf,parent_delete,call_from_prop_files,from_portfolio_summary){
    if(obj == 'folder')
    {
        is_del = (fn == 'del') ? 'true' : 'false'
        if(del_type == 'Delete'){    
            new Ajax.Request("/properties/del_or_revert_folder/?folder_id="+obj_id+"&pid="+p_id+"&fn="+is_del+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&from_portfolio_summary="+from_portfolio_summary,{
                asynchronous:true,
                evalScripts:true,
                onLoading: function(res) {
                    load_writter();
                },
                insertion:Insertion.Top
            });
        }
        else{
            new Ajax.Request("/properties/delete_folder/?folder_id="+obj_id+"&pid="+p_id+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&parent_delete="+parent_delete+"&call_from_prop_files="+call_from_prop_files+"&from_portfolio_summary="+from_portfolio_summary,{
                asynchronous:true,
                evalScripts:true,
                onLoading:function(res){
                    load_writter();
                },
                insertion:Insertion.Top
            });
        }
        return false;
    }
    else
    {
        is_del = (fn == 'del') ? 'true' : 'false' 
        if(del_type == 'Delete'){
            new Ajax.Request("/properties/del_or_revert_doc/?doc_id="+obj_id+"&pid="+p_id+"&fn="+is_del+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&show_missing_file="+smf+"&from_portfolio_summary="+from_portfolio_summary,{
                asynchronous:true,
                evalScripts:true,
                onLoading: function(res) {
                    load_writter();
                },
                insertion:Insertion.Top
            });
        }
        else{
            new Ajax.Request("/properties/delete_doc/?doc_id="+obj_id+"&pid="+p_id+"&fn="+is_del+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&show_missing_file="+smf+"&from_portfolio_summary="+from_portfolio_summary,{
                asynchronous:true,
                evalScripts:true,
                onLoading: function(res) {
                    load_writter();
                },
                insertion:Insertion.Top
            });
        }
        return false;
    }
}




function file_asset_name_update_real_estate(current,parent_id,portfolio_type_id) {
    load_writter();
    crunch = current.id.split('_');
    var set_name = jQuery(current).prev().attr('value');
    var name = set_name;
    var place = crunch.pop();
    params = $H({
        id: place,
        value:name
    }).toQueryString();
    new Ajax.Request('/properties/change_filename', {
        asynchronous: true,
        evalScripts: true,
        parameters:params,
        method: 'POST',
        onComplete: function(res) {
            orig_filename = '';
//            load_completer();
            flash_writter("File renamed to "+name);
        }
    });
}



function delete_selected_real_estate(folders,docs,doc_names,folder_id,pid,del_files){
    var check_boxes= document.getElementsByName(folders);
    var check_boxes1= document.getElementsByName(docs);
    var check_boxes2= document.getElementsByName(doc_names);
    
    arr = [ ];
    for(i=0;i<check_boxes.length;i++){
        if(check_boxes[i].checked==true)
            arr.push(check_boxes[i].value);
    }
    
    arr1 = [ ];
    for(i=0;i<check_boxes1.length;i++){
        if(check_boxes1[i].checked==true)
            arr1.push(check_boxes1[i].value);
    }
    arr2 = [];
    for(i=0;i<check_boxes2.length;i++){
        if(check_boxes2[i].checked==true)
            arr2.push(check_boxes2[i].value);
    }

    if (arr.length > 0 || arr1.length > 0 || arr2.length > 0){
        if(confirm("Are you sure you want to delete?")){
            new Ajax.Request("/properties/delete_folders_docs/?doc_ids="+arr1+"&folder_ids="+arr+"&folder_id="+folder_id+"&pid="+pid+"&del_files="+del_files+"&doc_name_ids="+arr2,{
                asynchronous:true,
                evalScripts:true,
                insertion:Insertion.Top
            });
            return false;
        }
    }
    else{
 
        $('select_one').innerHTML = "<font color='red'>Nothing has been selected</font>"
        $("select_one").show("slow");
        setTimeout(close_error, (1 * 1500) )
        return false;
    }
}





function show_missing_files_real_estate(folder_id,pid,show_missing_files)
{
    new Ajax.Request("/properties/show_missing_files/?folder_id="+folder_id+"&pid="+pid+"&show_missing_file="+show_missing_files,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });
    return false;
}


 
function delete_filename_real_estate(del_type,id,portfolio_id,list,show_past_shared,del_files,smf){
    new Ajax.Request("/properties/delete_filename/?id="+id+"&portfolio_id="+portfolio_id+"&list="+list+"&show_past_shared="+show_past_shared+"&del_files="+del_files+"&del_type="+del_type+"&show_missing_file="+smf,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });
    return false;
}
 
function download_selected_real_estate(folders,docs,doc_names,folder_id,pid){
    var check_boxes= document.getElementsByName(folders);
    var check_boxes1= document.getElementsByName(docs);
    var check_boxes2= document.getElementsByName(doc_names);
    arr = [ ];
    for(i=0;i<check_boxes.length;i++){
        if(check_boxes[i].checked==true)
            arr.push(check_boxes[i].value);
    }
    arr1 = [ ];
    for(i=0;i<check_boxes1.length;i++){
        if(check_boxes1[i].checked==true)
            arr1.push(check_boxes1[i].value);
    }
    
    arr2 = [ ];
    for(i=0;i<check_boxes2.length;i++){
        if(check_boxes2[i].checked==true)
            arr2.push(check_boxes2[i].value);
    }
    
    if (arr.length > 0 || arr1.length > 0 || arr2.length > 0 ){
        loc = "/properties/download_folders_docs/?doc_ids="+arr1.join(',')+"&folder_ids="+arr.join(',')+"&folder_id="+folder_id+"&pid="+pid+"&doc_name_ids="+arr2.join(',')
        var frm = document.getElementById('download_trigger')
        frm.action = loc;
        frm.submit();
    }
    else{
        $('select_one').innerHTML = "<font color='red'>Nothing has been selected</font>";
        $("select_one").show("slow");
        setTimeout(close_error, (1 * 1500) )
    }
}


function open_data_docs_real_estate(pid) {
    new Ajax.Request("/properties/show_asset_docs/?data_hub=asset_data_and_documents&pid="+pid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
            toggle_highlight('asset_docs');
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;    
}

 
 
function revoke_document_real_estate(did,mem_id,fid,pid,list,del_files,sps,smf) {
    new Ajax.Request("/properties/unshare/?id="+did+"&mem_id="+mem_id+"&revoke=document"+"&folder_id="+fid+"&portfolio_id="+pid+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&show_missing_file="+smf,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}


function revoke_folder_real_estate(fid,mem_id,pid,list,del_files,sps,parent_delete) {
    new Ajax.Request("/properties/unshare/?id="+fid+"&mem_id="+mem_id+"&folder_revoke=true"+"&folder_id="+fid+"&portfolio_id="+pid+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&parent_delete="+parent_delete,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

 
 
function show_data_hub_docs_real_estate(pid,nid,is_show_del,close_light_box,edit_inside_asset) {
    show_del_var = (is_show_del == 'show_del') ? 'true' : 'false'
    new Ajax.Request("/properties/notes_data_hub/?pid="+pid+"&nid="+nid+"&del_files="+show_del_var+"&close_light_box="+close_light_box+"&edit_inside_asset="+edit_inside_asset,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function show_past_shared_real_estate(pid,sps) {
    new Ajax.Request("/properties/show_asset_files/?pid="+pid+"&show_past_shared="+sps,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function revoke_filename_real_estate(did,mem_id,fid,pid,list,del_files,sps,smf) {
    new Ajax.Request("/properties/unshare/?id="+did+"&mem_id="+mem_id+"&revoke_fn=true"+"&folder_id="+fid+"&portfolio_id="+pid+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&show_missing_file="+smf,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}


function revert_filename_real_estate(fid,pid,fnid,revert,list,del_files){
    new Ajax.Request("/properties/revert_filename/?id="+fnid+"&folder_id="+fid+"&portfolio_id="+pid+"&list="+list+"&del_files="+del_files,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}




function edit_folder_name_real_estate(current,parent_id,portfolio_type_id,org_nam){
    if (orig_filename == ''){
        orig_filename = current.innerHTML;
        crunch = current.id.split('_');
        id = crunch.pop();
        //innerValue = jQuery(current).children().html();
        folder_content = org_nam.split('[').pop();
        innerValue = org_nam.split('[')[0].replace(/^\s\s*/, '').replace(/\s\s*$/, '');
        //orig_filename = innerValue;
        jQuery('#'+current.id).parent().html('<span><input type="text" value="'+org_nam+'" selected=true size="18" style="width: 100px;"><a style="cursor:pointer;" id="update_'+ id +'" onclick="folder_name_update_real_estate(this,'+parent_id+','+portfolio_type_id+');">Rename</a></span><span onclick="call_folder_restore(this)" style="cursor:pointer" id="'+'c'+current.id+'">&nbsp;cancel</span>');
        jQuery('#c'+current.id).prev('span').children('input').select();
    }
}
	
function folder_name_update_real_estate(current,parent_id,portfolio_type_id) {
    crunch = current.id.split('_');
    var set_name = jQuery(current).prev().attr('value');
    var name = set_name;
    var place = crunch.pop();
    params = $H({
        id: place,
        value:name,
        parent_id:parent_id,
        portfolio_type_id:portfolio_type_id
    }).toQueryString();
    if(portfolio_type_id == 0)
        new Ajax.Request('/properties/change_folder_name', {
            asynchronous: true,
            evalScripts: true,
            parameters:params,
            method: 'POST',
            onLoading: function(){
                load_writter();
            },
            onComplete: function(res) {
                orig_filename = '';
                if(name.strip() != "")
                flash_writter("Folder renamed to "+name);
                else
                load_completer();
            }
        });
    else
        new Ajax.Request('/admin/master_folders/'+ navigation_path +'change_folder_name', {
            asynchronous: true,
            evalScripts: true,
            parameters:params,
            method: 'POST',
            onComplete: function(res) {
                orig_filename = ''
            }
        });
}


 
function moveto_tab(id) {
    new Ajax.Request("/properties/unshare/?id="+did+"&mem_id="+mem_id+"&revoke_fn=true"+"&folder_id="+fid+"&portfolio_id="+pid+"&list="+list+"&del_files="+del_files+"&show_past_shared="+sps+"&show_missing_file="+smf,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function call_timeline_filter_timeline_selector(val,note_id,partial_page,start_date)
{
    new Ajax.Request("/notes/"+for_time_period_setting+"select_time_period/?period="+val+"&note_id="+note_id+"&partial_page="+partial_page+"&start_date="+start_date,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function call_timeline_filter(val,note_id,partial_page)
{
    new Ajax.Request("/notes/"+for_time_period_setting+"select_time_period/?period="+val+"&note_id="+note_id+"&partial_page="+partial_page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}
 
function call_timeline_filter_property(val,note_id,partial_page)
{
    active_period = val;
    active_sub_month = '';
    var par = par_list[active_sub_call]
    if (last_renderer == 'variances')
     {
       if (val == 4){
           jQuery('#yearToDate').attr('className', 'subtabactiverow');
           jQuery('#lastMonth').attr('className', 'subtabdeactiverow');
           jQuery('#lastyear').attr('className', 'subtabdeactiverow');
        }
       if (val == 5){
            jQuery('#yearToDate').attr('className', 'subtabdeactiverow');
            jQuery('#lastMonth').attr('className', 'subtabactiverow');
            jQuery('#lastyear').attr('className', 'subtabdeactiverow');
        }    
        if (val == 6){
            jQuery('#yearToDate').attr('className', 'subtabdeactiverow');
            jQuery('#lastMonth').attr('className', 'subtabdeactiverow');
            jQuery('#lastyear').attr('className', 'subtabactiverow');
        }
     }
    
    if (last_renderer == 'capital' || last_renderer == 'cash_sub_view'){ // this is to display the year to date function for capital sub graph
        if (val == 4){
            for(var i=0; i <new Date().getMonth(); i++)
                jQuery('#time_line_highlight_'+ i).attr('className', 'active');
            jQuery('#yearToDate').attr('className', 'subtabactiverow');
            jQuery('#lastMonth').attr('className', 'subtabdeactiverow');
        }
        else if(val == 5){
            for(var i=0; i <new Date().getMonth(); i++)
                jQuery('#time_line_highlight_'+ i).attr('className', 'deactive');
            jQuery('#time_line_highlight_'+ (new Date().getMonth() - 1).toString()).attr('className', 'active');
            jQuery('#yearToDate').attr('className', 'subtabdeactiverow');
            jQuery('#lastMonth').attr('className', 'subtabactiverow');
            call_onetime_clearer = true;
        }
        (last_renderer == 'capital') ? capitalSubCalls(capital_sub_call, {}) : cashSubCalls(cash_sub_call,{
            cash_find_id:cash_find_id
        })
    }
    else if(par == 'cash_and_receivables'){
        performanceReviewCalls(active_sub_call, active_sub_params);
        return false;
    }
    else {
        new Ajax.Request("/properties/"+for_time_period_setting+"select_time_period/?period="+val+"&note_id="+note_id+"&partial_page="+par+"&financial_sub="+financial_sub+"&financial_subid="+financial_subid+"&occupancy_type="+occupancy_type,{
            asynchronous:true,
            evalScripts:true,
            onComplete:function(request){
                load_completer();
            },
            onLoading:function(request){
                load_writter();
            },
            insertion:Insertion.Top
        });
    }
    return false;
}


function call_timeline_filter_real_overview(portfolio_id,perio,partial_page)
{
    new Ajax.Request("/real_estates/select_time_period_real_overview/?period="+period+"&portfolio_id="+portfolio_id+"&partial_page="+partial_page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}





function show_property_view_real_estate(pid,nid,par) {
    new Ajax.Request("/real_estate/"+pid+"/properties/"+nid+"/property_view",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}
/* AMP */
function show_performance_review_real_estate(pid,nid,par) {
    new Ajax.Request("/real_estate/"+pid+"/properties/"+nid+"/performance_review",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET', // this is not used now ..removed shortly
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}


function show_financials_page_real_estate(pid,nid,par) {
    new Ajax.Request("/real_estate/"+pid+"/properties/"+nid+"/financial",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}
/* AMP */
function show_rent_rolls_real_estate(pid,nid,par) {
    new Ajax.Request("/real_estate/"+pid+"/properties/"+nid+"/rent_rolls",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}


function show_loans(pid,nid,par) {
    new Ajax.Request("/real_estates/"+pid+"/properties/"+nid+"/loan_details/",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}


function move_to_dispositions_real_estate(pid,nid,par) {
    new Ajax.Request("/real_estate/"+pid+"/properties/"+nid+"/move_to_dispositions",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}


    
function edit_portfolio_name_err(id) {
    document.getElementById('edit_pname_'+id).style.border = "1px solid #DD3C10"
}



function highlight_datahub()
{
    document.getElementById("over_tab").className = "deactivesubtab";
    document.getElementById("set_tab").className = "executivesubtab";
}

function check_picture_empty(image_type){
    if(image_type=="portfolio") {
        var att = document.getElementById('portfolio_image_uploaded_data').value;
    }
    else if(image_type=="note_or_real") {
        var att = document.getElementById('attachment_uploaded_data').value;
    }
    else if(image_type=="user") { 
        var att = document.getElementById('user_image_uploaded_data').value;
    }
    //~ file_field = { 'portfolio' : 'portfolio_image_uploaded_data' , 'note_or_real' : 'attachment_uploaded_data', 'user' : ' user_image_uploaded_data'}
    //~ var att = document.getElementById(file_field[image_type]).value
    var flag=false;
    if(att.length>0){
        var extn = att.split('.').last();
        extn=extn.toLowerCase();
        if (extn == "jpg" || extn == "jpeg" || extn == "png" || extn == "tif" || extn == "gif" || extn == "bmp" ) {
            load_writter();
            flag=true;
        }
        else {
            alert('Please upload (jpg,jpeg,png,tif,gif,bmp) format file only.');
            flag=false;
        }

    }
    else{
        alert("please select a file to upload")
    }
    return flag;
}

 function check_image_type(){
     if (document.getElementById('attachment_uploaded_data')==null)
     {
     att=new Array();
     }
		 else
		 {
		   var att = document.getElementById('attachment_uploaded_data').value;
		 }
    var flag=false;
    return_value = jQuery('#attachment_uploaded_data').val();
    if (typeof(return_value)=='undefined')
    {
        flag=true;
    }
    else{
        if(att.length>0){
            var extn = att.split('.').last();
            extn=extn.toLowerCase();
            if (extn == "jpg" || extn == "jpeg" || extn == "png" || extn == "tif" || extn == "gif" || extn == "bmp" ) {
                flag=true;
            }
            else {
                jQuery('#errmsg').html('Please upload (jpg,jpeg,png,tif,gif,bmp) format file only');
                jQuery('#attachment_uploaded_data').val('');
                flag=false;
            }

        }
        else{
            flag=true;
        }
    }
    return flag;
}

function property_acq_performance_review(nid) {
    new Ajax.Request("/property_acquisitions/acq_performance_review/"+nid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function property_acq_note_terms(nid) {
    new Ajax.Request("/property_acquisitions/note_terms/"+nid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function property_acq_rent_roll(nid) {
    new Ajax.Request("/property_acquisitions/acq_rent_roll/"+nid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function property_acq_property_view(nid) {
    new Ajax.Request("/property_acquisitions/acq_property_view/"+nid,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function show_datahub_property_acquisition(id) {
    new Ajax.Request("/property_acquisitions/confirmed_notes/?id="+id+"&data_hub=true",{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function change_overview_property_disposition(note_id,page,targ)
{
    if(jQuery("#"+"overview").css('display')=="none")
    {
        jQuery("#"+"overview").css('display','block');
        jQuery("#"+"addNewSale").css('display','none');
    }
    enable_tab(targ)
    new Ajax.Request("/property_dispositions/change_view_file/?id="+note_id+"&view_file="+page,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
    return false;
}

function move_to_marketplace_property_disposition(nid)
{
    if (confirm("Are you sure you want to move to marketplace?")) {
        new Ajax.Request("/property_dispositions/move_to_marketplace/?id="+nid,{
            asynchronous:true,
            evalScripts:true,
            onComplete:function(r){
                load_completer();
            },
            onLoading:function(request){
                load_writter();
            },
            insertion:Insertion.Top
        });
        return false;
    }
}

function clear_due_date(html_id,doc_name_id){
    if (confirm("Are you sure you want to remove the duedate?")) {
        id = "input#"+html_id
        jQuery(id).val('');
        jQuery('.date-pick').dpClearSelected();
        show_hide_clear_due_date(html_id);
        return false;
    }
}

function show_hide_clear_due_date(id)
{
    var html_id = "input#"+id
    var s = jQuery(html_id).val();
    if(s != "")
    {
        jQuery("#clear_due_date").show();
    }
    else
    {
        jQuery("#clear_due_date").hide();
    }

}

function load_char(val){
    input = val.length;
    if (input <250){
        $('msg').innerHTML= num_val;
    }
    else
    {
        return false;
    }

}
function image_check()
{
    var bool;
    var att = document.getElementById('portfolio_image_uploaded_data').value;
    if (att !='')
    {
        var extn = att.split('.').last();
        extn=extn.toLowerCase();
        if (extn == "jpg" || extn == "jpeg" || extn == "png" || extn == "tif" || extn == "gif" || extn == "bmp" || extn == "tiff" )
        {
            var re = portfolio_check();
            if (re)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            alert('Please upload (jpg,jpeg,png,tif,gif,bmp) format file only.');
            return false;
        }
    }
    else
    {
        var re = portfolio_check();
        if (re)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}

function enable_war_room_image(){
    jQuery('#prop_disp_war_room_image').attr('src','images/acquisitions_icon3.png')
    jQuery('#listing_info_image').attr('src','images/acquisitions_icon2_deactive.png')
    jQuery('#ready_due_image').attr('src','images/acquisitions_icon3_deactive.png')
    
}

function deselect_real_estate(folders,docs,doc_names,folder_id,pid,del_files,select_type){
    var check_boxes= document.getElementsByName(folders);
    var check_boxes1= document.getElementsByName(docs);
    var check_boxes2= document.getElementsByName(doc_names);
    
    arr = [ ];
    for(i=0;i<check_boxes.length;i++){
        if(check_boxes[i].checked==true)
            arr.push(check_boxes[i].value);
    }
    
    arr1 = [ ];
    for(i=0;i<check_boxes1.length;i++){
        if(check_boxes1[i].checked==true)
            arr1.push(check_boxes1[i].value);
    }
    arr2 = [];
    for(i=0;i<check_boxes2.length;i++){
        if(check_boxes2[i].checked==true)
            arr2.push(check_boxes2[i].value);
    }

    if (arr.length > 0 || arr1.length > 0 || arr2.length > 0){        
        new Ajax.Request("/properties/deselect/?doc_ids="+arr1+"&folder_ids="+arr+"&folder_id="+folder_id+"&pid="+pid+"&del_files="+del_files+"&doc_name_ids="+arr2+"&select_type="+select_type,{
            asynchronous:true,
            evalScripts:true,
            insertion:Insertion.Top
        });
        return false;        
    }
    else{
        $('select_one').innerHTML = "<font color='red'>Select File(s) to De-select/Select</font>"
        return false
    }
}

function show_cash_and_receivables(pid,nid,par) {
    new Ajax.Request("/real_estate/"+pid+"/properties/"+nid+"/cash_and_receivalble",{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}

function show_performance_review_real_estate_sort(pid,nid,par,id,start_date,period,key,order) {
    new Ajax.Request("/performance_review_property/"+for_time_period_setting+"change_date/?id="+nid+"&start_date="+start_date+"&key="+key+"&order="+order+"&period="+period+"&partial_page="+par,{
        asynchronous:true,
        evalScripts:true,
        method: 'GET',
        parameters: {
            partial_page:par
        },
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
    return false;
}

function call_to_comment(id, type){ // THIS is for comments part.
    var params = {};
    var comment;
    if (type.indexOf('save') != -1)
        comment = jQuery('#text_'+type.split('&')[0]+'_'+id);
    if (type.indexOf('update') != -1)
        comment = jQuery('#edit_'+type.split('&')[0]+'_'+id);
    if (type.indexOf('reply') != -1)
        comment = jQuery('#reply_'+type.split('&')[0]+'_'+id);
    params.comment=jQuery(comment).val();
    new Ajax.Request('/properties/comment_view?id='+id+'&type='+type+all_cmts+comment_place, {
        asynchronous:true,
        evalScripts:true,
        parameters: params,
        onLoading:function(request){
            load_writter();
        },
        onComplete:function(request){
            jQuery(comment).attr('style','overflow-x: hidden; overflow-y: hidden; height: 25px; padding-top: 0px; padding-bottom: 0px; ');
        }
    });
}

function flush_last_comment(){ // THIS is for comments part.
    if (detect_comment_call == false)
        if(comment_curr != '')
            jQuery("#"+comment_curr).html("");
}

function delete_comment(id){ // THIS is for comments part.
    new Ajax.Request('/properties/comment_delete?id='+id, {
        asynchronous:true,
        evalScripts:true,
        parameters: params,
        onLoading:function(request){
            load_writter();
        }
    });
}

function edit_comment(id, type, com, expln_cmt_for){
    jQuery("#comment_view_"+com+"_options").css("visibility","hidden");
    var expln_cmt_forr = (typeof(expln_cmt_for) == 'undefined') ? '' : '&exp_cmt_for='+expln_cmt_for.split('__').shift()
    cancel_edit_comment();
    jQuery(last_reply_comm).html('');
    var str= 'if(/\\S/.test(jQuery(\'#edit_'+type+'_'+id+'\').val())){call_to_comment('+id+',\''+type+'&comment_id='+com + expln_cmt_forr+'&update=true\');return false;}else{alert(\'Comment cant be null\');return false;}';
    var cont = jQuery('#act_comment_'+ com).html();
    str = '<textarea  class="expand35-200 fieldinput edit_comment_box" id="edit_'+type+'_'+id+'">'+ cont +'</textarea><div class="addbut"> <div class="addpropertyrow"><a href="#" onclick="'+str+'">Save</a><span>&nbsp;</span></div><div class="addpropertyrow"><a href="#" onclick="cancel_edit_comment();return false;">Cancel</a><span>&nbsp;</span></div>';
    hidden_edit = (expln_cmt_forr == '') ? '#new_'+type : '#new_'+type+'_'+expln_cmt_for.split('__').pop()
    jQuery(hidden_edit).hide();
    last_edit_comm = '#edit_comment_'+com;
    last_edit_cont =  jQuery(last_edit_comm).html();
    jQuery(last_edit_comm).html(str);
    jQuery("textarea[class*=expand]").TextAreaExpander();
}

function cancel_edit_comment(){
    if (last_edit_comm != ''){
        jQuery(last_edit_comm).html(last_edit_cont);
        jQuery(hidden_edit).show();
    }
}

function reply_comment(id, type, com){
    if (last_reply_comm != '')
        jQuery(last_reply_comm).html('');
    var str= 'if(/\\S/.test(jQuery(\'#reply_comment\').val())){call_to_comment('+id+',\''+type+'&comment_id='+com+'&reply=true\')}else{alert(\'Please enter the reply\')}';
    str = '<input type="text" id="reply_'+type+'_'+id+'" style="height: 16px;border:1px solid #60A77D;">&nbsp;<label style="padding: 1px 3px 0px; background-color: rgb(96, 167, 125); color: white; cursor: pointer;" onclick="'+str+'">Reply comment</label>&nbsp;<label onclick="last_reply_comm=\'\';jQuery(\'#reply_comment_'+ com +'\').html(\'\');jQuery(\'#reply_comment_'+ com +'\').attr(\'class\',\'\');return false;" style="background-color: #60a77d;color: white;padding: 1px 3px 0px 3px;cursor: pointer;">Cancel</label>';
    last_reply_comm ='#reply_comment_'+com;
    jQuery(last_reply_comm).attr('class', 'commentcontainer');
    jQuery(last_reply_comm).html(str);
}

function add_property_real_estate(number,property_id)
{
    new Ajax.Request("/properties/update_tab/?tab_id="+number+"&property_id="+property_id,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });
}




function basic_form_submit()
{
    
    jQuery("#basic_form_submit").val('false');
    //document.getElementById("basic_form_submit").value = "false";
    jQuery('#basic_details_form').submit();
//document.forms["basic_details_form"].submit();
}
  
  
function activate_tabs(tab)
{   
    document.getElementById("errmsg").innerHTML = "   ";
    class_id =   "tabactive" + tab
    document.getElementById("unorderd_list").className = "ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all"
    document.getElementById("tabactive1").className = " "
    document.getElementById("tabactive2").className = " "
    document.getElementById("tabactive3").className = " "
    document.getElementById(class_id).className = "ui-state-default ui-corner-top ui-tabs-selected ui-state-active"
    jQuery('#'+class_id).children()[1].onclick = "";
}
  
  
function property_form_submit()
{
    document.getElementById("property_form_submit").value = "false";
    document.forms["property_form"].submit();
}
  
function loan_form_submit()
{
    document.getElementById("loan_form_submit").value = "false";
    document.forms["loan_form"].submit();
}
  
function delete_loan(property_id,loan_number,delete_form,from_debt_summary,from_property_details,highlight)
{
    var i = 1;
    var b = param_for_edit ? "&edit_inside_asset=true" : ""
    rem_count--;
    new Ajax.Request("/properties/delete_loan/?property_id="+property_id+"&loan_number="+loan_number+"&delete_form="+delete_form+"&from_debt_summary="+from_debt_summary+"&from_property_details="+from_property_details+"&highlight="+highlight+b,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top,
        onComplete:function(){
            jQuery('.loancol ').each(function(res){
                this.innerHTML = "Loan "+ i;
                i += 1;
            });
        }
    });
    loan_number =  loan_number - 1;
    form_number =  form_number - 1;
}

function update_page_close()
{
    new Ajax.Request("/properties/respond_to_parent_initial_page/?property_id="+property_id,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });

}


function add_property_form_submit(name)
{
  if(jQuery("#basic_details_form").length != 0)
  {
      jQuery("#basic_details_form").submit();
  }
  if(jQuery("#property_form").length != 0)
  {
      jQuery("#property_form").submit();
  }
  if(jQuery("#loan_form").length != 0)
  {
      jQuery("#loan_form").submit();
  }
}


function set_tab(value,form)
{
    document.getElementById("tab_id").value = value
    document.getElementById("form_txt").value = form
}

function spms_form_submit()
{
    document.forms["spms_form"].submit();
}  
   
 
function list_scheduling_days(selected_val)
{
    //	 "<option value='Monthly'>Monthly</option>"
    var val = ''
    for( var i=0; i <= 20; i++)
    {
        if(i == selected_val)
            val =val + "<option value='"+i+"' selected='selected'>"+i+"</option>"
        else
            val =val + "<option value='"+i+"'>"+i+"</option>"
    		 
    }
    document.getElementById('list_scheduling_days_div').innerHTML = "<select name='repeat_ta[task_scheduling_days]' id='repeat_task_task_scheduling_days' class='collabsinput'> "+val+"</select> "
}
 
 
function show_repeat_task(checked)
{
    if (checked == true)
    {
        document.getElementById('is_has_repeat').value ='true';
        document.getElementById('repeat_details').style.display='block'
    }
    else
    {
        document.getElementById('is_has_repeat').value ='false';
        document.getElementById('repeat_details').style.display='none'
    }
	 
		 
//alert(document.getElementById('repeat_task_id').value);
}

function spms_form_submit_false()
{
    document.getElementById("spms_form_submit").value = "false";
}
 
function change_property_pic(property_id, property_img_path) {
    jQuery("#pic_"+property_id).attr("src", property_img_path)
}


function check_download_link(resource,portfolio_id,id,val)
{
    if (resource != "")
    {
        show_hide_asset_docs1_real_estate(portfolio_id,id,val)
    }
    else
    {
        flash_writter("Action restricted");
    }
    return false;
}

function check_download_link_for_notes(resource,portfolio_id,id,val)
{
    if (resource != "")
    {
        show_hide_asset_docs1(portfolio_id,id,val)
    }
    else
    {
        flash_writter("Action restricted");
    }
    return false;
}

function check_download_link_for_file(resource,path)
{
    if (resource != "")
    {
        window.open(path,'_blank')
    }
    else
    {
        flash_writter("Action restricted");
    }
    return false;
}

function add_loan(number,property_id,loan_form_number)
{
    var loan_table2 = jQuery("#loan_table2").html();
    var loan_table3 = jQuery("#loan_table3").html();
    if(loan_table2 == "")
    {
        number = 1;
        rem_count++;
        loan_form_number =2;
    }
    else if(loan_table3 ==  "")
    {
        number = 2;
        rem_count++;
        loan_form_number =3;
    }
    var i= 1;
    new Ajax.Request("/properties/add_loan/?property_id="+property_id+"&number="+number+"&loan_form_number="+loan_form_number,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top,
        onComplete:function(){
            jQuery('.loancol ').each(function(res){
                this.innerHTML = "Loan "+ i;
                i += 1;
            });
        }
    });

    loan_number =  loan_number + 1;
    form_number =  form_number + 1;
    //loan_form_number = loan_form_number + 1
    if(rem_count == 3)
        jQuery("#add_loan_button").hide();
    
}

function delete_loan_form(loan_form_number)
{
    jQuery('#loan_table'+loan_form_number).html('');
    jQuery("#add_loan_button").show();
    var i = 1;
    jQuery('.loancol ').each(function(res){
        this.innerHTML = "Loan "+ i;
        i += 1;
    });
    //  if(loan_form_number != 3 && document.getElementsByName("Loan_Amount["+loan_form_number+"]")[0])
    //{
    //  document.getElementsByName("Loan_Amount["+loan_form_number+"]")[0].name = "Loan_Amount["+(loan_form_number-1)+"]";
    // document.getElementsByName("Date_of_Promissory_Note["+loan_form_number+"]")[0].name = "Date_of_Promissory_Note["+(loan_form_number-1)+"]";
    // document.getElementsByName("Maturity["+loan_form_number+"]")[0].name = "Maturity["+(loan_form_number-1)+"]";
    // document.getElementsByName("Interest_Rate["+loan_form_number+"]")[0].name = "Interest_Rate["+(loan_form_number-1)+"]";
    // document.getElementsByName("Lender["+loan_form_number+"]")[0].name = "Lender["+(loan_form_number-1)+"]";
    // document.getElementsByName("Loan_Balance["+loan_form_number+"]")[0].name = "Loan_Balance["+(loan_form_number-1)+"]";
    // document.getElementsByName("Term["+loan_form_number+"]")[0].name = "Term["+(loan_form_number-1)+"]";
    // document.getElementsByName("Payments["+loan_form_number+"]")[0].name = "Payments["+(loan_form_number-1)+"]";
    // document.getElementsByName("Tax_Escrow_Payments["+loan_form_number+"]")[0].name = "Tax_Escrow_Payments["+(loan_form_number-1)+"]";
    // document.getElementsByName("Prepayment["+loan_form_number+"]")[0].name = "Prepayment["+(loan_form_number-1)+"]";
    // document.getElementsByName("Replacement_Reserve["+loan_form_number+"]")[0].name = "Replacement_Reserve["+(loan_form_number-1)+"]";
    // document.getElementsByName("Tenant_Improvement_and_Leasing_Commission_Reserve["+loan_form_number+"]")[0].name = "Tenant_Improvement_and_Leasing_Commission_Reserve["+(loan_form_number-1)+"]";
    //document.getElementsByName("Guarantors["+loan_form_number+"]")[0].name = "Guarantors["+(loan_form_number-1)+"]";
    //}
    
    rem_count--;
//    jQuery('#loan_table'+loan_form_number).empty();
//    jQuery('#loan_table'+loan_form_number).remove();
//    loan_number =  loan_number - 1;
    
}

function yield_calender(){
    Date.firstDayOfWeek = 0;
    Date.format = 'dd mmm yyyy';
    jQuery(function()
    {
        jQuery('.date-pick').datePicker({
            startDate:'01/01/2000'
        })
        jQuery('#start-date').bind(
            'dpClosed',
            function(e, selectedDates)
            {
                var d = selectedDates[0];
                if ( d ) {
                    d = new Date(d);
                    jQuery('#end-date').dpSetStartDate(d.addDays(1).asString());
                }
            }
            );
    });
}
  
  
function add_class_for_datepicker(id1,id2){
    jQuery('#'+id1).addClass('inputtext_for_datepicker date-pick dp-applied loan_fieldinput');
    jQuery('#'+id2).addClass('inputtext_for_datepicker date-pick dp-applied loan_fieldinput');
}

function toggle_comment(cur, evnt){
    if(typeof(evnt) == 'undefined'){
        jQuery(cur).attr('onclick', save_toggler)
    }
    else{
        save_toggler = evnt
        jQuery(cur).attr('onclick', function(){
            flush_last_comment();
            toggle_comment(this);
        })
    }
}
    
function save_build_imp_exp(val,id,month,ytd_check,variance_doc_id,return_path)
{
    return_path = return_path.replace(/&/gi, "and")
    if (val != "" && trim(val))
    {
        params = {
            exp: val,
            id: id,
            month: month,
            ytd_check: ytd_check,
            variance_doc_id: variance_doc_id,
            performance_review_path: return_path
        };
        //new Ajax.Request("/real_estates/save_explanation/?exp="+val+"&id="+id+"&month="+month+'&performance_review_path='+return_path,{
        new Ajax.Request("/real_estates/save_explanation/",{
            asynchronous:true,
            evalScripts:true,
            parameters:params,
            onLoading:function(request){
                load_writter();
            }
        });
    }
    else
    {
        flash_writter("Enter explanation");
    }
}
    
function save_financial_exp(val,id,month,ytd_check,variance_doc_id,return_path)
{
    return_path = return_path.replace(/&/gi, "and")
    if (val != "" && trim(val))
    {
        params = {
            exp: val,
            id: id,
            month: month,
            ytd_check: ytd_check,
            variance_doc_id: variance_doc_id,
            performance_review_path: return_path
        };
        //new Ajax.Request("/real_estates/save_financial_explanation/?exp="+val+"&id="+id+"&month="+month+'&performance_review_path='+return_path,{
        new Ajax.Request("/real_estates/save_financial_explanation/",{
            asynchronous:true,
            evalScripts:true,
            parameters:params,
            onLoading:function(request){
                load_writter();
            }
        });
    }
    else
    {
        flash_writter("Enter explanation");
    }
}

function save_cash_receivable_exp(val,id,month)
{
    return_path = return_path.replace(/&/gi, "and")
    if (val != "" && trim(val))
    {
        params = {
            exp: val,
            id: id,
            month: month,
            performance_review_path: return_path
        };
        //new Ajax.Request("/real_estates/save_cash_receivable_explanation/?exp="+val+"&id="+id+"&month="+month+'&performance_review_path='+return_path,{
        new Ajax.Request("/real_estates/save_cash_receivable_explanation/",{
            asynchronous:true,
            evalScripts:true,
            parameters:params,
            onLoading:function(request){
                load_writter();
            }
        });
    }
    else
    {
        flash_writter("Enter explanation");
    }
}
    
function save_lease_exp(val,id,month,year,occupancy_type,return_path)
{
    return_path = return_path.replace(/&/gi, "and")
    if (val != "" && trim(val))
    {
        params = {
            exp: val,
            id: id,
            month: month,
            year: year,
            occupancy_type: occupancy_type,
            performance_review_path: return_path
        };
        //new Ajax.Request("/real_estates/save_lease_explanation/?exp="+val+"&id="+id+"&month="+month+"&year="+year+"&occupancy_type="+occupancy_type+'&performance_review_path='+return_path,{
        new Ajax.Request("/real_estates/save_lease_explanation/",{
            asynchronous:true,
            evalScripts:true,
            parameters:params,
            onLoading:function(request){
                load_writter();
            }
        });
    }
    else
    {
        flash_writter("Enter explanation");
    }
}
    
function show_collaboration_myprofile()
{      
    document.getElementById("col_setup").className = 'executivesubtab';    
    document.getElementById("col_overview").className = 'deactivesubtab';
    document.getElementById("col_overview_image").style.width="70px";
    document.getElementById("col_setup_image").style.width="75px";

    new Ajax.Request("/collaboration_hub/my_profile",{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top,
        onLoading:function(request){
            load_writter();
        },
        onComplete:function(){
            load_completer();
        }
    });
}

function edit_user_name(current,field)
{
    if(orig_filename.length > 0 && field == 'name')
    {
        call_name_restore(document.getElementById('ccomment'),'comment');
    }
    else if(orig_filename.length > 0 && field == 'comment')
    {
        call_name_restore(document.getElementById('cname'),'name');
    }
    orig_filename = current.innerHTML;
    crunch = current.id.split('_');
    id = crunch.pop();
    if(navigator.appName == "Microsoft Internet Explorer" && field == 'comment')
    {
        innerValue = document.getElementById('comment').innerHTML.gsub(/<\/?H>/,'');
    }
    else
    {
        innerValue = jQuery(current).children().html();
    }
    folder_content = innerValue.split('[').pop();
    innerValue = innerValue.split('[')[0].replace(/^\s\s*/, '').replace(/\s\s*$/, '');
    jQuery('#'+current.id).parent().html((jQuery("#"+current.id).parent().hasClass("comment") ? "<strong>Description</strong> : " : "")+'<span><input type="text" value="'+innerValue+'" selected=true size="18" style="width: 100px;"><a style="cursor:pointer;" id="update_'+ id +'" onclick="user_name_update_real_estate(this,\''+field+'\');">Save</a></span><span onclick="call_name_restore(this,\''+field+'\')" style="cursor:pointer;color:#025B8D;font-weight:bold;font-size:11px;" id="'+'c'+current.id+'">&nbsp;Cancel</span>');
    jQuery('#c'+current.id).prev('span').children('input').select();
    edit_id = field + "_edit"
    jQuery('#'+edit_id).hide();
}



function edit_user_password()
{
    document.getElementById('change_password').style.display ="block";   
    jQuery("#pass_text").hide();
}


function user_name_update_real_estate(current,field) {
    crunch = current.id.split('_');
    var set_name = jQuery(current).prev().attr('value');
    var name = escape(set_name);
    var place = crunch.pop();
    var field_name = field;
    params = $H({
        id: place,
        value:name,
        field:field_name
    }).toQueryString();
   
    new Ajax.Request("/collaboration_hub/change_user_name?name="+name+"&field="+field_name, {
        asynchronous: true,
        evalScripts: true,
        method: 'POST',
        onLoading: function(){
            load_writter();
        },
        onComplete: function(res) {
            orig_filename = '';
            load_completer();
        }
    });
}

function show_folder_struct_coll_hub(port_id,parent_id)
{
    new Ajax.Request("/collaboration_hub/list_of_folders/?portfolio_id="+port_id+"&parent_id="+parent_id,{
        asynchronous:true,
        evalScripts:true,
        onLoading:function(request){
            load_writter();
        },
        onComplete:function(request){
            load_completer();
        }
    });
}

function do_user_name_update(place,res) {

    if(res.strip() == '' || res.strip() == " ")
    {
        res = orig_filename;
    }
    else  {
        res_print = orig_filename.split('>');
        res = (typeof(update_for_user) !='undefined') ? res_print[0]+'>'+ res +(place == 'name' ? '</strong>'  : '</h>') : res_print[0]+'>'+ res+' ['+ folder_content +'</a>'
    }
    folder_content ='';
    var div_id = 'div.'+place;
    abs_parent = jQuery('#update_'+place).parents(div_id);
    if (typeof(update_for_user) == 'undefined'){
        abs_parent = jQuery('#update_'+place);
    }

    if(place == "comment")
    {
        jQuery(abs_parent).html('<strong>Description</strong> : <span id='+place+'>'+ res +'</span>&nbsp;<a href="#" onclick="edit_user_name(document.getElementById(\''+place+'\'),\''+place+'\');return false;" class="bluecolor" id=\''+place+'\'_edit>Edit</a>');
   
    }
    else
    {
        jQuery(abs_parent).html('<span id='+place+'>'+ res +'</span>&nbsp;<a href="#" onclick="edit_user_name(document.getElementById(\''+place+'\'),\''+place+'\');return false;" class="bluecolor" id=\''+place+'\'_edit>Edit</a>');
    }
    
    
}

function call_name_restore(current,field){
    crunch = current.id.split('_');
    set_html = orig_filename;
    set_id = field;

    if(field == "comment")
    {
        jQuery('#'+current.id).parent().html('<strong>Description</strong> : <span id="'+ set_id +'">'+ set_html +'</span>&nbsp;<a href="#" onclick="edit_user_name(document.getElementById(\''+field+'\'),\''+field+'\');return false;" class="bluecolor" id=\''+field+'\'_edit>Edit</a>');
    }
    else
    {
        jQuery('#'+current.id).parent().html('<span id="'+ set_id +'">'+ set_html +'</span>&nbsp;<a href="#" onclick="edit_user_name(document.getElementById(\''+field+'\'),\''+field+'\');return false;" class="bluecolor" id=\''+field+'\'_edit>Edit</a>');
    }
    
    orig_filename = '';
    folder_content = '';
}


	
function delete_shared_collaborators(em,id)
{
    var d =  document.getElementById(em)
    if(d == null)
    {
        document.getElementById(em+id).style.display ='none';
    }
    else
    {
        document.getElementById(em).style.display ='none';
    }

    var delete_user = document.getElementById('deleted_users').value;
    if (delete_user=='')
        document.getElementById('deleted_users').value =em;
    else
        document.getElementById('deleted_users').value =delete_user+","+em;
}
  
function check_email_address(str)
{ 
    var at="@"
    var dot="."
    var lat=str.indexOf(at)
    var lstr=str.length
    var ldot=str.indexOf(dot)
    if (str.indexOf(at)==-1){
        return false
    }
    if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
        return false
    }
    if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
        return false
    }
    if (str.indexOf(at,(lat+1))!=-1){
        return false
    }
    if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
        return false
    }
    if (str.indexOf(dot,(lat+2))==-1){
        return false
    }
    if (str.indexOf(" ")!=-1){
        return false
    }
} 
 
  
  
function add_collaborators_list()
{	  
    var  m =document.getElementById('collaborator_list').value.split(",");
    var collabs = []
    //......................displays error msg if user shares to himself or adding already added email or invalid email start...................................
    for(e=0;e<m.length;e++)
    {
        if(cur_email == m[e])
        {
            display_err_msg_if_share_to_yourself(m[e]);
            return false;
        }
        else
        {
            if(document.getElementById(m[e]) == null) {
                collabs.push(m[e]);
            }
            var s = m[e].strip();
            if(check_email_address(s) == false)
            {
                flash_writter('Please enter valid email address');
                return false;
            }
            else
            {
                if (document.getElementById(s) && document.getElementById(s).style.display != 'none')
                {
                    flash_writter(s+' has been taken already');
                    return false;
                }
            }
        }
    }
    //......................displays error msg if user shares to himself or adding already added email or invalid email end...................................
    for(e=0;e<m.length;e++)
    {
        var s = m[e];
        if(document.getElementById(s) == null || document.getElementById(s).style.display == 'none')
        {
            var add ='false';
            if(document.getElementById(s) != null && document.getElementById(s).style.display == 'none')
            {
                add_already_added_then_deleted_users(s)
            }
            else
            {
                if(document.getElementById(s))
                {  }
                else
                {
                    var add ='true';
                    var collaborator_list = collabs.join(",");
                    var collab_arr = collaborator_list.gsub(' ','').split(',');
                    var collab_exact = []
                    for(j=0;j<unique(collab_arr).length;j++)
                    {
                        if(collab_arr[j] != cur_email)
                            collab_exact.push(collab_arr[j])
                        new_collaborators.push(collab_arr[j])
                    }
                    if(collab_arr.length == 1 && collab_exact.length == 0)
                    {  }
                    else
                    {
                        collaborator_list = jQuery.grep(collaborator_list, function(n,i){
                            return n != 'undefined';
                        });
  
                        collaborator_list = collab_exact.join(',');
                        var already_added_users =collab_exact.join(',');
                        var deleted_users =document.getElementById('deleted_users').value;
                        if(share == 'true')
                        {
                            var c = new_collaborators;
                            document.getElementById('already_added_users').value = c;
                        }
                        else
                        {
                            var c = already_added_users;
                            document.getElementById('already_added_users').value = document.getElementById('already_added_users').value +","+ c;
                        }
                    }
                }
            }
        }
        else
        {  }
        new_collaborators = jQuery.grep(new_collaborators, function(n,i){
            return n != '';
        });
    }
    if(c)
    {
        var already = c.split(",")
        c = jQuery.grep(already, function(n,i){
            return n != 'undefined';
        });
        new Ajax.Request("/properties/add_collaborators_with_profile?collaborator_list="+collaborator_list+"&already_added_users="+c+"&deleted_users="+deleted_users+"&share="+share,{
            asynchronous:true,
            evalScripts:true,
            insertion:Insertion.Top
        });
    }

    else
    {
        //  document.getElementById('collaborator_list').value = '';
        jQuery('#collaborator_list').css('color','gray');
        jQuery('#collaborator_list').val('Enter email addresses here');
    }
    show_or_hide_to();
}
 
 
function add_already_added_then_deleted_users(s)
{
    document.getElementById(s).style.display = 'block';
    var collaborators_list = document.getElementById('collaborator_list').value.split(",")
    new_collaborators.push(s);
    deleted_already_added_users = jQuery.grep(deleted_already_added_users, function(n,i){
        return n != s;
    });
    var deleted_users =document.getElementById('deleted_users').value;
    deleted_users =  deleted_users.split(",");
    deleted_users =   deleted_already_added_users || deleted_users;
    document.getElementById('deleted_users').value = deleted_users.join(",");
    if(share != 'true')
    {
        document.getElementById('already_added_users').value = document.getElementById('already_added_users').value +","+ s;
    }
}


function display_err_msg_if_share_to_yourself(email)
{

    if(file == true)
    {
        flash_writter('Sharing file to yourself is restricted');
    }
    if(folder == true)
    {
        flash_writter('Sharing folder to yourself is restricted');
    }
    else
    {
        flash_writter('Assigning task to yourself is restricted');
    }
}

 
 
  
function add_collaborators_list_share()
{	  
    var collaborator_list = document.getElementById('collaborator_list').value;
    var already_added_users =document.getElementById('already_added_users').value;
    var deleted_users =document.getElementById('deleted_users').value;
    new Ajax.Request("/properties/add_collaborators_with_profile?collaborator_list="+collaborator_list+"&already_added_users="+already_added_users+"&deleted_users="+deleted_users+"&share=true"+"&folder_id="+folder_id+"&id="+id,{
        asynchronous:true,
        evalScripts:true,
        onLoading:function () { 
            if(collaborator_list != "") {
                load_writter();
            }
        },
        onComplete:function() {
            if(collaborator_list != "") {
                load_completer();
            }
        },
        insertion:Insertion.Top 
    });	  
}
	 
  
  
function assign_already_added_users(users_list)
{
    document.getElementById('already_added_users').value = users_list;
    document.getElementById('collaborator_list').value = 'Enter email addresses here';
}
  
function delete_collaborator_users(em,id,existing_user)
{
    new_collaborators = jQuery.grep(new_collaborators, function(n,i){
        return n != em;
    });
    if(share == 'true')
    {
        document.getElementById('already_added_users').value = new_collaborators.join(',');
    }
    else
    {
        var u = document.getElementById('already_added_users').value.split(",")
        users = jQuery.grep(u, function(n,i){
            return n != em;
        });
        document.getElementById('already_added_users').value = users.join(',');
    }
    d = document.getElementById(em);
    if(d == null)
    {
        d = document.getElementById(em);
    }
    d.style.display = 'none';
    if(existing_user == 'true' )
    {
        var delete_user = document.getElementById('deleted_users').value;
        if (delete_user=='')
            document.getElementById('deleted_users').value =em;
        else
            document.getElementById('deleted_users').value =delete_user+","+em;
    }
    show_or_hide_to();
}
function show_or_hide_to(){
    ((deleted_already_added_users.length == added_users.split(',').length-1) && new_collaborators.length == 0) ? jQuery('#addpropertyrow_to').hide() : new_collaborators.length==0 && added_users=="" ? jQuery('#addpropertyrow_to').hide() : jQuery('#addpropertyrow_to').show();
}

function call_to_store_expln(id, month, document, is_ytd, type){
    type = typeof(type) == 'undefined' ? 'cash_flow' : type == 'cap_exp' ? 'cap_exp' : 'leases'
    params = {
        month: month,
        type: type,
        document: document
    };
    if (type != "leases")
    {
        if(is_ytd){
            params.is_ytd_explanation = '1'
            params.expln = jQuery('#expln_ytd_'+ id).val();
        }
        else{
            params.is_ytd_explanation = '0'
            params.expln = jQuery('#expln_'+ id).val();
        }
    }
    else
    {
        params.expln = jQuery('#expln_'+ id).val();
    }
    params.expln = trim(params.expln)
    if (/\S/.test(params.expln)){
        new Ajax.Request('/properties/'+id+'/save_explanations_now', {
            asynchronous:true,
            evalScripts:true,
            parameters:params,
            method : 'get',
            onComplete:function(request){
                load_completer();
            },
            onLoading:function(request){
                load_writter();
            }
        });
    }
    
}

function call_to_store_expln_if_try_comment(id, month, document, type){
    type = typeof(type) == 'undefined' ? 'cash_flow' : 'cap_exp'
    params = {
        month: month,
        type: type,
        document: document
    };
    params.expln = '';
    params.dummy_rec = true; // this is to add rec for enabling comment in explanation
    new Ajax.Request('/properties/'+id+'/save_explanations_now', {
        asynchronous:true,
        evalScripts:true,
        parameters:params,
        method : 'get',
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
   
}

function back_call_after_threshold(type_task, del_files, folder_id, from_assign_task, id, month, portfolio_id, revoke_fn, show_missing_file){
    back_threshold = "new Ajax.Request('/properties/"+ type_task +"?del_files="+ del_files +"&folder_id="+ folder_id +"&from_assign_task="+from_assign_task+"&id="+id+"&month="+month+"&portfolio_id="+portfolio_id+"&revoke_fn="+revoke_fn+"&show_missing_file="+show_missing_file+"', {asynchronous:true,  evalScripts:true });"
}


function show_or_hide_save_button(members_list)
{
    if ((document.getElementById("collaborator_list").value == "" || document.getElementById("collaborator_list").value == null) && (document.getElementById("deleted_users").value == "" || document.getElementById("deleted_users").value == null) && (document.getElementById("already_added_users").value == "" || document.getElementById("already_added_users").value == null))
    {
        document.getElementById("save_button").style.display = "none";
    }
    else
    {
        document.getElementById("save_button").style.display = "block";
    }
}



function show_or_hide_save_button_cancel_button()
{
    if ((document.getElementById("collaborator_list").value == "" || document.getElementById("collaborator_list").value == null) && (document.getElementById("deleted_users").value == "" || document.getElementById("deleted_users").value == null) && (document.getElementById("already_added_users").value == "" || document.getElementById("already_added_users").value == null))
    {
        document.getElementById("save_button").style.display = "none";
        document.getElementById("cancel_button").style.display = "none";
    }
    else
    {
        document.getElementById("save_button").style.display = "block";
        document.getElementById("cancel_button").style.display = "block";
    }
}


function find_close_function(pid,fid,hide_del,list,call,sps)
{
    if(revoke == 0)
    {
        Control.Modal.close();
    }
    else
    {
        //        Control.Modal.close();
        if(call != "true")
        {
            refresh_page_after_close_prop(pid,fid,'hide_del',list,call,sps);
        } 

        else
        {
            refresh_page_after_close_from_files_and_prop(pid,fid,'hide_del',list);
        }
    }
}

function validateThreshold(varPer,varAmt,capExp,varPer_ytd,varAmt_ytd,capExp_ytd)
{
    var ValidChars = "0123456789.";
    var IsNumber=true;
    var Char;
    var toBeValidated =  typeof(capExp)== 'undefined' ? [varPer, varAmt] : [varPer, varAmt, capExp]
    var toBeValidated_ytd =  typeof(capExp_ytd)== 'undefined' ? [varPer_ytd, varAmt_ytd] : [varPer_ytd, varAmt_ytd, capExp_ytd]
    if (typeof(capExp)== 'undefined'){
        capExp = '0'
    }
    if (typeof(capExp_ytd)== 'undefined'){
        capExp_ytd = '0'
    }
    if(varPer=="" || varAmt== "" || capExp== "" ) {
        jQuery("#error_msg").text("Empty values not allowed");
        if(jQuery("#error_msg").attr("place") == "admin") {
            jQuery('#error_msg').css('margin-left','85px');
        }
        else {
            jQuery('#error_msg').css('margin-left','230px');
        }
        return false;
    }
    else {
        for(j = 0; j < toBeValidated.length && IsNumber == true; j++ )
        {
            for (i = 0; i < toBeValidated[j].length && IsNumber == true; i++)
            {
                Char = toBeValidated[j].charAt(i);
                if (ValidChars.indexOf(Char) == -1) {
                    IsNumber = false;
                }
            }
        }
        if(IsNumber) {
            return IsNumber;
        }
        else {
            jQuery("#error_msg").text("Enter only numbers ");
            if(jQuery("#error_msg").attr("place") == "admin") {
                jQuery('#error_msg').css('margin-left','100px');
            }
            else {
                jQuery('#error_msg').css('margin-left','245px');
            }
            return IsNumber;
        }
    }
    
    if(varPer_ytd=="" || varAmt_ytd== "" || capExp_ytd== "" ) {
        jQuery("#error_msg").text("Empty values not allowed");
        if(jQuery("#error_msg").attr("place") == "admin") {
            jQuery('#error_msg').css('margin-left','85px');
        }
        else {
            jQuery('#error_msg').css('margin-left','230px');
        }
        return false;
    }
    else {
        for(j = 0; j < toBeValidated.length && IsNumber == true; j++ )
        {
            for (i = 0; i < toBeValidated[j].length && IsNumber == true; i++)
            {
                Char = toBeValidated[j].charAt(i);
                if (ValidChars.indexOf(Char) == -1) {
                    IsNumber = false;
                }
            }
        }
        if(IsNumber) {
            return IsNumber;
        }
        else {
            jQuery("#error_msg").text("Enter only numbers ");
            if(jQuery("#error_msg").attr("place") == "admin") {
                jQuery('#error_msg').css('margin-left','100px');
            }
            else {
                jQuery('#error_msg').css('margin-left','245px');
            }
            return IsNumber;
        }
    }
}



function move_copy_to_action(operation)
{

    var move_folder_id=''
    move_folder_id = document.getElementById('move_folder_id').value;
    if (move_folder_id!='')
    {
        if(confirm('Previous collaborators(if any) will be removed. Do you like to continue?')){
            jQuery('#upload_form1').submit();
            return false;
        }
    }
    else
    {
        alert("Please select a folder to '"+operation+"' ")
    }

}

function assign_already_added_users(users_list)
{
    document.getElementById('already_added_users').value = users_list;
    document.getElementById('collaborator_list').value = 'Enter email addresses here';
}

function with_out_file_task_validation(){
    var _task_type  = jQuery('#task_task_type_id :selected').text();
    if (_task_type == "") {
        if (jQuery('#varianceTaskLbl').text().strip() == "Explain Variances")
            _task_type  = "Explain Variances"
    }
    if (_task_type == "General" || _task_type == "Upload File"){
        if(/\S/.test(jQuery('#task_instruction').val()) && jQuery('#task_instruction').val() != "Enter the instruction here..."  && jQuery('#task_subject').val() !=="" ){
            if(restrict_save_for_without_collaborators()){
                document.forms.upload_form1.submit();
                return true;
            }
            else
                return false;
        }
        else{
            if(/\S/.test(jQuery('#task_subject').val()) == false)
                jQuery('#task_subject').css('border','1px solid #DD3C10');
            else
                jQuery('#task_subject').css('border','1px solid #EAEAEA');
            if(/\S/.test(jQuery('#task_instruction').val()) == false)
                jQuery('#task_instruction').css('border','1px solid #DD3C10');
            else
                jQuery('#task_instruction').css('border','1px solid #EAEAEA');
            jQuery('#err_task_dialog').css('display', 'block')
        }
        scrollTo(0,0);
        return false;
    }else{
        if(_task_type == "Review File" || _task_type == "Update File" || _task_type == "Explain Variances" || _task_type == "Discussion"){
            if(/\S/.test(jQuery('#task_subject').val()) == false){
                jQuery('#task_subject').css('border','1px solid #DD3C10');
                jQuery('#task_instruction').css('border','1px solid #EAEAEA');
                jQuery('#err_task_dialog').css('display', 'block');
                scrollTo(0,0);
                return false;
            }
            else{
                if(/\S/.test(jQuery('#task_instruction').val()) == false){
                    if(confirm("Save task without an instruction?")){
                        if(restrict_save_for_without_collaborators()){
                            document.forms.upload_form1.submit();
                            return true;
                        }
                        else
                            return false;
                    }
                    else
                        return false;
                }else{
                    if(restrict_save_for_without_collaborators()){
                        document.forms.upload_form1.submit();
                        return true;
                    }else{
                        return false
                    }
                }
            }
        }
    }
}

function cancel_prev_upload_que() {
  jQuery("div[id *= 'SWFUpload']").each(function(){jQuery(this).remove()});
  // Do not use id SWFUpoad any where.
}

function blank_file_upload_swf(){
    jQuery('.progressCancel').parent("div.red").parent("div").each(function(){
        jQuery(this).remove();
    }); 
    var cnt = 0;
    jQuery('.progressWrapper').each(function(){
        if(jQuery(this).is(':visible')){
            cnt++;
        }
    });
    if (cnt < 1) {
        alert('Please select a file to upload');
        jQuery('#initiate_basic').css('visibility', 'visible');
        return false;
    }
    else {
        swfu.startUpload();
        jQuery('#change_but').attr('value','Uploading...');
        load_writter();
        return true;
    }
    return false;
}

function restrict_empty_collaborators(){
    var coll = document.getElementById('collaborator_list').value;
    if((coll !=='' && coll != "Enter email addresses here") || (added_users == "" && new_collaborators.length == 0 && deleted_already_added_users.length ==0)){
        flash_writter("Please Add Collaborator(s) Email First and Click on the '+ Add' Button above.");
        return false;
    }
    else{
        return true;
    }
}

function delect_selected_file_main_for_folder(upload_type,upload_file_id,task_id,fname)
{
    AddedFiles.splice(AddedFiles.indexOf(fname),1);
    var already_upload_file = document.getElementById('all_already_upload_file').value;
    var all_tree_structure_file = document.getElementById('all_tree_structure_file').value;
    new Ajax.Request("/properties/delect_task_file_for_main?upload_type="+upload_type+"&upload_file_id="+upload_file_id+"&task_id="+task_id+"&already_upload_file="+already_upload_file+"&all_tree_structure_file="+all_tree_structure_file,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });
}

function delect_selected_file_main(upload_type,upload_file_id,document_id,fname)
{
    AddedFiles.splice(AddedFiles.indexOf(fname),1);
    var already_upload_file = document.getElementById('all_already_upload_file').value;
    var all_tree_structure_file = document.getElementById('all_tree_structure_file').value;
    new Ajax.Request("/properties/delect_task_file_for_main?upload_type="+upload_type+"&upload_file_id="+upload_file_id+"&document_id="+document_id+"&already_upload_file="+already_upload_file+"&all_tree_structure_file="+all_tree_structure_file,{
        asynchronous:true,
        evalScripts:true,
        insertion:Insertion.Top
    });
}


function unique(arrayName)
{
    var newArray=new Array();
        label:for(var i=0; i<arrayName.length;i++ )
        {
            for(var j=0; j<newArray.length;j++ )
            {
                if(newArray[j]==arrayName[i])
                    continue label;
            }
            newArray[newArray.length] = arrayName[i];
        }
    return newArray;
}

function change_asset_view_path(portfolio_id,property_id)
{
    var path  = "/real_estate/"+portfolio_id+"/properties/"+property_id
    document.getElementById('asset_view_path').href = path;
}

function return_to_portfolio_path(portfolio_id)
{
    var path  = "/real_estates/"+portfolio_id
    document.getElementById('asset_view_path').href = path;    
    flash_writter("Add a property to go to Asset View");
}

function approve_and_completion()
{
    var task_id = document.getElementById('store_task_id').value;
    new Ajax.Request("/properties/task_completion?task_id="+task_id+"&task_type_pure_task=pure_task",{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            document.forms.upload_form1.submit();
            return true;
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
}

function approve_and_completion_file_task()
{
    var task_id = document.getElementById('task_doc_id').value;
    new Ajax.Request("/properties/task_completion?task_id="+task_id+"&task_type=doc",{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            document.forms.upload_form1.submit();
            return true;
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
}
function approve_and_completion_file_task(task_id)
{
    new Ajax.Request("/tasks/task_completion?task_id="+task_id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            Control.Modal.close();
            document.forms.upload_form1.submit();
            return true;
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
}

function approve_and_completion_variance()
{
    var task_id = document.getElementById('task_id').value;
    new Ajax.Request("/properties/task_completion?task_id="+task_id+"&task_type_variance=task_variance",{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            document.forms.upload_form1.submit();
            return true;
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
}

function approve_and_completion_view_task(task_id)
{
    //        var task_id = document.getElementById('task_doc_id').value;
    new Ajax.Request("/properties/request_completion?task_id="+task_id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            document.forms.update_task_form.submit();
            return true;
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
}
      

function delete_task(task_id, task_type){
    new Ajax.Request("/properties/task_destroy?task_id="+task_id+"&task_type="+task_type,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            go_back_to_file_structure_in_view_task();
            return true;
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
}

function approve_and_complete_repeat_task(task_id,task_type,delete_mode){
    if(delete_mode == 'only this occurrence')
        link = "/tasks/delete_repeat_tasks?task_id="
    else if(delete_mode == 'all occurrence')
        link = "/tasks/delete_all_repeat_tasks?perform=task_complete&task_id="
    new Ajax.Request(link+task_id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            document.forms.upload_form1.submit();
            Control.Modal.close();
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
}


function delete_repeat_task(task_id,task_type,delete_mode){
    if(delete_mode == 'only this occurrence')
        link = "/tasks/delete_repeat_tasks?task_id="
    else if(delete_mode == 'all occurrence')
        link = "/tasks/delete_all_repeat_tasks?perform=delete&task_id="
    new Ajax.Request(link+task_id,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            if(task_type == 'pure_task')
                go_back_cancel_for_folder();
            else if(task_type == 'task_with_file')
                go_back_to_file_structure_in_view_task();
            else
                go_back_to_file_structure(false);
            Control.Modal.close();
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        }
    });
}

function restrict_save_for_without_collaborators(){
    //    if(jQuery('#add_coll_list').val() == ''){
    if (jQuery("#add_coll_list").length > 0){
        if(jQuery('#add_coll_list').val() == '')
            if(confirm('There are no collaborators added. Do you like to continue?'))
                return true;
            else
                return false;
        else
            return true;
    }
    else if(confirm('There are no collaborators added. Do you like to continue?')) {
        return true;
    }
    else
        return false;
}

function with_out_file_task_validation_and_with_out_collaborators(){
    var _task_type  = jQuery('#task_task_type_id :selected').text();
    if (_task_type == "") {
        if (jQuery('.explaincol').text() == " Explain Variances")
            _task_type  = "Explain Variances"
    }
    if (_task_type == "Custom Instruction" || _task_type == "Upload File"){
        if( /\S/.test(jQuery('#task_instruction').val()) && jQuery('#task_instruction').val() != "Enter the instruction here..." ){
            if(restrict_save_for_without_collaborators()){
                document.forms.upload_form1.submit();
                return true;
            }
            else{
                return false;
            }
        }
        else{
            jQuery('#task_instruction').css('border','1px solid #DD3C10');
            return false;
        }

    }else{
        if(_task_type == "Review File" || _task_type == "Update File" || _task_type == "Explain Variances"){ 
            if( /\S/.test(jQuery('#task_instruction').val()) && jQuery('#task_instruction').val() == "Enter the instruction here..." ){ 
                if(confirm("Save task without an instruction?")){
                    if(restrict_save_for_without_collaborators()){
                        document.forms.upload_form1.submit();
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else
                    return false;
            }else{
                document.forms.upload_form1.submit();
                return true;
            }
        }
    }
}

function view_task_complete_page(task_value,user,comment_type){
    if(task_value){
        jQuery('#add_coll_list').val()=='' ? jQuery('.collab_content_row').hide():jQuery('#add_collaborators_link').hide();
        var divs = document.getElementsByClassName('addpropertyrow');
        for(var i=0; i<divs.length; i++) {
            divs[i].style.visibility='hidden'
        }
        if(user=="owner"){
            document.getElementById('task_task_type_id').disabled=true;
            document.getElementById('task_instruction').disabled=true;
        }
        // Starts --- Hide the task comments if there is no comments --
        if(comment_type == 'Document'){
            if(jQuery('div#list_comments_file').children().length >0){
                jQuery('#new_document').hide();
                jQuery('#commenteditrow').hide();
            }
            else
                jQuery('.tasks_comment_row').hide();
        }
        else if(comment_type == 'Task'){
            if(jQuery('div#list_comments_task').children().length >0){
                jQuery('#new_puretask').hide();
                jQuery('#commenteditrow').hide();
            }
            else
                jQuery('.tasks_comment_row').hide();
        }
        else if(comment_type == 'variance_task'){
            //            var new_comment = /^text_explanation_(\d)+$/
            var new_comments = jQuery(".variance_rowwrapper").find("textarea").parent("div").parent("div");
            new_comments.each(function() {
                this.hide();
            });
            var item_explanation=jQuery('.tablecoll5').find("textarea");
            item_explanation.each(function(){
                this.disable()
            });
            
        }
        // Ends----
        // Starts Hide the files if there is no added files list
        if(jQuery('div#added_files_list').children().length == 0)
            jQuery('div#added_files_list').parent().hide();
        // End--
        // Hide subject
        jQuery('#task_subject').attr('disabled',true);
    // ends
    }
}

function change_basic_form()
{
    document.getElementById('basic_form_close').value = 'false';
}

/**
 * this is used to find whether collaborators adeded or not in the tasks
 */
function findCollaboratorsInTasks() {
    if(/\S/.test(jQuery('#collbartor_list_display').text()) == false)
        jQuery('.add_a_collaborater').show();
    else
        jQuery('.add_a_collaborater').hide();
}

function find_file_already_added_in_addFiles(){
    var flname =  jQuery('#fileUpAddFiles').val().gsub('\\',' ').split(' ');
    flname = flname[flname.length-1];
    var already = false;
    for (i = 0; i < AddedFiles.length; i++) {
        if(AddedFiles[i] == flname){
            already = true;
            break;
        }
    }
    if(already == true){
        alert('File already added');
        return false;
    }
    else{
        AddedFiles.push(flname);
        tempFiles +="AddedFiles.pop();";
        return true;
    }
}

function display_pname_err_msg(t){
    document.getElementById('pname_err_msg').innerHTML = t;
}

function replace_image_for_print_chart(chart_id,user_id)
{
    
        image_id = chart_id+"_image"
        document.getElementById(chart_id).style.display="none";
        document.getElementById(image_id).style.display="block";
        document.getElementById('chart_image_id').src="/images/ExportedImages/fusionchart_"+user_id+".jpg";
        setTimeout("window.print()", 4000);
        setTimeout("delay_print_functionality('"+chart_id+"')", 4000) ;
}

function delay_print_functionality(chart_id)
{
    load_writter();
    image_id = chart_id+"_image"
    document.getElementById(chart_id).style.display="block";
    document.getElementById(image_id).style.display="none";
    load_completer();
}


function saveCommentBeforeExit(type,id)
{
    if(jQuery("#text_"+type+"_"+id).length>0 && jQuery("#text_"+type+"_"+id).val()!="")
    {
        var result=confirm("Do you like to save the comment entered?");
        if (result==true){jQuery(".addbut .addpropertyrow a").trigger('click');}
    }
    else if(jQuery("#edit_"+type+"_"+id).length>0 && jQuery("#edit_"+type+"_"+id).val()!="")
    {
        var result=confirm("Do you like to save the comment entered?");
        if (result==true){jQuery("#edit_"+type+"_"+id).siblings(".addbut").find("a:first").trigger('click');}
    }
} 

// added for setting comment and exp id to delete
function set_comment_and_exp_id(id,target){
    if($(target)!=null){
        if($(target).value==""){
            $(target).value=id;
        }
        else{
            $(target).value=$(target).value+"$$"+id;
        }
    }
}
// end

function remove_from_already_existing_users(toRemove) {
    toRemoveArr=toRemove.split(',');
    existingArr=document.getElementById('already_added_users').value.split(',');
    newData=existingArr.diff(toRemoveArr).join(',');
    document.getElementById('already_added_users').value=newData;
}


function open_edit_variance_task(task_id,portfolio_id,folder_id,edit_task_for_folder,month)
{
    active_call="datahub";
   new Ajax.Request("/properties/edit_task/?id="+task_id+"&portfolio_id="+portfolio_id+"&folder_id="+folder_id+"&from_assign_task=cash_flow"+"&month="+month,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
}


function open_view_variance_task(task_id,portfolio_id,folder_id,edit_task_for_folder,month)
{
    active_call="datahub";

   new Ajax.Request("/properties/view_task/?id="+task_id+"&portfolio_id="+portfolio_id+"&folder_id="+folder_id+"&from_assign_task=cash_flow"+"&month="+month,{
        asynchronous:true,
        evalScripts:true,
        onComplete:function(request){
            load_completer();
        },
        onLoading:function(request){
            load_writter();
        },
        insertion:Insertion.Top
    });
}

function disable_control() {
    jQuery('#modal_container').prepend('<div id="toDisable" style="position:fixed;top:0pt;left:0pt;width:100%;height:100%;z-index:9999"></div>');
}


function deactivate_click(id){
    jQuery("#"+id).prev("a").hide();
    jQuery("#"+id).show();
    var t=setTimeout(function(){activate_click(id);},4000);
}
function activate_click(id){
    jQuery("#"+id).hide();
    jQuery("#"+id).prev("a").show();
}