class Admin::BlogsController < ApplicationController
  before_filter :admin_login_required
  protect_from_forgery :except=>[:change_category_blogs,:manage_comments]
   layout 'admin'
   cache_sweeper :tag_sweeper
   
  # GET /blogs
  # GET /blogs.xml
  def index
 
    @blogs = Blog.paginate :order=>"created_at desc",:page=>params[:page],:per_page=>15

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @blogs }
    end
  end

  # GET /blogs/1
  # GET /blogs/1.xml
  def show
    @blog = Blog.find(params[:id])
    @active_media = @blog.attachings.find_by_is_primary(true)

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @blog }
    end
  end

  # GET /blogs/new
  # GET /blogs/new.xml
  def new
    list_categories

    @blog = Blog.new
    @active_users = User.find(:all,:conditions=>['state = ?',"active"])
	
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @blog }
    end
  end

  # GET /blogs/1/edit
  def edit
	  list_categories
    @active_users = User.find(:all,:conditions=>['state = ?',"active"])
    @blog = Blog.find(params[:id])
    @err = false
  end

  # POST /blogs
  # POST /blogs.xml
  def create
	list_categories
    @blog = Blog.new(params[:blog])
    @active_users = User.find(:all,:conditions=>['state = ?',"active"])

    respond_to do |format|
      @blog.author = params[:blog][:author]
      @blog.featured_top = params[:is_blog_featured_top] ? params[:blog][:featured_top] : nil
      if @blog.save
	      unless params[:categories].nil?
	params[:categories]. each do |category|
	   @blog_categories = @blog.blog_categories.create(:category_id=>category,:blog_id=>@blog)
   end
   @blog.attachings.last.update_attributes(:is_primary => true) if (!@blog.attachings.blank? || !@blog.attachings.empty?) 
	   end
        flash[:notice] = 'Blog was successfully created.'
        format.html { redirect_to(admin_blogs_url) }
        format.xml  { render :xml => @blog, :status => :created, :location => @blog }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @blog.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /blogs/1
  # PUT /blogs/1.xml
  def update
     list_categories
		 @active_users = User.find(:all,:conditions=>['state = ?',"active"])
    @blog = Blog.find(params[:id])

    respond_to do |format|
      params[:blog][:featured_top] = params[:is_blog_featured_top] ? params[:blog][:featured_top] : nil
      if @blog.update_attributes(params[:blog])

	unless params[:categories].nil?
  if @blog.blog_categories.collect{|x|x.category_id.to_s} != params[:categories]
  @blog.blog_categories.destroy_all
	params[:categories].each do |category|
@blog_categories = @blog.blog_categories.create(:category_id=>category,:blog_id=>@blog)
	end
	end
	end

        flash[:notice] = 'Blog was successfully updated.'
        format.html { redirect_to(admin_blogs_url) }
        format.xml  { head :ok }
      else
        @err = true
        format.html { render :action => "edit" }
        format.xml  { render :xml => @blog.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /blogs/1
  # DELETE /blogs/1.xml
  def destroy
    @blog = Blog.find(params[:id])
    @blog.destroy

    respond_to do |format|
      format.html { redirect_to(admin_blogs_url) }
      format.xml  { head :ok }
    end
  end
  
  def delete_blogs
      if !params[:blog].blank?
        params[:blog].each do |blog|
	  blog = Blog.find(blog)
	  blog.destroy 
        end
        flash[:notice] = 'Blog(s) was successfully deleted.'
      else  
        flash[:error] = 'Select Blog(s) to delete.'
      end    
      respond_to do |format|
        format.html { redirect_to(admin_blogs_url) }
         format.xml  { render :xml => @blog }
      end
    end
    
    def edit_media
	   @blog = Blog.find(params[:id])
	   @blog_attachings = @blog.attachings
   end
   
   def upload_media
	@blog = Blog.find(params[:id])
	@blog_attachings = @blog.attachings
	    respond_to do |format|
		    unless params[:blog][:data].blank?
		       @blog_attachings = @blog.update_attributes(params[:blog])
			flash[:notice] = 'Media File uploaded successfully.'
			 format.html { redirect_to(admin_blogs_url) }
			 format.xml  { render :xml => @blog, :status => :created, :location => @blog }
			 else
			flash[:error] = "Select a Media to Upload"
			format.html { render :action => "edit_media" }
		    end
	    end
    end
    
    def active_media
    @blog = Blog.find(params[:id])
		@media = @blog.attachings.find_by_asset_id(params[:blog_attaching][:asset_id])    
    prev_primary_attaching = @blog.attachings.find_by_is_primary(true)
    prev_primary_attaching.update_attributes(:is_primary=>false) if !prev_primary_attaching.nil?    
		@media.update_attributes(:is_primary => true)  if @media
		flash[:notice] = 'Media activated successfully.'
		redirect_to(admin_blogs_url)
    end
    
    
    def list_categories
	    @list_categories = Category.find(:all,:conditions=>['parent_id != ? and status = ?',0,1])
    end
    
    #To display blogs which are set as featured in Home page
    
    def featured_in_homepage
      @homepage_featuredblogs = Blog.featured_in_home_page.paginate :page=>params[:page],:per_page=>15
      return unless request.post?
      if params[:commit] == "Remove Selected from Featured Blogs"
        remove_featured_positions(params[:featuredblog_home],'Home','featured_top')
      elsif params[:commit] == "Change Featured Display Positions of Selected Blogs"
        change_featured_positions(params[:featuredblog_home],params[:featuredbloghome_],'Home','featured_top')
      end  
      redirect_to(homepage_featuredblogs_url)      
    end  
    
   #To change positions of selected blogs to be displayed as featured in Home page
    
    def change_featured_positions(featuredblog_params,featuredblogposition_params,display,field)
      if !featuredblog_params.blank?
        featuredblog_params.each do |featuredblog_home|
          if (featuredblogposition_params.keys).include?(featuredblog_home)
            b = Blog.find(featuredblog_home)
            b.update_attributes(:"#{field}"=>featuredblogposition_params[featuredblog_home][0])
          end
        end
        flash[:notice] = "Selected Blog(s) positions are changed for Featured display in #{display} page"
      else      
        flash[:error] = "Select Blog(s) to change positions of Featured display in #{display} page"
      end
    end     
    
   #To remove selected blogs to be displayed as featured in Home/Category page
    
    def remove_featured_positions(featuredblog_params,display,field)
      if !featuredblog_params.blank?
            featuredblog_params.each do |featuredblog_home|
              b = Blog.find(featuredblog_home)
              b.update_attributes(:"#{field}"=>nil)
            end
          flash[:notice] = "Selected Blog(s) are removed from Featured display in #{display} page"
        else      
          flash[:error] = "Select Blog(s) to remove from Featured display in #{display} page"
        end
    end  
    
    #To display blogs which are set as featured in Category page
    
    def featured_in_categorypage
      @categories = Category.find(:all,:conditions=>['parent_id != ? and status = ?',0,1])
      @category = Category.find(:first,:conditions=>['parent_id != ? and status = ?',0,1])
      @category_blogs = @category.blogs
      return unless request.post?
      if params[:commit] == "Remove Selected from Featured Blogs"
        remove_category_featured_positions
      elsif params[:commit] == "Change Featured Display Positions of Selected Blogs"
        change_category_featured_positions
      end  
      redirect_to(categorypage_featuredblogs_url)   
    end  
    
    def remove_category_featured_positions
      if !params[:featuredblog_category].blank?
        params[:featuredblog_category].each do |featuredblog_home|
            f = FeaturedblogCategory.find_by_blog_id_and_category_id(featuredblog_home,params[:categoryid])
	    if f
            f.destroy
	    end
        end
        flash[:notice] = "Selected Blog(s) positions are changed for Featured display in Category page"
      else      
        flash[:error] = "Select Blog(s) to change positions of Featured display in Category page"
      end
    end  
    
    def change_category_featured_positions
      if !params[:featuredblog_category].blank?
        params[:featuredblog_category].each do |featuredblog_home|
          if (params[:featuredblogcategory_].keys).include?(featuredblog_home)
            f = FeaturedblogCategory.find_or_create_by_blog_id_and_category_id(featuredblog_home,params[:categoryid])
            f.update_attributes(:featured_cat=>params[:featuredblogcategory_][featuredblog_home][0])
          end
        end
        flash[:notice] = "Selected Blog(s) positions are changed for Featured display in Category page"
      else      
        flash[:error] = "Select Blog(s) to change positions of Featured display in Category page"
      end
    end  
    
    def change_category_blogs
      @category = Category.find(params[:id])
      @category_blogs = @category.blogs
      if request.xml_http_request?
        render :update do |page|
          page.replace_html "featured_categoryblogs", :partial=>'featured_categoryblogs'
        end	
      end
    end  
    
    def manage_comments
	    if request.xhr?
		    render :update do |page|
		    @comments = Comment.paginate :all,:conditions=>['is_approved =? and commentable_type = ?',params[:comment],'Blog'],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if !params[:comment].blank?
		    @comments = Comment.paginate :all,:conditions=>['commentable_type = ?','Blog'],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:comment].blank?
		    page.replace_html 'comments',:partial=>'comments'
		    end
	    else
	       @comments = Comment.paginate :all,:conditions=>['commentable_type = ?','Blog'],:order=>"created_at desc",:page=>params[:page],:per_page=>15
	    end
    end
    
    
    def approve_comment
	    @comment = Comment.find(params[:id])
	    @comment.update_attributes(:is_approved =>true)
	    flash[:notice] = 'Comment has been approved.'
	    redirect_to(manage_comments_path)
    end
    
    def disapprove_comment
	    @comment = Comment.find(params[:id])
	    @comment.update_attributes(:is_approved =>false)
	    flash[:notice] = 'Comment has been disapproved.'
	    redirect_to(manage_comments_path)
    end
    
   def destroy_comment
    @comment = Comment.find(params[:id])
    @comment.destroy

    respond_to do |format|
	flash[:notice]='Comment has been deleted.'
      format.html { redirect_to(manage_comments_path) }
      format.xml  { head :ok }
    end
  end
  
   def delete_blog_comments
	if !params[:commit] && !params[:comment].blank?
		params[:comment].each do |comment|
		  comment = Comment.find(comment)
		  comment.destroy 
		end
        flash[:notice] = 'Comment(s) was successfully deleted.'
	elsif params[:commit]
		if params[:commit] == "Approve selected comments"
			approve_selected_comments
		else
			disapprove_selected_comments
		end
	else
		flash[:error] = 'Select Comment(s) to delete.'
      end    
      respond_to do |format|
        format.html { redirect_to(manage_comments_path) }
         format.xml  { render :xml => @comment }
      end
    end
    
    def approve_selected_comments
	if !params[:comment].blank?
	   params[:comment].each do |comment|
	   comment = Comment.find(comment)
	   comment.update_attributes(:is_approved=>true) 
	   flash[:notice] = 'Select Comment(s) has been approved.'
	  end
	else 
	   flash[:error] = 'Select Comment(s) to approve.'
	end
    end
	 
    def disapprove_selected_comments
		if !params[:comment].blank?
		   params[:comment].each do |comment|
		   comment = Comment.find(comment)
		   comment.update_attributes(:is_approved=>false)
		   flash[:notice] = 'Select Comment(s) has been disapproved.'
		  end
		else 
		   flash[:error] = 'Select Comment(s) to disapprove.'
		end
    end

    
end
