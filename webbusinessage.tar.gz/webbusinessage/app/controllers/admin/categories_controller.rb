class Admin::CategoriesController < ApplicationController
  before_filter :admin_login_required
	layout 'admin'
	
  def index
    @categories = Category.paginate :conditions=>['parent_id = ?',0],:page=>params[:page],:per_page=>15,:order=>'created_at asc'
    
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @categories }
    end
  end

  # GET /categories/1
  # GET /categories/1.xml
  def show
    @category = Category.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @category }
    end
  end

  # GET /categories/new
  # GET /categories/new.xml
  def new
	  
     load_categories
    @category = Category.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @category }
    end
  end

  # GET /categories/1/edit
  def edit
	  load_categories
	  
    @category = Category.find(params[:id])
    @parentid = @category.parent_id
  end

  # POST /categories
  # POST /categories.xml
  def create
  load_categories
	
	@category = Category.create(:parent_id=>params[:category][:parent_id],:name=>params[:category][:name],:description=>params[:category][:description],:position=>params[:category][:position],:status=>params[:category][:status])
	@prev_cat = Category.find_by_parent_id_and_position(@category.parent_id,@category.position)

    respond_to do |format|
      if @category.save
        flash[:notice] = 'Category was successfully created.'
        format.html { redirect_to(admin_categories_url) }
        format.xml  { render :xml => @category, :status => :created, :location => @category }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @category.errors, :status => :unprocessable_entity }
	end
    end
  end

  # PUT /categories/1
  # PUT /categories/1.xml
  def update
	  load_categories
    @category = Category.find(params[:id])
    
    respond_to do |format|
    if @category.update_attributes(params[:category])
        flash[:notice] = 'Category was successfully updated.'
        format.html { redirect_to(admin_categories_url) }
        format.xml  { head :ok }
      else
        @prev_cat = Category.find_by_parent_id_and_position(@category.parent_id,@category.position)
        format.html { render :action => "edit" }
        format.xml  { render :xml => @category.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /categories/1
  # DELETE /categories/1.xml
  def destroy
    @category = Category.find(params[:id])
    move_to_uncategorised(@category)

    respond_to do |format|
      format.html { redirect_to(admin_categories_url) }
      format.xml  { head :ok }
    end
  end
  
   def delete_categories
    if !params[:category].blank?
      params[:category].each do |category_id|
        category = Category.find(category_id)
        move_to_uncategorised(category)
      end
    flash[:notice] = 'Categories(s) was successfully deleted.'
    else
    flash[:error] = 'Select Categories(s) to delete.'  
    end

    respond_to do |format|
      format.html { redirect_to(admin_categories_url) }
      format.xml  { render :xml => @content_types }
    end
   end 

  def move_to_uncategorised(category)
    if category.parent_id.to_i == 0
        if !category.children.empty?
        last_cat_position = Category.find_by_parent_id(0,:order=>"position desc")
        c = Category.find_by_name('Uncategorised')
          if c.nil?
            c = Category.create(:name=>'Uncategorised',:parent_id=>0,:status=>true,:position=>last_cat_position.position+1,:description=>"Uncategorized Items")
            c.children << category.children
            category.destroy
          else
            c.children << category.children
            category.destroy
          end
        else
          category.destroy
        end              
    else  
      category.destroy
    end
  end  

  def load_categories
	@categories = Category.find(:all,:conditions=>['parent_id = ?',0])
  end


end
