class Admin::ContentTypesController < ApplicationController
	before_filter :admin_login_required
  layout 'admin'
	
  # GET /content_types
  # GET /content_types.xml
  def index
    load_content_types
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @content_types }
    end
  end	
	
	# GET /content_types/1
  # GET /content_types/1.xml
  def show
    @content_type = ContentType.find(params[:id])
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @content_type }
    end
  end
	
	# GET /content_types/new
  # GET /content_types/new.xml
  def new
    @content_type = ContentType.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @content_type }
    end
  end	
	
	# POST /content_types
  # POST /content_types.xml
  def create
    @content_type = ContentType.new(params[:content_type])
    
    respond_to do |format|
      if @content_type.save
      flash[:notice] = 'ContentType was successfully created.'
      format.html { redirect_to(admin_content_types_url) }
        format.xml  { render :xml => @content_type, :status => :created, :location => @content_type }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @content_type.errors, :status => :unprocessable_entity }
      end
    end
  end	
	
	# GET /content_types/1/edit
  def edit
    @content_type = ContentType.find(params[:id])
  end
	
	# PUT /content_types/1
  # PUT /content_types/1.xml
  def update
    @content_type = ContentType.find(params[:id])

    respond_to do |format|
      if @content_type.update_attributes(params[:content_type])
        flash[:notice] = 'ContentType was successfully updated.'
        format.html { redirect_to(admin_content_types_url) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @content_type.errors, :status => :unprocessable_entity }
      end
    end
  end	
	
	# DELETE /content_types/1
  # DELETE /content_types/1.xml
  def destroy
    @content_type = ContentType.find(params[:id])
    @content_type.destroy
    flash[:notice] = "ContentType was successfully deleted."
    respond_to do |format|
      format.html { redirect_to(admin_content_types_url) }
      format.xml  { head :ok }
    end
  end
  
	def delete_content_types
    if !params[:content_type].blank?
      params[:content_type].each do |content_type|
        content_type = ContentType.find(content_type)
        content_type.destroy 
      end
    flash[:notice] = 'ContentType(s) was successfully deleted.'
    else
    flash[:error] = 'Select ContentType(s) to delete.'  
    end

    respond_to do |format|
      format.html { redirect_to(admin_content_types_url) }
      format.xml  { render :xml => @content_types }
    end
   end 
	
	def load_content_types
    sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort]
    @content_types = ContentType.paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}"
  end 

end
