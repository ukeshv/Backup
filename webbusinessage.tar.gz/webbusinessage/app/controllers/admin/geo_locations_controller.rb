class Admin::GeoLocationsController < ApplicationController
	before_filter :admin_login_required
  layout 'admin'
	
  # GET /geo_locations
  # GET /geo_locations.xml
  def index
    load_geo_locations
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @geo_locations }
    end
  end	
	
	# GET /geo_locations/1
  # GET /geo_locations/1.xml
  def show
    @geo_location = GeoLocation.find(params[:id])
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @geo_location }
    end
  end
	
	# GET /geo_locations/new
  # GET /geo_locations/new.xml
  def new
    @geo_location = GeoLocation.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @geo_location }
    end
  end	
	
	# POST /geo_locations
  # POST /geo_locations.xml
  def create
    @geo_location = GeoLocation.new(params[:geo_location])
    
    respond_to do |format|
      if @geo_location.save
      flash[:notice] = 'GeoLocation was successfully created.'
      format.html { redirect_to(admin_geo_locations_url) }
        format.xml  { render :xml => @geo_location, :status => :created, :location => @geo_location }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @geo_location.errors, :status => :unprocessable_entity }
      end
    end
  end	
	
	# GET /geo_locations/1/edit
  def edit
    @geo_location = GeoLocation.find(params[:id])
  end
	
	# PUT /geo_locations/1
  # PUT /geo_locations/1.xml
  def update
    @geo_location = GeoLocation.find(params[:id])

    respond_to do |format|
      if @geo_location.update_attributes(params[:geo_location])
        flash[:notice] = 'GeoLocation was successfully updated.'
        format.html { redirect_to(admin_geo_locations_url) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @geo_location.errors, :status => :unprocessable_entity }
      end
    end
  end	
	
	# DELETE /geo_locations/1
  # DELETE /geo_locations/1.xml
  def destroy
    @geo_location = GeoLocation.find(params[:id])
    @geo_location.destroy
    flash[:notice] = "GeoLocation was successfully deleted."
    respond_to do |format|
      format.html { redirect_to(admin_geo_locations_url) }
      format.xml  { head :ok }
    end
  end
  
	def delete_geo_locations
    if !params[:geo_location].blank?
      params[:geo_location].each do |geo_location|
        geo_location = GeoLocation.find(geo_location)
        geo_location.destroy 
      end
      flash[:notice] = 'GeoLocation(s) was successfully deleted.'
    else  
      flash[:error] = 'Select GeoLocation(s) to delete.'
    end    
    respond_to do |format|
      format.html { redirect_to(admin_geo_locations_url) }
      format.xml  { render :xml => @geo_locations }
    end
   end 
	
	def load_geo_locations
    sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort]
    @geo_locations = GeoLocation.paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}"
  end 
	
	
end
