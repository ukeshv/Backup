class Admin::ListingsController < ApplicationController
  before_filter :admin_login_required
  protect_from_forgery :except=>[:change_category_listings,:index,:auto_complete_for_user_email,:manage_comments]
	layout 'admin'
  require "faster_csv"
  require "csv"
  auto_complete_for :user, :email
  cache_sweeper :tag_sweeper
  
  def index

    if request.xhr?
	render :update do |page|
		@listings = Listing.paginate :all,:conditions=>['is_sponsored =?',params[:filter_type]],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:filter_type] && !params[:filter_type].blank?
		@listings = Listing.paginate :all,:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:filter_type] && params[:filter_type].blank?
		@listings = Listing.paginate :all,:conditions=>['status =?',params[:filter_status]],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:filter_status] && !params[:filter_status].blank?
		@listings = Listing.paginate :all,:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:filter_status] && params[:filter_status].blank?
		@listings = Listing.paginate :all,:conditions=>['expiry_date >= ?',params[:from_date].to_date],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if !params[:from_date].blank?
		@listings = Listing.paginate :all,:conditions=>['expiry_date <= ?',params[:to_date].to_date],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if !params[:to_date].blank?
		@listings = Listing.paginate :all,:conditions=>['(expiry_date >= (?) and expiry_date <= (?))',params[:from_date].to_date,params[:to_date].to_date],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if !params[:from_date].blank? && !params[:to_date].blank?
		if params[:author]
			user_id = User.find(:all,:conditions=>["email LIKE '%%#{params[:author]}%%'"]).collect{|x| x.id}
			list = Listing.find(:all,:conditions=>['author_id IN (?)',user_id]).collect{|x| x.id}
		@listings = Listing.paginate :all,:conditions=>['id IN (?)',list],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if !list.empty?
		end
		page.replace_html 'listing',:partial=>'listing'
	end
	else
	@listings = Listing.paginate :order=>"created_at desc",:page=>params[:page],:per_page=>15

	end

  end
  
  def new
      list_dropdowns
    @listing = Listing.new
    @specific_content_types = SpecificContentType.find(:all,:conditions=>["status = ?",true])
    @geo_locations = GeoLocation.find(:all)
    @user_levels = UserLevel.find(:all)
  end
  
    def create
      list_dropdowns
      @listing = Listing.new(params[:listing])
      respond_to do |format|
          @listing.author_id = current_user.id
          @listing.editor_id = current_user.id
          @listing.featured_top = params[:is_listing_featured_top] ? params[:listing][:featured_top] : nil
          @listing.featured_cat = params[:is_listing_featured_cat] ? params[:listing][:featured_cat] : nil
          if @listing.save              
              @listing.attachings.last.update_attributes(:is_primary => true) if (!@listing.attachings.blank? || !@listing.attachings.empty?) 
              flash[:notice] = 'Listing was successfully created.'
              format.html { redirect_to(admin_listings_url) }
              format.xml  { render :xml => @listing, :status => :created, :location => @listing }
          else
              format.html { render :action => "new" }
              format.xml  { render :xml => @listing.errors, :status => :unprocessable_entity }
          end
      end
    end
 
  # GET /listings/1/edit
  def edit
	  list_dropdowns
    @listing = Listing.find(params[:id])
    @err = false
  end 

  # PUT /listings/1
  # PUT /listings/1.xml
  def update
    list_dropdowns
    @listing = Listing.find(params[:id])
    respond_to do |format|
    params[:listing][:author_id] = current_user.id
    params[:listing][:editor_id] = current_user.id
    params[:listing][:featured_top] = params[:is_listing_featured_top] ? params[:listing][:featured_top] : nil
    params[:listing][:featured_cat] = params[:is_listing_featured_cat] ? params[:listing][:featured_cat] : nil
      if @listing.update_attributes(params[:listing])
        flash[:notice] = 'Listing was successfully updated.'
        format.html { redirect_to(admin_listings_url) }
        format.xml  { head :ok }
      else
        @err = true
        format.html { render :action => "edit" }
        format.xml  { render :xml => @listing.errors, :status => :unprocessable_entity }
      end
    end
  end

  # GET /blogs/1
  # GET /blogs/1.xml
  def show
    @listing = Listing.find(params[:id])
    @active_media = @listing.attachings.find_by_is_primary(true)

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @listing }
    end
  end

  # DELETE /blogs/1
  # DELETE /blogs/1.xml
  def destroy
    @listing = Listing.find(params[:id])
    @listing.destroy

    respond_to do |format|
      format.html { redirect_to(admin_listings_url) }
      format.xml  { head :ok }
    end
  end
  
  def delete_listings
    if !params[:commit]
      if !params[:listing].blank?
        params[:listing].each do |listing|
	  listing = Listing.find(listing)
	  listing.destroy 
        end
        flash[:notice] = 'Listing(s) was successfully deleted.'
      else  
        flash[:error] = 'Select Listing(s) to delete.'
      end
    else
      if !params[:listing].blank?
        params[:listing].each do |listing|
	  listing = Listing.find(listing)
	  listing.update_attribute('status','Active') 
        end
        flash[:notice] = 'Listing(s) was successfully activated.'
      else  
        flash[:error] = 'Select Listing(s) to Activate.'
      end
    end  
      respond_to do |format|
        format.html { redirect_to(admin_listings_url) }
         format.xml  { render :xml => @listing }
      end
  end

   def edit_media
	   @listing = Listing.find(params[:id])
	   @listing_attachings = @listing.attachings
   end
   
   def upload_media
	@listing = Listing.find(params[:id])
	@listing_attachings = @listing.attachings
	    respond_to do |format|
		    unless params[:listing][:data].blank?
		       @listing_attachings = @listing.update_attributes(params[:listing])
			flash[:notice] = 'Media File uploaded successfully.'
			 format.html { redirect_to(admin_listings_url) }
			 format.xml  { render :xml => @listing, :status => :created, :location => @listing }
			 else
			flash[:error] = "Select a Media to Upload"
			format.html { render :action => "edit_media" }
		    end
	    end
    end
    
    def active_media
    @listing = Listing.find(params[:id])
		@media = @listing.attachings.find_by_asset_id(params[:listing_attaching][:asset_id])    
    prev_primary_attaching = @listing.attachings.find_by_is_primary(true)
    prev_primary_attaching.update_attributes(:is_primary=>false) if !prev_primary_attaching.nil?    
		@media.update_attributes(:is_primary => true)  if @media
		flash[:notice] = 'Media activated successfully.'
		redirect_to(admin_listings_url)
    end 

  def list_dropdowns
	  @categories = Category.find(:all,:conditions=>['parent_id != ? and status = ?',0,1])
    @content_types = ContentType.find(:all,:conditions=>['status = ?',1])
    @specific_content_types = SpecificContentType.find(:all,:conditions=>["status = ?",true])
    @geo_locations = GeoLocation.find(:all)
    @user_levels = UserLevel.find(:all)
  end
    
    #To display listings which are set as featured in Home page
    
    def featured_in_homepage
      @homepage_featuredlistings = Listing.featured_in_home_page.paginate :page=>params[:page],:per_page=>15
      return unless request.post?
      if params[:commit] == "Remove Selected from Featured Listings"
        remove_featured_positions(params[:featuredlisting_home],'Home','featured_top')
      elsif params[:commit] == "Change Featured Display Positions of Selected Listings"
        change_featured_positions(params[:featuredlisting_home],params[:featuredlistinghome_],'Home','featured_top')
      end  
      redirect_to(homepage_featuredlistings_url)      
    end  
    
   #To change positions of selected listings to be displayed as featured in Home page
    
    def change_featured_positions(featuredlisting_params,featuredlistingposition_params,display,field)
      if !featuredlisting_params.blank?
        featuredlisting_params.each do |featuredlisting_home|
          if (featuredlistingposition_params.keys).include?(featuredlisting_home)
            l = Listing.find(featuredlisting_home)
            l.update_attributes(:"#{field}"=>featuredlistingposition_params[featuredlisting_home][0])
          end
        end
        flash[:notice] = "Selected Listing(s) positions are changed for Featured display in #{display} page"
      else      
        flash[:error] = "Select Listing(s) to change positions of Featured display in #{display} page"
      end
    end     
    
   #To remove selected listings to be displayed as featured in Home page
    
    def remove_featured_positions(featuredlisting_params,display,field)
      if !featuredlisting_params.blank?
            featuredlisting_params.each do |featuredlisting_home|
              l = Listing.find(featuredlisting_home)
              l.update_attributes(:"#{field}"=>nil)
            end
          flash[:notice] = "Selected Listing(s) are removed from Featured display in #{display} page"
        else      
          flash[:error] = "Select Listing(s) to remove from Featured display in #{display} page"
        end
    end  

    #To display listings which are set as featured in a specific category page
    
    def featured_in_categorypage
      @categories = Category.find(:all,:conditions=>['parent_id != ? and status = ?',0,1])
      @category = Category.find(:first,:conditions=>['parent_id != ? and status = ?',0,1])
      @category_listings = @category.listings
      return unless request.post?
      if params[:commit] == "Remove Selected from Featured Listings"
        remove_category_featured_positions
      elsif params[:commit] == "Change Featured Display Positions of Selected Listings"
        change_category_featured_positions
      end  
      redirect_to(categorypage_featuredlistings_url)   
    end  
    
    def remove_category_featured_positions
      if !params[:featuredlisting_category].blank?
        params[:featuredlisting_category].each do |featuredlisting_home|
            f = FeaturedlistingCategory.find_by_listing_id_and_category_id(featuredlisting_home,params[:categoryid])
            f.destroy
        end
        flash[:notice] = "Selected Listing(s) positions are changed for Featured display in Category page"
      else      
        flash[:error] = "Select Listing(s) to change positions of Featured display in Category page"
      end
    end  
    
    def change_category_featured_positions
      if !params[:featuredlisting_category].blank?
        params[:featuredlisting_category].each do |featuredlisting_home|
          if (params[:featuredlistingcategory_].keys).include?(featuredlisting_home)
            f = FeaturedlistingCategory.find_or_create_by_listing_id_and_category_id(featuredlisting_home,params[:categoryid])
            f.update_attributes(:featured_cat=>params[:featuredlistingcategory_][featuredlisting_home][0])
          end
        end
        flash[:notice] = "Selected Listing(s) positions are changed for Featured display in Category page"
      else      
        flash[:error] = "Select Listing(s) to change positions of Featured display in Category page"
      end
    end  
    
    def change_category_listings
      @category = Category.find(params[:id])
      @category_listings = @category.listings
      if request.xml_http_request?
        render :update do |page|
          page.replace_html "featured_categorylistings", :partial=>'featured_categorylistings'
        end	
      end
    end 

	def listings_preview
    if !params[:listing][:file].blank? 
		require 'fileutils' 
		@file=params[:listing][:file] 
		Dir.mkdir("#{RAILS_ROOT}/tmp/#{current_user.id.to_s}") if !File.directory?("#{RAILS_ROOT}/tmp/#{current_user.id.to_s}")
		@file_path = "#{RAILS_ROOT}/tmp/#{current_user.id}/#{current_user.id}.csv"
    error_log_file = "#{RAILS_ROOT}/tmp/#{current_user.id}/error.txt"
		File.open(@file_path, 'wb') do |f|
			f.write @file.read
		end		
    
		@listings = []
		reading_assigning_listings
    @listing_results = []
    i = 1
		@listings.each do |listing|
      File.open(error_log_file, 'a') do |f|
      assigning_listing_fields(listing)
      
			if listing['id'] == 0
        assigning_new_listing_fields(listing)         
        if @l.valid?
          @listing_results << "valid"
        else  
          @listing_results << @l.errors
          f.write "Errors in ROW #{i}\n"
          f.write @l.errors['url'].inspect if !@l.errors['url'].nil?
          f.write "\n" if !@l.errors['url'].nil?
          f.write @l.errors['title'].inspect if !@l.errors['title'].nil?
          f.write "\n" if !@l.errors['title'].nil?
          f.write @l.errors['display_url'].inspect if !@l.errors['display_url'].nil?
          f.write "\n" if !@l.errors['display_url'].nil?
          f.write @l.errors['destination_url'].inspect if !@l.errors['destination_url'].nil?
          f.write "\n" if !@l.errors['destination_url'].nil?
          f.write @l.errors['description'].inspect if !@l.errors['description'].nil?
          f.write "\n" if !@l.errors['description'].nil?
          f.write @l.errors['category_id'].inspect if !@l.errors['category_id'].nil?
          f.write "\n" if !@l.errors['category_id'].nil?
          f.write @l.errors['content_type_id'].inspect if !@l.errors['content_type_id'].nil?
          f.write "\n" if !@l.errors['content_type_id'].nil?
          f.write @l.errors['current_rank'].inspect if !@l.errors['current_rank'].nil?
          f.write "---------------------------------------------------------------------------\n"
        end #l.valid
      else
        l = Listing.find_by_id(listing['id'])
          if !l.nil?
            l.url = @listing_url
            l.title = @listing_title
            l.description = @listing_description
            l.short_description = listing['short_description']
            l.display_url = @listing_display_url
            l.destination_url = @listing_destination_url
            l.is_sponsored = listing['is_sponsored']
            
            l.category_id = @listing_category
            l.content_type_id = @listing_content_type
            l.specific_content_type_id = @specific_content_type.id
            l.user_level_id = @user_level.id
            l.geo_location_id = @geo_location.id
            
            l.author_id = @listing_author
            l.editor_id = @listing_editor
            l.editor_comments = listing['editor_comments']
            l.sponsored_item1 = listing['sponsored_item1']
            l.sponsored_item2 = listing['sponsored_item2']
            l.current_rank = @listing_current_rank
            l.editor_rating = listing['editor_rating']
            l.tag_list = listing['tags']
            
            l.activated_from = listing['activated_from']
            l.expiry_date = listing['expiry_date']
            l.featured_top = listing['featured_top']
            l.featured_cat = listing['featured_cat']
            
            l.destination_url_views_count = listing['destination_url_views_count']
            l.summary_listing_page_views_count = listing['summary_listing_page_views_count']
            l.full_listing_page_views_count = listing['full_listing_page_views_count']
            l.sponsored_item1_views_count = listing['sponsored_item1_views_count']
            l.sponsored_item2_views_count = listing['sponsored_item2_views_count']
            
            if l.valid?  
              @listing_results << "valid"
            else
              @listing_results << l.errors             
              f.write "Errors in ROW #{i}\n"
              f.write @l.errors['url'].inspect if !@l.errors['url'].nil?
              f.write "\n" if !@l.errors['url'].nil?
              f.write @l.errors['title'].inspect if !@l.errors['title'].nil?
              f.write "\n" if !@l.errors['title'].nil?
              f.write @l.errors['display_url'].inspect if !@l.errors['display_url'].nil?
              f.write "\n" if !@l.errors['display_url'].nil?
              f.write @l.errors['destination_url'].inspect if !@l.errors['destination_url'].nil?
              f.write "\n" if !@l.errors['destination_url'].nil?
              f.write @l.errors['description'].inspect if !@l.errors['description'].nil?
              f.write "\n" if !@l.errors['description'].nil?
              f.write @l.errors['category_id'].inspect if !@l.errors['category_id'].nil?
              f.write "\n" if !@l.errors['category_id'].nil?
              f.write @l.errors['content_type_id'].inspect if !@l.errors['content_type_id'].nil?
              f.write "\n" if !@l.errors['content_type_id'].nil?
              f.write @l.errors['current_rank'].inspect if !@l.errors['current_rank'].nil?
              f.write "---------------------------------------------------------------------------\n"
            end  #l.update_attributes
          else
            @listing_results << "NO LISTING ID #{listing['id']} EXISTS" 
            f.write "Errors in ROW #{i}\n"
            f.write "NO LISTING ID #{listing['id']} EXISTS" 
            f.write "---------------------------------------------------------------------------\n"
          end
          end
        end #if listing['id'] == 0
        i = i+1
      end
   else
      flash[:error] = "Upload CSV file"
      redirect_to(upload_listings_url)
    end
	end 

def listings_final_upload
  require 'fileutils' 
  @file_path = "#{RAILS_ROOT}/tmp/#{current_user.id}/#{current_user.id}.csv"
  @listings = []	
  reading_assigning_listings
  i = 1
  if !params[:valid_listings].nil?
  @listings.each do |listing|
    if params[:valid_listings].include?(i.to_s)
      
      assigning_listing_fields(listing)
      
        if listing['id'] == 0
        assigning_new_listing_fields(listing)
        @l.save
      else
        l = Listing.find_by_id(listing['id'])
          if !l.nil?            
            l.update_attributes(:url =>@listing_url,:title =>@listing_title,:description =>@listing_description,:short_description => listing['short_description'],:display_url => @listing_display_url,:destination_url =>@listing_destination_url,:is_sponsored => listing['is_sponsored'],:category_id =>@listing_category,:content_type_id =>@listing_content_type,:specific_content_type_id =>@specific_content_type.id,:user_level_id =>@user_level.id,:geo_location_id =>@geo_location.id,:author_id =>@listing_author,:editor_id =>@listing_editor,:editor_comments => listing['editor_comments'],:sponsored_item1 => listing['sponsored_item1'],:sponsored_item2 => listing['sponsored_item2'],:current_rank =>@listing_current_rank,:editor_rating => listing['editor_rating'],:tag_list => listing['tags'],:activated_from => listing['activated_from'],:expiry_date => listing['expiry_date'],:featured_top => listing['featured_top'],:featured_cat => listing['featured_cat'],:destination_url_views_count => listing['destination_url_views_count'],:summary_listing_page_views_count => listing['summary_listing_page_views_count'],:full_listing_page_views_count => listing['full_listing_page_views_count'],:sponsored_item1_views_count => listing['sponsored_item1_views_count'],:sponsored_item2_views_count => listing['sponsored_item2_views_count'])
          end
      end #if listing['id'] == 0
    end #params[:valid_listings].include?(i.to_s)
    i = i+1
  end
      respond_to do |format|
        format.html { redirect_to(admin_listings_url) }
        format.xml  { render :xml => @listing }
      end
  else
    flash[:error] = "Upload CSV again and Select Valid Listings before creating or update listings"
    redirect_to(upload_listings_url)
  end
end  

  def reading_assigning_listings
    FasterCSV.foreach(@file_path, :headers=> true,:converters=> :numeric,:skip_blanks=>true ) do |line|
			@listings<<Hash["id"=>line[0],"url"=>line[1],"title"=>line[2],"description"=>line[3],"category"=>line[4],"content_type"=>line[5],"short_description"=>line[6],"destination_url"=>line[7],"display_url"=>line[8],"tags"=>line[9],"specific_content_type"=>line[10],"user_level"=>line[11],"geo_location"=>line[12],"author_email"=>line[13],"editor_comments"=>line[14],"is_sponsored"=>line[15],"current_rank"=>line[16],"sponsored_item1"=>line[17],"sponsored_item2"=>line[18],"editor_rating"=>line[19],"editor_email"=>line[20],"activated_from"=>line[21],"expiry_date"=>line[22],"featured_top"=>line[23],"featured_cat"=>line[24],"destination_url_views_count"=>line[25],"summary_listing_page_views_count"=>line[26],"full_listing_page_views_count"=>line[27],"sponsored_item1_views_count"=>line[28],"sponsored_item2_views_count"=>line[29]]
		end		
  end  

  def assigning_listing_fields(listing)
      @listing_url = (listing['url'] == 0 ? nil : listing['url'])
      @listing_title = (listing['title'] == 0 ? nil : listing['title'])
      @listing_description = (listing['description'] == 0 ? nil : listing['description'])
      @listing_display_url = (listing['display_url'] == 0 ? nil : listing['display_url'])
      @listing_destination_url = (listing['destination_url'] == 0 ? nil : listing['destination_url'])
      
      @listing_category = (listing['category'] == 0 ? nil : listing['category'])
      
      category = Category.find_by_name(listing['category']) if !@listing_category.nil?
      content_type = ContentType.find_by_name(listing['content_type'])
      
      @listing_category = (!category.nil? ? category.id : nil) if !@listing_category.nil?
      @listing_content_type = (!content_type.nil? ? content_type.id : nil)
      
      @specific_content_type = SpecificContentType.find_or_create_by_name(listing['specific_content_type'])
      @user_level = UserLevel.find_or_create_by_name(listing['user_level'])
      @geo_location = GeoLocation.find_or_create_by_name(listing['geo_location'])
      
      author = User.find_by_email(listing['author_email'])
      @listing_author = (!author.nil? ? author.id : nil)
      
      editor = User.find_by_email(listing['editor_email'])
      @listing_editor = (!editor.nil? ? editor.id : nil)
      
      @listing_current_rank = (listing['current_rank'] == 0 ? nil : listing['current_rank'])
      @listing_activated_form = (listing['activated_from'] == 0 ? nil : listing['activated_from'])
      @listing_expiry_date = (listing['expiry_date'] == 0 ? nil : listing['expiry_date'])
  end  

#Assigning each column value fetched from a single row of a CSV file
  def assigning_new_listing_fields(listing)
     @l = Listing.new(:url=>@listing_url,:title=>@listing_title,:description=>@listing_description,:category_id=>@listing_category,:content_type_id=>@listing_content_type,:short_description=>listing['short_description'],:display_url=>@listing_display_url,:destination_url=>@listing_destination_url,:is_sponsored=>listing['is_sponsored'],:specific_content_type_id=>@specific_content_type.id,:user_level_id=>@user_level.id,:geo_location_id=>@geo_location.id,:author_id=>@listing_author,:editor_id =>@listing_editor,:editor_comments=>listing['editor_comments'],:sponsored_item1=>listing['sponsored_item1'],:sponsored_item2=>listing['sponsored_item2'],:current_rank=>@listing_current_rank,:editor_rating=>listing['editor_rating'],:tag_list=>listing['tags'],:activated_from=>@listing_activated_form,:expiry_date=>@listing_expiry_date,:featured_top=>listing['featured_top'],:featured_cat=>listing['featured_cat'],:destination_url_views_count=>listing['destination_url_views_count'],:summary_listing_page_views_count=>listing['summary_listing_page_views_count'],:full_listing_page_views_count=>listing['full_listing_page_views_count'],:sponsored_item1_views_count=>listing['sponsored_item1_views_count'],:sponsored_item2_views_count=>listing['sponsored_item2_views_count'])
  end  

  def download_logfile    
    filepath = "#{RAILS_ROOT}/tmp/#{current_user.id}/error.txt"
    if File.exists? filepath
     send_file filepath
    else
	   redirect_to admin_listings_url
    end
  end

  def listing_reports
    @categories = Category.find(:all,:conditions=>['parent_id != ? and status = ?',0,1])
    @content_types = ContentType.find(:all,:conditions=>['status = ?',1])
  end  

  def condition_string
      categories = [ ]
      content_types = [ ]
      
      if !params[:categories].blank?
        params[:categories].each do |category|
          categories << category.to_i
        end  
      end
    
      if !params[:content_types].blank?
        params[:content_types].each do |content_type|
          content_types << content_type.to_i
        end  
      end  

      @conditions_string << "listings.category_id in (#{categories.join(",")})" if !params[:categories].blank?
      @conditions_string << "listings.content_type_id in (#{content_types.join(",")})" if !params[:content_types].blank?
    
			@conditions_string << "users.email LIKE '%%#{params[:user][:email]}%%'" if !params[:user][:email].blank?
      @conditions_string << "listings.is_sponsored = #{params[:listing_type]}" if !params[:listing_type].blank?
      
      @conditions_string << "listings.expiry_date >= '#{params[:from_expiry_date].to_date}'" if !params[:from_expiry_date].blank?
      @conditions_string << "listings.expiry_date <= '#{params[:to_expiry_date].to_date}'" if !params[:to_expiry_date].blank?
      
      @conditions_string << "listings.created_at >= '#{params[:from_created_date].to_date}'" if !params[:from_created_date].blank?
      @conditions_string << "listings.created_at <= '#{params[:to_created_date].to_date}'" if !params[:to_created_date].blank?
      
			@search_query = @conditions_string.join(" AND ")
	end


  def import_listings
    @conditions_string = []
    condition_string
    @listings = Listing.find(:all, :conditions =>[@search_query],:include=>[:author],:order=>"listings.created_at desc")

    if !@listings.empty?
    report = StringIO.new
		
		CSV::Writer.generate(report, ',') do |csv|
      
    csv << %w(ID URL TITLE DESCRIPTION CATEGORY CONTENT-TYPE SHORT-DESCRIPTION DESTINATION-URL DISPLAY-URL TAGS SPECIFIC-CONTENT-TYPE USER-LEVEL GEO-LOCATION AUTHOR COMMENTS TYPE RANK SPONSORED-ITEM1 SPONSORED-ITEM2 EDITOR-RATING EDITOR ACTIVATED-FROM EXPIRY-DATE FEATURED-TOP FEATURED-CAT DESTINATION-URL-VIEWS-COUNT SUMMARY-LISTING-PAGE-VIEWS-COUNT FULL-LISTING-PAGE-VIEWS-COUNT SPONSORED-ITEM1-VIEWS-COUNT SPONSORED-ITEM2-VIEWS-COUNT)
		
		@listings.each do |l|
      
    type = (l.is_sponsored == true ? "Sponsored" : "Normal")
    category = !l.category.nil? ? l.category.name : "-"
    content_type = !l.content_type.nil? ? l.content_type.name : "-"
    specific_content_type = !l.specific_content_type.nil? ? l.specific_content_type.name : "-"
    user_level = !l.user_level.nil? ? l.user_level.name : "-"
    geo_location = !l.geo_location.nil? ? l.geo_location.name : "-"
    author = !l.author.nil? ? l.author.email : "-"
    editor = !l.editor.nil? ? l.editor.email : "-"
    
		csv << [l.id,l.url,l.title,l.description.gsub( %r{</?[^>]+?>}, '' ),category,content_type,l.short_description,l.destination_url,l.display_url,l.tag_list,specific_content_type,user_level,geo_location,author,l.editor_comments,type,l.current_rank,l.sponsored_item1,l.sponsored_item2,l.editor_rating,editor,l.activated_from,l.expiry_date,l.featured_top,l.featured_cat,l.destination_url_views_count,l.summary_listing_page_views_count,l.full_listing_page_views_count,l.sponsored_item1_views_count,l.sponsored_item2_views_count]
    end
  
		end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'listings.csv')
    else 
    flash[:error] = "No Listings found"
    redirect_to(listing_reports_url)
    end
  end  
  
  def download_listings
	#report = StringIO.new
	send_file "#{RAILS_ROOT}/doc/sample.csv", :type => 'text/html; charset=utf-8; header=present', :filename => 'sample_listings.csv'
  end
  

 def listing_directory
    session[:content_type_id] = ContentType.find(:first,:conditions=>['placeholder = "Tab" and status = 1']).id
    session[:category_id] = Category.find(:first,:conditions=>['parent_id != ? and status = ?',0,1]).id
    @categories = Category.find(:all,:conditions=>['parent_id = ? and status = ?',0,1])
    @content_types = ContentType.find(:all,:conditions=>['placeholder = "Tab" and status = 1'],:order=>'position asc')
    if params[:cid] && params[:ctypeid]
    session[:category_id] = params[:cid].nil? ? session[:category_id] : params[:cid]
    session[:content_type_id] = params[:ctypeid].nil? ? session[:content_type_id] : params[:ctypeid]
    @listings = Listing.find(:all,:conditions=>['category_id = ? and content_type_id = ?',session[:category_id],session[:content_type_id]])
    else  
    @listings = Listing.find(:all,:conditions=>['featured_cat IS NOT NULL and featured_cat != 0 and status = ?',"Active"],:order=>"featured_cat asc")
    end
  end
  
  def replicate
	  list_dropdowns
	  @listing = Listing.find(params[:id])
  end
  
    def filter_listings
		@listings = [ ]
		@query = [ ]
		
	render :update do |page|
		@query << "is_sponsored = #{params[:filter_type]}" if !params[:filter_type].blank?
		@query << "status = '#{params[:filter_status]}'" if !params[:filter_status].blank?
		@query << "expiry_date >= '#{params[:from_date].to_date}'" if !params[:from_date].blank?
	        @query << "expiry_date <= '#{params[:to_date].to_date}'" if !params[:to_date].blank?
		@query << "users.email LIKE '%%#{params[:user][:email]}%%'" if !params[:user][:email].blank?
		
		@search_query = @query.join(" AND ")
		@listings= Listing.find(:all,:conditions=>[@search_query],:include=>[:author],:order=>'listings.created_at desc')
		page.replace_html 'listing',:partial=>'listing'
	end
  end
  
  #Manage Comments
  
      def manage_comments
	    if request.xhr?
		    render :update do |page|
		    @comments = Comment.paginate :all,:conditions=>['is_approved =? and commentable_type =?',params[:comment],'Listing'],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if !params[:comment].blank?
		    @comments = Comment.paginate :all,:conditions=>['commentable_type = ?','Listing'],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:comment].blank?
		    page.replace_html 'comments',:partial=>'comments'
		    end
	    else
	       @comments = Comment.paginate :all,:conditions=>['commentable_type = ?','Listing'],:order=>"created_at desc",:page=>params[:page],:per_page=>15
	    end
    end
    
    
    def approve_comment
	    @comment = Comment.find(params[:id])
	    @comment.update_attributes(:is_approved =>true)
	    flash[:notice] = 'Comment has been approved.'
	    redirect_to(manage_comments_path)
    end
    
    def disapprove_comment
	    @comment = Comment.find(params[:id])
	    @comment.update_attributes(:is_approved =>false)
	    flash[:notice] = 'Comment has been disapproved.'
	    redirect_to(manage_comments_path)
    end
    
   def destroy_comment
    @comment = Comment.find(params[:id])
    @comment.destroy

    respond_to do |format|
	flash[:notice]='Comment has been deleted.'
      format.html { redirect_to(manage_comments_path) }
      format.xml  { head :ok }
    end
  end
  
   def delete_listing_comments
	if !params[:commit] && !params[:comment].blank?
		params[:comment].each do |comment|
		  comment = Comment.find(comment)
		  comment.destroy 
		end
        flash[:notice] = 'Comment(s) was successfully deleted.'
	elsif params[:commit]
		if params[:commit] == "Approve selected comments"
			approve_selected_comments
		else
			disapprove_selected_comments
		end
	else
		flash[:error] = 'Select Comment(s) to delete.'
      end    
      respond_to do |format|
        format.html { redirect_to(manage_comments_path) }
         format.xml  { render :xml => @comment }
      end
    end
    
    def approve_selected_comments
	if !params[:comment].blank?
	   params[:comment].each do |comment|
	   comment = Comment.find(comment)
	   comment.update_attributes(:is_approved=>true) 
	   flash[:notice] = 'Select Comment(s) has been approved.'
	  end
	else 
	   flash[:error] = 'Select Comment(s) to approve.'
	end
    end
	 
    def disapprove_selected_comments
		if !params[:comment].blank?
		   params[:comment].each do |comment|
		   comment = Comment.find(comment)
		   comment.update_attributes(:is_approved=>false)
		   flash[:notice] = 'Select Comment(s) has been disapproved.'
		  end
		else 
		   flash[:error] = 'Select Comment(s) to disapprove.'
		end
    end



end
