class Admin::MembersController < ApplicationController
	before_filter :admin_login_required
	protect_from_forgery :except=>[:index,:auto_complete_for_user_email]
	layout 'admin'
	auto_complete_for :user, :email
	require "csv"
	
  # GET /members
  # GET /members.xml
  def index
	  
    if request.xhr?
	render :update do |page|
		@members = User.paginate :all,:conditions=>["email LIKE '%%#{params[:email]}%%'"],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:email]
		@members = User.paginate :all,:conditions=>["firstname LIKE '%%#{params[:name]}%%' or lastname LIKE '%%#{params[:name]}%%'"],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:name]
		@members = User.paginate :all,:conditions=>['user_role =?',params[:filter_member_type]],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if !params[:filter_member_type].blank?
		@members = User.paginate :all,:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:filter_member_type] && params[:filter_member_type].blank?
		if params[:filter_category]
		users = User.find :all
		user_ids= [ ]
		users.each do |user|
			if !user.favourite_category_ids.nil?
			if user.favourite_category_ids.include?(params[:filter_category])
				user_ids << user.id
			end
			end
		end
		@members = User.paginate :all,:conditions=>['id IN (?)',user_ids],:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:filter_category]
		@members = User.paginate :all,:order=>"created_at desc",:page=>params[:page],:per_page=>15 if params[:filter_category].blank?
		end
		page.replace_html 'members',:partial=>'members'
	end

   else
       @members = User.paginate :page=>params[:page],:per_page=>15,:order=>'created_at desc'
   end
   @categories = Category.find(:all,:conditions=>['parent_id != ? and status= ?',0,1])

  end

  # GET /members/1
  # GET /members/1.xml
  def show
    @member = User.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @member }
    end
  end


  # DELETE /members/1
  # DELETE /members/1.xml
  def destroy
    @member = User.find(params[:id])
    @member.destroy
     flash[:notice] = 'Member was successfully deleted.'
    respond_to do |format|
      format.html { redirect_to(admin_members_url) }
      format.xml  { head :ok }
    end
  end
  
  def delete_members
		if !params[:commit] == "Export as CSV"
    if !params[:member].blank?
      params[:member].each do |member|
        member = User.find(member)
        member.destroy 
      end
    flash[:notice] = 'Members(s) was successfully deleted.'
    else
    flash[:error] = 'Select Member(s) to delete.'  
    end

    respond_to do |format|
      format.html { redirect_to(admin_members_url) }
      format.xml  { render :xml => @members }
    end
		else
		@users = User.find(:all,:conditions=>['id IN (?)',params[:members]])
		if !@users.empty?
    report = StringIO.new
		
		CSV::Writer.generate(report, ',') do |csv|
      
    csv << %w(ID EMAIL FIRSTNAME LASTNAME TYPE USER-LEVEL GEO-LOCATION LINKEDIN-PROFILE TWITTER-PROFILE SOCIAL-PROFILE IS-CONTENT-CONTRIBUTE ALTERNATE-EMAIL COMPANY COMPANY-URL ADDRESS CITY STATE COUNTRY PHONE FAX FAVOURITE-CATEGORIES IS-NEWSLETTER-NOTIFICATION LOGGEDIN-COUNT)
		
			@users.each do |l|
      
				user_level = !l.user_level.nil? ? l.user_level.name : "-"
				geo_location = !l.geo_location.nil? ? l.geo_location.name : "-"
				is_content_contribute = (l.is_content_contribute == true ? "Yes" : "No")
				country = !l.country.nil? ? l.country.country_name : "-"
				is_newsletter_notification = (l.is_newsletter_notification == true ? "Yes" : "No")
    
				csv << [l.id,l.email,l.firstname,l.lastname,l.user_role,user_level,geo_location,l.linkedin_profile_url,l.twitter_profile_url,l.social_profile_url,is_content_contribute,l.alternate_email,l.company,l.company_url,l.address,l.city,l.user_state,country,l.phone,l.fax,"-",is_newsletter_notification,l.loggedin_count]
			end
  
		end
    report.rewind
    send_data(report.read, :type => 'text/csv; charset=iso-8859-1; header=present', :filename => 'members.csv')
    else 
    flash[:error] = "No Users Selected"
		redirect_to(admin_members_url)
    end			
		end	
   end 
   
   def filter_members
	@members = [ ]
	@query = [ ]
		
	render :update do |page|
		
	@query << "user_role = '#{params[:member_type]}'" if !params[:member_type].blank?
	@query << "email LIKE '%%#{params[:user][:email]}%%'" if !params[:user][:email].blank?
	@query << "(firstname LIKE '%%#{params[:name]}%%' or lastname LIKE '%%#{params[:name]}%%')" if !params[:name].blank?
	@query << "loggedin_count >= '#{params[:from_count]}'" if !params[:from_count].blank?
	@query << "loggedin_count <= '#{params[:to_count]}'" if !params[:to_count].blank?
	if !params[:category].nil?
	if params[:category][:category_name] && !params[:category][:category_name].blank?
	users = User.find :all
	user_ids= [ ]
	users.each do |user|
		if !user.favourite_category_ids.nil?

		if (user.favourite_category_ids.split(",").to_a == params[:category][:category_name].to_a)
			user_ids << user.id
		end
		end
	end
	@query << "id IN (#{user_ids})" if !user_ids.blank?
	end
	end
	@search_query = @query.join(" AND ")
	@members= User.paginate(:all,:conditions=>[@search_query],:order=>'created_at desc', :page => params[:page],  :per_page => 15)
	page.replace_html 'members',:partial=>'members'
	end
   
   end
   

end
