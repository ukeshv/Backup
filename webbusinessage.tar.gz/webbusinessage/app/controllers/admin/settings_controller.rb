class Admin::SettingsController < ApplicationController
	before_filter :admin_login_required
	layout 'admin'
	
  def index
    @setting = AdminSetting.find(:first)
  end
  
  def update
    @setting = AdminSetting.find(params[:id])
	if  @setting.update_attribute('auto_approve_comment',params[:settings][:auto_approve_comment])
	flash[:notice] = 'Settings was successfully updated.'
	 redirect_to(admin_settings_url) 
	end
  end	
  
end
