class Admin::SpecificContentTypesController < ApplicationController
	before_filter :admin_login_required
  layout 'admin'
	
  # GET /specific_content_types
  # GET /specific_content_types.xml
  def index
    load_specific_content_types
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @specific_content_types }
    end
  end	
	
	# GET /specific_content_types/1
  # GET /specific_content_types/1.xml
  def show
    @specific_content_type = SpecificContentType.find(params[:id])
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @content_type }
    end
  end
	
	# GET /specific_content_types/new
  # GET /specific_content_types/new.xml
  def new
    @specific_content_type = SpecificContentType.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @specific_content_type }
    end
  end	
	
	# POST /specific_content_types
  # POST /specific_content_types.xml
  def create
    @specific_content_type = SpecificContentType.new(params[:specific_content_type])
    
    respond_to do |format|
      if @specific_content_type.save
      flash[:notice] = 'SpecificContentType was successfully created.'
      format.html { redirect_to(admin_specific_content_types_url) }
        format.xml  { render :xml => @specific_content_type, :status => :created, :location => @specific_content_type }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @specific_content_type.errors, :status => :unprocessable_entity }
      end
    end
  end	
	
	# GET /specific_content_types/1/edit
  def edit
    @specific_content_type = SpecificContentType.find(params[:id])
  end
	
	# PUT /specific_content_types/1
  # PUT /specific_content_types/1.xml
  def update
    @specific_content_type = SpecificContentType.find(params[:id])

    respond_to do |format|
      if @specific_content_type.update_attributes(params[:specific_content_type])
        flash[:notice] = 'SpecificContentType was successfully updated.'
        format.html { redirect_to(admin_specific_content_types_url) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @specific_content_type.errors, :status => :unprocessable_entity }
      end
    end
  end	
	
	# DELETE /specific_content_types/1
  # DELETE /specific_content_types/1.xml
  def destroy
    @specific_content_type = SpecificContentType.find(params[:id])
    @specific_content_type.destroy
    flash[:notice] = "SpecificContentType was successfully deleted."
    respond_to do |format|
      format.html { redirect_to(admin_specific_content_types_url) }
      format.xml  { head :ok }
    end
  end
  
	def delete_specific_content_types
    if !params[:specific_content_type].blank?
      params[:specific_content_type].each do |specific_content_type|
        specific_content_type = SpecificContentType.find(specific_content_type)
        specific_content_type.destroy 
      end
    flash[:notice] = 'SpecificContentType(s) was successfully deleted.'
    else
    flash[:error] = 'Select SpecificContentType(s) to delete.'      
    end
    respond_to do |format|
      format.html { redirect_to(admin_specific_content_types_url) }
      format.xml  { render :xml => @specific_content_types }
    end
   end 
	
	def load_specific_content_types
    sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort]
    @specific_content_types = SpecificContentType.paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}"
  end 

end
