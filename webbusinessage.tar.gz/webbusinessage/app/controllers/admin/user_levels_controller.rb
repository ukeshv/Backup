class Admin::UserLevelsController < ApplicationController
	before_filter :admin_login_required
  layout 'admin'
	
  # GET /user_levels
  # GET /user_levels.xml
  def index
    load_user_levels
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @user_levels }
    end
  end	
	
	# GET /user_levels/1
  # GET /user_levels/1.xml
  def show
    @user_level = UserLevel.find(params[:id])
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @user_level }
    end
  end
	
	# GET /user_levels/new
  # GET /user_levels/new.xml
  def new
    @user_level = UserLevel.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @user_level }
    end
  end	
	
	# POST /user_levels
  # POST /user_levels.xml
  def create
    @user_level = UserLevel.new(params[:user_level])
    
    respond_to do |format|
      if @user_level.save
      flash[:notice] = 'UserLevel was successfully created.'
      format.html { redirect_to(admin_user_levels_url) }
        format.xml  { render :xml => @user_level, :status => :created, :location => @user_level }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @user_level.errors, :status => :unprocessable_entity }
      end
    end
  end	
	
	# GET /user_levels/1/edit
  def edit
    @user_level = UserLevel.find(params[:id])
  end
	
	# PUT /user_levels/1
  # PUT /user_levels/1.xml
  def update
    @user_level = UserLevel.find(params[:id])

    respond_to do |format|
      if @user_level.update_attributes(params[:user_level])
        flash[:notice] = 'UserLevel was successfully updated.'
        format.html { redirect_to(admin_user_levels_url) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @user_level.errors, :status => :unprocessable_entity }
      end
    end
  end	
	
	# DELETE /user_levels/1
  # DELETE /user_levels/1.xml
  def destroy
    @user_level = UserLevel.find(params[:id])
    @user_level.destroy
    flash[:notice] = "UserLevel was successfully deleted."
    respond_to do |format|
      format.html { redirect_to(admin_user_levels_url) }
      format.xml  { head :ok }
    end
  end
  
	def delete_user_levels
    if !params[:user_level].blank?
      params[:user_level].each do |user_level|
        user_level = UserLevel.find(user_level)
        user_level.destroy 
      end
    flash[:notice] = 'UserLevel(s) was successfully deleted.'
    else
    flash[:error] = 'Select UserLevel(s) to delete.'  
    end
    respond_to do |format|
      format.html { redirect_to(admin_user_levels_url) }
      format.xml  { render :xml => @user_levels }
    end
   end 
	
	def load_user_levels
    sort_field = params[:sort].nil? ? 'created_at desc' : params[:sort]
    @user_levels = UserLevel.paginate :page=>params[:page],:per_page=>15,:order=>"#{sort_field}"
  end 
end
