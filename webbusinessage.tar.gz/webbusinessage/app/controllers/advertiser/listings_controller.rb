class Advertiser::ListingsController < ApplicationController
     before_filter :check_is_advertiser
     protect_from_forgery :except=>[:calc_expiry_date,:totalprice]
     layout 'advertiser'
	
  def website_url
    advertiser = current_user
    return unless request.post?
    web_url = params[:advertiser_review_website][:website].include?('http://') ? params[:advertiser_review_website][:website] : "http://"+params[:advertiser_review_website][:website]
	    @advertiser_review_website = AdvertiserReviewWebsite.new
	    @advertiser_review_website.website = web_url
	    @advertiser_review_website.comment= params[:advertiser_review_website][:comment]
	    if @advertiser_review_website.save
	    UserMailer.deliver_advertiser_website(@advertiser_review_website.website,@advertiser_review_website.comment,advertiser)
	    redirect_to :action=>'web_url_show',:id=>@advertiser_review_website.id
	    else
	    render :action=>:website_url
	    end
  end
  
  def web_url_show
	  @advertiser = AdvertiserReviewWebsite.find(params[:id])
  end
  
  	
  def  submitted_listings
	   @submitted_listings = Listing.paginate :all,:conditions=>['author_id = ?',current_user.id],:order=>"created_at desc",:page=>params[:page],:per_page=>15
  end

  def submit_listing
	list_dropdowns
	@listing = Listing.new
	return unless request.post?
	  @listing = Listing.new(params[:listing])
	  @listing.author_id = current_user.id
	  @listing.editor_id = current_user.id
	  @listing.is_sponsored = 1
	  @listing.status = 'Draft'	
	  if @listing.save              
	    @listing.attachings.last.update_attributes(:is_primary => true) if (!@listing.attachings.blank? || !@listing.attachings.empty?) 
	    flash[:notice] = 'Listing was successfully created.'
	    redirect_to :action=>'submitted_listings'
	  else
		  render :action=>'submit_listing'
	  end
	  
  end
  
    def list_dropdowns
    @categories = Category.find(:all,:conditions=>['parent_id != ? and status = ?',0,1])
    @content_types = ContentType.find(:all,:conditions=>['status = ?',1])
    @specific_content_types = SpecificContentType.find(:all,:conditions=>["status = ?",true])
    @geo_locations = GeoLocation.find(:all)
    @user_levels = UserLevel.find(:all)

  end
  
  def edit_submit_listing
	  list_dropdowns
	@listing = Listing.find(params[:id])  
  end
  
  
  def update_submit_listing
	  list_dropdowns
	  @listing = Listing.find(params[:id])  
	 if @listing.update_attributes(params[:listing])
		flash[:notice] = 'Listing was successfully updated.'
		redirect_to :action=>'submitted_listings'
	else
		render :action=>'edit_submit_listing',:id=>@listing.id
	end
	
  end
  
  
  def check_is_advertiser
	if current_user.user_role == 'Admin'
	   redirect_to users_path
	end
end

def destroy
	@submitted_listing = Listing.find(params[:id])
	@submitted_listing.destroy
	redirect_to :action=>'submitted_listings'
end

def delete_submitted_listings
	if !params[:submitted_listing].blank?
		params[:submitted_listing].each do |listing|
		  listing = Listing.find(listing)
		  listing.destroy 
		end
		flash[:notice] = 'Listing(s) was successfully deleted.'
      else  
        flash[:error] = 'Select Listing(s) to delete.'
      end    
	redirect_to :action=>'submitted_listings'
end

def calc_expiry_date
	render :update do |page|
		@d =  params[:date_val]
		@d1 = @d.to_date
		if params[:month_val] ==  "6"
			@d2 = @d1.advance(:months => 6)
		else
				@d2 = @d1.advance(:months =>12)
		end
			@date = @d2.strftime('%B %d, %Y')

		 page['listing[expiry_date]'].value =  "#{@date}"
	end
end

def totalprice
	render :update do |page|
		if params[:add]
		@total_price = params[:list_price].to_i + params[:add].to_i
		@hidden_total_price = @total_price.abs
		@total = "$ #{@hidden_total_price}"
		else
		@total_price = params[:list_price].to_i - params[:sub].to_i	
		@hidden_total_price = @total_price.abs
		@total = "$ #{@hidden_total_price}"
		end
		page.replace_html 'replace_price', @total
		page[:total].value = @hidden_total_price
	end
	
end

end
