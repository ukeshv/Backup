class AdvertisersController < ApplicationController
	  layout 'home'
	protect_from_forgery :except=>[:update_upgrade]
	
	def new
	  if !logged_in?
	  @countries = Country.find(:all)
	  else
		redirect_back_or_default(users_path)
	  end
	end	
  
  	def create
	@countries = Country.find(:all)
	@user = User.new(params[:user])
	@user.is_advertiser = 1
	
	    if  @user.valid_with_captcha? && @user.valid? 
		    @user.save
		    @user.update_attributes(:state=>'active',:activated_at=>Time.now)
		    self.current_user = @user
		    redirect_to(advertiser_details_path(@user.id))
	    else
		    render :action=>'new'
	    end
	 end
	 
	 def details
			@geo_locations = GeoLocation.find(:all)
			@user_levels = UserLevel.find(:all)
			@countries = Country.find(:all)
			@sub_categories = Category.find(:all,:conditions=>['parent_id != ? and status = ?',0,1])
			@user = User.find_by_id(params[:userid])
			@selected_categories = @user.favourite_category_ids.split(",")  if @user.favourite_category_ids
		end	
   
	 def update_details
			@user = User.find_by_id(params[:userid])
			@user.update_attributes(params[:user])
			@user.favourite_category_ids = params[:user][:favourite_category_ids].join(',').to_s if params[:user] && !params[:user][:favourite_category_ids].nil? && params[:user][:favourite_category_ids].length > 0
			@user.save
			flash[:notice] = "Successfully Updated"
			redirect_to users_path
	 end		

	
	def upgrade
		@countries = Country.find(:all)
		@user = User.find_by_id(params[:userid])
	end

	def update_upgrade
		@countries = Country.find(:all)
		@user = current_user
				@user.is_advertiser = 1
		      if @user.update_attributes(params[:user])
			  render :update do |page|
			  page.redirect_to(users_path)
			  end
		      else
			render :update do |page|
		          for h in @user.errors
			    if !@user.errors["#{h[0]}"].nil?
				page.show "#{h[0]}_user"              
				page.replace_html "#{h[0]}_user","#{h[1]}"
			    end          
				page.hide "company_user" if @user.errors['company'].nil?
				page.hide "address_user" if @user.errors['address'].nil?
				page.hide "city_user" if @user.errors['city'].nil?
				page.hide "user_state_user" if @user.errors['user_state'].nil?
				page.hide "country_id_user" if @user.errors['country_id'].nil?
				page.hide "phone_user" if @user.errors['phone'].nil?
				page.hide "company_url_user" if @user.errors['company_url'].nil?
			 end
		    end
		    end
	    end	
	  

	def advertise
		@meta_title = META_CONFIG[:advertise_title]
    @meta_desc = META_CONFIG[:advertise_desc]
    @meta_keywords = META_CONFIG[:advertise_keywords]
	end	

end
