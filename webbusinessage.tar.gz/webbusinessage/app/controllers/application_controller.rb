class ApplicationController < ActionController::Base
  include ExceptionNotifiable
  include AuthenticatedSystem
  include RoleRequirementSystem
  include SimpleCaptcha::ControllerHelpers
  include OpenIdAuthentication
  
  helper :all # include all helpers, all the time
  protect_from_forgery :secret => 'b0a876313f3f9195e9bd01473bc5cd06'
  filter_parameter_logging :password, :password_confirmation
  rescue_from ActiveRecord::RecordNotFound, :with => :record_not_found
  
  before_filter :is_admin
  
  $featured_positions = [1,2,3,4,5,6,7,8,9,10]  
  
  def is_admin
    if logged_in?
      @is_admin = (current_user.user_role == 'Admin') ? true : false
    else
      @is_admin = false
    end
  end  
  
  def admin_login_required
    if logged_in?
      if !(current_user.user_role == 'Admin')
        redirect_to '/'
      end
    else
      redirect_to '/'
    end   
  end  
  
    def savelist
	  render :update do |page|
		  listing = Listing.find(params[:id])
		  current_user.has_favorite(listing)
		  page.hide "save_list_#{listing.id}"
		  page.show "list_#{listing.id}"
	  end
  end
  
    def saveblog
	  render :update do |page|
		  blog = Blog.find(params[:id])
		  current_user.has_favorite(blog)
		  page.hide "save_blog_#{blog.id}"
		  page.show "blog_#{blog.id}"
		  page.show "blogtext_#{blog.id}"
		  page.hide "save_blogtext_#{blog.id}"
	  end
  end

  
  
  protected
  
  # Automatically respond with 404 for ActiveRecord::RecordNotFound
  def record_not_found
    render :file => File.join(RAILS_ROOT, 'public', '404.html'), :status => 404
  end
end

