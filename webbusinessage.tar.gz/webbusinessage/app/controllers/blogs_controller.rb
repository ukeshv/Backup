class BlogsController < ApplicationController
	layout 'home'
        protect_from_forgery :except=>[:add_rating,:saveblog]
        before_filter :login_required,:only=>[:saveblog] 


	def index
		@meta_title = META_CONFIG[:blogs_index_title]
    @meta_desc = META_CONFIG[:blogs_index_desc]
    @meta_keywords = META_CONFIG[:blogs_index_keywords]
		@featured_blogs = Blog.featured_blogs_in_bloghome_page
	  @recent_blogs = Blog.recent_blogs_in_bloghome_page.paginate :page=>params[:page],:per_page=>10
	end
    
    def categories
	@category = Category.find_by_category_permalink(params[:cname])
	if @category
	@meta_title = @category.blog_metatag_title	
	@blogs = Blog.blogs_in_category(@category.id)
	else
		redirect_to(blogs_path)
  end
  end
    	
	def show
    @blog = Blog.find_by_url(params[:url])
    if @blog
   	load_comments
		@recent_blogs = Blog.find(:all,:conditions=>['id !=? and status=?',@blog.id,'Active'],:limit=>3,:order=>'created_at desc')
		categories = @blog.categories.collect{|x| x.id}
		@blog_categories = BlogCategory.find(:all,:conditions=>['category_id IN (?)',categories]).collect{|x| x.blog_id}
		@related_blogs = Blog.find(:all,:conditions=>['id IN (?) and id !=? and status=?',@blog_categories,@blog.id,'Active'],:limit=>3,:order=>'created_at desc')
		@rating_open=true  if @blog.rated_by?(User.find(current_user.id) )==false if logged_in?
		@rating=Rating.find_by_rater_id_and_rated_id_and_rated_type(current_user.id,@blog,'Blog') if logged_in?
		@rating=@rating.rating if @rating if logged_in?
		@blog.is_viewed(current_user.id) if logged_in?
    @trackback_urls = []
    @blog.trackback_urls.split(',').each do |x|
      @trackback_urls << x  
    end
      @meta_title = @blog.title
      @meta_desc = @blog.short_description
      @meta_keywords = @blog.tag_list
			else
				redirect_to(blogs_url)
	end
	end
	
   def add_rating
    @blog= Blog.find(params[:blog])
    @user=User.find(current_user.id)
    @blog.rate(params[:id],@user)
   # @listing.rating_for_listing=@listing.rating_average
          @blog.save

    render :update do |page|     
      #page.replace_html 'rating_div','<font color="green">Thanks for Rating</font>'
      page.replace_html "rating_div",:partial=>"rated_stars",:locals=>{:blog=>@blog}
      page.replace_html "rating_title","Rated"
      page.replace_html "overallrating",:partial=>"overall_rating",:locals=>{:listing=>@blog}
      #page.insert_html('bottom', 'rating_div',"<font color='green'>Thanks for Rating</font>")
    end
   end

	
  def add_comment
  if !logged_in?  
  @blog = Blog.find(params[:id])
			if @blog
			load_comments
			@comment = Comment.new(params[:comment])
			@comment.loggedin = 1 if !logged_in?
						if @comment.valid?
						@comment.save
						@blog.comments << @comment
							load_comments
								render :update do |page|
								page[:comments_comment].value =  ""
								page[:comment_firstname].value =  ""
								page[:comment_lastname].value =  ""
								page[:comment_email].value = ""
								page[:firstname_comment].innerHTML =  ""
								page[:lastname_comment].innerHTML =  ""
								page[:email_comment].innerHTML =  ""
								page[:comment_comment].innerHTML =  ""
								session[:firstname] = params[:comment][:firstname]  if params[:agree_member]
								session[:lastname] = params[:comment][:lastname]  if params[:agree_member]
								session[:email] = params[:comment][:email]  if params[:agree_member]
								session[:comment] = params[:comment][:comment]  if params[:agree_member]
								session[:contact] =[ ]
								session[:contact] << [session[:firstname],session[:lastname],session[:email]]

								page.redirect_to(signup_path) if params[:agree_member]
								page.replace_html "list_comments",:partial=>"blog_comments"
								@comments_count = !@admin_setting.auto_approve_comment ? @approved_comments.length : @comments.length
								page.replace_html "comments_count","<p class='commentsText'><a href='#'> #{@comments_count} Comment(s)</a></p>"
								page.show 'message'	
								end  
						else
							render :update do |page|
										for h in @comment.errors
											if !@comment.errors["#{h[0]}"].nil?
											page.show "#{h[0]}_comment"              
											page.replace_html "#{h[0]}_comment","#{h[1]}"
											end          
										page.hide "firstname_comment" if @comment.errors['firstname'].nil?
										page.hide "lastname_comment" if @comment.errors['lastname'].nil?
										page.hide "email_comment" if @comment.errors['email'].nil?
										page.hide "comment_comment" if @comment.errors['comment'].nil?
										page.hide 'message'	
										end
							end     
					end  
				else
				redirect_to(users_path)
				end
    else
     @blog = Blog.find(params[:id])
				if @blog
					 load_comments
				 @comment = Comment.new(params[:comment])
						if @comment.valid?
							 @comment.user_id = current_user.id
							 @comment.firstname = current_user.firstname
							 @comment.lastname = current_user.lastname
							 @comment.email = current_user.email
							@comment.save
							@blog.comments << @comment
							 load_comments
									render :update do |page|
									page[:comments_comment].value =  ""
									page[:comment_comment].innerHTML =  ""
									page.replace_html "list_comments",:partial=>"blog_comments"
									@comments_count = !@admin_setting.auto_approve_comment ? @approved_comments.length : @comments.length
									page.replace_html "comments_count","<p class='commentsText'><a href='#'> #{@comments_count} Comment(s)</a></p>"
									page.show 'message'	
									end 
					 else
							 render :update do |page|
										 for h in @comment.errors
													if !@comment.errors["#{h[0]}"].nil?
													page.show "#{h[0]}_comment"              
													page.replace_html "#{h[0]}_comment","#{h[1]}"
										page.hide 'message'	
													end          
										 end  
							 end  
					 end
				else
						redirect_to(users_path)
				end
   end 
  end
  
  def load_comments
	@admin_setting = AdminSetting.find(:first)
	@approved_comments = @blog.comments.find(:all,:conditions=>['is_approved=?',1],:order=>'created_at desc')
	@comments = @blog.comments.find(:all,:order=>'created_at desc')
  end
  
  def rss
    @blogs = Blog.find(:all,:conditions=>['status = ?',"Active"],:order=>'created_at desc')
    	render :layout=>false
   end 
	
end
