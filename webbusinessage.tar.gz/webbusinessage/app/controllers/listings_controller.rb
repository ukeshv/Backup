class ListingsController < ApplicationController
	  layout :change_layout
          protect_from_forgery :except=>[:add_rating,:update_destination_count]
	  
   def index
    @meta_title = META_CONFIG[:listings_index_title]
    @meta_desc = META_CONFIG[:listings_index_desc]
    @meta_keywords = META_CONFIG[:listings_index_keywords]
    session[:content_type_id] = ContentType.find(:first,:conditions=>['placeholder = "Tab" and status = 1']).id
    session[:category_id] = Category.find(:first,:conditions=>['parent_id != ? and status = ?',0,1]).id
    @content_types = ContentType.find(:all,:conditions=>['placeholder = ? and status =?','Tab',1],:order=>'position asc')
    @sponsored_listings = Listing.sponsored_listings_in_listingspage(session[:category_id],session[:content_type_id])
    @listings = Listing.normal_listings_in_listingspage(session[:category_id],session[:content_type_id]).paginate :page=>params[:page],:per_page=>10
    Listing.update_listings_count(@sponsored_listings)
    Listing.update_listings_count(@listings)
   end

  def list_by_category_contenttype
        session[:content_type_id] = ContentType.find(:first,:conditions=>['placeholder = "Tab" and status = 1']).id
        session[:category_id] = Category.find(:first,:conditions=>['parent_id != ? and status = ?',0,1]).id
	@content_types = ContentType.find(:all,:conditions=>['placeholder = ? and status =?','Tab',1],:order=>'position asc')
        if params[:cid] && params[:ctypeid]
					session[:category_id] = params[:cid].nil? ? session[:category_id] : params[:cid]
					session[:content_type_id] = params[:ctypeid].nil? ? session[:content_type_id] : params[:ctypeid]
	@sponsored_listings = Listing.sponsored_listings_in_listingspage(session[:category_id],session[:content_type_id])
	@listings = Listing.normal_listings_in_listingspage(session[:category_id],session[:content_type_id]).paginate :page=>params[:page],:per_page=>10
	Listing.update_listings_count(@sponsored_listings)
	Listing.update_listings_count(@listings)
	else  
	@sponsored_listings =Listing.find(:all,:conditions=>['is_sponsored = ? and status=? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',1,'Active',(Date.today),(Date.today)],:limit=>3,:order=>'current_rank asc')   
	@listings = Listing.paginate :all,:conditions=>['is_sponsored = ? and status=? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',0,'Active',(Date.today),(Date.today)],:page=>params[:page],:per_page=>10,:order=>'featured_cat asc' 
	Listing.update_listings_count(@sponsored_listings)
	Listing.update_listings_count(@listings)
  end
        render :action=>'index'
  end

  def show
    @listing = Listing.find_by_url(params[:url])
    if @listing
    session[:category_id] = @listing.category_id
    session[:content_type_id] = @listing.content_type_id
    load_comments
    @admin_setting = AdminSetting.find(:first)
    @active_media = @listing.attachings.find_by_is_primary(true)
    @listing_attachings = @listing.attachings
    @title = @listing.title
    @description = @listing.description
    @keywords = @listing.tag_list
    @content_types = ContentType.find(:all,:conditions=>['placeholder = ? and status =?','Tab',1],:order=>'position asc')	
    @rating_open=true  if @listing.rated_by?(User.find(current_user.id) )==false if logged_in?
    @rating=Rating.find_by_rater_id_and_rated_id_and_rated_type(current_user.id,@listing,'Listing') if logged_in?
    @rating=@rating.rating if @rating if logged_in?
    @listing.is_viewed(current_user.id) if logged_in?
    @listing.update_attribute("full_listing_page_views_count",@listing.full_listing_page_views_count.nil? ? @listing.full_listing_page_views_count=1 : @listing.full_listing_page_views_count+1) 
      @meta_title = @listing.title
      @meta_desc = @listing.short_description
      @meta_keywords = @listing.tag_list
			else
				redirect_to(listings_url)
    end
  end

	
  def add_rating
    @listing= Listing.find(params[:listing])
    @user=User.find(current_user.id)
    @listing.rate(params[:id],@user)
   # @listing.rating_for_listing=@listing.rating_average
          @listing.save

    render :update do |page|     
      #page.replace_html 'rating_div','<font color="green">Thanks for Rating</font>'
      page.replace_html "rating_div",:partial=>"rated_stars",:locals=>{:listing=>@listing}
      page.replace_html "rating_title","<li> Rated </li>"
      page.replace_html "overallrating",:partial=>"overall_rating",:locals=>{:listing=>@listing}
     # page.replace_html "overallrating",:partial=>"overall_rating",:locals=>{:listing=>@listing}
      #page.insert_html('bottom', 'rating_div',"<font color='green'>Thanks for Rating</font>")
    end
end


  def add_comment
  if !logged_in?  
  @listing = Listing.find(params[:id])
  @comment = Comment.new(params[:comment])
  @admin_setting = AdminSetting.find(:first)
  @comment.loggedin = 1 if !logged_in?
    if @comment.valid?
    @comment.save
    @listing.comments << @comment
    load_comments
      render :update do |page|
      page[:comments_comment].value =  ""
      page[:comment_firstname].value =  ""
      page[:comment_lastname].value =  ""
      page[:comment_email].value = ""
      page[:firstname_comment].innerHTML =  ""
      page[:lastname_comment].innerHTML =  ""
      page[:email_comment].innerHTML =  ""
      page[:comment_comment].innerHTML =  ""
	session[:firstname] = params[:comment][:firstname]  if params[:agree_member]
	session[:lastname] = params[:comment][:lastname]  if params[:agree_member]
	session[:email] = params[:comment][:email]  if params[:agree_member]
	session[:comment] = params[:comment][:comment]  if params[:agree_member]
	session[:contact] =[ ]
	session[:contact] << [session[:firstname],session[:lastname],session[:email]]
      page.redirect_to(signup_path) if params[:agree_member]
      page.replace_html 'list_comments',:partial=>'listing_comments'
      page.show 'message'	

      end  
    else
      render :update do |page|
        for h in @comment.errors
          if !@comment.errors["#{h[0]}"].nil?
          page.show "#{h[0]}_comment"              
          page.replace_html "#{h[0]}_comment","#{h[1]}"
          end          
        page.hide "firstname_comment" if @comment.errors['firstname'].nil?
        page.hide "lastname_comment" if @comment.errors['lastname'].nil?
        page.hide "email_comment" if @comment.errors['email'].nil?
        page.hide "comment_comment" if @comment.errors['comment'].nil?
	page.hide 'message'
        end
      end     
    end  
   else
     @listing = Listing.find(params[:id])
     @comment = Comment.new(params[:comment])
     if @comment.valid?
       @comment.user_id = current_user.id
       @comment.firstname = current_user.firstname
       @comment.lastname = current_user.lastname
       @comment.email = current_user.email
      @comment.save
      @listing.comments << @comment
      load_comments
      render :update do |page|
      page[:comments_comment].value =  ""
      page[:comment_comment].innerHTML =  ""
      page.replace_html 'list_comments',:partial=>'listing_comments'
      page.show 'message'	
      end 
     else
       render :update do |page|
         for h in @comment.errors
          if !@comment.errors["#{h[0]}"].nil?
          page.show "#{h[0]}_comment"              
          page.replace_html "#{h[0]}_comment","#{h[1]}"
	  page.hide 'message'
          end          
         end  
       end  
     end        
   end 
  end

  def load_comments
	@admin_setting = AdminSetting.find(:first)
	@approved_comments = @listing.comments.find(:all,:conditions=>['is_approved=?',1],:order=>'created_at desc')
	@comments = @listing.comments.find(:all,:order=>'created_at desc')
  end

  
    def change_layout
        (action_name=="index" || action_name=="show" || action_name == "categories" || action_name =='list_by_category_contenttype') ? "home" : "webbusinessage"
   end

 def update_destination_count
	 render :update do |page|
	 @listing = Listing.find_by_id(params[:id])
	 @listing.update_attribute("destination_url_views_count",@listing.destination_url_views_count.nil? ? @listing.destination_url_views_count=1 : @listing.destination_url_views_count+1) 
	 end
 end
 
 end
