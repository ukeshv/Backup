class SessionsController < ApplicationController
  skip_before_filter :verify_authenticity_token, :only => :create
  protect_from_forgery :except=>[:set_image]
  layout :change_layout
  
  def index
    @meta_title = META_CONFIG[:sessions_index_title]
    @meta_desc = META_CONFIG[:sessions_index_desc]
    @meta_keywords = META_CONFIG[:sessions_index_keywords]
    @listings = Listing.normal_listings_in_home
    @sponsored_listings = Listing.sponsored_listings_in_home
    @featured_blogs = Blog.featured_blogs_in_home_page
    @recent_blogs = Blog.recent_blogs_in_home_page.paginate 
    redirect_back_or_default(users_path) if logged_in?
  end  

  def new
    redirect_back_or_default(users_path) if logged_in?
  end

  def create
    #logout_keeping_session!
    if using_open_id?
      open_id_authentication
    else
      password_authentication
    end
  end

  def destroy
    logout_killing_session!
    flash[:notice] = "You have been logged out."
    redirect_back_or_default(root_path)
  end
  
  def open_id_authentication
    authenticate_with_open_id do |result, identity_url|
      if result.successful? && self.current_user = User.find_by_identity_url(identity_url)
        successful_login
      else
        flash[:error] = result.message || "Sorry no user with that identity URL exists"
        @remember_me = params[:remember_me]
        render :action => :new
      end
    end
  end
  
  def change_layout
        (action_name=="index" || action_name =="new" || action_name =="create" ) ? "home" : "webbusinessage"
  end

  def set_image
    i=params[:id]
    file = "/partial/img"+i
    render :update do |page|
      page.replace_html 'test',:partial=>file
    end
  end

  protected
  
  def password_authentication
    user = User.authenticate(params[:email], params[:password])
    if user
      self.current_user = user
      loggedin_count = !current_user.loggedin_count.nil? ? current_user.loggedin_count : 0
      current_user.update_attributes(:loggedin_count=>loggedin_count+1)
      successful_login
    else
      note_failed_signin
      @email = params[:email]
      @remember_me = params[:remember_me]
      render :action => :new
    end
  end
  
  def successful_login
    new_cookie_flag = (params[:remember_me] == "1")
    handle_remember_cookie! new_cookie_flag
    redirect_back_or_default(users_path)
    flash.now[:notice] = "Logged in successfully"
  end

  def note_failed_signin
    flash.now[:error] = "Email and/or password you entered is invalid."
    logger.warn "Failed login for '#{params[:email]}' from #{request.remote_ip} at #{Time.now.utc}"
  end
end
