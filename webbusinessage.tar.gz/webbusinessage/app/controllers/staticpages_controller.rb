class StaticpagesController < ApplicationController
	layout 'home'
	
	def aboutus
		@meta_title = META_CONFIG[:aboutus_title]
    @meta_desc = META_CONFIG[:aboutus_desc]
    @meta_keywords = META_CONFIG[:aboutus_keywords]
	end
	
	def personal_marketing_ebook		
	end	
	
	def download_marketing_ebook
		send_file("#{RAILS_ROOT}/public/downloads/WebBusinessAge_Personal_Marketing.pdf",:disposition => 'disposition')
	end	
	
	def terms
	end
	
	def privacy_policy
	end
	
	def contactus
		 return unless request.post?
		 session[:firstname] = params[:firstname]
		 session[:lastname] = params[:lastname]
		 session[:email] = params[:email]
		 session[:subject_msg] = params[:subject]
		 session[:purpose] = params[:purpose]
		 session[:comment] = params[:comment]
		 UserMailer.deliver_contact_us(params[:firstname],params[:email],params[:subject],params[:purpose],params[:comment])
		 session[:contact] = [ ]
		 session[:contact] << [session[:firstname],session[:lastname],session[:email]]
		 flash.now[:notice] = "Your Mail has been sent to admin"
		 redirect_to after_contactus_path
	end
	
	def after_contactus
		 @find_user = User.find_by_email(session[:contact][0][2])
		 return unless request.post?
		 session[:contact] = nil
		 redirect_to root_path
	end	 
	
	def media_kit_download
		send_file("#{RAILS_ROOT}/public/downloads/MediaKit.pdf",:disposition => 'disposition')
end

	def aboutus_download
		send_file("#{RAILS_ROOT}/public/downloads/Features.pdf",:disposition => 'disposition')
	end
	
	
end
