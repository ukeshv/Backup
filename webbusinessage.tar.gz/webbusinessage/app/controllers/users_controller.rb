class UsersController < ApplicationController
  skip_before_filter :verify_authenticity_token, :only => :create
  before_filter :login_required,:only=>[:index,:myprofile,:savelist] 
  before_filter :edit_permission,:only=>[:edit,:show]
  protect_from_forgery :except=>[:savelist,:subscribe_email]
  layout :change_layout
  
  def index
    @listings = Listing.normal_listings_in_home
    @sponsored_listings = Listing.sponsored_listings_in_home
    @featured_blogs = Blog.featured_blogs_in_home_page
    @recent_blogs = Blog.recent_blogs_in_home_page.paginate 
 end  
 
  def show
	@user = User.find_by_id(params[:id])
	@sub_categories = Category.find(:all,:conditions=>['parent_id != ? and status = ?',0,1])
	@selected_categories = @user.favourite_category_ids.split(",")  if @user.favourite_category_ids
  end             
  
  def categories
  @category = Category.find_by_category_permalink(params[:cname])
  if @category
			@featured_blogs = Blog.featured_blogs_based_on_category(@category.id)
			@recent_blogs = Blog.recent_blogs_based_on_category(@category.id)
			@listings = Listing.normal_listings_based_on_category_in_home(@category.id).paginate :page=>params[:page],:per_page=>10
			@sponsored_listings = Listing.sponsored_listings_based_on_category_in_home(@category.id)
			@meta_title = @category.metatag_title
			@meta_desc = @category.metatag_desc
			@meta_keywords = @category.metatag_keywords
	else
			redirect_to(users_path)
	end
  end
  
  def new
		if !logged_in?
     @user = User.new 
		else
			redirect_to(root_path)
	  end
  end
  
	def edit_permission
		if logged_in? && User.exists?(params[:id])
			user = User.find(params[:id])
			if (current_user.user_role == 'Admin')
				return
			elsif user.id == current_user.id
				return
			else
				redirect_to(login_path)
			end
		else
			redirect_to(login_path)
			end			
	end    
  
  def edit
    @geo_locations = GeoLocation.find(:all)
    @user_levels = UserLevel.find(:all)
    @countries = Country.find(:all)
    @sub_categories = Category.find(:all,:conditions=>['parent_id != ? and status = ?',0,1])
    @user = User.find_by_id(params[:id])
    @selected_categories = @user.favourite_category_ids.split(",")  if @user.favourite_category_ids
  end
  
 
  def create
   #logout_keeping_session!
    if using_open_id?
      authenticate_with_open_id(params[:openid_url], :return_to => open_id_create_url, 
        :required => [:nickname, :email]) do |result, identity_url, registration|
        if result.successful?
          create_new_user(:identity_url => identity_url, :login => registration['nickname'], :email => registration['email'])
        else
          failed_creation(result.message || "Sorry, something went wrong")
        end
      end
    else
    @user = User.new(params[:user])
    if @user.valid_with_captcha?
      if @user.not_using_openid?
        #@user.register!
				 session[:contact] = nil
        @user.update_attributes(:state=>'active',:user_role=>'Reader',:activated_at=>Time.now)
      else
        @user.register_openid!
      end
    end
    
    if @user.errors.empty?
      #successful_creation(@user)
       self.current_user = @user
      loggedin_count = !current_user.loggedin_count.nil? ? current_user.loggedin_count : 0
      current_user.update_attributes(:loggedin_count=>loggedin_count+1)
      new_cookie_flag = (params[:remember_me] == "1")
    handle_remember_cookie! new_cookie_flag
      redirect_to edit_user_path(@user)
    else
      failed_creation
    end
    end
  end
  
  def update
    @user = User.find_by_id(params[:id])
    if @user.update_attributes(params[:user])
      @user.favourite_category_ids = params[:user][:favourite_category_ids].join(',').to_s if params[:user] && !params[:user][:favourite_category_ids].nil? && params[:user][:favourite_category_ids].length > 0
      @user.save
     flash[:notice] = "Successfully Updated"
     if @user.user_role == 'Advertiser'
	     redirect_to users_path
	     else
     redirect_to advertiser_upgrade_path(@user.id)
     end
    else
      render :action=>'edit'
    end       
  end
  
  def activate
    logout_keeping_session!
    user = User.find_by_activation_code(params[:activation_code]) unless params[:activation_code].blank?
    case
    when (!params[:activation_code].blank?) && user && !user.active?
      user.activate!
      flash[:notice] = "Signup complete! Please sign in to continue."
      redirect_to login_path
    when params[:activation_code].blank?
      flash[:error] = "The activation code was missing.  Please follow the URL from your email."
      redirect_back_or_default(root_path)
    else 
      flash[:error]  = "We couldn't find a user with that activation code -- check your email? Or maybe you've already activated -- try signing in."
      redirect_back_or_default(root_path)
    end
  end
  
  def advertiser_member_edit
    @countries = Country.find(:all)
    @user = User.find_by_id(params[:id])
    if params[:commit] == "Make me an Advertiser member"
      @user.update_attribute(:user_role,params[:user_role])
      redirect_back_or_default(root_path)
    end 
  end  
  
  
  def myprofile
  end
  
  def dashboard
	if logged_in?  
	@user= current_user
	find_category
	@blogs = @user.blogs.find(:all,:conditions=>['status=?','Active']).collect{|x| x.id}
	@listings = @user.listings.find(:all,:conditions=>['status=? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)','Active',(Date.today),(Date.today)]).collect{|x| x.id}
	@recently_viewed_blogs =UserViewedBlog.find(:all,:conditions=>['user_id = ? and blog_id IN (?) and last_viewed_at >=?',@user.id,@blogs,(Date.today -30)],:limit=>5,:order=>'created_at desc')
	@recently_viewed_listings = UserViewedListing.find(:all,:conditions=>['user_id = ? and listing_id IN (?) and last_viewed_at >=?',@user.id,@listings,(Date.today - 30)],:limit=>5,:order=>'created_at desc')
	@saved_blogs = @user.favorite_blogs
	@saved_listings = @user.favorite_listings
	@recommended_listings = Listing.find(:all,:conditions=>['status=? and category_id IN (?) and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)','Active',@categories,(Date.today),(Date.today)])
	@recommended_blogs = Blog.find(:all,:conditions=>['status=? and id IN (?)','Active',@blog_ids])
	@results = UserSearch.find(:all,:conditions=>['user_id=? and updated_at >=?',current_user.id,(Date.today-30)],:select=>'distinct Date(updated_at)')
	else
		redirect_to login_path
	end
  end

  def find_category
	if logged_in?
		@user= current_user
		@recently_viewed_listing_ids = UserViewedListing.find(:all,:conditions=>['user_id = ? and listing_id IN (?)',@user.id,@listings],:order=>'created_at desc').collect{|x| x.listing_id}
		if @user.favourite_category_ids.nil?
		  @categories = Listing.find(:all,:conditions=>['status=? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL) and id IN (?)','Active',(Date.today),(Date.today),@recently_viewed_listing_ids]).collect{|x| x.category_id}
		  @blog_ids =UserViewedBlog.find(:all,:conditions=>['user_id = ? and blog_id IN (?)',@user.id,@blogs],:order=>'created_at desc').collect{|x| x.blog_id}
		else
		  @categories = @user.favourite_category_ids
		  @blog_ids = BlogCategory.find(:all,:conditions=>['category_id In (?)',@categories]).collect{|x| x.blog_id}
		end
	else
	        redirect_to login_path	
	end
  end

  def saved_listings
	if logged_in?  
	@user= current_user
	@my_saved_listings = @user.favorite_listings
	else
	  redirect_to login_path	
	end
  end

  def recommended_listings
	  find_category
	@my_recommended_listings =  Listing.find(:all,:conditions=>['status=? and category_id IN (?) and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)','Active',@categories,(Date.today),(Date.today)],:order=>'created_at desc')
  end

  def recently_viewed_listings
	if logged_in?  
	@user= current_user
	@listings = @user.listings.find(:all,:conditions=>['status=? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)','Active',(Date.today),(Date.today)]).collect{|x| x.id}
	@my_recently_viewed_listings = UserViewedListing.find(:all,:conditions=>['user_id = ? and listing_id IN (?) and last_viewed_at >=?',@user.id,@listings,(Date.today-30)],:order=>'created_at desc')
	else
	  redirect_to login_path
	end
  end

  def saved_blogs
	if logged_in?  
	@user= current_user
	@my_saved_blogs = @user.favorite_blogs
	else
	  redirect_to login_path	
	end
  end

  def recommended_blogs
	  find_category
	@my_recommended_blogs= Blog.find(:all,:conditions=>['status=? and id IN (?)','Active',@blog_ids],:order=>'created_at desc')
  end

  def recently_viewed_blogs
	if logged_in?  
	@user= current_user
	@blogs = @user.blogs.find(:all,:conditions=>['status=?','Active']).collect{|x| x.id}
	@my_recently_viewed_blogs = UserViewedBlog.find(:all,:conditions=>['user_id = ? and blog_id IN (?) and last_viewed_at >=?',@user.id,@blogs,()],:order=>'created_at desc')
	else
	  redirect_to login_path	
	end
  end

  def saved_searches
	dashboard
	@my_saved_searches = @results
   end

  
  def search
	if !params[:q].nil? || !params[:q]
		blogquery
		@blogs= Blog.find(:all,:conditions=>[@search_blog],:order=>'created_at desc')
		listingquery
		@listings= Listing.find(:all,:conditions=>[@search_listing],:order=>'created_at desc')
		sponsoredlisting
		@sponsored_listings = Listing.find(:all,:conditions=>[@search_sponsored_listing],:order=>'created_at desc')
		if logged_in?
      @check = UserSearch.find(:first,:conditions=>['user_id=? and updated_at >=? and search_keyword=?',current_user.id,(Date.today-30),params[:q]])
			if !@check.nil?
				@check.update_attribute('updated_at',Date.today)
				else
							@user_search = UserSearch.create(:user_id=>current_user.id,:search_keyword=>params[:q])
				end
			@results = UserSearch.find(:all,:conditions=>['user_id=? and updated_at >=?',current_user.id,(Date.today-30)],:select=>'distinct Date(updated_at)')
		end
	end
  end

  
  def change_layout
			(action_name=="index" || action_name =="categories" || action_name == "new" || action_name == "create" || action_name=="edit" || action_name=="myprofile" || action_name =="list_by_tag" || action_name=="search" || action_name =="dashboard" || action_name=="saved_listings" || action_name=="recently_viewed_listings" || action_name=="saved_blogs" || action_name=="recently_viewed_blogs" || action_name=="recommended_blogs" || action_name=="recommended_listings" || action_name=="saved_searches" || action_name=="show" || action_name=="change_password") ? "home" : "webbusinessage"
  end

  
  def list_by_tag
	  @tag = Tag.find_by_name(params[:name])
	  if !@tag.nil?
	  @blog_tags = @tag.taggings.find(:all,:conditions=>['taggable_type =?','Blog']).collect{|x| x.taggable_id}
	  @listing_tags = @tag.taggings.find(:all,:conditions=>['taggable_type =?','Listing']).collect{|x| x.taggable_id}
	  @blogs = Blog.find(:all,:conditions=>['id IN (?) and status =?',@blog_tags,'Active'])
	  @listings = Listing.find(:all,:conditions=>['id IN (?) and is_sponsored =? and status = ? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',@listing_tags,0,'Active',(Date.today),(Date.today)])
	  @sponsored_listings = Listing.find(:all,:conditions=>['id IN (?) and is_sponsored =? and status = ? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',@listing_tags,1,'Active',(Date.today),(Date.today)])
	  end
  end
  
  def blogquery
        blog_query = [ ] 
	blog_query << "(url LIKE '%%#{params[:q]}%%' OR title LIKE '%%#{params[:q]}%%' OR short_description LIKE '%%#{params[:q]}%%' OR description LIKE '%%#{params[:q]}%%')"
	blog_query << "(status='Active')"
	@search_blog = blog_query.join(" AND ")
  end

  def listingquery
        listing_query = [ ]
	listing_query << "(url LIKE '%%#{params[:q]}%%' OR title LIKE '%%#{params[:q]}%%' OR short_description LIKE '%%#{params[:q]}%%' OR description LIKE '%%#{params[:q]}%%')"
	listing_query << "(is_sponsored = 0 and status = 'Active' and (Date(activated_from) <= '#{Date.today}' or activated_from IS NULL) and (Date(expiry_date) >= '#{Date.today}' or expiry_date IS NULL))"
	@search_listing = listing_query.join(" AND ")
  end

  def sponsoredlisting
        sponsored_listing_query = [ ]
	sponsored_listing_query << "(url LIKE '%%#{params[:q]}%%' OR title LIKE '%%#{params[:q]}%%' OR short_description LIKE '%%#{params[:q]}%%' OR description LIKE '%%#{params[:q]}%%')"
	sponsored_listing_query << "(is_sponsored = 1 and status = 'Active' and (Date(activated_from) <= '#{Date.today}' or activated_from IS NULL) and (Date(expiry_date) >= '#{Date.today}' or expiry_date IS NULL))"
	@search_sponsored_listing = sponsored_listing_query.join(" AND ")
  end

	def subscribe_email
		if !params[:subscribe_email].blank?
			h = Hominid.new  
			list = h.lists.find {|list| list["name"] == APP_CONFIG[:hominid_list_name] }
			h.subscribe(list["id"], params[:subscribe_email]) 
			flash[:notice] = "Thanks for subscribing with Web Business Age Newsletter!"
		else
			flash[:error] = "Provide Email for Newsletter subscription!"
		end	
		redirect_back_or_default(root_path)
 end	
 
 def change_password
                       return unless request.post?
                       if User.authenticate(current_user.email, params[:old_password])
                              if (!(params[:old_password]) || !params[:password_confirmation].blank?)
                                       current_user.password_confirmation = params[:password_confirmation]
                                       current_user.password = params[:password]        
                                       if current_user.save
                                               flash[:notice] = "Password successfully updated."
                                               redirect_to root_path
                                      else
                                               flash.now[:error] = "Password Mismatch, your password was not changed."
                                               render :action => 'change_password'
                                       end
                               else
                                       flash.now[:error] = "Enter New Password and Confirm Password."
                                       render :action => 'change_password'      
                               end
                       else
                               flash.now[:error] = "Your current password is incorrect."
                               render :action => 'change_password'
                       end 
				end 

  def feed
		@blogs = Blog.find(:all,:conditions=>['status = ?',"Active"],:limit=>10,:order=>'created_at desc')	
		render :layout=>false
   end 

  
  protected
  
  def create_new_user(attributes)
    @user = User.new(attributes)
    if @user && @user.valid_with_captcha?
      if @user.not_using_openid?
        @user.register!
        @user.update_attribute(:user_role,'Reader')
      else
        @user.register_openid!
      end
    end
    
    if @user.errors.empty?
      successful_creation(@user)
    else
      failed_creation
    end
  end
  
  def successful_creation(user)
    redirect_back_or_default(root_path)
    flash[:notice] = "Thanks for signing up!"
    flash[:notice] << " We're sending you an email with your activation code." if @user.not_using_openid?
    flash[:notice] << " You can now login with your OpenID." unless @user.not_using_openid?
  end
  
  def failed_creation(message = '')
    flash[:error] = message
    render :action => :new
  end
end
