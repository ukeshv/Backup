module Admin::BlogsHelper

def blog_categories_name(blog)
	if !blog.blog_categories.empty?
	return blog.blog_categories.collect{ |x|  x.category.name if !x.category.nil?}.to_sentence
	else
	return "-- No Categories --"	
	end	
end	

def single_blog_url(blog)
	return "#{APP_CONFIG[:site_url]}/blog/#{blog.created_at.year}/#{blog.created_at.strftime('%m')}/#{blog.created_at.strftime('%d')}/#{blog.url}"
end	

def blog_category_position(blogid,categoryid)
	f = FeaturedblogCategory.find_by_blog_id_and_category_id(blogid,categoryid)
	if !f.nil?
	return f.featured_cat
	else
	return nil
	end	
end	

end
