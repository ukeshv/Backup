module Admin::ContentTypesHelper
end
