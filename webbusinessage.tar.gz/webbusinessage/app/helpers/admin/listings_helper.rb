module Admin::ListingsHelper
def listing_categories_name(listing)
	if !listing.listing_categories.empty?
	return listing.listing_categories.collect{|x|x.category.name}.to_sentence
	else
	return "-- No Categories --"	
	end	
end

def listing_category_name(listing)
	!listing.category.nil? ? listing.category.name : "-"
end	

def listing_content_type_name(listing)
	!listing.content_type.nil? ? listing.content_type.name : "-"
end	

def listing_specific_content_type_name(listing)
	!listing.specific_content_type.nil? ? listing.specific_content_type.name : "-"
end	

def listing_geolocation_name(listing)
!listing.geo_location.nil? ? listing.geo_location.name : "-" 
end

def listing_userlevel_name(listing)
!listing.user_level.nil? ? listing.user_level.name : "-" 
end

def listing_author_name(listing)
!listing.author.nil? ? listing.author.firstname : "-" 
end

def listing_editor_name(listing)
!listing.editor.nil? ? listing.editor.firstname : "-" 
end

def single_listing_url(listing)
	return "#{APP_CONFIG[:site_url]}/listing/#{listing.created_at.year}/#{listing.created_at.strftime('%m')}/#{listing.created_at.strftime('%d')}/#{listing.url}"
end	

def listing_content_types_name(listing)
	if !listing.listing_content_types.empty?
	return listing.listing_content_types.collect{|x|x.content_type.name}.to_sentence
	else
	return "-- No Content Types --"	
	end	
end

def listing_category_position(listingid,categoryid)
	f = FeaturedlistingCategory.find_by_listing_id_and_category_id(listingid,categoryid)
	if !f.nil?
	return f.featured_cat
	else
	return nil
	end	
end	

end
