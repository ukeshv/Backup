module Admin::SpecificContentTypesHelper
end
