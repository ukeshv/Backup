module Advertiser::ListingsHelper
end
