module ApplicationHelper
  include TagsHelper

  # Sets the page title and outputs title if container is passed in.
  # eg. <%= title('Hello World', :h2) %> will return the following:
  # <h2>Hello World</h2> as well as setting the page title.
  def title(str, container = nil)
    @page_title = str
    content_tag(container, str) if container
  end
  
  # Outputs the corresponding flash message if any are set
  def flash_messages
    messages = []
    %w(notice warning error).each do |msg|
      messages << content_tag(:div, html_escape(flash[msg.to_sym]), :id => "flash-#{msg}") unless flash[msg.to_sym].blank?
    end
    messages
  end
  
  def sort_link(text, parameter, options, html_options=nil)
	   key = parameter
	   key += " DESC" if params[:sort] == parameter
	   sorting_params=params.clone
	   if params[:sort] == parameter 
	   text =text
	   elsif params[:sort]==("#{parameter} DESC")
	   text =text
	   end        
	   link_to text, sorting_params.merge(:sort=>key)
   end 
   
     # Get categories and subcategories in tree structure  
     def display_trees(category_name)
    @ret = []
    for category_name in category_name
      if category_name.parent_id == 0 
        @ret << category_name
        find_subtrees(category_name)
      end
    end
    return @ret
  end

  def find_subtrees(category_name)
    if(category_name.children.size > 0)
      category_name.children.each { |cat_names|
        @ret << cat_names
        if cat_names.children.size > 0
          find_subtrees(cat_names)
        end
      }
    end
  end
  
  
  def list_category
	   @categories = Category.find(:all,:conditions=>['parent_id =? and status=?',0,1],:order=>'position ASC')
  end


  def display_parent(category)
    category.parent.nil? ? "-" : category.parent.name
  end  

  def display_children(category)
    category.children.empty? ? "-" : category.children.collect{|x| x.name}.join(',')
  end  
  
  #Display name for comment

  def disp_name(comment)
      return comment.user.nil? ? "Anonymous" : comment.user.firstname  
  end

  def is_advertiser
	  if (controller_name == 'advertisers')
		  return true
	  else
		  return false
	  end		  
  end
 
  def link_site(site_name,link_url,link_title)
    case site_name
      when 'Yahoo'
        site = "http://myweb2.search.yahoo.com/myresults/bookmarklet?&ei=UTF-8&u=" + CGI.escape(link_url) + "&t=" + CGI.escape(link_title)
      when 'Delicious'
        site = "http://del.icio.us/post?url=" + CGI.escape(link_url) + "&title=" + CGI.escape(link_title)
      when 'Digg'
        site = "http://digg.com/submit?phase=2&url=" + CGI.escape(link_url) + "&title=" + CGI.escape(link_title)
      when 'Reditt'
        site = "http://reddit.com/submit?url="+CGI.escape(link_url) + "&title=" + CGI.escape(link_title)
      when 'Furl'
        site = "http://furl.net/storeIt.jsp?t=" + CGI.escape(link_title) + "&u=" + CGI.escape(link_url)
      when 'Blinklist'
        site = "http://blinklist.com/index.php?Action=Blink/addblink.php&url=" + CGI.escape(link_url) + "&Title=" + CGI.escape(link_title)
      when 'Stumble It!'
        site = "http://www.stumbleupon.com/submit?url="+ CGI.escape(link_url) + "&title=" + CGI.escape(link_title)
      when 'FaceBook'
        site = "http://www.facebook.com/share.php?u=" + CGI.escape(link_url) + "&t=" + CGI.escape(link_title)
      when 'Technorati'
        site = "http://technorati.com/faves?add=" + CGI.escape(link_url)
      end
      return site
    end
    
    def get_url(id)
    listing = Listing.find(id)
    link_name = "#{APP_CONFIG[:site_url]}/listing/#{listing.created_at.year}/#{listing.created_at.month}/#{listing.url}"
    return link_name
  end
  
  def get_title(id)
    listing = Listing.find(id)
    title = listing.title
    return title
  end
  
  def calculate_month(date1,date2,rank)
	m = (date2.year*12+date2.month) - (date1.year*12+date1.month)
	@price = 100 if (m == 12 && rank.nil?)
	@price = 60 if (m == 6 && rank.nil?)
	@price = 100 + (85*100/100) if (m == 12 && rank == 1 )
	@price = 60 + (85*60/100) if (m == 6 && rank == 1)
	@price = 100 + (65*100/100) if (m == 12 && rank == 2)
	@price = 60 + (65*60/100) if (m == 6 && rank == 2)
	@price = 100  if (m == 12 && !rank.nil? && rank >= 3 )
	@price = 60 if (m == 6 && !rank.nil?  && rank >= 3)
	return @price

  end
  
 def blog_red_stars(red)
  div = []
  div << "<div id='rating_div'>"
  red.to_i.times{|x| div << "<img id='img#{x}' src='/images/new/share_star_orange.gif'/>"  }
  (5 - red.to_i).times{|x| div << "<img id='img#{x}' src='/images/new/share_star_gray.gif'>"  }
  div << "</div>"
  return div.join
end

def blog_gray_stars
  div = []
  5.times{|x| div << "<img id='img#{x+1}' src='/images/new/share_star_gray.gif' onmouseover='change(#{x+1},#{@blog.id})'>"  }
  return div.join
end

def blog_gray_stars_login
  div = []
  5.times{|x| div << "<img id='img#{x+1}' src='/images/new/share_star_gray.gif' onmouseover='logintorate()' onmouseout='hide_text();'>"  }
  return div.join
end

def blog_red_stars_overall_rated(red)
  div = []
  div << ""
  red.to_i.times{|x| div << "<img id='img#{x}' src='/images/new/orange-star.gif' title='Already Rated'/>"  }
  (5 - red.to_i).times{|x| div << "<img id='img#{x}' src='/images/new/gray-star.gif' title='Already Rated'/>"  }
  div << ""
  return div.join
end

def blog_overall_rated(red)
  div = []
  div << ""
  red.to_i.times{|x| div << "<img id='img#{x}' src='/images/new/share_star_orange.gif' title='Already Rated'/>"  }
  (5 - red.to_i).times{|x| div << "<img id='img#{x}' src='/images/new/share_star_gray.gif' title='Already Rated'/>"  }
  div << ""
  return div.join
end

  
  
  def red_stars(red)
  div = []
  div << "<div id='rating_div'>"
  red.to_i.times{|x| div << "<img id='img#{x}' src='/images/new/share_star_orange.gif'/>"  }
  (5 - red.to_i).times{|x| div << "<img id='img#{x}' src='/images/new/share_star_gray.gif'>"  }
  div << "</div>"
  return div.join
end

def gray_stars
  div = []
  5.times{|x| div << "<img id='img#{x+1}' src='/images/new/share_star_gray.gif' onmouseover='change(#{x+1},#{@listing.id})'>"  }
  return div.join
end

def red_stars_overall_rated(red)
  div = []
  div << ""
  red.to_i.times{|x| div << "<img id='img#{x}' src='/images/new/orange-star.gif' title='Already Rated'/>"  }
  (5 - red.to_i).times{|x| div << "<img id='img#{x}' src='/images/new/gray-star.gif' title='Already Rated'/>"  }
  div << ""
  return div.join
end

def listing_overall_rated(red)
  div = []
  div << ""
  red.to_i.times{|x| div << "<img id='img#{x}' src='/images/new/share_star_orange.gif' title='Already Rated'/>"  }
  (5 - red.to_i).times{|x| div << "<img id='img#{x}' src='/images/new/share_star_gray.gif' title='Already Rated'/>"  }
  div << ""
  return div.join
end

def listing_gray_stars_login
  div = []
  5.times{|x| div << "<img id='img#{x+1}' src='/images/new/share_star_gray.gif' onmouseover='logintorate()' onmouseout='hide_text();'>"  }
  return div.join

end

def blog_description(blog)
	blog.short_description? ? (blog.short_description != "0") ? blog.short_description : (truncate(blog.description,100).gsub('<p>','').gsub('</p>','')) :  (truncate(blog.description,100).gsub('<p>','').gsub('</p>',''))
end

def listing_description(listing)
	listing.short_description? ? (listing.short_description != "0") ? listing.short_description : (truncate(listing.description,100).gsub('<p>','').gsub('</p>','')) :  (truncate(listing.description,100).gsub('<p>','').gsub('</p>',''))
end

def my_listings_description(listing)
	listing.short_description? ? (listing.short_description != "0") ? truncate(listing.short_description,75) : (truncate(listing.description,75).gsub('<p>','').gsub('</p>','')) :  (truncate(listing.description,75).gsub('<p>','').gsub('</p>',''))
end

def show_blogs_url(blog)
	return "#{APP_CONFIG[:site_url]}/blog/#{blog.id}"	
end

def home_blog_url
	return "#{APP_CONFIG[:site_url]}/blogs"
end

def category_description(category)
	!category.description.blank? ? truncate(category.description,100) : category.name
end

def display_blogcategories_name(blog)
	@names = blog.categories.collect{|x| x.name}.join(',').to_s
end

#To display active listings and active blogs .Also only listings that are not expired are listed
  def tags_display
    @tags = [ ]
    a = Listing.find(:all,:conditions=>['status = ? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)','Active',(Date.today),(Date.today)],:order=>"updated_at desc",:limit=>20)
    b = Blog.find(:all,:conditions=>['status = ?','Active'],:order=>"updated_at desc",:limit=>20)
    a.each do |x|
      @tags += x.tag_counts
    end  
    b.each do |y|
      @tags += y.tag_counts
    end  
   @tags = @tags.uniq    
    #~ @tags = @tags.uniq    
    #joins = ["INNER JOIN #{Tagging.table_name} ON #{Tag.table_name}.id = #{Tagging.table_name}.tag_id"]    
    #group_by  = "#{Tag.table_name}.id, #{Tag.table_name}.name HAVING COUNT(*) > 0"    
    #@tags = Tag.find(:all,:select  =>"#{Tag.table_name}.id, #{Tag.table_name}.name, COUNT(*) AS count", :joins => joins.join(" "),:group => group_by,:limit=>20)
  end
  
end
