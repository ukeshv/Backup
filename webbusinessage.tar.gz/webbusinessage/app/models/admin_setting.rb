class AdminSetting < ActiveRecord::Base
	
	def self.send_newsletter
		list_name = APP_CONFIG[:hominid_list_name]
		@hominid = Hominid.new
		mailing_lists = @hominid.lists
		unless mailing_lists.nil?
			@list_id = mailing_lists.find {|list| list["name"] == list_name}["id"]
		end
		subscribed_members = @hominid.members(@list_id)
		
		#Result of subscribed_members will be as follows.From this fetch emails and send mail
		
		#[{"timestamp"=>"2009-07-16 03:20:48", "email"=>"revathy@railsfactory.org"}, {"timestamp"=>"2009-07-16 03:48:43", "email"=>"revathy01@gmail.com"}, {"timestamp"=>"2009-07-16 04:01:39", "email"=>"revathyror@gmail.com"}]		
		
		#Mail to be sent to these subscribed_members through for loop
	end

end
