class AdvertiserReviewWebsite < ActiveRecord::Base
	
	validates_presence_of :website,:message=>"Provide Website Url"
	validates_format_of :website,:with=> /([^\/\\]+)\.(\w+)$/, :message=>"Provide Valid Website Url"
end
