class Blog < ActiveRecord::Base
	
        acts_as_taggable
	acts_as_rated
	acts_as_commentable
	acts_as_polymorphic_paperclip
	acts_as_favorite	


	has_many :users,:through=>:user_viewed_blogs
	has_many :user_viewed_blogs
	has_many :categories,:through=>:blog_categories
	has_many :blog_categories,:dependent=>:destroy
	has_many :featuredblog_categories,:dependent=>:destroy

	validates_presence_of :url, :message=>'Provide blog Url'
	validates_format_of :url,:with => /^[^\s]+$/, :message => "Url Can only contain letters and numbers with no spaces."
	validates_uniqueness_of :url, :message => 'This Blog Url Already Exists'
	validates_presence_of :title, :message=>'Provide blog Title'
	validates_presence_of :description, :message=>'Provide Blog Description'
	validates_format_of :trackback_urls, :with => URI::regexp(%w(http https)) ,:allow_blank=>true, :message => "Provide valid Url."
  validates_length_of :title, :within => 1..240,:too_long => "Title length limited to 240 characters.",:too_short => "Title length limited to 240 characters."

	#validates_uniqueness_of :featured_top,:allow_blank=>true, :message => "This Position is already choosen."
	#validates_numericality_of :featured_top,:allow_blank=>true, :message => "Provide numbers."

def self.featured_in_home_page
	find(:all,:conditions=>['featured_top is NOT NULL and status = ?','Active'],:order=>"updated_at desc")
end	

def self.featured_in_category_page
	find(:all,:conditions=>['featured_cat is NOT NULL and status = ?','Active'],:order=>"updated_at desc")
end	

def self.featured_blogs_in_home_page
	find(:all,:conditions=>['featured_top IS NOT NULL and status=?','Active'],:limit=>10,:order=>'featured_top asc, created_at desc')
end

def self.featured_blogs_in_bloghome_page
	find(:all,:conditions=>['featured_top IS NOT NULL and status=?','Active'],:limit=>10,:order=>'featured_top asc, created_at desc')
end

def self.recent_blogs_in_home_page
	find(:all,:conditions=>['featured_top IS NULL and status=?','Active'],:limit=>10,:order=>'created_at desc')
end

def self.recent_blogs_in_bloghome_page
	find(:all,:conditions=>['((featured_top IS NOT NULL) or (featured_top IS NULL)) and status=?','Active'],:limit=>10,:order=>'created_at desc')
end

def self.featured_blogs_based_on_category(id)
	find(:all,:conditions=>['featuredblog_categories.category_id = ? and blogs.status=?',id,'Active'],:include=>[:featuredblog_categories],:limit=>5,:order=>'featuredblog_categories.featured_cat asc')
end

def self.recent_blogs_based_on_category(id)
	find(:all,:conditions=>['blog_categories.category_id = ? and blogs.status=?',id,'Active'],:include=>[:blog_categories],:limit=>5,:order=>'blog_categories.created_at desc')
end

def self.blogs_in_category(id)
       find(:all,:conditions=>['blog_categories.category_id = ? and blogs.status=?',id,'Active'],:include=>[:blog_categories],:order=>'blog_categories.created_at desc')
end

def display_selected
	if self.attachings.length>0
		if self.attachings.find_by_is_primary(true)
			image = self.attachings.find_by_is_primary(true)
		else
			image = self.attachings.find(:first)
		end	
		url = image.asset.url(:tiny)
		image ? url : "/images/new/blog_tiny_default.png"
	else
	"/images/new/blog_tiny_default.png"
	end
end

def display_selected_large
	if self.attachings.length>0
		if self.attachings.find_by_is_primary(true)
			image = self.attachings.find_by_is_primary(true)
		else
			image = self.attachings.find(:first)
		end	
		url = image.asset.url(:small)
		image ? url : "/images/new/blog_small_default.png"
	else
	"/images/new/blog_small_default.png"
	end
end

def is_viewed(userid)
		if self.user_viewed_blogs.find_by_user_id(userid).nil?
			b = self.user_viewed_blogs.new
			b.user_id = userid
			b.blog_id = self.id
			b.last_viewed_at = Date.today
			b.save
		else
			b = self.user_viewed_blogs.find_by_user_id(userid)	
			b.update_attribute("last_viewed_at",Time.now)
		end
   end




end
