class Category < ActiveRecord::Base
	
	
	acts_as_ordered_tree :foreign_key => :parent_id,:order  => :position
	
	validates_presence_of :name, :message=>'Provide Category Name'
	validates_uniqueness_of :name, :scope =>:parent_id, :message=>'Name already used.Provide different name'
	validates_presence_of :position, :message=>'Provide Category position'
	validates_uniqueness_of :position, :scope => :parent_id, :message => 'This position is already choosed' 
	
	before_save :change_display_link
	
	#has_many :listings,:through=>:listing_categories
	#has_many :listing_categories	
	
	has_many :blogs,:through=>:blog_categories
	has_many :blog_categories,:dependent=>:destroy
	
	has_many :listings
	
	named_scope :active, :conditions =>["status = ?",true]
	
	def display_status
		self.status == true ? 'Active' : 'Inactive'
end

 def change_display_link
		 category = self.name.strip
		 category_name = category.gsub(' ','-')
		 self.category_permalink = category_name
 end
 

end
