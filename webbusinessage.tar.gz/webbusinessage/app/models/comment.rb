class Comment < ActiveRecord::Base
	attr_accessor :loggedin
	belongs_to :user
	validates_presence_of :firstname, :if => Proc.new { |comment| comment.loggedin ==1 },  :message => "Enter Firstname."
	validates_presence_of :lastname, :if => Proc.new { |comment| comment.loggedin ==1 },  :message => "Enter Lastname."
	validates_presence_of :email, :if => Proc.new { |comment| comment.loggedin ==1 },  :message => "Enter Email."
	validates_format_of :email, :with => /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/, :if => Proc.new { |comment| comment.loggedin ==1 },  :message => "Enter Valid Email."
	validates_presence_of :comment, :message => "Enter Comment."
end
