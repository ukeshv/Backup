class ContentType < ActiveRecord::Base
	
	validates_presence_of :name,:message=>"Provide Content Type Name"
	validates_uniqueness_of :name, :message=> 'Content Type Name has been already exist'
	validates_uniqueness_of :placeholder,:scope=>:position,:message=>"Position has been already assigned to this placeholder"
	validates_presence_of :position,:message=>"Provide Content Type Position in selected Placeholder"
	
	#has_many :listings,:through=>:listing_content_types
	#has_many :listing_content_types
	
	has_many :listings
	
	def display_status
		self.status == true ? 'Active' : 'Inactive'
	end		
	
end
