class FeaturedblogCategory < ActiveRecord::Base
	belongs_to :blog
end
