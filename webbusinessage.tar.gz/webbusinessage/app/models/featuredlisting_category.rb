class FeaturedlistingCategory < ActiveRecord::Base
	belongs_to :listing
end
