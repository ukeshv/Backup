class GeoLocation < ActiveRecord::Base
	
	validates_presence_of :name,:message=>'Provide Geo Location name'
	validates_uniqueness_of :name, :message=> 'Geo Location Name has been already exist'
	
	has_many :listings
	has_many :users
	
end
