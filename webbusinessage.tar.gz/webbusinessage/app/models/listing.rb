class Listing < ActiveRecord::Base
		acts_as_taggable
		acts_as_rated
  	acts_as_polymorphic_paperclip   
		  acts_as_commentable
			has_many :users,:through=>:user_viewed_listings
		  has_many :user_viewed_listings
		acts_as_favorite	
		
			#has_many :content_types,:through=>:listing_content_types
			#has_many :listing_content_types,:dependent=>:destroy
			
			#has_many :categories,:through=>:listing_categories
			#has_many :listing_categories,:dependent=>:destroy
			
			has_many :featuredlisting_categories,:dependent=>:destroy
			
			belongs_to :author, :class_name => "User", :foreign_key => "author_id"
			belongs_to :editor, :class_name => "User", :foreign_key => "editor_id"
			
			belongs_to :category
			belongs_to :content_type
			belongs_to :specific_content_type
			belongs_to :geo_location
			belongs_to :user_level
      
  validates_presence_of :url, :message=>'Provide listing Url'
	validates_format_of :url,:with => /^[A-Za-z0-9_-]+$/,:allow_blank=>true, :message => "Url Can only contain letters and numbers with no spaces."
	validates_uniqueness_of :url,:allow_blank=>true, :message => 'This Listing Url Already Exists'
  
  validates_presence_of :display_url, :message =>'Provide Display Url'
  validates_presence_of :destination_url, :message=>'Provide Destination Url'
  
	validates_presence_of :title, :message=>'Provide Listing Title'
	validates_presence_of :description, :message=>'Provide Listing Description'
	
	validates_presence_of :category_id,:message=>"Select a category for listing"
	validates_presence_of :content_type_id,:message=>"Select a content type for listing"	
	
	#validates_presence_of :current_rank,:if => Proc.new { |listing| listing.is_sponsored == true }, :message => "Provide Rank for this sponsored listing"
	
	validates_numericality_of :current_rank,:if => Proc.new { |listing| listing.is_sponsored == true },:allow_blank=>true, :message => "Provide numbers/digits for Rank."
	validates_uniqueness_of :current_rank, :scope => [:category_id, :content_type_id],:if => Proc.new { |listing| listing.is_sponsored == true },:allow_blank=>true, :message => "This Rank is already choosen for a sponsored listing"
	
def self.featured_in_home_page
	find(:all,:conditions=>['featured_top is NOT NULL and status = ?','Active'],:order=>"updated_at desc")
end	

def self.sponsored_listings_in_home
      @arr = Listing.find(:all,:conditions=>['is_sponsored =? and status = ? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL) and featured_top != ?',1,'Active',(Date.today),(Date.today),0],:order=>'featured_top asc',:limit=>10)
	self.update_listings_count(@arr)
end

def self.normal_listings_in_home
      @arr = Listing.find(:all,:conditions=>['is_sponsored =? and status = ? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL) and featured_top != ?',0,'Active',(Date.today),(Date.today),0],:order=>'featured_top asc',:limit=>10)
	self.update_listings_count(@arr)
end

def self.sponsored_listings_based_on_category_in_home(id)
	@arr = [ ]
	@arr += Listing.find(:all,:conditions=>['category_id = ? and featured_cat IS NOT NULL and featured_cat != ? and is_sponsored =? and status = ? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',id,0,1,'Active',(Date.today),(Date.today)],:order=>'featured_cat asc')
	#@arr += Listing.find(:all,:conditions=>['category_id = ? and featured_cat IS NULL and is_sponsored =? and status = ? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',id,1,'Active',(Date.today),(Date.today)])
        self.update_listings_count(@arr)
end

def self.normal_listings_based_on_category_in_home(id)
      @arr = [ ]
      @arr += Listing.find(:all,:conditions=>['category_id = ? and featured_cat IS NOT NULL  and featured_cat != ? and is_sponsored =? and status = ? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',id,0,0,'Active',(Date.today),(Date.today)],:order=>'featured_cat asc')
      #@arr += Listing.find(:all,:conditions=>['category_id = ? and featured_cat IS NULL and is_sponsored =? and status = ? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',id,0,'Active',(Date.today),(Date.today)])
      self.update_listings_count(@arr)
	end
	
		def self.sponsored_listings_in_listingspage(category_id,content_type_id)
			@arr = [ ]
			@arr += Listing.find(:all,:conditions=>['category_id = ? and current_rank IS NOT NULL and content_type_id=? and is_sponsored = ? and status=? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',category_id,content_type_id,1,'Active',(Date.today),(Date.today)],:limit=>3,:order=>'current_rank asc')   
			@arr += Listing.find(:all,:conditions=>['category_id = ? and current_rank IS NULL and content_type_id=? and is_sponsored = ? and status=? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',category_id,content_type_id,1,'Active',(Date.today),(Date.today)])
  end

	
	def self.normal_listings_in_listingspage(category_id,content_type_id)
			@arr = [ ]
			@arr += Listing.find(:all,:conditions=>['category_id = ? and current_rank IS NOT NULL and content_type_id = ? and is_sponsored = ? and status=? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',category_id,content_type_id,0,'Active',(Date.today),(Date.today)],:order=>'current_rank asc')
			@arr += Listing.find(:all,:conditions=>['category_id = ? and current_rank IS NULL and content_type_id = ? and is_sponsored = ? and status=? and (Date(activated_from) <= ? or activated_from IS NULL) and (Date(expiry_date) >= ? or expiry_date IS NULL)',category_id,content_type_id,0,'Active',(Date.today),(Date.today)])
  end


def self.update_listings_count(listings)
	listings.each do |listing|
		listing.update_attribute("summary_listing_page_views_count",listing.summary_listing_page_views_count.nil? ? listing.summary_listing_page_views_count=1 : listing.summary_listing_page_views_count+1) 
	end
end

def display_selected
	if self.attachings.length>0
		if self.attachings.find_by_is_primary(true)
			image = self.attachings.find_by_is_primary(true)
		else
			image = self.attachings.find(:first)
    end	
		url = image.asset.url(:l_tiny)
		image ? url : "/images/new/tiny_listing.png"
	else
	"/images/new/tiny_listing.png"
end
end

def display_selected_large
	if self.attachings.length>0
		if self.attachings.find_by_is_primary(true)
			image = self.attachings.find_by_is_primary(true)
		else
			image = self.attachings.find(:first)
		end	
		url = image.asset.url(:l_small)
		image ? url : "/images/new/small_listing.png"
	else
	"/images/new/small_listing.png"
	end
end



def is_viewed(userid)
		if self.user_viewed_listings.find_by_user_id(userid).nil?
			b = self.user_viewed_listings.new
			b.user_id = userid
			b.listing_id = self.id
			b.last_viewed_at = Date.today
			b.save
		else
			b = self.user_viewed_listings.find_by_user_id(userid)
			b.update_attribute("last_viewed_at",Time.now)
		end
end

end
