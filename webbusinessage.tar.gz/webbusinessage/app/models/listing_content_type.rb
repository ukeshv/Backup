class ListingContentType < ActiveRecord::Base
	belongs_to :listing
  belongs_to :content_type
end
