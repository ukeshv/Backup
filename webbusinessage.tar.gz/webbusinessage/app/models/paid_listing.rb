class PaidListing < ActiveRecord::Base
end
