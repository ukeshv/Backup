class Payment < ActiveRecord::Base
end
