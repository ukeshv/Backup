class SpecificContentType < ActiveRecord::Base
	
	validates_presence_of :name,:message=>"Provide Specific Content Type Name"	
	validates_uniqueness_of :name, :message=> 'Specific Content Type Name has been already exist'
	
	has_many :listings
	
	def display_status
		self.status == true ? 'Active' : 'Inactive'
	end
	
end
