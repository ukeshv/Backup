require 'digest/sha1'

class User < ActiveRecord::Base
  acts_as_favorite_user

  include Authentication
  include Authentication::ByPassword
  include Authentication::ByCookieToken
  include Authorization::AasmRoles

    attr_accessor :is_advertiser

  # Validations
  #validates_presence_of :login, :if => :not_using_openid?
  #validates_length_of :login, :within => 3..40, :if => :not_using_openid?
  #validates_uniqueness_of :login, :case_sensitive => false, :if => :not_using_openid?
  #validates_format_of :login, :with => RE_LOGIN_OK, :message => MSG_LOGIN_BAD, :if => :not_using_openid?
  validates_format_of :firstname, :with => RE_NAME_OK, :message => MSG_NAME_BAD, :allow_nil => true
  validates_length_of :firstname, :within => 1..20,:too_long => "Enter firstname between 1 and 20 characters long.",:too_short => "Enter firstname between 1 and 20 characters long."
  validates_presence_of :email, :if => :not_using_openid?,:message => "Enter your email address."
  validates_length_of :email, :within => 6..100, :if => :not_using_openid?, :message => MSG_EMAIL_BAD
  validates_uniqueness_of :email, :case_sensitive => false, :if => :not_using_openid?,:message => 'An account is already registered with this address.'
  validates_format_of :email, :with => RE_EMAIL_OK, :message => MSG_EMAIL_BAD, :if => :not_using_openid?,:message=>"Please provide a valid Email Address"
  validates_uniqueness_of :identity_url, :unless => :not_using_openid?
  validate :normalize_identity_url
  
  validates_presence_of :company, :if => Proc.new { |user| user.is_advertiser ==1 },  :message => "Enter Company."
  validates_presence_of :address, :if => Proc.new { |user| user.is_advertiser == 1 }, :message => "Enter Address."
  validates_presence_of :city, :if => Proc.new { |user| user.is_advertiser == 1 }, :message => "Enter City."
  validates_presence_of :user_state, :if => Proc.new { |user| user.is_advertiser == 1 }, :message => "Enter State."
  validates_presence_of :country_id, :if => Proc.new { |user| user.is_advertiser == 1 }, :message => "Select country"
  validates_presence_of :phone, :if => Proc.new { |user| user.is_advertiser == 1 }, :message => "Enter phone."
  validates_format_of :phone, :with => /^[0-9]/,:if => Proc.new { |user| user.is_advertiser == 1 }, :message => "PhoneNumber should be digits"
  validates_length_of :phone, :within => 6..25,:if => Proc.new { |user| user.is_advertiser == 1 },:too_short=>"Number Should be aleast 8 digits",:too_long=>"Number not to exceed 10 digits"
  validates_presence_of :company_url, :if => Proc.new { |user| user.is_advertiser == 1 }, :message => "Enter Company website."
#  validates_format_of :company_url , :if =>Proc.new { |user| user.is_advertiser == 1},:with =>/^(http|https):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(([0-9]{1,5})?\/.*)?$/ix ,:message=>'Provide Valid Url'
  
  

  #Captcha Validation
	apply_simple_captcha #:message => "The secret Image and code were different"
  
  # Relationships
  has_and_belongs_to_many :roles
  has_many :comments
  has_many :listings,:through=>:user_viewed_listings
  has_many :user_viewed_listings
  
  has_many :blogs,:through=>:user_viewed_blogs
  has_many :user_viewed_blogs
  
  has_many :user_searches
  
  has_many :author_listings, :class_name => 'Listing', :foreign_key => "author_id" 
  has_many :editor_listings, :class_name => 'Listing', :foreign_key => "editor_id"
  
  belongs_to :geo_location
  belongs_to :user_level
  belongs_to :country

  # HACK HACK HACK -- how to do attr_accessible from here?
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  #attr_accessible :email, :firstname, :password, :password_confirmation

  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  def self.authenticate(email, password)
    u = find_in_state :first, :active, :conditions => { :email => email } # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end
  
  # Check if a user has a role.
  def has_role?(role)
    list ||= self.roles.map(&:name)
    list.include?(role.to_s) || list.include?('admin')
  end
  
  # Not using open id
  def not_using_openid?
    identity_url.blank?
  end
  
  # Overwrite password_required for open id
  def password_required?
    new_record? ? not_using_openid? && (crypted_password.blank? || !password.blank?) : !password.blank?
  end
  
  def fullname
    "#{firstname} #{lastname}"
  end

   #~ def linkedin_profile_url
     #~ raw_title = read_attribute( "linkedin_profile_url" )
     #~ raw_title = "http://www.linkedin.com/" + raw_title unless raw_title.nil?
    #~ raw_title
   #~ end 
  
  #~ def twitter_profile_url
    #~ raw_title = read_attribute( "twitter_profile_url" )
    #~ raw_title = "http://www.twitter.com/" + raw_title unless raw_title.nil?
    #~ raw_title
  #~ end 
  
  #~ def social_profile_url
    #~ raw_title = read_attribute( "social_profile_url" )
    #~ raw_title = "http://" + raw_title unless raw_title.nil?
    #~ raw_title
  #~ end 
  
  #~ def company_url
    #~ raw_title = read_attribute( "company_url" )
    #~ raw_title = "http://" + raw_title unless raw_title.nil?
    #~ raw_title
  #~ end 

 protected
    
  def make_activation_code
    self.deleted_at = nil
    self.activation_code = self.class.make_token
  end
  
  def normalize_identity_url
    self.identity_url = OpenIdAuthentication.normalize_url(identity_url) unless not_using_openid?
  rescue URI::InvalidURIError
    errors.add_to_base("Invalid OpenID URL")
  end
end
