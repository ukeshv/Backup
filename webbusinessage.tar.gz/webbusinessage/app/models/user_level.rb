class UserLevel < ActiveRecord::Base
	
	validates_presence_of :name,:message=>'Provide User Level Name'
	validates_uniqueness_of :name, :message=> 'User Level Name has been already exist'
	
	has_many :listings
	has_many :users
	
end
