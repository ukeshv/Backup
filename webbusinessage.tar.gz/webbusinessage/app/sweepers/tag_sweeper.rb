class TagSweeper < ActionController::Caching::Sweeper

  observe Tag,Tagging

  def after_save(record)
    clear_cache(record)
  end

  def after_update(record)
    clear_cache(record)
  end
  
	def clear_cache(record)
    expire_fragment(%r{views/top_tags.*})
	end

end
