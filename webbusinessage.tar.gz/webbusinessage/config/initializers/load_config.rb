APP_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/settings.yml")[RAILS_ENV].symbolize_keys
META_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/metatags.yml")[RAILS_ENV].symbolize_keys