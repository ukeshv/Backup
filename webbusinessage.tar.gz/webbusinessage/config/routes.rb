ActionController::Routing::Routes.draw do |map| 
  
   map.namespace(:admin) do |admin|
    admin.resources :geo_locations
    admin.resources :user_levels
    admin.resources :content_types
    admin.resources :specific_content_types
    admin.resources :categories
    admin.resources :blogs
    admin.resources :listings
    admin.resources :members
    admin.resources :settings
  end 
   
  
  # Restful Authentication Rewrites
  map.logout '/logout', :controller => 'sessions', :action => 'destroy'
  map.login '/login', :controller => 'sessions', :action => 'new'
  map.register '/register', :controller => 'users', :action => 'create'
  map.signup '/signup', :controller => 'users', :action => 'new'
  map.advertiser_signup '/advertiser_signup', :controller => 'advertisers', :action => 'new'
  map.activate '/activate/:activation_code', :controller => 'users', :action => 'activate', :activation_code => nil
  map.forgot_password '/forgot_password', :controller => 'passwords', :action => 'new'
  #map.reset_password '/reset_password/:reset_code', :controller => 'passwords', :action => 'edit'
  map.change_password '/change_password/:reset_code', :controller => 'passwords', :action => 'reset'
  map.open_id_complete '/opensession', :controller => "sessions", :action => "create", :requirements => { :method => :get }
  map.open_id_create '/opencreate', :controller => "users", :action => "create", :requirements => { :method => :get }
  map.simple_captcha '/simple_captcha/:action', :controller => 'simple_captcha'
  map.blog_edit_media '/blog_edit_media/:id', :controller => 'admin/blogs',:action=>'edit_media'
  map.blog_upload_media '/blog_upload_media/:id', :controller => 'admin/blogs',:action=>'upload_media'
  map.blog_active_media '/blog_active_media/:id', :controller => 'admin/blogs',:action=>'active_media' 
  map.homepage_featuredblogs '/homepage_featuredblogs', :controller => 'admin/blogs',:action=>'featured_in_homepage' 
  map.categorypage_featuredblogs '/categorypage_featuredblogs', :controller => 'admin/blogs',:action=>'featured_in_categorypage' 
  map.listing_edit_media '/listing_edit_media/:id', :controller => 'admin/listings',:action=>'edit_media'
  map.listing_upload_media '/listing_upload_media/:id', :controller => 'admin/listings',:action=>'upload_media'
  map.listing_active_media '/listing_active_media/:id', :controller => 'admin/listings',:action=>'active_media'
  map.homepage_featuredlistings '/homepage_featuredlistings', :controller => 'admin/listings',:action=>'featured_in_homepage' 
  map.categorypage_featuredlistings '/categorypage_featuredlistings', :controller => 'admin/listings',:action=>'featured_in_categorypage' 
  map.upload_listings '/upload_listings', :controller => 'admin/listings',:action=>'upload_listings' 
  map.listings_preview '/listings_preview', :controller => 'admin/listings',:action=>'listings_preview' 
  map.listings_final_upload '/listings_final_upload', :controller => 'admin/listings',:action=>'listings_final_upload' 
  map.download_logfile '/download_logfile', :controller => 'admin/listings',:action=>'download_logfile' 
  map.listing_reports '/listing_reports', :controller => 'admin/listings',:action=>'listing_reports' 
  map.listing_directory '/listing_directory', :controller => 'admin/listings', :action=>'listing_directory'
  map.listing_directory_category_content_type '/listing_directory/category/:cid/content_type/:ctypeid', :controller => 'admin/listings', :action=>'listing_directory'
  map.replicate_listing '/listing/replicate/:id',:controller=>'admin/listings',:action=>'replicate'
  map.manage_comments '/blogs/managecomments',:controller=>'admin/blogs',:action=>'manage_comments'
  map.listing_manage_comments '/listings/managecomments',:controller=>'admin/listings',:action=>'manage_comments'
  #map.advertiser_details '/user/:id/advertiser/new', :controller=>'users' ,:action=>'advertiser_member_edit'
  map.advertiser_upgrade '/advertisers/upgrade/:userid', :controller=>'advertisers' , :action=>'upgrade'
  map.advertiser_listings_website_url '/advertiser_listings_website_url',:controller=>'advertiser/listings',:action=>'website_url'
  map.advertise '/advertise',:controller=>'advertisers',:action=>'advertise'
  map.view_listing 'listing/:year/:month/:date/:url', :controller=>'listings', :action=>'show'
  map.view_blog 'blog/:year/:month/:date/:url', :controller=>'blogs', :action=>'show'
  map.listing_category_contenttype '/listings/category/:cid/content_type/:ctypeid', :controller=>'listings', :action=>'list_by_category_contenttype'
  map.list_by_tags '/tag/:name', :controller=>'users',:action=>'list_by_tag'
  map.search '/search',:controller=>'users',:action=>'search'
  map.aboutus '/Aboutus',:controller=>'staticpages',:action=>'aboutus'
  map.terms '/Terms_of_service',:controller=>'staticpages',:action=>'terms'
  map.privacy_policy '/Privacy_Policy',:controller=>'staticpages',:action=>'privacy_policy'
  map.contactus '/ContactUs',:controller=>'staticpages',:action=>'contactus'
  map.personal_marketing_ebook '/personal-marketing-ebook',:controller=>'staticpages',:action=>'personal_marketing_ebook'
  map.dashboard '/dashboard',:controller=>'users',:action=>'dashboard'
  map.saved_listings '/saved_listings',:controller=>'users',:action=>'saved_listings'
  map.recommended_listings '/recommended_listings',:controller=>'users',:action=>'recommended_listings'
  map.recently_viewed_listings '/recently_viewed_listings',:controller=>'users',:action=>'recently_viewed_listings'
  map.saved_blogs '/saved_blogs',:controller=>'users',:action=>'saved_blogs'
  map.recommended_blogs '/recommended_blogs',:controller=>'users',:action=>'recommended_blogs'
  map.recently_viewed_blogs '/recently_viewed_blogs',:controller=>'users',:action=>'recently_viewed_blogs'
  map.saved_search '/saved_searches',:controller=>'users',:action=>'saved_searches'
  map.advertiser_details 'advertisers/details/:userid', :controller=>'advertisers', :action=>'details'
  map.update_advertiser_details 'advertisers/update_details/:userid', :controller=>'advertisers', :action=>'update_details'
  map.list_by_categories 'category/:name/:cname',:controller=>'users',:action=>'categories'
  map.blog_categories '/blogs/category/:name/:cname',:controller=>'blogs',:action=>'categories'
  map.after_contactus '/thankspage/' ,:controller=>'staticpages',:action=>'after_contactus'
  map.user_password_change '/password_change', :controller=>'users', :action=>'change_password' 
  map.blog_rssfeed '/blog/feed', :controller=>'blogs' , :action=>'rss'
  map.media_download '/media_download', :controller=>'staticpages' , :action=>'media_kit_download'
  map.download '/download', :controller=>'staticpages' , :action=>'aboutus_download'
	map.feed '/feed' ,:controller => 'users', :action =>'feed'
  # Restful Authentication Resources
  map.resources :users ,:member=>{:myprofile=>:get},:collection=>{:subscribe_email=>:get}
  map.resources :passwords
  map.resource :session
  map.resources :blogs
  map.resources :listings
  # Home Page
  map.root :controller => 'sessions', :action => 'index'

  # Install the default routes as the lowest priority.
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
end
