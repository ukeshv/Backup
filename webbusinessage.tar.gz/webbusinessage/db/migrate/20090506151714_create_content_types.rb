class CreateContentTypes < ActiveRecord::Migration
  def self.up
    create_table :content_types do |t|
      t.string :name
      t.text :description
      t.string :placeholder,:limit=>100
      t.integer :position
      t.boolean :status,:default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :content_types
  end
end
