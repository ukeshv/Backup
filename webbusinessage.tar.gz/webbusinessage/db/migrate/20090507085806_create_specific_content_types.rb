class CreateSpecificContentTypes < ActiveRecord::Migration
  def self.up
    create_table :specific_content_types do |t|
      t.string :name
      t.boolean :status,:default=>false
      t.timestamps
    end
  end

  def self.down
    drop_table :specific_content_types
  end
end
