class CreateUserViewedListings < ActiveRecord::Migration
  def self.up
    create_table :user_viewed_listings do |t|
      t.integer :user_id
      t.integer :listing_id
      t.datetime :last_viewed_at
      t.timestamps
    end
  end

  def self.down
    drop_table :user_viewed_listings
  end
end
