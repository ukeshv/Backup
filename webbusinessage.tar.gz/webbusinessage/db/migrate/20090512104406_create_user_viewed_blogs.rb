class CreateUserViewedBlogs < ActiveRecord::Migration
  def self.up
    create_table :user_viewed_blogs do |t|
      t.integer :user_id
      t.integer :blog_id
      t.datetime :last_viewed_at
      t.timestamps
    end
  end

  def self.down
    drop_table :user_viewed_blogs
  end
end
