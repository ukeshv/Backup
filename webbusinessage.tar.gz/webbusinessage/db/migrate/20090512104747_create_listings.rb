class CreateListings < ActiveRecord::Migration
  def self.up
    create_table :listings do |t|
        t.string :url
        t.string :title
        t.text :short_description
        t.text :description        
        t.string :display_url
        t.text :destination_url
        t.boolean :is_sponsored,:default=>false
        
        t.integer :specific_content_type_id
        t.integer :geo_location_id
        t.integer :user_level_id
        
        t.integer :author_id
        t.integer :editor_id        
        t.string :editor_comments        
        t.string :status
        
        t.integer :featured_top
        t.integer :featured_cat
        t.string :sponsored_item1
        t.string :sponsored_item2
        
        t.integer :current_rank
        t.integer :editor_rating
        
        t.datetime :activated_from
        t.datetime :expiry_date

        t.integer :destination_url_views_count
        t.integer :summary_listing_page_views_count
        t.integer :full_listing_page_views_count
        t.integer :sponsored_item1_views_count
        t.integer :sponsored_item2_views_count

        t.text :trackback_urls
      t.timestamps
    end
  end

  def self.down
    drop_table :listings
  end
end
