class CreateListingCategories < ActiveRecord::Migration
  def self.up
    create_table :listing_categories do |t|
      t.integer :listing_id
      t.integer :category_id
      t.timestamps
    end
  end

  def self.down
    drop_table :listing_categories
  end
end
