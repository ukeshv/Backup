class CreateListingContentTypes < ActiveRecord::Migration
  def self.up
    create_table :listing_content_types do |t|
      t.integer :listing_id
      t.integer :content_type_id
      t.timestamps
    end
  end

  def self.down
    drop_table :listing_content_types
  end
end
