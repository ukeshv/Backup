class CreatePayments < ActiveRecord::Migration
  def self.up
    create_table :payments do |t|
      t.integer :user_id
      t.string :name, :state, :postal_code, :country, :correlation_id, :token_id,:transaction_id, :transaction_type, :payer_id, :limit=>100
      t.text :response
      t.datetime :payment_date
      t.timestamps
    end
  end

  def self.down
    drop_table :payments
  end
end
