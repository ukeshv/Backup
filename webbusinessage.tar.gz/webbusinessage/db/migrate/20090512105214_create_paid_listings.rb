class CreatePaidListings < ActiveRecord::Migration
  def self.up
    create_table :paid_listings do |t|
      t.integer :payment_id,:listing_id
      t.datetime :payment_valid_from,:payment_valid_to
      t.timestamps
    end
  end

  def self.down
    drop_table :paid_listings
  end
end
