class AddComments < ActiveRecord::Migration
  def self.up
    create_table "comments", :force => true do |t|
      t.column "comment", :text
      t.column "commentable_id", :integer
      t.column "commentable_type", :string
      t.column "user_id", :integer
      t.column "title", :string
      t.column "created_at", :datetime
      t.column "is_approved",:boolean,:default=>false
    end
  
  end

  def self.down
    drop_table :comments
  end
end
