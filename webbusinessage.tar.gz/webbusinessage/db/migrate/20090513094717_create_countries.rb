class CreateCountries < ActiveRecord::Migration
  def self.up
      create_table :countries do |t|
      t.string :continent_code
      t.string :country_code
      t.string :country_3code
      t.string :country_number
      t.string :country_name
    end
    country_file = File.expand_path(File.join(RAILS_ROOT, 'db/countries.csv'))    
    sql = ActiveRecord::Base.connection();
    sql.execute "LOAD DATA INFILE '#{country_file}' INTO TABLE countries  FIELDS TERMINATED BY ';' ENCLOSED BY '\"' LINES TERMINATED BY '\n' (continent_code,country_code,country_3code,country_number,country_name)";
  end

  def self.down
    drop_table :countries
  end
end
