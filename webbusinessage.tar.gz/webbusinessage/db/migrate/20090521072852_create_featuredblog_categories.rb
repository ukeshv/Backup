class CreateFeaturedblogCategories < ActiveRecord::Migration
  def self.up
    create_table :featuredblog_categories do |t|
      t.integer :blog_id
      t.integer :featured_cat
      t.integer :category_id
      t.timestamps
    end
  end

  def self.down
    drop_table :featuredblog_categories
  end
end
