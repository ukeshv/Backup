class CreateFeaturedlistingCategories < ActiveRecord::Migration
  def self.up
    create_table :featuredlisting_categories do |t|
      t.integer :listing_id
      t.integer :featured_cat
      t.integer :category_id
      t.timestamps
    end
  end

  def self.down
    drop_table :featuredlisting_categories
  end
end
