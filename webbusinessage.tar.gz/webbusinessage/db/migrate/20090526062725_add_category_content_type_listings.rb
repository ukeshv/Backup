class AddCategoryContentTypeListings < ActiveRecord::Migration
  def self.up
    add_column :listings, :category_id, :integer
    add_column :listings, :content_type_id, :integer
  end

  def self.down
    remove_column :listings, :category_id
    remove_column :listings, :content_type_id
  end
end
