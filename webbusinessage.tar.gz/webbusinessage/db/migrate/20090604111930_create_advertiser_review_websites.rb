class CreateAdvertiserReviewWebsites < ActiveRecord::Migration
  def self.up
    create_table :advertiser_review_websites do |t|
	t.string :website
	t.text :comment	
      t.timestamps
    end
  end

  def self.down
    drop_table :advertiser_review_websites
  end
end
