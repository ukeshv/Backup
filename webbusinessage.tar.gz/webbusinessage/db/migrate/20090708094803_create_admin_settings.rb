class CreateAdminSettings < ActiveRecord::Migration
  def self.up
    create_table :admin_settings do |t|
	t.boolean :auto_approve_comment,:default=>true  
      t.timestamps
    end
    execute "TRUNCATE TABLE admin_settings"
    AdminSetting.create(:auto_approve_comment=>true)
  end

  def self.down
    drop_table :admin_settings
  end
end
