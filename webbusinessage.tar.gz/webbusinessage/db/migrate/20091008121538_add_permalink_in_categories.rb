class AddPermalinkInCategories < ActiveRecord::Migration
  def self.up
		add_column :categories, :category_permalink,:string
				categories = Category.find(:all)
				categories.each do |category|
				category_name = category.name.strip	
				category.category_permalink = category_name.gsub(' ','-')
				category.save
				end
  end

  def self.down
			remove_column :categories, :category_permalink
  end
end
