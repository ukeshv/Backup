class AddCategoryMetatags < ActiveRecord::Migration
  def self.up
    add_column :categories,:metatag_title,:string
    add_column :categories,:metatag_desc,:text
    add_column :categories,:metatag_keywords,:text
  end

  def self.down
    remove_column :categories,:metatag_title
    remove_column :categories,:metatag_desc
    remove_column :categories,:metatag_keywords
  end
end
