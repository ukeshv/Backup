class AddBlogCategoryMetaTitle < ActiveRecord::Migration
  def self.up
    add_column :categories,:blog_metatag_title,:string
  end

  def self.down
    remove_column :categories,:blog_metatag_title
  end
end
