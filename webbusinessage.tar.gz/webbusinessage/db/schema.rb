# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20091022111541) do

  create_table "admin_settings", :force => true do |t|
    t.boolean  "auto_approve_comment", :default => true
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "advertiser_review_websites", :force => true do |t|
    t.string   "website"
    t.text     "comment"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "assets", :force => true do |t|
    t.string   "data_file_name"
    t.string   "data_content_type"
    t.integer  "data_file_size"
    t.integer  "attachings_count",  :default => 0
    t.datetime "created_at"
    t.datetime "data_updated_at"
  end

  create_table "attachings", :force => true do |t|
    t.integer  "attachable_id"
    t.integer  "asset_id"
    t.string   "attachable_type"
    t.boolean  "is_primary",      :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "attachings", ["asset_id"], :name => "index_attachings_on_asset_id"
  add_index "attachings", ["attachable_id"], :name => "index_attachings_on_attachable_id"

  create_table "blog_categories", :force => true do |t|
    t.integer  "blog_id"
    t.integer  "category_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "blogs", :force => true do |t|
    t.string   "url"
    t.string   "title"
    t.text     "short_description"
    t.text     "description"
    t.text     "trackback_urls"
    t.integer  "featured_top"
    t.integer  "featured_cat"
    t.string   "author"
    t.string   "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "categories", :force => true do |t|
    t.string   "name"
    t.integer  "parent_id",          :default => 0,     :null => false
    t.integer  "position"
    t.boolean  "status",             :default => false
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "category_permalink"
    t.string   "metatag_title"
    t.text     "metatag_desc"
    t.text     "metatag_keywords"
    t.string   "blog_metatag_title"
  end

  add_index "categories", ["parent_id"], :name => "index_categories_on_parent_id"

  create_table "comments", :force => true do |t|
    t.text     "comment"
    t.integer  "commentable_id"
    t.string   "commentable_type"
    t.integer  "user_id"
    t.string   "title"
    t.datetime "created_at"
    t.boolean  "is_approved",      :default => false
    t.string   "firstname"
    t.string   "lastname"
    t.string   "email"
    t.string   "website"
  end

  create_table "content_types", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.string   "placeholder", :limit => 100
    t.integer  "position"
    t.boolean  "status",                     :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "countries", :force => true do |t|
    t.string "continent_code"
    t.string "country_code"
    t.string "country_3code"
    t.string "country_number"
    t.string "country_name"
  end

  create_table "favorites", :force => true do |t|
    t.integer  "user_id"
    t.string   "favorable_type", :limit => 30
    t.integer  "favorable_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "featuredblog_categories", :force => true do |t|
    t.integer  "blog_id"
    t.integer  "featured_cat"
    t.integer  "category_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "featuredlisting_categories", :force => true do |t|
    t.integer  "listing_id"
    t.integer  "featured_cat"
    t.integer  "category_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "geo_locations", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "listing_categories", :force => true do |t|
    t.integer  "listing_id"
    t.integer  "category_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "listing_content_types", :force => true do |t|
    t.integer  "listing_id"
    t.integer  "content_type_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "listings", :force => true do |t|
    t.string   "url"
    t.string   "title"
    t.text     "short_description"
    t.text     "description"
    t.string   "display_url"
    t.text     "destination_url"
    t.boolean  "is_sponsored",                     :default => false
    t.integer  "specific_content_type_id"
    t.integer  "geo_location_id"
    t.integer  "user_level_id"
    t.integer  "author_id"
    t.integer  "editor_id"
    t.string   "editor_comments"
    t.string   "status"
    t.integer  "featured_top"
    t.integer  "featured_cat"
    t.string   "sponsored_item1"
    t.string   "sponsored_item2"
    t.integer  "current_rank"
    t.integer  "editor_rating"
    t.datetime "activated_from"
    t.datetime "expiry_date"
    t.integer  "destination_url_views_count"
    t.integer  "summary_listing_page_views_count"
    t.integer  "full_listing_page_views_count"
    t.integer  "sponsored_item1_views_count"
    t.integer  "sponsored_item2_views_count"
    t.text     "trackback_urls"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "category_id"
    t.integer  "content_type_id"
  end

  create_table "open_id_authentication_associations", :force => true do |t|
    t.integer "issued"
    t.integer "lifetime"
    t.string  "handle"
    t.string  "assoc_type"
    t.binary  "server_url"
    t.binary  "secret"
  end

  create_table "open_id_authentication_nonces", :force => true do |t|
    t.integer "timestamp",  :null => false
    t.string  "server_url"
    t.string  "salt",       :null => false
  end

  create_table "paid_listings", :force => true do |t|
    t.integer  "payment_id"
    t.integer  "listing_id"
    t.datetime "payment_valid_from"
    t.datetime "payment_valid_to"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "passwords", :force => true do |t|
    t.integer  "user_id"
    t.string   "reset_code"
    t.datetime "expiration_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "payments", :force => true do |t|
    t.integer  "user_id"
    t.string   "name",             :limit => 100
    t.string   "state",            :limit => 100
    t.string   "postal_code",      :limit => 100
    t.string   "country",          :limit => 100
    t.string   "correlation_id",   :limit => 100
    t.string   "token_id",         :limit => 100
    t.string   "transaction_id",   :limit => 100
    t.string   "transaction_type", :limit => 100
    t.string   "payer_id",         :limit => 100
    t.text     "response"
    t.datetime "payment_date"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "ratings", :force => true do |t|
    t.integer "rater_id"
    t.integer "rated_id"
    t.string  "rated_type"
    t.integer "rating",     :limit => 10, :precision => 10, :scale => 0
  end

  add_index "ratings", ["rated_type", "rated_id"], :name => "index_ratings_on_rated_type_and_rated_id"
  add_index "ratings", ["rater_id"], :name => "index_ratings_on_rater_id"

  create_table "roles", :force => true do |t|
    t.string "name"
  end

  create_table "roles_users", :id => false, :force => true do |t|
    t.integer "role_id"
    t.integer "user_id"
  end

  create_table "sessions", :force => true do |t|
    t.string   "session_id", :null => false
    t.text     "data"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "sessions", ["session_id"], :name => "index_sessions_on_session_id"
  add_index "sessions", ["updated_at"], :name => "index_sessions_on_updated_at"

  create_table "simple_captcha_data", :force => true do |t|
    t.string   "key",        :limit => 40
    t.string   "value",      :limit => 6
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "specific_content_types", :force => true do |t|
    t.string   "name"
    t.boolean  "status",     :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "taggings", :force => true do |t|
    t.integer  "tag_id"
    t.integer  "taggable_id"
    t.string   "taggable_type"
    t.datetime "created_at"
  end

  add_index "taggings", ["tag_id"], :name => "index_taggings_on_tag_id"
  add_index "taggings", ["taggable_id", "taggable_type"], :name => "index_taggings_on_taggable_id_and_taggable_type"

  create_table "tags", :force => true do |t|
    t.string "name"
  end

  create_table "tiny_mce_photos", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.integer  "user_id"
    t.string   "content_type"
    t.string   "filename"
    t.integer  "size"
    t.integer  "parent_id"
    t.string   "thumbnail"
    t.integer  "width"
    t.integer  "height"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "user_levels", :force => true do |t|
    t.string   "name",       :limit => 100
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "user_searches", :force => true do |t|
    t.integer  "user_id"
    t.string   "search_keyword"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "user_viewed_blogs", :force => true do |t|
    t.integer  "user_id"
    t.integer  "blog_id"
    t.datetime "last_viewed_at"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "user_viewed_listings", :force => true do |t|
    t.integer  "user_id"
    t.integer  "listing_id"
    t.datetime "last_viewed_at"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.string   "email",                      :limit => 100
    t.string   "firstname",                  :limit => 100
    t.string   "lastname",                   :limit => 100
    t.string   "user_role",                  :limit => 100
    t.string   "crypted_password",           :limit => 40
    t.string   "salt",                       :limit => 40
    t.string   "activation_code",            :limit => 40
    t.datetime "activated_at"
    t.integer  "geo_location_id"
    t.integer  "user_level_id"
    t.string   "linkedin_profile_url"
    t.string   "twitter_profile_url"
    t.string   "social_profile_url"
    t.boolean  "is_content_contribute",                     :default => false
    t.string   "alternate_email",            :limit => 100
    t.string   "company"
    t.string   "company_url"
    t.string   "address"
    t.string   "city",                       :limit => 100
    t.string   "user_state",                 :limit => 100
    t.integer  "country_id"
    t.string   "phone",                      :limit => 25
    t.string   "fax",                        :limit => 25
    t.string   "favourite_category_ids"
    t.boolean  "is_newsletter_notification",                :default => false
    t.datetime "last_logged_in"
    t.integer  "loggedin_count"
    t.text     "admin_notes"
    t.boolean  "status"
    t.string   "remember_token",             :limit => 40
    t.datetime "remember_token_expires_at"
    t.datetime "deleted_at"
    t.string   "identity_url"
    t.string   "login"
    t.string   "state",                                     :default => "passive", :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

end
