// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults
function select_all(classname)
{
  var check_boxes= document.getElementsByClassName(classname);
  val = 0;
  for(i=0;i<check_boxes.length;i++)
  {
    check_boxes[i].checked=true;
   // m = ($('listing_'+(check_boxes[i].value)).value);
   //val = parseInt(val) + parseInt(m);
  }
  //$('replace_price').innerHTML = "$" + val;
  //$('total').value = val
  return false;
}
  
function unselect_all(classname)
{
  var check_boxes= document.getElementsByClassName(classname);
  val =0;
  for(i=0;i<check_boxes.length;i++)
  {
    check_boxes[i].checked=false;
  }
  //$('replace_price').innerHTML = "$" + val;
  //$('total').value = val

  return false;
}

function change_category_blogs(category)
	{
  $('categoryid').value = category;
  new Ajax.Request("/admin/blogs/change_category_blogs/?id="+category,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
	}
  
function change_category_listings(category)
	{
  $('categoryid').value = category;
  new Ajax.Request("/admin/listings/change_category_listings/?id="+category,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
	}
	
 function filter_comments(val){
  new Ajax.Request("/admin/blogs/manage_comments/?comment="+val,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
 }
 
function filter_listings_comments(val){
new Ajax.Request("/admin/listings/manage_comments/?comment="+val,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
}
 
 
function filter_member_type(val){
 new Ajax.Request("/admin/members/index/?filter_member_type="+val,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
 }
 
 function filter_category(val){
 new Ajax.Request("/admin/members/index/?filter_category="+val,{asynchronous:true, evalScripts:true,onComplete:function(request){Element.hide('ajax-loader');}, onLoading:function(request){Element.show('ajax-loader');},insertion:Insertion.Top}); return false;
 }

function toggle_button()
{
if ($('terms').checked == false)
{
$('term_error').innerHTML="<font color='red'>Please select the Terms & Policies.</font>"
return false;
}
}

function adv_select_all(classname)
{
  var check_boxes= document.getElementsByClassName(classname);
  val = 0;
  for(i=0;i<check_boxes.length;i++)
  {
    check_boxes[i].checked=true;
    m = ($('listing_'+(check_boxes[i].value)).value);
   val = parseInt(val) + parseInt(m);
  }
  $('replace_price').innerHTML = "$" + val;
  $('total').value = val
  return false;
}
  
function adv_unselect_all(classname)
{
  var check_boxes= document.getElementsByClassName(classname);
  val =0;
  for(i=0;i<check_boxes.length;i++)
  {
    check_boxes[i].checked=false;
  }
  $('replace_price').innerHTML = "$" + val;
  $('total').value = val

  return false;
}

function savelist(obj){
  new Ajax.Request('/users/savelist/?id='+obj, {asynchronous:true, evalScripts:true}); return false;
}

 function update_count(listingid){
  new Ajax.Request('/listings/update_destination_count/?id='+listingid, {asynchronous:true, evalScripts:true});
}

function validate_contact_us(){
 var val = true;
 val = validate_firstname(val);
 val = validate_email(val);
 val = validate_comment(val);
 return val;
 }
 
 function validate_firstname(val){
if($('firstname').value =="" || $('firstname').value == null){
$('firstname_error').innerHTML="<font color='red'>Provide Firstname</font>";
$('firstname_error').style.display=''
val = false;
}
else{
$('firstname_error').style.display='none'
}
return val;
}
 
function validate_email(val){
if($('email').value =="" || $('email').value == null){
$('email_error').innerHTML="<font color='red'>Provide Email</font>";
$('email_error').style.display=''
val = false;
}
else if($('email').value !="" || $('email').value != null){
email = $('email').value;
var reg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  if(reg.test(email)==false){
  $('email_error').innerHTML="<font color='red'>Provide valid email</font>";
  $('email_error').style.display=''
  val = false;
  }
else{
$('email_error').style.display='none'
val = true;
}
}
else{
$('email_error').style.display='none'
}
return val;
}

function validate_comment(val){
if($('comment').value =="" || $('comment').value == null){
$('comment_error').innerHTML="<font color='red'>Provide Comment</font>";
$('comment_error').style.display=''
val = false;
}
else{
$('comment_error').style.display='none'
}
return val;
}


