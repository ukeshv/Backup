require 'test_helper'

class Admin::SettingsHelperTest < ActionView::TestCase
end
