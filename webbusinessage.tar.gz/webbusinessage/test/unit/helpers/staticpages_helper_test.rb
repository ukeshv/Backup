require 'test_helper'

class StaticpagesHelperTest < ActionView::TestCase
end
