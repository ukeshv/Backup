class AccountSettings::PasswordsController < ApplicationController
	before_filter :login_required
  
  def edit
    
  end
  
   
	 def update
     if (!params[:old_password].blank? && !params[:password].blank? && !params[:password_confirmation].blank?)
       
        if User.authenticateEmail(current_user.email, params[:old_password])
        
            if ((params[:password] == params[:password_confirmation]) && 
                              !params[:password_confirmation].blank?)
          current_user.password_confirmation = params[:password_confirmation]
          current_user.password = params[:password]
          
                    if current_user.save
                  flash[:notice] = APP_MESSAGE["password_update_success"]
                  #~ redirect_to profile_url(current_user.user_name)
                   redirect_to edit_user_account_settings_password_path(current_user)
                    else
                  flash.now[:error] = APP_MESSAGE["password_update_error"] 
                  render :action=>'edit'
                    end

            else
                  flash.now[:password_error] = APP_MESSAGE["new_password_mismatch"]
                  @old_password = params[:old_password]
                  render :action=>'edit'
            end
      else
        flash.now[:old_password_error] = APP_MESSAGE["old_password_error"]
        render :action=>'edit'
      end
      
      
  elsif (params[:old_password].blank? && params[:password].blank? && params[:password_confirmation].blank?)
       flash.now[:old_password_error] = "old password cant be blank"
    flash.now[:password_error] = "new password cant be blank"
    flash.now[:confirm_password_error] = " password confirmation cant be blank"
    render:action=>'edit'
    
  elsif params[:password].blank? && params[:password_confirmation].blank? && !params[:old_password].blank?
     if !User.authenticateEmail(current_user.email, params[:old_password])
        flash.now[:old_password_error] = "old password incorrect"
       end
    flash.now[:password_error] = "new password cant be blank"
    flash.now[:confirm_password_error] = "password confirmation cant be blank"
    render:action=>'edit'
    
  elsif params[:password].blank? && params[:old_password].blank? && !params[:password_confirmation].blank?
 
    flash.now[:password_error] = "new password cant be blank"
    flash.now[:old_password_error] = "old password cant be blank"
    render:action=>'edit'
    
  elsif params[:old_password].blank? && params[:password_confirmation].blank? && !params[:password].blank?  
      flash.now[:old_password_error] = "old password cant be blank"
      flash.now[:confirm_password_error] = "password confirmation cant be blank"
      render:action=>'edit'
      
  elsif params[:old_password].blank? && !params[:password_confirmation].blank? && !params[:password].blank?  
   
      flash.now[:old_password_error] = "old password cant be blank"
      render:action=>'edit'
      
  elsif params[:password].blank? && !params[:password_confirmation].blank? && !params[:old_password].blank? 
    if !User.authenticateEmail(current_user.email, params[:old_password])
        flash.now[:old_password_error] = "old password incorrect"
       end
   flash.now[:password_error] = "new password cant be blank"
   render:action=>'edit'
   
  else
   if !User.authenticateEmail(current_user.email, params[:old_password])
        flash.now[:old_password_error] = "old password incorrect"
       end
  flash.now[:confirm_password_error] = "password confirmation cant be blank"
  render:action=>'edit'
  end
	
end


end