class AccountSettings::ProfilesController < ApplicationController
	before_filter :login_required
	protect_from_forgery :except=>[:upload_media]
	
	def edit
		@user = User.find_by_id(current_user.id)
	end
	
	def update
		@user = User.find_by_id(current_user.id)
		if @user.update_attributes(params[:user])
			flash[:notice] = APP_MESSAGE["profile_update_success"]
			redirect_to edit_user_account_settings_profile_path(current_user)
		else  
			#flash.now[:error] = "some thing wrong"
			render :action => 'edit'  
		end  
	end
	
	def edit_media
	end	
	
	def upload_media
		@user = current_user
		if !params[:attachment].nil? && params[:attachment][:uploaded_data] != ""
		@attachment = Attachment.new(params[:attachment])
			if @attachment.valid?
			@user.attachment = @attachment
				if @user.save
					flash[:notice] = APP_MESSAGE["media_upload_success"]
					redirect_to edit_user_account_settings_profile_path(current_user)
				else
					flash.now[:error] = APP_MESSAGE["media_upload_fail2"]
					format.html { render :action => "edit" }
				end
			else
				flash.now[:error] = APP_MESSAGE["media_upload_fail2"]
				render :action=>'edit'
				
			end
		else
			flash.now[:error] = APP_MESSAGE["media_upload_fail1"]
			render :action=>'edit'
			
		end	
	end	
	
end
