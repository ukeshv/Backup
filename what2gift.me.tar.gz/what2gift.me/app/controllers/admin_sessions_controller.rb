# This controller handles the login/logout function of the site.  
class AdminSessionsController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  layout "admin"
  #include AuthenticatedSystem

  # render new.rhtml
  def new
  end

  def create
   
    logout_keeping_session!
    if(params['user_name'] == APP_CONFIG['user_name'] && params['password'] == APP_CONFIG['password'])
      flash[:success] == "Successfully logged!!!"
      session[:admin] = APP_CONFIG['id']
      redirect_to admin_user_path
      
    else
    admin = Admin.authenticate(params[:login], params[:password])
    if admin
        session[:admin] = admin.id
        #Protects against session fixation attacks, causes request forgery
        #protection if user resubmits an earlier form using back
        #button. Uncomment if you understand the tradeoffs.reset_session
        self.current_admin = admin
        new_cookie_flag = (params[:remember_me] == "1")
        handle_remember_cookie! new_cookie_flag
        redirect_to admin_users_path(current_admin)
        flash[:notice] = APP_MESSAGE["login_success"]
      else
        note_failed_signin
        @login       = params[:user_name]
        @remember_me = params[:remember_me]
        render :action => 'new'
      end
    end
    
  end
  
  def destroy
    admin_logout_killing_session!
    flash[:admin_login_notice] = APP_MESSAGE["signout_success"]
    redirect_to '/admin/login'
  end

protected
  # Track failed login attempts
  def note_failed_signin
    
    flash[:admin_login_error] = "Couldn't log you in as '#{params[:login]}'"
    logger.warn "Failed login for '#{params[:login]}' from #{request.remote_ip} at #{Time.now.utc}"
    
  end
end
