class Admins::EmailConfigrationsController < ApplicationController
	layout 'admin'
  before_filter :admin_login_required
# GET /categories
  # GET /categories.xml
  def index
    @email_configurations = EmailConfiguration.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @email_configurations }
    end
  end

  # GET /categories/1
  # GET /categories/1.xml
  def show
    @email_configuration = EmailConfiguration.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @email_configuration }
    end
  end

  # GET /categories/new
  # GET /categories/new.xml
  def new
    @email_configuration = EmailConfiguration.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @email_configuration }
    end
  end

  # GET /categories/1/edit
  def edit
    @email_configuration = EmailConfiguration.find(params[:id])
  end

  # POST /categories
  # POST /categories.xml
  def create
    @email_configuration = EmailConfiguration.new(params[:email_configuration])

    respond_to do |format|
      if @email_configuration.save
        flash[:notice] = APP_MESSAGE['category_create_success']
        format.html { redirect_to(admin_email_configuration_path) }
        format.xml  { render :xml => @email_configuration, :status => :created, :location => @email_configuration }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @email_configuration.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /categories/1
  # PUT /categories/1.xml
  def update
    @email_configuration = EmailConfiguration.find(params[:id])

    respond_to do |format|
      if @email_configuration.update_attributes(params[:email_configuration])
        flash[:notice] = APP_MESSAGE['category_update_success']
        format.html { redirect_to(admin_email_configuration_path) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @email_configuration.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /categories/1
  # DELETE /categories/1.xml
  def destroy
    @email_configuration = EmailConfiguration.find(params[:id])
    @email_configuration.destroy

    respond_to do |format|
      format.html { redirect_to(categories_url) }
      format.xml  { head :ok }
    end
  end
end
