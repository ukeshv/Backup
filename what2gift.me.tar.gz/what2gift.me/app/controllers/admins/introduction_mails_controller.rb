class Admins::IntroductionMailsController < ApplicationController
	layout 'admin'
  before_filter :admin_login_required
# GET /categories
  # GET /categories.xml
  def index
    @introduction_emails = IntroductionMail.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @introduction_emails }
    end
  end

  # GET /categories/1
  # GET /categories/1.xml
  def show
    @introduction_email = IntroductionMail.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @introduction_email }
    end
  end

  # GET /categories/new
  # GET /categories/new.xml
  def new
    @introduction_email = IntroductionMail.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @introduction_email }
    end
  end

  # GET /categories/1/edit
  def edit
    @introduction_email = IntroductionMail.find(params[:id])
  end

  # POST /categories
  # POST /categories.xml
  def create
    @introduction_email = IntroductionMail.new(params[:introduction_mail])

    respond_to do |format|
      if @introduction_email.save
        #flash[:notice] = APP_MESSAGE['category_create_success']
        format.html { redirect_to(admin_introduction_email_path) }
        format.xml  { render :xml => @introduction_email, :status => :created, :location => @introduction_email }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @introduction_email.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /categories/1
  # PUT /categories/1.xml
  def update
    @introduction_email = IntroductionMail.find(params[:id])

    respond_to do |format|
      if @introduction_email.update_attributes(params[:introduction_mail])
        #flash[:notice] = APP_MESSAGE['category_update_success']
        format.html { redirect_to(admin_introduction_email_path) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @introduction_email.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  def sent_email
    @introduction_emails = IntroductionMail.find(:all, :conditions=>["email_sent=?",false])
    if @introduction_emails.length > 0
      @introduction_emails.each do |introduction_email|
        UserMailer.deliver_introduction_email_notification(introduction_email)
        introduction_email.update_attributes(:email_sent =>true)
      end
      flash[:notice] = "Welcome mail sent successfully"
    else
      flash[:notice] = "Alerady send to all"
    end
    redirect_to(admin_introduction_email_path)
  end
  

  # DELETE /categories/1
  # DELETE /categories/1.xml
  def destroy
    @introduction_email = IntroductionMail.find(params[:id])
    @introduction_email.destroy

    respond_to do |format|
      format.html { redirect_to(categories_url) }
      format.xml  { head :ok }
    end
  end
end
