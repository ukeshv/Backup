class Admins::InventoriesController < ApplicationController
  layout 'admin'
  before_filter :admin_login_required
  before_filter :common_value, :only=>[:new, :create, :edit, :update]
  # GET /inventories
  # GET /inventories.xml
  def index
    @inventories = Inventory.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
      respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @inventories }
    end
  end

  # GET /inventories/1
  # GET /inventories/1.xml
  def show
    @inventory = Inventory.find(params[:id])
    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @inventory }
    end
  end

  # GET /inventories/new
  # GET /inventories/new.xml
  def new
    @inventory = Inventory.new
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @inventory }
    end
  end

  # GET /inventories/1/edit
  def edit
    @inventory = Inventory.find(params[:id])
  end

  # POST /inventories
  # POST /inventories.xml
  def create
    i = 0
    @inventory = Inventory.new(params[:inventory])
     while !params['images_list_'+i.to_s].nil?
      p = Hash["attachment"=>{"uploaded_data"=>""}]
      p["attachment"]["uploaded_data"] = params["images_list_"+i.to_s]
      attachment = Attachment.new(p["attachment"])
      @inventory.attachments << attachment
      i+=1
    end
    respond_to do |format|
        if @inventory.save 
        flash[:notice] = APP_MESSAGE['inventory_create_success']
        format.html { redirect_to(admin_inventory_path) }
        format.xml  { render :xml => @inventory, :status => :created, :location => @inventory }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @inventory.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /inventories/1
  # PUT /inventories/1.xml
  def update
    success = false
    @inventory = Inventory.find(params[:id])
  respond_to do |format|
    i = 0
    while !params['images_list_'+i.to_s].nil?
      p = Hash["attachment"=>{"uploaded_data"=>""}]
      p["attachment"]["uploaded_data"] = params["images_list_"+i.to_s]
      image = Attachment.new(p["attachment"])
      if image.valid?
        success = true
      end
      i+=1
    end
    if success
      i = 0
      @inventory.attachments.each{|a|a.destroy} if @inventory.attachments.length>0  
      while !params['images_list_'+i.to_s].nil?
        p = Hash["attachment"=>{"uploaded_data"=>""}]
        p["attachment"]["uploaded_data"] = params["images_list_"+i.to_s]
        image = Attachment.new(p["attachment"])
        if image.valid?
          @inventory.attachments<<image
        end
        i+=1
      end
    end
       if @inventory.update_attributes(params[:inventory])
        flash[:notice] = APP_MESSAGE['inventory_update_success']
        format.html { redirect_to(admin_inventory_path) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @inventory.errors, :status => :unprocessable_entity }
      end
  end
    
  end
  # DELETE /inventories/1
  # DELETE /inventories/1.xml
  def destroy
    @inventory = Inventory.find(params[:id])
    @inventory.destroy

    respond_to do |format|
      format.html { redirect_to(inventories_url) }
      format.xml  { head :ok }
    end
  end
  
protected
  def common_value
    @categories = Category.find(:all)
    @brands = Brand.find(:all)
    @vendors = Vendor.find(:all)
    @price_ranges = PriceRange.find(:all)
  end
  
end
