class  Admins::InviteeCategoriesController < ApplicationController
  # GET /invitee_categories
  # GET /invitee_categories.xml
  layout 'admin'
  before_filter :admin_login_required
  def index
    @invitee_categories = InviteeCategory.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @invitee_categories }
    end
  end

  # GET /invitee_categories/1
  # GET /invitee_categories/1.xml
  def show
    @invitee_category = InviteeCategory.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @invitee_category }
    end
  end

  # GET /invitee_categories/new
  # GET /invitee_categories/new.xml
  def new
    @invitee_category = InviteeCategory.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @invitee_category }
    end
  end

  # GET /invitee_categories/1/edit
  def edit
    @invitee_category = InviteeCategory.find(params[:id])
  end

  # POST /invitee_categories
  # POST /invitee_categories.xml
  def create
    @invitee_category = InviteeCategory.new(params[:invitee_category])

    respond_to do |format|
      if @invitee_category.save
        flash[:notice] = APP_MESSAGE['inviteecategory_create_success']
       format.html { redirect_to(admin_invitee_category_path) }
        format.xml  { render :xml => @invitee_category, :status => :created, :location => @invitee_category }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @invitee_category.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /invitee_categories/1
  # PUT /invitee_categories/1.xml
  def update
    @invitee_category = InviteeCategory.find(params[:id])

    respond_to do |format|
      if @invitee_category.update_attributes(params[:invitee_category])
        flash[:notice] = APP_MESSAGE['inviteecategory_update_success']
       format.html { redirect_to(admin_invitee_category_path) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @invitee_category.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /invitee_categories/1
  # DELETE /invitee_categories/1.xml
  def destroy
    @invitee_category = InviteeCategory.find(params[:id])
    @invitee_category.destroy

    respond_to do |format|
      format.html { redirect_to(invitee_categories_url) }
      format.xml  { head :ok }
    end
  end
end
