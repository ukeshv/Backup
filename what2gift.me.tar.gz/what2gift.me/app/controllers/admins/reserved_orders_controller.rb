class  Admins::ReservedOrdersController < ApplicationController
  layout 'admin'
  before_filter :admin_login_required
 
  def index
    @reserved_orders = WishList.all(:conditions=>"is_reserved = 1").paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @reserved_orders}
    end
  end

end
