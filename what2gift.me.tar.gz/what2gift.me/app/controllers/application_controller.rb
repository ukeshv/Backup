# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  helper :all # include all helpers, all the time
  protect_from_forgery # See ActionController::RequestForgeryProtection for details
  include ExceptionNotifiable
  include AuthenticatedSystem
  include UserAuthenticatedSystem
  # Scrub sensitive parameters from your log
  # filter_parameter_logging :password
  filter_parameter_logging :user_name, :email, :password, :password_confirmation
  before_filter :hosts
  
  def hosts
    $HOST = request.env['HTTP_HOST']
    referer = request.env['HTTP_REFERER'] 
    $REQ_URI = request.env['REQUEST_URI']
    unless referer.to_s.include?('locations')
      $REFERER = referer      
    end    
  end
  
  private        
    def gateway
      ActiveMerchant::Billing::Base.mode = :test 
      
      @gateway ||= ActiveMerchant::Billing::PaypalExpressGateway.new(:login => 'uthira_1247656879_biz_api1.gmail.com', :password => '1247656885', :signature => 'A8oIbp-O3u2QcQBmMAmLKPs3c3zkAV6C3ryOeENb6m.miIgcjCY3aj50')
    end
end
