class Browse::ContactsController < ApplicationController
	def index
		@email_configuration = EmailConfiguration.find :first
	end
	
end
