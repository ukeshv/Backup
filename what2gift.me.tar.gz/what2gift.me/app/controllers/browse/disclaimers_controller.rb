class Browse::DisclaimersController < ApplicationController
end
