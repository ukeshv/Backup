class Browse::FaqsController < ApplicationController
	layout 'application', :only=>'dummy'
	
	
	def dummy
		
	end
end
