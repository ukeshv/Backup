class Browse::RernsofusesController < ApplicationController
end
