class Browse::TermsofusesController < ApplicationController
	
	layout 'application',:only =>'dummy'

def dummy
	
end

	
end
