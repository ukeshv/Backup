class DashboardsController < ApplicationController
	before_filter :login_required
	
	def index
	@user = current_user
	@wish_lists = []
	@my_invites = []
	@reserved_gifts = []
	session[:micro_link] = nil
	session[:checkout_id] = nil
	if params[:event_status] == "past"
		#@events = @user.events.find(:all, :conditions=>["event_date < ?",Date.today]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 20
		@events = @user.events.paginate :conditions=>["event_date < ?",Date.today],:page => params[:page], :order => 'created_at DESC', :per_page => 3
		@event = @user.events.find(:first,:conditions=>["event_date < ?",Date.today], :order => 'created_at DESC') if @user.events
	else
		#@events = @user.events.find(:all, :conditions=>["event_date >= ?",Date.today]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 20
		@events = @user.events.paginate :conditions=>["event_date >= ?",Date.today],:page => params[:page], :order => 'created_at DESC', :per_page => 3
		@event = @user.events.find(:first,:conditions=>["event_date >= ?",Date.today], :order => 'created_at DESC') if @user.events
	end
	@user.events.each{|event| @reserved_gifts += event.wish_lists.find(:all, :conditions=>["is_gifted=?",true]) }
	@reserved_gifts = @reserved_gifts.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 6
	
	@wish_lists = @event.wish_lists.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 6 if @event 
	@my_invites = @user.invitees
	respond_to do |format|
				format.html{}
				format.js{
					render :update do |page| 
						if params[:wish_list] == "true"
							page.replace_html "dashboard_my_wish_list", :partial=>'dashboard_my_wish_list'
						elsif params[:gifted_list] == "true"
							page.replace_html "dashboard_my_gift_list", :partial=>'dashboard_my_gift_list'
						else
							page.replace_html "new_list", :partial=>'dash_board_index'
						end
					end
				}
			end
		end
		
	def destroy
		@wish_list = WishList.find_by_id(params[:id])
		@event = @wish_list.event
		if @wish_list
			@wish_list.destroy
			@wish_lists = []
			@wish_lists = @event.wish_lists.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 6 if @event 
			#@wish_lists = @wish_lists.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 6
			render :update do |page|
				page.replace_html "dashboard_my_wish_list", :partial=>'/dashboards/dashboard_my_wish_list'
			end
		end
	end
	
	def show_event_wishlist
		@event = Event.find_by_id(params[:id])
		@wish_lists = @event.wish_lists.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 6
		render :update do |page|
			page.replace_html 'dashboard_my_wish_list', :partial=> '/dashboards/dashboard_my_wish_list'
		end	
	end	
	
	
end
