class Events::CheckoutListsController < ApplicationController
	
	def create
	session[:checkout_id] << params[:wish_list_id].to_i
		@event = Event.find_by_id(params[:event_id])
		@invitee = Invitee.find_by_url_link(session[:micro_link])
		#@checkouts = Inventory.find_all_by_id(session[:checkout_id])
		#@event = Event.find_by_id(params[:event_id])
		wish_list = WishList.find_by_id(params[:wish_list_id].to_i)
		original_condition_string =  "`invitee_category_id` LIKE 'XXX' OR  `invitee_category_id` LIKE 'XXX,%' OR  `invitee_category_id` LIKE '%,XXX,%' OR  `invitee_category_id` LIKE '%,XXX'"
		condition_array = []
		for x in @invitee.invitee_category_id.split(',')
			condition_array << original_condition_string.gsub('XXX',x)
		end
		condition_string = condition_array.join(" OR ")
		condition_string1 = session[:checkout_id] != [] ? "wish_lists.id NOT in (#{session[:checkout_id].join(",")}) and"  : ""
		@wish_lists = @event.wish_lists.find(:all,:conditions=>["id NOT in (?) and is_gifted=? and is_reserved=? and #{condition_string1} (#{condition_string})",session[:checkout_id],false,false]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 3

		@categories = Category.find :all
		@brands = Brand.find :all
		@inventories = Inventory.all
		render :update do |page| 
			page.replace_html "invitationGalleryArea", :partial=>'/invitees/my_gift_list'
			#page.replace_html "invitationGalleryAreaPagination", :text=>"#{will_paginate @wish_lists,:renderer => 'RemoteLinkRenderer', :params=>{:action=>'index'},:prev_label =>'<img src="/images/Larrow.gif"/>', :next_label => '<img src="/images/Rarrow.gif"/>'}"
			page.replace_html "success_message_in_checkout_list", :text=>"#{wish_list.inventory.url_unescape(wish_list.inventory.name)} is added to Checklist"
			page.replace_html "item_num", :text=>"#{session[:checkout_id].length} items added."
			page.visual_effect(:appear, 'success_message_in_checkout_list',  :duration => 5.0)
			page.visual_effect(:fade, 'success_message_in_checkout_list',  :duration => 6.0)
		end
	end
	
	def destroy
		session[:checkout_id].delete(params[:inventory_id]) if params[:inventory_id]
		@checkouts = Inventory.find_all_by_id(session[:checkout_id])
		@event = Event.find_by_id(params[:event_id])
		render :update do |page| 
			page.replace_html "my_checkout_list", :partial=>'/invitees/checkout_list'
		end
	end
	
	
end


