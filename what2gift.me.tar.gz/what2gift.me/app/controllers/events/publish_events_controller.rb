class Events::PublishEventsController < ApplicationController
		before_filter :login_required
	def new
		@invitees = []
		@invitees_ids = []
		@event = Event.find_by_id(params[:event_id])
		if @event && @event.host_id == current_user.id
		@invitees = @event.invitees.find(:all).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 1 if @event
		@invitee = Invitee.new
		@event.invitees.collect{|inv| @invitees_ids << inv.id}
		@invitees_ids = @invitees_ids.join(",")
		else
			render :text=>"Wrong input"
		end
	end
	
	def create
		@invitees = []
		@invitees_ids = []
		@event = Event.find(params[:event_id])
		@invitee = Invitee.new(params[:invitee])
		
		if @invitee.valid?
			@event.invitees << @invitee
			@invitees = @event.invitees.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 1
			@invitee = Invitee.new
			@event.invitees.collect{|inv| @invitees_ids << inv.id}
			@invitees_ids = @invitees_ids.join(",")
			render :update do |page|
				page.replace_html "update_my_contacts", :partial => "update_my_contacts"
				page.replace_html "LeftCon", :partial => "invitee_form_field"
				page.replace_html "success_message_in_contact_list", :text=>"<br/><span class='success'>#{APP_MESSAGE["add_contact_success"]}</span>"
				page.visual_effect(:appear, 'success_message_in_contact_list',  :duration => 2.5)
				page.visual_effect(:fade, 'success_message_in_contact_list',  :duration => 10.5)
			end
		else
			@invitees = @event.invitees.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 1
			render :update do |page|
				page.replace_html "error_message_in_contact_list", :text=>"<br/><span class='warning'>#{APP_MESSAGE[contact_details_error]}</span>"
				page.visual_effect(:appear, 'error_message_in_contact_list',  :duration => 2.5)
				page.visual_effect(:fade, 'error_message_in_contact_list',  :duration => 10.5)
			end
		end
		#@invitee = Invitee.new()
		
	end
	
	def edit
		@invitee = Invitee.find_by_id(params[:invite_id])
		render :text=> @invitee.to_json
	end
	
	def update
		@invitees_ids = []
		@event = Event.find_by_id(params[:event_id])
		@invitee = Invitee.find_by_id(params[:udatestatus])
		@invitee.update_attributes(params[:invitee]) if @invitee
		@invitees = @event.invitees
		@invitee = Invitee.new
		@event.invitees.collect{|inv| @invitees_ids << inv.id}
		@invitees_ids = @invitees_ids.join(",")
		render :update do |page|
			page.replace_html "update_my_contacts", :partial => "update_my_contacts"
			page.replace_html "LeftCon", :partial => "invitee_form_field"
			page.replace_html "success_message_in_contact_list", :text=>"<br/><span class='success'>#{APP_MESSAGE[contact_update_success]}</span>"
			page.visual_effect(:appear, 'success_message_in_contact_list',  :duration => 5.0)
			page.visual_effect(:fade, 'success_message_in_contact_list',  :duration => 6.0)
		end
	end
	
	def destroy
		@invitees_ids = []
		@invitee = Invitee.find_by_id(params[:invite_id])
		@event = Event.find_by_id(params[:event_id])
		@invitee.destroy if @invitee
		@invitees = @event.invitees
		@invitee = Invitee.new
		@event.invitees.collect{|inv| @invitees_ids << inv.id}
		@invitees_ids = @invitees_ids.join(",")
		render :update do |page|
			page.replace_html "update_my_contacts", :partial => "update_my_contacts"
			page.replace_html "LeftCon", :partial => "invitee_form_field"
			page.replace_html "success_message_in_contact_list", :text=>"<br/><span class='success'>#{APP_MESSAGE[contact_delete_success]}</span>"
			page.visual_effect(:appear, 'success_message_in_contact_list',  :duration => 5.0)
			page.visual_effect(:fade, 'success_message_in_contact_list',  :duration => 6.0)
		end
	end
	
	def send_invitation
		if !params[:invite_id].nil? && !params[:invite_id].empty? && !params[:invite_id].blank? && params[:invite_id] != ""
			@invitees = Invitee.find_all_by_id(params[:invite_id].split(","))
			@invitees.each do |invitee|
				UserMailer.deliver_send_invitation_to_invitee(invitee.event.host, invitee)
			end
			render :update do |page|
				page.replace_html "success_message_in_contact_list", :text=>"<br/><span class='success'>#{APP_MESSAGE[send_invite_success]}</span>"
				page.visual_effect(:appear, 'success_message_in_contact_list',  :duration => 5.0)
				page.visual_effect(:fade, 'success_message_in_contact_list',  :duration => 6.0)
			end
		else
			render :update do |page|
				page.replace_html "error_message_in_contact_list", :text=>"<br/><span class='warning'>#{APP_MESSAGE[send_invite_fail]}</span>"
				page.visual_effect(:appear, 'error_message_in_contact_list',  :duration => 5.0)
				page.visual_effect(:fade, 'error_message_in_contact_list',  :duration => 6.0)
			end
		end
	end
	

end
