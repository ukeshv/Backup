class Events::WishListsController < ApplicationController
	#layout 'dashboard'
	layout 'application', :only=> 'dummy'
	def index
		 @inventories = Inventory.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 2
					@wish_list = WishList.new(params[:wish_list])
					@wish_lists = WishList.find(:all)
					@event = Event.find(:first)
				respond_to do |format|
				format.html{}
				format.js{
					render :update do |page| 
						page.replace_html "giftResult", :partial=>'wish_list_form'
					end
				}
			end
	end
	
	def new
		      
      	 
	end

	def create
		
					@inventories = Inventory.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
					wish_list = WishList.create(:event_id=>params[:event_id], :inventory_id=>params[:inventory_id])
					@inventory= Inventory.find(params[:inventory_id]).name
					render :update do |page|
					@wish_lists = WishList.find(:all)
					 page.replace_html "RightCon", :partial => "wish_list_form"
		
 	end
	end

  def destroy
					@wish_list = WishList.find(params[:wish_list_id])
					@wish_list = WishList.find(params[:wish_list_id])
					@wish_list.destroy
					render :update do |page|
					@wish_lists = WishList.find(:all)
					render :partial => "wish_list_form", :collection => @wish_lists
					page.replace_html "RightCon", :partial => "wish_list_form"
	end 
end

def show
	@inventories = Inventory.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 2
		render :update do |page| 
						page.replace_html "giftResult", :partial=>'wish_list_form'
					end
end


	def dummy
	end
	
end
