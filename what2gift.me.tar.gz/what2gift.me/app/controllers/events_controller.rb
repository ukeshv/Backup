class EventsController < ApplicationController
	before_filter :login_required
	before_filter :common_collection, :only=>[:new, :create, :update, :remove_event_images]
	def new
		if params[:event_id]
			@event = Event.find_by_id(params[:event_id])
			if(!@event)
				render :text=> "Wrong input"
			elsif(@event.host_id != current_user.id)
				render :text=> "Wrong input"
			end
		else
			@event = Event.new()
		end
		respond_to do |format|
			format.html{}
			format.js{
				render :update do |page| 
					page.replace_html "RightCon", :partial=>'right_side'
				end
			}
		end
	end
	
	def create
		if(params[:event][:persona_id] != "" && params[:event][:event_type_id] != "" && params[:event][:description].strip != "")
			if params[:event_update_id] != "" && !params[:event_update_id].nil? && !params[:event_update_id].empty?
				@event = Event.find_by_id(params[:event_update_id])
				if @event
					@event.update_attributes(params[:event])
					if params[:attachment] && params[:attachment][:uploaded_data]
						@event.attachments << Attachment.new(params[:attachment])
					end
					if params[:invitation] && params[:invitation][:uploaded_data]
						invite_attachment = Attachment.new(params[:invitation])
						invite_attachment.is_invitation = true
						@event.attachments << invite_attachment
					end
				end
			else
				@event = Event.create(params[:event])
				current_user.events << @event 
				if params[:attachment] && params[:attachment][:uploaded_data]
					@event.attachments << Attachment.new(params[:attachment])
				end
				if params[:invitation] && params[:invitation][:uploaded_data]
					invite_attachment = Attachment.new(params[:invitation])
					invite_attachment.is_invitation = true
					@event.attachments << invite_attachment
				end
			end
			@events = @user.events.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 3
			respond_to do |format|
					format.html{}
					format.js do
							render :update do |page|
								page.replace_html "LeftCon", :partial=>'left_side'
								page.replace_html "RightCon", :partial=>'right_side'
							end
					end
				end
		else
			render :update do |page|
				#render :text => "Failure"
			end
		end
	end
	
	def edit
		
	end
	
	def remove_event_images
		if params[:id]
      attachment = Attachment.find(params[:id])
      @event = Event.find_by_id(attachment.attachable_id)
      attachment.destroy
      respond_to do |format|
        format.html{}
        format.js  {
          render :update do |page|            
            page.replace_html "LeftCon", :partial=>'left_side'
          end
        }
      end
    end
	end
	
	
	def update
		@event = Event.find(params[:id])
		if @event
			@event.update_attributes(params[:event])
			if params[:attachment] && params[:attachment][:uploaded_data]
				@event.attachments << Attachment.new(params[:attachment])
			end
			if params[:invitation] && params[:invitation][:uploaded_data]
				invite_attachment = Attachment.new(params[:invitation])
				invite_attachment.is_invitation = true
				@event.attachments << invite_attachment
			end
		end
		@events = @user.events.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 3
		
		respond_to do |format|
					format.html{}
					format.js do
					if ((params[:invitation] && params[:invitation][:uploaded_data]) || (params[:attachment] && params[:attachment][:uploaded_data]))
						responds_to_parent do
							render :update do |page|
								page.replace_html "LeftCon", :partial=>'left_side'
								page.replace_html "RightCon", :partial=>'right_side'
							end
						end
					else
						render :update do |page|
								page.replace_html "LeftCon", :partial=>'left_side'
								page.replace_html "RightCon", :partial=>'right_side'
							end
					end
					
					end
				end
	end
	
def common_collection
	@user = current_user
	@events = @user.events.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 3
	@event_types = EventType.find :all
	@personas = Persona.find :all
end

end
