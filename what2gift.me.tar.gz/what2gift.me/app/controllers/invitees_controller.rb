class InviteesController < ApplicationController
	#before_filter :login_required
	layout "application", :only=> :dummy
	layout "inviteenew", :only=> :index
	
	def index
		if session[:checkout_id] && session[:checkout_id].length > 0
			session[:checkout_id] = session[:checkout_id]
			@checkout_lists = WishList.find_all_by_id(session[:checkout_id])
		else
			session[:checkout_id] = []
		end
		if params[:id]
			@invitee = Invitee.find_by_url_link(params[:id])
			
			if @invitee
				@event = @invitee.event
				@categories = Category.find(:all, :order=>'name ASC')
				@brands = Brand.find(:all, :order=>'name ASC')
				@inventories = Inventory.all
				@price_ranges = PriceRange.find :all
			original_condition_string =  "`invitee_category_id` LIKE 'XXX' OR  `invitee_category_id` LIKE 'XXX,%' OR  `invitee_category_id` LIKE '%,XXX,%' OR  `invitee_category_id` LIKE '%,XXX'"
					condition_array = []
					for x in @invitee.invitee_category_id.split(',')
						condition_array << original_condition_string.gsub('XXX',x)
					end
					condition_string = condition_array.join(" OR ")
          condition_string1 = session[:checkout_id] != [] ? "wish_lists.id NOT in (#{session[:checkout_id].join(",")}) and"  : ""
					@reserved_items = @event.wish_lists.find(:all,:conditions=>["is_reserved=? and reserved_at <=? and #{condition_string1} (#{condition_string})",true, (Date.today - 1)])
					if @reserved_items.length > 0
						@reserved_items.each do |reserved_item|
							reserved_item.update_attributes(:is_reserved => false, :need_sent_mail=>false, :reserved_at=>nil, :invitee_id=>nil)
						end
					end
				@wish_lists = @event.wish_lists.find(:all,:conditions=>["is_gifted=? and is_reserved=? and #{condition_string1} (#{condition_string})",false,false]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
				session[:micro_link] = params[:id]
				session[:event_id] = @event.id
				if session[:checkout_id]
					@checkouts = Inventory.find_all_by_id(session[:checkout_id])
				end
			else
				if current_user
					redirect_to user_dashboards_path(current_user)
				else
					redirect_to "/login"
				end
			end
		else
			if current_user
					redirect_to user_dashboards_path(current_user)
				else
					redirect_to "/login"
				end
		end
		  respond_to do |format|
				format.html{}
				format.js{
					render :update do |page| 
						page.replace_html "invitationGalleryArea", :partial=>'my_gift_list'
					end
				}
			end
	end
	
	
def checkout_lists
	session[:checkout_id] << params[:wish_list_id].to_i if params[:wish_list_id]
		@event = Event.find_by_id(params[:event_id])
		@invitee = Invitee.find_by_url_link(session[:micro_link])
		#@checkouts = Inventory.find_all_by_id(session[:checkout_id])
		#@event = Event.find_by_id(params[:event_id])
		wish_list = WishList.find_by_id(params[:wish_list_id].to_i) if params[:wish_list_id]
		original_condition_string =  "`invitee_category_id` LIKE 'XXX' OR  `invitee_category_id` LIKE 'XXX,%' OR  `invitee_category_id` LIKE '%,XXX,%' OR  `invitee_category_id` LIKE '%,XXX'"
		condition_array = []
		for x in @invitee.invitee_category_id.split(',')
			condition_array << original_condition_string.gsub('XXX',x)
		end
		condition_string = condition_array.join(" OR ")
		condition_string1 = session[:checkout_id] != [] ? "id NOT in (#{session[:checkout_id].join(",")}) and"  : ""
		@wish_lists = @event.wish_lists.find(:all,:conditions=>["is_gifted=? and is_reserved=? and #{condition_string1} (#{condition_string})",false,false]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
		@checkout_lists = WishList.find_all_by_id(session[:checkout_id])
		@categories = Category.find :all
		@brands = Brand.find :all
		@inventories = Inventory.all
		render :update do |page| 
			page.replace_html "invitationGalleryArea", :partial=>'my_gift_list'
			page.replace_html "invitationGalleryArea1", :partial=>'my_order_details'
			#page.replace_html "invitationGalleryAreaPagination", :text=>"#{will_paginate @wish_lists,:renderer => 'RemoteLinkRenderer', :params=>{:action=>'index'},:prev_label =>'<img src="/images/Larrow.gif"/>', :next_label => '<img src="/images/Rarrow.gif"/>'}"
			if wish_list
			#page.replace_html "success_message_in_checkout_list", :text=>"#{wish_list.inventory.name} is added to Checklist"
			page.replace_html "item_num", :text=>"#{@checkout_lists.length} item(s) added into the shopping cart."
			#page.visual_effect(:appear, 'success_message_in_checkout_list',  :duration => 5.5)
			#page.visual_effect(:fade, 'success_message_in_checkout_list',  :duration => 10.5)
			end
		end
	end
	
	
	def destroy
		session[:checkout_id].delete(params[:inventory_id]) if params[:inventory_id]
		@checkouts = Inventory.find_all_by_id(session[:checkout_id])
		@event = Event.find_by_id(params[:event_id])
		render :update do |page| 
			page.replace_html "my_checkout_list", :partial=>'/invitees/checkout_list'
		end
	end
	
def list_wish_lists
	#here id is specified user id not wish_lists id
	@event = Event.find_by_id(params[:event_id])
	@invitee = Invitee.find_by_url_link(session[:micro_link])
	@inventories = []
	@new_wishlists = []
	@wish_lists = @event.wish_lists
	original_condition_string =  "`invitee_category_id` LIKE 'XXX' OR  `invitee_category_id` LIKE 'XXX,%' OR  `invitee_category_id` LIKE '%,XXX,%' OR  `invitee_category_id` LIKE '%,XXX'"
	condition_array = []
	for x in @invitee.invitee_category_id.split(',')
		condition_array << original_condition_string.gsub('XXX',x)
	end
	condition_string = condition_array.join(" OR ")
  condition_string1 = session[:checkout_id] != [] ? "wish_lists.id NOT in (#{session[:checkout_id].join(",")}) and"  : ""
	if(params[:brand][:id] != "" && params[:inventory][:id] != "" && params[:category][:id] != "")
		@wish_lists = @wish_lists.find(:all, :joins=>:inventory, :conditions=>["inventories.brand_id=? and inventories.price_range_id=? and inventories.category_id=? and is_gifted=? and is_reserved=? and #{condition_string1} (#{condition_string})", params[:brand][:id], params[:inventory][:id], params[:category][:id], false, false]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
elsif(params[:brand][:id] != "" && params[:inventory][:id] != "" && params[:category][:id] == "")
	@wish_lists = @wish_lists.find(:all, :joins=>:inventory, :conditions=>["inventories.brand_id=? and inventories.price_range_id=? and is_gifted=? and is_reserved=? and #{condition_string1} (#{condition_string})", params[:brand][:id], params[:inventory][:id], false, false]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
elsif(params[:brand][:id] != "" && params[:inventory][:id] == "" && params[:category][:id] != "")
	@wish_lists = @wish_lists.find(:all, :joins=>:inventory, :conditions=>["inventories.brand_id=? and inventories.category_id=? and is_gifted=? and is_reserved=? and #{condition_string1} (#{condition_string})", params[:brand][:id], params[:category][:id], false, false]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
elsif(params[:brand][:id] == "" && params[:inventory][:id] != "" && params[:category][:id] != "")
	@wish_lists = @wish_lists.find(:all, :joins=>:inventory, :conditions=>["inventories.price_range_id=? and inventories.category_id=? and is_gifted=? and is_reserved=? and #{condition_string1} (#{condition_string})", params[:inventory][:id], params[:category][:id], false, false]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
elsif(params[:brand][:id] != "" && params[:inventory][:id] == "" && params[:category][:id] == "")
	@wish_lists = @wish_lists.find(:all, :joins=>:inventory, :conditions=>["inventories.brand_id=? and is_gifted=? and is_reserved=? and #{condition_string1} (#{condition_string})", params[:brand][:id], false, false]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
elsif(params[:brand][:id] == "" && params[:inventory][:id] != "" && params[:category][:id] == "")
	@wish_lists = @wish_lists.find(:all, :joins=>:inventory, :conditions=>["inventories.price_range_id=? and is_gifted=? and is_reserved=? and #{condition_string1} (#{condition_string})", params[:inventory][:id], false, false]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
elsif(params[:brand][:id] == "" && params[:inventory][:id] == "" && params[:category][:id] != "")
	@wish_lists = @wish_lists.find(:all, :joins=>:inventory, :conditions=>["inventories.category_id=? and is_gifted=false and is_reserved=false and #{condition_string1} (#{condition_string})", params[:category][:id]]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
elsif(params[:brand][:id] == "" && params[:inventory][:id] == "" && params[:category][:id] == "")
	@wish_lists = @wish_lists.paginate :conditions=>"is_gifted=false and is_reserved=false and #{condition_string1} (#{condition_string})", :page => params[:page], :order => 'created_at DESC', :per_page => 10
end
@event = Event.find_by_id(params[:event_id])
@category = Category.find_by_id(params[:category][:id]) if(params[:category][:id] != "")
@brand = Brand.find_by_id(params[:brand][:id]) if(params[:brand][:id] != "")
@price_range = PriceRange.find_by_id(params[:inventory][:id]) if(params[:inventory][:id] != "")
@inventory = @inventories.first if @inventories.length > 0
	respond_to do |format|
					format.html{}
					format.js{
						render :update do |page| 
							page.replace_html "invitationGalleryArea", :partial=>'my_gift_list'
						end
					}
				end
end
	
	def dummy
	end
	
end
