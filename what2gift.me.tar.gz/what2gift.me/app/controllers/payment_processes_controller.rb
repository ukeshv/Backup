class PaymentProcessesController < ApplicationController
	layout "inviteenew"
	before_filter :login_required
	def index
		@user = current_user
		@invitee = Invitee.find_by_url_link(session[:micro_link])
			if @invitee
				@event = @invitee.event
				@categories = Category.find :all
				@brands = Brand.find :all
				@inventories = Inventory.all
				if session[:checkout_id] && session[:checkout_id].length > 0
					@wish_lists = WishList.find(:all, :conditions=>["id in (?) and is_reserved=? and is_gifted=?", session[:checkout_id],false,false]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 10
				
				end
				#session[:micro_link] = params[:id]
				#session[:event_id] = @event.id
				if session[:checkout_id]
					@checkouts = Inventory.find_all_by_id(session[:checkout_id])
				end
			else
				render :template => "/payment_processes/status"
			end
	end

	def reserve_payment
		inventory_item_name = []
		inventory_item_id = []
		if session[:checkout_id] && session[:checkout_id].length
			session[:checkout_id].each do |wishlist_id|
				@reserve_from_list = WishList.find_by_id(wishlist_id)
				if @reserve_from_list
					@reserve_from_list.update_attributes(:is_reserved => true, :need_sent_mail=>true, :reserved_at=>Time.now, :invitee_id=>current_user.id)
					inventory_item_name << @reserve_from_list.inventory.url_unescape(@reserve_from_list.inventory.name)
					inventory_item_id << @reserve_from_list.inventory.productid
				end
			end
		UserMailer.deliver_reserved_item_notification(current_user,inventory_item_name,inventory_item_id)
			session[:checkout_id] = nil
			#session[:micro_link] = nil
			render :update do |page| 
				#page.replace_html "success_message_in_checkout_list", :text=>'Gift was resreved'
				page.replace_html "invitationGalleryArea", :partial=>'my_gift_list'
				page.replace_html "success_message_in_checkout_list", :text=>"Gifts you selected is/are reserved"
				#page.hide "main_content"
			end
		else
			render :update do |page| 
				page.replace_html "success_message_in_checkout_list", :text=>'Wrong process'
			end
		end
	end
	

	def order_gift_process
		# here id is event_id not in order id
		if session[:checkout_id] && session[:checkout_id].length > 0
			event = Event.find_by_id(params[:id])
			invitee = Invitee.find_by_url_link(session[:micro_link])
			order = Order.create!(:user_id=>current_user.id, :event_id=>event.id, :amount=>session[:total], :status=> :false)
			redirect_to online_payment_payment_process_path(order.id, :event_id=>event.id)
		else
			render :template => "/payment_processes/status"
		end
	end
	
	def online_payment
		if session[:checkout_id] && session[:checkout_id].length > 0
			@invitee = Invitee.find_by_url_link(session[:micro_link])
			@user = current_user
			@event = @invitee.event
			@order = Order.find_by_id(params[:id])
		else
			render :template => "/payment_processes/status"
		end
	end
	
	def payment_sucess
		if params[:payment_sucess] == "Close"
			if session[:checkout_id] && session[:checkout_id].length > 0
				@user = current_user
				@invitee = Invitee.find_by_url_link(session[:micro_link])
				@event = @invitee.event
				@order = Order.find_by_id(params[:order_id])
				@wishlists = WishList.find(:all,:conditions=>["id in (?)",session[:checkout_id]])
				if @order
					@item_name = []
					session[:checkout_id].each do |wish_list_id|
						wish_list = WishList.find_by_id(wish_list_id)
						 if wish_list
							wish_list.update_attributes(:is_gifted=>true)
							@item_name << wish_list.inventory.url_unescape(wish_list.inventory.name)
						end
					end
					@item_name_string = @item_name.join(",")
					if params[:deliver_to_host]
						@order.update_attributes(:status=>true, :delivery_id=>@event.host.id, :delivery_mode=>"host")
					else
						@order.update_attributes(:status=>true, :delivery_id=>@user.id, :delivery_mode=>"invitee")
					end
					
					flash[:notice] = "Payment Added Successfully"
					redirect_to invitee_path(session[:micro_link])
					UserMailer.deliver_purchase_invitee_notification(@user,@event,@order,@item_name_string)
					UserMailer.deliver_purchase_host_notification(@event,@invitee,@wishlists)
				end
				session[:checkout_id] = nil
				session[:micro_link] = nil
			else
				render :template => "/payment_processes/status"
			end
		else
			payment_failure
		end
	end
	
	def payment_failure
		if session[:checkout_id] && session[:checkout_id].length > 0
			@user = current_user
			@invitee = Invitee.find_by_url_link(session[:micro_link])
			@event = @invitee.event
			@order = Order.find_by_id(params[:order_id])
			if @order
				@order.update_attributes(:status=>false)
				flash[:notice] = "There is some issues in Payment process"
			end
		else
			render :template => "/payment_processes/status"
		end
	end
	
	
	
	def destroy
		if params[:wish_list_id]
			session[:checkout_id].delete(params[:wish_list_id].to_i)
		end
		@invitee = Invitee.find_by_url_link(session[:micro_link])
		@wish_lists = WishList.find(:all, :conditions=>["id in (?) and is_reserved=? and is_gifted=?", session[:checkout_id],false,false])
			render :update do |page| 
				page.replace_html "invitationGalleryArea", :partial=>'my_gift_list'
				page.replace_html "success_message_in_checkout_list", :text=>"Deleted this gift from carts"
			end
	end
	
	
end
