class PublishEventsController < ApplicationController
		before_filter :login_required
		layout 'application', :except=>[:create_invite]
		
		
	def new
		@invitees = []
		@invitees_ids = []
		@event = Event.find_by_id(params[:event_id])
		@invitee_categories = InviteeCategory.all
		if @event && @event.host_id == current_user.id
		@all_invitees = @event.invitees
		@invitees = @event.invitees.find(:all).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 9 if @event
		@invitee = Invitee.new
		@event.invitees.collect{|inv| @invitees_ids << inv.id}
		@invitees_ids = @invitees_ids.join(",")
		respond_to do |format|
					format.html{}
					format.js{
						render :update do |page| 
							page.replace_html "update_my_contacts", :partial=>'update_my_contacts'
						end
					}
				end
		else
			render :text=>"Wrong input"
		end
	end
	
	def create
		@invitees = []
		@invitee_list = []
		@invitees_ids = []
		@invitee_categories = InviteeCategory.all
		@event = Event.find(params[:event_id])
		@invitee = Invitee.new(params[:invitee])
		if @invitee.valid? && params[:invitee_category] && params[:invitee_category].length > 0
			if params[:invitee_category] && params[:invitee_category].length > 0
				params[:invitee_category].each do |key,value|
					@invitee_list << key
				end
				 @invitee_list << "6"
				 @invitees_category_ids = @invitee_list.join(",")
			else
				@invitees_category_ids = ""
			end
			@invitee.invitee_category_id = @invitees_category_ids
			@invitee.host_id=current_user.id
			@event.invitees << @invitee
			@invitees = @event.invitees.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 9
			@invitee = Invitee.new
			@event.invitees.collect{|inv| @invitees_ids << inv.id}
			@invitees_ids = @invitees_ids.join(",")
			@all_invitees = @event.invitees
			render :update do |page|
				page.replace_html "update_my_contacts", :partial => "update_my_contacts"
				page.replace_html "LeftCon", :partial => "invitee_form_field"
				page.replace_html "success_message_in_contact_list", :text=>"<br/>Contact Added Successfully"
				page.visual_effect(:appear, 'success_message_in_contact_list',  :duration => 5.5)
				page.visual_effect(:fade, 'success_message_in_contact_list',  :duration => 10.5)
			end
		else
			@invitees = @event.invitees.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 9
			render :update do |page|
				page.replace_html "invitee_phone_error", :text=>"#{error_message_on :invitee, :phone}"
				page.replace_html "invitee_mobile_error", :text=>"#{error_message_on :invitee, :mobile}"
				page.replace_html "invitee_email_error", :text=>"#{error_message_on :invitee, :email}"
				page.replace_html "invitee_fname_error", :text=>"#{error_message_on :invitee, :fname}"
				page.replace_html "invitee_lname_error", :text=>"#{error_message_on :invitee, :lname}"
				if params[:invitee_category] && params[:invitee_category].length > 0
					page.replace_html "invitee_category_id_error", :text=>""
				else
					page.replace_html "invitee_category_id_error", :text=>"Please select the invitee category"
				end
				#page.visual_effect(:appear, 'error_message_in_contact_list',  :duration => 5.5)
				#page.visual_effect(:fade, 'error_message_in_contact_list',  :duration => 10.5)
			end
		end
		#@invitee = Invitee.new()
		
	end
	
	def edit
		@invitee = Invitee.find_by_id(params[:id])
		render :text=> @invitee.to_json
	end
	
	def update
		@invitees_ids = []
		@invitee_list = []
		@invitee = Invitee.find_by_id(params[:id])
		@event = @invitee.event
		@invitee_categories = InviteeCategory.all
		if @invitee && params[:invitee_category] && params[:invitee_category].length > 0 && @invitee.update_attributes(params[:invitee])
			if params[:invitee_category] && params[:invitee_category].length > 0
				params[:invitee_category].each do |key,value|
					@invitee_list << key
				end
				@invitee_list << "6"
				@invitees_category_ids = @invitee_list.join(",")
			else
				@invitees_category_ids = ""
			end
			@invitee.invitee_category_id = @invitees_category_ids
			@invitee.host_id=current_user.id
			@invitee.save!
			@invitees = @event.invitees.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 9
			@invitee = Invitee.new
			@event.invitees.collect{|inv| @invitees_ids << inv.id}
			@invitees_ids = @invitees_ids.join(",")
			@all_invitees = @event.invitees
			render :update do |page|
				page.replace_html "update_my_contacts", :partial => "update_my_contacts"
				page.replace_html "LeftCon", :partial => "invitee_form_field"
				page.replace_html "success_message_in_contact_list", :text=>"<br/>Contact Updated Successfully"
				page.visual_effect(:appear, 'success_message_in_contact_list',  :duration => 5.0)
				page.visual_effect(:fade, 'success_message_in_contact_list',  :duration => 6.0)
			end
		else
			@invitees = @event.invitees.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 9
			render :update do |page|
				page.replace_html "invitee_phone_error", :text=>"#{error_message_on :invitee, :phone}"
				page.replace_html "invitee_mobile_error", :text=>"#{error_message_on :invitee, :mobile}"
				page.replace_html "invitee_email_error", :text=>"#{error_message_on :invitee, :email}"
				page.replace_html "invitee_fname_error", :text=>"#{error_message_on :invitee, :fname}"
				page.replace_html "invitee_lname_error", :text=>"#{error_message_on :invitee, :lname}"
				if params[:invitee_category] && params[:invitee_category].length > 0
					page.replace_html "invitee_category_id_error", :text=>""
				else
					page.replace_html "invitee_category_id_error", :text=>"Please select the invitee category"
				end
			end
		end
		
	end
	
	def destroy
		@invitees_ids = []
		@invitee = Invitee.find_by_id(params[:id])
		@event = Event.find_by_id(params[:event_id])
		@invitee.destroy if @invitee
		@invitees = @event.invitees.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 9
		@invitee = Invitee.new
		@event.invitees.collect{|inv| @invitees_ids << inv.id}
		@invitee_categories = InviteeCategory.all
		@invitees_ids = @invitees_ids.join(",")
		@all_invitees = @event.invitees
		render :update do |page|
			page.replace_html "update_my_contacts", :partial => "update_my_contacts"
			page.replace_html "LeftCon", :partial => "invitee_form_field"
			page.replace_html "success_message_in_contact_list", :text=>"<br/>Contact Deleted successfully"
			page.visual_effect(:appear, 'success_message_in_contact_list',  :duration => 5.0)
			page.visual_effect(:fade, 'success_message_in_contact_list',  :duration => 6.0)
		end
	end
	
	def send_invitation
		if !params[:invite_id].nil? && !params[:invite_id].empty? && !params[:invite_id].blank? && params[:invite_id] != ""
			@invitees = Invitee.find_all_by_id(params[:invite_id].split(","))
			@invitees.each do |invitee|
				UserMailer.deliver_send_invitation_to_invitee(invitee.event.host, invitee)
			end
			render :update do |page|
				page.replace_html "success_message_in_contact_list", :text=>"<br/>Invitation Sent Successfully"
				page.visual_effect(:appear, 'success_message_in_contact_list',  :duration => 5.0)
				page.visual_effect(:fade, 'success_message_in_contact_list',  :duration => 6.0)
			end
		else
			render :update do |page|
				page.replace_html "error_message_in_contact_list", :text=>"<br/>Please check from the list"
				page.visual_effect(:appear, 'error_message_in_contact_list',  :duration => 5.0)
				page.visual_effect(:fade, 'error_message_in_contact_list',  :duration => 6.0)
			end
		end
	end
	
	def sorting_with_albhabet
		#here id is event id not in publish_event id
		if params[:id]
			@event = Event.find_by_id(params[:id])
			if params[:sort_value] == "All"
				@invitees = @event.invitees.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 9
				@all_invitees = @event.invitees if @event
			else
				@invitees = @event.invitees.find(:all, :conditions=>["fname LIKE ?","#{params[:sort_value]}%"]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 9
				@all_invitees = @event.invitees.find(:all, :conditions=>["fname LIKE ?","#{params[:sort_value]}%"])
			end
			respond_to do |format|
					format.html{}
					format.js{
						render :update do |page| 
							page.replace_html "update_my_contacts", :partial=>'update_my_contacts'
						end
					}
				end
		end
	end
	
	def invitation_page
		@invitees = Invitee.find(:all)
	end	
	
	def create_invite
		#here id is event id not in publish_event id
		if params[:id]
			@event = Event.find_by_id(params[:id])
			@invitees = @event.invitees
		end
	end
	
end
