# This controller handles the login/logout function of the site.  
class SessionsController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  layout 'application', :except=> 'index'

  # render new.rhtml
  def new
  
  end

def create
 
    logout_keeping_session!
    @login  = params[:user_name]
if !params[:user_name].blank? && !params[:password].blank? 
    user = User.authenticate(params[:user_name], params[:password])
   
  if user
      self.current_user = user
      if session[:micro_link]
        @invitee = Invitee.find_by_url_link(session[:micro_link])
        @invitee.update_attributes(:invite_id=>user.id) if(@invitee.email == user.email)
      end
      flash[:login_notice] = APP_MESSAGE["login_success"]
      if (session[:checkout_id] && session[:checkout_id].length > 0) && (@invitee.invite_id == user.id)
        redirect_to payment_processes_path(:event_id=>@invitee.event.id)
      else
        redirect_to user_dashboards_path(current_user)
      end
      new_cookie_flag = (params[:remember_me] == "1")
      handle_remember_cookie! new_cookie_flag
      
      
      
  else
      user = User.authenticatewithoutactivation(params[:user_name], params[:password])
      if user
        flash.now[:login_error] =APP_MESSAGE["login_fail"]
      else
         user = User.authenticateUsername(params[:user_name])
         if user
         flash.now[:login_password_error] = APP_MESSAGE["wrong_password_error"]
        else
          flash.now[:login_username_error] = APP_MESSAGE["wrong_username_error"]
         end
        self.note_failed_signin
      end
     @remember_me = params[:remember_me]
      render :action => 'new' 
  end
    
      
elsif (params[:user_name].blank? && params[:password].blank?)
      flash.now[:login_username_error] = APP_MESSAGE["username_blank_error"]
      flash.now[:login_password_error] = APP_MESSAGE["login_password_blank_error"]
       render :action => 'new'
elsif params[:user_name].blank?
    flash.now[:login_username_error] = APP_MESSAGE["username_blank_error"]
     render :action => 'new'
elsif params[:password].blank?
   flash.now[:login_password_error] = APP_MESSAGE["login_password_blank_error"]
   user = User.authenticateUsername(params[:user_name])
     if !user
       flash.now[:login_username_error] = "Incorrect username"  
      end
   
     render :action => 'new'
end   
end

 

   def destroy
    logout_killing_session!
    flash[:login_notice] = APP_MESSAGE["signout_success"]
    redirect_to '/login'
   end

protected
  # Track failed login attempts
  def note_failed_signin
    
    #flash.now[:login_error] = APP_MESSAGE["login_error"]
    logger.warn "Failed login for '#{params[:user_name]}' from #{request.remote_ip} at #{Time.now.utc}"
  end

  
end
