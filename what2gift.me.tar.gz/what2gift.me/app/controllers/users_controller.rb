class UsersController < ApplicationController
  # Be sure to include AuthenticationSystem in Application Controller instead
  layout 'application', :except=> 'index'
  # render new.rhtml
  def new
    if session[:micro_link]
      @invitee = Invitee.find_by_url_link(session[:micro_link])
      if @invitee
        params['user'] = {}
        params['user']['email'] = @invitee.email
        params['user']['phone'] = @invitee.phone
        params['user']['mobile_phone'] = @invitee.mobile
        params['user']['fname'] = @invitee.fname
        params['user']['lname'] = @invitee.lname
        @user = User.new(params[:user])
      end
    end
 end
 
  def create
   logout_keeping_session!
    if params[:login]
      login_page
    end
    if params[:register]
      signup_page
    end
  end
   
  def activate
    logout_keeping_session!
    user = User.find_by_activation_code(params[:activation_code]) unless params[:activation_code].blank?
    case
    when (!params[:activation_code].blank?) && user && !user.active?
      user.activate!
      self.current_user = user
      flash[:signup_notice] = APP_MESSAGE["signup_success"]
      if session[:micro_link]
        @invitee = Invitee.find_by_url_link(session[:micro_link])
        @invitee.update_attributes(:invite_id=>user.id) if(@invitee.email == user.email)
      end
      if (session[:checkout_id] && session[:checkout_id].length > 0) && (@invitee.invite_id == user.id)
        redirect_to payment_processes_path(:event_id=>@invitee.event)
      else
        redirect_to user_dashboards_path(current_user)
      end
    when params[:activation_code].blank?
      flash[:signup_notice] = APP_MESSAGE["activation_code_error"]
      redirect_back_or_default('/login')
    else 
      flash[:signup_notice]  = APP_MESSAGE["activation_failed_error"]
      redirect_back_or_default('/login')
    end
   
  end
  
 
    #gain email address
    def forgot_password
      return unless request.post?
      if !params[:user][:email].blank?
        if @user = User.find_by_email(params[:user][:email])
          @user.forgot_password
          @user.save
          redirect_back_or_default('/login')
          flash[:login_notice] = APP_MESSAGE["password_reset"]
        else
          flash[:password_error] = APP_MESSAGE["reset_email_error"]
        end
      else
        flash[:password_error] = APP_MESSAGE["reset_blank_email"]
      end
    end

    #reset password

    def reset_password
      @user = User.find_by_password_reset_code(params[:id])
      if !@user.nil?
        return unless request.post?
      if @user 
        if ((params[:user][:password] && params[:user][:password_confirmation]) && 
                                !params[:user][:password_confirmation].blank? && !params[:user][:password].blank?)
          #self.current_user = @user #for the next two lines to work
          @user.password_confirmation = params[:user][:password_confirmation]
          @user.password = params[:user][:password]
                    if @user.password == @user.password_confirmation
                      
                    @user.reset_password
                              if @user.save 
                              flash[:login_notice] = APP_MESSAGE["password_reset_success"]
                              redirect_to '/login'  
                                                   
                              else
                                flash.now[:password_error] = APP_MESSAGE["password_reset_fail"]
                                render :reset_password
                              end
                              
                    else
                    flash.now[:password_error] = APP_MESSAGE["password_mismatch_error"]  
                    render :reset_password 
                      
                    end
        elsif params[:user][:password].blank? && params[:user][:password_confirmation].blank?
        
           flash.now[:password_error] = "password should not be blank"
           flash.now[:password_confirmation_error] = "password confirmation should not be blank"
           render :reset_password
         elsif params[:user][:password].blank?
          
           flash.now[:password_error] = "password should not be blank"
           render :reset_password
         else params[:user][:password_confirmation].blank?
        
              flash.now[:password_confirmation_error] = "password confirmation should not be blank"
              render :reset_password
            end
            else
              flash[:login_notice] = "Not a valid link"
            redirect_to "/login"
          end
        else
          flash[:login_notice] = "Not a valid link"
          redirect_to "/login"
        end
        
    end


def forgot_user_name
      return unless request.post?
      if !params[:user][:email].blank?
      if @user = User.find_by_email(params[:user][:email])
        @user.forgot_user_name
        @user.save
        redirect_back_or_default('/login')
        flash[:login_notice] = APP_MESSAGE["username_reset"]
      else
        flash.now[:username_error] = APP_MESSAGE["reset_email_error"]
      end
      else
        flash.now[:username_error] = APP_MESSAGE["reset_blank_email"]
      end  
    end

    def reset_user_name
      @user = User.find_by_user_name_reset_code(params[:id])
      if !@user.nil?
      return unless request.post?
      if @user
    #  return if @user unless params[:user]
      if !((params[:user][:user_name] )).blank?
          # self.current_user = @user 
              @user.user_name = params[:user][:user_name]
                      if @user.valid?
                         @user.reset_user_name
                        @user.save!
                        flash[:login_notice] = APP_MESSAGE["username_reset_success"]
                        redirect_to '/login'        
                    else
                   flash.now[:username_error] = APP_MESSAGE["username_reset_fail"]
                    end
                    
              else
          flash.now[:username_error] = "Username cant be blank"
        end  
        else
          flash[:login_notice] = "Not a valid link"
          redirect_to "/login"
        end
        else
          flash[:login_notice] = "Not a valid link"
          redirect_to "/login"
        end
        
    end
  

 def login_page
    logout_keeping_session!
    @login = params[:user_name]
    if !params[:user_name].blank? && !params[:password].blank? 
    user = User.authenticate(params[:user_name], params[:password])
              if user
                          self.current_user = user
                          new_cookie_flag = (params[:remember_me] == "1")
                          handle_remember_cookie! new_cookie_flag
                          flash[:login_notice] = APP_MESSAGE["login_success"]
                          if session[:micro_link]
                            @invitee = Invitee.find_by_url_link(session[:micro_link])
                            @invitee.update_attributes(:invite_id=>user.id) if(@invitee.email == user.email)
                          end
                          if (session[:checkout_id] && session[:checkout_id].length > 0) && (@invitee.invite_id == user.id)
                            redirect_to payment_processes_path(:event_id=>@invitee.event)
                          else
                            redirect_to user_dashboards_path(current_user)
                          end
              else
                        user = User.authenticatewithoutactivation(params[:user_name], params[:password])
                          if user
                            flash[:login_error] = APP_MESSAGE["login_fail"]
                          else
                          user = User.authenticateUsername(params[:user_name])
                           if user
                           flash[:login_password_error] = APP_MESSAGE["wrong_password_error"]
                           else
                           flash[:login_username_error] = APP_MESSAGE["wrong_username_error"]
                           end
                           self.note_failed_signin
                          end
               
                @remember_me = params[:remember_me]
                #render :action => 'new'
                redirect_to new_session_path
              end   
          
   elsif (params[:user_name].blank? && params[:password].blank?)
     
            flash[:login_username_error] = APP_MESSAGE["username_blank_error"]
            flash[:login_password_error] = APP_MESSAGE["login_password_blank_error"]
          
            redirect_to new_session_path
   elsif params[:user_name].blank?
    
            flash[:login_username_error] = APP_MESSAGE["username_blank_error"]
            redirect_to new_session_path
  elsif params[:password].blank?
  
           flash[:login_password_error] = APP_MESSAGE["login_password_blank_error"]
           user = User.authenticateUsername(params[:user_name])
           if !user
               flash[:login_username_error] = "Incorrect username"  
           end
           
           redirect_to new_session_path
   end   
    
    
  end
  
  def signup_page
    @user = User.new(params[:user])
    success = @user && @user.save
    if success && @user.errors.empty?
            # Protects against session fixation attacks, causes request forgery
      # protection if visitor resubmits an earlier form using back
      # button. Uncomment if you understand the tradeoffs.
      # reset session
      #self.current_user = @user # !! now logged in
      if session[:micro_link]
        @invitee = Invitee.find_by_url_link(session[:micro_link])
        @invitee.update_attributes(:invite_id=>@user.id) if(@invitee.email == @user.email)
      end
      redirect_to '/login'
      flash[:error] = ''
      flash[:signup_notice] = APP_MESSAGE["signup_complete"]
    else
      flash[:signup_error] = nil
      flash[:signup_notice] = nil
      #flash[:error]  = "We couldn't set up that account, sorry.  Please try again, or contact an admin (link is above)."
      render :action => 'new'
    end
  end

protected
  # Track failed login attempts
  def note_failed_signin
   # flash.now[:login_error] = APP_MESSAGE["login_error"]
    logger.warn "Failed login for '#{params[:user_name]}' from #{request.remote_ip} at #{Time.now.utc}"
  end

end
  
  
  
  

