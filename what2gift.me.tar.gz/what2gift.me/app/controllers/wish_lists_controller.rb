class WishListsController < ApplicationController
	before_filter :login_required,:except=>[:wishlist_show,:wishlist_wlt,:show_inventory]
	layout "application", :except=> [:why_like_this_edit, :why_like_this_update,:edit_wishlist,:wishlist_show,:wishlist_wlt,:show_inventory]
	def index
		
		if params[:event_id]
			@invitee_categories = InviteeCategory.all
			@event = Event.find_by_id(params[:event_id])
			if @event && @event.host_id == current_user.id
				@inventories = Inventory.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
				@inventory = Inventory.first
				@wish_list = WishList.new()
				@all_wish_lists = @event.wish_lists
				@wish_lists = @event.wish_lists.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 8
				@categories = Category.find(:all, :order=>'name ASC')
				@brands = Brand.find(:all, :order=>'name ASC')
				@price_ranges = PriceRange.find :all
				respond_to do |format|
					format.html{}
					format.js{
						if params[:status] == "wishlist"
						render :update do |page| 
							page.replace_html "RightCon", :partial=>'wish_list_display'
						end
						else
							render :update do |page| 
								page.replace_html "giftResult", :partial=>'wish_list_form'
							end
						end
					}
				end
			else
				render :text => "Wrong input"
			end
		else
			render :text => "Wrong input"
		end
	end
	
	def new
		@wish_list= WishList.new
       	 
	end

	def create
		if params[:event_id]
			@event = Event.find_by_id(params[:event_id])
			if @event
				@inventories = Inventory.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
				@event.wish_lists << WishList.new(:inventory_id => params[:inventory_id], :invitee_category_id => 6)
				@inventory= Inventory.find_by_id(params[:inventory_id])
			@all_wish_lists = @event.wish_lists
 			@wish_lists = @event.wish_lists.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 8
				render :update do |page|
					page.replace_html "RightCon", :partial => "wish_list_display"		
				end
			else
				render :text => "Wrong input"
			end
		else
			render :text => "Wrong input"
		end
	end
	
	def edit_wishlist
			@wish_list = WishList.find_by_id(params[:id])
			@inventory = @wish_list.inventory
	end
	
	
	

  def destroy					
		@wish_list = WishList.find_by_id(params[:id])
		if @wish_list
			@wish_list.destroy
			@event = Event.find_by_id(params[:event_id])
		@all_wish_lists = @event.wish_lists
		@wish_lists = @event.wish_lists.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 8
			@inventories = Inventory.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
			render :update do |page|
				page.replace_html "RightCon", :partial=>'wish_list_display'
					render :partial => "wish_list_display", :collection => @wish_lists
				end
		else
			render :text => "Wrong input"
		end 
	end

	def why_like_this_edit
		@invitee_categories = InviteeCategory.all :order=>"id DESC"
		@wish_list = WishList.find_by_id(params[:id])
	end
	
def why_like_this_update
   @invitee_list = []
	@wish_list = WishList.find_by_id(params[:id])
	if params[:invitee] && params[:invitee].length > 0
		params[:invitee].each do |key,value|
			@invitee_list << key
		end
		@invitees = @invitee_list.join(",")
	else
		@invitees = ""
	end
	
	if @wish_list
	@wish_list.why_like_this = params[:wish_list][:why_like_this]
	@wish_list.invitee_category_id = @invitees
	@wish_list.save
		render :update do |page|
			page.replace_html "why_like_this_successmsg", :text=>"Updated Successfully"
		end
	end
end

def display_particular_product
	#here id is specified inventory id not wish_lists id
	@inventory = Inventory.find_by_id(params[:id])
	if @inventory
		@event = Event.find_by_id(params[:event_id])
		render :update do |page|
			page.replace_html "display_particular_product_information", :partial=>"display_particular_product_information"
		end
	else
		render :text=>"Wrong Input"	
	end
end

def list_inventories
	#here id is specified user id not wish_lists id
	if(params[:brand][:id] != "" && params[:price_range][:id] != "" && params[:category][:id] != "")
		@inventories = Inventory.find(:all, :conditions=>["brand_id=? and price_range_id=? and category_id=?", params[:brand][:id], params[:price_range][:id], params[:category][:id]]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
elsif(params[:brand][:id] != "" && params[:price_range][:id] != "" && params[:category][:id] == "")
	@inventories = Inventory.find(:all, :conditions=>["brand_id=? and price_range_id=?", params[:brand][:id], params[:price_range][:id]]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
elsif(params[:brand][:id] != "" && params[:price_range][:id] == "" && params[:category][:id] != "")
	@inventories = Inventory.find(:all, :conditions=>["brand_id=? and category_id=?", params[:brand][:id], params[:category][:id]]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
elsif(params[:brand][:id] == "" && params[:price_range][:id] != "" && params[:category][:id] != "")
	@inventories = Inventory.find(:all, :conditions=>["price_range_id=? and category_id=?", params[:price_range][:id], params[:category][:id]]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
elsif(params[:brand][:id] != "" && params[:price_range][:id] == "" && params[:category][:id] == "")
	@inventories = Inventory.find(:all, :conditions=>["brand_id=?", params[:brand][:id]]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
elsif(params[:brand][:id] == "" && params[:price_range][:id] != "" && params[:category][:id] == "")
	@inventories = Inventory.find(:all, :conditions=>["price_range_id=?", params[:price_range][:id]]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
elsif(params[:brand][:id] == "" && params[:price_range][:id] == "" && params[:category][:id] != "")
	@inventories = Inventory.find(:all, :conditions=>["category_id=?", params[:category][:id]]).paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
elsif(params[:brand][:id] == "" && params[:price_range][:id] == "" && params[:category][:id] == "")
	@inventories = Inventory.all.paginate :page => params[:page], :order => 'created_at DESC', :per_page => 12
end
@event = Event.find_by_id(params[:event_id])
@category = Category.find_by_id(params[:category][:id]) if(params[:category][:id] != "")
@brand = Brand.find_by_id(params[:brand][:id]) if(params[:brand][:id] != "")
@price_range = PriceRange.find_by_id(params[:price_range][:id]) if(params[:price_range][:id] != "")
@inventory = @inventories.first if @inventories.length > 0
	respond_to do |format|
					format.html{}
					format.js{
						render :update do |page| 
							page.replace_html "giftResult", :partial=>'wish_list_form'
							#page.replace_html "display_particular_product_information", :partial=>"display_particular_product_information"
						end
					}
				end
end


def wishlist_show
	@wish_list = WishList.find_by_id(params[:id])
	end

def wishlist_wlt
	@wish_list = WishList.find_by_id(params[:id])
end	

def show_inventory
	@inventory = Inventory.find(params[:id])
end	
	
end
