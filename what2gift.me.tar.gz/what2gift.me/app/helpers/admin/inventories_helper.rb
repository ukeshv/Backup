module Admin::InventoriesHelper
end
