module Admins::InventoriesHelper
end
