module Admins::VendorsHelper
end
