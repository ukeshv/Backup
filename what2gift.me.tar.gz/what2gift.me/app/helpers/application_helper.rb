# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
	
	def event_time
		["12.00 AM", "01.00 AM", "02.00 AM","03.00 AM","04.00 AM","05.00 AM","06.00 AM","07.00 AM","08.00 AM","09.00 AM","10.00 AM","11.00 AM","12.00 PM","01.00 PM","02.00 PM","03.00 PM","04.00 PM","05.00 PM","06.00 PM","07.00 PM","08.00 PM","09.00 PM","10.00 PM","11.00 PM"]
	end
	def user_title
	["Mr","Ms","Mrs"]	
end

 def convert_number_format(num)
s = num.to_s
if s.include? ?.
pre, post = s.split '.'
return "#{pre.reverse.gsub( /\d{3}(?=\d)/, '\&,' ).reverse}.#{post}"
else
return s.reverse.gsub( /\d{3}(?=\d)/, '\&,' ).reverse
end
end

	def getCheckSum(merchant_Id,amount,order_Id ,redirect_Url,workingKey)
  @str ="#{merchant_Id}|#{order_Id}|#{amount}|#{redirect_Url}|#{workingKey}"
  @adler = 1
  @adler = adler32(@adler,@str)
 	return @adler
end
  def verifychecksum(merchant_Id,order_Id,amount,auth_desc,checksum,workingKey)
    @str = "#{merchant_Id}|#{order_Id}|#{amount}|#{auth_desc}|#{workingKey}"
    @adler = 1
    @adler = adler32(@adler,@str)
    if(@adler == checksum)
      return "true" 
    else
      return "false" 
   end 
  end

 def adler32(adler , str)
  str=str.split(//)
	@base =  65521 
	 @s1 = adler & 0xffff 
    @s2 = (adler >> 16) & 0xffff
 for i in 0...str.length
   str[i].each_byte do|@c|
      @s1 = (@s1 + @c.to_i) % @base 
      @s2 = (@s2 + @s1) % @base 
      end
    end
	return  leftshift(@s2 , 16)  + @s1
 end

  def leftshift(str , num)
 
   @str =  str.to_s(2)
   for i in 1...(64 - @str.length)
   if  i  < 64-@str.length
           @str="0"+@str.to_s
    end
    end
	    for i in 0...num
           @str=@str.to_s+"0"
	          @str=@str.slice(1,@str.length-1)
      end
	 return cdec(@str) 


 end

def cdec(num)

 num=num.to_s.split(//)
  	@dec=0
for i in 0... num.length
  @temp=num[i]
      @dec=@dec+@temp.to_i*(2**( num.length - i - 1))
     end

	 return @dec
 end
 
end

