module Browse::FaqsHelper
end
