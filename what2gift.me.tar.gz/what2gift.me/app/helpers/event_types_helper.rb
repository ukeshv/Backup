module EventTypesHelper
end
