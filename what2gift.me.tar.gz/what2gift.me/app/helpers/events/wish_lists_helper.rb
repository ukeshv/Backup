module Events::WishListsHelper
end
