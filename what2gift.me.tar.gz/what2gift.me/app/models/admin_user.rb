class Admin < ActiveRecord::Base
	
	def self.authenticate(user_name, password)
    return nil if user_name.blank? || password.blank?
    #u = find_by_user_name(user_name.downcase) # need to get the salt
    u = find :first, :conditions => ['user_name = ? and activated_at IS NOT NULL', user_name.downcase] # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end
	
	
end
