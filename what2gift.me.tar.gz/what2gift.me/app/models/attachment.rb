class Attachment < ActiveRecord::Base
		has_attachment :content_type => :image,:storage => :file_system, :path_prefix => 'public/attachments',:thumbnails => {:profile =>[80,80], :big_image=>[230,230], :invite =>[66,66], :event =>[60,60]},:max_size => 4.megabytes
		belongs_to :attachable, :polymorphic=>true
		validates_as_attachment
end
