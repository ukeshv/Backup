class Brand < ActiveRecord::Base
		has_many :inventory
		validates_presence_of     :name, :message=>"Please enter the brand name"
		validates_uniqueness_of   :name, :message=>"Brand name must be unique"
end
