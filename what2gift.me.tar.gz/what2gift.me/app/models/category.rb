class Category < ActiveRecord::Base
	has_one :inventory
	
	validates_presence_of     :name, :message=>"Please enter the category name"
  validates_uniqueness_of   :name, :message=>"Category name must be unique"
end
