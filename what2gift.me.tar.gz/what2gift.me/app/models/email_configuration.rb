class EmailConfiguration < ActiveRecord::Base
	validates_presence_of     :admin_email , :message=>"Please enter the admin email"
	validates_presence_of     :support_email , :message=>"Please enter the support email"
end
