class Event < ActiveRecord::Base
	
	belongs_to :host,:class_name=>"User",:foreign_key=>"host_id"
	belongs_to :event_type
	has_many :invitees
	has_many :wish_lists
	has_many :attachments, :as => :attachable
	belongs_to :attachable, :polymorphic=>true
	
	
	def invitations
		self.attachments.find(:all, :conditions=>["is_invitation=?",true]) if self.attachments && self.attachments.length > 0
	end
	
	def images
		self.attachments.find(:all, :conditions=>["is_invitation=?",false]) if self.attachments && self.attachments.length > 0
	end
	
end
