class EventType < ActiveRecord::Base
	has_many :events
	validates_presence_of     :name, :message=>"Please enter the event type name"
  validates_uniqueness_of   :name, :message=>"EventType name must be unique"
end
