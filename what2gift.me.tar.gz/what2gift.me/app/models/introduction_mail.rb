class IntroductionMail < ActiveRecord::Base
end
