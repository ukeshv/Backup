class Inventory < ActiveRecord::Base
	#validates_presence_of     :name, :message=>"Please enter the title"
  #validates_uniqueness_of   :name, :message=>"Title must be unique"
  belongs_to :category
  belongs_to :brand
  belongs_to :vendor
  belongs_to :price_range
	has_many :attachments, :as => :attachable
	has_many :wish_lists
	belongs_to :attachable, :polymorphic=>true
	before_create :esacpe_the_string
	before_update :esacpe_the_string
	
def esacpe_the_string
	self.name = self.url_escape(self.name)
	self.description = self.url_escape(self.description)
	self.short_description = self.url_escape(self.short_description)
end
	
def url_escape(string)
	string.gsub(/([^ a-zA-Z0-9_.-]+)/n) do
	'%' + $1.unpack('H2' * $1.size).join('%').upcase
	end.tr(' ', '+')
end

def url_unescape(string)
	string.tr('+', ' ').gsub(/((?:%[0-9a-fA-F]{2})+)/n) do
	[$1.delete('%')].pack('H*')
	end
end
	
end
