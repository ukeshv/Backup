require 'digest/sha1'

class Invitee < ActiveRecord::Base
	belongs_to :event
	
	#Associations
	belongs_to :user,   :foreign_key => "host_id",   :class_name => "User" 
	belongs_to :user,   :foreign_key => "invite_id",   :class_name => "User" 
	
	validates_presence_of     :email, :message =>  APP_MESSAGE["email_blank_error"] 
	validates_presence_of     :phone, :message =>  APP_MESSAGE["phone_blank_error"], :if => :phone_required?  
	validates_presence_of     :mobile, :message =>  APP_MESSAGE["mobile_blank_error"], :if => :mobile_required?
	validates_format_of       :email,    :with => Authentication.email_regex, :message => APP_MESSAGE["email_valid_error"]
	validates_presence_of     :fname, :message => "First name can't be blank"
	#~ validates_presence_of     :phone, :if => :phone_required?
	#~ validates_presence_of     :mobile, :if => :mobile_required?
	validates_format_of :phone, :message => APP_MESSAGE["phone_error"], :with => /^[\(\)0-9\- \+\.]{10,20}$/, :allow_blank=>true
	validates_length_of :phone, :within => 8..15, :on=>:create,:message => APP_MESSAGE["phone_long_error"],  :if => :phone_required?
  validates_format_of :mobile, :message => APP_MESSAGE["mobile_error"], :with => /^[\(\)0-9\- \+\.]{10,20}$/, :allow_blank=>true
	validates_length_of :mobile, :within => 8..15, :on=>:create,:message => APP_MESSAGE["mobile_long_error"],  :if => :mobile_required?
	validates_format_of :fname, :with => StandardRegexp.alpha, :message => APP_MESSAGE["firstname_error"], :allow_blank=>true
  validates_format_of :lname, :with => StandardRegexp.alpha, :message =>  APP_MESSAGE["lastname_error"], :allow_blank=>true
	before_create :create_microlink
	
	def create_microlink
		self.url_link = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join + self.email + self.fname )
	end
	
	def phone_required?
		if mobile.nil? || mobile.blank? || mobile == ""
			return true
		else
			return false
		end
	end
	def mobile_required?
		if phone.nil? || phone.blank? || phone == ""
			return true
		else
			return false
		end
	end

	def full_name
    if self.fname && self.lname
      "#{self.fname.capitalize} #{self.lname.capitalize}"
    else
      "#{self.fname.capitalize}"
    end
	end
	
end
