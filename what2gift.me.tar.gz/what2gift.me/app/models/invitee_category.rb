class InviteeCategory < ActiveRecord::Base
	has_many :wish_lists
end
