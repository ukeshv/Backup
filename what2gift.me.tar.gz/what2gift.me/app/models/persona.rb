class Persona < ActiveRecord::Base
	validates_presence_of     :name, :message=>"Please enter the persona name"
  validates_uniqueness_of   :name, :message=>"Persona name must be unique"
end
