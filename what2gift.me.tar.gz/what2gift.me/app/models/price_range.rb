class PriceRange < ActiveRecord::Base
	has_one :inventory
end
