require 'digest/sha1'

class User < ActiveRecord::Base
  include Authentication
  include Authentication::ByPassword
  include Authentication::ByCookieToken

  validates_presence_of     :user_name, :message => APP_MESSAGE["username_blank_error"]
  validates_length_of       :user_name,    :within => 6..30, :message => APP_MESSAGE["username_size_error"]
  validates_uniqueness_of   :user_name, :message => APP_MESSAGE["username_unique_error"]
  validates_format_of       :user_name,    :with => Authentication.login_regex, :message => Authentication.bad_login_message

  #~ validates_format_of       :name,     :with => Authentication.name_regex,  :message => Authentication.bad_name_message, :allow_nil => true
  #~ validates_length_of       :name,     :maximum => 100

  validates_presence_of     :title,  :message => APP_MESSAGE["title_blank_error"]
  validates_presence_of     :fname,  :message => APP_MESSAGE["fname_blank_error"]
  validates_presence_of     :lname,  :message => APP_MESSAGE["lname_blank_error"]
  validates_presence_of     :address,  :message => APP_MESSAGE["address_blank_error"]
  validates_presence_of     :phone,  :message => APP_MESSAGE["phone_blank_error"], :if => :phone_required?
  validates_presence_of     :mobile_phone,  :message => APP_MESSAGE["mobile_blank_error"], :if => :mobile_required?
  
  validates_presence_of     :email,  :message => APP_MESSAGE["email_blank_error"]
  #validates_length_of       :email,    :within => 6..100, :message => "Email should be atleast 6 and maximum 100" #r@a.wk
  validates_uniqueness_of   :email,  :message => APP_MESSAGE["email_unique_error"]
  validates_format_of       :email,    :with =>StandardRegexp.email, :message => APP_MESSAGE["email_valid_error"]
  validates_format_of :phone, :message => APP_MESSAGE["phone_error"], :with => /^[\(\)0-9\- \+\.]{10,20}$/, :allow_blank=>true
  validates_length_of :phone, :within => 8..15,:message => APP_MESSAGE["phone_long_error"], :if => :phone_required?
  validates_format_of :mobile_phone, :message => APP_MESSAGE["mobile_error"], :with => /^[\(\)0-9\- \+\.]{10,20}$/, :allow_blank=>true
  validates_length_of :mobile_phone, :within => 8..15,:message => APP_MESSAGE["mobile_long_error"], :if => :mobile_required?
  validates_format_of :fname, :with => StandardRegexp.alpha, :message =>APP_MESSAGE["firstname_error"], :allow_blank=>true
  validates_format_of :lname, :with => StandardRegexp.alpha, :message => APP_MESSAGE["lastname_error"], :allow_blank=>true
  before_create :make_activation_code 
  # HACK HACK HACK -- how to do attr_accessible from here?
  # prevents a user from submitting a crafted form that bypasses activation
  # anything else you want your user to change should be added here.
  attr_accessible :user_name, :email, :name, :password, :password_confirmation,:website,:phone,:mobile_phone, :fname, :lname,:title,:suffix,:address,:about_me, :city, :state, :country, :pincode
    has_one :attachment, :as => :attachable
		belongs_to :attachable, :polymorphic=>true
    has_many :orders
    has_many :events, :class_name => "Event",:foreign_key => "host_id"
    
    has_many :orders, :class_name => "Order",:foreign_key => "delivery_id"
    
    has_many :invitees, :class_name => "Invitee", :foreign_key => "host_id"
    has_many :invitees, :class_name => "Invitee", :foreign_key => "invite_id"
    has_one :wish_list, :class_name => "WishList", :foreign_key => "invitee_id"
# Activates the user in the database.
  def activate!
   
    @activated = true
    self.activated_at = Time.now.utc
    self.activation_code = nil
    save(false)
  end
def full_name
    if self.fname && self.lname
      "#{self.fname.capitalize} #{self.lname.capitalize}"
    else
      "#{self.fname.capitalize}"
    end
	end
  
  	def phone_required?
		if mobile_phone.nil? || mobile_phone.blank? || mobile_phone == ""
			return true
		else
			return false
		end
	end
	def mobile_required?
		if phone.nil? || phone.blank? || phone == ""
			return true
		else
			return false
		end
	end
  
  # Returns true if the user has just been activated.
  def recently_activated?
    @activated
  end
def recently_forgot_password?
@forgotten_password 
end

  def recently_reset_password?
    @reset_password
  end
  def recently_forgot_user_name?
@forgotten_user_name
end

  def recently_reset_user_name?
    @reset_user_name
  end

  def active?
    # the existence of an activation code means they have not activated yet
    activation_code.nil?
  end

   def forgot_password
      @forgotten_password = true
      self.make_password_reset_code
    end

    def reset_password
      # First update the password_reset_code before setting the 
      # reset_password flag to avoid duplicate email notifications.
      self.update_attribute(:password_reset_code, nil)
      @reset_password = true
    end  
    
        
    def forgot_user_name
      @forgotten_user_name = true
      self.make_user_name_reset_code
    end

    def reset_user_name
      # First update the password_reset_code before setting the 
      # reset_password flag to avoid duplicate email notifications.
      self.update_attribute(:user_name_reset_code, nil)
      @reset_user_name = true
    end  
  # Authenticates a user by their login name and unencrypted password.  Returns the user or nil.
  #
  # uff.  this is really an authorization, not authentication routine.  
  # We really need a Dispatch Chain here or something.
  # This will also let us return a human error message.
  #
  def self.authenticate(user_name, password)
    return nil if user_name.blank? || password.blank?
    #u = find_by_user_name(user_name.downcase) # need to get the salt
    u = find :first, :conditions => ['user_name = ? and activated_at IS NOT NULL', user_name] # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end
  def self.authenticateUsername(user_name)
      u = find :first, :conditions => ['user_name = ? and activated_at IS NOT NULL', user_name]
      u ? u : nil
  end
  def self.authenticateEmail(email, password)
    return nil if email.blank? || password.blank?
    #u = find_by_user_name(user_name.downcase) # need to get the salt
    u = find :first, :conditions => ['email = ?', email] # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end
  
  def self.authenticatewithoutactivation(user_name, password)
    return nil if user_name.blank? || password.blank?
    #u = find_by_user_name(user_name.downcase) # need to get the salt
    u = find :first, :conditions => ['user_name = ?', user_name] # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end
  
  def login=(value)
    write_attribute :user_name, (value ? value.downcase : nil)
  end

  def email=(value)
    write_attribute :email, (value ? value.downcase : nil)
  end
  
  ADS_TITLE = [
    ["-select-",""],
    [ 'Mr', '1'],
    [ 'Ms', '2'], 
    [ 'Mrs', '3']
    ].freeze

  protected
     def make_activation_code
        self.activation_code = self.class.make_token
       
    end
 def make_password_reset_code
      self.password_reset_code = Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join )
    end
def make_user_name_reset_code
   self.user_name_reset_code = self.class.make_token
 end
 
 
 
end
