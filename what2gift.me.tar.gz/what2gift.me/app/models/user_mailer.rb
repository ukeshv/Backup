class UserMailer < ActionMailer::Base
  layout 'email_template'
  
  def signup_notification(user,status)
    @email_configuration =  EmailConfiguration.first
    if status
      @recipients  = "#{@email_configuration.admin_email}"
      @from        = "admin@what2gift.me"
      @subject     = "[what2gift.me]"
      @sent_on     = Time.now
      @body[:user] = user
    else
      setup_email(user)
    end
    @subject    += 'Please activate your new account'
    @body[:url]  = "http://#{$HOST}/activate/#{user.activation_code}"
    @content_type = "text/html"
  end
  
  def activation(user,status)
    @email_configuration =  EmailConfiguration.first
    if status
      @recipients  = "#{@email_configuration.admin_email}"
      @from        = "admin@what2gift.me"
      @subject     = "[what2gift.me]"
      @sent_on     = Time.now
      @body[:user] = user
    else
      setup_email(user)
    end
    @subject    += 'Your account has been activated!'
    @body[:url]  = "http://#{$HOST}/"
    @content_type = "text/html"
  end
  
  def forgot_password(user)
    setup_email(user)
    @subject    += 'You have requested to change your password'
    @body[:url]  = "http://#{$HOST}/reset_password/#{user.password_reset_code}" 
    @content_type = "text/html"
  end

  def reset_password(user)
    setup_email(user)
    @subject    += 'Your password has been reset.'
    @content_type = "text/html"
  end
  def forgot_user_name(user)
    setup_email(user)
    @subject    += 'You have requested to change your username'
    @body[:url]  = "http://#{$HOST}/reset_user_name/#{user.user_name_reset_code}" 
    @content_type = "text/html"
  end

  def reset_user_name(user)
    setup_email(user)
    @subject    += 'Your username has been reset.'
    @content_type = "text/html"
  end
      
  def send_invitation_to_invitee(host, invitee)
    setup_email(host,invitee)
    @subject    += "You got a invitation from #{host.fname}"
    @body[:url]  = "http://#{$HOST}/invitees/#{invitee.url_link}"
    @body[:invitee] = invitee
    @body[:host] = host
    @content_type = "text/html"
  end
  
  def reserved_item_notification(invitee,inventory_item_name,inventory_item_id)
    @recipients  = "#{invitee.email}"
    @from  = "admin@what2gift.me"
    @subject  = "Reserved Item"
    @sent_on     = Time.now
    @body[:invitee] = invitee
    @body[:inventory_item_name] = inventory_item_name
    @body[:inventory_item_id] = inventory_item_id
    @content_type = "text/html"
  end  
  
  def purchase_invitee_notification(user,event,order,item_string)
    @recipients  = "#{user.email}"
    @from  = "admin@what2gift.me"
    @subject  = "Purchase Invitee"
    @sent_on     = Time.now
    @body[:user] = user
    @body[:event] = event
    @body[:order] = order
    @body[:item_string] = item_string
    @content_type = "text/html"
  end  
  
  def purchase_host_notification(event,invitee,wishlists)
    @recipients  = "#{event.host.email}"
    @from  = "admin@what2gift.me"
    @subject  = "Purchase Host"
    @sent_on     = Time.now
    @body[:event] = event
    @body[:invitee] = invitee
    @body[:wishlists] = wishlists
    @content_type = "text/html"
  end  
  
  def reminder_reserved_item(wishlist)
    @recipients  = "#{wishlist.event.host.email}"
    @from  = "admin@what2gift.me"
    @subject  = "Reserved Item"
    @sent_on     = Time.now
    @body[:wishlist] = wishlist
    @content_type = "text/html"
  end  
  
  def introduction_email_notification(introduction_email)
    @recipients  = "#{introduction_email.recipient_email}"
    @from  = "admin@what2gift.me"
    @subject  = "Introduction email - What2giftme"
    @sent_on     = Time.now
    @body[:fname] = introduction_email.fname
    @body[:lname] = introduction_email.lname
    @body[:sname] = introduction_email.sname
    @body[:url]  = "http://#{$HOST}/"
    @content_type = "text/html"
  end 
      
  protected
    def setup_email(user, from=nil)
      if from
        @recipients  = "#{from.email}"
        @from        = "#{user.email}"
      else
        @recipients  = "#{user.email}"
        @from        = "admin@what2gift.me"
      end
      @subject     = "[what2gift.me]"
      @sent_on     = Time.now
      @body[:user] = user
    end
end


 
      
      
            
      
  