class UserObserver < ActiveRecord::Observer
  def after_create(user)
    UserMailer.deliver_signup_notification(user,false)
    UserMailer.deliver_signup_notification(user,true)
  end
def after_save(user)
       if user.recently_activated?
        UserMailer.deliver_activation(user,false)
        UserMailer.deliver_activation(user,true)
      end
      UserMailer.deliver_forgot_password(user) if user.recently_forgot_password?
      UserMailer.deliver_reset_password(user) if user.recently_reset_password?
      UserMailer.deliver_forgot_user_name(user) if user.recently_forgot_user_name?
      UserMailer.deliver_reset_user_name(user) if user.recently_reset_user_name?
      
    end  
    
def recently_forgot_password?
      @forgotten_password
end
    
    def recently_reset_password?
      @reset_password
    end
    def recently_forgot_user_name?
      @forgotten_user_name
    end
    
    def recently_reset_user_name?
      @reset_user_name
    end
    def recently_activated?
      @recent_active
    end
    

end
