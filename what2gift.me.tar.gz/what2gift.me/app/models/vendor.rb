class Vendor < ActiveRecord::Base
	has_many :inventories
end
