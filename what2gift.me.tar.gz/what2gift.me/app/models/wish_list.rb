class WishList < ActiveRecord::Base
	belongs_to :event
	belongs_to :inventory
	belongs_to :invitee_category
	belongs_to :user, :foreign_key => "invitee_id",   :class_name => "User" 
	
	def self.reserved_item_reminder
		@wishlists = WishList.find(:all,:conditions=>["is_reserved = true and need_sent_mail = true and reserved_at <= ?",(Time.now - 60*(60*12))])
		for @wishlist in @wishlists
			UserMailer.deliver_reminder_reserved_item(@wishlist)
			@wishlist.update_attribute(:need_sent_mail,false)
		end	
	end	
	
end
