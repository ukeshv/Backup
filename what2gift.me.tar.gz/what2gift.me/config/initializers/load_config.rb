APP_CONFIG = YAML.load_file("#{RAILS_ROOT}/config/settings.yml")
APP_MESSAGE = YAML.load_file("#{RAILS_ROOT}/config/message_notification.yml")

