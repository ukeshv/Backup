# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_what2giftme_session',
  :secret      => '64dce741e4f951c0888c71d30b010dfbc851904aad21c31d3d44e3286bfd67c64b9d9b0569065e164adcbc25349f1871f3d810043f1e66a471c58ec172ba207e'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
