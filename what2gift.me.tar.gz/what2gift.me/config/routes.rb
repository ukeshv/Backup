ActionController::Routing::Routes.draw do |map|

   
  #~ map.namespace(:admin) do |admin|
  #~ admin.logout '/logout', :controller => 'admin_sessions', :action => 'destroy'
  #~ admin.login '/login', :controller => 'admin_sessions', :action => 'new'
  #~ admin.register '/register', :controller => 'admins', :action => 'create'
  #~ admin.signup '/signup', :controller => 'admins', :action => 'new'
#~ end
  map.forgot_password '/forgot_password', :controller => 'users', :action => 'forgot_password'
  map.reset_password '/reset_password/:id', :controller => 'users', :action => 'reset_password'  
  map.forgot_user_name '/forgot_user_name', :controller => 'users', :action => 'forgot_user_name'
  map.reset_user_name '/reset_user_name/:id', :controller => 'users',:action => 'reset_user_name'  
  #map.resources :admins

  #map.resource :admin_session

  map.logout '/logout', :controller => 'sessions', :action => 'destroy'
  map.login '/login', :controller => 'sessions', :action => 'new'
  map.register '/register', :controller => 'users', :action => 'create'
  map.signup '/signup', :controller => 'users', :action => 'new'
  map.activate '/activate/:activation_code', :controller => 'users', :action => 'activate', :activation_code => nil
  map.login '', :controller => 'users', :action => 'index'
  map.resources :users

  map.resource :session
  
  
  map.resources :users do |user|
    user.resource :account_settings do |account_setting|
      account_setting.resource :profile, :controller=>'/account_settings/profiles',:member=>{:edit_media=>:get,:upload_media=>:post}  
      account_setting.resource :password, :controller=>'/account_settings/passwords' 
    end
    user.resources :dashboards
    user.resources :events do |event|
      
    end
  end
  
  map.resources :events do |event|
    event.resource :checkout_lists, :controller=>'/events/checkout_lists'
  end
  

  
  map.resources :faqs, :controller=>'/browse/faqs'
  map.resources :aboutus, :controller=>'browse/aboutus'
  map.resources :rernsofuses, :controller=>'/browse/rernsofuses'
  map.resources :helps, :controller=>'/browse/helps'
  map.resources :whydos, :controller=>'/browse/whydos'
  map.resources :disclaimers, :controller=>'/browse/disclaimers'
  map.resources :contacts, :controller=>'/browse/contacts'
  map.resources :termsofuses, :controller=>'/browse/termsofuses'
  
  # Added admin routes
  map.admin '/admin', :controller => 'admin_sessions', :action => 'new'
  map.admin_create '/admin/create', :controller => 'admin_sessions', :action => 'create'
  map.admin_logout '/admin/logout', :controller => 'admin_sessions', :action => 'destroy'
  map.admin_login '/admin/login', :controller => 'admin_sessions', :action => 'new'
  
  #Admin admin_users routes
  map.admin_admin_user '/admin/admin_user', :controller=> 'admins/admin_users', :action => 'index'
  map.admin_admin_user_new '/admin/admin_user/new', :controller=> 'admins/admin_users', :action => 'new'
  map.admin_admin_user_create '/admin/admin_user/create', :controller=> 'admins/admin_users', :action => 'create'
  map.admin_admin_user_edit '/admin/admin_user/edit/:id', :controller=> 'admins/admin_users', :action => 'edit'
  map.admin_admin_user_update '/admin/admin_user/update/:id', :controller=> 'admins/admin_users', :action => 'update'
  map.admin_admin_user_show '/admin/admin_user/show/:id', :controller=> 'admins/admin_users', :action => 'show'
  map.admin_admin_user_destroy '/admin/admin_user/destroy/:id', :controller=> 'admins/admin_users', :action => 'destroy'
  
  #Admin users routes
  map.admin_user '/admin/user', :controller=> 'admins/users', :action => 'index'
  map.admin_user_new '/admin/user/new', :controller=> 'admins/users', :action => 'new'
  map.admin_user_create '/admin/user/create', :controller=> 'admins/users', :action => 'create'
  map.admin_user_edit '/admin/user/edit/:id', :controller=> 'admins/users', :action => 'edit'
  map.admin_user_update '/admin/user/update/:id', :controller=> 'admins/users', :action => 'update'
  map.admin_user_show '/admin/user/show/:id', :controller=> 'admins/users', :action => 'show'
  map.admin_user_destroy '/admin/user/destroy/:id', :controller=> 'admins/users', :action => 'destroy'

  
  #Admin inventories routes
  map.admin_inventory '/admin/inventory', :controller=> 'admins/inventories', :action => 'index'
  map.admin_inventory_new '/admin/inventory/new', :controller=> 'admins/inventories', :action => 'new'
  map.admin_inventory_create '/admin/inventory/create', :controller=> 'admins/inventories', :action => 'create'
  map.admin_inventory_edit '/admin/inventory/edit/:id', :controller=> 'admins/inventories', :action => 'edit'
  map.admin_inventory_update '/admin/inventory/update/:id', :controller=> 'admins/inventories', :action => 'update'
  map.admin_inventory_show '/admin/inventory/show/:id', :controller=> 'admins/inventories', :action => 'show'
  map.admin_inventory_destroy '/admin/inventory/destroy/:id', :controller=> 'admins/inventories', :action => 'destroy'
  
  #Admin categories routes
  map.admin_category '/admin/category', :controller=> 'admins/categories', :action => 'index'
  map.admin_category_new '/admin/category/new', :controller=> 'admins/categories', :action => 'new'
  map.admin_category_create '/admin/category/create', :controller=> 'admins/categories', :action => 'create'
  map.admin_category_edit '/admin/category/edit/:id', :controller=> 'admins/categories', :action => 'edit'
  map.admin_category_update '/admin/category/update/:id', :controller=> 'admins/categories', :action => 'update'
  map.admin_category_show '/admin/category/show/:id', :controller=> 'admins/categories', :action => 'show'
  map.admin_category_destroy '/admin/category/destroy/:id', :controller=> 'admins/categories', :action => 'destroy'
  
  
  map.admin_brand '/admin/brand', :controller=> 'admins/brands', :action => 'index'
  map.admin_brand_new '/admin/brand/new', :controller=> 'admins/brands', :action => 'new'
  map.admin_brand_create '/admin/brand/create', :controller=> 'admins/brands', :action => 'create'
  map.admin_brand_edit'/admin/brand/edit/:id', :controller=> 'admins/brands', :action => 'edit'
  map.admin_brand_update '/admin/brand/update/:id', :controller=> 'admins/brands', :action => 'update'
  map.admin_brand_show '/admin/brand/show/:id', :controller=> 'admins/brands', :action => 'show'
  map.admin_brand_destroy '/admin/brand/destroy', :controller=> 'admins/brands', :action => 'destroy'

 
  
  map.admin_persona '/admin/persona', :controller=> 'admins/personas', :action => 'index'
  map.admin_persona_new '/admin/persona/new', :controller=> 'admins/personas', :action => 'new'
  map.admin_persona_create '/admin/persona/create', :controller=> 'admins/personas', :action => 'create'
  map.admin_persona_edit'/admin/persona/edit/:id', :controller=> 'admins/personas', :action => 'edit'
  map.admin_persona_update '/admin/persona/update/:id', :controller=> 'admins/personas', :action => 'update'
  map.admin_persona_show '/admin/persona/show/:id', :controller=> 'admins/personas', :action => 'show'
  map.admin_persona_destroy '/admin/persona/destroy', :controller=> 'admins/personas', :action => 'destroy'
  
  
  map.admin_invitee_category '/admin/invitee_category', :controller=> 'admins/invitee_categories', :action => 'index'
  map.admin_invitee_category_new '/admin/invitee_category/new', :controller=> 'admins/invitee_categories', :action => 'new'
  map.admin_invitee_category_create '/admin/invitee_category/create', :controller=> 'admins/invitee_categories', :action => 'create'
  map.admin_invitee_category_edit'/admin/invitee_category/edit/:id', :controller=> 'admins/invitee_categories', :action => 'edit'
  map.admin_invitee_category_update '/admin/invitee_category/update/:id', :controller=> 'admins/invitee_categories', :action => 'update'
  map.admin_invitee_category_show '/admin/invitee_category/show/:id', :controller=> 'admins/invitee_categories', :action => 'show'
  map.admin_invitee_category_destroy '/admin/invitee_category/destroy', :controller=> 'admins/invitee_categories', :action => 'destroy'
  
  
  map.admin_event_type '/admin/event_type', :controller=> 'admins/event_types', :action => 'index'
  map.admin_event_type_new '/admin/event_type/new', :controller=> 'admins/event_types', :action => 'new'
  map.admin_event_type_create '/admin/event_type/create', :controller=> 'admins/event_types', :action => 'create'
  map.admin_event_type_edit'/admin/event_type/edit/:id', :controller=> 'admins/event_types', :action => 'edit'
  map.admin_event_type_update '/admin/event_type/update/:id', :controller=> 'admins/event_types', :action => 'update'
  map.admin_event_type_show '/admin/event_type/show/:id', :controller=> 'admins/event_types', :action => 'show'
  map.admin_event_type_destroy '/admin/event_type/destroy', :controller=> 'admins/event_types', :action => 'destroy'
  
  map.admin_order '/admin/order', :controller=> 'admins/orders', :action => 'index'
  map.admin_reserved_order '/admin/reserved_order', :controller=> 'admins/reserved_orders', :action => 'index'
  
  #Guest invitees page
  map.list_wishlist '/invitees/list_wish_lists', :controller => 'invitees', :action => 'list_wish_lists'
  map.checkout_lists 'checkout_lists', :controller => 'invitees', :action => 'checkout_lists'
  map.invitee '/invitees/:id', :controller => 'invitees', :action => 'index'
  map.wishlist_show '/wishlist_show/:id', :controller =>'wish_lists',:action=>'wishlist_show'
  map.wishlist_wlt '/wishlist_wlt/:id', :controller =>'wish_lists',:action=>'wishlist_wlt'
  map.show_event_wishlist 'show_event_wishlist/:id', :controller => 'dashboards', :action => 'show_event_wishlist'
  map.show_inventory 'show_inventory/:id', :controller => 'wish_lists', :action => 'show_inventory'
  
  #Vendors page
  map.admin_vendor '/admin/vendor', :controller=> 'admins/vendors', :action => 'index'
  map.admin_vendor_new '/admin/vendor/new', :controller=> 'admins/vendors', :action => 'new'
  map.admin_vendor_create '/admin/vendor/create', :controller=> 'admins/vendors', :action => 'create'
  map.admin_vendor_edit'/admin/vendor/edit/:id', :controller=> 'admins/vendors', :action => 'edit'
  map.admin_vendor_update '/admin/vendor/update/:id', :controller=> 'admins/vendors', :action => 'update'
  map.admin_vendor_show '/admin/vendor/show/:id', :controller=> 'admins/vendors', :action => 'show'
  map.admin_vendor_destroy '/admin/vendor/destroy', :controller=> 'admins/vendors', :action => 'destroy'
  
  #Email Configuration
  map.admin_email_configuration '/admin/email_configuration', :controller=> 'admins/email_configrations', :action => 'index'
  map.admin_email_configuration_new '/admin/email_configuration/new', :controller=> 'admins/email_configrations', :action => 'new'
  map.admin_email_configuration_create '/admin/email_configuration/create', :controller=> 'admins/email_configrations', :action => 'create'
  map.admin_email_configuration_edit '/admin/email_configuration/edit/:id', :controller=> 'admins/email_configrations', :action => 'edit'
  map.admin_email_configuration_update '/admin/email_configuration/update/:id', :controller=> 'admins/email_configrations', :action => 'update'
  map.admin_email_configuration_show '/admin/email_configuration/show/:id', :controller=> 'admins/email_configrations', :action => 'show'
  map.admin_email_configuration_destroy '/admin/email_configuration/destroy/:id', :controller=> 'admins/email_configrations', :action => 'destroy'
  
  #Introduction Email
  map.admin_introduction_email '/admin/introduction_email', :controller=> 'admins/introduction_mails', :action => 'index'
  map.admin_introduction_email_new '/admin/introduction_email/new', :controller=> 'admins/introduction_mails', :action => 'new'
  map.admin_introduction_email_create '/admin/introduction_email/create', :controller=> 'admins/introduction_mails', :action => 'create'
  map.admin_introduction_email_edit '/admin/introduction_email/edit/:id', :controller=> 'admins/introduction_mails', :action => 'edit'
  map.admin_introduction_email_update '/admin/introduction_email/update/:id', :controller=> 'admins/introduction_mails', :action => 'update'
  map.admin_introduction_email_show '/admin/introduction_email/show/:id', :controller=> 'admins/introduction_mails', :action => 'show'
  map.admin_introduction_email_destroy '/admin/introduction_email/destroy/:id', :controller=> 'admins/introduction_mails', :action => 'destroy'
  map.admin_introduction_email_sent_email '/admin/sent_email', :controller=> 'admins/introduction_mails', :action => 'sent_email'
  
  
  #map.create_invite 'publish_events/invitation_page/:invitee_ids',  :controller =>  'publish_events', :action => 'invitation_page'
  
  map.resources :wish_lists ,:member=>{:why_like_this_edit=>:post, :wish_lists_pagination=> :post, :why_like_this_update=> :post, :display_particular_product=> :post, :list_inventories=> :post,:edit_wishlist=>:post}  
  map.resources :publish_events, :member=>{:send_invitation=>:post, :sorting_with_albhabet=> :post, :invitation_page=>:get, :create_invite=> :post}
  map.resources :payment_processes, :member=>{:reserve_payment => :post, :online_payment=> :get, :order_gift_process=> :get, :payment_failure=> :get}, :collection=>{ :payment_sucess=>:post}
  
  # The priority is based upon order of creation: first created -> highest priority.

  # Sample of regular route:
  #   map.connect 'products/:id', :controller => 'catalog', :action => 'view'
  # Keep in mind you can assign values other than :controller and :action

  # Sample of named route:
  #   map.purchase 'products/:id/purchase', :controller => 'catalog', :action => 'purchase'
  # This route can be invoked with purchase_url(:id => product.id)

  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   map.resources :products

  # Sample resource route with options:
  #   map.resources :products, :member => { :short => :get, :toggle => :post }, :collection => { :sold => :get }

  # Sample resource route with sub-resources:
  #   map.resources :products, :has_many => [ :comments, :sales ], :has_one => :seller
  
  # Sample resource route with more complex sub-resources
  #   map.resources :products do |products|
  #     products.resources :comments
  #     products.resources :sales, :collection => { :recent => :get }
  #   end

  # Sample resource route within a namespace:
  #   map.namespace :admin do |admin|
  #     # Directs /admin/products/* to Admin::ProductsController (app/controllers/admin/products_controller.rb)
  #     admin.resources :products
  #   end

  # You can have the root of your site routed with map.root -- just remember to delete public/index.html.
  # map.root :controller => "welcome"

  # See how all your routes lay out with "rake routes"
   # Home Page
  map.root :controller => 'users', :action => 'index'
  # Install the default routes as the lowest priority.
  # Note: These default routes make all actions in every controller accessible via GET requests. You should
  # consider removing or commenting them out if you're using named routes and resources.
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
end
