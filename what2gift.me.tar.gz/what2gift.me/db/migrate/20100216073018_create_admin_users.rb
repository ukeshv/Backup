class CreateAdminUsers < ActiveRecord::Migration
  def self.up
   create_table "admin_users", :force => true do |t|
     
      t.column :email,                     :string, :limit => 100
      t.column :crypted_password,          :string, :limit => 40
      t.column :salt,                      :string, :limit => 40
      t.column :first_name,                      :string, :limit => 100, :default => '', :null => true
      t.column :last_phone,                      :string, :limit => 100, :default => '', :null => true
      t.column :mobile_phone,           :string, :limit => 100, :default => '', :null => true
      end
  end

  def self.down
     drop_table "admin_users"
  end
end
