class CreateInventories < ActiveRecord::Migration
  def self.up
    create_table :inventories do |t|
      t.column :category_id, :int
      t.column :title, :string, :limit => 100
      t.column :description, :text, :limit => 1000
      t.column :price, :string
      t.column :tags, :text
      t.column :url_link, :string
      t.timestamps
    end
  end

  def self.down
    drop_table :inventories
  end
end
