class AddAdmin < ActiveRecord::Migration
  def self.up
    add_column :admins, :fname, :string, :limit => 100
    add_column :admins, :lname, :string, :limit => 100
    add_column :admins, :mobile, :int
  end

  def self.down
  end
end
