class CreateEvents < ActiveRecord::Migration
  def self.up
    create_table :events do |t|
      t.column :host_id, :int
      t.column :persona_id, :int
      t.column :event_type_id, :int
      t.column :host_id, :int
      t.column :description, :text, :limit => 1000, :default => '', :null => true
      t.column :personalized_message, :text, :limit => 1000, :default => '', :null => true
      t.column :venue, :string, :limit => 100, :default => '', :null => true
      t.column :event_date, :string, :limit => 100, :default => '', :null => true
      t.column :event_time, :datetime
      t.timestamps
    end
  end

  def self.down
    drop_table :events
  end
end
