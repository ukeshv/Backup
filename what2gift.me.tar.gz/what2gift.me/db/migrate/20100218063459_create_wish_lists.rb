class CreateWishLists < ActiveRecord::Migration
  def self.up
    create_table :wish_lists do |t|
      t.column :event_id, :int
      t.column :inventory_id, :int
      t.column :invitee_category_id, :int
      t.column :why_like_this, :text, :limit => 1000, :default => '', :null => true
      t.timestamps
    end
  end

  def self.down
    drop_table :wish_lists
  end
end
