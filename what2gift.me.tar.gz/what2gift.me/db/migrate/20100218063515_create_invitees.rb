class CreateInvitees < ActiveRecord::Migration
  def self.up
    create_table :invitees do |t|
      t.column :host_id, :int
      t.column :fname, :string, :limit => 100, :default => '', :null => true
      t.column :lname, :string, :limit => 100, :default => '', :null => true
      t.column :description, :text, :limit => 1000, :default => '', :null => true
      t.column :phone, :string, :limit => 100, :default => '', :null => true
      t.column :mobile, :string, :limit => 100, :default => '', :null => true
      t.column :email, :string, :limit => 100, :default => '', :null => true
      t.timestamps
    end
  end

  def self.down
    drop_table :invitees
  end
end
