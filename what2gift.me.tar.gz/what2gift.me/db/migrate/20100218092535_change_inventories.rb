class ChangeInventories < ActiveRecord::Migration
  def self.up
    rename_column :inventories, :title, :name
    rename_column :inventories, :url_link, :vendor_inventory_link
    add_column :inventories, :brand, :string
    add_column :inventories, :short_description, :text

  end

  def self.down
    rename_column :inventories,:name ,:title
    rename_column :inventories, :vendor_inventory_link ,:url_link
    remove_column :inventories, :brand, :string
    remove_column :inventories, :short_description, :text
  end
end
