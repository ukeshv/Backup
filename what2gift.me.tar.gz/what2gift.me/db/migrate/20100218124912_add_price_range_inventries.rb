class AddPriceRangeInventries < ActiveRecord::Migration
  def self.up
    add_column :inventories, :price_range, :text
  end

  def self.down
    remove_column :inventories, :price_range, :text
  end
end
