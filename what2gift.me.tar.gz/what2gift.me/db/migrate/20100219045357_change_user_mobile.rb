class ChangeUserMobile < ActiveRecord::Migration
  def self.up
    change_column :admins, :mobile, :string
  end

  def self.down
    change_column :admins, :mobile, :integer
  end
end
