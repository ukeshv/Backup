class AddFieldToInventories < ActiveRecord::Migration
  def self.up
  add_column :inventories, :code, :int
  end

  def self.down
  remove_column :inventories, :code, :int
  end
end
