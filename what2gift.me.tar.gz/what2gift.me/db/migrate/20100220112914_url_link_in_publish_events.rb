class UrlLinkInPublishEvents < ActiveRecord::Migration
  def self.up
    add_column :invitees, :url_link, :string
    add_column :wish_lists, :is_reserved, :boolean, :default=> false
    add_column :wish_lists, :is_gifted, :boolean, :default=> false
  end

  def self.down
    remove_column :invitees, :url_link
    remove_column :wish_lists, :is_reserved
    remove_column :wish_lists, :is_gifted
  end
end
