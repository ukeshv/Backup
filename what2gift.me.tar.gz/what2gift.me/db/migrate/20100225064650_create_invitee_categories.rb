class CreateInviteeCategories < ActiveRecord::Migration
  def self.up
      create_table :invitee_categories do |t|
      t.column :invitee_category, :string, :limit => 100
      t.timestamps
  end
    InviteeCategory.create(:invitee_category => "Family")
    InviteeCategory.create(:invitee_category => "Friends")
    InviteeCategory.create(:invitee_category => "General")
    InviteeCategory.create(:invitee_category => "Co-workers")
    InviteeCategory.create(:invitee_category => "Buddies received")
    InviteeCategory.create(:invitee_category => "All")
  end

  def self.down
      drop_table :invitee_categories
  end
end
