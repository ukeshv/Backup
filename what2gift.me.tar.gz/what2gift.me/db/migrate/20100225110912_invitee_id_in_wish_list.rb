class InviteeIdInWishList < ActiveRecord::Migration
  def self.up
     change_column :wish_lists, :invitee_category_id, :string
  end

  def self.down
     change_column :wish_lists, :invitee_category_id, :int
  end
end
