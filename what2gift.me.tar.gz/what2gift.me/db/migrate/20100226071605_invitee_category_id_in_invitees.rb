class InviteeCategoryIdInInvitees < ActiveRecord::Migration
  def self.up
    add_column :invitees, :invitee_category_id, :string
  end

  def self.down
    remove_column :invitees, :invitee_category_id
  end
end
