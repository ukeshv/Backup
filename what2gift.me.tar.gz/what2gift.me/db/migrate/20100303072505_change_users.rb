class ChangeUsers < ActiveRecord::Migration
  def self.up
     add_column :users, :title, :string
     add_column :users, :suffix, :string
     add_column :users, :address1, :text
     add_column :users, :address2, :text
  end

  def self.down
     remove_column :users, :title, :string
     remove_column :users, :suffix, :string
     remove_column :users, :address1, :text
     remove_column :users, :address2, :text
  end
end
