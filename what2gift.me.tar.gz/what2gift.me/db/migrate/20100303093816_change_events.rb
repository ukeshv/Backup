class ChangeEvents < ActiveRecord::Migration
  def self.up
    change_column :events, :event_date, :datetime,:default => false
    change_column :events, :event_time,:text,:limit => 1000, :default => '', :null => true
  end

  def self.down
    change_column :events, :event_date, :string,:limit => 1000, :default => '', :null => true
    change_column :events, :event_time,:datetime
  end
end
