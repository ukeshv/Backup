class AddedInvitationAndInviteId < ActiveRecord::Migration
  def self.up
     add_column :invitees, :invite_id, :int
     add_column :attachments, :is_invitation, :boolean, :default=>false
  end

  def self.down
    remove_column :invitees, :invite_id
    remove_column :attachments, :is_invitation
  end
end
