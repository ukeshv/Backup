class CreateOrders < ActiveRecord::Migration
  def self.up
    create_table :orders do |t|
      t.column :user_id, :int
      t.column :event_id, :int
      t.column :amount, :int
      t.column :status, :boolean
      t.timestamps
    end
  end

  def self.down
    drop_table :orders
  end
end
