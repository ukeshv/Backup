class AddCurrencyToInventories < ActiveRecord::Migration
  def self.up
    add_column :inventories, :currency_type, :string, :limit => 100, :default => '', :null => true
  end

  def self.down
  remove_column :inventories, :currency_type, :string, :limit => 100, :default => '', :null => true

  end
end
