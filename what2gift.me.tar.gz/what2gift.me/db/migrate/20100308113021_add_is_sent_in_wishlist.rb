class AddIsSentInWishlist < ActiveRecord::Migration
  def self.up
    add_column :wish_lists, :is_sent, :boolean, :default=>false
  end

  def self.down
    remove_column :wish_lists, :is_sent, :boolean
  end
end
