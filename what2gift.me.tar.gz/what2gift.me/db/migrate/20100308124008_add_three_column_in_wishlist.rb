class AddThreeColumnInWishlist < ActiveRecord::Migration
  def self.up
    rename_column :wish_lists, :is_sent , :need_sent_mail
    add_column :wish_lists, :invitee_id, :integer
    add_column :wish_lists, :reserved_at, :datetime
  end

  def self.down
    rename_column :wish_lists, :need_sent_mail, :is_sent
    remove_column :wish_lists, :invitee_id
    remove_column :wish_lists, :reserved_at
  end
end
