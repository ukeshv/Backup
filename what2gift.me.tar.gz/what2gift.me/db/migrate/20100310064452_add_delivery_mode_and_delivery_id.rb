class AddDeliveryModeAndDeliveryId < ActiveRecord::Migration
  def self.up
    add_column :orders, :delivery_mode, :string
    add_column :orders, :delivery_id, :integer
  end

  def self.down
    remove_column :orders, :delivery_mode
    remove_column :orders, :delivery_id
  end
end
