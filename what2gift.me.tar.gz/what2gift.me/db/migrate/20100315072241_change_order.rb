class ChangeOrder < ActiveRecord::Migration
  def self.up
     change_column :orders, :amount, :float
  end

  def self.down
         change_column :orders, :amount, :int

  end
end
