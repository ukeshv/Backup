class CreateVendors < ActiveRecord::Migration
  def self.up
    create_table :vendors do |t|
      t.column :name, :string, :limit => 100
      t.column :description, :text, :limit => 1000
      t.timestamps
    end
    add_column :inventories, :vendor_id, :int
    add_column :inventories, :productid, :string
  end

  def self.down
    drop_table :vendors
    remove_column :inventories, :vendor_id
    remove_column :inventories, :productid
  end
end
