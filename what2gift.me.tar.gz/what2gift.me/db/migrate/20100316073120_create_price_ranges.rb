class CreatePriceRanges < ActiveRecord::Migration
  def self.up
    create_table :price_ranges do |t|
      t.column :price_range, :string, :limit => 250
      add_column :inventories, :price_range_id, :integer
      add_column :inventories, :vendor_name, :string
      t.timestamps
    end
    PriceRange.create!(:price_range=>"< 5,000")
    PriceRange.create!(:price_range=>"5,001-10,000")
    PriceRange.create!(:price_range=>"10,001-20,000")
    PriceRange.create!(:price_range=>"20,001-30,000")
    PriceRange.create!(:price_range=>"30,001-40,000")
    PriceRange.create!(:price_range=>"40,001-50,000")
    PriceRange.create!(:price_range=>"50,001-60,000")
    PriceRange.create!(:price_range=>"60,001-70,000")
    PriceRange.create!(:price_range=>"70,001-80,000")
    PriceRange.create!(:price_range=>"80,001-90,000")
    PriceRange.create!(:price_range=>"90,001-1,00,000")
    PriceRange.create!(:price_range=>"1,00,000-2,00,000")
    PriceRange.create!(:price_range=>"> 2,00,000")
  end

  def self.down
    drop_table :price_ranges
    remove_column :inventories, :price_range_id
    remove_column :inventories, :vendor_name
  end
end
