class CreateEmailConfigurations < ActiveRecord::Migration
  def self.up
    create_table :email_configurations do |t|
      t.column :admin_email, :string, :limit => 500
      t.column :support_email, :string, :limit => 500
      t.timestamps
    end
    EmailConfiguration.create!(:admin_email=>"admin@energeate.com", :support_email=>"support@energeate.com")
  end

  def self.down
    drop_table :email_configurations
  end
end
