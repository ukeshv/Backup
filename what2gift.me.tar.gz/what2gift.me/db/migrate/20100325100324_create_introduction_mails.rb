class CreateIntroductionMails < ActiveRecord::Migration
  def self.up
    create_table :introduction_mails do |t|
      t.column :fname, :string, :limit => 100
      t.column :lname, :string, :limit => 100
      t.column :sname, :string, :limit => 100
      t.column :email_sent, :boolean, :default=>false
      t.column :recipient_email, :string, :limit => 500
      t.timestamps
    end
  end

  def self.down
    drop_table :introduction_mails
  end
end
