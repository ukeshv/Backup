# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20100325100324) do

  create_table "admin_users", :force => true do |t|
    t.string "email",            :limit => 100
    t.string "crypted_password", :limit => 40
    t.string "salt",             :limit => 40
    t.string "first_name",       :limit => 100, :default => ""
    t.string "last_phone",       :limit => 100, :default => ""
    t.string "mobile_phone",     :limit => 100, :default => ""
  end

  create_table "admins", :force => true do |t|
    t.string   "login",                     :limit => 40
    t.string   "name",                      :limit => 100, :default => ""
    t.string   "email",                     :limit => 100
    t.string   "crypted_password",          :limit => 40
    t.string   "salt",                      :limit => 40
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "remember_token",            :limit => 40
    t.datetime "remember_token_expires_at"
    t.string   "fname",                     :limit => 100
    t.string   "lname",                     :limit => 100
    t.string   "mobile"
  end

  add_index "admins", ["login"], :name => "index_admins_on_login", :unique => true

  create_table "attachments", :force => true do |t|
    t.integer  "attachable_id"
    t.string   "attachable_type"
    t.integer  "parent_id"
    t.string   "content_type"
    t.string   "filename"
    t.integer  "size"
    t.string   "thumbnail"
    t.integer  "width"
    t.integer  "height"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "is_invitation",   :default => false
  end

  create_table "brands", :force => true do |t|
    t.string   "name",       :limit => 100
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "categories", :force => true do |t|
    t.string   "name",       :limit => 40
    t.datetime "created_at"
    t.datetime "updated_at"
    t.text     "tags"
  end

  create_table "email_configurations", :force => true do |t|
    t.string   "admin_email",   :limit => 500
    t.string   "support_email", :limit => 500
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "event_types", :force => true do |t|
    t.string   "name",       :limit => 100
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "events", :force => true do |t|
    t.integer  "host_id"
    t.integer  "persona_id"
    t.integer  "event_type_id"
    t.text     "description"
    t.text     "personalized_message"
    t.string   "venue",                :limit => 100, :default => ""
    t.datetime "event_date"
    t.text     "event_time"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "introduction_mails", :force => true do |t|
    t.string   "fname",           :limit => 100
    t.string   "lname",           :limit => 100
    t.string   "sname",           :limit => 100
    t.boolean  "email_sent",                     :default => false
    t.string   "recipient_email", :limit => 500
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "inventories", :force => true do |t|
    t.integer  "category_id"
    t.string   "name",                  :limit => 100
    t.text     "description"
    t.string   "price",                 :limit => 100
    t.text     "tags"
    t.string   "vendor_inventory_link"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "brand"
    t.text     "short_description"
    t.integer  "brand_id"
    t.text     "price_range"
    t.integer  "code"
    t.string   "currency_type",         :limit => 100, :default => ""
    t.integer  "vendor_id"
    t.string   "productid"
    t.integer  "price_range_id"
    t.string   "vendor_name"
  end

  create_table "invitee_categories", :force => true do |t|
    t.string   "invitee_category", :limit => 100
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "invitees", :force => true do |t|
    t.integer  "host_id"
    t.string   "fname",               :limit => 100, :default => ""
    t.string   "lname",               :limit => 100, :default => ""
    t.text     "description"
    t.string   "phone",               :limit => 100, :default => ""
    t.string   "mobile",              :limit => 100, :default => ""
    t.string   "email",               :limit => 100, :default => ""
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "event_id"
    t.string   "url_link"
    t.string   "invitee_category_id"
    t.integer  "invite_id"
  end

  create_table "orders", :force => true do |t|
    t.integer  "user_id"
    t.integer  "event_id"
    t.float    "amount"
    t.boolean  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "delivery_mode"
    t.integer  "delivery_id"
  end

  create_table "personas", :force => true do |t|
    t.string   "name",       :limit => 100
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "price_ranges", :force => true do |t|
    t.string   "price_range", :limit => 250
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.string   "user_name",                 :limit => 40
    t.string   "address",                   :limit => 1000, :default => ""
    t.string   "email",                     :limit => 100
    t.string   "fname",                     :limit => 100
    t.string   "lname",                     :limit => 100
    t.string   "crypted_password",          :limit => 40
    t.string   "salt",                      :limit => 40
    t.string   "website",                   :limit => 100,  :default => ""
    t.string   "phone",                     :limit => 100,  :default => ""
    t.string   "mobile_phone",              :limit => 100,  :default => ""
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "remember_token",            :limit => 40
    t.datetime "remember_token_expires_at"
    t.string   "activation_code",           :limit => 40
    t.datetime "activated_at"
    t.string   "password_reset_code",       :limit => 40
    t.string   "user_name_reset_code",      :limit => 40
    t.string   "title"
    t.string   "suffix"
    t.text     "about_me"
    t.string   "city"
    t.string   "state"
    t.string   "country"
    t.string   "pincode"
  end

  create_table "vendors", :force => true do |t|
    t.string   "name",        :limit => 100
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "wish_lists", :force => true do |t|
    t.integer  "event_id"
    t.integer  "inventory_id"
    t.string   "invitee_category_id"
    t.text     "why_like_this"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "is_reserved",         :default => false
    t.boolean  "is_gifted",           :default => false
    t.boolean  "need_sent_mail",      :default => false
    t.integer  "invitee_id"
    t.datetime "reserved_at"
  end

end
