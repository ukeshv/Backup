Given /^I am in the index page$/ do
 visit '/'
end
When /^I fill the fields with values "([^\"]*)"$/ do |arg1|
	selenium.set_speed(10)
  fill_in("user[user_name]", :with =>"kumarsankar")  		
	fill_in("user[password]", :with => "kumarsankar")    
	fill_in("user[password_confirmation]", :with => "kumarsankar")  
	fill_in("user[email]", :with => "kumarsankar@gmail.com")   
	fill_in("user[fname]", :with => "kumarsankar")   
	fill_in("user[lname]", :with => "sankar")   
	fill_in("user[about_me]", :with => "good")   
		fill_in("user[phone]", :with => "0442600898")    
	fill_in("user[mobile_phone]", :with => "9898989898")   
end

Given /^I am in the signin page$/ do
	 visit '/login'
end
When /^I fill in user_name with "([^\"]*)"$/ do |arg1|
	   fill_in("user_name", :with => arg1)
end
When /^I fill in password with "([^\"]*)"$/ do |arg1|
	  fill_in("password", :with =>arg1)
end

When /^I click login$/ do
	  selenium.click("//img[@alt='login']")
end
When /^I click submit$/ do
	 selenium.set_speed(10)
	  selenium.click("//img[@alt='submit']")
		end
When /^I click editprofile$/ do
	  selenium.click("//img[@alt='editprofile']")
	end
	When /^I click update$/ do
	  selenium.click("//img[@alt='update']")
	end
	When /^I click changepassword$/ do
	  selenium.click("//img[@alt='changepassword']")
	end
When /^I should activate the account$/ do
	
 users = User.find(:last)
 link = "activate/#{users.activation_code}"
 visit "/#{link}"

end
When /^I click save$/ do
	  selenium.click("//img[@alt='save']")
	end
	When /^I click add$/ do
	  selenium.click("//img[@alt='add']")
	end
	When /^I click addnewevent$/ do
	  selenium.click("//img[@alt='addnewevent']")
	end
	When /^I click createwishlist$/ do
	  selenium.click("//img[@alt='createwishlist']")
	end
		When /^I click productimage$/ do
		selenium.click("//img[@src='/attachments/0000/0005/1202284487_profile.jpg']")
		
	end

	When /^I click update_item$/ do
		selenium.click("//input[@src='/images/updateBut.jpg?1266836392']")
		
	end

Then /^I should go to the sign in page$/ do
  visit '/login'
end
When /^I fill the  user\[about_me\]  with "([^\"]*)"$/ do |arg1|
   fill_in("user[about_me]", :with => arg1)
end

Then /^I should fill in old_password with "([^\"]*)"$/ do |arg1|
   fill_in("old_password", :with => arg1)
 end
 
 Then /^I should fill in password "([^\"]*)"$/ do |arg1|
 fill_in("password", :with => arg1)
end

Then /^I should fill in password_confirmation "([^\"]*)"$/ do |arg1|
  fill_in("password_confirmation", :with => arg1)
end

Then /^I attach a "([^\"]*)" image to "([^\"]*)"$/ do |arg1, arg2|
	selenium.attach_file( "attachment_uploaded_data",'file:///home/mariammal/what2gift.me/public/images/pro_002.jpg')
	end

Then /^I fiil in description with "([^\"]*)"$/ do |arg1|
  fill_in("event[description]", :with => arg1)
end

Then /^I fill in venue with "([^\"]*)"$/ do |arg1|
 fill_in("event[venue]", :with => arg1)
end

Then /^I select birthday party from "([^\"]*)"$/ do |arg1|
	selenium.select("event[event_type_id]","birthday party")

end

Then /^I select birthday boy from "([^\"]*)"$/ do |arg1|
   selenium.select("event[persona_id]","birthday boy")
 end
 
 Then /^I select 01\.00 PM from "([^\"]*)"$/ do |arg1|
 selenium.select("event[event_time]","01.00 PM")
end

 
Then /^I should see 'Edit event "([^\"]*)"'$/ do |arg1|
  response.should contain('Edit event "Welcome u all"')
end

Then /^I select electronics from "([^\"]*)"$/ do |arg1|
  selenium.select("category[id]","electronics")
end

Then /^I select motorola from "([^\"]*)"$/ do |arg1|
  selenium.select("brand[id]","motorola")
end

Given /^I am in the dashboard page of user123$/ do
  visit "/users/1/dashboards"
end

Then /^it should be added to the wishlist$/ do
	
	 assert_equal 'inv3',selenium.text_content("//div[@class='Wishlist']/div/ul/li[1]/a[contains(@class,'proName')]")
   assert_equal 'inventory2', selenium.text_content("//div[@class='Wishlist']/div/ul/li[2]/a[contains(@class,'proName')]")
  
end

Then /^I click addbutton of item3$/ do
selenium.click("//a[@id='plus_3']/img[contains(@alt,'add')]")
 end
Then /^I click addbutton of item2$/ do
selenium.click("//a[@id='plus_2']/img[contains(@alt,'add')]")
 end

When /^I click editgift of first item of wishlist$/ do
	 selenium.click("//a[@class='editGift'][1]")
	end
Then /^I check Friends$/ do
	selenium.check("invitee_category_1")
end
Then /^I fill in wish_list\[why_like_this\] with "([^\"]*)"$/ do |arg1|
  fill_in("wish_list[why_like_this]", :with => arg1)
end

When /^I click deletegift of first item of wishlist$/ do
	selenium.refresh
	selenium.refresh
	selenium.refresh
	selenium.refresh
	selenium.click("//a[@class='removeGift'][1]")
 end
 
 Then /^I will check prompt$/ do
 assert_equal 'Are you sure to delete?',selenium.get_confirmation
 selenium. choose_cancel_on_next_confirmation
 assert_equal 'inv3',selenium.text_content("//div[@class='Wishlist']/div/ul/li[1]/a[contains(@class,'proName')]")
 assert_equal "1",selenium.get_xpath_count("//div[@class='Wishlist']/div/ul/li")
 selenium. choose_ok_on_next_confirmation
 end
 
