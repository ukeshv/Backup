class StandardRegexp
        @@regex={
                :alpha => /^[A-Za-z ]+$/,
                :numeric => /^[0-9 ]+$/,
                :alpha_numeric => /^[A-Za-z0-9 ]+$/,
                :email => /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\Z/i,
                :username => /^[A-Za-z]+$/,
                :password => /^(?=.*\d)(?=.*([a-z]|[A-Z]))([\x20-\x7E]){8,40}$/,
                :phone => /(\+)?([-\._\(\) ]?[\d]{3,20}[-\._\(\) ]?){2,10}/,
                :zip => /^\d{5}$/,
                :city => /^[A-Za-z ]+$/,
                :state => /^[A-Z]{2}$/,
                :url => /^(ftp|https?):\/\/((?:[-a-z0-9]+\.)+[a-z]{2,})/,
                :ip => /^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})?$/,
                :cc => /^((67\d{2})|(4\d{3})|(5[1-5]\d{2})|(6011))(-?\s?\d{4}){3}|(3[4,7])\d{2}-?\s?\d{6}-?\s?\d{5}$/,
                :ccv => /^\d{3}$/,
        }

        def self.method_missing(method, *args)
                r=@@regex[method]
                raise NoMethodError if r.nil?
                r
        end
end

#now to rewrite the example from the ruby documentation:
=begin
class Person < ActiveRecord::Base
    validates_format_of :email, :with => StandardRegexp.email, :on => :create
end
=end



