// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults
function ismaxlength(obj){
           var mlength=obj.getAttribute? parseInt(obj.getAttribute("maxlength")) : ""
            if (obj.getAttribute && obj.value.length>mlength)
                obj.value=obj.value.substring(0,mlength)
        }
        


function wishInviteCheck(val){
if(val.id != "invitee_category_6")
	$("invitee_category_6").checked = false;
 else if($("invitee_category_6").checked == true)
 {
  for(i=1;i<=5;i++)
  {
    $("invitee_category_"+i).checked = false;
  }
 }
}


function select_the_item(current_obj_class)
	{
	var check_boxes= document.getElementsByClassName(current_obj_class);
	arr = [ ];
		for(i=0;i<check_boxes.length;i++){
			if(check_boxes[i].checked==true)
			arr.push(check_boxes[i].value);
		}
	if (arr.length > 0){
	return true;
		}
	else {
	$('why_like_this_successmsg').innerHTML = "<font color='red'>Please select the categories for this gift item.</font>"
	Element.show('why_like_this_successmsg');
	return false;
	}
	}