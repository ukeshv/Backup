function submitURL()
{window.open("http://submiturl.search.rediff.com/submit_URL.php","submitURLwin","toolbar=no,directories=no,resize=yes,menubar=no,location=no,scrollbars=yes,width=490,height=480,maximize=null,top=10,left=10");}

function findPosXY(tblid,tblid1,x,y){
	var curleft = 0;
	var curtop = 0;
	var obj = document.getElementById(tblid);
	if (obj.offsetParent)
	{
		while (obj.offsetParent)
		{
			curleft += obj.offsetLeft
			obj = obj.offsetParent;
		}
	}
	else if (obj.x)
	curleft += obj.x;
	document.getElementById(tblid1).style.left= parseInt(curleft + x) + 'px' ;
	var obj1 = document.getElementById(tblid);
	if (obj1.offsetParent)
	{
		while (obj1.offsetParent)
		{
			curtop += obj1.offsetTop
			obj1 = obj1.offsetParent;
		}
	}
	else if (obj1.y)
		curtop += obj1.y;
		document.getElementById(tblid1).style.top=parseInt(curtop + y) + 'px' ;
		document.getElementById(tblid1).style.display = "block" ;
}

function showDiv1(dvnm){
 document.getElementById(dvnm).style.display = "block" ;
}
function hideDiv1(dvnm){
 document.getElementById(dvnm).style.display = "none" ;
}
 
function showDivs(divnm){
		document.getElementById(divnm).style["display"]="block" ;
		document.getElementById(divnm).style["visibility"]="visible" ;
}

function hideDivs(divnm){
		document.getElementById(divnm).style["display"]="none" ;
		document.getElementById(divnm).style["visibility"]="hidden" ;
}
function GetCityValue(city){
    var matchcity = new Array( "Agartala (IXA)","IXA","ixa","Agatti (AGX)","AGX","agx","Agra (AGR)","AGR","agr","Ahmedabad (AMD)","AMD","amd","Aizawl (AJL)","AJL","ajl","Allahabad (IXD)","IXD","ixd","Amritsar (ATQ)","ATQ","atq","Aurangabad (IXU)","IXU","ixu","Baghdogra (IXB)","IXB","ixb","Bangalore (BLR)","BLR","blr","Belgaum (IXG)","IXG","ixg","Bellary (VID)","VID","vid","Bhavnagar (BHU)","BHU","bhu","Bhopal (BHO)","BHO","bho","Bhubaneshwar (BBI)","BBI","bbi","BHJ - Bhuj","BHJ","bhj","Calicut (CCJ)","CCJ","ccj","Chandigarh (IXC)","IXC","ixc","Chennai (MAA)","MAA","maa","Cochin(Kochi) (COK)","COK","cok","Coimbatore (CJB)","CJB","cjb","Dehradun (DED)","","","New Delhi (DEL)","","","Dharamshala (DHM)","DHM","dhm","Dibrugarh (DIB)","DIB","dib","Dimapur (DMU)","DMU","dmu","Diu (DIU)","DIU","diu","Gaya (GAY)","GAY","gay","Goa (GOI)","GOI","goi","Gorakhpur (GOP)","GOP","gop","Guwahati (GAU)","GAU","gau","Gwalior (GWL)","GWL","gwl","Hubli (HBX)","HBX","hbx","Hyderabad (HYD)","HYD","hyd","Imphal (IMF)","IMF","imf","Indore (IDR)","IDR","idr","Jabalpur (JLR)","JLR","jlr","Jaipur (JAI)","JAI","jai","Jaisalmer (JSA)","JSA","jsa","Jammu (IXJ)","IXJ","ixj","Jamnagar (JGA)","JGA","jga","Jamshedpur (IXW)","IXW","ixw","Jodhpur (JDH)","JDH","jdh","Jorhat (JRH)","JRH","jrh","Kandla (IXY)","IXY","ixy","Kanpur (KNU)","KNU","knu","Khajuraho (HJR)","HJR","hjr","Kolhapur (KLH)","KLH","klh","Kolkata (CCU)","CCU","ccu","Kullu (KUU)","KUU","kuu","Latur (LTU)","LTU","ltu","Leh (IXL)","IXL","ixl","Lilabari (IXI)","IXI","ixi","Lucknow (LKO)","LKO","lko","Madurai (IXM)","IXM","ixm","Mangalore (IXE)","IXE","ixe","Mumbai (BOM)","BOM","bom","Nagpur (NAG)","NAG","nag","Nanded (NDC)","NDC","ndc","Nasik (ISK)","ISK","isk","Pathankot (IXP)","IXP","ixp","Patna (PAT)","PAT","pat","Porbandar (PBD)","PBD","pbd","Portblair (IXZ)","IXZ","ixz","Pune (PNQ)","PNQ","pnq","Raipur (RPR)","RPR","rpr","Rajahmundry (RJA)","RJA","rja","Rajkot (RAJ)","RAJ","raj","Ranchi (IXR)","IXR","ixr","Shillong (SHL)","SHL","shl","Shimla (SLV)","SLV","slv","Silchar (IXS)","IXS","ixs","Srinagar (SXR)","SXR","sxr","Surat (STV)","STV","stv","Tezpur (TEZ)","TEZ","tez","Thiruvananthapuram (TRV)","TRV","trv","Tiruchirapalli (TRZ)","TRZ","trz","Tirupati (TIR)","TIR","tir","Tuticorin (TCR)","TCR","tcr","Udaipur (UDR)","UDR","udr","Vadodara (BDQ)","BDQ","bdq","Varanasi (VNS)","VNS","vns","Vijaywada (VGA)","VGA","vga","Vishakapatanam (VTZ)","VTZ","vtz");
    var cityvalue = new Array("Agartala","Agartala","Agartala","Agatti","Agatti","Agatti","Agra","Agra","Agra","Ahmedabad","Ahmedabad","Ahmedabad","Aizawl","Aizawl","Aizawl","Allahabad","Allahabad","Allahabad","Amritsar","Amritsar","Amritsar","Aurangabad","Aurangabad","Aurangabad","Baghdogra","Baghdogra","Baghdogra","Bangalore","Bangalore","Bangalore","Belgaum","Belgaum","Belgaum","Bellary","Bellary","Bellary","Bhavnagar","Bhavnagar","Bhavnagar","Bhopal","Bhopal","Bhopal","Bhubaneshwar","Bhubaneshwar","Bhubaneshwar","Bhuj","Bhuj","Bhuj","Calicut","Calicut","Calicut","Chandigarh","Chandigarh","Chandigarh","Chennai(Madras)","Chennai(Madras)","Chennai(Madras)","Cochin(Kochi)","Cochin(Kochi)","Cochin(Kochi)","Coimbatore","Coimbatore","Coimbatore","Dehradun","Dehradun","Dehradun","Delhi","Delhi","Delhi","Dharamshala","Dharamshala","Dharamshala","Dibrugarh","Dibrugarh","Dibrugarh","Dimapur","Dimapur","Dimapur","Diu","Diu","Diu","Gaya","Gaya","Gaya","Goa","Goa","Goa","Gorakhpur","Gorakhpur","Gorakhpur","Guwahati","Guwahati","Guwahati","Gwalior","Gwalior","Gwalior","Hubli","Hubli","Hubli","Hyderabad","Hyderabad","Hyderabad","Imphal","Imphal","Imphal","Indore","Indore","Indore","Jabalpur","Jabalpur","Jabalpur","Jaipur","Jaipur","Jaipur","Jaisalmer","Jaisalmer","Jaisalmer","Jammu","Jammu","Jammu","Jamnagar","Jamnagar","Jamnagar","Jamshedpur","Jamshedpur","Jamshedpur","Jodhpur","Jodhpur","Jodhpur","Jorhat","Jorhat","Jorhat","Kandla","Kandla","Kandla","Kanpur","Kanpur","Kanpur","Khajuraho","Khajuraho","Khajuraho","Kolhapur","Kolhapur","Kolhapur","Kolkata","Kolkata","Kolkata","Kullu","Kullu","Kullu","Latur","Latur","Latur","Leh","Leh","Leh","Lilabari","Lilabari","Lilabari","Lucknow","Lucknow","Lucknow","Madurai","Madurai","Madurai","Mangalore","Mangalore","Mangalore","Mumbai","Mumbai","Mumbai","Nagpur","Nagpur","Nagpur","Nanded","Nanded","Nanded","Nasik","Nasik","Nasik","Pathankot","Pathankot","Pathankot","Patna","Patna","Patna","Porbandar","Porbandar","Porbandar","Portblair","Portblair","Portblair","Pune","Pune","Pune","Raipur","Raipur","Raipur","Rajahmundry","Rajahmundry","Rajahmundry","Rajkot","Rajkot","Rajkot","Ranchi","Ranchi","Ranchi","Shillong","Shillong","Shillong","Shimla","Shimla","Shimla","Silchar","Silchar","Silchar","Srinagar","Srinagar","Srinagar","Surat","Surat","Surat","Tezpur","Tezpur","Tezpur","Thiruvananthapuram","Thiruvananthapuram","Thiruvananthapuram","Tiruchirapalli","Tiruchirapalli","Tiruchirapalli","Tirupati","Tirupati","Tirupati","Tuticorin","Tuticorin","Tuticorin","Udaipur","Udaipur","Udaipur","Vadodara","Vadodara","Vadodara","Varanasi","Varanasi","Varanasi","Vijaywada","Vijaywada","Vijaywada","Vishakapatanam","Vishakapatanam","Vishakapatanam");

    var matchfound="";
    for (i = 0; i < matchcity.length; i++)
    {
        if (matchcity[i] == city)
        {
            matchfound = cityvalue[i];
            break;
        }
    }
    //alert(matchfound);
    return matchfound;
}

/*for new calender */


var datePickerDivID = "datepicker";
var iFrameDivID = "datepickeriframe";

var dayArrayShort = new Array('S', 'M', 'T', 'W', 'T', 'F', 'S');
var dayArrayMed = new Array('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat');
var dayArrayLong = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
var monthArrayShort = new Array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
var monthArrayMed = new Array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec');
var monthArrayLong = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
 

var defaultDateSeparator = "-";        // common values would be "/" or "." or "-"
var defaultDateFormat = "ddmmmyy";    // valid values are "mdy", "dmy", and "ymd"
var dateSeparator = defaultDateSeparator;
var dateFormat = defaultDateFormat;


function displayDatePicker(dateFieldName, displayBelowThisObject, dtFormat, dtSep){
  var targetDateField = document.getElementsByName (dateFieldName).item(0);
 
  if (!displayBelowThisObject)
    displayBelowThisObject = targetDateField;
 
  if (dtSep)
    dateSeparator = dtSep;
  else
    dateSeparator = defaultDateSeparator;
 
  if (dtFormat)
    dateFormat = dtFormat;
  else
    dateFormat = defaultDateFormat;
 
  var x = displayBelowThisObject.offsetLeft;
  var y = displayBelowThisObject.offsetTop + displayBelowThisObject.offsetHeight ;
 
  var parent = displayBelowThisObject;
  while (parent.offsetParent) {
    parent = parent.offsetParent;
    x += parent.offsetLeft;
    y += parent.offsetTop ;
  }
 
  drawDatePicker(targetDateField, x, y);
}

function drawDatePicker(targetDateField, x, y){
  var dt = getFieldDate(targetDateField.value );
 
  if (!document.getElementById(datePickerDivID)) {
 
    var newNode = document.createElement("div");
    newNode.setAttribute("id", datePickerDivID);
    newNode.setAttribute("class", "dpDiv");
    newNode.setAttribute("style", "visibility: hidden;");
    document.body.appendChild(newNode);
  }
 
  var pickerDiv = document.getElementById(datePickerDivID);
  pickerDiv.style.position = "absolute";
  pickerDiv.style.left = x + "px";
  pickerDiv.style.top = y + "px";
  pickerDiv.style.visibility = (pickerDiv.style.visibility == "visible" ? "hidden" : "visible");
  pickerDiv.style.display = (pickerDiv.style.display == "block" ? "none" : "block");
  pickerDiv.style.zIndex = 10000;
 
  refreshDatePicker(targetDateField.name, dt.getFullYear(), dt.getMonth(), dt.getDate());
}


function refreshDatePicker(dateFieldName, year, month, day){
  
  var thisDay = new Date();
 
  if ((month >= 0) && (year > 0)) {
    thisDay = new Date(year, month, 1);
  } else {
    day = thisDay.getDate();
    thisDay.setDate(1);
  }
 

  var crlf = "\r\n";
  var TABLE = "<table cols=7 width=162 class='dpTable'>" + crlf;
  var xTABLE = "</table>" + crlf;
  var TR = "<tr class='dpTR'>";
  var TR_title = "<tr class='dpTitleTR'>";
  var TR_days = "<tr class='dpDayTR'>";
  var TR_todaybutton = "<tr class='dpTodayButtonTR'>";
  var xTR = "</tr>" + crlf;
  var TD = "<td class='dpTD' onMouseOut='this.className=\"dpTD\";' onMouseOver=' this.className=\"dpTDHover\";' ";    // leave this tag open, because we'll be adding an onClick event
  var TD_title = "<td colspan=5 class='dpTitleTD'>";
  var TD_buttons = "<td class='dpButtonTD'>";
  var TD_todaybutton = "<td colspan=7 class='dpTodayButtonTD'>";
  var TD_days = "<td class='dpDayTD'>";
  var TD_selected = "<td class='dpDayHighlightTD' onMouseOut='this.className=\"dpDayHighlightTD\";' onMouseOver='this.className=\"dpTDHover\";' ";    // leave this tag open, because we'll be adding an onClick event
  var xTD = "</td>" + crlf;
  var DIV_title = "<div class='dpTitleText'>";
  var DIV_selected = "<div class='dpDayHighlight'>";
  var xDIV = "</div>";
 
  var html = TABLE;
 
  
  html += TR_title;
  html += TD_buttons + getButtonCode(dateFieldName, thisDay, -1, "&lt;") + xTD;
  html += TD_title + DIV_title + monthArrayLong[ thisDay.getMonth()] + " " + thisDay.getFullYear() + xDIV + xTD;
  html += TD_buttons + getButtonCode(dateFieldName, thisDay, 1, "&gt;") + xTD;
  html += xTR;
 
  html += TR_days;
  for(i = 0; i < dayArrayShort.length; i++)
    html += TD_days + dayArrayShort[i] + xTD;
  html += xTR;
 
  html += TR;
 
  for (i = 0; i < thisDay.getDay(); i++)
    html += TD + "&nbsp;" + xTD;
 
  // now, the days of the month
  do {
    dayNum = thisDay.getDate();
    TD_onclick = " onclick=\"updateDateField('" + dateFieldName + "', '" + getDateString(thisDay) + "');\">";
    
    if (dayNum == day)
      html += TD_selected + TD_onclick + DIV_selected + dayNum + xDIV + xTD;
    else
      html += TD + TD_onclick + dayNum + xTD;
    
    // if this is a Saturday, start a new row
    if (thisDay.getDay() == 6)
      html += xTR + TR;
    
    // increment the day
    thisDay.setDate(thisDay.getDate() + 1);
  } while (thisDay.getDate() > 1)
 
  // fill in any trailing blanks
  if (thisDay.getDay() > 0) {
    for (i = 6; i > thisDay.getDay(); i--)
      html += TD + "&nbsp;" + xTD;
  }
  html += xTR;
 
  // add a button to allow the user to easily return to today, or close the calendar
  var today = new Date();
  var todayString = "Today is " + dayArrayMed[today.getDay()] + ", " + monthArrayMed[ today.getMonth()] + " " + today.getDate();
  html += TR_todaybutton + TD_todaybutton;
  html += "<button class='dpTodayButton' onClick='refreshDatePicker(\"" + dateFieldName + "\");'>this month</button> ";
  html += "<button class='dpTodayButton' onClick='updateDateField(\"" + dateFieldName + "\");'>close</button>";
  html += xTD + xTR;
 
  // and finally, close the table
  html += xTABLE;
 
  document.getElementById(datePickerDivID).innerHTML = html;
  // add an "iFrame shim" to allow the datepicker to display above selection lists
  adjustiFrame();
}



function getButtonCode(dateFieldName, dateVal, adjust, label){
  var newMonth = (dateVal.getMonth () + adjust) % 12;
  var newYear = dateVal.getFullYear() + parseInt((dateVal.getMonth() + adjust) / 12);
  if (newMonth < 0) {
    newMonth += 12;
    newYear += -1;
  }
 
  return "<button class='dpButton' onClick='refreshDatePicker(\"" + dateFieldName + "\", " + newYear + ", " + newMonth + ");'>" + label + "</button>";
}

function getDateString(dateVal){
  var dayString = "00" + dateVal.getDate();
  var monthString = "00" + (dateVal.getMonth()+1);
  dayString = dayString.substring(dayString.length - 2);
  monthString = monthString.substring(monthString.length - 2);
 
  switch (dateFormat) {
    case "ddmmmyy" :
      return dayString + dateSeparator + monthArrayShort[dateVal.getMonth()] + dateSeparator + dateVal.getFullYear();
    case "dmy" :
      return dayString + dateSeparator + monthString + dateSeparator + dateVal.getFullYear();
    case "ymd" :
      return dateVal.getFullYear() + dateSeparator + monthString + dateSeparator + dayString;
    case "mdy" :
    default :
      return monthString + dateSeparator + dayString + dateSeparator + dateVal.getFullYear();
  }
}
/*
function fnradioway() {
    if (document.track.radioway[1].checked == true) {
        document.track.document_date22.disabled = true
    } else {
        document.track.document_date22.disabled = false
    }
}
*/
function fnradioway() {}

function getFieldDate(dateString){
  var dateVal;
  var dArray;
  var d, m, y;
 
  try {
    dArray = splitDateString(dateString);
    if (dArray) {
      switch (dateFormat) {
        case "dmy" :
          d = parseInt(dArray[0], 10);
          m = parseInt(dArray[1], 10) - 1;
          y = parseInt(dArray[2], 10);
          break;
        case "ymd" :
          d = parseInt(dArray[2], 10);
          m = parseInt(dArray[1], 10) - 1;
          y = parseInt(dArray[0], 10);
          break;
        case "mdy" :
        default :
          d = parseInt(dArray[1], 10);
          m = parseInt(dArray[0], 10) - 1;
          y = parseInt(dArray[2], 10);
          break;
      }
      dateVal = new Date(y, m, d);
    } else if (dateString) {
      dateVal = new Date(dateString);
    } else {
      dateVal = new Date();
    }
  } catch(e) {
    dateVal = new Date();
  }
 
  return dateVal;
}


function splitDateString(dateString){
  var dArray;
  if (dateString.indexOf("/") >= 0)
    dArray = dateString.split("/");
  else if (dateString.indexOf(".") >= 0)
    dArray = dateString.split(".");
  else if (dateString.indexOf("-") >= 0)
    dArray = dateString.split("-");
  else if (dateString.indexOf("\\") >= 0)
    dArray = dateString.split("\\");
  else
    dArray = false;
 
  return dArray;
}

function updateDateField(dateFieldName, dateString){
  var targetDateField = document.getElementsByName (dateFieldName).item(0);
  if (dateString)
    targetDateField.value = dateString;
 
  var pickerDiv = document.getElementById(datePickerDivID);
  pickerDiv.style.visibility = "hidden";
  pickerDiv.style.display = "none";
 
  adjustiFrame();
  targetDateField.focus();
 
  if ((dateString) && (typeof(datePickerClosed) == "function"))
    datePickerClosed(targetDateField);
}


function adjustiFrame(pickerDiv, iFrameDiv){
  
  var is_opera = (navigator.userAgent.toLowerCase().indexOf("opera") != -1);
  if (is_opera)
    return;
  
 
  try {
    if (!document.getElementById(iFrameDivID)) {
      //document.body.innerHTML += "<iframe id='" + iFrameDivID + "' src='javascript:false;' scrolling='no' frameborder='0'>";
      var newNode = document.createElement("iFrame");
	  iFrameDiv.style.width = '0'+px;
      iFrameDiv.style.height = '0'+px;
      newNode.setAttribute("id", iFrameDivID);
      newNode.setAttribute("src", "javascript:false;");
      newNode.setAttribute("scrolling", "no");
      newNode.setAttribute ("frameborder", "0");
      document.body.appendChild(newNode);
    }
    
    if (!pickerDiv)
      pickerDiv = document.getElementById(datePickerDivID);
    if (!iFrameDiv)
      iFrameDiv = document.getElementById(iFrameDivID);
    
    try {
      iFrameDiv.style.position = "absolute";
      iFrameDiv.style.width = pickerDiv.offsetWidth;
      iFrameDiv.style.height = pickerDiv.offsetHeight ;
      iFrameDiv.style.top = pickerDiv.style.top;
      iFrameDiv.style.left = pickerDiv.style.left;
      iFrameDiv.style.zIndex = pickerDiv.style.zIndex - 1;
      iFrameDiv.style.visibility = pickerDiv.style.visibility ;
      iFrameDiv.style.display = pickerDiv.style.display;
    } catch(e) {
    }
 
  } catch (ee) {
  }
 
}
function showtxtDate(B) {
    var A = new makeArray("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
    if (B.getDate() < 10) {
        day = "0" + B.getDate()
    } else {
        day = B.getDate()
    }
    return day + "-" + A[B.getMonth()] + "-" + (B.getFullYear())
}
function DateAdd(F, A, K) {
    var J = 1;
    var C = J * 1000;
    var D = C * 60;
    var E = D * 60;
    var H = E * 24;
    var G = H * 365;
    var I;
    var B = K.valueOf();
    switch (F) {
    case "ms":
        I = new Date(B + J * A);
        break;
    case "s":
        I = new Date(B + C * A);
        break;
    case "mi":
        I = new Date(B + D * A);
        break;
    case "h":
        I = new Date(B + E * A);
        break;
    case "d":
        I = new Date(B + H * A);
        break;
    case "y":
        I = new Date(B + G * A);
        break
    }
    return I
}
function makeArray() {
    var A = makeArray.arguments;
    for (var B = 0; B < A.length; B++) 
    {
        this[B] = A[B];
    }
    this.length = A.length;
}

function emailwin(I){var L=parent.location.href;var J=L.split("?");var H=J[1];var G=I;var K=domainName+"/email_travelplanner.php?"+H+"&amp;tname="+G;window.open(K,"","height=1500,width=500,status=yes,toolbar=yes,menubar=yes,location=no");}


function bold(b){
	document.getElementById(b).className="r_bold"
}
function unbold(b){
	document.getElementById(b).className="r_unbold"
}


