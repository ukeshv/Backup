 
var EventsController = Class.create({
  initialize: function(form, userId) {
		this.userId = userId;
		this.formElement = form;
		// form submission
		Object.extend($('event_persona_id'), UpdateEvent).initialize();
		Object.extend($('event_event_type_id'), UpdateEvent).initialize();
		Object.extend($('event_description'), KeyupUpdateEvent).initialize();
		Object.extend($('event_venue'), UpdateEvent).initialize();
		Object.extend($('event_date'), UpdateEvent).initialize();
		Object.extend($('event_event_time'), UpdateEvent).initialize();
		Object.extend($('event_personalized_message'), UpdateEvent).initialize();
		//Object.extend($('attachment_uploaded_data'), UpdateEvent).initialize();*/
		
		// to go my event list page
		//Object.extend($('my_events_tag'), MyEventPage).initialize(this.formElement, this.userId);
		// to go wishlist page
		Object.extend($('my_wishlist_tag'), EventWishListPage).initialize(this.formElement, this.userId);
		// to go publis event page
		Object.extend($('publish_event_tag'), EventPublishPage).initialize(this.formElement, this.userId);
  }
});


var KeyupUpdateEvent = {
  initialize: function() {
  },
		
		onmouseout: function() {
			if(this.form['event[persona_id]'].value && this.form['event[event_type_id]'].value && this.form['event[description]'].value.strip() && this.form['mouse_checkout'].value =='false')
			{
				this.form['mouse_checkout'].value = 'true';
				if(this.form['event_status'].value == "edit")
					new Ajax.Request(this.form.action, {asynchronous: true, evalScripts: true, parameters:Form.serialize(this.form), method: 'PUT', onSuccess: this.successfulSave.bind(this)});
				else
					new Ajax.Request(this.form.action, {asynchronous: true, evalScripts: true, parameters:Form.serialize(this.form), method: 'POST', onSuccess: this.successfulSave.bind(this)});
			}
			if(!this.form['event[description]'].value.strip())
				this.form['mouse_checkout'].value = 'false';
		},
		onchange: function() {
			if(!this.form['event[description]'].value.strip())
				this.form['mouse_checkout'].value = 'false';
			if(this.form['event[persona_id]'].value && this.form['event[event_type_id]'].value && this.form['event[description]'].value.strip() )
			{
				this.form['mouse_checkout'].value = true;
				if(this.form['event_status'].value == "edit")
					new Ajax.Request(this.form.action, {asynchronous: true, evalScripts: true, parameters:Form.serialize(this.form), method: 'PUT', onSuccess: this.successfulSave.bind(this)});
				else
					new Ajax.Request(this.form.action, {asynchronous: true, evalScripts: true, parameters:Form.serialize(this.form), method: 'POST', onSuccess: this.successfulSave.bind(this)});
			}
		},
	
	successfulSave: function(o) {
		this.form.action = "/users/"+this.form['event_user_id'].value+"/events/"+this.form['event_update_id'].value;
  }
};

var UpdateEvent = {
  initialize: function() {
  },
		
		onchange: function() {
			if(!this.form['event[description]'].value.strip())
				this.form['mouse_checkout'].value = 'false';
			if(this.form['event[persona_id]'].value && this.form['event[event_type_id]'].value && this.form['event[description]'].value.strip() )
			{
				this.form['mouse_checkout'].value = true;
				if(this.form['event_status'].value == "edit")
					new Ajax.Request(this.form.action, {asynchronous: true, evalScripts: true, parameters:Form.serialize(this.form), method: 'PUT', onSuccess: this.successfulSave.bind(this)});
				else
					new Ajax.Request(this.form.action, {asynchronous: true, evalScripts: true, parameters:Form.serialize(this.form), method: 'POST', onSuccess: this.successfulSave.bind(this)});
			}
		},
	
	successfulSave: function(o) {
		this.form.action = "/users/"+this.form['event_user_id'].value+"/events/"+this.form['event_update_id'].value;
  }
};

/*var MyEventPage = {
  initialize: function(formElement, userId) {
		this.formElement = formElement;
		this.userId = userId
  },
	
  onclick: function(event) {
		if(this.formElement['event_update_id'].value == "edit")
		{
			window.location = "/users/"+this.userId+"/events/"+this.formElement['udatestatus'].value;
			$('error_msg').style.display = "none";
		}
		else
			$('error_msg').style.display = "block";
		Event.stop(event);
  }
};*/

var EventWishListPage = {
  initialize: function(formElement, userId) {
		this.formElement = formElement;
		this.userId = userId
  },
	
  onclick: function(event) {
		if(this.formElement['event_status'].value == "edit")
		{
			window.location = "/wish_lists?event_id="+this.formElement['event_update_id'].value;
			$('error_msg').style.display = "none";
		}
		else
			$('error_msg').style.display = "block";
		//Event.stop(event);
  }
};

var EventPublishPage = {
  initialize: function(formElement, userId) {
		this.formElement = formElement;
		this.userId = userId
  },
	
  onclick: function(event) {
		if(this.formElement['event_status'].value == "edit")
		{
			window.location = "/publish_events/new?event_id="+this.formElement['event_update_id'].value
			$('error_msg').style.display = "none";
		}
		else
			$('error_msg').style.display = "block";
	//	Event.stop(event);
  }
};



var DisplayDashboardEvents = {
  initialize: function(userId, eventStatus) {
		this.eventStatus = eventStatus;
		this.userId = userId
  },
	
  onclick: function(event) {
	if(this.eventStatus == 'past')
	{
		$('current_event_in_dashboard_span').className = ''
		$('past_event_in_dashboard_span').className = 'active'
	}
	else
	{
		$('current_event_in_dashboard_span').className = 'active'
		$('past_event_in_dashboard_span').className = ''
	}
		url = "/users/"+this.userId+"/dashboards";
		params = $H({event_status: this.eventStatus}).toQueryString();
		new Ajax.Request(url+"?"+params, {asynchronous: true, evalScripts: true, method: 'GET'});
		//Event.stop(event);
	}
};



