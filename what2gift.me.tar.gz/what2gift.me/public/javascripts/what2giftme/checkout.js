var UpdateCheckoutList = {
  initialize: function(wishlistId,inventoryId, url) {
		this.wishlistId = wishlistId;
		this.inventoryId = inventoryId;
		this.url = url;
  },
  onclick: function(event) {
		params = $H({wishlist_id: this.wishlistId, inventory_id: this.inventoryId}).toQueryString();
		new Ajax.Request(this.url+'?'+params , {asynchronous: true, evalScripts: true, method: 'POST'});
		//Event.stop(event);
	}
};

var DeleteGiftFromCheckout = {
  initialize: function(wishlistId, url) {
		this.wishlistId = wishlistId;
		this.url = url;
  },
  onclick: function(event) {
		params = $H({wish_list_id: this.wishlistId}).toQueryString();
		if(confirm("Do you want to delete this gift?"))
			new Ajax.Request(this.url + "?"+params , {asynchronous: true, evalScripts: true, method: 'DELETE'});
		//Event.stop(event);
	}
};


function UpdateWishList(obj, eventId)
{
	params = $H({event_id: eventId}).toQueryString();
	new Ajax.Request(obj.form.action+'?'+params, {asynchronous: true, evalScripts: true, parameters:Form.serialize(obj.form), method: 'POST'});
}


function AddedCheckoutList(wishlistId, eventId)
{
	params = $H({wish_list_id: wishlistId, event_id: eventId}).toQueryString();
	url =  "/checkout_lists"
	new Ajax.Request(url+'?'+params, {asynchronous: true, evalScripts: true, method: 'POST'});
}

var ReserveGiftFromCheckout = {
  initialize: function(eventId, url) {
		this.eventId = eventId;
		this.url = url;
  },
  onclick: function(event) {
		params = $H({event_id: this.eventId}).toQueryString();
		new Ajax.Request(this.url +'?'+params , {asynchronous: true, evalScripts: true, method: 'POST', onLoading: $('spinner_for_invitation').show()});
		//Event.stop(event);
	}
};
