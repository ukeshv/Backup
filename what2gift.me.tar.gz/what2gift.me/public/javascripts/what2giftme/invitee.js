var InvitesController = Class.create({
  initialize: function(form, userId, eventId) {
		this.userId = userId;
		this.eventId = eventId;
		this.formElement = form;
		// form submission
		Object.extend($('add_my_invitee'), UpdateContactList).initialize(this.formElement, this.eventId);
		Object.extend($('reset_my_invitee'), ResetInvitesForm).initialize(this.formElement, this.eventId);
  }
});

var UpdateContactList = {
  initialize: function(formElement,eventId) {
		this.formElement = formElement;
		this.eventId = eventId;
  },
	
  onclick: function(event) {
		if(this.formElement['event_update_id'] && this.formElement['event_update_id'].value == "edit")
		{
			this.formElement.action = "/publish_events/"+this.formElement['udatestatus'].value+"?event_id="+this.eventId;
			new Ajax.Request(this.formElement.action, {asynchronous: true, evalScripts: true, parameters:Form.serialize(this.formElement), method: 'PUT'});
			//this.formElement['event_update_id'].value = "new";
			//$('change_invite_title_content').innerHTML = "Enter New Contact"
			//$('add_my_invitee').innerHTML = "Add Contact"
			//this.formElement.action = "/publish_events/new?event_id="+this.eventId;
		}
		else
			new Ajax.Request(this.formElement.action, {asynchronous: true, evalScripts: true, parameters:Form.serialize(this.formElement), method: 'POST', onLoading: this.onLoadingElement(), onSuccess: this.onSuccessElement()});
		//Event.stop(event);
  },
	
	onLoadingElement: function() {
		$('add_my_invitee').hide();
		$('reset_my_invitee').hide();
		$('spinner_for_invitation_update').show();
  },
	
	onSuccessElement: function() {
		$('spinner_for_invitation_update').hide(); 
		$('add_my_invitee').show();
		$('reset_my_invitee').show();
	}
	
};

var ResetInvitesForm = {
  initialize: function(formElement,eventId) {
		this.formElement = formElement;
		this.eventId = eventId;
  },
	
  onclick: function(event) {
		this.formElement['event_update_id'].value = "new";
		this.formElement['udatestatus'].value = "";
		this.formElement['invitee[fname]'].value  = "";
		this.formElement['invitee[lname]'].value  = "";
		this.formElement['invitee[description]'].value  = "";
		this.formElement['invitee[phone]'].value  = "";
		this.formElement['invitee[mobile]'].value  = "";
		this.formElement['invitee[email]'].value  = "";
		
		this.formElement['invitee_category'].checked = false;
		/*this.formElement['invitee_category[2]'].checked = false;
		this.formElement['invitee_category[3]'].checked = false;
		this.formElement['invitee_category[4]'].checked = false;
		this.formElement['invitee_category[5]'].checked = false;*/
		//this.formElement['invitee_category[6]'].checked = false;
		$('invitee_phone_error').innerHTML = "";
		$('invitee_mobile_error').innerHTML = "";
		$('invitee_email_error').innerHTML = "";
		$('invitee_fname_error').innerHTML = "";
		$('invitee_lname_error').innerHTML = "";
		$('invitee_category_id_error').innerHTML = "";
		this.formElement.action = "/publish_events?event_id="+this.eventId;
		//Event.stop(event);
  }
};

var EditMyContactList = {
  initialize: function(userId, eventId, inviteId) {
		this.userId = userId;
		this.eventId = eventId;
		this.inviteId = inviteId;
		this.formElement = $('cmaForm1')
  },
	
  onclick: function(event) {
		$('invitee_phone_error').innerHTML = "";
		$('invitee_mobile_error').innerHTML = "";
		$('invitee_email_error').innerHTML = "";
		$('invitee_fname_error').innerHTML = "";
		$('invitee_lname_error').innerHTML = "";
		$('invitee_category_id_error').innerHTML = "";
		this.formElement.action = "/publish_events/"+this.inviteId+"/edit"
		params = $H({event_id: this.eventId}).toQueryString();
		new Ajax.Request(this.formElement.action+"?"+params, {asynchronous: true, evalScripts: true, method: 'GET', onComplete: this.successfulSave.bind(this)});
		//Event.stop(event);
  },
	
	successfulSave: function(o) {
		var EditValue = o.responseText.evalJSON();
		this.formElement['event_update_id'].value = "edit";
		this.formElement['udatestatus'].value = EditValue.invitee.id;
		this.formElement['invitee[fname]'].value  = EditValue.invitee.fname;
		this.formElement['invitee[lname]'].value  = EditValue.invitee.lname;
		this.formElement['invitee[description]'].value  = EditValue.invitee.description;
		this.formElement['invitee[phone]'].value  = EditValue.invitee.phone;
		this.formElement['invitee[mobile]'].value  = EditValue.invitee.mobile;
		this.formElement['invitee[email]'].value  = EditValue.invitee.email;
		$('invitee_category_'+EditValue.invitee.invitee_category_id.split(',')[0]).checked = true
		/*if( EditValue.invitee.invitee_category_id.include(this.formElement['invitee_category[6]'].value))
			this.formElement['invitee_category[6]'].checked = true;*/
		
		this.formElement.action = "/publish_events/"+this.formElement['udatestatus'].value+"?event_id="+this.eventId;
		//$('change_invite_title_content').innerHTML = "Edit Your Contact"
		//$('add_my_invitee').innerHTML = "Edit Contact"
  }
	
};

var DeleteMyContactList = {
  initialize: function(userId, eventId, inviteId) {
		this.userId = userId;
		this.eventId = eventId;
		this.inviteId = inviteId;
		this.formElement = $('cmaForm1')
  },
	
  onclick: function(event) {
		this.formElement.action = "/publish_events/"+this.inviteId
		params = $H({event_id: this.eventId}).toQueryString();
		if(confirm("Do you want to delete ?"))
			new Ajax.Request(this.formElement.action+"?"+params, {asynchronous: true, evalScripts: true, method: 'DELETE'});
		Event.stop(event);
  }
	
};

var SendInvitationToMyContactList = {
  initialize: function(userId, eventId, inviteIds) {
		this.userId = userId;
		this.eventId = eventId;
		this.inviteIds = inviteIds;
  },
	
  onclick: function(event) {
		var SendInvitesIds=new Array();
		var j = 0;
		var InviteeCheckbox = document.getElementsByClassName("invitee_checkbox");
		for(i=0;i<InviteeCheckbox.length;i++)
		{
			if(InviteeCheckbox[i].checked)
			{
				SendInvitesIds[j] = InviteeCheckbox[i].value
				j = j + 1;
			}
		}
		url = "/publish_events/"+this.eventId+"/send_invitation"
		params = $H({invite_id: SendInvitesIds.join(",")}).toQueryString();
		new Ajax.Request(url+"?"+params, {asynchronous: true, evalScripts: true, method: 'POST', onSuccess: this.successfulSendInvitation.bind(this), onLoading: this.onSuccessElement.bind()});
		//Event.stop(event);
  },
	
	successfulSendInvitation: function(o) {
		$('send_invititation_to_invitee').show();
		var InviteeCheckbox = document.getElementsByClassName("invitee_checkbox");
		$('spinner_for_invitation').hide();
		for(i=0;i<InviteeCheckbox.length;i++)
		{
			if(InviteeCheckbox[i].checked)
			{
				InviteeCheckbox[i].checked = false;
			//	j = j + 1;
			}
			
		}
  },
	
	onSuccessElement: function() {
		$('spinner_for_invitation').show(); 
		$('send_invititation_to_invitee').hide();
	}
	
};


function SortingWithAlbhabet(obj, eventId)
{
	url ="/publish_events/"+eventId+"/sorting_with_albhabet"
	params = $H({sort_value: obj.innerHTML}).toQueryString();
	new Ajax.Request(url+"?"+params, {asynchronous: true, evalScripts: true, method: 'POST'});
}
