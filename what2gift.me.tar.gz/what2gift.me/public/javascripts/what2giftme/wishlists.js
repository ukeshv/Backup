var WishlistsController = Class.create({
  initialize: function(userId, eventId) {
		this.userId = userId;
		this.eventId = eventId;
		// form submission
		Object.extend($('category_id'), UpdateWishList).initialize(this.userId, this.eventId);
		Object.extend($('brand_id'), UpdateWishList).initialize(this.userId, this.eventId);
		Object.extend($('price_range_id'), UpdateWishList).initialize(this.userId, this.eventId);
  }
});

var UpdateWishList = {

  initialize: function(userId, eventId) {
		this.userId = userId;
		this.eventId = eventId;
  },
	
  onchange: function() {
		this.form.action = "/wish_lists/"+this.userId+"/list_inventories"
		params = $H({event_id: this.eventId}).toQueryString();
		new Ajax.Request(this.form.action+'?'+params, {asynchronous: true, evalScripts: true, parameters:Form.serialize(this.form), method: 'POST', onSuccess: this.successfulSave.bind(this)});
  },
	
	successfulSave: function(o) {
		
  }
};



var DisplayProductInformation = {
  initialize: function(InventoryId, EventId,UserId) {
		this.InventoryId = InventoryId;
		this.EventId = EventId;
		this.UserId = UserId;
  },
	
  onclick: function(event) {
		url = "/wish_lists/"+this.InventoryId+"/display_particular_product"
		params = $H({event_id: this.EventId}).toQueryString();
		new Ajax.Request(url+"?"+params, {method: 'post', evalScripts: true});
		//Event.stop(event);
  }
};



function add(inventoryId, eventId)
{
url = "/wish_lists"
params = $H({event_id: eventId, inventory_id: inventoryId}).toQueryString();
new Ajax.Request(url + '?' + params, {method: 'post', evalScripts: true});
}

function removeItem(userId, wishListId,eventId,inventoryName,placeStatus)
{
if(placeStatus == 'dashboard')
	url = "/users/"+userId+"/dashboards/"+wishListId
else
	url = '/wish_lists/'+wishListId
if(confirm("Are you sure to remove " + inventoryName + " from your wishlist?"))
{
	params = $H({event_id: eventId}).toQueryString();
	new Ajax.Request(url  + '?' + params, {method: 'delete', evalScripts: true});
}
}


