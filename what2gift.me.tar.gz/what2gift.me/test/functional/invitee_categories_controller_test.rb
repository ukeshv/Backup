require 'test_helper'

class InviteeCategoriesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:invitee_categories)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create invitee_category" do
    assert_difference('InviteeCategory.count') do
      post :create, :invitee_category => { }
    end

    assert_redirected_to invitee_category_path(assigns(:invitee_category))
  end

  test "should show invitee_category" do
    get :show, :id => invitee_categories(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => invitee_categories(:one).to_param
    assert_response :success
  end

  test "should update invitee_category" do
    put :update, :id => invitee_categories(:one).to_param, :invitee_category => { }
    assert_redirected_to invitee_category_path(assigns(:invitee_category))
  end

  test "should destroy invitee_category" do
    assert_difference('InviteeCategory.count', -1) do
      delete :destroy, :id => invitee_categories(:one).to_param
    end

    assert_redirected_to invitee_categories_path
  end
end
