require 'test_helper'

class AccountSettings::PasswordsHelperTest < ActionView::TestCase
end
