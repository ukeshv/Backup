require 'test_helper'

class AccountSettings::ProfilesHelperTest < ActionView::TestCase
end
