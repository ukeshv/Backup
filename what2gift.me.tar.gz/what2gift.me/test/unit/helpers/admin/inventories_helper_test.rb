require 'test_helper'

class Admin::InventoriesHelperTest < ActionView::TestCase
end
