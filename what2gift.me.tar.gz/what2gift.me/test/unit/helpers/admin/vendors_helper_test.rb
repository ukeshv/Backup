require 'test_helper'

class Admin::VendorsHelperTest < ActionView::TestCase
end
