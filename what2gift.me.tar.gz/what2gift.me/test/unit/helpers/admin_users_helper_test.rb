require 'test_helper'

class AdminUsersHelperTest < ActionView::TestCase
end
