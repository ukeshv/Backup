require 'test_helper'

class Admins::AdminUsersHelperTest < ActionView::TestCase
end
