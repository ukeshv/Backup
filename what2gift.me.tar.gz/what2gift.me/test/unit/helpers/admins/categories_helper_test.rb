require 'test_helper'

class Admins::CategoriesHelperTest < ActionView::TestCase
end
