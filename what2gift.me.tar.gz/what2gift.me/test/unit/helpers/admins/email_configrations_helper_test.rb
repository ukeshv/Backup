require 'test_helper'

class Admins::EmailConfigrationsHelperTest < ActionView::TestCase
end
