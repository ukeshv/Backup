require 'test_helper'

class Admins::IntroductionMailsHelperTest < ActionView::TestCase
end
