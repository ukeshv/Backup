require 'test_helper'

class Admins::InventoriesHelperTest < ActionView::TestCase
end
