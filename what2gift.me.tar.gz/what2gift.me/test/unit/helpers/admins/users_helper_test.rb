require 'test_helper'

class Admins::UsersHelperTest < ActionView::TestCase
end
