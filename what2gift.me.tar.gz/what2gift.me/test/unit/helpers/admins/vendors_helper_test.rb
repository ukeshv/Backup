require 'test_helper'

class Admins::VendorsHelperTest < ActionView::TestCase
end
