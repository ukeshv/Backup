require 'test_helper'

class BrandsHelperTest < ActionView::TestCase
end
