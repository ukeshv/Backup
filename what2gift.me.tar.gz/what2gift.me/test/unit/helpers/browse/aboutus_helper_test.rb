require 'test_helper'

class Browse::AboutusHelperTest < ActionView::TestCase
end
