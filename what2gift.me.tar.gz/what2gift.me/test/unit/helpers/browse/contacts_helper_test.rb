require 'test_helper'

class Browse::ContactsHelperTest < ActionView::TestCase
end
