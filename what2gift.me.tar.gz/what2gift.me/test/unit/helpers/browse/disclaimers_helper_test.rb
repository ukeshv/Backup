require 'test_helper'

class Browse::DisclaimersHelperTest < ActionView::TestCase
end
