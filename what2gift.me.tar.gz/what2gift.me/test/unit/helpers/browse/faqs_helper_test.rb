require 'test_helper'

class Browse::FaqsHelperTest < ActionView::TestCase
end
