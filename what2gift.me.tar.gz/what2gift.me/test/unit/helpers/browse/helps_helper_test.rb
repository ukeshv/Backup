require 'test_helper'

class Browse::HelpsHelperTest < ActionView::TestCase
end
