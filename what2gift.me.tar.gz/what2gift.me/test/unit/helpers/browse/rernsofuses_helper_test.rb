require 'test_helper'

class Browse::RernsofusesHelperTest < ActionView::TestCase
end
