require 'test_helper'

class Browse::TermsofusesHelperTest < ActionView::TestCase
end
