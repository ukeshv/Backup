require 'test_helper'

class DashboardsHelperTest < ActionView::TestCase
end
