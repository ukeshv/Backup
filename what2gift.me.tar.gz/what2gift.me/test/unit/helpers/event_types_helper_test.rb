require 'test_helper'

class EventTypesHelperTest < ActionView::TestCase
end
