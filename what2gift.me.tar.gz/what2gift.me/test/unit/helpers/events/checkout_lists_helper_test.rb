require 'test_helper'

class Events::CheckoutListsHelperTest < ActionView::TestCase
end
