require 'test_helper'

class Events::PaymentProcessesHelperTest < ActionView::TestCase
end
