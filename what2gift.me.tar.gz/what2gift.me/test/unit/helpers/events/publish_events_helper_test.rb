require 'test_helper'

class Events::PublishEventsHelperTest < ActionView::TestCase
end
