require 'test_helper'

class Events::WishListsHelperTest < ActionView::TestCase
end
