require 'test_helper'

class InviteeCategoriesHelperTest < ActionView::TestCase
end
