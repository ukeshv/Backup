require 'test_helper'

class InviteesHelperTest < ActionView::TestCase
end
